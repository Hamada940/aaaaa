#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

PROJECT_DIR="/opt/vine-drop-hub"
PAYLOAD="${VINE_INSTALL_PAYLOAD:-./vine-drop-hub-r25-new-vps.tar.gz}"
INITIAL_PROFILE=""
SKIP_DOCKER_INSTALL=0

usage() {
  cat <<'EOF'
Usage: sudo bash install-new-ubuntu.sh [options]

Options:
  --payload PATH       Authenticated release payload archive
  --project-dir PATH   Clean install path (default: /opt/vine-drop-hub)
  --profile PATH       Privately transferred OpenVPN .ovpn or WireGuard .conf profile
  --skip-docker-install
                       Require an existing working `docker compose`
  -h, --help           Show this help

Without --profile, the verified code, Docker, and host VPN manager are installed,
but Compose remains stopped until the private profile is supplied to
host/finalize-install.sh. No credentials or VPN material are embedded.
EOF
}

while (($#)); do
  case "$1" in
    --payload) (($# >= 2)) || { echo "ERROR: --payload needs a path." >&2; exit 2; }; PAYLOAD="$2"; shift 2 ;;
    --project-dir) (($# >= 2)) || { echo "ERROR: --project-dir needs a path." >&2; exit 2; }; PROJECT_DIR="$2"; shift 2 ;;
    --profile) (($# >= 2)) || { echo "ERROR: --profile needs a path." >&2; exit 2; }; INITIAL_PROFILE="$2"; shift 2 ;;
    --skip-docker-install) SKIP_DOCKER_INSTALL=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

fail() { echo "ERROR: $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || fail "run with sudo."
[[ -f /etc/os-release ]] || fail "/etc/os-release is missing."
# shellcheck disable=SC1091
source /etc/os-release
[[ ${ID:-} == ubuntu ]] || fail "this installer requires Ubuntu."
case "${VERSION_ID:-}" in
  22.04) DOCKER_SUITE=jammy ;;
  24.04) DOCKER_SUITE=noble ;;
  *) fail "this release requires Ubuntu 22.04 or 24.04; found ${VERSION_ID:-unknown}." ;;
esac
[[ "$(dpkg --print-architecture)" == amd64 ]] || fail "this release requires x86-64/amd64 Ubuntu."
[[ -s $PAYLOAD ]] || fail "payload missing or empty: $PAYLOAD"
[[ -z $INITIAL_PROFILE || -s $INITIAL_PROFILE ]] || fail "initial profile missing or empty: $INITIAL_PROFILE"
[[ $PROJECT_DIR == /* && $PROJECT_DIR != / && $PROJECT_DIR != *$'\n'* && $PROJECT_DIR != *$'\r'* && $PROJECT_DIR != *$'\t'* && $PROJECT_DIR != *' '* ]] || \
  fail "project path must be an absolute non-root path without whitespace."
if [[ -e $PROJECT_DIR || -L $PROJECT_DIR ]]; then
  fail "clean-install destination already exists: $PROJECT_DIR"
fi
[[ ! -e /etc/systemd/system/vine-vpn-profile-manager.service && ! -L /etc/systemd/system/vine-vpn-profile-manager.service ]] || \
  fail "Vine VPN manager unit already exists; this is not a clean destination."
for command_name in awk bash dpkg install mktemp python3 readlink sha256sum tar; do
  command -v "$command_name" >/dev/null 2>&1 || fail "missing required command: $command_name"
done

install_docker() {
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    echo "Docker Compose is already available."
    return
  fi
  ((SKIP_DOCKER_INSTALL == 0)) || fail "docker compose is unavailable and --skip-docker-install was used."

  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y ca-certificates curl gnupg python3
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  cat >/etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $DOCKER_SUITE
Components: stable
Architectures: amd64
Signed-By: /etc/apt/keyrings/docker.asc
EOF
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  systemctl enable --now docker
  docker compose version
}

install_docker
command -v python3 >/dev/null || fail "python3 is required."
command -v sha256sum >/dev/null || fail "sha256sum is required."

parent_dir="$(dirname "$PROJECT_DIR")"
install -d -m 755 "$parent_dir"
parent_dir="$(readlink -f "$parent_dir")"
PROJECT_DIR="$parent_dir/$(basename "$PROJECT_DIR")"
[[ ! -e $PROJECT_DIR && ! -L $PROJECT_DIR ]] || fail "clean-install destination appeared concurrently: $PROJECT_DIR"
tmpdir="$(mktemp -d "$parent_dir/.vine-fresh-install.XXXXXXXX")"
candidate="$tmpdir/candidate"
mkdir -p "$candidate"
cleanup() { rm -rf "$tmpdir"; }
trap cleanup EXIT

python3 - "$PAYLOAD" <<'PY_PAYLOAD_SAFETY'
import pathlib, sys, tarfile
archive = pathlib.Path(sys.argv[1])
seen = set()
with tarfile.open(archive, "r:gz") as handle:
    for member in handle.getmembers():
        name = member.name
        pure = pathlib.PurePosixPath(name)
        if not name or pure.is_absolute() or ".." in pure.parts or str(pure) != name:
            raise SystemExit(f"ERROR: unsafe payload path: {name!r}")
        if name in seen:
            raise SystemExit(f"ERROR: duplicate payload path: {name}")
        seen.add(name)
        if not member.isfile() or member.issym() or member.islnk():
            raise SystemExit(f"ERROR: only regular payload files are permitted: {name}")
PY_PAYLOAD_SAFETY

tar -xzf "$PAYLOAD" -C "$candidate"
[[ -f "$candidate/.new-machine-files.sha256" ]] || fail "payload manifest missing."
[[ -f "$candidate/.new-machine-paths" ]] || fail "payload path inventory missing."
(
  cd "$candidate"
  sha256sum -c .new-machine-files.sha256 >/dev/null
)
python3 - "$candidate" <<'PY_INVENTORY'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1])
paths = root.joinpath('.new-machine-paths').read_text(encoding='utf-8').splitlines()
metadata = json.loads(root.joinpath('.new-machine-release.json').read_text(encoding='utf-8'))
expected_count = metadata.get('managedPathCount')
if not isinstance(expected_count, int) or expected_count < 64:
    raise SystemExit('ERROR: payload managed-path count is invalid')
if len(paths) != expected_count or paths != sorted(set(paths)):
    raise SystemExit(f'ERROR: payload must contain {expected_count} sorted unique managed paths')
actual = sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())
expected = sorted(paths + ['.new-machine-files.sha256', '.new-machine-paths'])
if actual != expected:
    raise SystemExit('ERROR: payload inventory differs from authenticated manifests')
if metadata.get('releaseId') != 'r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18':
    raise SystemExit('ERROR: payload release metadata is wrong')
if metadata.get('containsPrivateRuntimeState') is not False:
    raise SystemExit('ERROR: payload claims to contain private runtime state')
PY_INVENTORY

bash -n "$candidate/install-new-ubuntu.sh" "$candidate/host/finalize-install.sh" "$candidate/vpn/prepare-profile.sh"
python3 - "$candidate/host/vpn_profile_manager.py" <<'PY_COMPILE_MANAGER'
import pathlib, sys
source = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
compile(source, sys.argv[1], 'exec')
PY_COMPILE_MANAGER

mv "$candidate" "$PROJECT_DIR"
unit_installed=0
rollback_install() {
  status=$?
  trap - EXIT
  if ((status != 0)); then
    systemctl stop vine-vpn-profile-manager.service >/dev/null 2>&1 || true
    rm -rf "$PROJECT_DIR"
    if ((unit_installed)); then
      rm -f /etc/systemd/system/vine-vpn-profile-manager.service
      systemctl daemon-reload >/dev/null 2>&1 || true
    fi
  fi
  cleanup
  exit "$status"
}
trap rollback_install EXIT

chown -R root:root "$PROJECT_DIR"
find "$PROJECT_DIR" -type d -exec chmod 755 {} +
chmod 700 "$PROJECT_DIR/vpn" "$PROJECT_DIR/host"
chmod 700 \
  "$PROJECT_DIR/install-new-ubuntu.sh" \
  "$PROJECT_DIR/host/finalize-install.sh" \
  "$PROJECT_DIR/host/vpn_profile_manager.py" \
  "$PROJECT_DIR/vpn/prepare-profile.sh"
install -d -m 700 -o 1000 -g 1000 "$PROJECT_DIR/data" "$PROJECT_DIR/vpn-control/inbox"
install -d -m 700 "$PROJECT_DIR/vpn-control/processing" "$PROJECT_DIR/vpn/profile-backups"
install -d -m 755 "$PROJECT_DIR/vpn-control/status"
chown -R 1000:1000 "$PROJECT_DIR/data" "$PROJECT_DIR/vpn-control/inbox"

sed "s|@PROJECT_DIR@|$PROJECT_DIR|g" \
  "$PROJECT_DIR/host/vine-vpn-profile-manager.service" \
  >/etc/systemd/system/vine-vpn-profile-manager.service
unit_installed=1
chmod 644 /etc/systemd/system/vine-vpn-profile-manager.service
systemctl daemon-reload
systemctl enable --now vine-vpn-profile-manager.service

trap cleanup EXIT

echo
echo "Verified application code installed at $PROJECT_DIR"
echo "Application release: r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18"

if [[ -n $INITIAL_PROFILE ]]; then
  exec "$PROJECT_DIR/host/finalize-install.sh" --project-dir "$PROJECT_DIR" --profile "$INITIAL_PROFILE"
fi

cat <<EOF

Compose was intentionally not started because no private --profile was supplied.
Privately transfer either a self-contained OpenVPN .ovpn file or a standard
WireGuard .conf file to this server without pasting its contents into chat, then
run:

  sudo $PROJECT_DIR/host/finalize-install.sh \\
    --project-dir $PROJECT_DIR \\
    --profile /private/path/profile.ovpn-or.conf

After success, remove only the extra transferred copy. The canonical root-owned
profile remains under $PROJECT_DIR/vpn/.
EOF
