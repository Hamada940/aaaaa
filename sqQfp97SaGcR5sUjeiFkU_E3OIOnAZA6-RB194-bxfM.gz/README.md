# Vine Drop Hub — UV + VHelper + SmartViner live alerts

This R25 release adds an optional Windows Chrome/Edge **PC Order Companion** plus exact-ASIN AFA/AI watches and durable safety controls while preserving the R24 Ultraviner (`UV`), VHelper (`VH`), and global-only SmartViner (`SV`) live-source behavior. Detection, merging, first-alert delivery, and rules remain on the VPS; Amazon-authenticated Vine ordering runs only in the user's local browser through a loopback SSH forward. Matching ASINs still share one card, and later source confirmations remain silent. There is no live-event debounce, batch window, frame scheduler, intentional alert delay, or SmartViner reconnect catch-up request.

Broad automatic rules are disabled by default. First-match rules can use words/phrases (substring, exact phrase, whole-word, or exact title/brand), item retail price, ETV, or combined AND/OR logic, while an explicit **Order on PC** button is available on live cards. Clicking a **Live Feed product photo** now invokes that exact same confirmation-only action; it never dispatches or places an order by itself. The first valid photo or button press is captured at the stable document layer, so UV/VH card replacement during the pointer sequence cannot swallow it; it immediately opens one dashboard confirmation, while unavailable states explain their reason instead of silently ignoring input. VH RFY Server records and UV Explorer RFY/AFA records cannot be ordered directly; they may only arm a one-shot watch that waits for a later fresh trusted event explicitly/derivably publishing that ASIN into AFA or AI, then uses only that event's order metadata. Valid embedded children appear immediately. The watch dialog also offers two separately labeled, click-only sources: **Load variants from Amazon via PC** uses companion 25.0.4 and the local authenticated Amazon.ca session, while **Load variants from VHelper** uses one sanitized official VHelper 4.7.4 `item_explorer_variants` response. Neither source runs automatically, retries, or falls back to the other, and loaded choices remain only in the open dialog. **Any currently available variant** remains the default; companion 25.0.4 revalidates an exact child against current Amazon data and never substitutes another option. The item-price rule is separate from the final Amazon payable-total gate. C$30 is the proposed initial unattended cap; it is editable, and an exact higher total requires approval on the PC. Emergency pause, an acknowledge-only circuit breaker, and disabled-by-default rolling 24-hour automatic count/charge controls fail closed without deleting configuration. Signed one-time jobs follow **See Details → Request Product → Vine checkout → Place your order** and never blindly retry an uncertain placement. See `PC_ORDER_COMPANION.md`.

SmartViner is a clean-room connector based on the statically reviewed 0.9.42 protocol surface. It accepts only global `NewGlobalItemDiscovered` products on the authenticated private marketplace channel. Personalized `RfyItemDiscovered` frames are discarded before product normalization and can never enter storage, cards, activity, or notifications. Catalogue/history, reviews, chat, AI Shopper, ordering, account scraping, telemetry, webhooks, full SmartViner UI, and missed-discovery catch-up are excluded. The supplied proprietary extension is not copied, embedded, modified, or repackaged. See `SMARTVINER_LIVE_SOURCE.md`.

The split-route dual-stack Compose deployment sends UV and SmartViner through an application-only OpenVPN or WireGuard tunnel. The dashboard accepts the existing self-contained `.ovpn` format plus standard WireGuard `.conf` upload and dedicated manual WireGuard fields. WireGuard IPv4/IPv6 configuration, private-key isolation, pinned-Gluetun adaptation, health checks, and cross-protocol rollback are documented in `DASHBOARD_VPN_UPLOAD.md` and `GLUETUN_V3_41_1_WIREGUARD_AUDIT.md`. SmartViner additionally uses its own destination-locked CONNECT process at VPN-loopback `127.0.0.1:8889`; it never uses VHelper's direct-egress exception. VH remains destination-locked through the normal VPS route because its Cloudflare edge rejects the VPN exit. The dashboard remains bound to `127.0.0.1:3001` for SSH-tunnel-only access.

The live VH transport still prohibits `getLast100` in every startup, recovery, health, and manual-refresh path so source races use genuine live events only. R20 added explicit signed RFY Item Explorer, R21 added explicit click-only trial status, R22 bounded broadcast-gap recovery, and R23 isolated different-account UV onboarding plus blank notification-secret preservation. VHelper Package B preserves the existing working legacy synthetic UUID/CID without automatic migration; see `PACKAGE_B_IMPLEMENTATION.md` and `VHELPER_PROTOCOL_AUDIT.md`.

Release `r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18` is a narrow successor to the authenticated VHelper 4.7.4/build-3637 dashboard release. A silent UV identification timeout now enters one bounded, jittered exponential cooldown and retries automatically; a non-empty plan or real live alert resets the consecutive timeout state. Explicit WebSocket `invalidToken` remains terminal and manual-only, and the separate signed-search diagnostic cannot bypass it. UV diagnostics show timeout totals and pending retry timing. Live Feed now loads the newest **500** matching records first and offers **Load 500 more** through the retained **2,000**-item ceiling, while a bounded WebSocket overlay keeps fresh events visible immediately during older-page requests. No feed identity, credential, signed-search, passive-delivery, health-alert deduplication, ordering, VPN, or private-state boundary was widened.

## Files

- `server.js` — Express server, UV/VH/SV ingestion and health, first-live notification policy, persistence, REST API, and local `/ws-feed` WebSocket.
- `lib/source-registry.js` — three-source normalization, genuine-live merge decisions, immutable source clocks, and UV/VH/SV race summaries.
- `lib/sv-protocol.js` / `lib/sv-client.js` — pinned SmartViner live-event normalization, isolated rotating session state, authenticated private-channel client, reconnect, and redaction.
- `sv-connect-proxy.js` — VPN-namespace loopback CONNECT proxy hard-locked to `smartviner.com:443`.
- `SMARTVINER_LIVE_SOURCE.md` — scope, credential boundary, local onboarding, status, recovery, and user-run verification.
- `lib/vh-identity.js` / `lib/vh-protocol.js` — hardened/legacy identity policy, signing, FID provisioning, and audited VH normalization.
- `lib/vh-item-explorer.js` — strict RFY-only Item Explorer request validation, exact official 4.7.4 request construction, and bounded response sanitization.
- `lib/vh-item-explorer-variants.js` — strict Watch-click request validation, exact official 4.7.4 `item_explorer_variants` field order (`version`, not `app_version`), and child-ASIN/title/ETV sanitization.
- `lib/vh-trial-status.js` — strict click-request validation, exact official 4.7.4 `get_user_stats` request construction, and allowlisted trial-response sanitization.
- `lib/uv-protocol.js` — pinned UV runtime/launcher identifiers, account-housekeeping compatibility, and additive order-progress normalization.
- `lib/uv-retry-controller.js` — one bounded, jittered UV reconnect scheduler with timeout counters, terminal invalid-token latching, and authentication-evidence reset.
- `lib/uv-categories.js` — the exact 90-entry English UV 26.9.38 category ID/name/icon catalog plus UV-only category normalization.
- `lib/priority-rules.js` — offline-testable OR evaluation for keyword, price/ETV, and selected-category priority.
- `lib/live-persistence.js` — worker-thread persistence for live item/activity/notification deltas, keeping JSON serialization and disk writes off the feed event loop.
- `lib/cleared-item-memory.js` — bounded, persisted cleared-ASIN tombstones with editable expiry, restart-safe normalization, and silent UV/VH/SV confirmation tracking.
- `lib/order-protocol.js` / `lib/order-rules.js` / `lib/order-coordinator.js` — signed one-time order jobs/results plus independent read-only Amazon variant requests/results, explained first-match rules and preview, pairing/account binding, replay protection, rolling gates, and the sanitized ledger.
- `lib/order-watches.js` / `lib/order-safety.js` — persisted exact-ASIN one-shot watch lifecycle plus emergency-pause/circuit-breaker state.
- `companion/` — independent localhost/Amazon.ca-scoped MV3 extension, exact-total approval UI, Windows loopback-tunnel helpers, and local checkout executor.
- `PC_ORDER_COMPANION.md` — trust boundary, rule/final-total semantics, Windows setup, update, troubleshooting, and offline validation.
- `lib/vpn-profile.js` — bounded self-contained `.ovpn` validation plus standard/manual WireGuard parsing into one canonical private representation, with hooks, paths, and split tunnels rejected.
- `host/vpn_profile_manager.py` — narrow root-owned protocol-aware transaction manager with independent validation, host endpoint resolution, private complete-state backups, interruption recovery, dual-family health checks, and automatic restoration.
- `public/index.html` — dashboard with three-source cards/filters/race timing, dedicated isolated SmartViner onboarding and health, VH RFY Explorer, UV Catalog Explorer, Priority Categories, UV/VH diagnostics, and OpenVPN/WireGuard transactional switching/rollback.
- `config.json` — private per-installation settings; never distribute the populated working copy. The portable package supplies a blank safe version.
- `config.example.json` — safe template without real credentials.
- `package.json` / `package-lock.json` — Node dependencies and commands.
- `DEPLOY_FEED_HEALTH.md` — credential-safe manual deployment and rollback steps for the independent UV/VH health monitor.
- `MIGRATE_TO_NEW_UBUNTU.md` — recommended Ubuntu 22.04/24.04 installer, exact encrypted SSH-stream migration, fresh-install path, and cutover/rollback procedure.
- `DASHBOARD_VPN_UPLOAD.md` — OpenVPN/WireGuard validation boundary, dual-stack host-manager architecture, transaction states, recovery, and administration.
- `GLUETUN_V3_41_1_WIREGUARD_AUDIT.md` — direct pinned-source findings, endpoint-parser limitation, secret-file adaptation, firewall behavior, and dual-stack controls.
- `NEW_SERVER_INSTALL.md` — legacy/manual clean-Ubuntu recreation guide for the split-egress deployment.
- `install-new-ubuntu.sh` — clean Ubuntu 22.04 or 24.04 x86-64 installer used by the self-contained new-machine release.
- `update-working-vps.sh` — older Package B transactional in-place updater; do not use it over this release because it predates the VPN-manager Compose settings.
- `PACKAGE_B_IMPLEMENTATION.md` — identity modes, recovery/watchdogs, events, diagnostics, no-history trade-off, tests, and updater guarantees.
- `ULTRAVINER_26.9.38_STATIC_AUDIT.md` — historical full-file launcher/runtime comparison, protocol inventory, accepted changes, and deliberate exclusions.

## Where live alerts appear

A real UV WebSocket `alerts` message goes to **Live Feed**, not Explorer:

1. UV sends `type: "alerts"`.
2. `server.js` calls `ingestItem(..., "UV", "alerts")` and merges the ASIN in memory.
3. The server immediately broadcasts `new_item` on `/ws-feed` and starts configured Telegram/Discord requests.
4. `public/index.html` synchronously inserts only that card in its sorted position, plays its sound, and shows any priority toast.
5. A worker thread persists the item/activity/notification deltas to `data/*.json` without blocking live delivery.

There is no live-event debounce, batching window, `setTimeout`, animation-frame wait, or fixed burst size. Any number of different ASINs received together follows the same immediate per-item path rather than rebuilding the complete feed for every event. When UV, VH, and/or SV report the same ASIN, the first genuine live source creates the one card and notification. Every later source immediately patches that card through `update_item` and remains silent. The detail modal retains the complete source arrival order and each source's offset from the first arrival; the compatibility `leadMs` remains the first-to-second gap.

The R15 speed-only refinement keeps that behavior while removing avoidable work around it. UV and VH status frames are now emitted on real transitions rather than before every healthy item; status events no longer launch UV/VH diagnostic HTTP requests; the ten-second diagnostic/VPN poll runs only while the visible Settings tab is open; and live cards are found directly by ASIN instead of rebuilding a map of all rendered cards. Bounded in-memory measurements (the latest 256 samples) report server socket-receive-to-local-broadcast latency and this browser's WebSocket-receive-to-DOM-update latency in **Settings → UV Diagnostics**. Timing uses monotonic clocks, performs no network probe, and adds no timer, batching window, or frame-scheduling wait. Samples reset when the app process or browser page restarts.

The R16 notification-speed refinement applies exact per-item statistics deltas instead of scanning up to 2,000 browser items after every live update, compiles keyword/category/price settings once per settings change, trusts a server lookup that already proved a new ASIN is absent, reuses immutable UV routing data, amortizes bounded enrichment cleanup, and keeps routine success logging out of the default live path. Activity rows update locally without another HTTP fetch. Notification dedupe records are discarded only after the active dedupe window expires, bounding long-session memory without allowing an in-window second alert. These changes add no scheduler or notification delay.

The R17 VH stability repair follows the byte-identical official 4.5.2/build-3483 client’s connection semantics. A healthy Socket.IO transport remains connected when no application event or optional `broadcastSyncPong` appears within 30 seconds. Returned sync pongs still detect newer broadcast-marker mismatches, while Engine.IO failure, server denial, true connection errors, and the official three-hour refresh remain actionable. Planned same-socket recovery no longer becomes a false `io client disconnect` incident. No VH history probe was added, and invalid-UUID errors cannot silently alter saved identity material.

R22 corrects a failure observed when a newer server marker remained different after recovery: R21 repeatedly treated every returned marker as a new incident and could execute hundreds of reconnects. R22 records the gap once, permits one same-socket recovery, and suppresses additional marker-driven reconnects until a genuine new live VH broadcast arrives or local/server markers match. The returned pong still marks the transport healthy, the historical possible-gap warning remains visible, and no `getLast100`, backfill, polling, retry history request, identity mutation, or entitlement change is introduced.

R23 makes **Screens & Queues** the only credential-replacement surface for a different UV account. The new UV token and that account's customer ID/hash remain a mandatory atomic pair, while the Settings copies are read-only and excluded from `/api/config` saves. Blank Telegram token, Telegram chat ID, and Discord webhook controls now mean “preserve the saved value”; disabling Telegram remains an explicit checkbox. This prevents a UV account replacement or browser-cleared password field from silently deleting notification credentials, and prevents a later Telegram edit from retriggering UV onboarding validation.

R24 adds a separate **Settings → SmartViner Live Source** credential domain. Enter the SmartViner email and password only in the locally tunneled dashboard. The password is sent in one login request through the destination-locked VPN path, cleared from the browser input/request object, and never saved or logged. Only rotating access/refresh session state plus bounded account/marketplace metadata is stored in private `data/sv_auth.json` mode 0600. Browser APIs expose expiry/status booleans, never tokens. Generic Settings rejects every SmartViner field, and disconnecting or replacing SV leaves UV, VH, history, notification credentials, VPN material, and all other private state untouched.

The SV client is active on the VPS even while the browser is closed. It authenticates only `/api/v1/auth/login`, `/api/v1/auth/refresh`, `/api/v1/me`, `/broadcasting/auth`, and the pinned Reverb WebSocket. The proxy permits only `smartviner.com:443`. RFY is accepted only from the authenticated account-scoped event; RFY-shaped global events are discarded. Reconnect reauthorizes the live channel but deliberately performs no catalogue/history or gap-recovery request.

## Cleared-item suppression

**Clear Items**, an individual card clear, and selected-item clear now write only the card's canonical ASIN, clear time, and observed UV/VH/SV source names to private `data/cleared_items.json` before removing visible records. Product titles, images, prices, queue details, and notification credentials are never copied into this ledger. It is separate from `items.json`, activity, and the short notification-dedupe map.

While a tombstone is active, `ingestItem` rejects that ASIN before card lookup, activity creation, local WebSocket broadcast, browser sound, Telegram, or Discord. A delayed confirmation from UV, VH, or global-only SV updates the tombstone's source/last-confirmed metadata silently; it cannot recreate a card or notification. The ledger is normalized on restart, capped at 50,000 newest ASINs, and defaults to 24 hours from the most recent user clear.

Set **Settings → Cleared-Item Memory → Suppress cleared ASINs for (hours)** from `0` through `8760`. Changing the duration applies to retained clear times; shortening it prunes records that are already too old. `0` explicitly disables and erases the tombstone ledger, restoring legacy clear behavior. **Reset cleared-item memory** is separate, requires typing `RESET CLEARED ITEM MEMORY`, exposes no retained ASIN list, and never restores deleted cards. Once a tombstone expires or is reset, a later discovery follows the ordinary one-card, first-genuine-source, notification-dedupe, and priority rules. No debounce, batch, timer, or alert wait is introduced; a genuinely new ASIN still starts browser and outbound notification delivery before persistence.

The R18 passive VH enrichment UI makes server-granted `newVariants` and `newPrice`/`additional_img` data useful without making any new request. Product Details shows normalized variant labels/ASIN links and an in-place additional-image gallery. R21 removes only the compact variant/photo count overlays from card images; the received image/variant data, primary card image, Product Details gallery, and variant details remain intact. Late enrichment immediately patches the existing card and an already-open detail modal, but remains silent: the initial alert is never delayed and no second sound, toast, Telegram, or Discord notification is produced. Image URLs are protocol-validated and deduplicated before rendering.

R19 added source-specific `vhQueue` and `uvQueue` retention so a later equal-confidence observation from the other live feed cannot erase the queue each source actually supplied. R20 preserves that live-ingestion behavior but replaces the visible passive-only VH tab with the requested **VH RFY Server Explorer** for older records available through VHelper's trial/Tier 3 Item Explorer.

Opening the R20 tab is local UI only. A request occurs only after an explicit **Search**, **Previous**, or **Next** action. The backend strictly validates ASIN, title/wildcard, official ordering, ETV range, price range, availability, and page; fixes the VHelper queue to `potluck` (RFY); materializes the current saved VH identity without provisioning or saving it; builds the official API-version-5 / app-version-4.7.4 `action: "item_explorer"` object; and signs it with that identity's existing P-256 signing material. UUID, CID, keys, signature, and proxy details never reach the browser.

The endpoint serializes requests, rejects reused one-time request IDs, enforces VHelper's returned `wait_time`, caps request/response sizes, and makes no automatic retry or poll. A genuine `invalid_uuid` or subscription/trial insufficiency is shown without calling identity repair, rotation, replacement, relinking, or entitlement bypass.

R21 adds **Check Trial Status** in the same tab. It sends one signed API-version-5 / app-version-4.7.4 `action: "get_user_stats"` request only after that button is pressed, using the current saved UUID/CID/FID. It shares Item Explorer's one-request-at-a-time mutex, one-time request-ID replay cache, and server cooldown. The backend allowlists `trial_active`, valid Unix-seconds `trial_ends_at`, and numeric Patreon tier 0–3, calculates days remaining from the check time, and returns only those fields plus exact ISO/check times and cooldown. `resolved_uuid`, UUID-mismatch hints, linked devices, contribution statistics, payment fields, and every unrelated response property are discarded. The result remains only in browser memory; page load, tab switching, timers, retries, and background tasks never perform this check. Server entitlement is displayed as reported and is never inferred, extended, reset, or bypassed.

The three authorized VHelper signed reads are therefore RFY-only `item_explorer`, Watch-dialog-click-only `item_explorer_variants`, and click-only `get_user_stats` for trial status. They share one in-flight mutex, replay cache, and VHelper-directed cooldown. The variants exception is narrower than ordinary search: opening a card/dialog, switching tabs, arming a watch, starting the app, or any timer performs no lookup; one VHelper button click makes at most one VHelper request with no retry or automatic alternate source. In a UV RFY/AFA watch dialog, the separately labeled Amazon-via-PC button is an independent user action and never runs as fallback. The VHelper response is capped, allowlisted to targetable child ASIN plus bounded title-derived combination and ETV, held only for the open dialog, and neither persisted nor merged into the live item store. Only a child explicitly selected when the watch is armed is retained in that watch. None of these VHelper paths calls `getLast100`, signed `get_info`, broadcast logs, Amazon product-detail endpoints, or unrelated VH actions; `get_user_stats` contribution/device/payment fields are expressly discarded rather than displayed or stored. Ordinary Item Explorer embedded variants remain bounded and secret-free as before.

Returned Item Explorer records are sanitized to a maximum official page of 50 and rendered as read-only **VH Server** cards. They remain browser-only: they are not added to `allItems`, persisted, merged with live ASIN cards, selected for batch deletion, evaluated as live priority drops, or sent through the live browser sound/priority-toast, Telegram, Discord, or other notification paths. Their exact ASIN/title and an optional already-returned child-ASIN choice may be copied into a separate one-shot waiting watch, but no RFY enrollment/order metadata is retained or dispatched. The existing one-card live UV/VH merge and first-alert path is untouched.

Two-token Vine searches are selected by whitespace token before wrappers are removed, preserving meaningful punctuation inside brand names. For example, `GL.iNet Flint 4` now searches for `GL.iNet Flint`, rather than treating the period as a boundary and searching for `GL iNet`. The same canonical URL is used by explicit **Open Vine Search** links, read-only Explorer/server-record photos, the Telegram button, and the Discord link. A Live Feed photo is intentionally different in this release: it opens the existing **Order on PC** confirmation and sends nothing until **Send to PC** is pressed. Stored item links are recomputed at startup so existing cards are repaired as well as future drops.

Queue labels now honor Ultraviner's official product `type` before applying any fallback (`VENDOR_TARGETED` → RFY, `VENDOR_VINE_FOR_ALL` → AFA, and `VINE_FOR_ALL`/`ALL_ITEMS` → AI). Queue provenance is confidence-ranked, so a queue-less frame's default AI can enrich a same-ASIN card but cannot relabel an already known AFA/RFY queue. At startup, a stored both-source AI card is repaired only when the retained local activity log proves the legacy collision sequence—VH first reported AFA/RFY and UV replaced it with default AI within five minutes. This does not guess from titles or bulk-change genuine AI cards. The card and Product Details modal derive both queue text and color from the same resolved value.

Ultraviner's alert origin is a separate dimension. `ultraviner`, `brenda`, and `redrop` identify how a product alert entered UV; they do not replace RFY/AFA/AI. A Brenda event carrying `VENDOR_VINE_FOR_ALL`, for example, is displayed as **AFA** with a separate **Brenda** origin badge. On product cards only, the ordinary **Ultraviner** origin badge is hidden when the visible source badge already says **UV** or **UV + VH**; Brenda and Redrop remain visible. The underlying origin remains available to live-feed filters, Product Details, the API (`alert_origin`), statistics, Telegram captions, and configured Discord notifications. Startup safely migrates the old `Discord/Brenda` queue mistake: it retains Brenda as origin and reclassifies the Vine queue from already stored official product metadata/order counts, falling back to low-confidence AI only when no queue evidence exists. It does not invent missing Redrop provenance for old cards.

Live Telegram drops use `sendPhoto` with the full caption and prominent **Open Vine Search** and **View on Amazon** URL buttons. Telegram itself always opens a tapped photo in its media viewer—the Bot API provides no link target for the media—so the first button opens exactly the same per-item Vine search URL as the dashboard's explicit **Open Vine** action and read-only Explorer/server photo links. If the product has no usable image or Telegram rejects the remote image, the application falls back to one text alert with the same buttons and link previews disabled. Dashboard WebSocket delivery and the Telegram photo request are both started in the receiving event-loop turn, before activity/item/notified persistence is handed to the worker thread. Photo delivery can be slower than text because Telegram must retrieve and process the remote product image, and Telegram plus the phone operating system remain external delivery hops.

`alertDetail` and `pageData` only enrich an existing Live Feed item through `update_item`; they do not create another drop. The **UV RFY & Catalog Explorer** remains populated only by its own active/manual `/api/explore` catalog query. The separate **VH RFY Server Explorer** uses explicit signed `/api/vh/item-explorer/search` requests with fixed RFY queue `potluck`; its sanitized results never enter the Live Feed or UV explorer. `/api/vh/item-explorer/variants` is reached only by the separately labeled VHelper button in an eligible VH or UV watch dialog and returns an ephemeral bounded child list. The independent `/api/order-agent/variant-lookup/amazon` route is available only to a current opaque UV RFY/AFA Explorer seed; it performs bounded transient UV metadata hydration when required and correlates one signed read-only request with authenticated companion 25.0.4. It cannot arm a watch, create an order job, call VHelper, retry, or merge results into Explorer/live history. `/api/vh/trial-status` is reached only by its trial button and returns no item/device/contribution/payment/identity payload.

## UV RFY & Catalog Explorer pagination and watches

The UV Explorer now requests exactly one bounded page of at most 36 products at a time. **Previous** and **Next** each issue one deliberate signed `ultraviner/search` request with the official string-encoded `pageSize` and `page` fields. The dashboard shows the current page, the returned count, and its computed catalog position range without inventing a total. No loop, prefetch, or automatic multi-page fetch is used. Changing the search text or queue resets to page 1, stale overlapping responses cannot replace a newer query, and Next is offered only when UV returned a complete 36-item page because the endpoint does not provide a trustworthy total count.

**Watch for AFA/AI** is available on UV Explorer cards classified as RFY or AFA; AI Explorer cards do not expose it. The displayed catalog result is only an arming seed: it is never dispatched, cannot satisfy its own watch, and is not merged into the live feed. Eligibility still begins at the durable arming timestamp and requires a separate trustworthy fresh non-backfill AFA/AI live event received afterward. The server constructs any attempt only from that isolated event. Bounded child variants already present in the UV response appear immediately. Two separate buttons may then load more choices explicitly: Amazon through the paired/account-bound PC companion, or VHelper through its signed one-time endpoint. Each click invokes only the named source, with no automatic call, cross-source fallback, retry, ordering action, or Explorer/live-store mutation. All loaded choices clear when the dialog closes.

## UV 26.11.62 compatibility and non-destructive health hotfix

The complete public runtime now advertises `26.11.62` (2,522,827 bytes, SHA-256 `0d6cbbf5f0fc29fd7a90ac5270fa01df1d1ee16a3ad6d7c979c8515ea781ca3d`). The public launcher remains byte-identical `1.0.20` (4,901 bytes, SHA-256 `e62b534636c11d522e068591d1869385ec8b118cbc3b95bf314934ceb899441b`). Both were inspected statically without executing either client or calling an authenticated UV/Amazon endpoint; the separate 26.11.62 audit records the full evidence and no-alert diagnosis.

The Hub now sends the five additive current identification fields: `syncSettings`, `deviceType`, `isNearClaimLimit`, `isClaimLimitReached`, and `supportsEnrollmentGate`. Existing saved token, Amazon hash, device, selected screen, Alert queues, and Chat queues are preserved. Incoming `syncedSettings` is recognized as non-product housekeeping; all existing live-alert names remain unchanged.

Every signed `ultraviner/search` request retains the same eight-field HMAC object and adds `supportsEnrollmentGate: true` only to the JSON body, matching 26.11.62. Search requires the real synchronized Explore queue ID/name and never relabels an Alert queue as Explore. The Explorer tab now shows readiness and blocks signed search when that queue is missing. **Create and sync Explore queue** is an explicit, idempotent action available only when the saved UV pair is complete, screen sync is enabled, the live socket is open and authenticated, a screen is selected, and that screen has queue capacity. It creates a genuine new Explore UUID through the normal profile-mutation and `updateScreen` path; it never borrows an Alert UUID and never runs a search.

A scheduled signed-search HTTP rejection is diagnostic only. It records the HTTP status but cannot clear authentication, block reconnect, destroy an open socket, or label the token expired. Only UV's explicit WebSocket `invalidToken` frame can terminate and block that socket generation. Diagnostics separately show transport, plan/session authentication, whether live-alert delivery has been observed on the current connection, the last non-ping frame, the last LIVE alert, and the independent signed-search result. A quiet authenticated connection is not failed merely because no matching product has arrived.

## Historical UV 26.11.36 WebSocket identification hotfix

The complete then-current public runtime (`26.11.36`, 2,458,733 bytes, SHA-256 `f0a55b1cb698b918552efbdc371231cc23072949cf4941fc495f8cefce269e15`) and userscript launcher (`1.0.20`, 4,901 bytes, SHA-256 `e62b534636c11d522e068591d1869385ec8b118cbc3b95bf314934ceb899441b`) were inspected without executing either client. Their identification object retained the same top-level token and data-field shape audited in 26.9.38. Vine Drop Hub advertised those compatibility versions while preserving the saved token, Amazon hash, device, screen, and queue records.

A UV `connected` frame is only a transport greeting. It no longer clears the authentication timeout, marks the feed healthy, or logs a false authenticated session. A non-empty `plan` or genuine live alert is required. An explicit `invalidToken` is terminal for that socket generation, so an already queued empty plan cannot overwrite the rejection while the close handshake is in progress. The separate signed search probe remains useful REST-path evidence but is not treated as proof that WebSocket identification succeeded. See the compatibility addendum in `ULTRAVINER_26.9.38_STATIC_AUDIT.md`.

## Historical UV 26.9.38 compatibility refresh and dashboard actions

The full 26.9.38 runtime was parsed and compared offline against 26.9.11; see `ULTRAVINER_26.9.38_STATIC_AUDIT.md`. That release added `subscription` housekeeping and optional read-only `ordersInProgress` handling without ordering automation. Release `-11` advanced the live identification versions and authentication-state correctness; releases `-12` and `-13` preserve that now-live compatibility unchanged.

Dashboard action behavior:

- **Clear Items** executes immediately, without a confirmation dialog. It removes cards/activity but retains bounded hidden ASIN tombstones for the configured period, so delayed UV/VH/SV confirmations remain invisible and silent.
- **Reset cleared-item memory** is a separate typed-confirmation action; it permits future rediscoveries but does not restore cleared cards.
- Clicking a **Live Feed** product photo invokes the exact existing **Order on PC** readiness and confirmation flow. It does not silently dispatch or place an order. UV Explorer and VH server/history photos remain read-only **Open Vine** links, and the separate ℹ️ control still opens Product Details.
- **Generate New Synthetic VH Identity** uses one Continue/Cancel warning; no typed phrase is displayed or required by either the dashboard or API.
- **Check Trial Status** performs exactly one user-initiated signed read and displays the server-reported active/inactive state, exact expiry, calculated days remaining, and safely reported tier without saving the response.
- Product card images no longer carry photo-count or variant-count overlays; the primary image and Product Details gallery/variant content are unchanged.

## Category-based priority

Open **Priority Rules** in the dashboard to search and check any of the 90 exact English categories from the preserved UV 26.9.38 taxonomy. The default selection is empty. Saving the checklist persists `priorityCategoryIds` in the private `config.json` and silently recalculates existing cards.

An item is Priority when **any** of these rules matches:

- a configured Highlight keyword;
- the configured price/ETV threshold; or
- its UV-supplied `categoryId` is selected.

Cards and Product Details show the locally resolved category badge and human-readable reasons such as `Category: Electronics`. The first live UV event can therefore trigger the priority chime and first notification immediately when it carries a selected category. If VH is the first live source, its one normal notification is preserved; a later UV live event, `alertDetail`, or `pageData` may add the category and silently promote the existing merged card through `update_item`, with no second browser sound, Telegram alert, or Discord alert.

VHelper's official item model has no category field. VH-only items remain category-unknown: the application does not infer from titles and does not query Amazon or UV for missing categories. Category labels/icons are resolved locally by exact ID.

Category endpoints:

- `GET /api/categories` — catalog plus saved selections;
- `POST /api/categories/priority` with `{ "categoryIds": ["9", "30"] }` — validate, persist, and silently recheck cards.

## R25 AFA/AI watches and order safety

The VH RFY Server Explorer and UV Explorer RFY/AFA cards offer **Watch for AFA/AI**. Each displayed search record stays a browser-only arming seed and can never dispatch or satisfy its own watch. A watch defaults to 30 days (editable 1–30), targets only a separate later fresh non-backfill AFA/AI event received after the durable arming boundary, and constructs the signed item solely from an allowlist of that event. The arming dialog offers **Any currently available variant** plus valid embedded children. It has separately labeled Amazon-via-PC and VHelper controls for UV RFY/AFA seeds; VH server seeds retain their explicit VHelper control. Opening the dialog does not run either source. Each click runs only one bounded signed read, with no fallback or retry. Sanitized loaded choices live only in that dialog and never enter a live card, Explorer history, or manual **Order on PC**. Exact selection stores only the chosen child ASIN and label; companion 25.0.4 verifies the child against Amazon's fresh current variation response and Request Product acceptance. If it disappeared, the watch records **Missed — selected variant unavailable**, no substitute is tried, checkout is not opened, and nothing is queued or retried. Existing watches retain first-available behavior. Armed watches reserve their parent ASIN and can be cancelled; triggered, missed, expired, and cancelled state remains visible.

Settings adds a unified readiness panel, a configuration-preserving emergency pause, and a durable circuit breaker for ambiguous/account/final-total/currency/click-boundary or persistence uncertainty. Order intent is saved before socket dispatch, signed results are acknowledged only after their ledger transition is durable, and unsafe unacknowledged boundaries are recovered after restart. The circuit blocks all jobs until the user checks the ledger and Amazon Orders and types the acknowledgement phrase. Optional rolling-24-hour automatic placement-count and cumulative-final-total controls are present but disabled initially; reaching one changes the next automatic job to exact-total PC approval, and remaining charge allowance can only tighten its cap.

The rule editor adds a prominent dirty indicator, unload warning, duplication, exact phrase/whole-word modes, non-dispatching recent-live-item preview, and detailed match explanations. Credential-free JSON export/import carries rules and armed watches but no pairing, account, job, safety, feed, notification, or VPN secret. Imported broad rules are disabled for review; imported unexpired watches remain armed unless emergency pause is active.

A first live event is evaluated immediately. If it did not match the currently saved broad rules, the first later independent UV↔VH counterpart confirmation may create one automatic attempt when the newly merged card becomes a match and no prior automatic attempt exists. The confirmation must be fresh, non-backfill, explicit/derived, visible, and add UV to a VH live card or VH to a UV live card; SmartViner alone is not the counterpart. UV/VH `unavailable` flags are advisory for automatic rules and watches because either feed can be wrong; the paired browser and Amazon remain authoritative. Armed-watch reservation, ASIN attempt dedupe, pause/circuit/readiness, active-job, rolling-limit, signed-protocol, and final-total gates still apply. Matching may use the merged card, but the signed job's queue, enrollment, and source come only from the current confirming event. The same card is updated silently: no second card, sound, Telegram message, or Discord message. Card text describes current match state only; a **Recent PC jobs** row is the dispatch receipt.

When an isolated fresh UV/VH event has no usable retail price/ETV, the Hub may retain one memory-only completion permit for 60 seconds. UV `alertDetail`/`pageData` money or VH `newPrice`/`newETV` money may fill only the event's missing price fields. Rule configuration, title, brand, queue, source, enrollment, agent session, account binding, and safety readiness stay pinned to the original event-time boundary. A matching update consumes the permit before one durable attempt; expiry, restart, disconnect, rule/safety/watch changes, history/backfill, manual hiding, or any prior automatic attempt prevents dispatch. Distinct missing retail/ETV fields may arrive separately inside the window, but there is never a second attempt, reconnect queue, persistence, or replay.

## R25 delivery scope

This narrow hotfix accepts only the exact authenticated `r25-uv-26-11-62-compatibility-health-hotfix-20260910-16` managed release. It validates offline before downtime, takes a complete reversible backup, replaces managed source only, and preserves every private runtime path. The change is confined to audited VHelper 4.7.4/build-3637 pins and diagnostics, guarded Explorer-queue setup/readiness, stable Open Vine activation, Live Feed photo-to-confirmation behavior, collapsed rules/watch panels, documentation, release policy, and focused tests. Existing live ingestion, signed field order, automatic-order and delayed-money policy, OpenVPN/WireGuard, UV WebSocket authentication, exact-watch revalidation, pairing/account binding, signed dispatch, circuit breaker, and final-checkout safety remain unchanged. Companion **25.0.4 is unchanged**; an existing 25.0.4 installation does not need replacement, reload, re-pairing, or Amazon reauthentication. See `R25_IN_PLACE_UPDATE_NOTES.md`.

For a clean Ubuntu VPS, use the authenticated `r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18` fresh installer described in `MIGRATE_TO_NEW_UBUNTU.md`, not an older in-place updater. To keep fresh cards/history/order state while preserving the working synthetic VHelper identity, privately transfer only `config.json`, the complete active `data/identity.json` (including its signing key), and one `.ovpn` or `.conf` profile before finalization. Do not reconstruct or rotate the identity, and do not transfer the rest of `data/`.

The dashboard remains on `127.0.0.1:3001`. **Settings → VPN Profile Manager** validates and switches a self-contained OpenVPN `.ovpn`, standard WireGuard `.conf`, or manual WireGuard fields transactionally. A change recreates and health-checks `vpn`, the VPN-bound `sv-proxy`, and `app`; dual-stack WireGuard additionally proves IPv4 and configured IPv6 HTTPS egress. The Node container never receives the Docker socket. UV and SV follow the app-only VPN, while VH retains only its destination-locked direct route. The Windows companion uses a second local SSH forward to that same loopback listener and never requires a public dashboard port.

No populated `config.json`, `data/` file, cleared-item/order ledger, order pairing/rules, SmartViner session, UV/VH identity, notification credential, VPN profile/private key, control state, or backup is embedded in either payload.

## Requirements

- Node.js 20 recommended
- npm

Check versions:

```bash
node -v
npm -v
```

## Install

```bash
cd ~/vine
npm ci
```

Or, if `npm ci` reports a lock-file problem:

```bash
npm install
```

## Configuration

A working installation keeps UV and VH mode settings in private `config.json`. SmartViner enablement is persisted separately through its dedicated route; its rotating session is never placed in this generic configuration surface. In a sanitized package the values are blank/safe and must be configured locally:

```json
"enableUV": true,
"enableVH": true,
"enableSV": false,
"vhLoadHistory": false,
"priorityCategoryIds": [],
"clearedItemSuppressionHours": 24
```

On either the guarded in-place release or this clean-server release, use the SSH-tunneled dashboard's **Settings → SmartViner Live Source** section to sign in, then enable SV. Do not paste the SmartViner password or any printed token into chat, shell history, documentation, or `config.json`. See `SMARTVINER_LIVE_SOURCE.md`.

`vhLoadHistory` is retained only as a compatibility field and is forced to `false`. Package B never emits a VH `getLast100` request and ignores any unsolicited history batch. The R20 Item Explorer, R21 click-only trial-status read, and R25 Watch-dialog-click-only variants read are separate explicit signed operations; none changes live-stream history recovery or this configuration field.

Protect it:

```bash
chmod 600 config.json
```

Keep the bearer token only in the private working `config.json`. Do not place it in documentation, deployment patches, chat, or generic archives.

The account-specific UV inputs are a mandatory matched pair:

- the **new account's** `token`;
- the **new account's** Amazon Vine `customerId` or its 64-character SHA-256 hash (`azUser`).

The application stores `azUser` only as a SHA-256 hash. It rejects same-account token-only renewal and rejects a new-account submission that reuses either saved credential. `domain` remains a normal marketplace setting.

The application generates and persists `device`, `selectedScreenId`, Alert queue IDs, Chat queue IDs, Explore queue ID, and the rest of the UV-compatible screen layout in `data/uv_profile.json`. The old identity keys remain mirrored into `config.json` only for backwards-compatible tooling. Submitting a valid new account pair replaces the local UV profile with a fresh bootstrap layout; existing remote screens for the new account are restored before that placeholder can overwrite them.

Static inspection of UV 26.9.38 confirms that the opaque UV token contains only its Ultraviner account key; the official client obtains `customerId` separately from an authenticated Amazon/Vine page and sends its SHA-256 hash. Vine Drop Hub therefore requires both new values together rather than inventing, retaining, or falsely deriving the Amazon identity. The dashboard provides a local-only extraction snippet that reads `customerId` in the new account's Amazon tab and returns only its SHA-256 hash, without requesting cookies or an Amazon password.

### Independent feed-health alerts

The server monitors UV, VH, and SV independently and persists incident state in
`data/feed_health.json`:

- UV `invalidToken` frames trigger an immediate problem alert and block automatic reconnect until the credential is replaced or validates again.
- The configured UV token is also checked through the 26.11.62 signed-search shape approximately every six hours when a canonical Explore queue exists. Its last-check time is persisted, so container restarts do not create extra startup probes. A rejection is recorded as independent REST evidence but cannot terminate, unauthenticate, or reconnect-block the live WebSocket.
- VH transport health and supplemental application evidence are separate. A healthy transport is the official-client connection criterion; missing application activity or an optional sync pong is diagnostic and does not force a disconnect. Identity/setup failures, denial events, Socket.IO recovery, Engine.IO silence, returned broadcast-marker mismatches, real disconnects, and reconnections remain monitored.
- VH reuses the same Socket.IO object when identity fields are unchanged, checks `socket.recovered`, supervises every 10 seconds, detects two-minute engine silence, refreshes at three hours, and suppresses the expected `io client disconnect` incident during planned recovery.
- SV is healthy only after its pinned socket is open and its authenticated private marketplace channel is subscribed. Socket heartbeat and alert-channel silence are supervised independently; one same-socket re-subscription is attempted before reconnect. No reconnect path requests missed products.
- Ordinary connection losses use a two-minute grace period by default. A detected history-free gap after the recovery window is actionable immediately. Each continuing incident generates at most one Telegram problem message and one recovery message.
- An unhealthy source displays a persistent dashboard banner without marking the other source unhealthy.

Defaults can be changed in Settings or `config.json`:

```json
"enableFeedHealthAlerts": true,
"uvTokenCheckIntervalMs": 21600000,
"feedOutageGraceMs": 120000
```

`enableFeedHealthAlerts` controls Telegram health/recovery messages; dashboard health state remains visible. Telegram itself must also be enabled and configured. Inspect health without exposing credentials:

```bash
curl -sS http://127.0.0.1:3001/api/health | python3 -m json.tool
```

### Multiple screens and custom queues

The **Screens & Queues** page implements UV 26.9.38's relevant layout and WebSocket behavior:

- create, select, rename, reorder, clone, and delete screens;
- create, rename, reorder, clone, convert, and delete queues;
- generate UUIDv4 identifiers locally, as the official browser client does;
- send every Alert queue as `{id, name}` and every Chat queue as `{id, selectedChatChannel}` during identification;
- filter the local live feed by a selected custom Alert queue when UV supplies `data.queueId`;
- import `screens` and `queues` from an official `.uv` export without importing its account token;
- synchronize screen summaries and payloads using `screens`, `requestScreen`, `screen`, `updateScreen`, and `deleteScreen` frames.

On a fresh local profile, the generated bootstrap screen is replaced by the first remotely restored screen when synced screens exist. Layout state is in `data/uv_profile.json` and is covered by the existing persistent `./data:/app/data` Docker mount.

## Start in hard UV-only mode

On Ubuntu/Linux:

```bash
UV_ONLY=1 NODE_OPTIONS=--dns-result-order=ipv4first node server.js
```

Or with npm:

```bash
NODE_OPTIONS=--dns-result-order=ipv4first npm run start:uv-only
```

Hard UV-only mode prevents VH from being enabled by the UI or API for that process.

Normal mode, while still respecting `"enableVH": false` in config:

```bash
NODE_OPTIONS=--dns-result-order=ipv4first npm start
```

Routine per-frame and per-item success logs are disabled by default so Docker
stdout is not part of the live delivery hot path. Errors, denials, disconnects,
and health events remain logged. Temporarily enable verbose item logging only
for diagnosis:

```bash
VINE_VERBOSE_LIVE_LOGS=1 NODE_OPTIONS=--dns-result-order=ipv4first npm start
```

Stop with `Ctrl+C`.

## Open the dashboard

Locally:

```text
http://127.0.0.1:3001
```

For a remote VPS, do not expose port 3001 publicly: the dashboard APIs do not currently require authentication and the settings endpoint contains credentials. Use an SSH tunnel from your computer:

```bash
ssh -L 3001:127.0.0.1:3001 ubuntu@YOUR_SERVER_IP
```

Then open:

```text
http://127.0.0.1:3001
```

## Clean passive UV test

1. Open **Settings**.
2. Confirm **Enable Ultraviner (UV)** is selected.
3. Confirm **Enable VHelper (VH)** is not selected.
4. Click **Prepare Clean UV-Only Test**. This stops VH and clears old VH/history records that could otherwise make a real UV alert look like a merge.
5. Do **not** click **Catalog Backfill** during the passive test.
6. Watch **UV Diagnostics** and the terminal.

Expected authentication sequence:

```text
[UV WS] Socket open; waiting before identification.
[UV FRAME] type=connected products=0
[UV WS] Transport greeting received; awaiting identification result.
[UV WS] initial identification queued (... bytes, N alert queue(s), N chat queue(s)).
[UV WS] Identification identity: ...
[UV FRAME] type=plan products=0
[UV WS] Plan: ultimate
```

The transport greeting may arrive just before or just after the delayed identification write. It is not authentication proof. The plan value must be non-empty; a real live-alert frame is also sufficient evidence.

Expected real alert sequence:

```text
[UV FRAME] type=alerts products=1
[UV LIVE] alerts: 1 item(s)
[New Drop] [UV] [AI] ...
```

Possible enrichment afterward:

```text
[UV FRAME] type=alertDetail products=1
[UV DETAIL] Enriched existing item: ...
```

## Runtime controls

Disable VH immediately:

```bash
curl -X POST http://127.0.0.1:3001/api/vh/disable
```

Check VH state:

```bash
curl http://127.0.0.1:3001/api/vh/status
```

View redacted VH identity, application-ready, recovery, watchdog, sync, and route diagnostics:

```bash
curl http://127.0.0.1:3001/api/vh/diagnostics
```

View redacted SmartViner state (no tokens or password):

```bash
curl -sS http://127.0.0.1:3001/api/sv/status | python3 -m json.tool
```

Perform SmartViner sign-in only through the SSH-tunneled dashboard, not a shell command, so the password does not enter shell history. The dashboard also provides enable/disable, reconnect, and typed-confirmation session removal.

Force a UV reconnect after correcting configuration:

```bash
curl -X POST http://127.0.0.1:3001/api/uv/reconnect
```

View UV diagnostics:

```bash
curl http://127.0.0.1:3001/api/uv/diagnostics
```

Optionally validate the configured token through the UV search API without printing it. Only do this from the installation's intended UV egress; do not copy the credential to another host or test it from an unrelated IP:

```bash
curl -sS \
  -X POST \
  -H 'Content-Type: application/json' \
  -d '{}' \
  http://127.0.0.1:3001/api/uv/test-token
```

Clear all stored items/activity before testing:

```bash
curl -X POST http://127.0.0.1:3001/api/clear-all
```

## Optional app-only OpenVPN or WireGuard route

The included dual-stack Docker deployment routes only Vine Drop Hub and the destination-locked SmartViner proxy through the permitted custom OpenVPN or WireGuard profile; it does not change the VPS default route. VH alone retains its destination-locked direct-egress exception. The dashboard is published only on loopback. See `VPN_SETUP.md`, `DASHBOARD_VPN_UPLOAD.md`, `GLUETUN_V3_41_1_WIREGUARD_AUDIT.md`, and `SMARTVINER_LIVE_SOURCE.md`.

## VPS authentication timeout

If a working profile gets a WebSocket `101` but no `connected` or `plan` response on a new host:

1. Confirm Node 20 and `ws` 8.18.3:

   ```bash
   node -v
   npm ls ws
   ```

2. Force IPv4 using the start command above.
3. Test the token with `/api/uv/test-token` only from the installation's intended UV route.
4. If a stale local device identity is suspected, use **Screens & Queues → Fresh local identity**. The application generates the device, screen, Alert, Chat, and other queue UUIDs together and reconnects; do not hand-edit individual IDs.
5. If the token test works but WebSocket identification still times out, run the package on the same computer/network where the official extension works. A successful local connection would isolate the VPS/data-centre network or IP as the difference.

After an authentication timeout, automatic reconnect is intentionally blocked to avoid hammering the service. Use **Reconnect UV** or `/api/uv/reconnect` after making a correction.
