#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

SOURCE_PROFILE="${1:-vpn/client.ovpn}"
OUTPUT_PROFILE="${2:-vpn/client.gluetun.ovpn}"

if [[ ! -f "$SOURCE_PROFILE" ]]; then
  echo "ERROR: OpenVPN profile not found: $SOURCE_PROFILE" >&2
  exit 1
fi

if [[ "$SOURCE_PROFILE" == "$OUTPUT_PROFILE" ]]; then
  echo "ERROR: Input and output paths must be different." >&2
  exit 1
fi

mkdir -p "$(dirname "$OUTPUT_PROFILE")"
TEMP_FILE="$(mktemp "$(dirname "$OUTPUT_PROFILE")/.client.gluetun.XXXXXX")"
trap 'rm -f "$TEMP_FILE"' EXIT

# Gluetun's firewall intentionally prevents pre-tunnel DNS leaks. Resolve every
# OpenVPN remote hostname on the host before the profile enters the VPN
# namespace. Inline certificate/key blocks are copied byte-for-byte and never
# printed.
python3 - "$SOURCE_PROFILE" "$TEMP_FILE" <<'PY'
from __future__ import annotations

import ipaddress
from pathlib import Path
import re
import socket
import sys

source = Path(sys.argv[1])
output = Path(sys.argv[2])
text = source.read_text(encoding="utf-8-sig")
lines = text.replace("\r\n", "\n").replace("\r", "\n").splitlines()
remote_re = re.compile(r"^(?P<indent>\s*)(?P<name>remote)(?P<space>\s+)(?P<host>[^\s#;]+)(?P<rest>.*)$", re.IGNORECASE)
resolved = {}
inline_tag = None
result = []

for number, line in enumerate(lines, 1):
    stripped = line.strip()
    opening = re.fullmatch(r"<([A-Za-z0-9_-]+)>", stripped)
    closing = re.fullmatch(r"</([A-Za-z0-9_-]+)>", stripped)
    if inline_tag:
        result.append(line)
        if closing and closing.group(1).lower() == inline_tag:
            inline_tag = None
        continue
    if opening:
        inline_tag = opening.group(1).lower()
        result.append(line)
        continue
    if not stripped or stripped.startswith("#") or stripped.startswith(";"):
        result.append(line)
        continue

    match = remote_re.match(line)
    if not match:
        result.append(line)
        continue

    host = match.group("host").strip('"\'')
    try:
        address = ipaddress.ip_address(host)
        if address.version != 4:
            raise ValueError("IPv6 is not supported by this deployment")
        remote_ip = str(address)
    except ValueError:
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", host) or ".." in host:
            raise SystemExit(f"ERROR: invalid remote hostname on line {number}")
        try:
            answers = socket.getaddrinfo(host, None, socket.AF_INET, socket.SOCK_STREAM)
        except socket.gaierror as error:
            raise SystemExit(f"ERROR: could not resolve IPv4 for remote host {host}: {error}")
        remote_ip = answers[0][4][0]
    resolved.setdefault(host, remote_ip)
    result.append(
        f"{match.group('indent')}{match.group('name')}{match.group('space')}"
        f"{remote_ip}{match.group('rest')}"
    )

if not resolved:
    raise SystemExit("ERROR: no usable remote directive found")

output.write_text("\n".join(result) + "\n", encoding="utf-8")
for host, remote_ip in resolved.items():
    print(f"VPN endpoint prepared: {host} -> {remote_ip}")
PY

install -m 600 "$TEMP_FILE" "$OUTPUT_PROFILE"

echo "Prepared $OUTPUT_PROFILE"
echo "The original profile was not modified."
