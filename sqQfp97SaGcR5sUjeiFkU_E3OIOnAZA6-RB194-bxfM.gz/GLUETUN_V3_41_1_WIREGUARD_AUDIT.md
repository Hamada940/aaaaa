# Pinned Gluetun v3.41.1 WireGuard audit

Release: `qmcgaw/gluetun:v3.41.1`  
Source tag commit: `7f22fb32764d5d7548bc669cde88c57fc1a0de83`

This release was inspected directly at its pinned source tag before the Vine
WireGuard implementation was designed.

## Confirmed behavior

- `VPN_TYPE=wireguard` and `VPN_SERVICE_PROVIDER=custom` are supported.
- `WIREGUARD_CONF_SECRETFILE` defaults to `/run/secrets/wg0.conf` and is parsed
  before ordinary files and environment values.
- The secret config parser reads:
  - `[Interface] PrivateKey`
  - `[Interface] Address`
  - `[Peer] PresharedKey`
  - `[Peer] PublicKey`
  - `[Peer] Endpoint`
- Remaining settings are supported through environment values, including
  `WIREGUARD_ALLOWED_IPS`, `WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL`,
  `WIREGUARD_MTU`, and `WIREGUARD_IMPLEMENTATION`.
- `WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL` is parsed as a Go duration, not a
  bare integer count. The manager therefore renders canonical integer seconds
  with an explicit `s` suffix (`25s`, including canonical zero as `0s`). It
  accepts legacy bare `0` only for rollback/upgrade compatibility and rejects
  every non-zero unitless runtime value before Compose activation.
- WireGuard addresses and AllowedIPs use `net/netip`; IPv6 interface addresses
  are accepted only when the container has IPv6 support.
- Default AllowedIPs include both `0.0.0.0/0` and `::/0`; WireGuard ignores the
  IPv6 route when IPv6 is unavailable.
- Gluetun sets IPv4 and IPv6 firewall policies to DROP, permits only the VPN
  endpoint, local container networks, configured outbound subnets, loopback,
  established traffic, and required IPv6 NDP multicast output.
- The image contains Node-independent health logic and a Docker healthcheck;
  Vine additionally probes from its Node app sharing the VPN namespace.

## Pinned parser limitation and mitigation

The v3.41.1 INI parser splits `[Peer] Endpoint` with a plain colon split. It is
therefore not safe to rely on that parser for bracketed IPv6 endpoints, and the
upstream custom-provider documentation also requires an endpoint IP rather
than a hostname.

Vine does **not** give Gluetun the endpoint through the private INI file:

1. Node and Python independently validate `host:port` or `[IPv6]:port`.
2. The privileged host manager resolves a hostname before container creation.
3. The private `/run/secrets/wg0.conf` contains only private key, optional
   pre-shared key, and interface addresses.
4. A root-only mode-0600 `active.env` supplies the literal endpoint IP/port,
   server public key, full AllowedIPs, keepalive, and MTU.

This also prevents private key values from entering Compose environment text.

## Dual-stack controls

- Compose enables IPv6 and assigns a private ULA subnet in addition to the
  existing IPv4 bridge.
- `net.ipv6.conf.all.disable_ipv6=0` is set only on Gluetun's namespace.
- The direct VHelper exception is confined to the explicit IPv4 and IPv6 local
  bridge subnets; ordinary app traffic remains behind Gluetun's kill switch.
- WireGuard profiles with an IPv6 interface address are committed only after
  both IPv4 and IPv6 HTTPS egress succeed from `vine-drop-hub`.
- IPv4-only profiles are permitted for providers without tunnel IPv6, but
  their canonical AllowedIPs still include `::/0` so unsupported IPv6 cannot
  be intentionally routed directly.

## Upstream references

- Pinned Dockerfile and environment defaults:
  `https://github.com/qdm12/gluetun/blob/v3.41.1/Dockerfile`
- Pinned WireGuard file parser:
  `https://github.com/qdm12/gluetun/blob/v3.41.1/internal/configuration/sources/files/wireguard.go`
- Pinned secret source:
  `https://github.com/qdm12/gluetun/blob/v3.41.1/internal/configuration/sources/secrets/wireguard.go`
- Pinned WireGuard validation:
  `https://github.com/qdm12/gluetun/blob/v3.41.1/internal/configuration/settings/wireguard.go`
- Official custom provider setup:
  `https://github.com/qdm12/gluetun-wiki/blob/main/setup/providers/custom.md`
- Official IPv6 setup:
  `https://github.com/qdm12/gluetun-wiki/blob/main/setup/advanced/ipv6.md`
