import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import vm from 'node:vm';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const failures = [];

function relative(file) {
  return path.relative(root, file).split(path.sep).join('/');
}

function walk(directory) {
  if (!fs.existsSync(directory)) return [];
  const output = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (['node_modules', '__pycache__', '.git'].includes(entry.name)) continue;
    const value = path.join(directory, entry.name);
    if (entry.isDirectory()) output.push(...walk(value));
    else if (entry.isFile()) output.push(value);
  }
  return output;
}

function run(command, args, label) {
  const result = spawnSync(command, args, { cwd: root, encoding: 'utf8' });
  if (result.status !== 0) {
    failures.push(`${label}\n${result.stdout || ''}${result.stderr || ''}`.trim());
  }
}

const javascript = [
  path.join(root, 'server.js'),
  path.join(root, 'sv-connect-proxy.js'),
  path.join(root, 'vh-direct-proxy.js'),
  ...walk(path.join(root, 'lib')),
  ...walk(path.join(root, 'companion')),
  ...walk(path.join(root, 'scripts')),
  ...walk(path.join(root, 'test'))
].filter(file => /\.(?:js|mjs|cjs)$/.test(file));

for (const file of [...new Set(javascript)].sort()) {
  run(process.execPath, ['--check', file], `JavaScript syntax failed: ${relative(file)}`);
}

try {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'companion', 'manifest.json'), 'utf8'));
  if (manifest.manifest_version !== 3) throw new Error('manifest_version must be 3');
} catch (error) {
  failures.push(`Companion manifest parse failed: ${error.message}`);
}

try {
  const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
  const pattern = /<script(?:\s[^>]*)?>([\s\S]*?)<\/script\s*>/gi;
  let match;
  let count = 0;
  while ((match = pattern.exec(html))) {
    count += 1;
    new vm.Script(match[1], { filename: `public/index.html:inline-script-${count}` });
  }
  if (!count) throw new Error('no inline dashboard script found');
} catch (error) {
  failures.push(`Dashboard script syntax failed: ${error.stack || error.message}`);
}

for (const file of walk(root).filter(file => file.endsWith('.sh')).sort()) {
  run('bash', ['-n', file], `Shell syntax failed: ${relative(file)}`);
}

for (const file of walk(path.join(root, 'host')).filter(file => file.endsWith('.py')).sort()) {
  run('python3', ['-c', `compile(open(${JSON.stringify(file)}, encoding='utf-8').read(), ${JSON.stringify(file)}, 'exec')`], `Python syntax failed: ${relative(file)}`);
}

if (failures.length) {
  console.error(failures.join('\n\n'));
  process.exit(1);
}
console.log(`Offline syntax checks passed (${javascript.length} JavaScript modules, dashboard, manifest, shell, Python).`);
