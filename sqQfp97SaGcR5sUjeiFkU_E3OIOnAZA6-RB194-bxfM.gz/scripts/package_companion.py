#!/usr/bin/env python3
"""Build or verify the deterministic public PC companion ZIP without network access."""

from __future__ import annotations

import argparse
import hashlib
import io
import pathlib
import stat
import sys
import zipfile
import zlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT / "companion"
OUTPUT = ROOT / "public" / "downloads" / "vine-drop-hub-pc-companion.zip"
CHECKSUM = OUTPUT.with_suffix(OUTPUT.suffix + ".sha256")
FIXED_TIME = (2026, 9, 10, 13, 0, 0)


def source_files() -> list[pathlib.Path]:
    values: list[pathlib.Path] = []
    for path in SOURCE.rglob("*"):
        if path.is_symlink():
            raise SystemExit(f"ERROR: companion package cannot contain a symlink: {path}")
        if not path.is_file():
            continue
        relative = path.relative_to(SOURCE)
        if any(part in {"__pycache__", ".git"} for part in relative.parts):
            continue
        if path.name.endswith((".zip", ".crx", ".pem", ".key", ".p12", ".pfx", ".ovpn")):
            raise SystemExit(f"ERROR: prohibited companion package file: {relative}")
        values.append(path)
    values.sort(key=lambda value: value.relative_to(SOURCE).as_posix())
    if not values or SOURCE / "manifest.json" not in values:
        raise SystemExit("ERROR: companion manifest is missing")
    return values


def build_bytes() -> bytes:
    stream = io.BytesIO()
    # Store entries without DEFLATE so the exact ZIP bytes are reproducible
    # across Ubuntu 22.04/24.04 Python and zlib versions.
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_STORED) as archive:
        for path in source_files():
            relative = path.relative_to(SOURCE).as_posix()
            info = zipfile.ZipInfo(relative, FIXED_TIME)
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            mode = 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_STORED)
    return stream.getvalue()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="fail unless the committed ZIP and checksum are current")
    args = parser.parse_args()

    payload = build_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    checksum_text = f"{digest}  {OUTPUT.name}\n"
    if args.check:
        if not OUTPUT.is_file() or OUTPUT.read_bytes() != payload:
            print(f"ERROR: companion ZIP is missing or stale: {OUTPUT}", file=sys.stderr)
            return 1
        if not CHECKSUM.is_file() or CHECKSUM.read_text(encoding="utf-8") != checksum_text:
            print(f"ERROR: companion ZIP checksum file is missing or stale: {CHECKSUM}", file=sys.stderr)
            return 1
        with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
            required = [path.relative_to(SOURCE).as_posix() for path in source_files()]
            if archive.namelist() != required or archive.testzip() is not None:
                print("ERROR: companion ZIP inventory or CRC validation failed", file=sys.stderr)
                return 1
            for info in archive.infolist():
                data = archive.read(info.filename)
                if (
                    info.compress_type != zipfile.ZIP_STORED
                    or info.file_size != len(data)
                    or info.compress_size != len(data)
                    or info.CRC != (zlib.crc32(data) & 0xFFFFFFFF)
                ):
                    print(f"ERROR: companion ZIP entry is invalid: {info.filename}", file=sys.stderr)
                    return 1
        print(f"Companion package is current: {digest}")
        return 0

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_bytes(payload)
    CHECKSUM.write_text(checksum_text, encoding="utf-8")
    print(f"Wrote {OUTPUT.relative_to(ROOT)} ({len(payload)} bytes, sha256 {digest})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
