# SmartViner live source (R24)

## Purpose and boundary

R24 adds SmartViner (`SV`) as a third continuously running **live-item alert source** in Vine Drop Hub. The connector runs in the VPS application stack, so it remains active while the personal browser is closed.

This is a clean-room connector built from the statically reviewed SmartViner 0.9.42 protocol surface. The proprietary CRX is not copied, modified, embedded, or repackaged. The connector intentionally excludes:

- catalogue, feed-history, and reconnect-gap catch-up reads;
- reviews, chat, AI Shopper, ordering, checkout, and Amazon account/page scraping;
- SmartViner telemetry, webhooks, full UI, device administration, and unrelated account data.

Only these authenticated production operations are reachable from the connector:

- `POST https://smartviner.com/api/v1/auth/login`;
- `POST https://smartviner.com/api/v1/auth/refresh`;
- `GET https://smartviner.com/api/v1/me`;
- `POST https://smartviner.com/broadcasting/auth`;
- the pinned Pusher/Reverb protocol-7 WebSocket at `smartviner.com:443`.

The private channel is `private-alerts.marketplace.<marketplace_id>`. Only global `NewGlobalItemDiscovered` products and the non-item `AlertsHeartbeat` are processed. Every `RfyItemDiscovered` frame is classified as blocked from its outer transport envelope; its inner product payload is not parsed or retained, and it cannot enter storage, cards, activity, or notifications. RFY-shaped global events are also rejected.

Because SmartViner multiplexes event types on the same reviewed marketplace channel, the server can still transmit an RFY frame to the socket. The Hub cannot prevent those bytes from arriving without an officially documented separate global-only channel; it guarantees local discard rather than zero network receipt.

## One-card and first-alert behavior

UV, VH, and SV use one ASIN-keyed source registry:

1. The first genuine live event creates or promotes the card and starts the one browser/Telegram/Discord alert.
2. A later source for the same ASIN updates that card silently.
3. Each source's first receipt timestamp and queue observation are retained.
4. Product Details shows all source arrivals and offsets from the first source.
5. `leadMs` remains the first-to-second arrival gap for compatibility; `sourceArrivalOrder` and `sourceLeadMs` retain all three-source timing.

Historical/backfill and detail-only observations cannot claim a live source or trigger a first alert. There is no batching, debounce, animation-frame scheduling, or intentional delivery delay.

## Credential isolation

Never send the SmartViner password, access token, refresh token, or channel signature through chat.

Onboarding is available only in **Settings → SmartViner Live Source** on the dashboard, which must be reached through the existing SSH tunnel. The password:

- is read from the local password input;
- is used for one login request through the dedicated VPN egress;
- is cleared from the browser input and server request object;
- is never stored in `config.json`, `data/`, logs, activity, status, or browser storage.

After successful account verification, only rotating session material and bounded account metadata are saved in private `data/sv_auth.json` with mode 0600. The browser receives status booleans, expiries, account ID, marketplace ID, a bounded display name, and a masked email hint; it never receives bearer/refresh tokens.

SmartViner state is separate from:

- the UV token and Amazon Vine identity;
- the retained VH UUID/CID/FID and signing key;
- Telegram/Discord credentials;
- item/history/private application data;
- OpenVPN `.ovpn`, WireGuard `.conf`/private-key material, and VPN-control state.

Generic `POST /api/config` rejects SmartViner fields. Replacing or removing SV state cannot erase or rotate any other credential domain.

## Dedicated application-only VPN egress

The whole VPS is not routed through the selected OpenVPN or WireGuard profile. The application and SV proxy share Gluetun's network namespace; other VPS services retain their normal route.

SV has a separate CONNECT process on VPN-loopback `127.0.0.1:8889`:

- it binds only to loopback inside the shared namespace;
- it accepts only CONNECT;
- it allows exactly `smartviner.com:443`;
- it hardcodes the upstream destination rather than trusting the request authority;
- it never uses VHelper's direct-egress proxy at `172.30.77.2:8888`;
- it has no host port.

The application requires `SV_HTTPS_PROXY=http://127.0.0.1:8889`. If the agent is absent, SV fails closed as `egress_unavailable`; it does not fall back to the application or VPS default route.

For the low-resource in-place update, the SV proxy process reuses the already-installed `vine-drop-hub:local` Node image with a read-only mounted entrypoint. The service remains read-only, unprivileged, capability-free, and independently health-checked. No image pull or build is needed.

## Local onboarding after the update

1. Keep the dashboard private. On the local computer, open the existing SSH tunnel:

   ```bash
   ssh -L 3001:127.0.0.1:3001 ubuntu@YOUR_SERVER_IP
   ```

2. Open `http://127.0.0.1:3001` in that computer's browser.
3. Open **Settings → SmartViner Live Source**.
4. Confirm **Dedicated VPN egress** reports ready. If it does not, do not enter credentials; inspect the local Compose status first.
5. Enter the SmartViner account email and password in the dedicated fields and choose **Sign In / Replace SV Account**.
6. Confirm the dashboard reports the expected masked account and marketplace. Do not copy any locally printed secret into chat.
7. Choose **Enable SV**. Healthy state is **Live**, with the private channel shown as subscribed.
8. Leave the browser closed if desired; the VPS client continues running.

A replacement login is verified completely before it replaces a working session. If session persistence fails, the prior session is restored. Concurrent/late refresh and account responses cannot clear or repopulate a replacement/disconnected account.

## Controls and safe diagnostics

The dedicated section provides:

- **Refresh SV Status** — local status only;
- **Enable/Disable SV** — persists only SV enablement;
- **Reconnect SV** — reconnects and reauthorizes the live channel, with no catch-up request;
- **Disconnect SV Account** — requires the exact typed phrase `DISCONNECT SMARTVINER` and removes only the isolated SV session.

A redacted local status can also be viewed through the tunnel:

```bash
curl -sS http://127.0.0.1:3001/api/sv/status | python3 -m json.tool
```

Safe fields include state, connection/channel booleans, allowed events, expiries, bounded account metadata, and last live/heartbeat/error times. `passwordStored` is always false. Do not run a command that places the password in shell history.

## Reconnect behavior

The first reconnect is immediate, then bounded exponential delays use the reviewed 0/0.5/1/2/4/8/10-second schedule with jitter. A 20-second Pusher ping and 90-second socket-staleness watchdog detect half-open transport. Once an alert heartbeat has been seen, channel silence triggers one same-socket unsubscribe/reauthorize/resubscribe; if it remains unavailable, the socket is replaced.

Reconnect never calls `/feed/discoveries`, never sends a `since` value or cursor, and never replays catalogue/history. A real item emitted while the client is disconnected can therefore be missed. That is the explicitly selected live-only trade-off; catch-up remains disabled unless separately approved.

## User-run verification (intended VPS egress only)

The release was validated offline and no assistant-side SmartViner, UV, VH, Telegram, Amazon, token, feed, or VPS endpoint was contacted.

After local onboarding, the user may verify from the intended VPS egress:

1. The top SV pill and dedicated status show **Live** / **subscribed**.
2. Closing the dashboard does not stop the SV container/client.
3. A genuine SV live event creates an SV card only if no UV/VH live source already created it.
4. A later matching UV/VH/SV event adds its source badge/timing without a second sound or outbound notification.
5. RFY appears only for the authenticated account event.
6. `data/sv_auth.json` remains private and no password is present in `config.json`, `data/`, or logs.
7. No history/catch-up request is expected after reconnect.

Use only non-secret status/error output when requesting help. Never paste the account password, bearer/refresh values, `.ovpn`/`.conf` contents, VPN credentials, or private keys.
