# Dashboard OpenVPN and WireGuard switching

## Architecture

The Node application remains unprivileged and does **not** receive the Docker
socket. It can write only to `vpn-control/inbox/` and read a strictly sanitized
status file from `vpn-control/status/`.

A root-owned systemd service runs `host/vpn_profile_manager.py`. It claims
requests from the inbox, independently validates profiles, resolves WireGuard
hostnames on the host, controls Docker Compose, writes status atomically, and
performs recovery or rollback. The dashboard can briefly disappear while
`vpn`, the VPN-bound `sv-proxy`, and `app` are recreated. The direct-egress
allowlisted `vh-proxy` remains separate.

## Accepted OpenVPN profiles

- Maximum size: 1 MiB
- Filename ends in `.ovpn`
- IPv4 UDP or TCP client profile using a TUN device
- At least one valid `remote` directive
- Certificate, key, CA, TLS key, and optional auth data embedded inline
- No password-encrypted private key
- No mixed TCP/UDP remotes

External paths, script/plugin/management hooks, server or TAP mode, proxy
settings, logging paths, daemonization, and malformed inline data are rejected.
Existing OpenVPN switching behavior is preserved.

## Accepted WireGuard profiles

WireGuard can be supplied as a standard `.conf` file (maximum 64 KiB) or with
the dedicated manual fields. Both paths are normalized to the same canonical
root-only representation before the privileged manager validates it again.

Required client settings:

- exactly one `[Interface]` and one `[Peer]`;
- one non-zero canonical 32-byte `PrivateKey` and server `PublicKey`;
- at least one IPv4 interface `Address`, with an optional IPv6 address;
- one IPv4, IPv6, or hostname `Endpoint` and UDP port;
- full-tunnel `AllowedIPs` containing `0.0.0.0/0`, and `::/0` whenever an IPv6
  tunnel address is present;
- optional canonical `PresharedKey`, `PersistentKeepalive`, and MTU from 1280
  through 9000.

Provider `DNS` IPs are accepted but deliberately replaced by the stack's
Google DoH policy. Executable `PreUp`, `PostUp`, `PreDown`, and `PostDown`
hooks, multiple peers, split-tunnel routes, and wg-quick interface/routing
state directives are rejected.

Gluetun remains pinned to `v3.41.1`. The manager mounts only WireGuard private
key, optional pre-shared key, and interface addresses at
`/run/secrets/wg0.conf`. Resolved endpoint IP, port, server public key, full
routes, keepalive, and MTU enter a root-only `vpn/active.env`. Keepalive is
rendered there as an explicit Gluetun duration such as `25s`, while the private
canonical profile and dashboard continue to represent the setting as integer
seconds. Private keys are never placed in Compose YAML, environment values,
generic settings, status, logs, command lines, or updater payloads.

## IPv4 and IPv6

The private Docker network is dual-stack and Gluetun's IPv6 sysctl is enabled.
Gluetun keeps both IPv4 and IPv6 firewall policies at DROP except for the VPN,
local allowlisted proxy subnet, and established traffic. WireGuard always gets
full-tunnel IPv4 and IPv6 AllowedIPs; Gluetun ignores unsupported IPv6 routing
when the profile has no IPv6 interface address. A dual-stack WireGuard profile
must pass both IPv4 and IPv6 HTTPS probes from the application container before
commit. A v4-only WireGuard profile must pass IPv4. Failure restores the prior
complete protocol state.

A hostname endpoint is resolved before Gluetun starts because pinned Gluetun
requires a literal endpoint IP. IPv4 is preferred when both A and AAAA records
exist for compatibility with hosts that lack native IPv6; an explicit IPv6
endpoint or an AAAA-only hostname uses IPv6.

## Transaction and recovery states

- `idle`: manager is available
- `queued`: dashboard wrote a request
- `validating`: independent host validation is running
- `applying`: candidate is installed and Compose is recreating VPN/SV-proxy/app
- `applied`: candidate and all required health checks passed
- `rolling_back`: automatic, recovery, or manual restoration is running
- `rolled_back`: previous complete protocol state is healthy
- `failed`: validation failed without activation, or recovery needs attention

Before touching runtime files, the manager stores all five private state files
(`client.ovpn`, `client.gluetun.ovpn`, `wireguard.conf`, `wg0.conf`, and
`active.env`) with hashes in a mode-0700 backup directory. A mode-0600 journal
makes an interrupted multi-file install recover conservatively on service
restart. Exact predecessor schema-1 OpenVPN backups remain restorable.

The backup history is bounded, while the current rollback target and active
recovery backup are protected from pruning. Status exposes only protocol,
transport, endpoint, endpoint family, supported tunnel families, port, and a
short fingerprint.

## Service administration

```bash
sudo systemctl status vine-vpn-profile-manager.service
sudo journalctl -u vine-vpn-profile-manager.service -n 100 --no-pager
```

Do not paste provider endpoints or any profile/key content into chat. The
service is designed not to log profile bodies or private key values.
