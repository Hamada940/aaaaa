'use strict';

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const https = require('https');
const WebSocket = require('ws');
const ioClient = require('socket.io-client');
const { HttpsProxyAgent } = require('https-proxy-agent');
const crypto = require('crypto');
const axios = require('axios');
const { VHelperIdentityManager } = require('./lib/vh-identity');
const {
  ITEM_EXPLORER_ACTION,
  ITEM_EXPLORER_APP_VERSION,
  ITEM_EXPLORER_QUEUE,
  ITEM_EXPLORER_MAX_RESPONSE_BYTES,
  ItemExplorerValidationError,
  normalizeItemExplorerRequest,
  buildItemExplorerContent,
  normalizeEmbeddedVariants,
  sanitizeItemExplorerResponse,
  isEntitlementMessage,
  safeUpstreamMessage
} = require('./lib/vh-item-explorer');
const {
  ITEM_EXPLORER_VARIANTS_ACTION,
  ITEM_EXPLORER_VARIANTS_VERSION,
  ITEM_EXPLORER_VARIANTS_MAX_RESPONSE_BYTES,
  ItemExplorerVariantsValidationError,
  normalizeItemExplorerVariantsRequest,
  buildItemExplorerVariantsContent,
  sanitizeItemExplorerVariantsResponse
} = require('./lib/vh-item-explorer-variants');
const {
  TRIAL_STATUS_ACTION,
  TRIAL_STATUS_APP_VERSION,
  TRIAL_STATUS_MAX_RESPONSE_BYTES,
  TrialStatusValidationError,
  normalizeTrialStatusRequest,
  buildTrialStatusContent,
  sanitizeTrialStatusResponse
} = require('./lib/vh-trial-status');
const {
  parseBoolean,
  normalizeVhPayload,
  normalizeVhEnrichment,
  extractBroadcastSync,
  decideBroadcastMismatchRecovery
} = require('./lib/vh-protocol');
const {
  UV_CATEGORY_CATALOG,
  normalizeUvCategoryId,
  getUvCategory,
  normalizePriorityCategoryIds,
  extractUvCategoryId
} = require('./lib/uv-categories');
const {
  compilePriorityRules,
  evaluateCompiledPriorityRules
} = require('./lib/priority-rules');
const {
  UV_RUNTIME_VERSION,
  UV_LAUNCHER_VERSION,
  UV_IDENTIFICATION_CAPABILITIES,
  UV_ACCOUNT_HOUSEKEEPING_TYPES,
  buildUvSearchRequestBody,
  normalizeUvOrdersInProgress
} = require('./lib/uv-protocol');
const { UvRetryController } = require('./lib/uv-retry-controller');
const {
  UV_EXPLORER_PAGE_SIZE,
  UvExplorerValidationError,
  normalizeUvExplorerRequest,
  buildUvExplorerSignedPayload,
  uvExplorerPageMetadata
} = require('./lib/uv-explorer');
const {
  MAX_OVPN_BYTES,
  MAX_WIREGUARD_BYTES,
  validateVpnSubmission
} = require('./lib/vpn-profile');
const { LivePersistence } = require('./lib/live-persistence');
const {
  normalizeSourceList,
  deriveLiveSources,
  liveMergeDecision,
  observeSource,
  sourceRaceSummary
} = require('./lib/source-registry');
const { SmartVinerClient } = require('./lib/sv-client');
const {
  DEFAULT_SUPPRESSION_HOURS,
  MAX_CLEARED_ITEMS,
  normalizeSuppressionHours,
  validateSuppressionHours,
  loadClearedItemMemory,
  serializeClearedItemMemory,
  pruneClearedItemMemory,
  rememberClearedItems,
  observeClearedItem,
  clearedItemMemoryStatus
} = require('./lib/cleared-item-memory');
const {
  extractEnrollmentGuid,
  sanitizeRecommendationMetadata
} = require('./lib/order-protocol');
const { OrderCoordinator } = require('./lib/order-coordinator');
const UV_CATEGORY_ID_SET = new Set(UV_CATEGORY_CATALOG.map(category => category.id));
const notificationHttpsAgent = new https.Agent({
  keepAlive: true,
  maxSockets: 32,
  maxFreeSockets: 8
});
const SV_PROXY_URL = String(process.env.SV_HTTPS_PROXY || '').trim();
const svHttpsProxyAgent = (() => {
  if (!SV_PROXY_URL) return null;
  try {
    const parsed = new URL(SV_PROXY_URL);
    if (
      parsed.protocol !== 'http:' ||
      parsed.hostname !== '127.0.0.1' ||
      parsed.port !== '8889' ||
      parsed.username ||
      parsed.password ||
      parsed.pathname !== '/' ||
      parsed.search ||
      parsed.hash
    ) {
      throw new Error('proxy must be exactly http://127.0.0.1:8889');
    }
    return new HttpsProxyAgent(parsed.href);
  } catch (error) {
    console.error('[SV] Invalid SV_HTTPS_PROXY:', error.message);
    return null;
  }
})();
const VERBOSE_LIVE_ITEM_LOGS = parseBoolean(process.env.VINE_VERBOSE_LIVE_LOGS, false);
function liveItemLog(...args) {
  if (VERBOSE_LIVE_ITEM_LOGS) console.log(...args);
}

// ============================================================================
// DIRECTORIES & PERSISTENCE
// ============================================================================
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const CONFIG_FILE = path.join(__dirname, 'config.json');
const ITEMS_FILE = path.join(DATA_DIR, 'items.json');
const ACTIVITY_FILE = path.join(DATA_DIR, 'activity.json');
const KEYWORDS_FILE = path.join(DATA_DIR, 'keywords.json');
const PINNED_FILE = path.join(DATA_DIR, 'pinned.json');
const DISMISSED_PRIORITY_FILE = path.join(DATA_DIR, 'dismissed_priority.json');
const HIDDEN_FILE = path.join(DATA_DIR, 'hidden.json');
const IDENTITY_FILE = path.join(DATA_DIR, 'identity.json');
const NOTIFIED_FILE = path.join(DATA_DIR, 'notified.json');
const CLEARED_ITEMS_FILE = path.join(DATA_DIR, 'cleared_items.json');
const FEED_HEALTH_FILE = path.join(DATA_DIR, 'feed_health.json');
const UV_PROFILE_FILE = path.join(DATA_DIR, 'uv_profile.json');
const SV_AUTH_FILE = path.join(DATA_DIR, 'sv_auth.json');
const ORDER_AGENT_FILE = path.join(DATA_DIR, 'order_agent.json');
const ORDER_RULES_FILE = path.join(DATA_DIR, 'order_rules.json');
const ORDER_JOBS_FILE = path.join(DATA_DIR, 'order_jobs.json');
const ORDER_WATCHES_FILE = path.join(DATA_DIR, 'order_watches.json');
const ORDER_SAFETY_FILE = path.join(DATA_DIR, 'order_safety.json');
const VPN_CONTROL_DIR = process.env.VPN_CONTROL_DIR
  ? path.resolve(process.env.VPN_CONTROL_DIR)
  : path.join(DATA_DIR, 'vpn-control');
const VPN_CONTROL_INBOX = path.join(VPN_CONTROL_DIR, 'inbox');
const VPN_CONTROL_STATUS_FILE = path.join(VPN_CONTROL_DIR, 'status', 'status.json');
const VPN_UPLOAD_CONFIRMATION = 'APPLY VPN PROFILE';
const VPN_ROLLBACK_CONFIRMATION = 'ROLL BACK VPN';
const CLEARED_MEMORY_RESET_CONFIRMATION = 'RESET CLEARED ITEM MEMORY';
const ORDER_PAIR_CONFIRMATION = 'PAIR PC ORDER COMPANION';
const ORDER_REVOKE_CONFIRMATION = 'REVOKE PC ORDER COMPANION';
const ORDER_IMPORT_CONFIRMATION = 'IMPORT ORDER AUTOMATION';
const VPN_BUSY_STATES = new Set(['queued', 'validating', 'applying', 'rolling_back']);

function loadJSON(file, def) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    console.error(`[FS] Error reading ${file}:`, error.message);
  }
  return def;
}

function saveJSON(file, data, options = {}) {
  const tempFile = `${file}.${process.pid}.${Date.now()}.tmp`;
  const serialized = JSON.stringify(data, null, 2);
  const currentMode = (() => {
    try {
      return fs.statSync(file).mode & 0o777;
    } catch (_) {
      return null;
    }
  })();
  const isSensitive =
    options.sensitive === true ||
    file === CONFIG_FILE ||
    file === IDENTITY_FILE ||
    /(?:identity|profile|credential|secret|token|auth)/i.test(path.basename(file));
  const mode = Number.isInteger(options.mode)
    ? options.mode
    : isSensitive
      ? 0o600
      : currentMode ?? 0o644;

  try {
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    fs.writeFileSync(tempFile, serialized, { encoding: 'utf8', mode });
    fs.chmodSync(tempFile, mode);
    try {
      fs.renameSync(tempFile, file);
      fs.chmodSync(file, mode);
    } catch (renameError) {
      // Docker cannot atomically replace a file that is itself a bind-mount
      // (usually EBUSY). Fall back to updating that mounted file in place.
      if (!['EBUSY', 'EXDEV', 'EPERM', 'EACCES'].includes(renameError.code)) throw renameError;
      fs.writeFileSync(file, serialized, { encoding: 'utf8', mode });
      fs.chmodSync(file, mode);
      try {
        fs.unlinkSync(tempFile);
      } catch (_) {}
    }
    return true;
  } catch (error) {
    try {
      if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    } catch (_) {}
    console.error(`[FS] Error writing ${file}:`, error.message);
    return false;
  }
}

function publicVpnManagerStatus() {
  let raw;
  try {
    const stat = fs.statSync(VPN_CONTROL_STATUS_FILE);
    if (!stat.isFile() || stat.size > 64 * 1024) throw new Error('invalid status file');
    raw = JSON.parse(fs.readFileSync(VPN_CONTROL_STATUS_FILE, 'utf8'));
  } catch (_) {
    return {
      schemaVersion: 1,
      managerAvailable: false,
      state: 'unavailable',
      message: 'The host VPN profile manager is not installed or has not started.',
      updatedAt: null,
      canRollback: false
    };
  }

  const safeProfile = value => {
    if (!value || typeof value !== 'object') return null;
    const vpnProtocol = ['openvpn', 'wireguard'].includes(String(value.vpnProtocol || '').toLowerCase())
      ? String(value.vpnProtocol).toLowerCase()
      : 'openvpn';
    const transportValue = String(value.transport || value.protocol || '').toLowerCase();
    const transport = ['udp', 'tcp'].includes(transportValue) ? transportValue : null;
    const endpointFamilyValue = String(value.endpointFamily || '').toLowerCase();
    const endpointFamily = ['ipv4', 'ipv6', 'hostname'].includes(endpointFamilyValue)
      ? endpointFamilyValue
      : null;
    const tunnelFamilies = Array.isArray(value.tunnelFamilies)
      ? [...new Set(value.tunnelFamilies.map(item => String(item).toLowerCase()))]
          .filter(item => ['ipv4', 'ipv6'].includes(item))
          .slice(0, 2)
      : ['ipv4'];
    return {
      vpnProtocol,
      transport,
      // protocol is retained for older dashboard code and means transport.
      protocol: transport,
      endpoint: String(value.endpoint || '').slice(0, 253),
      port: Number(value.port) >= 1 && Number(value.port) <= 65535 ? Number(value.port) : null,
      endpointFamily,
      tunnelFamilies,
      fingerprint: /^[a-f0-9]{1,32}$/i.test(String(value.fingerprint || ''))
        ? String(value.fingerprint).toLowerCase().slice(0, 32)
        : null
    };
  };

  return {
    schemaVersion: 2,
    managerAvailable: raw.managerAvailable === true,
    state: String(raw.state || 'unknown').slice(0, 40),
    message: String(raw.message || '').slice(0, 1000),
    error: raw.error ? String(raw.error).slice(0, 2000) : null,
    requestId: raw.requestId ? String(raw.requestId).slice(0, 80) : null,
    originalName: raw.originalName ? path.basename(String(raw.originalName)).slice(0, 180) : null,
    submittedAt: raw.submittedAt || null,
    startedAt: raw.startedAt || null,
    finishedAt: raw.finishedAt || null,
    updatedAt: raw.updatedAt || null,
    activeProfile: safeProfile(raw.activeProfile),
    candidateProfile: safeProfile(raw.candidateProfile),
    canRollback: raw.canRollback === true
  };
}

function ensureVpnManagerReady() {
  const status = publicVpnManagerStatus();
  if (!status.managerAvailable) {
    const error = new Error(status.message);
    error.statusCode = 503;
    throw error;
  }
  if (VPN_BUSY_STATES.has(status.state)) {
    const error = new Error(`A VPN profile transaction is already ${status.state}.`);
    error.statusCode = 409;
    throw error;
  }
  try {
    fs.mkdirSync(VPN_CONTROL_INBOX, { recursive: true, mode: 0o700 });
    fs.accessSync(VPN_CONTROL_INBOX, fs.constants.W_OK | fs.constants.X_OK);
  } catch (_) {
    const error = new Error('The VPN profile inbox is not writable by the application.');
    error.statusCode = 503;
    throw error;
  }
  const pending = fs
    .readdirSync(VPN_CONTROL_INBOX)
    .some(name => name.endsWith('.request.json'));
  if (pending) {
    const error = new Error('A VPN profile request is already queued.');
    error.statusCode = 409;
    throw error;
  }
  return status;
}

function writePrivateExclusive(file, content) {
  const descriptor = fs.openSync(file, 'wx', 0o600);
  try {
    fs.writeFileSync(descriptor, content, { encoding: 'utf8' });
    fs.fsyncSync(descriptor);
  } finally {
    fs.closeSync(descriptor);
  }
  fs.chmodSync(file, 0o600);
}

function queueVpnManagerRequest(request, candidateContent = null, candidateExtension = null) {
  const requestId = request.requestId;
  const extension = candidateContent === null
    ? null
    : String(candidateExtension || '').toLowerCase();
  if (extension && !['ovpn', 'conf'].includes(extension)) {
    throw new Error('Unsupported VPN candidate file type.');
  }
  const candidateFile = candidateContent === null ? null : `${requestId}.${extension}`;
  const candidatePath = candidateFile ? path.join(VPN_CONTROL_INBOX, candidateFile) : null;
  const requestPath = path.join(VPN_CONTROL_INBOX, `${requestId}.request.json`);

  try {
    if (candidatePath) writePrivateExclusive(candidatePath, candidateContent);
    writePrivateExclusive(
      requestPath,
      `${JSON.stringify({ ...request, candidateFile }, null, 2)}\n`
    );
  } catch (error) {
    try {
      if (candidatePath && fs.existsSync(candidatePath)) fs.unlinkSync(candidatePath);
    } catch (_) {}
    try {
      if (fs.existsSync(requestPath)) fs.unlinkSync(requestPath);
    } catch (_) {}
    throw error;
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================
const DEFAULT_CONFIG = {
  port: 3001,
  domain: 'amazon.ca',
  countryCode: 'ca',

  // Ultraviner is enabled by default. token + azUser are account inputs; the
  // remaining identity values are legacy mirrors of data/uv_profile.json.
  enableUV: true,
  token: '',
  azUser: '',
  device: '',
  selectedScreenId: '',
  alertQueueId: '',
  exploreQueueId: '',
  // UV synchronizes screen/queue definitions over the WebSocket. The
  // canonical local copy lives in data/uv_profile.json; the four identity
  // fields above remain mirrored for backwards-compatible deployments.
  uvSyncScreens: true,
  displayName: 'Vine Drop Hub',
  uvUserAgent:
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
  uvIdentificationDelayMs: 500,
  uvAuthenticationTimeoutMs: 15000,
  // Silent identification timeouts recover automatically. The cooldown doubles
  // after each consecutive timeout, receives bounded jitter, and tops out at
  // five minutes. An explicit WebSocket invalidToken remains terminal.
  uvReconnectDelayMs: 5000,
  uvReconnectMaxDelayMs: 300000,
  uvReconnectJitterRatio: 0.2,

  // Independent feed-health monitoring. UV's signed search path is probed
  // periodically as non-destructive REST evidence; it neither proves nor may
  // tear down WebSocket identification. Persistent transport/session outages
  // trigger one alert and recovery.
  enableFeedHealthAlerts: true,
  uvTokenCheckIntervalMs: 21600000,
  feedOutageGraceMs: 120000,

  // VHelper can be enabled in config or through /api/vh/enable.
  // UV_ONLY=1 or DISABLE_VH=1 is a hard process-level kill switch.
  enableVH: false,

  // SmartViner is separately authenticated and disabled by default. Rotating
  // session state lives only in private data/sv_auth.json; generic Settings
  // cannot read, submit, enable, disable, or erase it. No history catch-up.
  enableSV: false,

  // The Package B live transport is passive/live-only. VH getLast100 is
  // prohibited in every path (startup, recovery, health, and manual refresh).
  // R20's explicit item_explorer search is isolated from this compatibility flag.
  vhLoadHistory: false,

  telegramToken: '',
  telegramChatId: '',
  enableTelegram: false,
  discordWebhook: '',
  minPriorityPrice: 100,
  // UV product-category IDs selected in the dashboard. Category data is
  // optional and UV-derived; VH-only items remain category-unknown.
  priorityCategoryIds: [],
  maxStoredItems: 2000,
  notificationDedupeMinutes: 5,
  // Clear/delete hides a seen ASIN from every live source for this period.
  // Zero explicitly disables cleared-item memory and restores legacy clearing.
  clearedItemSuppressionHours: DEFAULT_SUPPRESSION_HOURS
};

let config = { ...DEFAULT_CONFIG, ...loadJSON(CONFIG_FILE, {}) };
config.clearedItemSuppressionHours = normalizeSuppressionHours(
  config.clearedItemSuppressionHours,
  DEFAULT_SUPPRESSION_HOURS
);
// Package B never permits VH history, even if an older config file carried a
// stale true value.
config.vhLoadHistory = false;
config.priorityCategoryIds = normalizePriorityCategoryIds(config.priorityCategoryIds).filter(id =>
  UV_CATEGORY_ID_SET.has(id)
);
// Keep only the one-way Amazon identity hash even when a raw customerId was
// supplied through a private bootstrap config.
if (config.azUser) config.azUser = sha256(String(config.azUser).trim());
saveJSON(CONFIG_FILE, config);

// ============================================================================
// ULTRAVINER LOCAL DEVICE, SCREENS & QUEUES
// ============================================================================
// UV 26.9.38 creates these UUIDs in the browser; they are not secrets and do
// not need to be copied from another installation. The Amazon customer ID is
// different: UV obtains it from an authenticated Amazon/Vine page and hashes
// it before identification, so it cannot be reconstructed from the UV token.
const UV_QUEUE_TYPES = Object.freeze([
  'Alert',
  'RFY',
  'AFA',
  'AI',
  'Search',
  'Explore',
  'Sweep',
  'Bookmark',
  'Chat'
]);
const UV_QUEUE_TYPE_SET = new Set(UV_QUEUE_TYPES);
const UV_SCREEN_ICONS = new Set(['computer', 'laptop', 'phone']);

function newUvId() {
  return crypto.randomUUID();
}

function safeIsoDate(value, fallback = new Date().toISOString()) {
  const parsed = Date.parse(value || '');
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : fallback;
}

function newUvScreen({ id = newUvId(), name = 'Screen 1', icon = 'computer', order = 1 } = {}) {
  const now = new Date().toISOString();
  return {
    id,
    order,
    name,
    icon: UV_SCREEN_ICONS.has(icon) ? icon : 'computer',
    isTemporary: false,
    creationDate: now,
    modifiedDate: now
  };
}

function newUvQueue(queueType, screenId, options = {}) {
  const now = new Date().toISOString();
  const type = UV_QUEUE_TYPE_SET.has(queueType) ? queueType : 'AI';
  const isCompact = ['Alert', 'Bookmark', 'Chat'].includes(type);
  return {
    queueDisplayType: isCompact ? 'list' : 'vanilla',
    queueSortType: 'smart',
    productSize: 5,
    queueSizingMode: 'relative',
    queueSize: type === 'AI' ? 10 : 1,
    queueHeight: ['RFY', 'AFA', 'Explore', 'Sweep'].includes(type) ? 3 : 1,
    hideBottomPagination: false,
    hideTopPagination: true,
    enableTopPaginatorHeatmap: true,
    enableBottomPaginatorHeatmap: true,
    hideImageCarousel: false,
    displayHiddenProducts: false,
    displayTitleTooltips: false,
    enableRocketOrder: false,
    enableRowSpacers: false,
    enableInvertedFlow: false,
    productFlow: 'left-to-right top-to-bottom',
    queueType: type,
    id: options.id || newUvId(),
    name: String(options.name || '').slice(0, 80),
    screenId,
    order: Number(options.order) || 1,
    isTemporary: false,
    forceRefresh: false,
    isTabActive: options.isTabActive !== false,
    isSettingsOpen: false,
    isFilterOpen: true,
    isMuted: false,
    selectedCategory: '',
    selectedSubcategory: '',
    selectedChatChannel: options.selectedChatChannel || null,
    selectedCountry: null,
    selectedBrendaCategories: null,
    selectedQueueTypes: null,
    searchTerm: String(options.searchTerm || ''),
    enableAutoRefresh: false,
    autoRefreshIntervalStart: 30,
    autoRefreshIntervalEnd: 60,
    enableAutoRefreshHourRestriction: false,
    autoRefreshHourStart: 8,
    autoRefreshHourEnd: 18,
    isAutoRefreshPaused: false,
    enableAutoRefreshCyclePages: false,
    enableAutoRefreshCyclePagesRestriction: false,
    autoRefreshCyclePagesEndHour: 12,
    pauseAutoRefreshOnProductFound: false,
    unpauseAutoRefreshOnHideAllProducts: false,
    etvFilterType: 'none',
    etvFilterCustomValue: 0,
    creationDate: now,
    modifiedDate: now
  };
}

function createDefaultUvProfile(legacy = {}) {
  const hasLegacyLayout = Boolean(
    legacy.device || legacy.selectedScreenId || legacy.alertQueueId || legacy.exploreQueueId
  );
  const screen = newUvScreen({ id: legacy.selectedScreenId || newUvId() });
  const definitions = [
    ['Alert', legacy.alertQueueId || newUvId()],
    ['RFY', newUvId()],
    ['AFA', newUvId()],
    ['AI', newUvId()],
    ['Search', newUvId()],
    ['Explore', legacy.exploreQueueId || newUvId()],
    ['Sweep', newUvId()],
    ['Bookmark', newUvId()],
    ['Chat', newUvId()]
  ];
  const queues = definitions.map(([type, id], index) =>
    newUvQueue(type, screen.id, {
      id,
      order: index + 1,
      isTabActive: ['Alert', 'RFY', 'AFA', 'AI', 'Search', 'Chat'].includes(type)
    })
  );

  return {
    schemaVersion: 1,
    device: legacy.device || newUvId(),
    selectedScreenId: screen.id,
    screens: [screen],
    queues,
    // This is a skeleton, even when legacy IDs were inherited: config.json did
    // not contain the complete queue layout or trustworthy modified dates.
    // Hydrate from UV first whenever remote screens exist, never overwrite a
    // real remote layout with newly manufactured defaults during migration.
    bootstrapScreenId: screen.id,
    initialSyncComplete: false,
    profileSource: hasLegacyLayout ? 'legacy-id-migration' : 'generated',
    updatedAt: new Date().toISOString()
  };
}

function normalizeUvScreen(screen, index) {
  const now = new Date().toISOString();
  const source = screen && typeof screen === 'object' ? screen : {};
  return {
    ...source,
    id: String(source.id || newUvId()),
    order: Number(source.order) || index + 1,
    name: String(source.name || `Screen ${index + 1}`).slice(0, 80),
    icon: UV_SCREEN_ICONS.has(source.icon) ? source.icon : 'computer',
    isTemporary: false,
    creationDate: safeIsoDate(source.creationDate, now),
    modifiedDate: safeIsoDate(source.modifiedDate, source.creationDate || now)
  };
}

function normalizeUvQueue(queue, screenId, index) {
  const source = queue && typeof queue === 'object' ? queue : {};
  const type = UV_QUEUE_TYPE_SET.has(source.queueType) ? source.queueType : 'AI';
  const base = newUvQueue(type, screenId, {
    id: source.id || newUvId(),
    name: source.name,
    order: Number(source.order) || index + 1,
    selectedChatChannel: source.selectedChatChannel,
    searchTerm: source.searchTerm,
    isTabActive: source.isTabActive
  });
  return {
    ...base,
    ...source,
    id: String(source.id || base.id),
    screenId,
    queueType: type,
    name: String(source.name || '').slice(0, 80),
    order: Number(source.order) || index + 1,
    isTemporary: false,
    selectedChatChannel: source.selectedChatChannel || null,
    creationDate: safeIsoDate(source.creationDate, base.creationDate),
    modifiedDate: safeIsoDate(source.modifiedDate, source.creationDate || base.modifiedDate)
  };
}

function normalizeUvProfile(value, legacy = {}) {
  if (!value || typeof value !== 'object') return createDefaultUvProfile(legacy);

  let screens = Array.isArray(value.screens)
    ? value.screens.map(normalizeUvScreen).filter(screen => screen.id)
    : [];
  if (!screens.length) screens = [newUvScreen()];
  screens.sort((a, b) => a.order - b.order);
  screens.forEach((screen, index) => {
    screen.order = index + 1;
  });

  const screenIds = new Set(screens.map(screen => screen.id));
  let queues = Array.isArray(value.queues)
    ? value.queues
        .filter(queue => queue && screenIds.has(String(queue.screenId || '')))
        .map((queue, index) => normalizeUvQueue(queue, String(queue.screenId), index))
    : [];

  const firstScreenId = screens[0].id;
  if (!queues.some(queue => queue.queueType === 'Alert')) {
    queues.push(
      newUvQueue('Alert', firstScreenId, {
        id: legacy.alertQueueId || newUvId(),
        order: queues.filter(queue => queue.screenId === firstScreenId).length + 1
      })
    );
  }
  for (const screen of screens) {
    const screenQueues = queues
      .filter(queue => queue.screenId === screen.id)
      .sort((a, b) => a.order - b.order);
    screenQueues.forEach((queue, index) => {
      queue.order = index + 1;
    });
  }

  const selectedScreenId = screenIds.has(String(value.selectedScreenId || ''))
    ? String(value.selectedScreenId)
    : firstScreenId;
  const bootstrapScreenId = screenIds.has(String(value.bootstrapScreenId || ''))
    ? String(value.bootstrapScreenId)
    : null;

  return {
    ...value,
    schemaVersion: 1,
    device: String(value.device || legacy.device || newUvId()),
    selectedScreenId,
    screens,
    queues,
    bootstrapScreenId,
    initialSyncComplete: Boolean(value.initialSyncComplete),
    updatedAt: safeIsoDate(value.updatedAt)
  };
}

let uvProfile = normalizeUvProfile(loadJSON(UV_PROFILE_FILE, null), config);

function getUvQueues(queueType = null) {
  const queues = Array.isArray(uvProfile.queues) ? uvProfile.queues : [];
  return queues
    .filter(queue => !queueType || queue.queueType === queueType)
    .sort((a, b) => a.order - b.order);
}

function effectiveUvExploreQueue() {
  const queue = getUvQueues('Explore')[0];
  if (!queue?.id) return null;
  return {
    id: String(queue.id),
    name: String(queue.name || 'Explore').slice(0, 80),
    screenId: String(queue.screenId || '') || null
  };
}

function syncLegacyUvConfig() {
  const selectedScreen = uvProfile.screens.find(
    screen => screen.id === uvProfile.selectedScreenId
  ) || uvProfile.screens[0];
  const alertQueue = getUvQueues('Alert')[0];
  const exploreQueue = effectiveUvExploreQueue();
  config.device = uvProfile.device;
  config.selectedScreenId = selectedScreen?.id || '';
  config.alertQueueId = alertQueue?.id || '';
  // Never relabel an Alert queue as Explore. Signed search requires the real
  // canonical Explore queue identity from data/uv_profile.json.
  config.exploreQueueId = exploreQueue?.id || '';
}

function persistUvProfile() {
  uvProfile.updatedAt = new Date().toISOString();
  syncLegacyUvConfig();
  saveJSON(UV_PROFILE_FILE, uvProfile);
  saveJSON(CONFIG_FILE, config);
}

function inspectUvToken(token = config.token) {
  const text = String(token || '').trim();
  let decodedUuid = false;
  try {
    const decoded = Buffer.from(text.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString(
      'utf8'
    );
    decodedUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      decoded
    );
  } catch (_) {}
  return {
    present: Boolean(text),
    length: text.length,
    opaqueAccountToken: decodedUuid,
    containsAmazonIdentity: false
  };
}

function publicUvExploreReadiness() {
  const queue = effectiveUvExploreQueue();
  const selectedScreen = uvProfile.screens.find(screen => screen.id === uvProfile.selectedScreenId) || null;
  const selectedScreenQueueCount = selectedScreen
    ? uvProfile.queues.filter(candidate => candidate.screenId === selectedScreen.id).length
    : 0;
  const accountReady = Boolean(config.token && config.azUser);
  const syncEnabled = config.uvSyncScreens !== false;
  const socketOpen = Boolean(uvWs && uvWs.readyState === WebSocket.OPEN);
  const authenticated = Boolean(uvAuthenticated);
  const capacityReady = Boolean(selectedScreen && selectedScreenQueueCount < 40);
  const blockers = [];
  if (!queue) {
    if (!accountReady) blockers.push('uv_account_incomplete');
    if (!syncEnabled) blockers.push('uv_screen_sync_disabled');
    if (!socketOpen || !authenticated) blockers.push('uv_session_not_authenticated');
    if (!selectedScreen) blockers.push('uv_selected_screen_missing');
    else if (!capacityReady) blockers.push('uv_selected_screen_queue_limit');
  }
  return {
    ready: Boolean(queue),
    setupRequired: !queue,
    queueId: queue?.id || null,
    queueScreenId: queue?.screenId || null,
    accountReady,
    syncEnabled,
    socketOpen,
    authenticated,
    selectedScreenReady: Boolean(selectedScreen),
    selectedScreenId: selectedScreen?.id || null,
    selectedScreenQueueCount,
    selectedScreenQueueLimit: 40,
    capacityReady,
    canCreate: !queue && blockers.length === 0,
    blockers
  };
}

function publicUvProfile() {
  const alertQueues = getUvQueues('Alert');
  const chatQueues = getUvQueues('Chat');
  return {
    schemaVersion: uvProfile.schemaVersion,
    device: uvProfile.device,
    selectedScreenId: uvProfile.selectedScreenId,
    screens: [...uvProfile.screens].sort((a, b) => a.order - b.order),
    queues: [...uvProfile.queues].sort((a, b) => {
      const aScreen = uvProfile.screens.find(screen => screen.id === a.screenId)?.order || 0;
      const bScreen = uvProfile.screens.find(screen => screen.id === b.screenId)?.order || 0;
      return aScreen - bScreen || a.order - b.order;
    }),
    alertQueues: alertQueues.map(queue => ({ id: queue.id, name: queue.name || '' })),
    chatQueues: chatQueues.map(queue => ({
      id: queue.id,
      selectedChatChannel: queue.selectedChatChannel || null
    })),
    syncScreens: config.uvSyncScreens !== false,
    explorerReadiness: publicUvExploreReadiness(),
    initialSyncComplete: Boolean(uvProfile.initialSyncComplete),
    bootstrapPending: Boolean(uvProfile.bootstrapScreenId),
    onboarding: {
      ready: Boolean(config.token && config.azUser),
      newAccountPairRequired: true,
      hasToken: Boolean(config.token),
      hasAmazonUser: Boolean(config.azUser),
      missing: [!config.token && 'token', !config.azUser && 'azUser'].filter(Boolean),
      token: inspectUvToken()
    },
    updatedAt: uvProfile.updatedAt
  };
}

syncLegacyUvConfig();
saveJSON(UV_PROFILE_FILE, uvProfile);
saveJSON(CONFIG_FILE, config);

const VH_FORCE_DISABLED =
  process.env.UV_ONLY === '1' ||
  process.env.DISABLE_VH === '1' ||
  process.env.ENABLE_VH === '0';

function isVhEnabled() {
  return Boolean(config.enableVH) && !VH_FORCE_DISABLED;
}

const QUEUE_CONFIDENCE_RANK = Object.freeze({ default: 0, legacy: 1, derived: 2, explicit: 3 });
const ALERT_ORIGIN_CONFIDENCE_RANK = Object.freeze({ default: 0, event: 1, explicit: 2 });

// Cleared ASINs live in a separate, bounded ledger. They are intentionally not
// cards, activity entries, or notification-dedupe records. A restart therefore
// cannot turn a delayed UV/VH/SV confirmation back into a new visible item.
let clearedItemMemory = loadClearedItemMemory(loadJSON(CLEARED_ITEMS_FILE, {}), {
  suppressionHours: config.clearedItemSuppressionHours,
  maxEntries: MAX_CLEARED_ITEMS
});
let clearedItemMemoryNeedsPersistence = false;

function persistClearedItemMemory() {
  const saved = saveJSON(CLEARED_ITEMS_FILE, serializeClearedItemMemory(clearedItemMemory), {
    sensitive: true
  });
  if (saved) clearedItemMemoryNeedsPersistence = false;
  return saved;
}

function pruneAndPersistClearedItemMemory(now = Date.now()) {
  const removed = pruneClearedItemMemory(
    clearedItemMemory,
    now,
    config.clearedItemSuppressionHours,
    MAX_CLEARED_ITEMS
  );
  if (removed) clearedItemMemoryNeedsPersistence = true;
  if (clearedItemMemoryNeedsPersistence) persistClearedItemMemory();
  return removed;
}

function rememberClearedRecords(records, now = Date.now()) {
  // rememberClearedItems replaces touched entries and prunes Map keys without
  // mutating untouched entry objects, so a shallow Map snapshot is transactional.
  const previousMemory = new Map(clearedItemMemory);
  const previousNeedsPersistence = clearedItemMemoryNeedsPersistence;
  const result = rememberClearedItems(clearedItemMemory, records, {
    now,
    suppressionHours: config.clearedItemSuppressionHours,
    maxEntries: MAX_CLEARED_ITEMS
  });
  let persisted = true;
  if (result.changed) {
    clearedItemMemoryNeedsPersistence = true;
    persisted = persistClearedItemMemory();
    if (!persisted) {
      clearedItemMemory = previousMemory;
      clearedItemMemoryNeedsPersistence = previousNeedsPersistence;
    }
  }
  return { ...result, persisted };
}

function suppressFromClearedItemMemory(asin, source, now = Date.now()) {
  const result = observeClearedItem(clearedItemMemory, asin, source, {
    now,
    suppressionHours: config.clearedItemSuppressionHours
  });
  if (result.changed) {
    if (result.suppressed) {
      clearedItemMemoryNeedsPersistence = true;
      persistClearedItemMemory();
    } else {
      // An expired tombstone permits this item. Defer only this housekeeping
      // write until after the genuine live broadcast/notification starts.
      clearedItemMemoryNeedsPersistence = true;
    }
  }
  return result.suppressed;
}

// Canonicalize the document even when an older or malformed shape was loaded.
clearedItemMemoryNeedsPersistence = true;
persistClearedItemMemory();

let allItems = loadJSON(ITEMS_FILE, []);
if (!Array.isArray(allItems)) allItems = [];
// If the process stopped between durably recording a clear and the asynchronous
// items write, the tombstone remains authoritative on restart.
allItems = allItems.filter(item => !clearedItemMemory.has(String(item?.asin || '').trim().toUpperCase()));

function appendSource(value, source) {
  return normalizeSourceList([...(Array.isArray(value) ? value : []), source]);
}

function isLiveItem(item) {
  return deriveLiveSources(item).length > 0;
}

// Preserve each live transport's own Vine queue independently from the merged
// card's current display queue. This retains exact provenance and the legacy
// local vh_rfy_only compatibility filter when a later same-ASIN event has a
// different queue. Legacy records are inferred only when provenance is
// unambiguous; mixed-source records without source-specific evidence are not guessed.
function storedLiveQueueForSource(item, source) {
  const expectedSource = String(source || '').toUpperCase();
  if (!['UV', 'VH', 'SV'].includes(expectedSource)) return null;

  const liveSources = deriveLiveSources(item);
  if (!liveSources.includes(expectedSource)) return null;

  const explicitValue = expectedSource === 'VH'
    ? item?.vhQueue
    : expectedSource === 'SV'
      ? item?.svQueue
      : item?.uvQueue;
  const explicitQueue = normalizeKnownQueue(explicitValue);
  if (explicitQueue) return explicitQueue;

  const mergedQueue = normalizeKnownQueue(item?.queue);
  if (!mergedQueue) return null;
  if (String(item?.queueObservedFrom || '').toUpperCase() === expectedSource) {
    return mergedQueue;
  }
  return liveSources.length === 1 ? mergedQueue : null;
}

function isPassiveVhRfyItem(item) {
  return storedLiveQueueForSource(item, 'VH') === 'RFY';
}

function trustedStoredUvCategoryId(item) {
  if (!item || typeof item !== 'object') return null;
  const observedSources = normalizeSourceList([
    ...normalizeSourceList(item.observedSources),
    ...normalizeSourceList(item.sources)
  ]);
  const hasUvProvenance =
    String(item.categorySource || '').toUpperCase() === 'UV' || observedSources.includes('UV');
  return hasUvProvenance ? normalizeUvCategoryId(item.categoryId) : null;
}

function normalizeStoredItemSources(item) {
  if (!item || typeof item !== 'object') return item;

  const observedSources = normalizeSourceList([
    ...normalizeSourceList(item.observedSources),
    ...normalizeSourceList(item.sources)
  ]);
  const liveSources = deriveLiveSources(item);
  const historySources = normalizeSourceList(
    item.historySources || observedSources.filter(source => !liveSources.includes(source))
  );

  const uvAlertQueueIds = Array.isArray(item.uvAlertQueueIds)
    ? [...new Set(item.uvAlertQueueIds.map(id => String(id || '')).filter(Boolean))]
    : liveSources.includes('UV')
      ? getUvQueues('Alert').map(queue => queue.id)
      : [];
  const storedOrigin = storedAlertOriginClassification(item);
  const uvQueue = storedLiveQueueForSource(item, 'UV');
  const vhQueue = storedLiveQueueForSource(item, 'VH');
  const svQueue = storedLiveQueueForSource(item, 'SV');
  const enrollmentGuid = extractEnrollmentGuid(item) || null;
  const scrubbedItem = sanitizeRecommendationMetadata(item);

  return {
    ...scrubbedItem,
    sources: liveSources,
    liveSources,
    observedSources,
    historySources,
    enrichmentSources: normalizeSourceList(item.enrichmentSources),
    uvAlertQueueIds,
    uvQueue,
    vhQueue,
    svQueue,
    origin: storedOrigin.origin,
    alertOrigin: storedOrigin.origin,
    alertOrigins: storedOrigin.origins,
    alertOriginConfidence: storedOrigin.confidence,
    alertOriginRaw: storedOrigin.raw,
    recommendation: enrollmentGuid,
    enrollmentGuid,
    enrollment_guid: enrollmentGuid,
    isHistoricalOnly: liveSources.length === 0
  };
}

// Migrate persisted records so badges and race statistics represent genuine
// live detections, not historical batches or detail-only enrichment.
allItems = allItems.map(normalizeStoredItemSources);

let activityLog = loadJSON(ACTIVITY_FILE, []);
if (!Array.isArray(activityLog)) activityLog = [];

// Live item, activity, and notification-state writes are delegated to a
// worker thread. The feed event loop never waits for JSON serialization or
// filesystem I/O before broadcasting a newly received item.
let livePersistence = null;

let keywords = loadJSON(KEYWORDS_FILE, {
  highlight: [
    'espresso',
    'coffee',
    'oled',
    '4k',
    'monitor',
    'anker',
    'drone',
    'ssd',
    'leather',
    'vacuum',
    'gpu',
    'nvme'
  ],
  hide: [],
  blur: []
});
if (!keywords || typeof keywords !== 'object') {
  keywords = { highlight: [], hide: [], blur: [] };
}
for (const type of ['highlight', 'hide', 'blur']) {
  if (!Array.isArray(keywords[type])) keywords[type] = [];
}

let compiledPriorityRules = null;
function refreshCompiledPriorityRules() {
  compiledPriorityRules = compilePriorityRules({
    keywords,
    minPriorityPrice: config.minPriorityPrice,
    priorityCategoryIds: config.priorityCategoryIds
  });
  return compiledPriorityRules;
}
refreshCompiledPriorityRules();

// Normalize category metadata, priority sources, queue provenance, and canonical
// two-token Vine search links at startup. Alert-origin provenance is normalized
// in the same pass. This repairs
// persisted punctuation links, high-confidence VH-AFA/RFY -> UV-default-AI race
// collisions recorded by the local activity log, and the legacy mistake that
// stored Brenda/Discord as a queue. Unrelated history and private data are kept.
allItems = allItems.map(item => {
  if (!item || typeof item !== 'object') return item;
  const categoryId = trustedStoredUvCategoryId(item);
  const category = getUvCategory(categoryId);
  const matches = checkKeywordMatches(item.title, item.price, item.etv, categoryId);
  const searchTitle = item.title || 'Unknown Product';
  const firstTwoWords = getFirstTwoWords(searchTitle);
  const legacyQueueRepair = repairLegacyUvQueueCollision(item, activityLog);
  const storedQueue = storedQueueClassification(item);
  const legacyBrendaQueue = /(?:brenda|discord)/i.test(String(item.queue || ''));
  const legacyOriginEvent = legacyBrendaQueue || /alert(?:Details)?FromBrenda/i.test(
    String(item.queueRaw || item.sourceEvent || '')
  )
    ? 'alertFromBrenda'
    : /alertFromRedrop/i.test(String(item.queueRaw || item.sourceEvent || ''))
      ? 'alertFromRedrop'
      : '';
  const migratedLegacyQueue = legacyBrendaQueue
    ? classifyItemQueue(item, '', null)
    : null;
  const startupQueue = legacyQueueRepair.repaired
    ? {
        queue: legacyQueueRepair.queue,
        confidence: 'derived',
        raw: legacyQueueRepair.reason,
        source: 'startup-migration',
        observedAt: item.last_seen || item.date_added || null
      }
    : migratedLegacyQueue
      ? {
          ...migratedLegacyQueue,
          source: 'startup-origin-migration',
          observedAt: item.last_seen || item.date_added || null
        }
      : {
          ...storedQueue,
          queue: storedQueue.queue || 'AI'
        };
  const liveSources = deriveLiveSources(item);
  const startupUvQueue = normalizeKnownQueue(item.uvQueue) ||
    (liveSources.includes('UV') && String(startupQueue.source || '').toUpperCase() === 'UV'
      ? normalizeKnownQueue(startupQueue.queue)
      : null);
  const startupVhQueue = normalizeKnownQueue(item.vhQueue) ||
    (legacyQueueRepair.repaired && liveSources.includes('VH')
      ? normalizeKnownQueue(legacyQueueRepair.queue)
      : liveSources.includes('VH') && String(startupQueue.source || '').toUpperCase() === 'VH'
        ? normalizeKnownQueue(startupQueue.queue)
        : null);
  const startupSvQueue = normalizeKnownQueue(item.svQueue) ||
    (liveSources.includes('SV') && String(startupQueue.source || '').toUpperCase() === 'SV'
      ? normalizeKnownQueue(startupQueue.queue)
      : null);
  const startupOrigin = resolveMergedAlertOrigin(
    item,
    classifyItemAlertOrigin(item, legacyOriginEvent, '', false)
  );
  return {
    ...item,
    firstTwoWords,
    vineSearchUrl: getTwoWordSearchUrl(searchTitle),
    uvQueue: startupUvQueue,
    vhQueue: startupVhQueue,
    svQueue: startupSvQueue,
    queue: startupQueue.queue,
    queueConfidence: startupQueue.confidence,
    queueRaw: startupQueue.raw,
    queueObservedFrom: startupQueue.source,
    queueObservedAt: startupQueue.observedAt,
    origin: startupOrigin.origin,
    alertOrigin: startupOrigin.origin,
    alertOrigins: startupOrigin.origins,
    alertOriginConfidence: startupOrigin.confidence,
    alertOriginRaw: startupOrigin.raw,
    categoryId,
    categoryName: category?.name || null,
    categoryEmoji: category?.emoji || null,
    categorySource: categoryId ? 'UV' : null,
    isHighlight: matches.isHighlight,
    isPriceHighlight: matches.isPriceHighlight,
    isCategoryPriority: matches.isCategoryPriority,
    priorityReasons: matches.priorityReasons,
    isHide: matches.isHide,
    isBlur: matches.isBlur
  };
});
saveJSON(ITEMS_FILE, allItems);

const pinnedAsins = new Set(loadJSON(PINNED_FILE, []));
const dismissedPriorityAsins = new Set(loadJSON(DISMISSED_PRIORITY_FILE, []));
const hiddenAsins = new Set(loadJSON(HIDDEN_FILE, []));

// New format: { "ASIN": epochMilliseconds }. Old array files are deliberately
// migrated to timestamps of zero so historical entries do not permanently
// suppress a future genuine live alert.
const notifiedRaw = loadJSON(NOTIFIED_FILE, {});
const notifiedAt = new Map();
if (Array.isArray(notifiedRaw)) {
  notifiedRaw.forEach(asin => {
    if (asin) notifiedAt.set(asin, 0);
  });
} else if (notifiedRaw && typeof notifiedRaw === 'object') {
  Object.entries(notifiedRaw).forEach(([asin, timestamp]) => {
    const value = Number(timestamp);
    if (asin && Number.isFinite(value)) notifiedAt.set(asin, value);
  });
}
let nextNotifiedSweepAt = 0;

function notificationDedupeTtlMs() {
  return Math.max(0, Number(config.notificationDedupeMinutes) || 5) * 60000;
}

function pruneExpiredNotified(now = Date.now(), force = false) {
  const ttl = notificationDedupeTtlMs();
  if (!force && now < nextNotifiedSweepAt) return 0;
  nextNotifiedSweepAt = now + Math.max(1000, Math.min(30000, ttl || 1000));
  let removed = 0;
  for (const [asin, timestamp] of notifiedAt.entries()) {
    if (!Number.isFinite(timestamp) || timestamp <= 0 || ttl === 0 || now - timestamp >= ttl) {
      notifiedAt.delete(asin);
      removed += 1;
    }
  }
  return removed;
}
pruneExpiredNotified(Date.now(), true);

const persistedFeedHealth = loadJSON(FEED_HEALTH_FILE, {});
function createFeedHealthRecord(feed) {
  const saved = persistedFeedHealth?.[feed] || {};
  return {
    feed,
    status: saved.activeIncident ? 'down' : 'checking',
    reason: saved.reason || '',
    incidentKey: saved.incidentKey || '',
    incidentSince: saved.incidentSince || null,
    activeIncident: Boolean(saved.activeIncident),
    alertedAt: saved.alertedAt || null,
    lastHealthyAt: saved.lastHealthyAt || null,
    recoveredAt: saved.recoveredAt || null,
    lastTokenCheckAt: saved.lastTokenCheckAt || null,
    lastTokenCheckStatus: saved.lastTokenCheckStatus || null
  };
}

const feedHealth = {
  UV: createFeedHealthRecord('UV'),
  VH: createFeedHealthRecord('VH'),
  SV: createFeedHealthRecord('SV')
};

function notifiedSnapshot() {
  pruneExpiredNotified();
  const entries = [...notifiedAt.entries()]
    .filter(([, timestamp]) => Number.isFinite(timestamp))
    .sort((left, right) => left[1] - right[1])
    .slice(-5000);
  return Object.fromEntries(entries);
}

function persistNotified() {
  const snapshot = notifiedSnapshot();
  if (!livePersistence?.replaceNotified(snapshot)) saveJSON(NOTIFIED_FILE, snapshot);
}

function wasRecentlyNotified(asin, now = Date.now()) {
  const timestamp = notifiedAt.get(asin);
  if (!Number.isFinite(timestamp) || timestamp <= 0) return false;
  if (now - timestamp < notificationDedupeTtlMs()) return true;
  notifiedAt.delete(asin);
  return false;
}

function markNotified(asin, now = Date.now()) {
  // This synchronous in-memory mark suppresses a duplicate immediately. The
  // caller starts outbound notifications before handing the mark to disk.
  pruneExpiredNotified(now);
  notifiedAt.delete(asin);
  notifiedAt.set(asin, now);
  return now;
}

function itemSortTime(item) {
  const numeric = Number(item?.date_added_ms ?? item?.last_seen_ms);
  if (Number.isFinite(numeric)) return numeric;
  const parsed = Date.parse(item?.date_added || item?.date || item?.last_seen || '');
  return Number.isFinite(parsed) ? parsed : 0;
}

function compareItems(left, right) {
  const leftPinned = pinnedAsins.has(left.asin);
  const rightPinned = pinnedAsins.has(right.asin);
  if (leftPinned !== rightPinned) return leftPinned ? -1 : 1;

  const leftPriority = left.isHighlight && !dismissedPriorityAsins.has(left.asin);
  const rightPriority = right.isHighlight && !dismissedPriorityAsins.has(right.asin);
  if (leftPriority !== rightPriority) return leftPriority ? -1 : 1;

  return itemSortTime(right) - itemSortTime(left);
}

function sortItemsArray(arr) {
  arr.sort(compareItems);
}

function sortedItemInsertionIndex(item) {
  let low = 0;
  let high = allItems.length;
  while (low < high) {
    const middle = (low + high) >>> 1;
    if (compareItems(item, allItems[middle]) < 0) high = middle;
    else low = middle + 1;
  }
  return low;
}

function upsertItemInMemory(item, knownIndex) {
  // `undefined` means the caller has not looked. An integer -1 means the
  // caller already proved absence, so do not repeat a full-array scan.
  let index = Number.isInteger(knownIndex)
    ? knownIndex
    : allItems.findIndex(candidate => candidate.asin === item.asin);
  if (index >= 0 && allItems[index]?.asin !== item.asin) {
    // Defensively recover if a stale positive index was supplied.
    index = allItems.findIndex(candidate => candidate.asin === item.asin);
  }
  if (index !== -1) allItems.splice(index, 1);

  item.isPinned = pinnedAsins.has(item.asin);
  item.isPriorityDismissed = dismissedPriorityAsins.has(item.asin);
  item.isHiddenManual = hiddenAsins.has(item.asin);
  allItems.splice(sortedItemInsertionIndex(item), 0, item);

  const maximum = Number(config.maxStoredItems) || 2000;
  if (allItems.length > maximum) allItems.length = maximum;
  return item;
}

function persistItemUpsert(item) {
  if (!livePersistence?.upsertItem(item, Number(config.maxStoredItems) || 2000)) {
    saveJSON(ITEMS_FILE, allItems);
  }
}

function persistItemsReplace() {
  if (!livePersistence?.replaceItems(allItems, Number(config.maxStoredItems) || 2000)) {
    saveJSON(ITEMS_FILE, allItems);
  }
}

function persistItemsDelete(asins) {
  if (!livePersistence?.deleteItems(asins)) saveJSON(ITEMS_FILE, allItems);
}

sortItemsArray(allItems);
for (const item of allItems) {
  item.isPinned = pinnedAsins.has(item.asin);
  item.isPriorityDismissed = dismissedPriorityAsins.has(item.asin);
  item.isHiddenManual = hiddenAsins.has(item.asin);
}

livePersistence = new LivePersistence({
  files: {
    items: ITEMS_FILE,
    activity: ACTIVITY_FILE,
    notified: NOTIFIED_FILE
  },
  initial: {
    items: allItems,
    activity: activityLog,
    notified: notifiedSnapshot()
  },
  maximumItems: Number(config.maxStoredItems) || 2000,
  onFatal: error => {
    // Fault-only fallback: retain correctness if the worker itself fails.
    // Normal live ingestion never enters these synchronous writes.
    console.error('[Persistence Worker]', error.message);
    saveJSON(ITEMS_FILE, allItems);
    saveJSON(ACTIVITY_FILE, activityLog);
    saveJSON(NOTIFIED_FILE, notifiedSnapshot());
  }
});

console.log(
  `[Storage] ${allItems.length} items, ${pinnedAsins.size} pinned, ` +
    `${notifiedAt.size} notification records.`
);

// ============================================================================
// VHELPER IDENTITY (PACKAGE B)
// ============================================================================
const VH_APP_VERSION = '4.7.4';
const VH_BUILD_VERSION = '3637';
const VH_API_VERSION = 5;
const VH_API_URL = 'https://api.v-helper.com/';
const VH_WS_URL = 'wss://api.v-helper.com';
const VH_PROXY_URL = String(process.env.VH_PROXY_URL || '').trim();

function publicVhProtocolVersions() {
  return Object.freeze({
    liveIdentity: VH_APP_VERSION,
    auditedBuild: VH_BUILD_VERSION,
    api: VH_API_VERSION,
    itemExplorer: ITEM_EXPLORER_APP_VERSION,
    itemExplorerVariants: ITEM_EXPLORER_VARIANTS_VERSION,
    trialStatus: TRIAL_STATUS_APP_VERSION
  });
}
let vhProxyAgent = null;

if (VH_PROXY_URL) {
  try {
    const parsedProxy = new URL(VH_PROXY_URL);
    if (!['http:', 'https:'].includes(parsedProxy.protocol)) {
      throw new Error('VH_PROXY_URL must use http:// or https://');
    }
    vhProxyAgent = new HttpsProxyAgent(parsedProxy);
    console.log(
      `[VH NET] Destination-locked direct proxy configured: ${parsedProxy.hostname}:${
        parsedProxy.port || (parsedProxy.protocol === 'https:' ? 443 : 80)
      }`
    );
  } catch (error) {
    console.error('[VH NET] Invalid VH_PROXY_URL:', error.message);
  }
}

function vhAxiosOptions(timeout = 15000) {
  const bounded = {
    timeout,
    maxContentLength: ITEM_EXPLORER_MAX_RESPONSE_BYTES,
    maxBodyLength: 128 * 1024
  };
  return vhProxyAgent
    ? { ...bounded, httpsAgent: vhProxyAgent, proxy: false }
    : bounded;
}

function describeVhError(error) {
  const status = error?.response?.status;
  const raw = error?.response?.data;
  const body = raw == null ? '' : typeof raw === 'string' ? raw : JSON.stringify(raw);
  const excerpt = body.replace(/\s+/g, ' ').slice(0, 240);
  return `${error.message}${status ? ` | HTTP ${status}` : ''}${excerpt ? ` | ${excerpt}` : ''}`;
}

async function requestVhJson(payload) {
  if (!isVhEnabled()) throw new Error('VHelper is disabled');
  const response = await axios.post(VH_API_URL, payload, vhAxiosOptions(15000));
  return response.data;
}

const identityManager = new VHelperIdentityManager({
  file: IDENTITY_FILE,
  loadJSON,
  saveJSON,
  requestJson: requestVhJson,
  apiVersion: VH_API_VERSION,
  appVersion: VH_APP_VERSION
});

// User-initiated signed VHelper reads share one in-memory mutex, replay cache,
// and server-directed cooldown. Item Explorer results, click-loaded Watch-flow
// variants, and trial-status replies stay isolated from the live feed,
// notifications, activity logs, and disk.
const VH_SIGNED_REQUEST_TTL_MS = 10 * 60 * 1000;
const VH_SIGNED_MAX_REQUEST_IDS = 128;
const vhSignedRequestIds = new Map();
let vhSignedRequestInFlight = false;
let vhSignedNextAllowedAtMs = 0;
let vhItemExplorerLastAttemptAt = null;
let vhItemExplorerLastSuccessAt = null;
let vhItemExplorerLastErrorCode = null;

function pruneVhSignedRequestIds(now = Date.now()) {
  for (const [requestId, expiresAt] of vhSignedRequestIds.entries()) {
    if (!Number.isFinite(expiresAt) || expiresAt <= now) {
      vhSignedRequestIds.delete(requestId);
    }
  }
  while (vhSignedRequestIds.size > VH_SIGNED_MAX_REQUEST_IDS) {
    const oldest = vhSignedRequestIds.keys().next().value;
    if (!oldest) break;
    vhSignedRequestIds.delete(oldest);
  }
}

function hasSeenVhSignedRequest(requestId, now = Date.now()) {
  pruneVhSignedRequestIds(now);
  return vhSignedRequestIds.has(requestId);
}

function rememberVhSignedRequest(requestId, now = Date.now()) {
  vhSignedRequestIds.set(requestId, now + VH_SIGNED_REQUEST_TTL_MS);
  pruneVhSignedRequestIds(now);
}

function applyVhSignedCooldown(waitTime, now = Date.now()) {
  const seconds = Number(waitTime);
  if (!Number.isFinite(seconds) || seconds <= 0) return 0;
  const boundedSeconds = Math.min(86400, Math.ceil(seconds));
  vhSignedNextAllowedAtMs = Math.max(
    vhSignedNextAllowedAtMs,
    now + boundedSeconds * 1000
  );
  return boundedSeconds;
}

function vhSignedRetryAfterSeconds(now = Date.now()) {
  return Math.max(0, Math.ceil((vhSignedNextAllowedAtMs - now) / 1000));
}

function publicVhItemExplorerStatus() {
  return {
    enabled: isVhEnabled(),
    available: true,
    action: ITEM_EXPLORER_ACTION,
    fixedQueue: ITEM_EXPLORER_QUEUE,
    userInitiatedOnly: true,
    automaticPolling: false,
    inFlight: vhSignedRequestInFlight,
    retryAfterSeconds: vhSignedRetryAfterSeconds(),
    lastAttemptAt: vhItemExplorerLastAttemptAt,
    lastSuccessAt: vhItemExplorerLastSuccessAt,
    lastErrorCode: vhItemExplorerLastErrorCode,
    resultsPersisted: false,
    liveStoreMerged: false,
    identityMutationAllowed: false
  };
}

function publicVhItemExplorerVariantsCapability() {
  return {
    enabled: isVhEnabled(),
    available: true,
    action: ITEM_EXPLORER_VARIANTS_ACTION,
    userInitiatedOnly: true,
    watchArmClickOnly: true,
    oneRequestPerClick: true,
    automaticPolling: false,
    automaticRetry: false,
    inFlight: vhSignedRequestInFlight,
    retryAfterSeconds: vhSignedRetryAfterSeconds(),
    responsePersisted: false,
    liveStoreMerged: false,
    identityMutationAllowed: false,
    alternateSourcesAllowed: false
  };
}

function publicVhTrialStatusCapability() {
  return {
    enabled: isVhEnabled(),
    available: true,
    action: TRIAL_STATUS_ACTION,
    userInitiatedOnly: true,
    automaticPolling: false,
    inFlight: vhSignedRequestInFlight,
    retryAfterSeconds: vhSignedRetryAfterSeconds(),
    responsePersisted: false,
    resolvedUuidApplied: false,
    devicesAccepted: false,
    contributionStatisticsAccepted: false,
    paymentDataAccepted: false,
    identityMutationAllowed: false
  };
}

// ============================================================================
// ULTRAVINER CRYPTOGRAPHY & UTILS
// ============================================================================
const COUNTRY_MAP = {
  'amazon.com': 1,
  US: 1,
  'amazon.ca': 2,
  CA: 2,
  'amazon.co.uk': 3,
  UK: 3,
  'amazon.de': 4,
  DE: 4,
  'amazon.fr': 5,
  FR: 5,
  'amazon.it': 6,
  IT: 6,
  'amazon.es': 7,
  ES: 7,
  'amazon.co.jp': 8,
  JP: 8,
  'amazon.com.au': 9,
  AU: 9
};
const Ge = COUNTRY_MAP;

function sha256(text) {
  if (!text) return '';
  if (/^[0-9a-f]{64}$/i.test(text)) return text.toLowerCase();
  return crypto.createHash('sha256').update(String(text)).digest('hex');
}

function sortObjectDeep(value) {
  if (value == null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(sortObjectDeep);
  const output = {};
  Object.keys(value)
    .sort()
    .forEach(key => {
      output[key] = sortObjectDeep(value[key]);
    });
  return output;
}

function signUvPayload(payload, token) {
  const timestamp = Date.now();
  const serialized = JSON.stringify(sortObjectDeep(payload));
  const signature = crypto
    .createHmac('sha256', token)
    .update(serialized)
    .digest('hex');

  return {
    'Content-Type': 'application/json',
    'X-Request-Signature': signature,
    'X-Request-Timestamp': timestamp.toString()
  };
}

// ============================================================================
// ITEM, TITLE, DATE & KEYWORD UTILS
// ============================================================================
function decodeHtmlEntities(str) {
  if (!str) return '';
  return String(str)
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, decimal) => String.fromCharCode(Number(decimal)))
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
}

function getFirstTwoWords(title) {
  if (!title) return '';
  // Choose words by whitespace before removing wrappers. Punctuation that is
  // meaningful inside a brand token (GL.iNet, e.l.f., AT&T, C++, Wi-Fi,
  // O'Keeffe's) must not split that token and consume the two-word budget.
  return decodeHtmlEntities(title)
    .trim()
    .split(/\s+/u)
    .map(token => token.replace(/[^\p{L}\p{M}\p{N}._&+'’\/-]+/gu, ''))
    .filter(token => /[\p{L}\p{N}]/u.test(token))
    .slice(0, 2)
    .join(' ');
}

function getTwoWordSearchUrl(title, domain = config.domain) {
  return `https://www.${domain}/vine/vine-items?search=${encodeURIComponent(
    getFirstTwoWords(title)
  )}`;
}

function normalizeKnownQueue(queueValue, eventType = '') {
  if (queueValue === 15 || queueValue === '15') return 'AI';
  if (queueValue === 14 || queueValue === '14') return 'AFA';
  if (queueValue === 13 || queueValue === '13') return 'RFY';

  const value = String(queueValue || '')
    .toLowerCase()
    .replace(/[\s\-_]+/g, '_');

  // Brenda/Discord and Redrop describe how an alert entered Ultraviner, not
  // the Amazon Vine queue that contains the product. Deliberately ignore those
  // words here so a later official product `type` can still resolve RFY/AFA/AI.
  void eventType;

  if (
    value.includes('potluck') ||
    value.includes('rfy') ||
    value.includes('vendor_targeted') ||
    value.includes('targeted')
  ) {
    return 'RFY';
  }

  if (
    value.includes('last_chance') ||
    value.includes('lastchance') ||
    value.includes('afa') ||
    value.includes('vendor_vine_for_all') ||
    value.includes('vine_for_all_vendor')
  ) {
    return 'AFA';
  }

  if (
    value.includes('encore') ||
    value === 'ai' ||
    value.includes('vine_for_all') ||
    value.includes('all_items') ||
    value.includes('allitems')
  ) {
    return 'AI';
  }

  return null;
}

function normalizeAlertOrigin(value) {
  const normalized = String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[\s\-_]+/g, '_');
  if (!normalized) return null;
  if (normalized.includes('brenda') || normalized.includes('discord')) return 'brenda';
  if (normalized.includes('redrop')) return 'redrop';
  if (normalized.includes('ultraviner') || normalized === 'uv') return 'ultraviner';
  if (normalized.includes('myself')) return 'myself';
  return null;
}

function normalizeAlertOriginList(value) {
  const list = Array.isArray(value) ? value : value ? [value] : [];
  return [
    ...new Set(list.map(normalizeAlertOrigin).filter(Boolean))
  ];
}

function classifyItemAlertOrigin(item, eventType = '', source = '', inferUvDefault = true) {
  const product = item && typeof item === 'object' ? item : {};
  const explicitCandidates = [
    product.origin,
    product.alertOrigin,
    product.alert_origin,
    product.alertSource,
    product.alert_source
  ];
  for (const candidate of explicitCandidates) {
    const origin = normalizeAlertOrigin(candidate);
    if (origin) {
      return {
        origin,
        confidence: 'explicit',
        raw: String(candidate).slice(0, 120)
      };
    }
  }

  if (eventType === 'alertFromBrenda' || eventType === 'alertDetailsFromBrenda') {
    return { origin: 'brenda', confidence: 'event', raw: eventType };
  }
  if (eventType === 'alertFromRedrop') {
    return { origin: 'redrop', confidence: 'event', raw: eventType };
  }
  if (inferUvDefault && String(source).toUpperCase() === 'UV') {
    return { origin: 'ultraviner', confidence: 'default', raw: eventType || null };
  }
  return { origin: null, confidence: 'default', raw: null };
}

function storedAlertOriginClassification(item) {
  const origins = normalizeAlertOriginList([
    ...(Array.isArray(item?.alertOrigins) ? item.alertOrigins : []),
    item?.alertOrigin,
    item?.origin
  ]);
  const origin =
    normalizeAlertOrigin(item?.alertOrigin) || normalizeAlertOrigin(item?.origin) || origins[0] || null;
  const confidence = Object.hasOwn(ALERT_ORIGIN_CONFIDENCE_RANK, item?.alertOriginConfidence)
    ? item.alertOriginConfidence
    : origin
      ? 'event'
      : 'default';
  return {
    origin,
    origins,
    confidence,
    raw: item?.alertOriginRaw ?? null
  };
}

function resolveMergedAlertOrigin(existing, incoming) {
  const previous = storedAlertOriginClassification(existing);
  if (!incoming?.origin) return previous;

  // A default "Ultraviner" inference must not overwrite or dilute an already
  // evidenced Brenda/Redrop origin when a later generic enrichment frame omits
  // its own origin field. Explicit payload values and named origin events win.
  if (incoming.confidence === 'default' && previous.origins.length > 0) return previous;

  const origins = normalizeAlertOriginList([...previous.origins, incoming.origin]);
  const previousRank = ALERT_ORIGIN_CONFIDENCE_RANK[previous.confidence] ?? 0;
  const incomingRank = ALERT_ORIGIN_CONFIDENCE_RANK[incoming.confidence] ?? 0;
  const useIncoming = !previous.origin || incomingRank >= previousRank;
  return {
    origin: useIncoming ? incoming.origin : previous.origin,
    origins,
    confidence: useIncoming ? incoming.confidence : previous.confidence,
    raw: useIncoming ? incoming.raw : previous.raw
  };
}

function alertOriginLabel(value) {
  const origin = normalizeAlertOrigin(value);
  if (origin === 'brenda') return 'Brenda';
  if (origin === 'redrop') return 'Redrop';
  if (origin === 'ultraviner') return 'Ultraviner';
  if (origin === 'myself') return 'Myself';
  return '';
}

function normalizeQueue(queueValue, eventType = '', fallbackQueue = null) {
  const known = normalizeKnownQueue(queueValue, eventType);
  if (known) return known;

  if (fallbackQueue && fallbackQueue !== 'ALL') {
    const fallback = normalizeKnownQueue(fallbackQueue);
    if (['RFY', 'AFA', 'AI'].includes(fallback)) return fallback;
  }

  return 'AI';
}

function classifyItemQueue(item, eventType = '', fallbackQueue = null) {
  const source = item && typeof item === 'object' ? item : {};
  // Event names identify the alert transport/origin and never override the
  // official product queue fields below.
  void eventType;

  // `type` is the official UV product field (for example,
  // VENDOR_VINE_FOR_ALL for AFA). Search all recognized fields rather than
  // allowing an unknown wrapper value to hide a later authoritative value.
  const candidates = [
    source.queue,
    source.queueType,
    source.recommendationType,
    source.recommendation_type,
    source.queue_type,
    source.queueName,
    source.type,
    source.vine_queue,
    source.feed
  ];
  for (const candidate of candidates) {
    const queue = normalizeKnownQueue(candidate);
    if (queue) {
      return {
        queue,
        confidence: 'explicit',
        raw: String(candidate).slice(0, 120)
      };
    }
  }

  const rfyOrders = Number(source.rfyOrders || 0);
  const afaOrders = Number(source.afaOrders || 0);
  const aiOrders = Number(source.aiOrders || 0);
  if (rfyOrders > 0 && !(afaOrders > 0) && !(aiOrders > 0)) {
    return { queue: 'RFY', confidence: 'derived', raw: 'rfyOrders' };
  }
  if (afaOrders > 0 && !(rfyOrders > 0) && !(aiOrders > 0)) {
    return { queue: 'AFA', confidence: 'derived', raw: 'afaOrders' };
  }
  if (aiOrders > 0 && !(rfyOrders > 0) && !(afaOrders > 0)) {
    return { queue: 'AI', confidence: 'derived', raw: 'aiOrders' };
  }

  const fallback = normalizeKnownQueue(fallbackQueue);
  if (fallback && ['RFY', 'AFA', 'AI'].includes(fallback)) {
    return { queue: fallback, confidence: 'derived', raw: 'fallbackQueue' };
  }

  return { queue: 'AI', confidence: 'default', raw: null };
}

function storedQueueClassification(item) {
  const queue = String(item?.queue || '').trim();
  const confidence = Object.hasOwn(QUEUE_CONFIDENCE_RANK, item?.queueConfidence)
    ? item.queueConfidence
    : queue && queue !== 'AI'
      ? 'legacy'
      : 'default';
  return {
    queue,
    confidence,
    raw: item?.queueRaw ?? null,
    source: item?.queueObservedFrom ?? null,
    observedAt: item?.queueObservedAt ?? null
  };
}

function resolveMergedQueue(existing, incoming, source, observedAt, isBackfill = false) {
  const previous = storedQueueClassification(existing);
  const candidate = {
    queue: incoming?.queue || 'AI',
    confidence: Object.hasOwn(QUEUE_CONFIDENCE_RANK, incoming?.confidence)
      ? incoming.confidence
      : 'default',
    raw: incoming?.raw ?? null,
    source,
    observedAt
  };

  if (!previous.queue) return candidate;
  if (isBackfill) return previous;

  const previousRank = QUEUE_CONFIDENCE_RANK[previous.confidence];
  const candidateRank = QUEUE_CONFIDENCE_RANK[candidate.confidence];
  // The concrete defect fixed here was a queue-less/default UV frame replacing
  // an explicit VH AFA classification on the same ASIN. Lower-confidence data
  // may enrich a merged card, but it must not relabel its known queue.
  if (candidateRank < previousRank) return previous;
  return candidate;
}

function repairLegacyUvQueueCollision(item, entries, maximumGapMs = 5 * 60 * 1000) {
  const currentQueue = String(item?.queue || '').toUpperCase();
  const liveSources = normalizeSourceList(item?.liveSources?.length ? item.liveSources : item?.sources);
  if (currentQueue !== 'AI' || !liveSources.includes('UV') || !liveSources.includes('VH')) {
    return { queue: item?.queue || 'AI', repaired: false };
  }

  const activity = Array.isArray(entries) ? entries : [];
  const starts = activity.filter(entry => {
    const data = entry?.data || {};
    return (
      entry?.type === 'new_item' &&
      data.asin === item.asin &&
      data.source === 'VH' &&
      ['AFA', 'RFY'].includes(String(data.queue || '').toUpperCase())
    );
  });
  const confirmations = activity.filter(entry => {
    const data = entry?.data || {};
    return (
      entry?.type === 'source_confirmation' &&
      data.asin === item.asin &&
      data.source === 'UV' &&
      String(data.queue || '').toUpperCase() === 'AI'
    );
  });

  for (const start of starts) {
    const startMs = Date.parse(start.date);
    if (!Number.isFinite(startMs)) continue;
    for (const confirmation of confirmations) {
      const confirmationMs = Date.parse(confirmation.date);
      if (
        Number.isFinite(confirmationMs) &&
        confirmationMs >= startMs &&
        confirmationMs - startMs <= maximumGapMs
      ) {
        return {
          queue: String(start.data.queue).toUpperCase(),
          repaired: true,
          reason: 'legacy-uv-default-overwrite'
        };
      }
    }
  }

  return { queue: item?.queue || 'AI', repaired: false };
}

function parseItemTime(raw) {
  const value =
    raw?.alertedDate ??
    raw?.date_added ??
    raw?.date ??
    raw?.createdAt ??
    raw?.lastDate ??
    raw?.timestamp;

  if (value == null || value === '') return null;

  if (typeof value === 'number' || /^\d+$/.test(String(value))) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return null;
    return numeric < 1e12 ? numeric * 1000 : numeric;
  }

  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseMoney(value, fallback = 0) {
  if (value == null || value === '' || value === 'N/A') return fallback;
  const parsed = Number(String(value).replace(/[^0-9.+-]/g, ''));
  return Number.isFinite(parsed) ? parsed : fallback;
}

function checkKeywordMatches(title, price = null, etv = null, categoryId = null) {
  return evaluateCompiledPriorityRules({
    title,
    price,
    etv,
    categoryId,
    compiled: compiledPriorityRules
  });
}

const BACKFILL_EVENT_TYPES = new Set([
  'INITIAL_LOAD',
  'HISTORICAL',
  'EXPLORE',
  'CATALOG',
  'BATCH_INGEST',
  'HTML_INGEST',
  'SEARCH'
]);

const UV_LIVE_ALERT_TYPES = new Set([
  'alerts',
  'alertFromEtv',
  'alertFromExternalData',
  'alertFromCategory',
  'alertFromBrenda',
  'alertDetailsFromBrenda',
  'alertFromRedrop'
]);

const UV_DETAIL_TYPES = new Set(['alertDetail', 'pageData']);
const UV_HOUSEKEEPING_TYPES = new Set([
  'status',
  ...UV_ACCOUNT_HOUSEKEEPING_TYPES,
  'categories',
  'categoryList',
  'subcategoryList',
  'connectionSummary',
  'speedometer',
  'screens',
  'screen',
  'syncedSettings',
  'hiveLoad',
  'version',
  'promotion',
  'electronVersion',
  'refreshWebhooks'
]);

// ============================================================================
// TELEGRAM & DISCORD
// ============================================================================
function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function truncateTelegramText(value, maximum) {
  const text = String(value ?? '');
  if (text.length <= maximum) return text;
  return `${text.slice(0, Math.max(0, maximum - 1)).trimEnd()}…`;
}

function telegramHttpUrl(value, fallback) {
  try {
    const parsed = new URL(String(value || ''));
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') return parsed.href;
  } catch (_) {}
  return fallback;
}

function telegramItemLinks(item) {
  const title = item.title || 'Unknown Product';
  const asin = item.asin || 'N/A';
  const words = item.firstTwoWords || getFirstTwoWords(title);
  const searchFallback = `https://www.${config.domain}/vine/vine-items?search=${encodeURIComponent(
    words
  )}`;
  const productFallback = `https://www.${config.domain}/dp/${encodeURIComponent(asin)}`;
  return {
    words,
    searchUrl: telegramHttpUrl(item.vineSearchUrl, searchFallback),
    productUrl: telegramHttpUrl(item.dpUrl, productFallback)
  };
}

function buildTelegramMessage(item, { compact = false } = {}) {
  const limited = (value, maximum) =>
    compact ? truncateTelegramText(value, maximum) : String(value ?? '');
  const queue = limited(String(item.queue || 'AI').toUpperCase(), 16);
  const title = limited(item.title || 'Unknown Product', 220);
  const asin = limited(item.asin || 'N/A', 20);
  const rawPrice = item.price != null && item.price !== 'N/A' ? `$${item.price}` : 'N/A';
  const rawEtv =
    item.etv != null && item.etv !== 'N/A'
      ? item.isZeroEtv
        ? '$0.00 (Free)'
        : `$${item.etv}`
      : 'N/A';
  const price = limited(rawPrice, 24);
  const etv = limited(rawEtv, 24);
  const brand = limited(item.brand || 'Unknown', 60);
  const dateValue = new Date(item.date_added || Date.now());
  const date = (Number.isNaN(dateValue.getTime()) ? new Date() : dateValue)
    .toISOString()
    .replace('T', ' ')
    .slice(0, 19);
  const links = telegramItemLinks(item);
  const words = limited(links.words, 60);
  const sourceTag = limited((item.sources || []).join(' + ') || 'Live', 40);
  const alertOriginTag = limited(
    normalizeAlertOriginList(item.alertOrigins?.length ? item.alertOrigins : [item.alertOrigin, item.origin])
      .map(alertOriginLabel)
      .filter(Boolean)
      .join(' + '),
    60
  );

  let message = '';
  if (item.isHighlight) message += '🚨 <b>[PRIORITY ITEM]</b>\n\n';
  message += `<b>${escapeHtml(title)}</b>\n\n`;
  message += `🏷️ <b>ASIN:</b> <code>${escapeHtml(asin)}</code>\n`;
  if (brand !== 'Unknown') message += `🏢 <b>Brand:</b> ${escapeHtml(brand)}\n`;
  if (item.categoryId) {
    const category = limited(item.categoryName || `Category ${item.categoryId}`, 80);
    message += `${item.categoryEmoji || '🏷️'} <b>Category:</b> ${escapeHtml(category)}\n`;
  }
  message += `💰 <b>ETV:</b> ${escapeHtml(etv)} | <b>Retail:</b> ${escapeHtml(price)}\n`;
  if (alertOriginTag) {
    message += `📡 <b>Alert origin:</b> ${escapeHtml(alertOriginTag)}\n`;
  }
  if (item.isHighlight && Array.isArray(item.priorityReasons) && item.priorityReasons.length) {
    const reasons = limited(item.priorityReasons.slice(0, 4).join('; '), 140);
    message += `🚨 <b>Priority because:</b> ${escapeHtml(reasons)}\n`;
  }
  message += `📅 <b>Detected:</b> ${date}\n\n`;
  message += `🛒 <b>Order:</b> <a href="${escapeHtml(
    links.searchUrl
  )}">Search Vine for "${escapeHtml(words)}"</a>\n`;
  message += `🔗 <b>Amazon:</b> <a href="${escapeHtml(
    links.productUrl
  )}">View on Amazon</a>\n\n`;
  message += `🔔 <b>NEW ${escapeHtml(queue)} DROP!</b> [${escapeHtml(sourceTag)}]`;
  return message;
}

function telegramItemReplyMarkup(item) {
  const links = telegramItemLinks(item);
  return {
    inline_keyboard: [
      [{ text: '🔍 Open Vine Search', url: links.searchUrl }],
      [{ text: '🛒 View on Amazon', url: links.productUrl }]
    ]
  };
}

function sendTelegramTextOnly(text, replyMarkup = null) {
  const body = {
    chat_id: config.telegramChatId,
    text,
    parse_mode: 'HTML',
    disable_web_page_preview: true
  };
  if (replyMarkup) body.reply_markup = replyMarkup;
  const payload = JSON.stringify(body);

  const request = https.request(
    {
      hostname: 'api.telegram.org',
      path: `/bot${config.telegramToken}/sendMessage`,
      method: 'POST',
      agent: notificationHttpsAgent,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    },
    response => {
      let responseBody = '';
      response.on('data', chunk => {
        responseBody += chunk;
      });
      response.on('end', () => {
        if (response.statusCode === 200) {
          console.log('[Telegram] Text alert sent.');
        } else {
          console.error(`[Telegram] HTTP ${response.statusCode}: ${responseBody.slice(0, 300)}`);
        }
      });
    }
  );

  request.on('error', error => console.error('[Telegram Error]:', error.message));
  request.write(payload);
  request.end();
  return true;
}

function sendTelegramPhoto(item) {
  const imageUrl = String(item.img_url || '').trim();
  const replyMarkup = telegramItemReplyMarkup(item);
  if (!/^https?:\/\//i.test(imageUrl)) {
    return sendTelegramTextOnly(buildTelegramMessage(item), replyMarkup);
  }

  const payload = JSON.stringify({
    chat_id: config.telegramChatId,
    photo: imageUrl,
    caption: buildTelegramMessage(item, { compact: true }),
    parse_mode: 'HTML',
    reply_markup: replyMarkup
  });
  let fallbackStarted = false;
  const startFallback = reason => {
    if (fallbackStarted) return;
    fallbackStarted = true;
    console.warn(`[Telegram] Photo alert failed (${reason}); using text fallback.`);
    sendTelegramTextOnly(buildTelegramMessage(item), replyMarkup);
  };

  const request = https.request(
    {
      hostname: 'api.telegram.org',
      path: `/bot${config.telegramToken}/sendPhoto`,
      method: 'POST',
      agent: notificationHttpsAgent,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    },
    response => {
      let responseBody = '';
      response.on('data', chunk => {
        responseBody += chunk;
      });
      response.on('end', () => {
        if (response.statusCode === 200) {
          console.log(`[Telegram] Photo alert sent: ${item.asin}`);
        } else {
          startFallback(`HTTP ${response.statusCode}: ${responseBody.slice(0, 180)}`);
        }
      });
    }
  );

  request.on('error', error => startFallback(error.message));
  request.write(payload);
  request.end();
  return true;
}

function sendTelegramNotification(item) {
  if (!config.enableTelegram || !config.telegramToken || !config.telegramChatId) return false;

  // Restore photo alerts while retaining the zero-wait live path: the
  // sendPhoto request starts now, before any live persistence message. Telegram
  // opens media taps in its viewer, so the Vine search and Amazon destinations
  // are exposed as prominent URL buttons directly below the photo.
  return sendTelegramPhoto(item);
}

async function sendDiscordWebhook(item) {
  if (!config.discordWebhook) return;

  try {
    const sourceTag = (item.sources || []).join(' + ') || 'Drop';
    await axios.post(
      config.discordWebhook,
      {
        username: 'Vine Drop Hub',
        embeds: [
          {
            title: `${item.isHighlight ? '🚨 [HIGHLIGHT] ' : ''}[${sourceTag}] ${String(
              item.title || 'Unknown Product'
            ).slice(0, 200)}`,
            url: item.dpUrl,
            color: item.isHighlight ? 0xff4757 : item.isZeroEtv ? 0x2ed573 : 0x70a1ff,
            fields: [
              { name: 'ASIN', value: `\`${item.asin}\``, inline: true },
              { name: 'Queue', value: item.queue || 'AI', inline: true },
              ...(normalizeAlertOriginList(
                item.alertOrigins?.length ? item.alertOrigins : [item.alertOrigin, item.origin]
              ).length
                ? [
                    {
                      name: 'Alert Origin',
                      value: normalizeAlertOriginList(
                        item.alertOrigins?.length
                          ? item.alertOrigins
                          : [item.alertOrigin, item.origin]
                      )
                        .map(alertOriginLabel)
                        .filter(Boolean)
                        .join(', '),
                      inline: true
                    }
                  ]
                : []),
              {
                name: 'ETV / Price',
                value: item.etv != null && item.etv !== 'N/A' ? `$${item.etv}` : 'N/A',
                inline: true
              },
              {
                name: 'Sources',
                value: (item.sources || []).join(', ') || 'Live',
                inline: true
              },
              ...(item.categoryId
                ? [
                    {
                      name: 'UV Category',
                      value: `${item.categoryEmoji || '🏷️'} ${
                        item.categoryName || `Category ${item.categoryId}`
                      }`,
                      inline: true
                    }
                  ]
                : []),
              ...(item.isHighlight && Array.isArray(item.priorityReasons) && item.priorityReasons.length
                ? [
                    {
                      name: 'Priority because',
                      value: item.priorityReasons.slice(0, 4).join('; '),
                      inline: false
                    }
                  ]
                : []),
              {
                name: 'Vine 2-Word Search',
                value: `[🔍 Search Vine: "${item.firstTwoWords}"](${item.vineSearchUrl})`,
                inline: false
              },
              { name: 'Links', value: `[🛒 Amazon Page](${item.dpUrl})`, inline: false }
            ],
            thumbnail: item.img_url ? { url: item.img_url } : undefined,
            timestamp: new Date().toISOString()
          }
        ]
      },
      { timeout: 8000, httpsAgent: notificationHttpsAgent }
    );
  } catch (error) {
    console.error('[Discord Webhook Error]:', error.message);
  }
}

// ============================================================================
// EXPRESS/LOCAL WEBSOCKET STATE
// ============================================================================
let uvStatus = 'Disconnected';
let vhStatus = VH_FORCE_DISABLED ? 'Disabled (UV-only process mode)' : 'Disabled';
let svClient = null;
let orderCoordinator = null;
let svStatus = {
  source: 'SV',
  enabled: Boolean(config.enableSV),
  state: config.enableSV ? 'starting' : 'disabled',
  authenticated: false,
  connected: false,
  channelReady: false,
  historyEnabled: false,
  catalogueEnabled: false,
  gapRecoveryEnabled: false
};

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const localWss = new WebSocket.Server({ server, path: '/ws-feed' });

const LIVE_DELIVERY_SAMPLE_LIMIT = 256;
const LIVE_TIMING_START = Symbol('liveDeliveryStartedHrNs');
const liveDeliverySamplesUs = { UV: [], VH: [], SV: [], ALL: [] };
let liveDeliverySequence = 0;

function appendLiveDeliverySample(source, microseconds) {
  if (!Number.isFinite(microseconds) || microseconds < 0) return;
  const normalizedSource = normalizeSourceList(source)[0] || 'UV';
  for (const key of [normalizedSource, 'ALL']) {
    const samples = liveDeliverySamplesUs[key];
    samples.push(microseconds);
    if (samples.length > LIVE_DELIVERY_SAMPLE_LIMIT) {
      samples.splice(0, samples.length - LIVE_DELIVERY_SAMPLE_LIMIT);
    }
  }
}

function summarizeLiveDeliverySamples(samples) {
  if (!samples.length) {
    return { count: 0, lastUs: null, p50Us: null, p95Us: null, maxUs: null };
  }
  const sorted = [...samples].sort((left, right) => left - right);
  const percentile = value => sorted[Math.max(0, Math.ceil(sorted.length * value) - 1)];
  return {
    count: samples.length,
    lastUs: samples[samples.length - 1],
    p50Us: percentile(0.5),
    p95Us: percentile(0.95),
    maxUs: sorted[sorted.length - 1]
  };
}

function publicLiveDeliveryPerformance() {
  return {
    sampleLimit: LIVE_DELIVERY_SAMPLE_LIMIT,
    unit: 'microseconds',
    receiveToBroadcast: {
      all: summarizeLiveDeliverySamples(liveDeliverySamplesUs.ALL),
      UV: summarizeLiveDeliverySamples(liveDeliverySamplesUs.UV),
      VH: summarizeLiveDeliverySamples(liveDeliverySamplesUs.VH),
      SV: summarizeLiveDeliverySamples(liveDeliverySamplesUs.SV)
    }
  };
}

function startLiveDeliveryTiming(source, eventType) {
  return {
    source: normalizeSourceList(source)[0] || 'UV',
    eventType: String(eventType || 'live').slice(0, 80),
    receivedAtMs: Date.now(),
    startedHrNs: process.hrtime.bigint()
  };
}

function finishLiveDeliveryTiming(timing) {
  if (!timing || typeof timing.startedHrNs !== 'bigint') return null;
  const elapsedUs = Math.max(0, Number((process.hrtime.bigint() - timing.startedHrNs) / 1000n));
  const meta = {
    sequence: ++liveDeliverySequence,
    source: timing.source,
    eventType: timing.eventType,
    serverReceivedAtMs: timing.receivedAtMs,
    serverBroadcastAtMs: Date.now(),
    serverProcessingUs: elapsedUs
  };
  // Keep the monotonic start private and non-enumerable: JSON delivery carries
  // only safe numeric diagnostics, while the server can include stringify and
  // client.send queueing in its own complete receive-to-broadcast sample.
  Object.defineProperty(meta, LIVE_TIMING_START, { value: timing.startedHrNs });
  return meta;
}

function broadcastLocal(type, data, meta = null) {
  const envelope = { type, data };
  if (meta) envelope.meta = meta;
  const message = JSON.stringify(envelope);
  localWss.clients.forEach(client => {
    // The PC order companion uses this localhost-only WebSocket server but is
    // isolated from dashboard feed traffic and receives signed order envelopes
    // only through OrderCoordinator.
    if (client.vdhRole === 'order-agent') return;
    if (client.readyState === WebSocket.OPEN) client.send(message);
  });
  const startedHrNs = meta?.[LIVE_TIMING_START];
  if (typeof startedHrNs === 'bigint') {
    const elapsedUs = Math.max(0, Number((process.hrtime.bigint() - startedHrNs) / 1000n));
    appendLiveDeliverySample(meta.source, elapsedUs);
  }
}

function addActivity(type, data) {
  const entry = { type, data, date: new Date().toISOString() };
  activityLog.unshift(entry);
  if (activityLog.length > 1000) activityLog.length = 1000;
  broadcastLocal('activity', entry);
  if (!livePersistence?.prependActivity(entry)) saveJSON(ACTIVITY_FILE, activityLog);
}

function handleOrderCoordinatorEvent(eventType, eventData) {
  const status = orderCoordinator?.publicStatus() || null;
  broadcastLocal('order_agent_event', { eventType, data: eventData, status });
  if (eventType === 'rules_updated' || eventType === 'watches_updated') return;
  if (eventType.startsWith('watch_')) {
    addActivity(`order_${eventType}`, eventData || {});
    return;
  }
  if (eventType.startsWith('safety_')) {
    addActivity(`order_${eventType}`, {
      title: eventData?.circuitBreaker?.message || (eventData?.manualPaused ? 'Automatic ordering paused' : 'Order safety updated'),
      asin: eventData?.circuitBreaker?.asin || null
    });
    return;
  }
  if (eventType === 'job_created') {
    addActivity('order_job_created', eventData);
    return;
  }
  if (eventType === 'job_result') {
    addActivity('order_job_result', eventData?.job || eventData);
    return;
  }
  if (eventType === 'agent_connected' || eventType === 'agent_disconnected' || eventType === 'account_mismatch') {
    addActivity(`order_${eventType}`, {
      connected: Boolean(status?.connected),
      authenticated: Boolean(status?.authenticated),
      accountMatched: Boolean(status?.accountMatched),
      agentId: status?.agentId || null,
      lastError: status?.lastError || null
    });
  }
}

orderCoordinator = new OrderCoordinator({
  pairingFile: ORDER_AGENT_FILE,
  rulesFile: ORDER_RULES_FILE,
  jobsFile: ORDER_JOBS_FILE,
  watchesFile: ORDER_WATCHES_FILE,
  safetyFile: ORDER_SAFETY_FILE,
  loadJSON,
  saveJSON,
  // Ordering is bound only to SHA-256(customerId) learned from the locally
  // authenticated browser during signed PC pairing. Synthetic Hub/UV/VH
  // identity values are deliberately outside this trust boundary.
  onEvent: handleOrderCoordinatorEvent
});

function maybeDispatchAutomaticOrder(item, observation = {}) {
  if (!item || item.isHistoricalOnly) {
    return { ok: false, skipped: true, reason: 'item is not a fresh live observation' };
  }
  // Rule-specific hide/unavailable gates live in the coordinator after it has
  // first checked for an explicitly armed watch. That prevents stale RFY card
  // fields from suppressing a later isolated AFA/AI watch opportunity.
  return orderCoordinator.dispatchForLiveItem(item, observation);
}

function withOrderRuleMatch(item) {
  if (!item || typeof item !== 'object') return item;
  return { ...item, orderRuleMatch: orderCoordinator.explainRuleMatch(item) };
}

// ============================================================================
// INDEPENDENT UV/VH/SV HEALTH ALERTS
// ============================================================================
let feedHealthMonitorInterval = null;
let uvTokenHealthTimer = null;

function configuredUvTokenCheckIntervalMs() {
  return Math.max(3600000, Number(config.uvTokenCheckIntervalMs) || 21600000);
}

function publicFeedHealth() {
  const copy = record => ({
    feed: record.feed,
    status: record.status,
    reason: record.reason,
    incidentSince: record.incidentSince,
    activeIncident: record.activeIncident,
    alertedAt: record.alertedAt,
    lastHealthyAt: record.lastHealthyAt,
    recoveredAt: record.recoveredAt,
    lastTokenCheckAt: record.lastTokenCheckAt,
    lastTokenCheckStatus: record.lastTokenCheckStatus
  });

  return {
    UV: copy(feedHealth.UV),
    VH: copy(feedHealth.VH),
    SV: copy(feedHealth.SV),
    alertsEnabled: config.enableFeedHealthAlerts !== false,
    outageGraceMs: Math.max(30000, Number(config.feedOutageGraceMs) || 120000),
    uvTokenCheckIntervalMs: configuredUvTokenCheckIntervalMs()
  };
}

function persistAndBroadcastFeedHealth() {
  saveJSON(FEED_HEALTH_FILE, feedHealth);
  broadcastLocal('feed_health', publicFeedHealth());
}

function sendFeedHealthTelegram(feed, event, reason = '') {
  if (
    config.enableFeedHealthAlerts === false ||
    !config.enableTelegram ||
    !config.telegramToken ||
    !config.telegramChatId
  ) {
    return;
  }

  const name = feed === 'UV'
    ? 'Ultraviner (UV)'
    : feed === 'VH'
      ? 'VHelper (VH)'
      : 'SmartViner (SV)';
  if (event === 'recovered') {
    sendTelegramTextOnly(
      `✅ <b>${name} feed restored</b>\n\nReal-time monitoring is connected again.`
    );
    return;
  }

  sendTelegramTextOnly(
    `🚨 <b>${name} feed problem</b>\n\n${escapeHtml(reason || 'Connection unavailable.')}\n\n` +
      'Live alerts from this source may be interrupted. Check Vine Drop Hub diagnostics.'
  );
}

function noteFeedProblem(feed, reason, incidentKey, immediate = false) {
  const state = feedHealth[feed];
  if (!state) return;

  const now = Date.now();
  const nowIso = new Date(now).toISOString();
  const safeReason = String(reason || 'Connection unavailable').replace(/\s+/g, ' ').slice(0, 500);
  const key = String(incidentKey || `${feed.toLowerCase()}-connectivity`).slice(0, 160);
  const before = JSON.stringify(state);
  let newlyActive = false;

  if (state.incidentKey !== key || state.status === 'healthy' || state.status === 'disabled') {
    state.status = 'checking';
    state.reason = safeReason;
    state.incidentKey = key;
    state.incidentSince = nowIso;
    state.activeIncident = false;
    state.alertedAt = null;
  } else {
    state.reason = safeReason;
    if (!state.incidentSince) state.incidentSince = nowIso;
  }

  const sinceMs = Date.parse(state.incidentSince) || now;
  const graceMs = Math.max(30000, Number(config.feedOutageGraceMs) || 120000);
  const alertDue = immediate || now - sinceMs >= graceMs;

  if (alertDue) {
    state.status = 'down';
    if (!state.activeIncident) {
      state.activeIncident = true;
      state.alertedAt = nowIso;
      newlyActive = true;
    }
  }

  // Persist the dedupe state before attempting Telegram delivery so a process
  // restart cannot resend the same active incident.
  if (before !== JSON.stringify(state)) persistAndBroadcastFeedHealth();
  if (newlyActive) {
    console.error(`[Health] ${feed} incident: ${safeReason}`);
    sendFeedHealthTelegram(feed, 'problem', safeReason);
    addActivity('feed_health_issue', { source: feed, reason: safeReason });
  }
}

function transitionActiveFeedIncident(feed, reason, incidentKey) {
  const state = feedHealth[feed];
  if (!state?.activeIncident) {
    noteFeedProblem(feed, reason, incidentKey);
    return;
  }

  const safeReason = String(reason || 'Connection unavailable').replace(/\s+/g, ' ').slice(0, 500);
  const key = String(incidentKey || `${feed.toLowerCase()}-connectivity`).slice(0, 160);
  if (state.reason === safeReason && state.incidentKey === key) return;
  state.reason = safeReason;
  state.incidentKey = key;
  state.status = 'down';
  persistAndBroadcastFeedHealth();
}

function reportVhFeedProblem(reason, incidentKey, immediate = false) {
  if (feedHealth.VH.activeIncident) {
    transitionActiveFeedIncident('VH', reason, incidentKey);
    return;
  }
  noteFeedProblem('VH', reason, incidentKey, immediate);
}

function markFeedHealthy(feed, detail = 'Connected') {
  const state = feedHealth[feed];
  if (!state) return;
  const nextReason = String(detail || 'Connected').slice(0, 500);
  if (
    state.status === 'healthy' &&
    !state.activeIncident &&
    state.reason === nextReason
  ) {
    return;
  }

  const nowIso = new Date().toISOString();
  const wasAlerted = state.activeIncident;
  state.status = 'healthy';
  state.reason = nextReason;
  state.incidentKey = '';
  state.incidentSince = null;
  state.activeIncident = false;
  state.alertedAt = null;
  state.lastHealthyAt = nowIso;
  state.recoveredAt = wasAlerted ? nowIso : state.recoveredAt;

  persistAndBroadcastFeedHealth();
  if (wasAlerted) {
    console.log(`[Health] ${feed} recovered.`);
    sendFeedHealthTelegram(feed, 'recovered');
    addActivity('feed_health_recovered', { source: feed });
  }
}

function markFeedDisabled(feed) {
  const state = feedHealth[feed];
  if (!state) return;
  if (state.status === 'disabled' && !state.activeIncident) return;

  state.status = 'disabled';
  state.reason = 'Disabled by configuration';
  state.incidentKey = '';
  state.incidentSince = null;
  state.activeIncident = false;
  state.alertedAt = null;
  persistAndBroadcastFeedHealth();
}

function uvLiveAlertObservedOnCurrentConnection() {
  const connectedAtMs = Date.parse(uvConnectedAt || '');
  const receivedAtMs = Date.parse(uvLastAlertReceivedAt || '');
  return Number.isFinite(connectedAtMs) &&
    Number.isFinite(receivedAtMs) &&
    receivedAtMs >= connectedAtMs;
}

function uvSessionHealthReason() {
  return uvLiveAlertObservedOnCurrentConnection()
    ? 'Plan/session authenticated; live-alert delivery observed on this connection'
    : 'Plan/session authenticated; live-alert delivery not yet observed on this connection';
}

function evaluateFeedHealth() {
  if (!config.enableUV) {
    markFeedDisabled('UV');
  } else if (uvAuthenticated && uvWs?.readyState === WebSocket.OPEN) {
    markFeedHealthy('UV', uvSessionHealthReason());
  } else {
    const tokenIncident = feedHealth.UV.activeIncident &&
      feedHealth.UV.incidentKey.startsWith('uv-token:');
    if (!tokenIncident) {
      noteFeedProblem(
        'UV',
        uvStatus || 'WebSocket is not authenticated',
        `uv-connectivity:${sha256(config.token).slice(0, 12)}`
      );
    }
  }

  if (!isVhEnabled()) {
    markFeedDisabled('VH');
  } else if (vhDenied) {
    reportVhFeedProblem(
      vhDenial?.message || 'VHelper server denial is latched',
      'vh-server-denial'
    );
  } else if (isVhTransportHealthy()) {
    // Match the official 4.7.4 client's connectivity criterion: Socket.IO
    // "connect" reports the live feed open. Application events remain useful
    // evidence, but their absence is not grounds to destroy a healthy socket.
    markFeedHealthy(
      'VH',
      vhApplicationReady
        ? 'Socket.IO transport and VH application activity are ready'
        : 'Socket.IO transport connected; awaiting optional application activity'
    );
  } else {
    reportVhFeedProblem(
      vhStatus || 'VH transport is not ready',
      'vh-connectivity'
    );
  }

  if (!config.enableSV) {
    markFeedDisabled('SV');
  } else if (svStatus.connected && svStatus.channelReady && svStatus.state === 'healthy') {
    markFeedHealthy('SV', 'Private live-alert channel subscribed');
  } else {
    noteFeedProblem(
      'SV',
      svStatus.lastError || (svStatus.authenticated ? 'SmartViner live-alert channel is not ready' : 'SmartViner sign-in is required'),
      svStatus.authBlocked ? 'sv-auth' : svStatus.permissionDenied ? 'sv-permission' : 'sv-connectivity'
    );
  }
}

function scheduleUvTokenHealthCheck(delayMs) {
  if (uvTokenHealthTimer) clearTimeout(uvTokenHealthTimer);
  const delay = Math.max(30000, Number(delayMs) || 60000);
  uvTokenHealthTimer = setTimeout(async () => {
    uvTokenHealthTimer = null;
    try {
      await runConfiguredUvTokenHealthCheck();
    } catch (error) {
      console.error('[UV Health] Token check error:', error.message);
    } finally {
      scheduleUvTokenHealthCheck(configuredUvTokenCheckIntervalMs());
    }
  }, delay);
  uvTokenHealthTimer.unref?.();
}

function nextUvTokenHealthCheckDelayMs() {
  const interval = configuredUvTokenCheckIntervalMs();
  const lastCheckMs = Date.parse(feedHealth.UV.lastTokenCheckAt || '');
  const now = Date.now();
  if (!Number.isFinite(lastCheckMs) || lastCheckMs > now + 300000) return interval;

  const remaining = lastCheckMs + interval - now;
  // If the check became overdue while the process was stopped, allow normal
  // feed authentication to settle before making the single catch-up request.
  return remaining > 0 ? remaining : 300000;
}

function startFeedHealthMonitor() {
  if (feedHealthMonitorInterval) clearInterval(feedHealthMonitorInterval);
  evaluateFeedHealth();
  feedHealthMonitorInterval = setInterval(evaluateFeedHealth, 30000);
  feedHealthMonitorInterval.unref?.();
  scheduleUvTokenHealthCheck(nextUvTokenHealthCheckDelayMs());
}

function stopFeedHealthMonitor() {
  if (feedHealthMonitorInterval) clearInterval(feedHealthMonitorInterval);
  if (uvTokenHealthTimer) clearTimeout(uvTokenHealthTimer);
  feedHealthMonitorInterval = null;
  uvTokenHealthTimer = null;
}

function notifyLiveItem(item) {
  if (!item || item.isHide || item.isHiddenManual) return false;
  if (wasRecentlyNotified(item.asin)) return false;

  const notifiedAtMs = markNotified(item.asin);
  // Both outbound requests start before any persistence message is posted.
  sendTelegramNotification(item);
  void sendDiscordWebhook(item);
  if (!livePersistence?.setNotified(item.asin, notifiedAtMs, notificationDedupeTtlMs())) {
    persistNotified();
  }
  return true;
}

function isAllowedLocalWebSocketOrigin(originValue) {
  const origin = String(originValue || '').trim();
  if (!origin) return true; // Preserve local non-browser administration clients.
  if (/^http:\/\/(?:127\.0\.0\.1|localhost):[0-9]{2,5}$/i.test(origin)) return true;
  if (/^http:\/\/\[::1\]:[0-9]{2,5}$/i.test(origin)) return true;
  return /^chrome-extension:\/\/[a-p]{32}$/i.test(origin);
}

localWss.on('connection', (socket, request) => {
  if (!isAllowedLocalWebSocketOrigin(request?.headers?.origin)) {
    try { socket.close(1008, 'Local dashboard or companion origin required'); } catch (_) {}
    return;
  }
  let role = 'dashboard';
  try {
    const url = new URL(request?.url || '/ws-feed', 'http://127.0.0.1');
    if (url.searchParams.get('role') === 'order-agent') role = 'order-agent';
  } catch (_) {}
  socket.vdhRole = role;

  if (role === 'order-agent') {
    orderCoordinator.attachSocket(socket);
    socket.on('message', message => {
      const outcome = orderCoordinator.handleSocketMessage(socket, message);
      if (!outcome?.ok && outcome?.error && socket.readyState === WebSocket.OPEN) {
        // Invalid signatures/authentication close inside the coordinator. Other
        // bounded protocol errors receive no sensitive diagnostic payload.
        console.warn('[Order Agent] Ignored companion message:', outcome.error);
      }
    });
    socket.on('close', (_code, reason) => {
      orderCoordinator.detachSocket(socket, reason?.toString?.() || 'connection closed');
    });
    socket.on('error', error => {
      orderCoordinator.detachSocket(socket, error?.message || 'connection error');
    });
    return;
  }

  socket.send(
    JSON.stringify({
      type: 'init',
      data: {
        status: { uvStatus, vhStatus, svStatus },
        feedHealth: publicFeedHealth(),
        itemsCount: allItems.filter(isLiveItem).length,
        keywords,
        pinnedAsins: [...pinnedAsins],
        dismissedPriorityAsins: [...dismissedPriorityAsins],
        hiddenAsins: [...hiddenAsins],
        uvProfile: publicUvProfile(),
        orderAgent: orderCoordinator.publicStatus(),
        orderRules: orderCoordinator.publicRules(),
        orderWatches: orderCoordinator.publicWatches(500),
        orderSafety: orderCoordinator.publicSafety(),
        config: {
          domain: config.domain,
          countryCode: config.countryCode,
          enableUV: config.enableUV,
          enableVH: config.enableVH,
          enableSV: config.enableSV,
          vhLoadHistory: false,
          effectiveVHEnabled: isVhEnabled(),
          vhForceDisabled: VH_FORCE_DISABLED,
          hasToken: Boolean(config.token),
          minPriorityPrice: config.minPriorityPrice,
          priorityCategoryIds: config.priorityCategoryIds,
          enableFeedHealthAlerts: config.enableFeedHealthAlerts !== false,
          uvTokenCheckIntervalMs: config.uvTokenCheckIntervalMs,
          feedOutageGraceMs: config.feedOutageGraceMs,
          enableTelegram: config.enableTelegram,
          hasTelegramToken: Boolean(config.telegramToken),
          telegramChatId: config.telegramChatId,
          hasWebhook: Boolean(config.discordWebhook)
        }
      }
    })
  );
});

// ============================================================================
// UNIFIED ITEM INGESTION
// ============================================================================
// Only the authenticated SmartViner client's private-channel callback holds
// this capability. HTTP/test routes cannot label arbitrary payloads as SV.
const SV_LIVE_INGRESS = Symbol('authenticated SmartViner private-channel ingress');

function ingestItem(raw, source = 'UV', eventType = 'drop', fallbackQueue = null, liveTiming = null, ingress = null) {
  if (!raw) return null;
  source = normalizeSourceList(source)[0];
  if (!source) return null;
  if (source === 'SV' && ingress !== SV_LIVE_INGRESS) return null;

  const flattened = raw.details ? { ...raw, ...raw.details } : { ...raw };
  const normalizeQueueIds = value => [
    ...new Set(
      (Array.isArray(value) ? value : value ? [value] : [])
        .map(id => String(id || '').trim())
        .filter(Boolean)
    )
  ];
  const incomingUvAlertQueueIds = normalizeQueueIds(
    flattened.uvAlertQueueIds || flattened.uv_alert_queue_ids
  );
  const asin = flattened.asin || flattened.parentAsin || raw.asin || raw.parentAsin;
  if (!asin || asin === 'N/A') return null;

  const nowMs = Date.now();
  // This gate precedes card lookup, activity, local broadcast, sound, Telegram,
  // and Discord. A later confirmation from any genuine live source updates only
  // the private tombstone and cannot resurrect or notify the cleared ASIN.
  if (suppressFromClearedItemMemory(asin, source, nowMs)) return null;

  const existingIndex = allItems.findIndex(item => item.asin === asin);
  const nowIso = new Date(nowMs).toISOString();
  const isBackfill = BACKFILL_EVENT_TYPES.has(eventType);

  const sourceTime = parseItemTime(flattened);
  const addedMs = isBackfill && sourceTime != null ? sourceTime : nowMs;
  const addedIso = new Date(addedMs).toISOString();

  const pick = (incoming, previous) => {
    const empty = value =>
      value === undefined ||
      value === null ||
      value === '' ||
      value === 'N/A' ||
      value === 'Unknown Product';

    if (isBackfill) {
      return !empty(previous) ? previous : !empty(incoming) ? incoming : previous;
    }
    return !empty(incoming) ? incoming : previous;
  };

  const queueClassification = classifyItemQueue(flattened, eventType, fallbackQueue);
  const queue = queueClassification.queue;
  const incomingAlertOrigin = classifyItemAlertOrigin(flattened, eventType, source, !isBackfill);
  const previous = existingIndex >= 0 ? allItems[existingIndex] : null;
  const rawTitle = flattened.title || flattened.name || previous?.title || 'Unknown Product';
  const title = decodeHtmlEntities(rawTitle).trim();
  const firstTwoWords = getFirstTwoWords(title);
  const vineSearchUrl = getTwoWordSearchUrl(title, config.domain);
  const dpUrl = `https://www.${config.domain}/dp/${asin}`;

  const price = flattened.price ?? previous?.price ?? 'N/A';
  const etv = flattened.etv ?? flattened.price ?? previous?.etv ?? 'N/A';
  const etvMin = flattened.etv_min ?? flattened.etv ?? previous?.etv_min ?? null;
  const etvMax = flattened.etv_max ?? flattened.etv ?? previous?.etv_max ?? null;
  const isZeroEtv =
    [etv, etvMin].some(value => value !== null && value !== 'N/A' && Number(value) === 0) ||
    Boolean(previous?.isZeroEtv);

  const imgUrl =
    flattened.img_url ||
    flattened.imageUrl ||
    flattened.img ||
    flattened.thumbnail ||
    previous?.img_url ||
    null;

  const rawAdditionalImages =
    flattened.additional_img ?? flattened.images ?? previous?.additional_img ?? [];
  const additionalImages = Array.isArray(rawAdditionalImages)
    ? rawAdditionalImages
    : rawAdditionalImages
      ? [rawAdditionalImages]
      : [];
  const brand =
    flattened.brand || flattened.byLine || flattened.seller || previous?.brand || 'Unknown';
  const variants = sanitizeRecommendationMetadata(
    flattened.variants ?? previous?.variants ?? []
  );
  const unavailable = parseBoolean(
    flattened.unavailable,
    parseBoolean(previous?.unavailable, false)
  );
  const limited = parseBoolean(flattened.limited, parseBoolean(previous?.limited, false));
  const coupon = flattened.coupon || previous?.coupon || '';
  const discount = flattened.discount || previous?.discount || '';
  const stars = flattened.stars || previous?.stars || '';
  const reviewers = flattened.reviewers || previous?.reviewers || '';
  const orderSuccess = flattened.order_success ?? flattened.orderSuccess ?? previous?.order_success ?? 0;
  const orderFailed = flattened.order_failed ?? flattened.orderFailed ?? previous?.order_failed ?? 0;
  // UV 26.9.38 adds the live `ordersInProgress` demand signal. VH cannot
  // overwrite it; a missing UV value retains the last UV observation.
  const ordersInProgress =
    source === 'UV'
      ? normalizeUvOrdersInProgress(
          flattened.ordersInProgress ?? flattened.orders_in_progress,
          previous?.ordersInProgress ?? 0
        )
      : normalizeUvOrdersInProgress(previous?.ordersInProgress, 0);
  const enrollmentGuid =
    flattened.enrollmentGuid ?? flattened.enrollment_guid ?? previous?.enrollmentGuid ?? null;
  // Persist only the enrollment component. A full RFY recommendation ID embeds
  // the Amazon customer ID and is reconstructed transiently by the paired PC.
  const incomingRecommendationGuid = extractEnrollmentGuid(flattened) || null;
  const recommendationGuid =
    incomingRecommendationGuid ||
    extractEnrollmentGuid(enrollmentGuid) ||
    extractEnrollmentGuid(previous?.recommendation) ||
    null;
  const isParentAsin = parseBoolean(
    flattened.isParentAsin ?? flattened.is_parent_asin,
    parseBoolean(previous?.isParentAsin, false)
  );
  const isPreRelease = parseBoolean(
    flattened.isPreRelease ?? flattened.is_pre_release,
    parseBoolean(previous?.isPreRelease, false)
  );
  // A watched AFA/AI dispatch receives this isolated one-event payload instead
  // of the merged card. Nothing below falls back to a historical RFY record,
  // especially not enrollment/recommendation metadata.
  const liveEventOrderItem = {
    asin,
    title: decodeHtmlEntities(flattened.title || flattened.name || 'Unknown Product').trim(),
    brand: flattened.brand || flattened.byLine || flattened.seller || null,
    queue,
    enrollmentGuid: incomingRecommendationGuid,
    isParentAsin: parseBoolean(flattened.isParentAsin ?? flattened.is_parent_asin, false),
    isPreRelease: parseBoolean(flattened.isPreRelease ?? flattened.is_pre_release, false),
    price: flattened.price ?? null,
    etv: flattened.etv ?? null,
    img_url: flattened.img_url || flattened.imageUrl || flattened.img || flattened.thumbnail || null,
    liveSources: [source],
    firstDiscoveredMs: nowMs,
    unavailable: parseBoolean(flattened.unavailable, false)
  };
  const reason = flattened.reason ?? flattened.removal_reason ?? previous?.reason ?? null;
  const tier = flattened.tier ?? flattened.vine_tier ?? previous?.tier ?? null;
  const vhServerDate = flattened.vhServerDate ?? previous?.vhServerDate ?? null;
  const vhDateAdded = flattened.dateAdded ?? flattened.date_added_server ?? previous?.vhDateAdded ?? null;
  const sourceEvent = flattened.sourceEvent ?? flattened.source_event ?? eventType;
  const incomingSvPublishedAtMs = (() => {
    if (source !== 'SV' || flattened.svPublishedAtMs == null || flattened.svPublishedAtMs === '') return null;
    const value = Number(flattened.svPublishedAtMs);
    return Number.isFinite(value) && value > 0 ? value : null;
  })();
  const incomingCategoryId = extractUvCategoryId(flattened, source, null);
  const categoryId = extractUvCategoryId(flattened, source, previous?.categoryId);
  const category = getUvCategory(categoryId);
  const categoryName = category?.name || previous?.categoryName || null;
  const categoryEmoji = category?.emoji || previous?.categoryEmoji || null;
  const categorySource = incomingCategoryId ? 'UV' : previous?.categorySource || null;
  const categoryObservedAt = incomingCategoryId
    ? nowIso
    : previous?.categoryObservedAt || null;

  const matches = checkKeywordMatches(title, price, etv, categoryId);
  const isPinned = pinnedAsins.has(asin);
  const isPriorityDismissed = dismissedPriorityAsins.has(asin);
  const isHiddenManual = hiddenAsins.has(asin);

  if (existingIndex !== -1) {
    const existing = allItems[existingIndex];
    const mergeDecision = liveMergeDecision(existing, source, isBackfill);
    const {
      previousLiveSources,
      liveSources,
      hadLiveBefore,
      promotedFromBackfill,
      crossFeedConfirmation
    } = mergeDecision;
    const observedSources = appendSource(
      existing.observedSources?.length ? existing.observedSources : existing.sources,
      source
    );
    const historySources = isBackfill
      ? appendSource(existing.historySources, source)
      : normalizeSourceList(existing.historySources);
    const resolvedQueue = resolveMergedQueue(
      existing,
      queueClassification,
      source,
      nowIso,
      isBackfill
    );
    const resolvedAlertOrigin = resolveMergedAlertOrigin(existing, incomingAlertOrigin);

    // Source clocks are written once. Null legacy clocks are treated as
    // missing, and only genuine live events participate in the source race.
    const sourceObserved = {
      ...existing,
      // Include the just-appended live source as an arrival-order hint when
      // two independent feeds are received within the same millisecond.
      sources: liveSources,
      liveSources,
      ...observeSource(existing, source, { nowMs, live: !isBackfill })
    };
    const race = sourceRaceSummary(sourceObserved);
    const discoveredUvAt = sourceObserved.discovered_uv_at || null;
    const discoveredUvMs = sourceObserved.discovered_uv_ms ?? null;
    const discoveredVhAt = sourceObserved.discovered_vh_at || null;
    const discoveredVhMs = sourceObserved.discovered_vh_ms ?? null;
    const discoveredSvAt = sourceObserved.discovered_sv_at || null;
    const discoveredSvMs = sourceObserved.discovered_sv_ms ?? null;
    const liveUvAt = sourceObserved.live_uv_at || null;
    const liveUvMs = sourceObserved.live_uv_ms ?? null;
    const liveVhAt = sourceObserved.live_vh_at || null;
    const liveVhMs = sourceObserved.live_vh_ms ?? null;
    const liveSvAt = sourceObserved.live_sv_at || null;
    const liveSvMs = sourceObserved.live_sv_ms ?? null;
    const {
      firstDiscoveredBy,
      firstDiscoveredAt,
      firstDiscoveredMs,
      leadMs,
      sourceArrivalOrder,
      sourceLeadMs
    } = race;

    const mergedItem = {
      ...existing,
      asin,
      title: pick(title, existing.title),
      firstTwoWords: pick(firstTwoWords, existing.firstTwoWords),
      // `sources` remains the dashboard/API compatibility field, but now it
      // contains live detections only. Other observations are tracked apart.
      sources: liveSources,
      liveSources,
      observedSources,
      historySources,
      enrichmentSources: normalizeSourceList(existing.enrichmentSources),
      uvAlertQueueIds: normalizeQueueIds([
        ...normalizeQueueIds(existing.uvAlertQueueIds),
        ...incomingUvAlertQueueIds
      ]),
      uvQueue:
        !isBackfill && source === 'UV' ? queue : storedLiveQueueForSource(existing, 'UV'),
      vhQueue:
        !isBackfill && source === 'VH' ? queue : storedLiveQueueForSource(existing, 'VH'),
      svQueue:
        !isBackfill && source === 'SV' ? queue : storedLiveQueueForSource(existing, 'SV'),
      isHistoricalOnly: liveSources.length === 0,
      firstDiscoveredBy,
      firstDiscoveredAt,
      firstDiscoveredMs,
      discovered_uv_at: discoveredUvAt,
      discovered_uv_ms: discoveredUvMs,
      discovered_vh_at: discoveredVhAt,
      discovered_vh_ms: discoveredVhMs,
      discovered_sv_at: discoveredSvAt,
      discovered_sv_ms: discoveredSvMs,
      live_uv_at: liveUvAt,
      live_uv_ms: liveUvMs,
      live_vh_at: liveVhAt,
      live_vh_ms: liveVhMs,
      live_sv_at: liveSvAt,
      live_sv_ms: liveSvMs,
      leadMs,
      sourceArrivalOrder,
      sourceLeadMs,
      queue: resolvedQueue.queue,
      queueConfidence: resolvedQueue.confidence,
      queueRaw: resolvedQueue.raw,
      queueObservedFrom: resolvedQueue.source,
      queueObservedAt: resolvedQueue.observedAt,
      origin: resolvedAlertOrigin.origin,
      alertOrigin: resolvedAlertOrigin.origin,
      alertOrigins: resolvedAlertOrigin.origins,
      alertOriginConfidence: resolvedAlertOrigin.confidence,
      alertOriginRaw: resolvedAlertOrigin.raw,
      categoryId,
      categoryName,
      categoryEmoji,
      categorySource,
      categoryObservedAt,
      price: pick(price, existing.price),
      etv: pick(etv, existing.etv),
      etv_min: etvMin ?? existing.etv_min,
      etv_max: etvMax ?? existing.etv_max,
      isZeroEtv,
      img_url: pick(imgUrl, existing.img_url),
      additional_img: additionalImages?.length
        ? additionalImages
        : existing.additional_img || [],
      brand: pick(brand, existing.brand),
      variants:
        variants !== undefined && variants !== null && variants !== ''
          ? variants
          : existing.variants || [],
      unavailable,
      available: !unavailable,
      limited,
      coupon: pick(coupon, existing.coupon),
      discount: pick(discount, existing.discount),
      stars: pick(stars, existing.stars),
      reviewers: pick(reviewers, existing.reviewers),
      order_success: orderSuccess,
      order_failed: orderFailed,
      ordersInProgress,
      recommendation: pick(recommendationGuid, existing.recommendation),
      recommendationType: pick(
        flattened.recommendationType || flattened.recommendation_type || flattened.type,
        existing.recommendationType
      ),
      enrollmentGuid,
      enrollment_guid: enrollmentGuid,
      isParentAsin,
      is_parent_asin: isParentAsin,
      isPreRelease,
      is_pre_release: isPreRelease,
      variant_asin: flattened.variant_asin ?? existing.variant_asin ?? null,
      reason,
      tier,
      vhServerDate: source === 'VH' ? vhServerDate : existing.vhServerDate,
      vhDateAdded: source === 'VH' ? vhDateAdded : existing.vhDateAdded,
      vhSourceEvent: source === 'VH' ? sourceEvent : existing.vhSourceEvent,
      svSourceEvent: source === 'SV' ? sourceEvent : existing.svSourceEvent,
      svEventId: source === 'SV'
        ? (flattened.svEventId || existing.svEventId || null)
        : existing.svEventId,
      svPublishedAtMs: source === 'SV'
        ? (incomingSvPublishedAtMs ?? existing.svPublishedAtMs ?? null)
        : existing.svPublishedAtMs,
      isHighlight: matches.isHighlight,
      isPriceHighlight: matches.isPriceHighlight,
      isCategoryPriority: matches.isCategoryPriority,
      priorityReasons: matches.priorityReasons,
      isHide: matches.isHide,
      isBlur: matches.isBlur,
      isPinned,
      isPriorityDismissed,
      isHiddenManual,
      date_added: promotedFromBackfill ? nowIso : existing.date_added || addedIso,
      date_added_ms: promotedFromBackfill ? nowMs : existing.date_added_ms ?? addedMs,
      last_seen: nowIso,
      last_seen_ms: nowMs,
      last_live_event_at: !isBackfill ? nowIso : existing.last_live_event_at,
      last_live_event_ms: !isBackfill ? nowMs : existing.last_live_event_ms,
      last_updated_by: source,
      uv_event_at: flattened.uv_event_at || existing.uv_event_at,
      vineSearchUrl,
      dpUrl
    };

    upsertItemInMemory(mergedItem, existingIndex);

    if (!isBackfill) {
      // A later trustworthy UV↔VH cross-feed confirmation remains completely
      // silent, but may create the first broad-rule order attempt if enrichment
      // makes the merged card newly match and no automatic attempt exists.
      // Watches still take precedence. Queue/enrollment data for any such job
      // comes only from this current event, never from the merged card.
      const allowLaterRuleDispatch = !mergeDecision.notify &&
        crossFeedConfirmation &&
        ['UV', 'VH'].includes(source) &&
        previousLiveSources.some(previousSource =>
          ['UV', 'VH'].includes(previousSource) && previousSource !== source
        ) &&
        ['explicit', 'derived'].includes(queueClassification.confidence);
      maybeDispatchAutomaticOrder(mergedItem, {
        queue,
        confidence: queueClassification.confidence,
        observedAtMs: nowMs,
        source,
        isBackfill: false,
        watchOnly: !mergeDecision.notify,
        allowLaterRuleDispatch,
        feedUnavailableAdvisory: ['UV', 'VH'].includes(source),
        allowDelayedPriceCompletion: ['UV', 'VH'].includes(source),
        previousLiveSources,
        previousMergedItem: existing,
        liveEventItem: liveEventOrderItem
      });
      if (mergeDecision.notify) {
        // No persistence, timer, or full-array sort precedes live delivery.
        broadcastLocal('new_item', withOrderRuleMatch(mergedItem), finishLiveDeliveryTiming(liveTiming));
        notifyLiveItem(mergedItem);
        addActivity('new_item', {
          asin,
          title: mergedItem.title,
          source,
          queue: mergedItem.queue,
          price: mergedItem.price,
          etv: mergedItem.etv,
          firstDiscoveredBy: mergedItem.firstDiscoveredBy,
          alertOrigin: mergedItem.alertOrigin,
          alertOrigins: mergedItem.alertOrigins,
          promotedFromBackfill: true
        });
      } else {
        // Every later live source updates the same card and race clocks, but
        // does not produce another sound, Telegram message, or Discord message.
        broadcastLocal('update_item', withOrderRuleMatch(mergedItem), finishLiveDeliveryTiming(liveTiming));
        if (crossFeedConfirmation) {
          addActivity('source_confirmation', {
            asin,
            title: mergedItem.title,
            source,
            queue: mergedItem.queue,
            alertOrigin: mergedItem.alertOrigin,
            alertOrigins: mergedItem.alertOrigins,
            firstDiscoveredBy,
            leadMs,
            sourceArrivalOrder,
            sourceLeadMs
          });
        }
      }
    }

    persistItemUpsert(mergedItem);

    const leadText = leadMs != null ? ` | lead=${leadMs}ms (${firstDiscoveredBy})` : '';
    const modeText = isBackfill
      ? 'backfill/silent'
      : promotedFromBackfill
        ? 'promoted-to-live'
        : crossFeedConfirmation
          ? 'cross-feed-confirmation/silent'
          : 'live-merge';
    liveItemLog(
      `[Merged] [${liveSources.join('+') || 'HISTORY'}] [${mergedItem.queue}] ${asin}${leadText} ` +
        `(${modeText}) - ${mergedItem.title.slice(0, 60)}`
    );
    return mergedItem;
  }

  const firstDecision = liveMergeDecision(null, source, isBackfill);
  const firstObservation = observeSource({}, source, { nowMs, live: !isBackfill });
  const firstRace = sourceRaceSummary(firstObservation);

  const newItem = {
    asin,
    title,
    firstTwoWords,
    sources: firstDecision.liveSources,
    liveSources: firstDecision.liveSources,
    observedSources: [source],
    historySources: isBackfill ? [source] : [],
    enrichmentSources: [],
    uvAlertQueueIds: incomingUvAlertQueueIds,
    uvQueue: !isBackfill && source === 'UV' ? queue : null,
    vhQueue: !isBackfill && source === 'VH' ? queue : null,
    svQueue: !isBackfill && source === 'SV' ? queue : null,
    isHistoricalOnly: isBackfill,
    firstDiscoveredBy: isBackfill ? null : source,
    firstDiscoveredAt: isBackfill ? null : nowIso,
    firstDiscoveredMs: isBackfill ? null : nowMs,
    discovered_uv_at: firstObservation.discovered_uv_at || null,
    discovered_uv_ms: firstObservation.discovered_uv_ms ?? null,
    discovered_vh_at: firstObservation.discovered_vh_at || null,
    discovered_vh_ms: firstObservation.discovered_vh_ms ?? null,
    discovered_sv_at: firstObservation.discovered_sv_at || null,
    discovered_sv_ms: firstObservation.discovered_sv_ms ?? null,
    live_uv_at: firstObservation.live_uv_at || null,
    live_uv_ms: firstObservation.live_uv_ms ?? null,
    live_vh_at: firstObservation.live_vh_at || null,
    live_vh_ms: firstObservation.live_vh_ms ?? null,
    live_sv_at: firstObservation.live_sv_at || null,
    live_sv_ms: firstObservation.live_sv_ms ?? null,
    leadMs: firstRace.leadMs,
    sourceArrivalOrder: firstRace.sourceArrivalOrder,
    sourceLeadMs: firstRace.sourceLeadMs,
    queue,
    queueConfidence: queueClassification.confidence,
    queueRaw: queueClassification.raw,
    queueObservedFrom: source,
    queueObservedAt: nowIso,
    origin: incomingAlertOrigin.origin,
    alertOrigin: incomingAlertOrigin.origin,
    alertOrigins: normalizeAlertOriginList(incomingAlertOrigin.origin),
    alertOriginConfidence: incomingAlertOrigin.confidence,
    alertOriginRaw: incomingAlertOrigin.raw,
    categoryId,
    categoryName,
    categoryEmoji,
    categorySource,
    categoryObservedAt,
    price,
    etv,
    etv_min: etvMin,
    etv_max: etvMax,
    isZeroEtv,
    img_url: imgUrl,
    additional_img: additionalImages,
    brand,
    variants,
    unavailable,
    available: !unavailable,
    limited,
    coupon,
    discount,
    stars,
    reviewers,
    order_success: orderSuccess,
    order_failed: orderFailed,
    ordersInProgress,
    recommendation: recommendationGuid,
    recommendationType:
      flattened.recommendationType || flattened.recommendation_type || flattened.type || null,
    enrollmentGuid,
    enrollment_guid: enrollmentGuid,
    isParentAsin,
    is_parent_asin: isParentAsin,
    isPreRelease,
    is_pre_release: isPreRelease,
    variant_asin: flattened.variant_asin ?? null,
    reason,
    tier,
    vhServerDate: source === 'VH' ? vhServerDate : null,
    vhDateAdded: source === 'VH' ? vhDateAdded : null,
    vhSourceEvent: source === 'VH' ? sourceEvent : null,
    svSourceEvent: source === 'SV' ? sourceEvent : null,
    svEventId: source === 'SV' ? (flattened.svEventId || null) : null,
    svPublishedAtMs: incomingSvPublishedAtMs,
    hashtagCount: flattened.hashtagCount,
    isHighlight: matches.isHighlight,
    isPriceHighlight: matches.isPriceHighlight,
    isCategoryPriority: matches.isCategoryPriority,
    priorityReasons: matches.priorityReasons,
    isHide: matches.isHide,
    isBlur: matches.isBlur,
    isPinned,
    isPriorityDismissed,
    isHiddenManual,
    date_added: addedIso,
    date_added_ms: addedMs,
    last_seen: nowIso,
    last_seen_ms: nowMs,
    last_live_event_at: !isBackfill ? nowIso : null,
    last_live_event_ms: !isBackfill ? nowMs : null,
    last_updated_by: source,
    uv_event_at: flattened.uv_event_at || null,
    vineSearchUrl,
    dpUrl
  };

  upsertItemInMemory(newItem, existingIndex);

  if (firstDecision.notify) {
    // Dispatch a matching signed PC job immediately; card rendering,
    // notifications, and persistence stay off the critical order path.
    maybeDispatchAutomaticOrder(newItem, {
      queue,
      confidence: queueClassification.confidence,
      observedAtMs: nowMs,
      source,
      isBackfill: false,
      watchOnly: false,
      feedUnavailableAdvisory: ['UV', 'VH'].includes(source),
      allowDelayedPriceCompletion: ['UV', 'VH'].includes(source),
      liveEventItem: liveEventOrderItem
    });
    // Dashboard and outbound notification requests begin immediately. The
    // persistence worker receives its delta only after those sends start.
    broadcastLocal('new_item', withOrderRuleMatch(newItem), finishLiveDeliveryTiming(liveTiming));
    notifyLiveItem(newItem);
    addActivity('new_item', {
      asin,
      title,
      source,
      queue,
      alertOrigin: newItem.alertOrigin,
      alertOrigins: newItem.alertOrigins,
      price,
      etv,
      firstDiscoveredBy: source
    });
    liveItemLog(`[New Drop] [${source}] [${queue}] ${asin} - ${title.slice(0, 70)}`);
  } else {
    liveItemLog(`[Backfill] [${source}] [${queue}] ${asin} (silent)`);
  }

  // If this ASIN's tombstone expired at the ingestion gate, genuine live
  // delivery above already started. Persisting its removal now cannot add alert
  // latency and prevents the stale entry from lingering on disk.
  if (clearedItemMemoryNeedsPersistence) persistClearedItemMemory();
  persistItemUpsert(newItem);
  return newItem;
}

async function initializeSmartViner() {
  if (svClient) return svClient;
  svClient = new SmartVinerClient({
    axios,
    WebSocket,
    httpsAgent: svHttpsProxyAgent,
    loadAuth: () => loadJSON(SV_AUTH_FILE, null),
    saveAuth: value => {
      if (!saveJSON(SV_AUTH_FILE, value, { sensitive: true, mode: 0o600 })) {
        throw new Error('Could not save isolated SmartViner session state');
      }
    },
    // Fail closed: SmartViner may never inherit the app's default route. Its
    // dedicated destination-locked proxy is mandatory whenever it is enabled.
    isEnabled: () => Boolean(config.enableSV && svHttpsProxyAgent),
    logger: console
  });
  svClient.on('status', status => {
    svStatus = {
      ...status,
      configuredEnabled: Boolean(config.enableSV),
      egressReady: Boolean(svHttpsProxyAgent),
      state: config.enableSV && !svHttpsProxyAgent ? 'egress_unavailable' : status.state,
      lastError: config.enableSV && !svHttpsProxyAgent
        ? 'Dedicated SmartViner egress proxy is unavailable'
        : status.lastError
    };
    broadcastLocal('sv_status', svStatus);
  });
  svClient.on('item', (item, meta = {}) => {
    // Defense in depth: even a future client regression cannot promote a
    // personalized RFY frame into Hub storage or notifications.
    const eventType = String(meta.eventType || item.svSourceEvent || '').slice(0, 80);
    if (eventType !== 'NewGlobalItemDiscovered') return;
    ingestItem(
      item,
      'SV',
      eventType,
      item.queueType || null,
      startLiveDeliveryTiming('SV', eventType),
      SV_LIVE_INGRESS
    );
  });
  try {
    await svClient.initialize();
  } catch (error) {
    svStatus = {
      ...svStatus,
      configuredEnabled: Boolean(config.enableSV),
      enabled: Boolean(config.enableSV),
      egressReady: Boolean(svHttpsProxyAgent),
      state: 'error',
      lastError: String(error?.message || 'SmartViner initialization failed').slice(0, 500)
    };
    console.error('[SV] Initialization failed:', svStatus.lastError);
    broadcastLocal('sv_status', svStatus);
  }
  return svClient;
}

// Official Ultraviner treats alertDetail/pageData as enrichment only. This
// function never inserts a new item and never stamps a live discovery clock.
function applyUvAlertDetail(raw, messageType = 'alertDetail') {
  const detail = raw?.details ? { ...raw, ...raw.details } : { ...raw };
  const asin = detail.asin || detail.parentAsin;
  if (!asin) return null;

  const index = allItems.findIndex(item => item.asin === asin);
  if (index === -1) {
    liveItemLog(`[UV DETAIL] Orphan ${messageType} ignored: ${asin}`);
    return null;
  }

  const existing = allItems[index];
  const liveSources = deriveLiveSources(existing);
  const observedSources = appendSource(
    existing.observedSources?.length ? existing.observedSources : existing.sources,
    'UV'
  );
  const enrichmentSources = appendSource(existing.enrichmentSources, 'UV');

  const hasDetailPrice =
    detail.price !== undefined && detail.price !== null && detail.price !== '' && detail.price !== 'N/A';
  const price = hasDetailPrice ? detail.price : existing.price;
  const etv = detail.etv ?? existing.etv;
  const incomingCategoryId = extractUvCategoryId(detail, 'UV', null);
  const categoryId = extractUvCategoryId(detail, 'UV', existing.categoryId);
  const category = getUvCategory(categoryId);
  const matches = checkKeywordMatches(existing.title, price, etv, categoryId);
  const hasEtv = etv != null && etv !== '' && etv !== 'N/A';
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const detailAlertOrigin = resolveMergedAlertOrigin(
    existing,
    classifyItemAlertOrigin(detail, messageType, 'UV', false)
  );

  const updated = {
    ...existing,
    // Detail messages enrich data but do not claim a UV live detection.
    sources: liveSources,
    liveSources,
    observedSources,
    enrichmentSources,
    origin: detailAlertOrigin.origin,
    alertOrigin: detailAlertOrigin.origin,
    alertOrigins: detailAlertOrigin.origins,
    alertOriginConfidence: detailAlertOrigin.confidence,
    alertOriginRaw: detailAlertOrigin.raw,
    isHistoricalOnly: liveSources.length === 0,
    categoryId,
    categoryName: category?.name || existing.categoryName || null,
    categoryEmoji: category?.emoji || existing.categoryEmoji || null,
    categorySource: incomingCategoryId ? 'UV' : existing.categorySource || null,
    categoryObservedAt: incomingCategoryId ? nowIso : existing.categoryObservedAt || null,
    recommendation: detail.recommendation ?? existing.recommendation,
    img_url: detail.imageUrl || detail.img_url || existing.img_url,
    additional_img:
      Array.isArray(detail.images) && detail.images.length
        ? detail.images
        : existing.additional_img,
    price,
    etv,
    etv_min: detail.etv !== undefined ? detail.etv : existing.etv_min,
    etv_max: detail.etv !== undefined ? detail.etv : existing.etv_max,
    isZeroEtv: (hasEtv && Number(etv) === 0) || existing.isZeroEtv,
    limited: detail.limited ?? existing.limited,
    seller: detail.seller ?? existing.seller,
    multiple_options: Array.isArray(detail.multiple_options)
      ? detail.multiple_options
      : existing.multiple_options,
    multiple_colors: Array.isArray(detail.multiple_colors)
      ? detail.multiple_colors
      : existing.multiple_colors,
    multiple_sizes: Array.isArray(detail.multiple_sizes)
      ? detail.multiple_sizes
      : existing.multiple_sizes,
    ordersInProgress: normalizeUvOrdersInProgress(
      detail.ordersInProgress ?? detail.orders_in_progress,
      existing.ordersInProgress ?? 0
    ),
    isParentAsin: detail.isParentAsin ?? existing.isParentAsin,
    isPreRelease: detail.isPreRelease ?? existing.isPreRelease,
    hashtagCount: detail.hashtagCount ?? existing.hashtagCount,
    isHighlight: matches.isHighlight,
    isPriceHighlight: matches.isPriceHighlight,
    isCategoryPriority: matches.isCategoryPriority,
    priorityReasons: matches.priorityReasons,
    isHide: matches.isHide,
    isBlur: matches.isBlur,
    last_seen: nowIso,
    last_seen_ms: nowMs,
    last_detail_at: nowIso,
    last_updated_by: 'UV_DETAIL'
  };

  // A price/ETV detail can complete only a memory-only permit created by this
  // ASIN's isolated UV/VH live event during the preceding 60 seconds. The
  // coordinator consumes the permit before one dispatch and never replays it.
  orderCoordinator.dispatchForDelayedPriceCompletion(updated, {
    asin,
    source: 'UV',
    eventType: messageType,
    receivedAtMs: nowMs,
    price: detail.price,
    etv: detail.etv
  });

  upsertItemInMemory(updated, index);
  broadcastLocal('update_item', withOrderRuleMatch(updated));
  persistItemUpsert(updated);
  liveItemLog(`[UV DETAIL] Enriched existing item: ${asin}`);
  return updated;
}

function extractUvProducts(message) {
  const data = message?.data;
  if (Array.isArray(data?.products)) return data.products;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data)) return data;
  if (data?.product) return [data.product];
  if (data?.item) return [data.item];
  if (data?.asin || data?.parentAsin) return [data];
  if (message?.asin || message?.parentAsin) return [message];
  return [];
}

// ============================================================================
// ULTRAVINER STREAM
// ============================================================================
let uvWs = null;
let uvPingInterval = null;
let uvIdentificationTimer = null;
let uvAuthenticationTimer = null;
let uvReidentifyTimer = null;
let uvGeneration = 0;
let uvAuthenticated = false;
let uvConnectedAt = null;
let uvLastFrameAt = null;
let uvLastAlertAt = null;
let uvLastAlertReceivedAt = null;
const uvRecentFrames = [];
const uvRetryController = new UvRetryController({
  getBaseDelayMs: () => config.uvReconnectDelayMs,
  getMaxDelayMs: () => config.uvReconnectMaxDelayMs,
  getJitterRatio: () => config.uvReconnectJitterRatio,
  onRetry: retry => {
    console.log(`[UV WS] Starting scheduled ${retry.reason} retry.`);
    connectUltraviner({ trigger: 'automatic-retry', allowTerminalReset: false });
  }
});

function clearUvTimers() {
  if (uvPingInterval) clearInterval(uvPingInterval);
  uvRetryController.cancelPending();
  if (uvIdentificationTimer) clearTimeout(uvIdentificationTimer);
  if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
  if (uvReidentifyTimer) clearTimeout(uvReidentifyTimer);
  uvPingInterval = null;
  uvIdentificationTimer = null;
  uvAuthenticationTimer = null;
  uvReidentifyTimer = null;
}

function destroyUvSocket() {
  if (!uvWs) return;
  try {
    uvWs.removeAllListeners();
    uvWs.terminate();
  } catch (_) {}
  uvWs = null;
}

function stopUltraviner(status = 'Disabled') {
  uvGeneration += 1;
  uvRetryController.blockTerminal(
    String(status).toLowerCase().includes('disabled') ? 'disabled' : 'stopped'
  );
  uvAuthenticated = false;
  clearUvTimers();
  destroyUvSocket();
  uvStatus = status;
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  if (!config.enableUV) markFeedDisabled('UV');
  console.log(`[UV WS] ${status}`);
}

function validateUvConfig() {
  const missing = [];
  if (!config.token) missing.push('token');
  if (!config.azUser) missing.push('azUser (new account Amazon customer ID or SHA-256 hash)');
  if (!uvProfile.device) missing.push('device');
  if (!uvProfile.selectedScreenId) missing.push('selected screen');
  if (!getUvQueues('Alert').length) missing.push('alert queue');
  if (missing.length) throw new Error(`Missing UV configuration: ${missing.join(', ')}`);
}

function effectiveUvIdentity() {
  const alertQueues = getUvQueues('Alert');
  const chatQueues = getUvQueues('Chat');
  return {
    device: uvProfile.device,
    azUserHash: sha256(config.azUser),
    selectedScreenId: uvProfile.selectedScreenId,
    alertQueueId: alertQueues[0]?.id || '',
    alertQueues: alertQueues.map(queue => ({ id: queue.id, name: queue.name || '' })),
    exploreQueue: effectiveUvExploreQueue(),
    chatQueues: chatQueues.map(queue => ({
      id: queue.id,
      selectedChatChannel: queue.selectedChatChannel || null
    })),
    displayName: config.displayName,
    domain: config.domain,
    userAgent: config.uvUserAgent
  };
}

function scheduleUvReconnect(generation, reason = 'transport-close') {
  if (
    generation !== uvGeneration ||
    uvRetryController.isTerminalBlocked() ||
    !config.enableUV
  ) {
    return false;
  }

  const useAuthenticationBackoff =
    reason === 'authentication-timeout' ||
    uvRetryController.diagnostics().authenticationTimeoutCount > 0;
  const scheduled = uvRetryController.schedule(reason, { useAuthenticationBackoff });
  if (!scheduled.scheduled) return false;

  const seconds = Math.max(1, Math.ceil(scheduled.delayMs / 1000));
  uvStatus = reason === 'authentication-timeout'
    ? `Authentication timeout; retrying in ${seconds}s`
    : `Disconnected; retrying in ${seconds}s`;
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  console.log(
    `[UV WS] ${reason} retry scheduled in ${scheduled.delayMs}ms ` +
      `(at ${scheduled.nextRetryAt}).`
  );
  return true;
}

function recordUvFrame(type, productCount) {
  uvLastFrameAt = new Date().toISOString();
  uvRecentFrames.unshift({ type, productCount, date: uvLastFrameAt });
  if (uvRecentFrames.length > 25) uvRecentFrames.length = 25;
}

function sendUvSocketMessage(payload, socket = uvWs) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  try {
    socket.send(JSON.stringify(payload));
    return true;
  } catch (error) {
    console.error(`[UV WS] Could not send ${payload?.type || 'frame'}:`, error.message);
    return false;
  }
}

function buildUvIdentificationPayload() {
  const identity = effectiveUvIdentity();
  const userAgent = config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent;
  return {
    type: 'identification',
    token: config.token,
    data: {
      device: identity.device,
      azUser: identity.azUserHash,
      userAgent,
      height: 912,
      width: 1707,
      isTouchDevice: false,
      syncBookmarks: true,
      syncScreens: config.uvSyncScreens !== false,
      syncSettings: UV_IDENTIFICATION_CAPABILITIES.syncSettings,
      deviceType: UV_IDENTIFICATION_CAPABILITIES.deviceType,
      version: UV_RUNTIME_VERSION,
      domain: config.domain,
      launcherVersion: UV_LAUNCHER_VERSION,
      launcherType: 'userscript',
      launcherPlatform: 'win32',
      displayName: config.displayName,
      selectedScreenId: identity.selectedScreenId,
      // UV sends every Alert and Chat queue across every screen, not only the
      // currently selected screen. Queue names/channels are part of routing.
      alertQueues: identity.alertQueues,
      chatQueues: identity.chatQueues,
      themeName: 'Dark',
      language: 'EN',
      tier: 'gold',
      isFirefox: false,
      isNearClaimLimit: UV_IDENTIFICATION_CAPABILITIES.isNearClaimLimit,
      isClaimLimitReached: UV_IDENTIFICATION_CAPABILITIES.isClaimLimitReached,
      supportsEnrollmentGate: UV_IDENTIFICATION_CAPABILITIES.supportsEnrollmentGate
    }
  };
}

function sendUvIdentification(socket = uvWs, reason = 'identification') {
  try {
    validateUvConfig();
  } catch (error) {
    console.warn(`[UV WS] ${reason} skipped: ${error.message}`);
    return false;
  }
  const payload = buildUvIdentificationPayload();
  const serialized = JSON.stringify(payload);
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  try {
    socket.send(serialized);
    console.log(
      `[UV WS] ${reason} queued (${Buffer.byteLength(serialized)} bytes, ` +
        `${payload.data.alertQueues.length} alert queue(s), ` +
        `${payload.data.chatQueues.length} chat queue(s)).`
    );
    return true;
  } catch (error) {
    console.error(`[UV WS] ${reason} write failed:`, error.message);
    return false;
  }
}

function scheduleUvReidentification(reason = 'layout re-identification') {
  if (!uvAuthenticated || !uvWs || uvWs.readyState !== WebSocket.OPEN) return;
  if (uvReidentifyTimer) clearTimeout(uvReidentifyTimer);
  uvReidentifyTimer = setTimeout(() => {
    uvReidentifyTimer = null;
    sendUvIdentification(uvWs, reason);
  }, 250);
  uvReidentifyTimer.unref?.();
}

function announceUvProfile(reason = 'updated') {
  persistUvProfile();
  broadcastLocal('uv_profile', publicUvProfile());
  addActivity('uv_profile_updated', {
    source: 'UV',
    reason,
    screens: uvProfile.screens.length,
    alertQueues: getUvQueues('Alert').length,
    chatQueues: getUvQueues('Chat').length
  });
}

function serializableUvScreen(screenId) {
  const screen = uvProfile.screens.find(candidate => candidate.id === screenId);
  if (!screen) return null;
  const queues = uvProfile.queues
    .filter(queue => queue.screenId === screenId)
    .sort((a, b) => a.order - b.order)
    .map(queue => {
      const copy = { ...queue };
      delete copy.forceRefresh;
      delete copy.categoryList;
      delete copy.subcategoryList;
      delete copy.page;
      delete copy.isAutoRefreshPaused;
      delete copy.modifiedDate;
      return copy;
    });
  return { screen: { ...screen, isTemporary: false }, queues };
}

function sendUvScreenUpdate(screenId, modifiedDate = null) {
  if (config.uvSyncScreens === false) return false;
  const payload = serializableUvScreen(screenId);
  if (!payload) return false;
  const date = safeIsoDate(modifiedDate || payload.screen.modifiedDate);
  payload.screen.modifiedDate = date;
  return sendUvSocketMessage({
    type: 'updateScreen',
    data: {
      modified_date: date,
      screen_id: screenId,
      payload
    }
  });
}

function requestUvScreen(screenId) {
  if (!screenId || config.uvSyncScreens === false) return false;
  return sendUvSocketMessage({ type: 'requestScreen', data: { screen_id: screenId } });
}

const pendingUvScreenRequests = new Set();

function handleUvScreensSummary(data) {
  if (config.uvSyncScreens === false) return;
  const summaries = Array.isArray(data?.screens) ? data.screens : [];
  const remoteIds = new Set(summaries.map(screen => String(screen.id || '')).filter(Boolean));
  const bootstrapReplacement = Boolean(uvProfile.bootstrapScreenId && summaries.length);

  pendingUvScreenRequests.clear();
  for (const summary of summaries) {
    const screenId = String(summary.id || '');
    if (!screenId) continue;
    const local = uvProfile.screens.find(screen => screen.id === screenId);
    const remoteModified = Date.parse(summary.modified_date || summary.modifiedDate || '');
    const localModified = Date.parse(local?.modifiedDate || '');

    // A just-created skeleton has synthetic dates and partial queues. Request
    // every real remote screen first instead of treating "created now" as a
    // reason to overwrite the account's established UV layout.
    if (
      bootstrapReplacement ||
      !local ||
      !Number.isFinite(localModified) ||
      remoteModified > localModified
    ) {
      pendingUvScreenRequests.add(screenId);
      requestUvScreen(screenId);
    } else if (!Number.isFinite(remoteModified) || localModified > remoteModified) {
      sendUvScreenUpdate(screenId, local.modifiedDate);
    }
  }

  if (!bootstrapReplacement) {
    for (const local of uvProfile.screens) {
      if (!remoteIds.has(local.id)) sendUvScreenUpdate(local.id, local.modifiedDate);
    }
  }

  if (!pendingUvScreenRequests.size) {
    uvProfile.initialSyncComplete = true;
    if (!summaries.length) uvProfile.bootstrapScreenId = null;
    persistUvProfile();
    broadcastLocal('uv_profile', publicUvProfile());
  }
}

function mergeUvScreenFromServer(data) {
  const packet = data?.payload && typeof data.payload === 'object' ? data.payload : data;
  const incoming = packet?.screen;
  if (!incoming?.id) return false;

  const modifiedDate = safeIsoDate(
    data?.modified_date || packet?.modified_date || incoming.modifiedDate || incoming.creationDate
  );
  const normalizedScreen = normalizeUvScreen(
    { ...incoming, modifiedDate, isTemporary: false },
    uvProfile.screens.length
  );
  const incomingQueues = Array.isArray(packet?.queues) ? packet.queues : [];
  const normalizedQueues = incomingQueues.map((queue, index) =>
    normalizeUvQueue(queue, normalizedScreen.id, index)
  );

  const bootstrapId = uvProfile.bootstrapScreenId;
  if (bootstrapId && bootstrapId !== normalizedScreen.id) {
    uvProfile.screens = uvProfile.screens.filter(screen => screen.id !== bootstrapId);
    uvProfile.queues = uvProfile.queues.filter(queue => queue.screenId !== bootstrapId);
  }
  if (bootstrapId) uvProfile.bootstrapScreenId = null;

  const screenIndex = uvProfile.screens.findIndex(screen => screen.id === normalizedScreen.id);
  if (screenIndex >= 0) uvProfile.screens[screenIndex] = normalizedScreen;
  else uvProfile.screens.push(normalizedScreen);
  uvProfile.queues = uvProfile.queues.filter(queue => queue.screenId !== normalizedScreen.id);
  uvProfile.queues.push(...normalizedQueues);

  if (!uvProfile.screens.some(screen => screen.id === uvProfile.selectedScreenId) || bootstrapId) {
    uvProfile.selectedScreenId = normalizedScreen.id;
  }
  pendingUvScreenRequests.delete(normalizedScreen.id);
  if (!pendingUvScreenRequests.size) uvProfile.initialSyncComplete = true;

  uvProfile = normalizeUvProfile(uvProfile, config);
  persistUvProfile();
  broadcastLocal('uv_profile', publicUvProfile());
  scheduleUvReidentification('screen-sync re-identification');
  console.log(
    `[UV Screens] Merged ${normalizedScreen.name} (${normalizedScreen.id}) with ` +
      `${normalizedQueues.length} queue(s).`
  );
  return true;
}

function deleteUvScreenFromServer(data) {
  const screenId = String(data?.screen_id || data?.screenId || '');
  if (!screenId || !uvProfile.screens.some(screen => screen.id === screenId)) return false;
  uvProfile.screens = uvProfile.screens.filter(screen => screen.id !== screenId);
  uvProfile.queues = uvProfile.queues.filter(queue => queue.screenId !== screenId);
  if (!uvProfile.screens.length) {
    const replacement = createDefaultUvProfile({ device: uvProfile.device });
    uvProfile = replacement;
  } else {
    if (uvProfile.selectedScreenId === screenId) {
      uvProfile.selectedScreenId = [...uvProfile.screens].sort((a, b) => a.order - b.order)[0].id;
    }
    uvProfile = normalizeUvProfile(uvProfile, config);
  }
  persistUvProfile();
  broadcastLocal('uv_profile', publicUvProfile());
  scheduleUvReidentification('screen-delete re-identification');
  return true;
}

function connectUltraviner({ trigger = 'requested', allowTerminalReset = true } = {}) {
  if (!config.enableUV) {
    stopUltraviner('Disabled');
    markFeedDisabled('UV');
    return;
  }

  try {
    validateUvConfig();
  } catch (error) {
    stopUltraviner(error.message);
    return;
  }

  if (uvRetryController.isTerminalBlocked() && !allowTerminalReset) {
    console.warn(
      `[UV WS] ${trigger} reconnect suppressed by terminal ${
        uvRetryController.diagnostics().terminalReason || 'authentication'
      } block.`
    );
    return false;
  }

  // Every explicit reconnect path cancels a pending cooldown before opening a
  // socket. Only user/startup/configuration paths may clear a terminal block;
  // automatic retry callbacks can never bypass invalidToken.
  uvGeneration += 1;
  const generation = uvGeneration;
  clearUvTimers();
  if (allowTerminalReset) uvRetryController.clearTerminalBlock();
  uvAuthenticated = false;
  destroyUvSocket();

  const userAgent = config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent;
  const wsUrl = 'wss://api.ultraviner.com/';
  const headers = {
    Origin: `https://www.${config.domain}`,
    'User-Agent': userAgent,
    'Accept-Language': 'en-CA,en;q=0.9,ar;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    Pragma: 'no-cache',
    'Cache-Control': 'no-cache'
  };

  uvStatus = 'Connecting...';
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  console.log(`[UV WS] Connecting to ${wsUrl} for ${config.domain}...`);

  try {
    // Once this socket receives an explicit authentication rejection, ignore
    // every later application frame that was already queued by the server.
    // In particular, an empty plan frame must not overwrite invalidToken with
    // a false Authenticated state while the graceful close is in flight.
    let terminalUvAuthFailure = false;
    let authenticationTimedOut = false;
    const socket = new WebSocket(wsUrl, {
      headers,
      handshakeTimeout: 15000,
      perMessageDeflate: true
    });
    uvWs = socket;

    socket.on('open', () => {
      if (generation !== uvGeneration || socket !== uvWs) return;

      uvConnectedAt = new Date().toISOString();
      uvStatus = 'Authenticating...';
      broadcastLocal('status', { uvStatus, vhStatus, svStatus });
      console.log('[UV WS] Socket open; waiting before identification.');

      const delay = Math.max(0, Number(config.uvIdentificationDelayMs) || 500);
      uvIdentificationTimer = setTimeout(() => {
        uvIdentificationTimer = null;
        if (generation !== uvGeneration || socket.readyState !== WebSocket.OPEN) return;

        const identity = effectiveUvIdentity();
        sendUvIdentification(socket, 'initial identification');
        console.log('[UV WS] Identification identity:', {
          device: identity.device,
          azUserHash: identity.azUserHash ? '<configured>' : '<missing>',
          selectedScreenId: identity.selectedScreenId,
          alertQueueCount: identity.alertQueues.length,
          chatQueueCount: identity.chatQueues.length,
          displayName: identity.displayName,
          domain: identity.domain,
          token: '<redacted>',
          tokenLength: String(config.token || '').length,
          tokenFingerprint: sha256(config.token).slice(0, 12)
        });

        const authenticationTimeout = Math.max(
          5000,
          Number(config.uvAuthenticationTimeoutMs) || 15000
        );
        uvAuthenticationTimer = setTimeout(() => {
          uvAuthenticationTimer = null;
          if (
            generation !== uvGeneration ||
            socket !== uvWs ||
            socket.readyState !== WebSocket.OPEN ||
            uvAuthenticated
          ) {
            return;
          }

          // A silent timeout is transient evidence, not a credential
          // rejection. Record it for bounded exponential cooldown recovery;
          // the close handler owns the one non-overlapping retry timer.
          authenticationTimedOut = true;
          uvRetryController.recordAuthenticationTimeout();
          uvStatus = 'Authentication timeout; preparing retry';
          broadcastLocal('status', { uvStatus, vhStatus, svStatus });
          const timeoutReason =
            `No connected/plan response within ${authenticationTimeout}ms. ` +
            'Verify the token, duplicate clients, VPN route, or device identity.';
          console.error(`[UV WS] ${timeoutReason}`);
          noteFeedProblem(
            'UV',
            timeoutReason,
            `uv-connectivity:${sha256(config.token).slice(0, 12)}`
          );
          try {
            socket.close(4001, 'authentication timeout');
          } catch (_) {}
        }, authenticationTimeout);
      }, delay);

      uvPingInterval = setInterval(() => {
        if (
          generation === uvGeneration &&
          socket === uvWs &&
          socket.readyState === WebSocket.OPEN
        ) {
          socket.send(JSON.stringify({ type: 'ping' }));
        }
      }, 30000);
    });

    socket.on('message', raw => {
      if (generation !== uvGeneration || socket !== uvWs) return;

      // One monotonic clock covers frame decoding, classification, item
      // normalization, in-memory merge, and preparation of each local send.
      const liveFrameTiming = startLiveDeliveryTiming('UV', 'unclassified');
      const text = raw.toString();
      if (text === 'ping') {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({ type: 'pong' }));
        }
        return;
      }
      if (text === 'pong') return;

      let message;
      try {
        message = JSON.parse(text);
      } catch (error) {
        console.error('[UV WS] Non-JSON frame:', text.slice(0, 500));
        return;
      }

      const { type, data } = message;
      liveFrameTiming.eventType = String(type || 'unclassified').slice(0, 80);
      if (type === 'ping') {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({ type: 'pong' }));
        }
        return;
      }
      if (type === 'pong') return;

      const products = extractUvProducts(message);
      recordUvFrame(type || '<missing>', products.length);
      liveItemLog(`[UV FRAME] type=${type || '<missing>'} products=${products.length}`);

      if (terminalUvAuthFailure) {
        console.warn(
          `[UV WS] Ignoring ${type || '<missing>'} received after terminal authentication rejection.`
        );
        return;
      }

      if (type === 'connected') {
        // The official client treats `connected` as a transport greeting, not
        // proof that identification succeeded. Keep the authentication timer
        // running until a non-empty plan or a real live frame arrives.
        uvAuthenticated = false;
        uvStatus = 'Connected; awaiting UV plan...';
        broadcastLocal('status', { uvStatus, vhStatus, svStatus });
        console.log('[UV WS] Transport greeting received; awaiting identification result.');
        return;
      }

      if (type === 'invalidToken') {
        terminalUvAuthFailure = true;
        if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
        uvAuthenticationTimer = null;
        uvRetryController.blockTerminal('invalid-token');
        uvAuthenticated = false;
        uvStatus = 'Invalid / Expired Token';
        broadcastLocal('status', { uvStatus, vhStatus, svStatus });
        console.error('[UV WS] invalidToken; automatic reconnect blocked.');
        noteFeedProblem(
          'UV',
          'Ultraviner rejected this WebSocket identification. The same token may still pass the separate search endpoint.',
          `uv-token:${sha256(config.token).slice(0, 12)}`,
          true
        );
        try {
          socket.close(1000, 'invalid token');
        } catch (_) {}
        return;
      }

      if (type === 'plan') {
        const plan = typeof data === 'string' ? data.trim() : '';
        if (!plan) {
          console.warn('[UV WS] Empty plan frame ignored; authentication is not proven.');
          return;
        }
        if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
        uvAuthenticationTimer = null;
        authenticationTimedOut = false;
        uvRetryController.resetAfterEvidence('non-empty-plan');
        uvAuthenticated = true;
        if (uvStatus !== 'Authenticated') {
          uvStatus = 'Authenticated';
          broadcastLocal('status', { uvStatus, vhStatus, svStatus });
        }
        markFeedHealthy('UV', uvSessionHealthReason());
        console.log(`[UV WS] Plan: ${plan}`);
        return;
      }

      if (type === 'screens') {
        handleUvScreensSummary(data);
        return;
      }
      if (type === 'screen') {
        mergeUvScreenFromServer(data);
        return;
      }
      if (type === 'deleteScreen') {
        deleteUvScreenFromServer(data);
        return;
      }

      if (UV_HOUSEKEEPING_TYPES.has(type)) return;

      if (UV_DETAIL_TYPES.has(type)) {
        if (!products.length) {
          liveItemLog(`[UV DETAIL] ${type} contained no products.`);
          return;
        }
        products.forEach(product => applyUvAlertDetail(product, type));
        return;
      }

      if (!UV_LIVE_ALERT_TYPES.has(type)) {
        console.log(`[UV WS] Ignoring non-alert type: ${type}`);
        return;
      }

      if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
      uvAuthenticationTimer = null;
      const statusChanged = !uvAuthenticated || uvStatus !== 'Authenticated';
      authenticationTimedOut = false;
      uvRetryController.resetAfterEvidence('live-alert');
      uvAuthenticated = true;
      uvStatus = 'Authenticated';
      uvLastAlertReceivedAt = new Date().toISOString();
      uvLastAlertAt = data?.now || uvLastAlertReceivedAt;
      // A healthy live stream used to emit an unchanged status frame before
      // every item. Only real transitions belong on the dashboard hot path.
      if (statusChanged) broadcastLocal('status', { uvStatus, vhStatus, svStatus });
      markFeedHealthy('UV', uvSessionHealthReason());

      if (!products.length) {
        console.log(
          `[UV WS] Live alert ${type} contained no products: ${JSON.stringify(message).slice(
            0,
            1000
          )}`
        );
        return;
      }

      liveItemLog(
        `[UV LIVE] ${type}: ${products.length} item(s), serverTime=${data?.now || 'n/a'}`
      );

      const frameUvAlertQueueIds = data?.queueId
        ? [String(data.queueId)]
        : getUvQueues('Alert').map(queue => queue.id);
      products.forEach(product => {
        const itemObj = product.details
          ? { ...product, ...product.details }
          : { ...product };

        itemObj.uv_event_at = data?.now || itemObj.date || new Date().toISOString();
        // UV 26.9.38 routes a frame carrying data.queueId only to that Alert
        // queue; a frame without queueId is delivered to every Alert queue.
        itemObj.uvAlertQueueIds = frameUvAlertQueueIds;

        // Do not prefill AI here. Official UV products carry their queue in
        // `type` (for example VENDOR_VINE_FOR_ALL for AFA); assigning queue=AI
        // before ingestion would hide that authoritative field because `queue`
        // has higher precedence. classifyItemQueue handles true omissions.
        // Alert event names are retained separately as origin provenance
        // (Ultraviner, Brenda, or Redrop), never as a fourth Vine queue.
        ingestItem(itemObj, 'UV', type, null, liveFrameTiming);
      });
    });

    socket.on('close', (code, reasonBuffer) => {
      if (generation !== uvGeneration || socket !== uvWs) return;

      const reason = reasonBuffer?.toString() || '(none)';
      console.log(`[UV WS] Closed: code=${code}, reason=${reason}`);
      clearUvTimers();
      uvWs = null;
      uvAuthenticated = false;

      if (config.enableUV && !uvRetryController.isTerminalBlocked()) {
        scheduleUvReconnect(
          generation,
          authenticationTimedOut ? 'authentication-timeout' : 'transport-close'
        );
      } else if (!config.enableUV) {
        uvStatus = 'Disabled';
        broadcastLocal('status', { uvStatus, vhStatus, svStatus });
        markFeedDisabled('UV');
      } else if (uvStatus === 'Authenticated') {
        // A terminally blocked close must not leave the dashboard claiming that
        // a dead socket is authenticated. Specific invalid-token status remains
        // visible until an explicit user reconnect clears the block.
        uvStatus = 'Disconnected; manual reconnect required';
        broadcastLocal('status', { uvStatus, vhStatus, svStatus });
      }

      if (
        config.enableUV &&
        !(feedHealth.UV.activeIncident && feedHealth.UV.incidentKey.startsWith('uv-token:'))
      ) {
        noteFeedProblem(
          'UV',
          `WebSocket closed (code ${code}, reason ${reason}).`,
          `uv-connectivity:${sha256(config.token).slice(0, 12)}`
        );
      }
    });

    socket.on('error', error => {
      if (generation !== uvGeneration || socket !== uvWs) return;
      console.error('[UV WS] Error:', error.message);
      noteFeedProblem(
        'UV',
        `WebSocket error: ${error.message}`,
        `uv-connectivity:${sha256(config.token).slice(0, 12)}`
      );
    });
  } catch (error) {
    console.error('[UV WS] Setup error:', error.message);
    uvStatus = `Error: ${error.message}`;
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    noteFeedProblem(
      'UV',
      `WebSocket setup error: ${error.message}`,
      `uv-connectivity:${sha256(config.token).slice(0, 12)}`
    );
    scheduleUvReconnect(generation, 'setup-error');
  }
}

// ============================================================================
// UV CATALOG/EXPLORER
// ============================================================================
const UV_EXPLORER_VARIANT_SEED_TTL_MS = 15 * 60 * 1000;
const UV_EXPLORER_VARIANT_SEED_LIMIT = 1500;
const UV_EXPLORER_VARIANT_REQUEST_TTL_MS = 10 * 60 * 1000;
const UV_EXPLORER_VARIANT_REQUEST_LIMIT = 128;
const uvExplorerVariantSeeds = new Map();
const uvExplorerVariantRequestIds = new Map();

function normalizeUvEmbeddedVariants(flattened, parentAsin) {
  const output = [];
  const seen = new Set();
  for (const source of [
    flattened?.variants,
    flattened?.variation_data,
    flattened?.variations,
    flattened?.children,
    flattened?.variant_asin || flattened?.variantAsin
      ? [{
          asin: flattened.variant_asin ?? flattened.variantAsin,
          dimensions: flattened.variant_dimensions ?? flattened.dimensions ?? flattened.dimension_values
        }]
      : null
  ]) {
    for (const variant of normalizeEmbeddedVariants(source)) {
      if (variant.asin === parentAsin || seen.has(variant.asin)) continue;
      seen.add(variant.asin);
      output.push(variant);
      if (output.length >= 100) return output;
    }
  }
  return output;
}

function pruneUvExplorerVariantState(now = Date.now()) {
  for (const [seedId, seed] of uvExplorerVariantSeeds.entries()) {
    if (!seed || seed.expiresAtMs <= now) uvExplorerVariantSeeds.delete(seedId);
  }
  while (uvExplorerVariantSeeds.size > UV_EXPLORER_VARIANT_SEED_LIMIT) {
    uvExplorerVariantSeeds.delete(uvExplorerVariantSeeds.keys().next().value);
  }
  for (const [requestId, expiresAtMs] of uvExplorerVariantRequestIds.entries()) {
    if (!Number.isFinite(expiresAtMs) || expiresAtMs <= now) {
      uvExplorerVariantRequestIds.delete(requestId);
    }
  }
  while (uvExplorerVariantRequestIds.size > UV_EXPLORER_VARIANT_REQUEST_LIMIT) {
    uvExplorerVariantRequestIds.delete(uvExplorerVariantRequestIds.keys().next().value);
  }
}

function rememberUvExplorerVariantSeed(rawProduct, formattedProduct, now = Date.now()) {
  const asin = String(formattedProduct?.asin || '').trim().toUpperCase();
  const queue = String(formattedProduct?.queue || '').trim().toUpperCase();
  if (!/^[A-Z0-9]{10}$/.test(asin) || !['RFY', 'AFA'].includes(queue)) return null;
  const flattened = rawProduct?.details
    ? { ...rawProduct, ...rawProduct.details }
    : rawProduct && typeof rawProduct === 'object'
      ? rawProduct
      : {};
  pruneUvExplorerVariantState(now);
  const seedId = `uv-variant-${crypto.randomBytes(18).toString('base64url')}`;
  uvExplorerVariantSeeds.set(seedId, Object.freeze({
    seedId,
    asin,
    queue,
    enrollmentGuid: extractEnrollmentGuid(flattened) || null,
    expiresAtMs: now + UV_EXPLORER_VARIANT_SEED_TTL_MS
  }));
  pruneUvExplorerVariantState(now);
  return seedId;
}

function resolveUvExplorerVariantSeed(seedId, asin, now = Date.now()) {
  pruneUvExplorerVariantState(now);
  const normalizedSeedId = String(seedId || '').trim();
  const normalizedAsin = String(asin || '').trim().toUpperCase();
  if (!/^uv-variant-[A-Za-z0-9_-]{24}$/.test(normalizedSeedId) || !/^[A-Z0-9]{10}$/.test(normalizedAsin)) {
    const error = new Error('The UV Explorer variant lookup seed is invalid');
    error.code = 'variant_seed_invalid';
    throw error;
  }
  const seed = uvExplorerVariantSeeds.get(normalizedSeedId);
  if (!seed || seed.expiresAtMs <= now || seed.asin !== normalizedAsin) {
    const error = new Error('This UV Explorer record expired or is no longer available; search again before loading variants');
    error.code = 'variant_seed_expired';
    throw error;
  }
  return seed;
}

function formatProductForDisplay(product, fallbackQueue = 'RFY') {
  const flattened = product.details ? { ...product, ...product.details } : product;
  const asin = flattened.asin || flattened.parentAsin || 'N/A';
  const title = decodeHtmlEntities(flattened.title || flattened.name || 'Unknown Product').trim();
  const rawQueue =
    flattened.queue ||
    flattened.queueType ||
    flattened.type ||
    flattened.recommendationType ||
    flattened.queue_type ||
    '';
  const queue = normalizeQueue(rawQueue, '', fallbackQueue);
  const price = flattened.price ?? 'N/A';
  const etv = flattened.etv ?? flattened.price ?? 'N/A';
  const imgUrl =
    flattened.img_url || flattened.imageUrl || flattened.img || flattened.thumbnail || '';
  const brand = flattened.brand || flattened.byLine || flattened.seller || 'Unknown';
  const categoryId = extractUvCategoryId(flattened, 'UV', null);
  const category = getUvCategory(categoryId);
  const matches = checkKeywordMatches(title, price, etv, categoryId);
  const variants = normalizeUvEmbeddedVariants(flattened, asin);
  const isParentAsin = flattened.isParentAsin === true ||
    flattened.is_parent_asin === true ||
    variants.length > 0;

  return {
    asin,
    title,
    firstTwoWords: getFirstTwoWords(title),
    sources: ['UV'],
    firstDiscoveredBy: 'UV',
    queue,
    categoryId,
    categoryName: category?.name || null,
    categoryEmoji: category?.emoji || null,
    categorySource: categoryId ? 'UV' : null,
    price,
    etv,
    isZeroEtv: etv !== 'N/A' && Number(etv) === 0,
    img_url: imgUrl,
    brand,
    isParentAsin,
    // Retain only bounded child ASINs and display-safe dimensions already
    // present in this one UV search response. Recommendation, customer,
    // enrollment, offer, and signing metadata never reaches the browser.
    variants,
    isHighlight: matches.isHighlight,
    isPriceHighlight: matches.isPriceHighlight,
    isCategoryPriority: matches.isCategoryPriority,
    priorityReasons: matches.priorityReasons,
    isPinned: pinnedAsins.has(asin),
    date_added: flattened.date_added || flattened.date || new Date().toISOString(),
    vineSearchUrl: getTwoWordSearchUrl(title, config.domain),
    dpUrl: `https://www.${config.domain}/dp/${asin}`
  };
}

async function readBoundedUvJson(response, maximumBytes, operation) {
  const declaredBytes = Number(response.headers.get('content-length'));
  if (Number.isFinite(declaredBytes) && declaredBytes > maximumBytes) {
    const error = new Error(`${operation} returned an oversized response`);
    error.code = 'uv_variant_metadata_too_large';
    throw error;
  }
  const chunks = [];
  let total = 0;
  const reader = response.body?.getReader?.();
  if (reader) {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maximumBytes) {
        try { await reader.cancel(); } catch (_) {}
        const error = new Error(`${operation} returned an oversized response`);
        error.code = 'uv_variant_metadata_too_large';
        throw error;
      }
      chunks.push(Buffer.from(value));
    }
  } else {
    const buffer = Buffer.from(await response.arrayBuffer());
    total = buffer.length;
    if (total > maximumBytes) {
      const error = new Error(`${operation} returned an oversized response`);
      error.code = 'uv_variant_metadata_too_large';
      throw error;
    }
    chunks.push(buffer);
  }
  const text = Buffer.concat(chunks, total).toString('utf8');
  let payload;
  try {
    payload = JSON.parse(text);
  } catch (_) {
    const error = new Error(`${operation} returned invalid JSON`);
    error.code = 'uv_variant_metadata_invalid';
    throw error;
  }
  if (!response.ok) {
    const error = new Error(`${operation} returned HTTP ${response.status}`);
    error.code = response.status === 401 || response.status === 403
      ? 'uv_variant_metadata_unauthorized'
      : 'uv_variant_metadata_unavailable';
    throw error;
  }
  return payload;
}

async function fetchUvExplorerEnrollmentSeed(seed) {
  if (seed.enrollmentGuid) return seed;
  if (!config.token) {
    const error = new Error('The saved UV token is unavailable for this explicit product-metadata lookup');
    error.code = 'uv_variant_metadata_unavailable';
    throw error;
  }
  const controller = new AbortController();
  // Bound the two sequential official UV reads to one 20-second window.
  const timer = setTimeout(() => controller.abort(), 20_000);
  timer.unref?.();
  const commonHeaders = {
    Authorization: `Bearer ${config.token}`,
    Origin: `https://www.${config.domain}`,
    Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
    'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
  };
  try {
    // Follow the inspected official UV runtime: one deep-link authorization
    // read, then one signed product hydration read. Neither response is sent to
    // the browser or persisted, and neither call can place an order.
    const deepLinkResponse = await fetch(
      `https://api.ultraviner.com/ultraviner/productDeepLink?asin=${encodeURIComponent(seed.asin)}`,
      { method: 'GET', headers: commonHeaders, signal: controller.signal }
    );
    const deepLink = await readBoundedUvJson(
      deepLinkResponse,
      64 * 1024,
      'UV product authorization lookup'
    );
    const auth = String(deepLink?.data?.auth || '').trim();
    if (!auth || auth.length > 4096 || /[\u0000-\u001f\u007f]/u.test(auth)) {
      const error = new Error('UV did not return bounded product authorization metadata');
      error.code = 'uv_variant_metadata_invalid';
      throw error;
    }
    const type = seed.queue === 'RFY' ? 'VENDOR_TARGETED' : 'VENDOR_VINE_FOR_ALL';
    const signedPayload = { asin: seed.asin, type };
    const productResponse = await fetch(
      `https://api.ultraviner.com/ultraviner/product?asin=${encodeURIComponent(seed.asin)}&auth=${encodeURIComponent(auth)}&type=${encodeURIComponent(type)}`,
      {
        method: 'GET',
        headers: { ...commonHeaders, ...signUvPayload(signedPayload, config.token) },
        signal: controller.signal
      }
    );
    const productPayload = await readBoundedUvJson(
      productResponse,
      512 * 1024,
      'UV product metadata lookup'
    );
    const product = productPayload?.product;
    if (!product || typeof product !== 'object' || Array.isArray(product)) {
      const error = new Error('UV product metadata did not contain a product object');
      error.code = 'uv_variant_metadata_invalid';
      throw error;
    }
    const returnedAsin = String(product.asin || product.parentAsin || seed.asin).trim().toUpperCase();
    if (returnedAsin !== seed.asin) {
      const error = new Error('UV product metadata returned a different ASIN');
      error.code = 'uv_variant_metadata_invalid';
      throw error;
    }
    const enrollmentGuid = extractEnrollmentGuid(product);
    if (!enrollmentGuid) {
      const error = new Error('UV did not provide transient recommendation metadata needed for Amazon variants');
      error.code = 'uv_variant_metadata_missing';
      throw error;
    }
    const hydrated = Object.freeze({ ...seed, enrollmentGuid });
    uvExplorerVariantSeeds.set(seed.seedId, hydrated);
    return hydrated;
  } catch (error) {
    if (error?.name === 'AbortError') {
      const timeout = new Error('The explicit UV product-metadata lookup timed out');
      timeout.code = 'uv_variant_metadata_timeout';
      throw timeout;
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchInitialUvCatalog() {
  if (!config.token || !config.enableUV) return;

  const countryId = Ge[config.domain] || 2;
  const exploreQueue = effectiveUvExploreQueue();
  if (!exploreQueue) {
    console.warn('[UV Sync] A real Explore queue is required; Alert queues are not search identities.');
    return;
  }

  try {
    const signedPayload = {
      pageSize: '100',
      page: '1',
      searchTerm: '',
      countryId: countryId.toString(),
      categories: '',
      queueTypes: 'RFY,AI,AFA',
      queueId: exploreQueue.id,
      queueName: exploreQueue.name
    };
    const body = buildUvSearchRequestBody(config.token, signedPayload);
    const headers = {
      ...signUvPayload(signedPayload, config.token),
      Authorization: `Bearer ${config.token}`,
      Origin: `https://www.${config.domain}`,
      Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
      'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
    };

    const response = await fetch('https://api.ultraviner.com/ultraviner/search', {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      console.warn(`[UV Sync] HTTP ${response.status}: ${(await response.text()).slice(0, 300)}`);
      return;
    }

    const data = await response.json();
    const products = Array.isArray(data.products) ? data.products : [];
    console.log(`[UV Sync] Ingesting ${products.length} catalog records silently.`);

    for (let index = products.length - 1; index >= 0; index -= 1) {
      const product = products[index];
      ingestItem(product.details ? { ...product, ...product.details } : product, 'UV', 'INITIAL_LOAD');
    }

    persistItemsReplace();
    broadcastLocal('feed_refreshed', { count: allItems.filter(isLiveItem).length });
  } catch (error) {
    console.error('[UV Sync] Error:', error.message);
  }
}

// ============================================================================
// VHELPER PASSIVE ITEM/ENRICHMENT HANDLING
// ============================================================================
const pendingVhEnrichments = new Map();
const VH_PENDING_ENRICHMENT_TTL_MS = 5 * 60 * 1000;
const VH_PENDING_ENRICHMENT_LIMIT = 500;
const VH_PENDING_ENRICHMENT_SWEEP_MS = 30 * 1000;
let nextPendingVhEnrichmentSweepAt = 0;

function sweepPendingVhEnrichments(now = Date.now()) {
  if (now < nextPendingVhEnrichmentSweepAt) return;
  nextPendingVhEnrichmentSweepAt = now + VH_PENDING_ENRICHMENT_SWEEP_MS;
  for (const [asin, entries] of pendingVhEnrichments.entries()) {
    const fresh = entries.filter(entry => now - entry.receivedAt < VH_PENDING_ENRICHMENT_TTL_MS);
    if (fresh.length) pendingVhEnrichments.set(asin, fresh);
    else pendingVhEnrichments.delete(asin);
  }
}

function rememberPendingVhEnrichment(eventName, rawPayload) {
  const patch = normalizeVhEnrichment(eventName, rawPayload);
  if (!patch?.asin) return;
  const now = Date.now();
  // Opportunistic event-time cleanup: no timer, debounce, or delivery wait.
  sweepPendingVhEnrichments(now);
  if (pendingVhEnrichments.size >= VH_PENDING_ENRICHMENT_LIMIT) {
    pendingVhEnrichments.delete(pendingVhEnrichments.keys().next().value);
  }
  const entries = pendingVhEnrichments.get(patch.asin) || [];
  entries.push({ eventName, rawPayload, receivedAt: now });
  pendingVhEnrichments.set(patch.asin, entries.slice(-10));
}

function applyVhEnrichment(
  eventName,
  rawPayload,
  {
    allowPending = true,
    allowDelayedPriceCompletion = true,
    receivedAtMs = Date.now()
  } = {}
) {
  const patch = normalizeVhEnrichment(eventName, rawPayload);
  if (!patch?.asin) return null;
  const index = allItems.findIndex(item => item.asin === patch.asin);
  if (index === -1) {
    if (allowPending) rememberPendingVhEnrichment(eventName, rawPayload);
    liveItemLog(`[VH ENRICH] Deferred orphan ${eventName}: ${patch.asin}`);
    return null;
  }

  const existing = allItems[index];
  const liveSources = deriveLiveSources(existing);
  const updated = {
    ...existing,
    sources: liveSources,
    liveSources,
    observedSources: appendSource(
      existing.observedSources?.length ? existing.observedSources : existing.sources,
      'VH'
    ),
    enrichmentSources: appendSource(existing.enrichmentSources, 'VH'),
    vhLastEnrichmentEvent: eventName,
    vhEnrichedAt: patch.vhEnrichedAt,
    last_updated_by: 'VH_ENRICHMENT'
  };

  const copyIfDefined = field => {
    if (patch[field] !== undefined && patch[field] !== null && patch[field] !== '') {
      updated[field] = patch[field];
    }
  };
  [
    'price',
    'etv',
    'etv_min',
    'etv_max',
    'variants',
    'additional_img',
    'unavailable',
    'available',
    'unavailableReason',
    'order_success',
    'order_failed'
  ].forEach(copyIfDefined);

  if (patch.etv !== undefined && patch.etv !== null && patch.etv !== '') {
    const etvValues = [updated.etv_min, updated.etv_max, patch.etv]
      .map(value => parseMoney(value, NaN))
      .filter(Number.isFinite);
    if (etvValues.length) {
      updated.etv_min = Math.min(...etvValues);
      updated.etv_max = Math.max(...etvValues);
      updated.isZeroEtv = updated.etv_min === 0;
    }
  }
  if (patch.additional_img !== undefined) {
    updated.additional_img = Array.isArray(patch.additional_img)
      ? patch.additional_img
      : patch.additional_img
        ? [patch.additional_img]
        : existing.additional_img || [];
  }

  const matches = checkKeywordMatches(
    updated.title,
    updated.price,
    updated.etv,
    updated.categoryId
  );
  updated.isHighlight = matches.isHighlight;
  updated.isPriceHighlight = matches.isPriceHighlight;
  updated.isCategoryPriority = matches.isCategoryPriority;
  updated.priorityReasons = matches.priorityReasons;
  updated.isHide = matches.isHide;
  updated.isBlur = matches.isBlur;

  if (allowDelayedPriceCompletion && ['newPrice', 'newETV'].includes(eventName)) {
    orderCoordinator.dispatchForDelayedPriceCompletion(updated, {
      asin: patch.asin,
      source: 'VH',
      eventType: eventName,
      receivedAtMs,
      price: patch.price,
      etv: patch.etv
    });
  }

  upsertItemInMemory(updated, index);
  // Enrichment is deliberately silent: no discovery clock and no external
  // notification. It only updates an existing merged card.
  broadcastLocal('update_item', withOrderRuleMatch(updated));
  persistItemUpsert(updated);
  liveItemLog(`[VH ENRICH] ${eventName}: ${patch.asin}`);
  return updated;
}

function applyPendingVhEnrichments(asin) {
  const entries = pendingVhEnrichments.get(asin) || [];
  pendingVhEnrichments.delete(asin);
  for (const entry of entries) {
    if (Date.now() - entry.receivedAt < VH_PENDING_ENRICHMENT_TTL_MS) {
      // An enrichment received before its live item may update the card, but it
      // can never be replayed as a delayed automatic-order trigger.
      applyVhEnrichment(entry.eventName, entry.rawPayload, {
        allowPending: false,
        allowDelayedPriceCompletion: false,
        receivedAtMs: entry.receivedAt
      });
    }
  }
}

function ingestVhLivePayload(rawPayload, eventName = 'newItem', liveTiming = null) {
  const normalized = normalizeVhPayload(rawPayload, { event: eventName });
  const item = ingestItem(normalized, 'VH', eventName, null, liveTiming);
  if (item?.asin) applyPendingVhEnrichments(item.asin);
  return item;
}

// ============================================================================
// VHELPER STREAM — PACKAGE B, LIVE-ONLY, HARD-DISABLE CAPABLE
// ============================================================================
let vhSocket = null;
let vhSocketSignature = '';
let vhSetupRetryTimer = null;
let vhSupervisorTimer = null;
let vhConnectInFlight = false;
let vhSetupRetryAttempts = 0;
let vhNextSetupAttemptAt = 0;
let vhApplicationReady = false;
let vhDenied = false;
let vhDenial = null;
let vhConnectedAtMs = 0;
let vhDisconnectedAtMs = 0;
let vhLastEngineActivityMs = 0;
let vhLastApplicationActivityMs = 0;
let vhLastSyncSentAtMs = 0;
let vhSyncPendingSinceMs = 0;
let vhLastSyncPongAtMs = 0;
let vhLastBroadcast = null;
let vhConnectionInfo = null;
let vhLastRecovery = null;
let vhPossibleGap = null;
let vhReconnectCount = 0;
let vhEngine = null;
let vhEngineActivityHandler = null;
let vhPlannedDisconnect = null;
let vhLastRecoveryRequest = null;
let vhSyncNoticeObservedForSentAtMs = 0;
let vhBroadcastSyncConsecutiveMisses = 0;
let vhLastBroadcastSyncMissAtMs = 0;
let vhApplicationEvidenceNoticeConnectionAtMs = 0;
let vhBroadcastGapRecovery = null;
let vhBroadcastGapReconnectSuppressions = 0;

const VH_SUPERVISOR_INTERVAL_MS = 10000;
const VH_BROADCAST_SYNC_INTERVAL_MS = 60000;
// The official 4.7.4 client sends broadcastSyncPing but does not require a
// pong or tear down the socket when one is absent. These thresholds therefore
// drive diagnostics only; they must never become forced-disconnect timers.
const VH_BROADCAST_SYNC_NOTICE_MS = 30000;
const VH_ENGINE_SILENCE_MS = 120000;
const VH_MAX_CONNECTION_AGE_MS = 3 * 60 * 60 * 1000;
const VH_APPLICATION_EVIDENCE_NOTICE_MS = 30000;
const VH_RECOVERY_WINDOW_MS = 60000;

function clearVhSetupRetry() {
  if (vhSetupRetryTimer) clearTimeout(vhSetupRetryTimer);
  vhSetupRetryTimer = null;
}

function summarizeVhConnectionInfo(raw) {
  const outer = raw && typeof raw === 'object' ? raw : {};
  const data = outer.data && typeof outer.data === 'object' ? outer.data : outer;
  const devices = Array.isArray(data.devices) ? data.devices : [];
  return {
    receivedAt: new Date().toISOString(),
    socketId: data.socket_id || data.socketId || data.id || null,
    tier: data.tier ?? data.account_tier ?? null,
    connections: data.connections ?? data.connection_count ?? data.current_connections ?? null,
    connectionAllowance:
      data.connection_allowance ?? data.allowed_connections ?? data.max_connections ?? null,
    deviceCount: devices.length || data.device_count || null,
    devices: devices.slice(0, 20).map(device => ({
      id: device?.id || device?.device_id || null,
      name: device?.device_name || device?.name || null,
      current: Boolean(device?.current || device?.is_current)
    }))
  };
}

function isVhTransportHealthy() {
  if (!vhSocket?.connected) return false;
  const engineState = vhSocket.io?.engine?.readyState;
  if (engineState && engineState !== 'open') return false;
  if (vhLastEngineActivityMs && Date.now() - vhLastEngineActivityMs > VH_ENGINE_SILENCE_MS) {
    return false;
  }
  return true;
}

function markVhApplicationActivity(reason) {
  if (!isVhEnabled() || vhDenied || !vhSocket?.connected) return;
  const firstReady = !vhApplicationReady;
  const statusChanged = vhStatus !== 'Connected';
  vhApplicationReady = true;
  vhLastApplicationActivityMs = Date.now();
  vhStatus = 'Connected';
  if (firstReady) {
    console.log(`[VH WS] Application-ready (${reason}).`);
    addActivity('vh_application_ready', {
      source: 'VH',
      reason,
      recovered: Boolean(vhSocket.recovered)
    });
  }
  markFeedHealthy('VH', `Application-ready: ${reason}`);
  // Engine pings, enrichments, and every new item all mark activity. Do not
  // precede each item with an identical status frame.
  if (firstReady || statusChanged) broadcastLocal('status', { uvStatus, vhStatus, svStatus });
}

function noteVhPossibleGap(reason, details = {}) {
  vhPossibleGap = {
    detectedAt: new Date().toISOString(),
    reason,
    ...details
  };
  addActivity('vh_possible_gap', { source: 'VH', ...vhPossibleGap });
  // A gap is detected only after the recoverable session window or a newer
  // server marker proves local divergence, so it is actionable immediately.
  reportVhFeedProblem(`Possible missed VH broadcasts: ${reason}`, 'vh-possible-gap', true);
}

function recordVhLiveBroadcast(item) {
  if (!item?.asin) return;
  vhLastBroadcast = {
    asin: item.asin,
    receivedAt: new Date().toISOString(),
    receivedAtMs: Date.now(),
    serverDate: item.vhServerDate || null
  };
  if (vhBroadcastGapRecovery) {
    console.log(
      '[VH WS] New live broadcast observed after gap recovery; future distinct gaps may recover once.'
    );
    vhBroadcastGapRecovery = null;
    vhBroadcastGapReconnectSuppressions = 0;
  }
}

function emitVhBroadcastSync(reason = 'interval') {
  if (!isVhEnabled() || vhDenied || !vhSocket?.connected) return false;
  const now = Date.now();
  if (vhSyncPendingSinceMs && now - vhSyncPendingSinceMs < VH_BROADCAST_SYNC_NOTICE_MS) {
    return false;
  }
  // Match the official passive signal exactly: no payload, no history request,
  // and no requirement that every ping produce a pong. A returned pong can
  // still prove application activity or identify a broadcast-marker mismatch.
  vhSocket.emit('broadcastSyncPing');
  vhLastSyncSentAtMs = now;
  vhSyncPendingSinceMs = now;
  vhSyncNoticeObservedForSentAtMs = 0;
  console.log(`[VH WS] broadcastSyncPing (${reason}).`);
  return true;
}

function reconnectVhSameSocket(reason) {
  if (!isVhEnabled() || vhDenied) return;
  const safeReason = String(reason || 'recovery requested').slice(0, 300);
  const requestedAtMs = Date.now();
  vhReconnectCount += 1;
  vhApplicationReady = false;
  vhLastRecoveryRequest = {
    requestedAt: new Date(requestedAtMs).toISOString(),
    reason: safeReason
  };
  vhStatus = `Recovering: ${safeReason}`;
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  console.warn(`[VH WS] Same-socket recovery: ${safeReason}`);
  if (!vhSocket) {
    void connectVHelper({ force: true });
    return;
  }
  try {
    if (vhSocket.connected) {
      vhPlannedDisconnect = {
        socket: vhSocket,
        reason: safeReason,
        requestedAtMs
      };
      vhSocket.disconnect();
    }
  } catch (_) {
    vhPlannedDisconnect = null;
  }
  setTimeout(() => {
    if (!isVhEnabled() || vhDenied) return;
    if (vhSocket) {
      try {
        vhSocket.connect();
      } catch (error) {
        console.error('[VH WS] Same-socket reconnect failed:', error.message);
        void connectVHelper({ force: true });
      }
    } else {
      void connectVHelper({ force: true });
    }
  }, 250).unref?.();
}

function runVhSupervisor() {
  if (!isVhEnabled() || vhDenied) return;
  const now = Date.now();
  if (!vhSocket) {
    if (!vhConnectInFlight && now >= vhNextSetupAttemptAt) void connectVHelper();
    return;
  }
  if (!vhSocket.connected) {
    try {
      vhSocket.connect();
    } catch (_) {
      if (!vhConnectInFlight && now >= vhNextSetupAttemptAt) void connectVHelper({ force: true });
    }
    return;
  }

  const engineState = vhSocket.io?.engine?.readyState;
  if (engineState && engineState !== 'open') {
    reconnectVhSameSocket(`Engine.IO state is ${engineState}`);
    return;
  }
  if (vhLastEngineActivityMs && now - vhLastEngineActivityMs > VH_ENGINE_SILENCE_MS) {
    reconnectVhSameSocket('Engine.IO silent for more than two minutes');
    return;
  }
  if (vhConnectedAtMs && now - vhConnectedAtMs > VH_MAX_CONNECTION_AGE_MS) {
    reconnectVhSameSocket('three-hour connection refresh');
    return;
  }

  // The official client declares wsOpen on transport connect. It does not
  // require connection_info or another application event within 30 seconds.
  // Record missing evidence for diagnostics, but never induce a reconnect loop.
  if (
    !vhApplicationReady &&
    vhConnectedAtMs &&
    now - vhConnectedAtMs > VH_APPLICATION_EVIDENCE_NOTICE_MS &&
    vhApplicationEvidenceNoticeConnectionAtMs !== vhConnectedAtMs
  ) {
    vhApplicationEvidenceNoticeConnectionAtMs = vhConnectedAtMs;
    console.warn(
      '[VH WS] No application event observed yet; keeping healthy Socket.IO transport connected.'
    );
  }

  // The official client has no broadcastSyncPong deadline. A missing pong is
  // diagnostic only; disconnecting here would destroy a socket the official
  // client intentionally keeps alive.
  if (
    vhSyncPendingSinceMs &&
    now - vhSyncPendingSinceMs > VH_BROADCAST_SYNC_NOTICE_MS &&
    vhSyncNoticeObservedForSentAtMs !== vhSyncPendingSinceMs
  ) {
    vhSyncNoticeObservedForSentAtMs = vhSyncPendingSinceMs;
    vhBroadcastSyncConsecutiveMisses += 1;
    vhLastBroadcastSyncMissAtMs = now;
    if (
      vhBroadcastSyncConsecutiveMisses === 1 ||
      vhBroadcastSyncConsecutiveMisses % 15 === 0
    ) {
      console.warn(
        `[VH WS] broadcastSyncPong not observed (${vhBroadcastSyncConsecutiveMisses} consecutive); ` +
          'keeping healthy transport connected per official-client behavior.'
      );
    }
  }
  if (!vhLastSyncSentAtMs || now - vhLastSyncSentAtMs >= VH_BROADCAST_SYNC_INTERVAL_MS) {
    emitVhBroadcastSync('supervisor');
  }
}

function startVhSupervisor() {
  if (vhSupervisorTimer) return;
  vhSupervisorTimer = setInterval(runVhSupervisor, VH_SUPERVISOR_INTERVAL_MS);
  vhSupervisorTimer.unref?.();
}

function stopVhSupervisor() {
  if (vhSupervisorTimer) clearInterval(vhSupervisorTimer);
  vhSupervisorTimer = null;
}

function scheduleVhSetupRetry() {
  if (!isVhEnabled() || vhDenied || vhSetupRetryTimer) return;
  vhSetupRetryAttempts += 1;
  const delay = Math.min(300000, 30000 * 2 ** Math.min(4, vhSetupRetryAttempts - 1));
  vhNextSetupAttemptAt = Date.now() + delay;
  console.log(`[VH WS] Setup retry scheduled in ${delay}ms.`);
  vhSetupRetryTimer = setTimeout(() => {
    vhSetupRetryTimer = null;
    void connectVHelper({ force: true });
  }, delay);
  vhSetupRetryTimer.unref?.();
}

function destroyVhSocket() {
  detachVhEngineActivity();
  vhPlannedDisconnect = null;
  if (!vhSocket) return;
  const oldSocket = vhSocket;
  vhSocket = null;
  vhSocketSignature = '';
  try {
    oldSocket.removeAllListeners();
    oldSocket.io?.removeAllListeners?.();
    oldSocket.disconnect();
    oldSocket.close();
  } catch (_) {}
}

function stopVHelper(status) {
  clearVhSetupRetry();
  stopVhSupervisor();
  destroyVhSocket();
  vhApplicationReady = false;
  vhConnectedAtMs = 0;
  vhLastEngineActivityMs = 0;
  vhLastApplicationActivityMs = 0;
  vhSyncPendingSinceMs = 0;
  vhLastSyncSentAtMs = 0;
  vhSyncNoticeObservedForSentAtMs = 0;
  vhBroadcastSyncConsecutiveMisses = 0;
  vhLastBroadcastSyncMissAtMs = 0;
  vhApplicationEvidenceNoticeConnectionAtMs = 0;
  vhBroadcastGapRecovery = null;
  vhBroadcastGapReconnectSuppressions = 0;
  vhPlannedDisconnect = null;
  vhStatus = status || (VH_FORCE_DISABLED ? 'Disabled (UV-only process mode)' : 'Disabled');
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  if (!isVhEnabled()) markFeedDisabled('VH');
  console.log(`[VH WS] ${vhStatus}`);
}

function clearVhDenial() {
  vhDenied = false;
  vhDenial = null;
}

function latchVhDenial(raw, fallback = 'Connection denied by VHelper') {
  const message = String(raw?.message || raw?.reason || raw?.error || raw || fallback).slice(0, 300);
  vhDenied = true;
  vhDenial = { message, at: new Date().toISOString() };
  vhApplicationReady = false;
  vhPlannedDisconnect = null;
  vhStatus = `Denied: ${message}`;
  clearVhSetupRetry();
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  addActivity('vh_server_denial', { source: 'VH', message });
  reportVhFeedProblem(message, 'vh-server-denial');
  try {
    vhSocket?.disconnect();
  } catch (_) {}
  console.error(`[VH WS] Server denial latched: ${message}`);
}

function isInvalidUuidError(raw) {
  const text = JSON.stringify(raw || '').toLowerCase();
  return (
    raw?.invalid_uuid === true ||
    text.includes('uuid does not exist') ||
    text.includes('old uuid') ||
    text.includes('invalid uuid')
  );
}

async function handleVhConnectionError(raw) {
  const message = String(raw?.message || raw?.error || JSON.stringify(raw || {})).slice(0, 300);
  vhApplicationReady = false;
  reportVhFeedProblem(`Application connection_error: ${message}`, 'vh-application-error');
  if (!isInvalidUuidError(raw)) {
    const denialText = JSON.stringify(raw || message).toLowerCase();
    if (
      denialText.includes('too many') ||
      denialText.includes('connection limit') ||
      denialText.includes('not allowed') ||
      denialText.includes('denied') ||
      denialText.includes('banned')
    ) {
      latchVhDenial({ message });
      return;
    }
    vhStatus = `VH application error: ${message}`;
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    return;
  }
  // Identity continuity is more important than an automatic UUID mutation.
  // This applies to both preserved legacy identities and newly generated
  // hardened identities: retain the exact local record and require an explicit,
  // separately backed-up operator decision if the server rejects it.
  const diagnostics = identityManager.diagnostics(config.countryCode || 'ca');
  latchVhDenial(
    {
      message:
        `${diagnostics.identityMode || 'Stored'} VH UUID was rejected. ` +
        'Automatic identity replacement is disabled; the saved identity was preserved.'
    },
    message
  );
}

function detachVhEngineActivity() {
  if (vhEngine?.off && vhEngineActivityHandler) {
    vhEngine.off('packet', vhEngineActivityHandler);
    vhEngine.off('ping', vhEngineActivityHandler);
    vhEngine.off('pong', vhEngineActivityHandler);
  }
  vhEngine = null;
  vhEngineActivityHandler = null;
}

function attachVhEngineActivity(socket) {
  detachVhEngineActivity();
  const engine = socket.io?.engine;
  if (!engine?.on) return;
  vhEngine = engine;
  vhEngineActivityHandler = () => {
    if (socket === vhSocket) vhLastEngineActivityMs = Date.now();
  };
  engine.on('packet', vhEngineActivityHandler);
  engine.on('ping', vhEngineActivityHandler);
  engine.on('pong', vhEngineActivityHandler);
  vhEngineActivityHandler();
}

function bindVhSocketHandlers(socket) {
  socket.on('connect', () => {
    if (socket !== vhSocket || !isVhEnabled()) return;
    const now = Date.now();
    const downtimeMs = vhDisconnectedAtMs ? now - vhDisconnectedAtMs : 0;
    vhConnectedAtMs = now;
    vhLastEngineActivityMs = now;
    vhApplicationReady = false;
    vhSyncPendingSinceMs = 0;
    vhSyncNoticeObservedForSentAtMs = 0;
    vhBroadcastSyncConsecutiveMisses = 0;
    vhApplicationEvidenceNoticeConnectionAtMs = 0;
    if (vhPlannedDisconnect?.socket === socket) vhPlannedDisconnect = null;
    vhStatus = 'Connected — awaiting optional VH application activity';
    vhLastRecovery = {
      connectedAt: new Date(now).toISOString(),
      recovered: Boolean(socket.recovered),
      downtimeMs
    };
    attachVhEngineActivity(socket);
    // This is the same readiness point used by the official 4.7.4 client,
    // which reports wsOpen immediately on Socket.IO "connect".
    markFeedHealthy('VH', 'Socket.IO transport connected (official-client criterion)');
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    console.log(`[VH WS] Transport connected (recovered=${Boolean(socket.recovered)}).`);

    if (vhDisconnectedAtMs && !socket.recovered && downtimeMs > VH_RECOVERY_WINDOW_MS) {
      noteVhPossibleGap('Socket.IO recovery window was exceeded', { downtimeMs });
    }
    setTimeout(() => {
      if (socket === vhSocket && socket.connected) emitVhBroadcastSync('connect');
    }, 250).unref?.();
  });

  socket.on('connection_info', data => {
    if (socket !== vhSocket || !isVhEnabled()) return;
    vhConnectionInfo = summarizeVhConnectionInfo(data);
    vhSetupRetryAttempts = 0;
    vhNextSetupAttemptAt = 0;
    clearVhSetupRetry();
    markVhApplicationActivity('connection_info');
  });

  socket.on('newItem', data => {
    const liveTiming = startLiveDeliveryTiming('VH', 'newItem');
    if (socket !== vhSocket || !isVhEnabled()) return;
    markVhApplicationActivity('newItem');
    const item = ingestVhLivePayload(data, 'newItem', liveTiming);
    recordVhLiveBroadcast(item);
  });

  ['newETV', 'newPrice', 'newVariants', 'unavailableItem', 'orderAttempts'].forEach(eventName => {
    socket.on(eventName, data => {
      if (socket !== vhSocket || !isVhEnabled()) return;
      markVhApplicationActivity(eventName);
      applyVhEnrichment(eventName, data);
    });
  });

  socket.on('reloadPage', data => {
    if (socket !== vhSocket || !isVhEnabled()) return;
    markVhApplicationActivity('reloadPage');
    addActivity('vh_reload_ignored', {
      source: 'VH',
      queue: data?.queue || null,
      page: data?.page || null,
      passiveMode: true
    });
    console.log('[VH WS] reloadPage ignored (passive receiver).');
  });

  socket.on('last100', () => {
    if (socket !== vhSocket || !isVhEnabled()) return;
    // An unsolicited response is never ingested. More importantly, no code in
    // Package B emits the corresponding request.
    markVhApplicationActivity('unsolicited-last100-ignored');
    console.warn('[VH WS] Ignored unsolicited last100 payload (history prohibited).');
  });

  socket.on('message', raw => {
    const liveTiming = startLiveDeliveryTiming('VH', 'message-newItem');
    if (socket !== vhSocket || !isVhEnabled()) return;
    try {
      const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (data?.action === 'pong') markVhApplicationActivity('message-pong');
      if (data?.action === 'newItem' && (data?.item || data?.data?.item)) {
        markVhApplicationActivity('message-newItem');
        const item = ingestVhLivePayload(data, 'newItem', liveTiming);
        recordVhLiveBroadcast(item);
      }
    } catch (error) {
      console.error('[VH WS] Message parse error:', error.message);
    }
  });

  socket.on('broadcastSyncPong', data => {
    if (socket !== vhSocket || !isVhEnabled()) return;
    const pong = extractBroadcastSync(data);
    vhSyncPendingSinceMs = 0;
    vhSyncNoticeObservedForSentAtMs = 0;
    vhBroadcastSyncConsecutiveMisses = 0;
    vhLastSyncPongAtMs = Date.now();
    markVhApplicationActivity('broadcastSyncPong');

    const decision = decideBroadcastMismatchRecovery(
      data,
      {
        asin: vhLastBroadcast?.asin,
        timestamp: vhLastBroadcast?.receivedAt
      },
      Boolean(vhBroadcastGapRecovery)
    );
    if (decision.action === 'reconnect-once') {
      vhBroadcastGapRecovery = {
        detectedAt: new Date().toISOString(),
        localAsin: vhLastBroadcast.asin,
        serverAsin: pong.asin,
        serverTimestamp: pong.timestamp,
        markerKey: decision.markerKey
      };
      vhBroadcastGapReconnectSuppressions = 0;
      noteVhPossibleGap('Server latest-broadcast marker differs from local marker', {
        localAsin: vhLastBroadcast.asin,
        serverAsin: pong.asin,
        serverTimestamp: pong.timestamp
      });
      reconnectVhSameSocket('broadcast marker mismatch');
      return;
    }
    if (decision.action === 'keep-connected') {
      vhBroadcastGapReconnectSuppressions += 1;
      if (
        vhBroadcastGapReconnectSuppressions === 1 ||
        vhBroadcastGapReconnectSuppressions % 15 === 0
      ) {
        console.warn(
          '[VH WS] Broadcast marker still differs after one recovery attempt; ' +
            'keeping the healthy socket connected until a new live VH broadcast arrives.'
        );
      }
      return;
    }
    if (vhBroadcastGapRecovery && pong.asin && pong.asin === vhLastBroadcast?.asin) {
      console.log('[VH WS] Local and server broadcast markers match; gap recovery guard cleared.');
      vhBroadcastGapRecovery = null;
      vhBroadcastGapReconnectSuppressions = 0;
    }
  });

  socket.on('serverDisconnect', data => {
    if (socket !== vhSocket) return;
    latchVhDenial(data);
  });

  socket.on('connection_error', data => {
    if (socket !== vhSocket || !isVhEnabled()) return;
    void handleVhConnectionError(data);
  });

  socket.on('disconnect', reason => {
    if (socket !== vhSocket) return;
    const now = Date.now();
    const plannedRecord = vhPlannedDisconnect?.socket === socket ? vhPlannedDisconnect : null;
    const plannedRecovery = Boolean(
      plannedRecord && now - plannedRecord.requestedAtMs <= 10000
    );
    if (plannedRecord) vhPlannedDisconnect = null;

    detachVhEngineActivity();
    vhDisconnectedAtMs = now;
    vhApplicationReady = false;
    vhSyncPendingSinceMs = 0;
    vhSyncNoticeObservedForSentAtMs = 0;
    if (isVhEnabled() && !vhDenied) {
      if (plannedRecovery) {
        // socket.disconnect() necessarily reports "io client disconnect". Do
        // not replace the real recovery reason with that expected local event.
        vhStatus = `Recovering: ${plannedRecord.reason}`;
      } else {
        vhStatus = `Disconnected: ${reason}`;
        reportVhFeedProblem(`Socket.IO disconnected: ${reason}`, 'vh-connectivity');
      }
    } else if (!isVhEnabled()) {
      vhStatus = 'Disabled';
      markFeedDisabled('VH');
    }
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    console.log(
      `[VH WS] Disconnected: ${reason}` +
        (plannedRecovery ? ` (planned recovery: ${plannedRecord.reason})` : '')
    );
  });

  socket.on('connect_error', error => {
    if (socket !== vhSocket || vhDenied) return;
    vhApplicationReady = false;
    vhStatus = `Transport error: ${error.message}`;
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    console.error('[VH WS] Connect error:', error.message);
    reportVhFeedProblem(`Socket.IO connection error: ${error.message}`, 'vh-connectivity');
  });
}

async function connectVHelper({ force = false } = {}) {
  if (!isVhEnabled()) {
    stopVHelper();
    markFeedDisabled('VH');
    return;
  }
  if (vhDenied) {
    vhStatus = `Denied: ${vhDenial?.message || 'manual re-enable required'}`;
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    return;
  }
  if (vhConnectInFlight) return;
  if (!force && Date.now() < vhNextSetupAttemptAt) return;

  vhConnectInFlight = true;
  startVhSupervisor();
  vhStatus = 'Preparing VH identity...';
  broadcastLocal('status', { uvStatus, vhStatus, svStatus });
  console.log(`[VH WS] Preparing passive connection to ${VH_API_URL}...`);

  try {
    const configuredCountry = String(config.countryCode || 'ca').toLowerCase();
    const identity = await identityManager.getOrCreateIdentity(configuredCountry);
    if (!isVhEnabled() || vhDenied) return;
    // A preserved v1 identity keeps its original country/CID pairing even if a
    // later dashboard setting differs; no silent identity replacement occurs.
    const country = String(identity.country || configuredCountry).toLowerCase();
    const cid = identityManager.getCID(country, identity);
    const query = {
      app_version: VH_APP_VERSION,
      countryCode: country,
      uuid: identity.uuid,
      fid: identity.fid || '',
      cid,
      device_name: identity.deviceName || 'Vine Drop Hub Legacy Receiver'
    };
    const signature = JSON.stringify({ url: VH_WS_URL, query });

    if (vhSocket && vhSocketSignature === signature) {
      if (!vhSocket.connected) vhSocket.connect();
      return;
    }

    if (vhSocket) destroyVhSocket();
    const socketOptions = {
      autoConnect: false,
      transports: ['websocket'],
      reconnection: false,
      forceNode: true,
      rejectUnauthorized: true,
      query
    };
    if (vhProxyAgent) {
      // Both layers use the destination-locked direct proxy. UV remains in the
      // Gluetun network namespace and never uses this agent.
      socketOptions.agent = vhProxyAgent;
      socketOptions.transportOptions = { websocket: { agent: vhProxyAgent } };
    }

    const socket = ioClient(VH_WS_URL, socketOptions);
    vhSocket = socket;
    vhSocketSignature = signature;
    bindVhSocketHandlers(socket);
    socket.connect();
  } catch (error) {
    if (!isVhEnabled()) return;
    vhApplicationReady = false;
    vhStatus = `VH setup failed: ${error.message}`;
    broadcastLocal('status', { uvStatus, vhStatus, svStatus });
    console.error('[VH WS] Setup failure:', describeVhError(error));
    reportVhFeedProblem(`Setup failure: ${error.message}`, 'vh-connectivity');
    scheduleVhSetupRetry();
  } finally {
    vhConnectInFlight = false;
  }
}


// ============================================================================
// REST API
// ============================================================================

// PC ORDER COMPANION ---------------------------------------------------------
// The endpoint remains on the existing localhost-only dashboard listener. The
// Windows browser reaches it only through a persistent SSH local forward.
app.get('/api/order-agent/status', (_req, res) => {
  res.json({
    status: orderCoordinator.publicStatus(),
    rules: orderCoordinator.publicRules(),
    watches: orderCoordinator.publicWatches(500),
    safety: orderCoordinator.publicSafety(),
    jobs: orderCoordinator.recentJobs(100),
    websocketPath: '/ws-feed?role=order-agent',
    companionDownload: '/downloads/vine-drop-hub-pc-companion.zip'
  });
});

app.get('/api/order-agent/jobs', (req, res) => {
  res.json({ jobs: orderCoordinator.recentJobs(req.query?.limit) });
});

app.post('/api/order-agent/variant-lookup/amazon', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const declaredBytes = Number(req.get('content-length'));
  if (Number.isFinite(declaredBytes) && declaredBytes > 4096) {
    return res.status(413).json({
      error: 'Amazon variant lookup request exceeds the 4 KiB limit.',
      code: 'variant_lookup_request_too_large'
    });
  }
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body)
    ? req.body
    : {};
  if (Buffer.byteLength(JSON.stringify(body), 'utf8') > 4096) {
    return res.status(413).json({
      error: 'Amazon variant lookup request exceeds the 4 KiB limit.',
      code: 'variant_lookup_request_too_large'
    });
  }
  const requestId = String(body.requestId || '').trim();
  const seedId = String(body.seedId || '').trim();
  const asin = String(body.asin || '').trim().toUpperCase();
  if (
    !/^[A-Za-z0-9._:-]{12,120}$/.test(requestId) ||
    !/^uv-variant-[A-Za-z0-9_-]{24}$/.test(seedId) ||
    !/^[A-Z0-9]{10}$/.test(asin) ||
    Object.keys(body).some(key => !['requestId', 'seedId', 'asin'].includes(key))
  ) {
    return res.status(400).json({
      error: 'A one-time request ID, current UV Explorer seed, and parent ASIN are required.',
      code: 'variant_lookup_request_invalid'
    });
  }
  const now = Date.now();
  pruneUvExplorerVariantState(now);
  if (uvExplorerVariantRequestIds.has(requestId)) {
    return res.status(409).json({
      error: 'This one-time Amazon variant lookup request was already used.',
      code: 'variant_lookup_replayed'
    });
  }
  let seed;
  try {
    seed = resolveUvExplorerVariantSeed(seedId, asin, now);
  } catch (error) {
    return res.status(error?.code === 'variant_seed_expired' ? 410 : 400).json({
      error: String(error.message || error).slice(0, 500),
      code: String(error.code || 'variant_seed_invalid').slice(0, 80)
    });
  }
  uvExplorerVariantRequestIds.set(requestId, now + UV_EXPLORER_VARIANT_REQUEST_TTL_MS);
  pruneUvExplorerVariantState(now);

  try {
    const hydratedSeed = await fetchUvExplorerEnrollmentSeed(seed);
    const result = await orderCoordinator.requestAmazonVariantLookup({
      lookupId: requestId,
      asin: hydratedSeed.asin,
      queue: hydratedSeed.queue,
      enrollmentGuid: hydratedSeed.enrollmentGuid
    });
    return res.json({
      success: true,
      source: 'amazon_companion',
      parentAsin: hydratedSeed.asin,
      variants: result.variants,
      discardedVariants: result.discardedVariants,
      persisted: false,
      mergedIntoLiveFeed: false,
      orderAttempted: false,
      automaticRetry: false,
      fallbackSourceUsed: false
    });
  } catch (error) {
    const code = String(error?.code || 'amazon_variant_lookup_unavailable').slice(0, 80);
    const status = code === 'variant_lookup_timeout'
      ? 504
      : ['agent_offline', 'companion_update_required', 'variant_lookup_in_flight', 'agent_busy'].includes(code)
        ? 409
        : code.startsWith('uv_variant_metadata_')
          ? 502
          : 502;
    return res.status(status).json({
      error: String(error?.message || 'Amazon variants are unavailable').slice(0, 500),
      code,
      automaticRetry: false,
      fallbackSourceUsed: false
    });
  }
});

app.post('/api/order-agent/pair', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  if (body.confirmation !== ORDER_PAIR_CONFIRMATION) {
    return res.status(400).json({ error: `Confirmation must exactly match: ${ORDER_PAIR_CONFIRMATION}` });
  }
  let pairing;
  try {
    pairing = orderCoordinator.issuePairing({ agentLabel: body.agentLabel });
  } catch (_) {
    return res.status(500).json({ error: 'The new PC pairing could not be saved; ordering remains disabled. Retry after checking VPS storage.' });
  }
  broadcastLocal('order_agent_event', {
    eventType: 'pairing_created',
    status: orderCoordinator.publicStatus()
  });
  return res.json({
    success: true,
    ...pairing,
    warning: 'This pairing secret is displayed once. Enter it only in the local Chrome companion.'
  });
});

app.post('/api/order-agent/revoke', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  if (body.confirmation !== ORDER_REVOKE_CONFIRMATION) {
    return res.status(400).json({ error: `Confirmation must exactly match: ${ORDER_REVOKE_CONFIRMATION}` });
  }
  try {
    orderCoordinator.revokePairing();
  } catch (_) {
    return res.status(500).json({ error: 'The PC pairing revocation could not be saved; ordering remains disabled in this process. Retry before restarting.' });
  }
  broadcastLocal('order_agent_event', {
    eventType: 'pairing_revoked',
    status: orderCoordinator.publicStatus()
  });
  return res.json({ success: true, status: orderCoordinator.publicStatus() });
});

app.post('/api/order-agent/disconnect', (_req, res) => {
  orderCoordinator.disconnect('Disconnected from dashboard');
  return res.json({ success: true, status: orderCoordinator.publicStatus() });
});

app.post('/api/order-agent/rules', (req, res) => {
  try {
    const rules = orderCoordinator.updateRuleSet(req.body && typeof req.body === 'object' ? req.body : {});
    broadcastLocal('order_agent_event', {
      eventType: 'rules_updated',
      rules,
      status: orderCoordinator.publicStatus()
    });
    return res.json({ success: true, rules, status: orderCoordinator.publicStatus() });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.post('/api/order-agent/rules/preview', (req, res) => {
  try {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const draft = body.rules && typeof body.rules === 'object' ? body.rules : orderCoordinator.publicRules();
    const candidates = [...allItems]
      .filter(item => isLiveItem(item) && !item.isHide && !item.isHiddenManual)
      .sort((left, right) => Number(right.last_live_event_ms || right.date_added_ms || 0) - Number(left.last_live_event_ms || left.date_added_ms || 0))
      .slice(0, 200);
    return res.json({ success: true, preview: orderCoordinator.previewRules(candidates, draft) });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.get('/api/order-agent/watches', (_req, res) => {
  res.json(orderCoordinator.publicWatches(500));
});

app.post('/api/order-agent/watches', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  // Do not consult a merged or persisted card to decide whether this watch may
  // be armed. Eligibility begins at the durable armedAtMs boundary and can be
  // satisfied only by a separate later trusted live event.
  try {
    const result = orderCoordinator.armWatch(body);
    return res.status(result.created ? 201 : 200).json({
      success: true,
      ...result,
      watches: orderCoordinator.publicWatches(500),
      status: orderCoordinator.publicStatus()
    });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.post('/api/order-agent/watches/:watchId/cancel', (req, res) => {
  try {
    const watch = orderCoordinator.cancelWatch(req.params.watchId);
    return res.json({
      success: true,
      watch,
      watches: orderCoordinator.publicWatches(500),
      status: orderCoordinator.publicStatus()
    });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.post('/api/order-agent/safety/pause', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  try {
    const safety = orderCoordinator.setAutomaticPause(body.paused === true, {
      confirmation: body.confirmation,
      reason: body.reason
    });
    return res.json({ success: true, safety, status: orderCoordinator.publicStatus() });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.post('/api/order-agent/safety/acknowledge', (req, res) => {
  try {
    const safety = orderCoordinator.acknowledgeSafetyPause(req.body?.confirmation);
    return res.json({ success: true, safety, status: orderCoordinator.publicStatus() });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.get('/api/order-agent/export', (_req, res) => {
  res.json(orderCoordinator.exportConfiguration());
});

app.post('/api/order-agent/import', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  let configurationBytes = Infinity;
  try {
    configurationBytes = Buffer.byteLength(JSON.stringify(body.configuration ?? null), 'utf8');
  } catch (_) {}
  if (configurationBytes > 1024 * 1024) {
    return res.status(413).json({ error: 'Order-automation import exceeds the 1 MiB limit' });
  }
  if (body.confirmation !== ORDER_IMPORT_CONFIRMATION) {
    return res.status(400).json({ error: `Confirmation must exactly match: ${ORDER_IMPORT_CONFIRMATION}` });
  }
  try {
    const result = orderCoordinator.importConfiguration(body.configuration);
    return res.json({ success: true, ...result, status: orderCoordinator.publicStatus() });
  } catch (error) {
    return res.status(400).json({ error: String(error.message || error).slice(0, 500) });
  }
});

app.post('/api/order-agent/jobs', (req, res) => {
  const asin = String(req.body?.asin || '').trim().toUpperCase();
  const item = allItems.find(candidate => candidate.asin === asin && isLiveItem(candidate));
  if (!item) return res.status(404).json({ error: 'Live item not found' });
  if (item.unavailable) return res.status(409).json({ error: 'Item is marked unavailable' });
  const outcome = orderCoordinator.dispatchManual(item);
  if (!outcome.ok) return res.status(409).json(outcome);
  return res.json({ success: true, job: outcome.job, status: orderCoordinator.publicStatus() });
});

app.get('/api/vpn/status', (req, res) => {
  res.json(publicVpnManagerStatus());
});

app.post('/api/vpn/profile', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  try {
    ensureVpnManagerReady();
    if (body.confirmation !== VPN_UPLOAD_CONFIRMATION) {
      return res.status(400).json({
        error: `Confirmation must exactly match: ${VPN_UPLOAD_CONFIRMATION}`
      });
    }

    // Both .conf upload and manual WireGuard fields converge here into one
    // canonical private config. Only that private candidate enters the inbox;
    // request metadata and dashboard status contain no key material.
    const profile = validateVpnSubmission(body);
    const requestId = crypto.randomUUID();
    const submittedAt = new Date().toISOString();
    const candidateSha256 = crypto
      .createHash('sha256')
      .update(profile.content, 'utf8')
      .digest('hex');

    // Discard Express' parsed secret-bearing values before filesystem I/O and
    // before any possible error logging. profile.content remains only in this
    // narrow stack frame until it is written mode 0600.
    body.content = '';
    if (body.wireguard && typeof body.wireguard === 'object') {
      body.wireguard.privateKey = '';
      body.wireguard.presharedKey = '';
    }

    queueVpnManagerRequest(
      {
        schemaVersion: 2,
        action: 'apply',
        requestId,
        vpnProtocol: profile.vpnProtocol,
        originalName: profile.filename,
        submittedAt,
        sha256: candidateSha256,
        profile: {
          vpnProtocol: profile.vpnProtocol,
          transport: profile.transport,
          endpointCount: profile.remotes.length,
          endpointFamily: profile.endpointFamily || null,
          tunnelFamilies: profile.tunnelFamilies,
          fingerprint: profile.fingerprint.slice(0, 16)
        }
      },
      profile.content,
      profile.candidateExtension
    );

    console.log(
      `[VPN Profile] Queued ${requestId} (${profile.vpnProtocol}/${profile.transport}, ${profile.remotes.length} endpoint(s), fingerprint ${profile.fingerprint.slice(0, 16)}).`
    );
    res.status(202).json({
      success: true,
      requestId,
      state: 'queued',
      submittedAt,
      profile: {
        filename: profile.filename,
        source: profile.source,
        vpnProtocol: profile.vpnProtocol,
        transport: profile.transport,
        endpointCount: profile.remotes.length,
        endpointFamily: profile.endpointFamily || null,
        tunnelFamilies: profile.tunnelFamilies,
        profileDnsOverridden: profile.ignoredProfileDns === true,
        fingerprint: profile.fingerprint.slice(0, 16)
      },
      message:
        'Profile queued. The dashboard may disconnect while VPN and application containers are recreated.'
    });
  } catch (error) {
    const safeError = String(error.message || error)
      .replace(/[A-Za-z0-9+/]{43}=/g, '[redacted-key]')
      .replace(/(PrivateKey|PresharedKey)\s*[=:]\s*\S+/gi, '$1=[redacted]')
      .slice(0, 1000);
    console.error('[VPN Profile] Request rejected:', safeError);
    res.status(error.statusCode || 400).json({ error: safeError });
  } finally {
    body.content = '';
    if (body.wireguard && typeof body.wireguard === 'object') {
      body.wireguard.privateKey = '';
      body.wireguard.presharedKey = '';
    }
  }
});

app.post('/api/vpn/rollback', (req, res) => {
  try {
    const status = ensureVpnManagerReady();
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if (body.confirmation !== VPN_ROLLBACK_CONFIRMATION) {
      return res.status(400).json({
        error: `Confirmation must exactly match: ${VPN_ROLLBACK_CONFIRMATION}`
      });
    }
    if (!status.canRollback) {
      return res.status(409).json({ error: 'No dashboard-managed VPN backup is available.' });
    }

    const requestId = crypto.randomUUID();
    const submittedAt = new Date().toISOString();
    queueVpnManagerRequest({
      schemaVersion: 2,
      action: 'rollback',
      requestId,
      submittedAt
    });
    console.log(`[VPN Profile] Queued manual rollback ${requestId}.`);
    res.status(202).json({
      success: true,
      requestId,
      state: 'queued',
      submittedAt,
      message: 'Rollback queued. The dashboard will reconnect after the previous profile is restored.'
    });
  } catch (error) {
    console.error('[VPN Profile] Rollback rejected:', error.message);
    res.status(error.statusCode || 400).json({ error: error.message });
  }
});

let svOnboardingInFlight = false;
function noStore(res) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('Pragma', 'no-cache');
}

app.get('/api/sv/status', async (req, res) => {
  noStore(res);
  if (!svClient) await initializeSmartViner();
  res.json({
    ...svStatus,
    configuredEnabled: Boolean(config.enableSV),
    egressReady: Boolean(svHttpsProxyAgent),
    onboardingTransport: 'SSH-tunnel-only dashboard',
    passwordStored: false,
    personalRfyEnabled: false,
    historyEnabled: false,
    catalogueEnabled: false,
    gapRecoveryEnabled: false
  });
});

app.post('/api/sv/onboard', async (req, res) => {
  noStore(res);
  const email = String(req.body?.email || '');
  const password = String(req.body?.password || '');
  // Clear Express' parsed request object before every early return as well as
  // before the one permitted login call. The password is never retained there.
  if (req.body && typeof req.body === 'object') req.body.password = '';
  if (!svHttpsProxyAgent) return res.status(503).json({ error: 'Dedicated SmartViner egress is unavailable.' });
  if (svOnboardingInFlight) return res.status(409).json({ error: 'A SmartViner sign-in is already in progress.' });
  svOnboardingInFlight = true;
  try {
    if (!svClient) await initializeSmartViner();
    const result = await svClient.onboard({ email, password });
    svStatus = {
      ...svClient.publicStatus(),
      configuredEnabled: Boolean(config.enableSV),
      egressReady: Boolean(svHttpsProxyAgent)
    };
    addActivity('sv_account_configured', {
      source: 'SV', accountId: result.account.id, marketplaceId: result.account.marketplaceId
    });
    res.json({ success: true, account: result.account, status: svStatus });
  } catch (error) {
    const status = [400, 401, 403, 409, 422].includes(Number(error?.status)) ? Number(error.status) : 400;
    res.status(status).json({ error: String(error?.message || 'SmartViner sign-in failed').slice(0, 500) });
  } finally {
    svOnboardingInFlight = false;
  }
});

app.post('/api/sv/enable', async (req, res) => {
  noStore(res);
  if (typeof req.body?.enabled !== 'boolean') return res.status(400).json({ error: 'enabled must be true or false.' });
  if (req.body.enabled && !svHttpsProxyAgent) return res.status(503).json({ error: 'Dedicated SmartViner egress is unavailable.' });
  if (!svClient) await initializeSmartViner();
  const previous = Boolean(config.enableSV);
  config.enableSV = req.body.enabled;
  if (!saveJSON(CONFIG_FILE, config)) {
    config.enableSV = previous;
    return res.status(500).json({ error: 'Could not save SmartViner enablement.' });
  }
  await svClient.setEnabled(config.enableSV);
  evaluateFeedHealth();
  res.json({ success: true, status: svClient.publicStatus() });
});

app.post('/api/sv/reconnect', async (req, res) => {
  noStore(res);
  if (!config.enableSV) return res.status(409).json({ error: 'SmartViner is disabled.' });
  if (!svHttpsProxyAgent) return res.status(503).json({ error: 'Dedicated SmartViner egress is unavailable.' });
  if (!svClient) await initializeSmartViner();
  await svClient.reconnect();
  res.json({ success: true, status: svClient.publicStatus() });
});

app.post('/api/sv/disconnect', async (req, res) => {
  noStore(res);
  if (req.body?.confirmation !== 'DISCONNECT SMARTVINER') {
    return res.status(400).json({ error: 'Confirmation must exactly match: DISCONNECT SMARTVINER' });
  }
  if (svOnboardingInFlight) {
    return res.status(409).json({ error: 'A SmartViner account operation is already in progress.' });
  }
  svOnboardingInFlight = true;
  try {
    if (!svClient) await initializeSmartViner();
    await svClient.disconnectAccount();
    addActivity('sv_account_disconnected', { source: 'SV' });
    res.json({ success: true, status: svClient.publicStatus() });
  } catch (error) {
    res.status(500).json({ error: String(error?.message || 'Could not remove SmartViner session').slice(0, 500) });
  } finally {
    svOnboardingInFlight = false;
  }
});

app.get('/api/status', (req, res) => {
  const liveItems = allItems.filter(isLiveItem);
  const uvCount = liveItems.filter(item => (item.sources || []).includes('UV')).length;
  const vhCount = liveItems.filter(item => (item.sources || []).includes('VH')).length;
  const svCount = liveItems.filter(item => (item.sources || []).includes('SV')).length;
  const bothCount = liveItems.filter(
    item => (item.sources || []).includes('UV') && (item.sources || []).includes('VH')
  ).length;
  const multiSourceCount = liveItems.filter(item => normalizeSourceList(item.sources).length > 1).length;
  const threeSourceCount = liveItems.filter(item => normalizeSourceList(item.sources).length === 3).length;

  res.json({
    uvStatus,
    vhStatus,
    svStatus,
    uvAuthenticated,
    configuredVHEnabled: Boolean(config.enableVH),
    configuredSVEnabled: Boolean(config.enableSV),
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED,
    vhLoadHistory: false,
    vhTransportConnected: Boolean(vhSocket?.connected),
    vhApplicationReady,
    vhDenied,
    totalItems: liveItems.length,
    storedItems: allItems.length,
    uvCount,
    vhCount,
    svCount,
    bothCount,
    multiSourceCount,
    threeSourceCount,
    zeroEtvCount: liveItems.filter(item => item.isZeroEtv).length,
    highlightCount: liveItems.filter(item => item.isHighlight).length,
    categoryPriorityCount: liveItems.filter(item => item.isCategoryPriority).length,
    selectedPriorityCategoryCount: config.priorityCategoryIds.length,
    rfyCount: liveItems.filter(item => String(item.queue).toUpperCase() === 'RFY').length,
    afaCount: liveItems.filter(item => String(item.queue).toUpperCase() === 'AFA').length,
    brendaOriginCount: liveItems.filter(item =>
      normalizeAlertOriginList(
        item.alertOrigins?.length ? item.alertOrigins : [item.alertOrigin, item.origin]
      ).includes('brenda')
    ).length,
    redropOriginCount: liveItems.filter(item =>
      normalizeAlertOriginList(
        item.alertOrigins?.length ? item.alertOrigins : [item.alertOrigin, item.origin]
      ).includes('redrop')
    ).length,
    pinnedCount: pinnedAsins.size,
    domain: config.domain,
    feedHealth: publicFeedHealth(),
    orderAgent: orderCoordinator.publicStatus()
  });
});

app.get('/api/health', (req, res) => {
  res.json({
    ...publicFeedHealth(),
    uvStatus,
    vhStatus,
    svStatus,
    uvAuthenticated,
    vhConnected: Boolean(vhSocket?.connected),
    vhApplicationReady,
    vhDenied,
    orderAgent: orderCoordinator.publicStatus()
  });
});

app.get('/api/items', (req, res) => {
  let items = [...allItems];
  const {
    search,
    asin,
    title,
    etv_min,
    etv_max,
    price_min,
    price_max,
    queue,
    source,
    alert_origin,
    uv_alert_queue_id,
    zero_etv,
    highlight,
    vh_rfy_only = 'false',
    include_history = 'false',
    show_hidden = 'false',
    pinned_only = 'false',
    page = 1,
    limit = 60
  } = req.query;

  // Live Feed excludes catalog/history-only records by default. They remain in
  // storage so a later real event can be promoted and enriched correctly.
  if (include_history !== 'true') items = items.filter(isLiveItem);

  // Local-only passive explorer filter. It never requests VH history or the
  // signed VHelper Item Explorer; it selects retained genuine live detections
  // whose source-specific VH queue was RFY.
  if (vh_rfy_only === 'true') items = items.filter(isPassiveVhRfyItem);

  if (show_hidden !== 'true') {
    items = items.filter(item => !item.isHide && !hiddenAsins.has(item.asin));
  }
  if (pinned_only === 'true') items = items.filter(item => pinnedAsins.has(item.asin));

  const query = String(search || title || asin || '').toLowerCase().trim();
  if (query) {
    items = items.filter(
      item =>
        String(item.title || '').toLowerCase().includes(query) ||
        String(item.asin || '').toLowerCase().includes(query) ||
        String(item.brand || '').toLowerCase().includes(query) ||
        String(item.firstTwoWords || '').toLowerCase().includes(query)
    );
  }

  if (queue && queue !== 'ALL') {
    items = items.filter(item => String(item.queue || '').toLowerCase() === queue.toLowerCase());
  }

  if (source && source !== 'ALL') {
    const expectedSource = String(source).toUpperCase();
    if (expectedSource === 'BOTH') {
      // Preserve the legacy filter's exact UV+VH meaning.
      items = items.filter(
        item => (item.sources || []).includes('UV') && (item.sources || []).includes('VH')
      );
    } else if (expectedSource === 'MULTI') {
      items = items.filter(item => normalizeSourceList(item.sources).length > 1);
    } else if (expectedSource.endsWith('_ONLY')) {
      const onlySource = expectedSource.slice(0, -5);
      items = items.filter(item => {
        const sources = normalizeSourceList(item.sources);
        return sources.length === 1 && sources[0] === onlySource;
      });
    } else if (['UV', 'VH', 'SV'].includes(expectedSource)) {
      items = items.filter(item => normalizeSourceList(item.sources).includes(expectedSource));
    }
  }

  if (alert_origin && alert_origin !== 'ALL') {
    const expectedOrigin = normalizeAlertOrigin(alert_origin);
    items = items.filter(item =>
      normalizeAlertOriginList(
        item.alertOrigins?.length ? item.alertOrigins : [item.alertOrigin, item.origin]
      ).includes(expectedOrigin)
    );
  }

  if (uv_alert_queue_id && uv_alert_queue_id !== 'ALL') {
    const expectedQueueId = String(uv_alert_queue_id);
    items = items.filter(item =>
      Array.isArray(item.uvAlertQueueIds) && item.uvAlertQueueIds.includes(expectedQueueId)
    );
  }

  if (zero_etv === 'true') items = items.filter(item => item.isZeroEtv);
  if (highlight === 'true') items = items.filter(item => item.isHighlight);

  const etvMin = Number(etv_min);
  const etvMax = Number(etv_max);
  const priceMin = Number(price_min);
  const priceMax = Number(price_max);

  if (etv_min !== undefined && Number.isFinite(etvMin)) {
    items = items.filter(item => parseMoney(item.etv_min ?? item.etv, NaN) >= etvMin);
  }
  if (etv_max !== undefined && Number.isFinite(etvMax)) {
    items = items.filter(item => parseMoney(item.etv_max ?? item.etv, NaN) <= etvMax);
  }
  if (price_min !== undefined && Number.isFinite(priceMin)) {
    items = items.filter(item => parseMoney(item.price, NaN) >= priceMin);
  }
  if (price_max !== undefined && Number.isFinite(priceMax)) {
    items = items.filter(item => parseMoney(item.price, NaN) <= priceMax);
  }

  sortItemsArray(items);
  const total = items.length;
  const currentPage = Math.max(1, parseInt(page, 10) || 1);
  const pageLimit = Math.max(1, Math.min(500, parseInt(limit, 10) || 60));
  const start = (currentPage - 1) * pageLimit;

  res.json({
    items: items.slice(start, start + pageLimit).map(withOrderRuleMatch),
    total,
    page: currentPage,
    totalPages: Math.ceil(total / pageLimit) || 1,
    limit: pageLimit,
    status: { uvStatus, vhStatus, svStatus }
  });
});

app.get('/api/items/:asin', (req, res) => {
  const item = allItems.find(candidate => candidate.asin === req.params.asin);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  res.json(withOrderRuleMatch(item));
});

app.post('/api/delete-item', (req, res) => {
  const { asin } = req.body;
  if (!asin) return res.status(400).json({ error: 'ASIN required' });

  const removedItems = allItems.filter(item => item.asin === asin);
  const memoryResult = rememberClearedRecords(removedItems);
  if (!memoryResult.persisted) {
    return res.status(500).json({ error: 'Could not persist cleared-item memory; item was not cleared.' });
  }
  allItems = allItems.filter(item => item.asin !== asin);
  pinnedAsins.delete(asin);
  dismissedPriorityAsins.delete(asin);
  hiddenAsins.delete(asin);
  const legacyClear = config.clearedItemSuppressionHours === 0;
  if (legacyClear) notifiedAt.delete(asin);

  persistItemsDelete([asin]);
  saveJSON(PINNED_FILE, [...pinnedAsins]);
  saveJSON(DISMISSED_PRIORITY_FILE, [...dismissedPriorityAsins]);
  saveJSON(HIDDEN_FILE, [...hiddenAsins]);
  if (legacyClear && !livePersistence?.deleteNotified([asin])) persistNotified();
  broadcastLocal('item_deleted', { asin });
  res.json({ success: true, asin, remembered: removedItems.length > 0 && !legacyClear });
});

app.post('/api/delete-items', (req, res) => {
  const { asins } = req.body;
  if (!Array.isArray(asins) || !asins.length) return res.json({ success: true });

  const set = new Set(asins);
  const removedItems = allItems.filter(item => set.has(item.asin));
  const memoryResult = rememberClearedRecords(removedItems);
  if (!memoryResult.persisted) {
    return res.status(500).json({ error: 'Could not persist cleared-item memory; items were not cleared.' });
  }
  allItems = allItems.filter(item => !set.has(item.asin));
  const legacyClear = config.clearedItemSuppressionHours === 0;
  asins.forEach(asin => {
    pinnedAsins.delete(asin);
    dismissedPriorityAsins.delete(asin);
    hiddenAsins.delete(asin);
    if (legacyClear) notifiedAt.delete(asin);
  });

  persistItemsDelete(asins);
  saveJSON(PINNED_FILE, [...pinnedAsins]);
  saveJSON(DISMISSED_PRIORITY_FILE, [...dismissedPriorityAsins]);
  saveJSON(HIDDEN_FILE, [...hiddenAsins]);
  if (legacyClear && !livePersistence?.deleteNotified(asins)) persistNotified();
  broadcastLocal('items_deleted', { asins });
  res.json({ success: true, remembered: legacyClear ? 0 : removedItems.length });
});

app.post('/api/clear-all', (req, res) => {
  const clearedRecords = allItems;
  const memoryResult = rememberClearedRecords(clearedRecords);
  if (!memoryResult.persisted) {
    return res.status(500).json({ error: 'Could not persist cleared-item memory; view was not cleared.' });
  }
  allItems = [];
  activityLog = [];
  pinnedAsins.clear();
  dismissedPriorityAsins.clear();
  hiddenAsins.clear();
  const legacyClear = config.clearedItemSuppressionHours === 0;
  if (legacyClear) notifiedAt.clear();

  if (!livePersistence?.clearItems()) saveJSON(ITEMS_FILE, []);
  if (!livePersistence?.clearActivity()) saveJSON(ACTIVITY_FILE, []);
  saveJSON(PINNED_FILE, []);
  saveJSON(DISMISSED_PRIORITY_FILE, []);
  saveJSON(HIDDEN_FILE, []);
  if (legacyClear && !livePersistence?.clearNotified()) saveJSON(NOTIFIED_FILE, {});
  broadcastLocal('clear_all', {});
  res.json({
    success: true,
    remembered: memoryResult.remembered,
    suppressionHours: config.clearedItemSuppressionHours
  });
});

app.get('/api/cleared-items/status', (req, res) => {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  pruneAndPersistClearedItemMemory();
  res.json(
    clearedItemMemoryStatus(clearedItemMemory, {
      suppressionHours: config.clearedItemSuppressionHours,
      maxEntries: MAX_CLEARED_ITEMS
    })
  );
});

app.post('/api/cleared-items/reset', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  if (body.confirmation !== CLEARED_MEMORY_RESET_CONFIRMATION) {
    return res.status(400).json({
      error: `Confirmation must exactly match: ${CLEARED_MEMORY_RESET_CONFIRMATION}`
    });
  }
  const removed = clearedItemMemory.size;
  const previousMemory = clearedItemMemory;
  const previousNeedsPersistence = clearedItemMemoryNeedsPersistence;
  clearedItemMemory = new Map();
  clearedItemMemoryNeedsPersistence = true;
  if (!persistClearedItemMemory()) {
    clearedItemMemory = previousMemory;
    clearedItemMemoryNeedsPersistence = previousNeedsPersistence;
    return res.status(500).json({ error: 'Could not persist the cleared-item memory reset.' });
  }
  res.json({ success: true, removed });
});

app.get('/api/pinned', (req, res) => res.json([...pinnedAsins]));

app.post('/api/pin/toggle', (req, res) => {
  const { asin } = req.body;
  if (!asin) return res.status(400).json({ error: 'ASIN required' });

  const isPinned = !pinnedAsins.has(asin);
  if (isPinned) pinnedAsins.add(asin);
  else pinnedAsins.delete(asin);

  const item = allItems.find(candidate => candidate.asin === asin);
  if (item) item.isPinned = isPinned;

  sortItemsArray(allItems);
  saveJSON(PINNED_FILE, [...pinnedAsins]);
  persistItemsReplace();
  broadcastLocal('pinned_updated', { asin, isPinned, pinnedAsins: [...pinnedAsins] });
  res.json({ success: true, isPinned, pinnedAsins: [...pinnedAsins] });
});

app.post('/api/priority/dismiss', (req, res) => {
  const { asin, all } = req.body;
  if (all) {
    allItems.forEach(item => {
      if (item.isHighlight) dismissedPriorityAsins.add(item.asin);
    });
  } else if (asin) {
    dismissedPriorityAsins.add(asin);
  }

  allItems.forEach(item => {
    item.isPriorityDismissed = dismissedPriorityAsins.has(item.asin);
  });
  sortItemsArray(allItems);
  saveJSON(DISMISSED_PRIORITY_FILE, [...dismissedPriorityAsins]);
  persistItemsReplace();
  broadcastLocal('priority_dismissed', {
    asin,
    all: Boolean(all),
    dismissedPriorityAsins: [...dismissedPriorityAsins]
  });
  res.json({ success: true, dismissedPriorityAsins: [...dismissedPriorityAsins] });
});

app.get('/api/hidden', (req, res) => res.json([...hiddenAsins]));

app.post('/api/hidden/toggle', (req, res) => {
  const { asin } = req.body;
  if (!asin) return res.status(400).json({ error: 'ASIN required' });

  const isHidden = !hiddenAsins.has(asin);
  if (isHidden) hiddenAsins.add(asin);
  else hiddenAsins.delete(asin);

  const item = allItems.find(candidate => candidate.asin === asin);
  if (item) item.isHiddenManual = isHidden;
  saveJSON(HIDDEN_FILE, [...hiddenAsins]);
  persistItemsReplace();
  broadcastLocal('hidden_updated', [...hiddenAsins]);
  res.json({ success: true, hidden: isHidden });
});

app.get('/api/keywords', (req, res) => res.json(keywords));

function recheckAllKeywords() {
  refreshCompiledPriorityRules();
  allItems.forEach(item => {
    const categoryId = trustedStoredUvCategoryId(item);
    const category = getUvCategory(categoryId);
    const matches = checkKeywordMatches(item.title, item.price, item.etv, categoryId);
    item.categoryId = categoryId;
    item.categoryName = category?.name || null;
    item.categoryEmoji = category?.emoji || null;
    item.categorySource = categoryId ? 'UV' : null;
    if (!categoryId) item.categoryObservedAt = null;
    item.isHighlight = matches.isHighlight;
    item.isPriceHighlight = matches.isPriceHighlight;
    item.isCategoryPriority = matches.isCategoryPriority;
    item.priorityReasons = matches.priorityReasons;
    item.isHide = matches.isHide;
    item.isBlur = matches.isBlur;
  });
  sortItemsArray(allItems);
  persistItemsReplace();
  broadcastLocal('keywords_updated', keywords);
}

app.post('/api/keywords', (req, res) => {
  const { type, keyword } = req.body;
  if (!['highlight', 'hide', 'blur'].includes(type)) {
    return res.status(400).json({ error: 'Invalid keyword group type' });
  }

  const value = String(keyword || '').trim();
  if (!value) return res.status(400).json({ error: 'Keyword required' });

  if (!keywords[type]) keywords[type] = [];
  if (!keywords[type].some(item => item.toLowerCase() === value.toLowerCase())) {
    keywords[type].push(value);
    saveJSON(KEYWORDS_FILE, keywords);
    recheckAllKeywords();
  }
  res.json({ success: true, keywords });
});

app.post('/api/keywords/delete', (req, res) => {
  const { type, keyword } = req.body;
  if (!type || !keywords[type]) return res.status(400).json({ error: 'Invalid type' });

  keywords[type] = keywords[type].filter(
    item => item.toLowerCase() !== String(keyword || '').toLowerCase().trim()
  );
  saveJSON(KEYWORDS_FILE, keywords);
  recheckAllKeywords();
  res.json({ success: true, keywords });
});

app.get('/api/categories', (req, res) => {
  res.json({
    categories: UV_CATEGORY_CATALOG,
    priorityCategoryIds: config.priorityCategoryIds,
    selectedCount: config.priorityCategoryIds.length
  });
});

app.post('/api/categories/priority', (req, res) => {
  const rawIds = req.body?.categoryIds;
  if (!Array.isArray(rawIds)) {
    return res.status(400).json({ error: 'categoryIds must be an array' });
  }

  const normalizedIds = normalizePriorityCategoryIds(rawIds);
  const invalidIds = rawIds.filter(value => {
    const id = normalizeUvCategoryId(value);
    return !id || !UV_CATEGORY_ID_SET.has(id);
  });
  if (invalidIds.length) {
    return res.status(400).json({
      error: 'One or more category IDs are not in the UV 26.9.38 category catalog',
      invalidCategoryIds: [...new Set(invalidIds.map(value => String(value)))]
    });
  }

  config.priorityCategoryIds = normalizedIds;
  saveJSON(CONFIG_FILE, config);
  recheckAllKeywords();
  broadcastLocal('priority_categories_updated', {
    priorityCategoryIds: normalizedIds
  });
  addActivity('priority_categories_updated', {
    selectedCategoryIds: normalizedIds,
    selectedCategories: normalizedIds.map(id => getUvCategory(id)?.name).filter(Boolean)
  });
  res.json({
    success: true,
    priorityCategoryIds: normalizedIds,
    selectedCount: normalizedIds.length
  });
});

app.post('/api/vh/item-explorer/search', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const declaredBytes = Number(req.get('content-length'));
  let parsedBytes = Infinity;
  try {
    parsedBytes = Buffer.byteLength(JSON.stringify(req.body ?? null), 'utf8');
  } catch (_) {}
  if (
    (Number.isFinite(declaredBytes) && declaredBytes > 16 * 1024) ||
    parsedBytes > 16 * 1024
  ) {
    return res.status(413).json({
      error: 'Item Explorer search request exceeds the 16 KiB limit.',
      code: 'item_explorer_request_too_large'
    });
  }

  let search;
  try {
    search = normalizeItemExplorerRequest(req.body);
  } catch (error) {
    const statusCode = error instanceof ItemExplorerValidationError ? error.statusCode : 400;
    const code = error instanceof ItemExplorerValidationError
      ? error.code
      : 'invalid_item_explorer_request';
    return res.status(statusCode).json({ error: error.message, code });
  }

  const now = Date.now();
  if (hasSeenVhSignedRequest(search.requestId, now)) {
    return res.status(409).json({
      error: 'This one-time Item Explorer search request was already used.',
      code: 'replayed_item_explorer_request'
    });
  }
  if (!isVhEnabled()) {
    return res.status(409).json({
      error: 'VHelper is disabled; Item Explorer did not run.',
      code: 'vh_disabled'
    });
  }
  if (vhSignedRequestInFlight) {
    return res.status(409).json({
      error: 'Another signed VHelper request is already in progress.',
      code: 'vh_signed_request_in_flight'
    });
  }
  const retryAfterSeconds = vhSignedRetryAfterSeconds(now);
  if (retryAfterSeconds > 0) {
    res.set('Retry-After', String(retryAfterSeconds));
    return res.status(429).json({
      error: `VHelper requested a cooldown. Try again in ${retryAfterSeconds} second${
        retryAfterSeconds === 1 ? '' : 's'
      }.`,
      code: 'vh_signed_request_cooldown',
      retryAfterSeconds
    });
  }

  // Materialize only the identity already on disk. Unlike live setup, this
  // endpoint never provisions, repairs, rotates, relinks, or saves identity.
  const identity = identityManager.materialize(config.countryCode || 'ca');
  if (!identity || !identity.uuid) {
    return res.status(409).json({
      error: 'No existing saved VH identity with a UUID is available. Identity was not changed.',
      code: 'saved_vh_identity_unavailable'
    });
  }
  if (
    identity.identityMode === 'hardened-synthetic' &&
    !identityManager.validateHardened(identity)
  ) {
    return res.status(409).json({
      error: 'The existing saved VH identity cannot sign this request. Identity was not changed.',
      code: 'saved_vh_identity_invalid'
    });
  }

  let content;
  try {
    const cid = identityManager.getCID(identity.country, identity);
    content = buildItemExplorerContent(search, identity, cid);
  } catch (error) {
    return res.status(409).json({
      error: 'The existing saved VH identity is incomplete. Identity was not changed.',
      code: 'saved_vh_identity_invalid'
    });
  }

  rememberVhSignedRequest(search.requestId, now);
  vhSignedRequestInFlight = true;
  vhItemExplorerLastAttemptAt = new Date(now).toISOString();
  vhItemExplorerLastErrorCode = null;

  const sendEntitlementError = (data, statusCode = 403) => {
    applyVhSignedCooldown(data?.wait_time);
    vhItemExplorerLastErrorCode = 'invalid_uuid_or_subscription_insufficient';
    return res.status(statusCode).json({
      error:
        'VHelper rejected the current saved Vine Drop Hub VH identity or its Item Explorer entitlement. The identity was not changed.',
      code: 'invalid_uuid_or_subscription_insufficient',
      invalidUuid:
        data?.invalid_uuid === true || data?.invalid_uuid === 1 || data?.invalid_uuid === 'true',
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  };

  try {
    const result = await identityManager.callApi(content, identity);
    const responseBytes = Buffer.byteLength(JSON.stringify(result), 'utf8');
    if (responseBytes > ITEM_EXPLORER_MAX_RESPONSE_BYTES) {
      const error = new Error('VHelper Item Explorer response exceeded the safe size limit');
      error.code = 'item_explorer_response_too_large';
      throw error;
    }

    applyVhSignedCooldown(result.wait_time);
    const invalidUuid =
      result.invalid_uuid === true || result.invalid_uuid === 1 || result.invalid_uuid === 'true';
    if (invalidUuid) return sendEntitlementError(result);

    const upstreamMessage = safeUpstreamMessage(
      result.error_message || result.message || (typeof result.error === 'string' ? result.error : '')
    );
    if (upstreamMessage && isEntitlementMessage(upstreamMessage)) {
      return sendEntitlementError(result);
    }
    if (result.error === true || upstreamMessage) {
      vhItemExplorerLastErrorCode = 'vh_item_explorer_rejected';
      return res.status(502).json({
        error: 'VHelper rejected the Item Explorer request.',
        code: 'vh_item_explorer_rejected',
        retryAfterSeconds: vhSignedRetryAfterSeconds()
      });
    }

    const sanitized = sanitizeItemExplorerResponse(result, search.page);
    vhItemExplorerLastSuccessAt = new Date().toISOString();
    vhItemExplorerLastErrorCode = null;
    return res.json({
      success: true,
      source: 'vh_item_explorer',
      fixedQueue: ITEM_EXPLORER_QUEUE,
      queryTime: sanitized.queryTime,
      totalItems: sanitized.totalItems,
      waitTime: sanitized.waitTime,
      retryAfterSeconds: vhSignedRetryAfterSeconds(),
      page: sanitized.page,
      pageSize: sanitized.pageSize,
      discardedItems: sanitized.discardedItems,
      items: sanitized.items,
      persisted: false,
      mergedIntoLiveFeed: false
    });
  } catch (error) {
    const upstream = error?.response?.data;
    const invalidUuid =
      upstream?.invalid_uuid === true ||
      upstream?.invalid_uuid === 1 ||
      upstream?.invalid_uuid === 'true';
    const upstreamMessage = safeUpstreamMessage(
      upstream?.error_message ||
        upstream?.message ||
        (typeof upstream?.error === 'string' ? upstream.error : '')
    );
    if (invalidUuid || (upstreamMessage && isEntitlementMessage(upstreamMessage))) {
      return sendEntitlementError(upstream);
    }

    const upstreamWait = upstream?.wait_time || error?.response?.headers?.['retry-after'];
    applyVhSignedCooldown(upstreamWait);
    if (error?.response?.status === 429) {
      const wait = vhSignedRetryAfterSeconds();
      vhItemExplorerLastErrorCode = 'vh_item_explorer_rate_limited';
      if (wait > 0) res.set('Retry-After', String(wait));
      return res.status(429).json({
        error: wait > 0
          ? `VHelper requested a cooldown. Try again in ${wait} seconds.`
          : 'VHelper rate-limited the Item Explorer request.',
        code: 'vh_item_explorer_rate_limited',
        retryAfterSeconds: wait
      });
    }
    if (error?.response?.status === 401 || error?.response?.status === 403) {
      vhItemExplorerLastErrorCode = 'vh_item_explorer_forbidden';
      return res.status(403).json({
        error:
          'VHelper refused this signed Item Explorer request. The current saved identity or its trial/subscription may not be accepted; identity was not changed.',
        code: 'vh_item_explorer_forbidden',
        retryAfterSeconds: vhSignedRetryAfterSeconds()
      });
    }

    const tooLarge =
      error?.code === 'item_explorer_response_too_large' ||
      /maxContentLength|larger than max/i.test(String(error?.message || ''));
    vhItemExplorerLastErrorCode = tooLarge
      ? 'vh_item_explorer_response_too_large'
      : 'vh_item_explorer_unavailable';
    console.warn(
      '[VH Item Explorer] Request failed without identity mutation:',
      vhItemExplorerLastErrorCode,
      error?.response?.status || ''
    );
    return res.status(502).json({
      error: tooLarge
        ? 'VHelper returned an Item Explorer response above the safe size limit.'
        : 'VHelper Item Explorer is currently unavailable. No automatic retry was made.',
      code: vhItemExplorerLastErrorCode,
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  } finally {
    vhSignedRequestInFlight = false;
  }
});

// One deliberate Watch-dialog click may issue exactly one official VHelper
// 4.7.4 item_explorer_variants request. The response is sanitized for that
// open browser dialog only; it is never persisted or merged into live items.
app.post('/api/vh/item-explorer/variants', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const declaredBytes = Number(req.get('content-length'));
  let parsedBytes = Infinity;
  try {
    parsedBytes = Buffer.byteLength(JSON.stringify(req.body ?? null), 'utf8');
  } catch (_) {}
  if (
    (Number.isFinite(declaredBytes) && declaredBytes > 4 * 1024) ||
    parsedBytes > 4 * 1024
  ) {
    return res.status(413).json({
      error: 'Load-variants request exceeds the 4 KiB limit.',
      code: 'item_explorer_variants_request_too_large'
    });
  }

  let request;
  try {
    request = normalizeItemExplorerVariantsRequest(req.body);
  } catch (error) {
    const statusCode = error instanceof ItemExplorerVariantsValidationError
      ? error.statusCode
      : 400;
    const code = error instanceof ItemExplorerVariantsValidationError
      ? error.code
      : 'invalid_item_explorer_variants_request';
    return res.status(statusCode).json({ error: error.message, code });
  }

  const now = Date.now();
  if (hasSeenVhSignedRequest(request.requestId, now)) {
    return res.status(409).json({
      error: 'This one-time load-variants request was already used.',
      code: 'replayed_item_explorer_variants_request'
    });
  }
  if (!isVhEnabled()) {
    return res.status(409).json({
      error: 'VHelper is disabled; variants were not loaded.',
      code: 'vh_disabled'
    });
  }
  if (vhSignedRequestInFlight) {
    return res.status(409).json({
      error: 'Another signed VHelper request is already in progress.',
      code: 'vh_signed_request_in_flight'
    });
  }
  const retryAfterSeconds = vhSignedRetryAfterSeconds(now);
  if (retryAfterSeconds > 0) {
    res.set('Retry-After', String(retryAfterSeconds));
    return res.status(429).json({
      error: `VHelper requested a cooldown. Try again in ${retryAfterSeconds} second${
        retryAfterSeconds === 1 ? '' : 's'
      }.`,
      code: 'vh_signed_request_cooldown',
      retryAfterSeconds
    });
  }

  // Materialize only the identity already on disk. This endpoint cannot
  // provision, repair, rotate, recover, relink, or save identity material.
  const identity = identityManager.materialize(config.countryCode || 'ca');
  if (!identity || !identity.uuid) {
    return res.status(409).json({
      error: 'No existing saved VH identity with a UUID is available. Identity was not changed.',
      code: 'saved_vh_identity_unavailable'
    });
  }
  if (
    identity.identityMode === 'hardened-synthetic' &&
    !identityManager.validateHardened(identity)
  ) {
    return res.status(409).json({
      error: 'The existing saved VH identity cannot sign this request. Identity was not changed.',
      code: 'saved_vh_identity_invalid'
    });
  }

  let content;
  try {
    const cid = identityManager.getCID(identity.country, identity);
    content = buildItemExplorerVariantsContent(request, identity, cid);
  } catch (_) {
    return res.status(409).json({
      error: 'The existing saved VH identity is incomplete. Identity was not changed.',
      code: 'saved_vh_identity_invalid'
    });
  }

  rememberVhSignedRequest(request.requestId, now);
  vhSignedRequestInFlight = true;
  let receivedUpstreamResult = false;

  const sendVariantsEntitlementError = (data, statusCode = 403) => {
    applyVhSignedCooldown(data?.wait_time);
    return res.status(statusCode).json({
      error:
        'VHelper rejected the current saved Vine Drop Hub VH identity or its load-variants entitlement. The identity was not changed.',
      code: 'invalid_uuid_or_subscription_insufficient',
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  };

  try {
    // This is the only upstream call in the route. There is no retry branch.
    const result = await identityManager.callApi(content, identity);
    receivedUpstreamResult = true;
    const responseBytes = Buffer.byteLength(JSON.stringify(result), 'utf8');
    if (responseBytes > ITEM_EXPLORER_VARIANTS_MAX_RESPONSE_BYTES) {
      const error = new Error('VHelper load-variants response exceeded the safe size limit');
      error.code = 'item_explorer_variants_response_too_large';
      throw error;
    }

    applyVhSignedCooldown(result.wait_time);
    const invalidUuid =
      result.invalid_uuid === true || result.invalid_uuid === 1 || result.invalid_uuid === 'true';
    if (invalidUuid) return sendVariantsEntitlementError(result);

    const upstreamMessage = safeUpstreamMessage(
      result.error_message || result.message || (typeof result.error === 'string' ? result.error : '')
    );
    if (upstreamMessage && isEntitlementMessage(upstreamMessage)) {
      return sendVariantsEntitlementError(result);
    }
    if (result.error === true || upstreamMessage) {
      return res.status(502).json({
        error: 'VHelper rejected the load-variants request.',
        code: 'vh_item_explorer_variants_rejected',
        retryAfterSeconds: vhSignedRetryAfterSeconds()
      });
    }

    const sanitized = sanitizeItemExplorerVariantsResponse(result, request.asin);
    return res.json({
      success: true,
      source: 'vh_item_explorer_variants',
      parentAsin: sanitized.parentAsin,
      variants: sanitized.variants,
      discardedVariants: sanitized.discardedVariants,
      waitTime: sanitized.waitTime,
      retryAfterSeconds: vhSignedRetryAfterSeconds(),
      persisted: false,
      mergedIntoLiveFeed: false
    });
  } catch (error) {
    const upstream = error?.response?.data;
    const invalidUuid =
      upstream?.invalid_uuid === true ||
      upstream?.invalid_uuid === 1 ||
      upstream?.invalid_uuid === 'true';
    const upstreamMessage = safeUpstreamMessage(
      upstream?.error_message ||
        upstream?.message ||
        (typeof upstream?.error === 'string' ? upstream.error : '')
    );
    if (invalidUuid || (upstreamMessage && isEntitlementMessage(upstreamMessage))) {
      return sendVariantsEntitlementError(upstream);
    }

    const upstreamWait = upstream?.wait_time || error?.response?.headers?.['retry-after'];
    applyVhSignedCooldown(upstreamWait);
    if (error?.response?.status === 429) {
      const wait = vhSignedRetryAfterSeconds();
      if (wait > 0) res.set('Retry-After', String(wait));
      return res.status(429).json({
        error: wait > 0
          ? `VHelper requested a cooldown. Try again in ${wait} seconds.`
          : 'VHelper rate-limited the load-variants request.',
        code: 'vh_item_explorer_variants_rate_limited',
        retryAfterSeconds: wait
      });
    }
    if (error?.response?.status === 401 || error?.response?.status === 403) {
      return res.status(403).json({
        error:
          'VHelper refused this signed load-variants request. The current saved identity or entitlement may not be accepted; identity was not changed.',
        code: 'vh_item_explorer_variants_forbidden',
        retryAfterSeconds: vhSignedRetryAfterSeconds()
      });
    }

    const tooLarge =
      error?.code === 'item_explorer_variants_response_too_large' ||
      /maxContentLength|larger than max/i.test(String(error?.message || ''));
    const invalidResponse = !tooLarge && receivedUpstreamResult;
    const code = tooLarge
      ? 'vh_item_explorer_variants_response_too_large'
      : invalidResponse
        ? 'invalid_item_explorer_variants_response'
        : 'vh_item_explorer_variants_unavailable';
    console.warn(
      '[VH Item Explorer Variants] One-click request failed without identity mutation:',
      code,
      error?.response?.status || ''
    );
    return res.status(502).json({
      error: tooLarge
        ? 'VHelper returned a load-variants response above the safe size limit.'
        : invalidResponse
          ? 'VHelper returned an invalid load-variants response. No variants were accepted.'
          : 'VHelper variants are currently unavailable. No automatic retry was made.',
      code,
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  } finally {
    vhSignedRequestInFlight = false;
  }
});

// Explicit-only VHelper entitlement read. This route is never invoked by a
// timer, startup path, tab switch, retry loop, or the passive feed transport.
app.post('/api/vh/trial-status', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const declaredBytes = Number(req.get('content-length'));
  let parsedBytes = Infinity;
  try {
    parsedBytes = Buffer.byteLength(JSON.stringify(req.body ?? null), 'utf8');
  } catch (_) {}
  if (
    (Number.isFinite(declaredBytes) && declaredBytes > 4 * 1024) ||
    parsedBytes > 4 * 1024
  ) {
    return res.status(413).json({
      error: 'Trial-status request exceeds the 4 KiB limit.',
      code: 'trial_status_request_too_large'
    });
  }

  let request;
  try {
    request = normalizeTrialStatusRequest(req.body);
  } catch (error) {
    const statusCode = error instanceof TrialStatusValidationError ? error.statusCode : 400;
    const code = error instanceof TrialStatusValidationError
      ? error.code
      : 'invalid_trial_status_request';
    return res.status(statusCode).json({ error: error.message, code });
  }

  const now = Date.now();
  if (hasSeenVhSignedRequest(request.requestId, now)) {
    return res.status(409).json({
      error: 'This one-time trial-status request was already used.',
      code: 'replayed_trial_status_request'
    });
  }
  if (!isVhEnabled()) {
    return res.status(409).json({
      error: 'VHelper is disabled; trial status was not checked.',
      code: 'vh_disabled'
    });
  }
  if (vhSignedRequestInFlight) {
    return res.status(409).json({
      error: 'Another signed VHelper request is already in progress.',
      code: 'vh_signed_request_in_flight'
    });
  }
  const retryAfterSeconds = vhSignedRetryAfterSeconds(now);
  if (retryAfterSeconds > 0) {
    res.set('Retry-After', String(retryAfterSeconds));
    return res.status(429).json({
      error: `VHelper requested a cooldown. Try again in ${retryAfterSeconds} second${
        retryAfterSeconds === 1 ? '' : 's'
      }.`,
      code: 'vh_signed_request_cooldown',
      retryAfterSeconds
    });
  }

  // Read and materialize only the already-saved identity. No branch in this
  // endpoint provisions, repairs, rotates, resolves, relinks, or persists it.
  const identity = identityManager.materialize(config.countryCode || 'ca');
  if (!identity || !identity.uuid) {
    return res.status(409).json({
      error: 'No existing saved VH identity with a UUID is available. Identity was not changed.',
      code: 'saved_vh_identity_unavailable'
    });
  }
  if (
    identity.identityMode === 'hardened-synthetic' &&
    !identityManager.validateHardened(identity)
  ) {
    return res.status(409).json({
      error: 'The existing saved VH identity cannot sign this request. Identity was not changed.',
      code: 'saved_vh_identity_invalid'
    });
  }

  let content;
  try {
    const cid = identityManager.getCID(identity.country, identity);
    content = buildTrialStatusContent(request, identity, cid);
  } catch (_) {
    return res.status(409).json({
      error: 'The existing saved VH identity is incomplete. Identity was not changed.',
      code: 'saved_vh_identity_invalid'
    });
  }

  rememberVhSignedRequest(request.requestId, now);
  vhSignedRequestInFlight = true;

  let receivedUpstreamResult = false;
  const sendTrialEntitlementError = (data, statusCode = 403) => {
    applyVhSignedCooldown(data?.wait_time);
    return res.status(statusCode).json({
      error:
        'VHelper rejected the current saved Vine Drop Hub VH identity or entitlement. The identity was not changed.',
      code: 'invalid_uuid_or_subscription_insufficient',
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  };

  try {
    const result = await identityManager.callApi(content, identity);
    receivedUpstreamResult = true;
    const responseBytes = Buffer.byteLength(JSON.stringify(result), 'utf8');
    if (responseBytes > TRIAL_STATUS_MAX_RESPONSE_BYTES) {
      const error = new Error('VHelper trial-status response exceeded the safe size limit');
      error.code = 'trial_status_response_too_large';
      throw error;
    }

    applyVhSignedCooldown(result.wait_time);
    const invalidUuid =
      result.invalid_uuid === true || result.invalid_uuid === 1 || result.invalid_uuid === 'true';
    if (invalidUuid) return sendTrialEntitlementError(result);

    const upstreamMessage = safeUpstreamMessage(
      result.error_message || (typeof result.error === 'string' ? result.error : '')
    );
    if (upstreamMessage && isEntitlementMessage(upstreamMessage)) {
      return sendTrialEntitlementError(result);
    }
    if (result.error === true || upstreamMessage) {
      return res.status(502).json({
        error: 'VHelper rejected the trial-status request.',
        code: 'vh_trial_status_rejected',
        retryAfterSeconds: vhSignedRetryAfterSeconds()
      });
    }

    const checkedAtMs = Date.now();
    const sanitized = sanitizeTrialStatusResponse(result, checkedAtMs);
    return res.json({
      success: true,
      trialActive: sanitized.trialActive,
      trialEndsAt: sanitized.trialEndsAt,
      trialEndsAtIso: sanitized.trialEndsAtIso,
      daysRemaining: sanitized.daysRemaining,
      membershipTier: sanitized.membershipTier,
      checkedAt: new Date(checkedAtMs).toISOString(),
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  } catch (error) {
    const upstream = error?.response?.data;
    const invalidUuid =
      upstream?.invalid_uuid === true ||
      upstream?.invalid_uuid === 1 ||
      upstream?.invalid_uuid === 'true';
    const upstreamMessage = safeUpstreamMessage(
      upstream?.error_message ||
        upstream?.message ||
        (typeof upstream?.error === 'string' ? upstream.error : '')
    );
    if (invalidUuid || (upstreamMessage && isEntitlementMessage(upstreamMessage))) {
      return sendTrialEntitlementError(upstream);
    }

    const upstreamWait = upstream?.wait_time || error?.response?.headers?.['retry-after'];
    applyVhSignedCooldown(upstreamWait);
    if (error?.response?.status === 429) {
      const wait = vhSignedRetryAfterSeconds();
      if (wait > 0) res.set('Retry-After', String(wait));
      return res.status(429).json({
        error: wait > 0
          ? `VHelper requested a cooldown. Try again in ${wait} seconds.`
          : 'VHelper rate-limited the trial-status request.',
        code: 'vh_trial_status_rate_limited',
        retryAfterSeconds: wait
      });
    }
    if (error?.response?.status === 401 || error?.response?.status === 403) {
      return res.status(403).json({
        error:
          'VHelper refused this signed trial-status request. The current saved identity or entitlement may not be accepted; identity was not changed.',
        code: 'vh_trial_status_forbidden',
        retryAfterSeconds: vhSignedRetryAfterSeconds()
      });
    }

    const tooLarge =
      error?.code === 'trial_status_response_too_large' ||
      /maxContentLength|larger than max/i.test(String(error?.message || ''));
    const invalidResponse = !tooLarge && receivedUpstreamResult;
    console.warn(
      '[VH Trial Status] Request failed without identity mutation:',
      tooLarge ? 'response_too_large' : invalidResponse ? 'invalid_response' : 'unavailable',
      error?.response?.status || ''
    );
    return res.status(502).json({
      error: tooLarge
        ? 'VHelper returned a trial-status response above the safe size limit.'
        : invalidResponse
          ? 'VHelper returned an invalid trial-status response. No status was inferred.'
          : 'VHelper trial status is currently unavailable. No automatic retry was made.',
      code: tooLarge
        ? 'vh_trial_status_response_too_large'
        : invalidResponse
          ? 'invalid_trial_status_response'
          : 'vh_trial_status_unavailable',
      retryAfterSeconds: vhSignedRetryAfterSeconds()
    });
  } finally {
    vhSignedRequestInFlight = false;
  }
});

app.post('/api/identity/rotate', async (req, res) => {
  if (!isVhEnabled()) {
    return res.status(409).json({ error: 'VHelper is disabled' });
  }

  const backupDir = path.join(DATA_DIR, 'identity-backups');
  let backupFile = null;
  try {
    fs.mkdirSync(backupDir, { recursive: true, mode: 0o700 });
    fs.chmodSync(backupDir, 0o700);
    if (fs.existsSync(IDENTITY_FILE)) {
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      backupFile = path.join(backupDir, `identity-before-explicit-generation-${stamp}.json`);
      fs.copyFileSync(IDENTITY_FILE, backupFile, fs.constants.COPYFILE_EXCL);
      fs.chmodSync(backupFile, 0o600);
    }

    await identityManager.explicitlyGenerate(config.countryCode || 'ca');
    clearVhDenial();
    destroyVhSocket();
    void connectVHelper({ force: true });
    const diagnostics = identityManager.diagnostics(config.countryCode || 'ca');
    addActivity('vh_identity_explicitly_generated', {
      source: 'VH',
      identityMode: diagnostics.identityMode,
      fidState: diagnostics.fidState
    });
    res.json({ success: true, identity: diagnostics });
  } catch (error) {
    if (backupFile && fs.existsSync(backupFile)) {
      try {
        fs.copyFileSync(backupFile, IDENTITY_FILE);
        fs.chmodSync(IDENTITY_FILE, 0o600);
      } catch (restoreError) {
        console.error('[VH Identity] Backup restore failed:', restoreError.message);
      }
    }
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/activity', (req, res) => {
  const limit = Math.max(1, Math.min(1000, parseInt(req.query.limit, 10) || 100));
  res.json(activityLog.slice(0, limit));
});

// ============================================================================
// UV 26.9.38-STYLE LOCAL PROFILE, SCREENS & CUSTOM QUEUES
// ============================================================================
function touchUvScreen(screenId) {
  const screen = uvProfile.screens.find(candidate => candidate.id === screenId);
  if (screen) screen.modifiedDate = new Date().toISOString();
  return screen;
}

function reorderUvRecords(records, id, requestedOrder) {
  const ordered = [...records].sort((a, b) => a.order - b.order);
  const currentIndex = ordered.findIndex(record => record.id === id);
  if (currentIndex < 0) return ordered;
  const nextIndex = Math.max(0, Math.min(ordered.length - 1, Number(requestedOrder) - 1));
  const [record] = ordered.splice(currentIndex, 1);
  ordered.splice(nextIndex, 0, record);
  ordered.forEach((entry, index) => {
    entry.order = index + 1;
  });
  return ordered;
}

function commitUvProfileMutation(reason, screenIds = [], options = {}) {
  uvProfile.bootstrapScreenId = null;
  uvProfile.initialSyncComplete = true;
  uvProfile = normalizeUvProfile(uvProfile, config);
  announceUvProfile(reason);
  for (const screenId of new Set(screenIds.filter(Boolean))) {
    sendUvScreenUpdate(screenId);
  }
  if (options.reidentify !== false) scheduleUvReidentification(`${reason} re-identification`);
  return publicUvProfile();
}

function configureNewUvAccount(tokenInput, amazonIdentityInput) {
  const token = String(tokenInput || '').trim();
  const amazonIdentity = String(amazonIdentityInput || '').trim();
  const amazonIdentityHash = sha256(amazonIdentity);
  if (!token || !amazonIdentityHash) {
    const error = new Error(
      'A new UV token and the new Amazon Vine customer ID or SHA-256 hash are both required.'
    );
    error.statusCode = 400;
    throw error;
  }

  const existingToken = String(config.token || '').trim();
  const existingAmazonIdentityHash = sha256(config.azUser);
  const hasExistingAccount = Boolean(existingToken || existingAmazonIdentityHash);
  if (hasExistingAccount && token === existingToken) {
    const error = new Error('A new account must use a new UV token; the saved token was reused.');
    error.statusCode = 409;
    throw error;
  }
  if (hasExistingAccount && amazonIdentityHash === existingAmazonIdentityHash) {
    const error = new Error(
      'A new account must use its new Amazon Vine customer ID; the saved Amazon identity was reused.'
    );
    error.statusCode = 409;
    throw error;
  }

  config.token = token;
  // Persist only the one-way hash even when the raw customerId was supplied.
  config.azUser = amazonIdentityHash;
  uvProfile = createDefaultUvProfile({});
  uvProfile.profileSource = 'new-account-bootstrap';
  return { replacedExistingAccount: hasExistingAccount };
}

app.get('/api/uv/profile', (req, res) => {
  res.json(publicUvProfile());
});

// Explicit, idempotent remediation for a profile that predates the canonical
// Explore queue. This never borrows an Alert UUID and never starts a search.
// Requiring an authenticated open socket and screen sync ensures the new queue
// is sent through UV's normal updateScreen protocol before the operator uses it.
app.post('/api/uv/explore-queue/setup', (req, res) => {
  const existing = effectiveUvExploreQueue();
  if (existing) {
    return res.json({
      success: true,
      created: false,
      updateQueued: false,
      queue: existing,
      profile: publicUvProfile()
    });
  }
  if (!config.token || !config.azUser) {
    return res.status(409).json({
      error: 'The saved UV account pair is incomplete.',
      code: 'uv_account_incomplete'
    });
  }
  if (config.uvSyncScreens === false) {
    return res.status(409).json({
      error: 'Enable UV screen synchronization before creating the Explore queue.',
      code: 'uv_screen_sync_disabled'
    });
  }
  if (!uvAuthenticated || !uvWs || uvWs.readyState !== WebSocket.OPEN) {
    return res.status(409).json({
      error: 'Reconnect the saved UV account and wait for plan/session authentication first.',
      code: 'uv_session_not_authenticated'
    });
  }

  const screen = uvProfile.screens.find(candidate => candidate.id === uvProfile.selectedScreenId);
  if (!screen) {
    return res.status(409).json({
      error: 'Select a UV screen before creating the Explore queue.',
      code: 'uv_selected_screen_missing'
    });
  }
  const screenQueues = uvProfile.queues.filter(queue => queue.screenId === screen.id);
  if (screenQueues.length >= 40) {
    return res.status(409).json({
      error: 'The selected UV screen already has the maximum of 40 queues.',
      code: 'uv_selected_screen_queue_limit'
    });
  }

  const queue = newUvQueue('Explore', screen.id, {
    order: screenQueues.length + 1,
    // Blank is deliberate: effectiveUvExploreQueue supplies canonical Explore.
    name: ''
  });
  uvProfile.queues.push(queue);
  touchUvScreen(screen.id);
  const profile = commitUvProfileMutation('explore-queue-created', [screen.id]);
  res.status(201).json({
    success: true,
    created: true,
    updateQueued: true,
    queue: effectiveUvExploreQueue(),
    profile
  });
});

app.post('/api/uv/onboard', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const previousSyncScreens = config.uvSyncScreens;
  const credentialsSubmitted = body.token !== undefined || body.azUser !== undefined;
  let accountResult = null;

  if (credentialsSubmitted) {
    if (body.newAccount !== true) {
      return res.status(400).json({
        error:
          'Same-account token renewal is disabled. Configure a new account with both its new UV token and new Amazon Vine customer ID/hash.'
      });
    }
    try {
      accountResult = configureNewUvAccount(body.token, body.azUser);
    } catch (error) {
      return res.status(error.statusCode || 400).json({ error: error.message });
    }
  }

  if (body.displayName !== undefined) {
    config.displayName = String(body.displayName || 'Vine Drop Hub').trim().slice(0, 100);
  }
  if (body.domain !== undefined) config.domain = String(body.domain || 'amazon.ca').trim();
  if (body.syncScreens !== undefined) config.uvSyncScreens = Boolean(body.syncScreens);
  if (body.enableUV !== undefined) config.enableUV = Boolean(body.enableUV);

  if (!accountResult && body.resetLocalIdentity === true) {
    uvProfile = createDefaultUvProfile({});
    uvProfile.bootstrapScreenId = null;
    uvProfile.initialSyncComplete = true;
    uvProfile.profileSource = 'explicit-reset';
  }

  persistUvProfile();
  const profile = publicUvProfile();
  broadcastLocal('uv_profile', profile);
  if (accountResult) {
    addActivity('uv_account_configured', {
      source: 'UV',
      replacedExistingAccount: accountResult.replacedExistingAccount,
      device: '<regenerated>',
      amazonIdentity: '<new hash configured>'
    });
  }

  if (config.enableUV && profile.onboarding.ready && body.connect !== false) {
    connectUltraviner({ trigger: 'profile-update' });
  } else if (
    config.enableUV &&
    profile.onboarding.ready &&
    previousSyncScreens !== config.uvSyncScreens
  ) {
    scheduleUvReidentification('screen-sync setting');
  } else if (config.enableUV && !profile.onboarding.ready) {
    stopUltraviner(
      `Waiting for UV onboarding: ${profile.onboarding.missing.join(', ')}; ` +
        'local device/screens/queues are ready'
    );
  } else if (!config.enableUV) {
    stopUltraviner('Disabled');
  }

  res.json({
    success: true,
    ready: profile.onboarding.ready,
    missing: profile.onboarding.missing,
    newAccountConfigured: Boolean(accountResult),
    profile,
    message: accountResult
      ? 'New UV token and Amazon identity saved together; the local UV profile was regenerated.'
      : 'UV profile settings updated.'
  });
});

app.post('/api/uv/profile/reset', (req, res) => {
  const previousScreenIds = uvProfile.screens.map(screen => screen.id);
  uvProfile = createDefaultUvProfile({});
  uvProfile.bootstrapScreenId = null;
  uvProfile.initialSyncComplete = true;
  uvProfile.profileSource = 'explicit-reset';
  persistUvProfile();
  broadcastLocal('uv_profile', publicUvProfile());

  // A reset deliberately creates a new local UV installation. It does not
  // delete the previous screens from UV's server; that avoids destructive
  // cross-device side effects. Reconnect because the device identity changed;
  // the fresh screen is uploaded during the next normal screen sync.
  if (config.enableUV && config.token && config.azUser) {
    connectUltraviner({ trigger: 'profile-reset' });
  }
  addActivity('uv_profile_reset', {
    source: 'UV',
    previousScreens: previousScreenIds.length,
    device: '<regenerated>'
  });
  res.json({ success: true, profile: publicUvProfile() });
});

app.post('/api/uv/screens', (req, res) => {
  if (uvProfile.screens.length >= 30) {
    return res.status(400).json({ error: 'A maximum of 30 screens is supported.' });
  }
  const order = uvProfile.screens.length + 1;
  const screen = newUvScreen({
    name: String(req.body?.name || `Screen ${order}`).trim().slice(0, 80),
    icon: req.body?.icon,
    order
  });
  const queueType = UV_QUEUE_TYPE_SET.has(req.body?.queueType) ? req.body.queueType : 'Alert';
  uvProfile.screens.push(screen);
  uvProfile.queues.push(newUvQueue(queueType, screen.id, { order: 1 }));
  const profile = commitUvProfileMutation('screen-created', [screen.id]);
  res.json({ success: true, screen, profile });
});

app.patch('/api/uv/screens/:id', (req, res) => {
  const screen = uvProfile.screens.find(candidate => candidate.id === req.params.id);
  if (!screen) return res.status(404).json({ error: 'Screen not found.' });
  if (req.body?.name !== undefined) {
    screen.name = String(req.body.name || '').trim().slice(0, 80) || 'Untitled Screen';
  }
  if (req.body?.icon !== undefined && UV_SCREEN_ICONS.has(req.body.icon)) {
    screen.icon = req.body.icon;
  }
  let affectedScreenIds = [screen.id];
  if (req.body?.order !== undefined) {
    uvProfile.screens = reorderUvRecords(uvProfile.screens, screen.id, req.body.order);
    affectedScreenIds = uvProfile.screens.map(candidate => candidate.id);
    affectedScreenIds.forEach(touchUvScreen);
  }
  if (req.body?.selected === true) uvProfile.selectedScreenId = screen.id;
  touchUvScreen(screen.id);
  const profile = commitUvProfileMutation('screen-updated', affectedScreenIds);
  res.json({ success: true, screen, profile });
});

app.post('/api/uv/screens/:id/select', (req, res) => {
  const screen = uvProfile.screens.find(candidate => candidate.id === req.params.id);
  if (!screen) return res.status(404).json({ error: 'Screen not found.' });
  uvProfile.selectedScreenId = screen.id;
  const profile = commitUvProfileMutation('screen-selected', [], { reidentify: true });
  res.json({ success: true, profile });
});

app.post('/api/uv/screens/:id/clone', (req, res) => {
  const source = uvProfile.screens.find(candidate => candidate.id === req.params.id);
  if (!source) return res.status(404).json({ error: 'Screen not found.' });
  if (uvProfile.screens.length >= 30) {
    return res.status(400).json({ error: 'A maximum of 30 screens is supported.' });
  }

  const cloneId = newUvId();
  const clone = normalizeUvScreen(
    {
      ...source,
      id: cloneId,
      name: `${source.name} (Copy)`.slice(0, 80),
      order: source.order + 1,
      creationDate: new Date().toISOString(),
      modifiedDate: new Date().toISOString()
    },
    source.order
  );
  const shiftedScreenIds = [];
  uvProfile.screens = uvProfile.screens.map(screen => {
    if (screen.order <= source.order) return screen;
    shiftedScreenIds.push(screen.id);
    return {
      ...screen,
      order: screen.order + 1,
      modifiedDate: new Date().toISOString()
    };
  });
  uvProfile.screens.push(clone);

  const sourceQueues = uvProfile.queues.filter(queue => queue.screenId === source.id);
  for (const queue of sourceQueues) {
    uvProfile.queues.push(
      normalizeUvQueue(
        {
          ...queue,
          id: newUvId(),
          screenId: cloneId,
          creationDate: new Date().toISOString(),
          modifiedDate: new Date().toISOString()
        },
        cloneId,
        queue.order - 1
      )
    );
  }
  const profile = commitUvProfileMutation('screen-cloned', [cloneId, ...shiftedScreenIds]);
  res.json({ success: true, screen: clone, profile });
});

app.delete('/api/uv/screens/:id', (req, res) => {
  const screen = uvProfile.screens.find(candidate => candidate.id === req.params.id);
  if (!screen) return res.status(404).json({ error: 'Screen not found.' });
  if (uvProfile.screens.length === 1) {
    return res.status(400).json({ error: 'The last screen cannot be deleted.' });
  }

  uvProfile.screens = uvProfile.screens.filter(candidate => candidate.id !== screen.id);
  uvProfile.queues = uvProfile.queues.filter(queue => queue.screenId !== screen.id);
  if (uvProfile.selectedScreenId === screen.id) {
    uvProfile.selectedScreenId = [...uvProfile.screens].sort((a, b) => a.order - b.order)[0].id;
  }
  uvProfile.screens
    .sort((a, b) => a.order - b.order)
    .forEach((candidate, index) => {
      candidate.order = index + 1;
      candidate.modifiedDate = new Date().toISOString();
    });
  const profile = commitUvProfileMutation(
    'screen-deleted',
    uvProfile.screens.map(candidate => candidate.id)
  );
  sendUvSocketMessage({
    type: 'deleteScreen',
    data: { screen_id: screen.id }
  });
  res.json({ success: true, profile });
});

app.post('/api/uv/screens/:screenId/queues', (req, res) => {
  const screen = uvProfile.screens.find(candidate => candidate.id === req.params.screenId);
  if (!screen) return res.status(404).json({ error: 'Screen not found.' });
  const screenQueues = uvProfile.queues.filter(queue => queue.screenId === screen.id);
  if (screenQueues.length >= 40) {
    return res.status(400).json({ error: 'A maximum of 40 queues per screen is supported.' });
  }
  const queueType = UV_QUEUE_TYPE_SET.has(req.body?.queueType) ? req.body.queueType : 'Alert';
  const queue = newUvQueue(queueType, screen.id, {
    order: screenQueues.length + 1,
    name: String(req.body?.name || '').trim().toLowerCase().slice(0, 80),
    selectedChatChannel: req.body?.selectedChatChannel,
    searchTerm: req.body?.searchTerm
  });
  uvProfile.queues.push(queue);
  touchUvScreen(screen.id);
  const profile = commitUvProfileMutation('queue-created', [screen.id]);
  res.json({ success: true, queue, profile });
});

app.patch('/api/uv/queues/:id', (req, res) => {
  const queue = uvProfile.queues.find(candidate => candidate.id === req.params.id);
  if (!queue) return res.status(404).json({ error: 'Queue not found.' });
  const oldScreenId = queue.screenId;
  const oldType = queue.queueType;

  if (req.body?.queueType !== undefined) {
    if (!UV_QUEUE_TYPE_SET.has(req.body.queueType)) {
      return res.status(400).json({ error: 'Unsupported queue type.' });
    }
    if (
      oldType === 'Alert' &&
      req.body.queueType !== 'Alert' &&
      getUvQueues('Alert').length === 1
    ) {
      return res.status(400).json({ error: 'At least one Alert queue is required.' });
    }
    queue.queueType = req.body.queueType;
  }
  if (req.body?.name !== undefined) {
    queue.name = String(req.body.name || '').trim().toLowerCase().slice(0, 80);
  }
  if (req.body?.selectedChatChannel !== undefined) {
    queue.selectedChatChannel = req.body.selectedChatChannel
      ? String(req.body.selectedChatChannel).trim().slice(0, 120)
      : null;
  }
  if (req.body?.searchTerm !== undefined) {
    queue.searchTerm = String(req.body.searchTerm || '').trim().slice(0, 200);
  }
  if (req.body?.isMuted !== undefined) queue.isMuted = Boolean(req.body.isMuted);
  if (req.body?.isTabActive !== undefined) queue.isTabActive = Boolean(req.body.isTabActive);
  if (req.body?.order !== undefined) {
    const screenQueues = uvProfile.queues.filter(candidate => candidate.screenId === queue.screenId);
    const reordered = reorderUvRecords(screenQueues, queue.id, req.body.order);
    const orderMap = new Map(reordered.map(candidate => [candidate.id, candidate.order]));
    uvProfile.queues.forEach(candidate => {
      if (orderMap.has(candidate.id)) candidate.order = orderMap.get(candidate.id);
    });
  }
  queue.modifiedDate = new Date().toISOString();
  touchUvScreen(queue.screenId);
  const profile = commitUvProfileMutation('queue-updated', [oldScreenId]);
  res.json({ success: true, queue, profile });
});

app.post('/api/uv/queues/:id/clone', (req, res) => {
  const source = uvProfile.queues.find(candidate => candidate.id === req.params.id);
  if (!source) return res.status(404).json({ error: 'Queue not found.' });
  const screenQueues = uvProfile.queues.filter(queue => queue.screenId === source.screenId);
  if (screenQueues.length >= 40) {
    return res.status(400).json({ error: 'A maximum of 40 queues per screen is supported.' });
  }
  screenQueues.forEach(queue => {
    if (queue.order > source.order) queue.order += 1;
  });
  const clone = normalizeUvQueue(
    {
      ...source,
      id: newUvId(),
      name: source.name ? `${source.name}-copy`.slice(0, 80) : '',
      order: source.order + 1,
      creationDate: new Date().toISOString(),
      modifiedDate: new Date().toISOString()
    },
    source.screenId,
    source.order
  );
  uvProfile.queues.push(clone);
  touchUvScreen(source.screenId);
  const profile = commitUvProfileMutation('queue-cloned', [source.screenId]);
  res.json({ success: true, queue: clone, profile });
});

app.delete('/api/uv/queues/:id', (req, res) => {
  const queue = uvProfile.queues.find(candidate => candidate.id === req.params.id);
  if (!queue) return res.status(404).json({ error: 'Queue not found.' });
  if (queue.queueType === 'Alert' && getUvQueues('Alert').length === 1) {
    return res.status(400).json({ error: 'The last Alert queue cannot be deleted.' });
  }
  const screenId = queue.screenId;
  uvProfile.queues = uvProfile.queues.filter(candidate => candidate.id !== queue.id);
  uvProfile.queues
    .filter(candidate => candidate.screenId === screenId)
    .sort((a, b) => a.order - b.order)
    .forEach((candidate, index) => {
      candidate.order = index + 1;
    });
  touchUvScreen(screenId);
  const profile = commitUvProfileMutation('queue-deleted', [screenId]);
  res.json({ success: true, profile });
});

app.post('/api/uv/layout/import', (req, res) => {
  const incomingScreens = Array.isArray(req.body?.screens) ? req.body.screens : [];
  const incomingQueues = Array.isArray(req.body?.queues) ? req.body.queues : [];
  if (!incomingScreens.length) {
    return res.status(400).json({ error: 'The UV export contains no screens.' });
  }
  if (incomingScreens.length > 30 || incomingQueues.length > 1200) {
    return res.status(400).json({ error: 'The imported UV layout is too large.' });
  }

  const mode = req.body?.mode === 'merge' ? 'merge' : 'replace';
  const oldScreenIds = new Set(uvProfile.screens.map(screen => screen.id));
  const normalizedScreens = incomingScreens.map(normalizeUvScreen);
  const importedIds = new Set(normalizedScreens.map(screen => screen.id));
  const normalizedQueues = incomingQueues
    .filter(queue => importedIds.has(String(queue?.screenId || '')))
    .map((queue, index) => normalizeUvQueue(queue, String(queue.screenId), index));

  if (mode === 'replace') {
    uvProfile.screens = normalizedScreens;
    uvProfile.queues = normalizedQueues;
    uvProfile.selectedScreenId = importedIds.has(String(req.body?.selectedScreenId || ''))
      ? String(req.body.selectedScreenId)
      : normalizedScreens.sort((a, b) => a.order - b.order)[0].id;
  } else {
    const screenMap = new Map(uvProfile.screens.map(screen => [screen.id, screen]));
    normalizedScreens.forEach(screen => screenMap.set(screen.id, screen));
    uvProfile.screens = [...screenMap.values()];
    for (const screen of normalizedScreens) {
      uvProfile.queues = uvProfile.queues.filter(queue => queue.screenId !== screen.id);
    }
    uvProfile.queues.push(...normalizedQueues);
  }

  const profile = commitUvProfileMutation(
    `layout-imported-${mode}`,
    uvProfile.screens.map(screen => screen.id)
  );
  if (mode === 'replace') {
    for (const oldId of oldScreenIds) {
      if (!importedIds.has(oldId)) {
        sendUvSocketMessage({ type: 'deleteScreen', data: { screen_id: oldId } });
      }
    }
  }
  res.json({ success: true, mode, profile });
});

app.get('/api/config', (req, res) => {
  // SV enablement/account/session state is available only through dedicated
  // status/control surfaces, not the generic Settings document.
  const { enableSV: _isolatedSmartVinerEnablement, ...genericConfig } = config;
  res.json({
    ...genericConfig,
    hasToken: Boolean(config.token),
    tokenPreview: config.token
      ? `${config.token.slice(0, 6)}...${config.token.slice(-4)}`
      : '',
    hasWebhook: Boolean(config.discordWebhook),
    status: { uvStatus, vhStatus, svStatus },
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED
  });
});

app.post('/api/config', (req, res) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  if (Object.keys(body).some(key => /^(?:enable)?sv(?:$|[A-Z_])/i.test(key))) {
    return res.status(400).json({
      error:
        'SmartViner account state and enablement are isolated from ordinary settings. Use the dedicated SmartViner connection controls.'
    });
  }
  if (
    body.token !== undefined ||
    body.azUser !== undefined ||
    body.newUvAccount !== undefined
  ) {
    return res.status(400).json({
      error:
        'UV account credentials are isolated from ordinary settings. Use Screens & Queues to submit the new token and matching Amazon Vine customer ID/hash together.'
    });
  }
  if (body.clearedItemSuppressionHours !== undefined) {
    try {
      body.clearedItemSuppressionHours = validateSuppressionHours(
        body.clearedItemSuppressionHours
      );
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  }
  const accountResult = null;
  for (const key of ['telegramToken', 'telegramChatId', 'discordWebhook']) {
    if (body[key] === undefined) continue;
    const replacement = String(body[key] || '').trim();
    if (!replacement && String(config[key] || '').trim()) {
      // Blank generic-form values preserve existing secrets. Telegram has an
      // explicit enable switch, so disabling notifications never requires
      // destructive credential deletion.
      delete body[key];
    } else {
      body[key] = replacement;
    }
  }

  const allowedKeys = [
    'domain',
    'countryCode',
    'enableUV',
    'enableVH',
    'uvSyncScreens',
    'displayName',
    'uvUserAgent',
    'uvIdentificationDelayMs',
    'uvAuthenticationTimeoutMs',
    'uvReconnectDelayMs',
    'enableFeedHealthAlerts',
    'uvTokenCheckIntervalMs',
    'feedOutageGraceMs',
    'telegramToken',
    'telegramChatId',
    'enableTelegram',
    'minPriorityPrice',
    'notificationDedupeMinutes',
    'clearedItemSuppressionHours',
    'maxStoredItems',
    'discordWebhook',
    'port'
  ];

  const uvRestartKeys = new Set([
    'domain',
    'enableUV',
    'uvSyncScreens',
    'displayName',
    'uvUserAgent',
    'uvIdentificationDelayMs',
    'uvAuthenticationTimeoutMs'
  ]);
  const vhRestartKeys = new Set(['countryCode', 'enableVH']);

  let restartUV = Boolean(accountResult);
  let restartVH = false;
  let recheckPriority = false;
  let rescheduleFeedHealth = false;
  let reconfigureClearedItemMemory = false;

  allowedKeys.forEach(key => {
    if (body[key] === undefined) return;
    let value = body[key];

    if (['port', 'maxStoredItems'].includes(key)) value = parseInt(value, 10);
    if (
      [
        'minPriorityPrice',
        'notificationDedupeMinutes',
        'clearedItemSuppressionHours',
        'uvIdentificationDelayMs',
        'uvAuthenticationTimeoutMs',
        'uvReconnectDelayMs',
        'uvTokenCheckIntervalMs',
        'feedOutageGraceMs'
      ].includes(key)
    ) {
      value = Number(value);
    }

    if (value === config[key]) return;
    config[key] = value;
    if (uvRestartKeys.has(key)) restartUV = true;
    if (vhRestartKeys.has(key)) restartVH = true;
    if (key === 'minPriorityPrice') recheckPriority = true;
    if (key === 'clearedItemSuppressionHours') reconfigureClearedItemMemory = true;
    if (
      ['enableFeedHealthAlerts', 'uvTokenCheckIntervalMs', 'feedOutageGraceMs'].includes(key)
    ) {
      rescheduleFeedHealth = true;
    }
  });

  // data/uv_profile.json is canonical for generated UUIDs; keep the legacy
  // config fields as read-only mirrors for older tooling.
  if (accountResult) {
    persistUvProfile();
    broadcastLocal('uv_profile', publicUvProfile());
    addActivity('uv_account_configured', {
      source: 'UV',
      replacedExistingAccount: accountResult.replacedExistingAccount,
      device: '<regenerated>',
      amazonIdentity: '<new hash configured>'
    });
  } else {
    syncLegacyUvConfig();
    saveJSON(CONFIG_FILE, config);
  }
  if (reconfigureClearedItemMemory) {
    pruneClearedItemMemory(
      clearedItemMemory,
      Date.now(),
      config.clearedItemSuppressionHours,
      MAX_CLEARED_ITEMS
    );
    persistClearedItemMemory();
  }
  if (recheckPriority) recheckAllKeywords();

  if (restartUV) {
    if (config.enableUV) connectUltraviner({ trigger: 'settings-update' });
    else stopUltraviner('Disabled');
  }

  if (restartVH) {
    if (isVhEnabled()) {
      clearVhDenial();
      startVhSupervisor();
      void connectVHelper({ force: true });
    } else stopVHelper();
  }

  if (rescheduleFeedHealth) startFeedHealthMonitor();

  res.json({
    success: true,
    newAccountConfigured: Boolean(accountResult),
    config,
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED
  });
});

// Explicit VHelper kill/enable endpoints.
app.get('/api/vh/status', (req, res) => {
  res.json({
    configuredEnabled: Boolean(config.enableVH),
    effectiveEnabled: isVhEnabled(),
    forceDisabled: VH_FORCE_DISABLED,
    liveOnly: true,
    liveStreamHistoryEnabled: false,
    historyEnabled: false,
    protocolVersions: publicVhProtocolVersions(),
    itemExplorer: publicVhItemExplorerStatus(),
    itemExplorerVariants: publicVhItemExplorerVariantsCapability(),
    trialStatus: publicVhTrialStatusCapability(),
    transportConnected: Boolean(vhSocket?.connected),
    transportHealthy: isVhTransportHealthy(),
    applicationReady: vhApplicationReady,
    applicationEvidenceRequiredForHealth: false,
    denied: vhDenied,
    denial: vhDenial,
    status: vhStatus,
    health: publicFeedHealth().VH,
    identity: identityManager.diagnostics(config.countryCode || 'ca')
  });
});

app.get('/api/vh/diagnostics', (req, res) => {
  const toIso = value => (value ? new Date(value).toISOString() : null);
  res.json({
    package: 'B',
    appVersion: VH_APP_VERSION,
    buildVersion: VH_BUILD_VERSION,
    apiVersion: VH_API_VERSION,
    protocolVersions: publicVhProtocolVersions(),
    configuredEnabled: Boolean(config.enableVH),
    effectiveEnabled: isVhEnabled(),
    forceDisabled: VH_FORCE_DISABLED,
    status: vhStatus,
    transportConnected: Boolean(vhSocket?.connected),
    transportHealthy: isVhTransportHealthy(),
    applicationReady: vhApplicationReady,
    applicationEvidenceRequiredForHealth: false,
    socketRecovered: Boolean(vhSocket?.recovered),
    denied: vhDenied,
    denial: vhDenial,
    connectedAt: toIso(vhConnectedAtMs),
    disconnectedAt: toIso(vhDisconnectedAtMs),
    lastEngineActivityAt: toIso(vhLastEngineActivityMs),
    lastApplicationActivityAt: toIso(vhLastApplicationActivityMs),
    lastBroadcastSyncSentAt: toIso(vhLastSyncSentAtMs),
    lastBroadcastSyncPongAt: toIso(vhLastSyncPongAtMs),
    broadcastSyncPending: Boolean(vhSyncPendingSinceMs),
    broadcastSyncPongRequired: false,
    broadcastSyncConsecutiveMisses: vhBroadcastSyncConsecutiveMisses,
    lastBroadcastSyncMissAt: toIso(vhLastBroadcastSyncMissAtMs),
    reconnectCount: vhReconnectCount,
    setupRetryAttempts: vhSetupRetryAttempts,
    lastRecoveryRequest: vhLastRecoveryRequest,
    lastRecovery: vhLastRecovery,
    possibleGap: vhPossibleGap,
    broadcastGapRecovery: vhBroadcastGapRecovery,
    broadcastGapReconnectSuppressions: vhBroadcastGapReconnectSuppressions,
    connectionInfo: vhConnectionInfo,
    lastBroadcast: vhLastBroadcast,
    pendingEnrichmentAsins: pendingVhEnrichments.size,
    identity: identityManager.diagnostics(config.countryCode || 'ca'),
    itemExplorer: publicVhItemExplorerStatus(),
    itemExplorerVariants: publicVhItemExplorerVariantsCapability(),
    trialStatus: publicVhTrialStatusCapability(),
    route: {
      destinationLockedProxyConfigured: Boolean(vhProxyAgent),
      proxyUrlExposed: false,
      uvRouteShared: false
    },
    policy: {
      passiveLiveStreamOnly: true,
      getLast100Prohibited: true,
      signedItemExplorerEnabled: true,
      itemExplorerUserInitiatedOnly: true,
      itemExplorerIdentityMutationAllowed: false,
      signedItemExplorerVariantsEnabled: true,
      itemExplorerVariantsWatchClickOnly: true,
      itemExplorerVariantsAutomaticRetry: false,
      itemExplorerVariantsResponsePersisted: false,
      itemExplorerVariantsLiveStoreMerged: false,
      itemExplorerVariantsIdentityMutationAllowed: false,
      signedTrialStatusEnabled: true,
      trialStatusUserInitiatedOnly: true,
      trialStatusResponsePersisted: false,
      trialStatusIdentityMutationAllowed: false,
      broadcastSyncPongRequired: false,
      applicationEvidenceRequiredForHealth: false,
      assistedLoadEmits: false,
      contributionEmits: false
    },
    health: publicFeedHealth().VH,
    recentActivity: activityLog.filter(entry => entry.data?.source === 'VH').slice(0, 25)
  });
});

app.post('/api/vh/disable', (req, res) => {
  config.enableVH = false;
  saveJSON(CONFIG_FILE, config);
  stopVHelper('Disabled');
  res.json({ success: true, enableVH: false, status: vhStatus });
});

app.post('/api/vh/enable', (req, res) => {
  if (VH_FORCE_DISABLED) {
    return res.status(409).json({
      error: 'VH is force-disabled by UV_ONLY/DISABLE_VH/ENABLE_VH environment mode.'
    });
  }

  config.enableVH = true;
  config.vhLoadHistory = false;
  saveJSON(CONFIG_FILE, config);
  clearVhDenial();
  startVhSupervisor();
  void connectVHelper({ force: true });
  res.json({ success: true, enableVH: true, status: 'Preparing VH identity...' });
});

app.post('/api/telegram/test', (req, res) => {
  if (!config.telegramToken || !config.telegramChatId) {
    return res.status(400).json({ error: 'Telegram Token and Chat ID required.' });
  }

  sendTelegramNotification({
    title: "Nespresso VertuoPlus Coffee and Espresso Machine by De'Longhi",
    asin: 'B01N7T7K3R',
    firstTwoWords: 'Nespresso VertuoPlus',
    queue: 'RFY',
    sources: ['UV'],
    price: '199.99',
    etv: '199.99',
    isZeroEtv: false,
    isHighlight: true,
    brand: 'Nespresso',
    img_url: '',
    date_added: new Date().toISOString()
  });
  res.json({ success: true });
});

app.post('/api/explore', async (req, res) => {
  let request;
  try {
    request = normalizeUvExplorerRequest(req.body || {});
  } catch (error) {
    if (error instanceof UvExplorerValidationError) {
      return res.status(400).json({
        error: error.message,
        code: error.code,
        products: [],
        total: 0
      });
    }
    throw error;
  }

  const countryId = Ge[config.domain] || 2;
  const primaryQueue = request.queueTypes.length === 1 ? request.queueTypes[0] : null;
  const exploreQueue = effectiveUvExploreQueue();
  const emptyPage = uvExplorerPageMetadata(request.page, 0);
  if (!config.token) {
    return res.status(503).json({
      products: [],
      total: 0,
      ...emptyPage,
      searchTerm: request.searchTerm,
      queueTypes: request.queueTypes,
      uvStatus,
      code: 'uv_token_missing',
      error: 'A saved UV token is required for signed catalog search.'
    });
  }
  if (!exploreQueue) {
    return res.status(503).json({
      products: [],
      total: 0,
      ...emptyPage,
      searchTerm: request.searchTerm,
      queueTypes: request.queueTypes,
      uvStatus,
      code: 'uv_explore_queue_missing',
      error: 'A canonical UV Explore queue must be created and synchronized before catalog search.'
    });
  }

  try {
    const signedPayload = buildUvExplorerSignedPayload(request, {
      countryId,
      queueId: exploreQueue.id,
      queueName: exploreQueue.name
    });
    const body = buildUvSearchRequestBody(config.token, signedPayload);
    const response = await fetch('https://api.ultraviner.com/ultraviner/search', {
      method: 'POST',
      headers: {
        ...signUvPayload(signedPayload, config.token),
        Authorization: `Bearer ${config.token}`,
        Origin: `https://www.${config.domain}`,
        Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
        'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      return res.status(response.status).json({
        products: [],
        total: 0,
        ...emptyPage,
        searchTerm: request.searchTerm,
        queueTypes: request.queueTypes,
        error: (await response.text()).slice(0, 500) || `UV search returned HTTP ${response.status}`,
        uvStatus
      });
    }

    const data = await response.json();
    if (!data || typeof data !== 'object' || !Array.isArray(data.products)) {
      return res.status(502).json({
        products: [],
        total: 0,
        ...emptyPage,
        searchTerm: request.searchTerm,
        queueTypes: request.queueTypes,
        error: 'UV search returned an invalid products payload',
        uvStatus
      });
    }
    const products = data.products
      .slice(0, UV_EXPLORER_PAGE_SIZE)
      .map(product => {
        const formatted = formatProductForDisplay(product, primaryQueue);
        const variantLookupId = rememberUvExplorerVariantSeed(product, formatted);
        return variantLookupId ? { ...formatted, variantLookupId } : formatted;
      });
    sortItemsArray(products);
    const pageMetadata = uvExplorerPageMetadata(request.page, products.length);
    res.json({
      products,
      total: products.length,
      ...pageMetadata,
      searchTerm: request.searchTerm,
      queueTypes: request.queueTypes,
      uvStatus
    });
  } catch (error) {
    res.status(500).json({
      products: [],
      total: 0,
      ...emptyPage,
      searchTerm: request.searchTerm,
      queueTypes: request.queueTypes,
      error: String(error.message || error).slice(0, 500),
      uvStatus
    });
  }
});

app.post('/api/ingest/items', (req, res) => {
  const { items = [], defaultQueue = 'RFY', source = 'UV' } = req.body;
  if (!Array.isArray(items) || !items.length) {
    return res.status(400).json({ error: 'items array is required' });
  }

  let count = 0;
  items.forEach(raw => {
    const value = { ...raw };
    if (ingestItem(value, source, 'BATCH_INGEST', defaultQueue)) count += 1;
  });
  res.json({ success: true, ingested: count, total: allItems.length });
});

app.post('/api/ingest/html', (req, res) => {
  const { html, queue = 'RFY', source = 'UV' } = req.body;
  if (!html || typeof html !== 'string') {
    return res.status(400).json({ error: 'html string is required' });
  }

  const parsed = [];
  const tileRegex =
    /<div[^>]*class="[^"]*vvp-item-tile[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/gi;
  let match;

  while ((match = tileRegex.exec(html)) !== null) {
    const tile = match[1];
    const asinMatch =
      tile.match(/data-asin="([A-Z0-9]{10})"/i) || tile.match(/\/dp\/([A-Z0-9]{10})/i);
    if (!asinMatch) continue;

    const titleMatch =
      tile.match(/<span[^>]*class="[^"]*a-truncate-full[^"]*"[^>]*>([\s\S]*?)<\/span>/i) ||
      tile.match(/<a[^>]*class="[^"]*a-link-normal[^"]*"[^>]*>([\s\S]*?)<\/a>/i) ||
      tile.match(/alt="([^"]+)"/i);
    const imageMatch =
      tile.match(/src="([^"]+media-amazon\.com[^"]+)"/i) || tile.match(/src="([^"]+)"/i);
    const recommendationMatch = tile.match(/data-recommendation-type="([^"]+)"/i);

    parsed.push({
      asin: asinMatch[1],
      title: titleMatch
        ? titleMatch[1].replace(/<[^>]+>/g, '').trim()
        : 'Vine Item',
      img_url: imageMatch?.[1] || null,
      queue: recommendationMatch?.[1] || queue,
      price: 'N/A',
      etv: 'N/A'
    });
  }

  let count = 0;
  parsed.forEach(item => {
    if (ingestItem(item, source, 'HTML_INGEST')) count += 1;
  });
  res.json({ success: true, count, items: parsed.slice(0, 10), total: allItems.length });
});

async function probeUvToken(token) {
  if (!token) return { success: false, status: 400, error: 'Token is required' };

  const countryId = Ge[config.domain] || 2;
  const exploreQueue = effectiveUvExploreQueue();
  if (!exploreQueue) {
    return {
      success: false,
      status: 0,
      skipped: true,
      code: 'uv_explore_queue_missing',
      error: 'A canonical UV Explore queue is required for the signed search check'
    };
  }

  const signedPayload = {
    pageSize: '10',
    page: '1',
    searchTerm: '',
    countryId: String(countryId),
    categories: '',
    queueTypes: 'RFY,AI,AFA',
    queueId: exploreQueue.id,
    queueName: exploreQueue.name
  };

  try {
    const response = await fetch('https://api.ultraviner.com/ultraviner/search', {
      method: 'POST',
      headers: {
        ...signUvPayload(signedPayload, token),
        Authorization: `Bearer ${token}`,
        Origin: `https://www.${config.domain}`,
        Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
        'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
      },
      body: JSON.stringify(buildUvSearchRequestBody(token, signedPayload)),
      signal: AbortSignal.timeout(15000)
    });

    const text = await response.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch (_) {}

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        contentType: response.headers.get('content-type') || '',
        error: text.slice(0, 1000)
      };
    }

    return {
      success: true,
      status: response.status,
      count: Array.isArray(data?.products) ? data.products.length : 0,
      data
    };
  } catch (error) {
    return { success: false, status: 0, error: error.message };
  }
}

async function runConfiguredUvTokenHealthCheck() {
  if (!config.enableUV || !config.token) return;

  const fingerprint = sha256(config.token).slice(0, 12);
  const result = await probeUvToken(config.token);
  feedHealth.UV.lastTokenCheckAt = new Date().toISOString();
  feedHealth.UV.lastTokenCheckStatus = result.success
    ? 'passed'
    : result.skipped
      ? 'skipped-no-explore-queue'
      : result.status
        ? `http-${result.status}`
        : 'network-error';
  persistAndBroadcastFeedHealth();

  if (result.success) {
    console.log(`[UV Health] Scheduled signed search probe passed (${result.count} records).`);
    if (uvAuthenticated && uvWs?.readyState === WebSocket.OPEN) {
      markFeedHealthy('UV', uvSessionHealthReason());
    } else if (
      feedHealth.UV.activeIncident &&
      feedHealth.UV.incidentKey.startsWith('uv-token:')
    ) {
      transitionActiveFeedIncident(
        'UV',
        uvRetryController.diagnostics().terminalReason === 'invalid-token'
          ? 'The signed search path accepted the configured credential, but the WebSocket explicitly returned invalidToken; manual reconnect is still required.'
          : 'The signed search path accepted the configured credential; WebSocket identification remains independently unproven.',
        uvRetryController.diagnostics().terminalReason === 'invalid-token'
          ? `uv-token:${fingerprint}`
          : `uv-connectivity:${fingerprint}`
      );
      // Signed search and WebSocket authentication are separate contracts.
      // In particular, a successful search must never bypass the terminal
      // invalidToken latch; only an explicit user action may reconnect it.
    }
    return;
  }

  if (result.skipped) {
    console.warn(`[UV Health] Signed search probe skipped: ${result.error}`);
    return;
  }

  const errorText = String(result.error || 'Unknown token-check failure');
  const looksLikeHtmlChallenge =
    String(result.contentType || '').toLowerCase().includes('text/html') ||
    /<!doctype html|<html/i.test(errorText);
  const explicitlyRejected =
    result.status === 401 ||
    (result.status === 403 &&
      !looksLikeHtmlChallenge &&
      !/timestamp|device clock|clock skew/i.test(errorText));

  if (explicitlyRejected) {
    feedHealth.UV.lastTokenCheckStatus = `rejected-http-${result.status}`;
    persistAndBroadcastFeedHealth();
    const wsSessionAuthenticated =
      uvAuthenticated && uvWs?.readyState === WebSocket.OPEN;
    console.warn(
      `[UV Health] Signed search rejected HTTP ${result.status}; diagnostic only. ` +
        (wsSessionAuthenticated
          ? 'The authenticated WebSocket is preserved.'
          : 'WebSocket health remains independently authoritative.')
    );
    if (wsSessionAuthenticated) {
      markFeedHealthy('UV', uvSessionHealthReason());
    }
    return;
  }

  // A search rejection, Cloudflare page, rate limit, or temporary endpoint
  // problem does not prove WebSocket token expiry. Only the socket's explicit
  // invalidToken frame may terminate and block that live session.
  console.warn(
    `[UV Health] Token check inconclusive (HTTP ${result.status || 'network'}): ` +
      errorText.replace(/\s+/g, ' ').slice(0, 180)
  );
}

app.post('/api/uv/test-token', async (req, res) => {
  const token = req.body?.token || config.token;
  const result = await probeUvToken(token);
  if (!result.success) {
    return res.status(result.skipped ? 409 : result.status || 500).json({
      success: false,
      skipped: Boolean(result.skipped),
      code: result.code || null,
      error: result.error
    });
  }

  res.json({
    success: true,
    count: result.count,
    message: 'UV signed search accepted the credential; WebSocket identification is a separate check.'
  });
});

app.post('/api/uv/test-drop', (req, res) => {
  const randomAsin = `B0${Math.random().toString(36).slice(2, 10).toUpperCase()}`.slice(0, 10);
  const item = ingestItem(
    {
      title: 'Ultraviner Test Drop: Nespresso Vertuo Coffee Machine',
      asin: randomAsin,
      queue: 'RFY',
      price: '199.99',
      etv: '199.99',
      brand: 'Nespresso',
      img_url: 'https://m.media-amazon.com/images/I/71wK+o8oYVL._AC_SL1500_.jpg',
      date: new Date().toISOString()
    },
    'UV',
    'TEST_LIVE'
  );
  res.json({ success: true, item });
});

app.post('/api/uv/reconnect', (req, res) => {
  config.enableUV = true;
  saveJSON(CONFIG_FILE, config);
  // Explicit user action cancels any pending cooldown and opens a socket now.
  // It is also the sole route that may clear an invalidToken terminal latch.
  connectUltraviner({ trigger: 'manual-reconnect', allowTerminalReset: true });
  res.json({ success: true, status: 'Connecting...' });
});

app.get('/api/uv/diagnostics', (req, res) => {
  const identity = effectiveUvIdentity();
  const liveItems = allItems.filter(isLiveItem);
  const retry = uvRetryController.diagnostics();
  res.json({
    uvStatus,
    vhStatus,
    svStatus,
    runtimeVersion: UV_RUNTIME_VERSION,
    launcherVersion: UV_LAUNCHER_VERSION,
    isWsOpen: Boolean(uvWs && uvWs.readyState === WebSocket.OPEN),
    uvAuthenticated,
    uvConnectedAt,
    uvLastFrameAt,
    uvLastAlertAt,
    uvLastAlertReceivedAt,
    liveAlertObservedOnCurrentConnection: uvLiveAlertObservedOnCurrentConnection(),
    reconnectBlocked: retry.terminalBlocked,
    authenticationTimeoutCount: retry.authenticationTimeoutCount,
    authenticationTimeoutTotal: retry.authenticationTimeoutTotal,
    nextRetryAt: retry.nextRetryAt,
    nextRetryInMs: retry.nextRetryInMs,
    retryStatus: retry.status,
    retry,
    hasToken: Boolean(config.token),
    tokenPreview: config.token ? `${config.token.slice(0, 6)}...${config.token.slice(-4)}` : 'None',
    identity,
    profile: publicUvProfile(),
    recentFrames: uvRecentFrames,
    totalItems: liveItems.length,
    storedItems: allItems.length,
    uvCount: liveItems.filter(item => (item.sources || []).includes('UV')).length,
    vhCount: liveItems.filter(item => (item.sources || []).includes('VH')).length,
    svCount: liveItems.filter(item => (item.sources || []).includes('SV')).length,
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED,
    vhLoadHistory: false,
    vhApplicationReady,
    vhDenied,
    feedHealth: publicFeedHealth(),
    liveDeliveryPerformance: publicLiveDeliveryPerformance(),
    lastUvActivity: activityLog.filter(entry => entry.data?.source === 'UV').slice(0, 10)
  });
});

app.post('/api/sync/refresh', async (req, res) => {
  if (config.token && config.enableUV) await fetchInitialUvCatalog();

  // Manual refresh deliberately has no VH or SV history path. A connected VH
  // socket gets only the history-free application liveness ping; SV remains on
  // its continuously active private live-alert channel without a catch-up call.
  if (isVhEnabled() && vhSocket?.connected) emitVhBroadcastSync('manual-refresh');

  if (uvWs?.readyState === WebSocket.OPEN) {
    uvWs.send(JSON.stringify({ type: 'ping' }));
  }

  const liveCount = allItems.filter(isLiveItem).length;
  broadcastLocal('feed_refreshed', { count: liveCount });
  res.json({ success: true, count: liveCount, uvStatus, vhStatus, svStatus });
});

// ============================================================================
// CLEANUP & SERVER START
// ============================================================================
const trimInterval = setInterval(() => {
  const maximum = Number(config.maxStoredItems) || 2000;
  if (allItems.length <= maximum) return;

  const trimmed = allItems.length - maximum;
  allItems.splice(maximum);
  persistItemsReplace();
  broadcastLocal('items_trimmed', { count: maximum });
  console.log(`[Cleanup] Trimmed ${trimmed} old items.`);
}, 3600000);

const PORT = Number(process.env.PORT) || Number(config.port) || 3001;

server.listen(PORT, async () => {
  console.log('\n===============================================================');
  console.log('Vine Drop Hub — UV + VH + SmartViner live sources');
  console.log(`Port: ${PORT}`);
  console.log(`UV: ${config.enableUV ? 'ENABLED' : 'DISABLED'}`);
  console.log(
    `VH: ${isVhEnabled() ? 'ENABLED' : 'COMPLETELY DISABLED'}${
      VH_FORCE_DISABLED ? ' (process-level UV-only mode)' : ''
    }`
  );
  console.log(`SV: ${config.enableSV ? (svHttpsProxyAgent ? 'ENABLED' : 'BLOCKED — dedicated egress unavailable') : 'DISABLED'}`);
  console.log(
    `PC order companion: ${orderCoordinator.publicStatus().paired ? 'PAIRED' : 'NOT PAIRED'}; ` +
      `automatic rules ${orderCoordinator.publicRules().enabled ? 'ENABLED' : 'DISABLED'}`
  );
  console.log(`Web interface: http://localhost:${PORT}`);
  console.log('===============================================================\n');

  if (config.enableUV) connectUltraviner({ trigger: 'startup' });
  else stopUltraviner('Disabled');

  if (isVhEnabled()) void connectVHelper();
  else stopVHelper();

  await initializeSmartViner();
  startFeedHealthMonitor();
});

let isShuttingDown = false;
function gracefulShutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  console.log(`\n[${signal}] Shutting down...`);

  clearInterval(trimInterval);
  stopFeedHealthMonitor();
  stopUltraviner('Stopped');
  stopVHelper('Stopped');
  svClient?.shutdown();
  orderCoordinator?.disconnect('Server shutting down');

  try {
    localWss.clients.forEach(client => client.terminate());
    localWss.close();
  } catch (_) {}

  const httpClosed = new Promise(resolve => {
    server.close(() => {
      console.log('[Shutdown] HTTP server closed.');
      resolve();
    });
    server.closeIdleConnections?.();
  });
  const persistenceClosed = livePersistence
    ? livePersistence.close(5000).catch(error => {
        console.error('[Shutdown] Persistence flush failed:', error.message);
      })
    : Promise.resolve();

  void Promise.all([httpClosed, persistenceClosed]).finally(() => {
    notificationHttpsAgent.destroy();
    svHttpsProxyAgent?.destroy?.();
    process.exit(0);
  });

  setTimeout(() => process.exit(0), 6000).unref();
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
