# Manual clean-server notes

The authenticated and recommended clean-server procedure is
`MIGRATE_TO_NEW_UBUNTU.md`. Use the release installer rather than manually
copying individual source files. This document records only the lower-level
operator checks for `r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18`.

## Supported host

- Ubuntu 22.04 or 24.04 amd64
- Docker Engine with Compose v2
- `/dev/net/tun`
- host IPv6 enabled
- at least 1.5 GiB RAM plus swap during build/test
- dashboard kept on VPS loopback only

```bash
uname -m
. /etc/os-release && printf '%s %s\n' "$ID" "$VERSION_ID"
test -c /dev/net/tun
cat /proc/sys/net/ipv6/conf/all/disable_ipv6
docker version
docker compose version
```

Expected architecture is `x86_64`, OS is Ubuntu 22.04/24.04, TUN exists, and
the IPv6 value is `0`.

## Do not hand-install managed source

The archive contains authenticated `.new-machine-files.sha256`,
`.new-machine-paths`, and `.new-machine-release.json`. The installer rejects
unsafe tar paths, links, duplicates, missing/extra files, wrong release IDs, or
a pre-existing destination. It also installs the systemd unit with the exact
project path substituted.

Use either the self-contained installer or the separate installer/archive pair
named in `MIGRATE_TO_NEW_UBUNTU.md`.

## Private profile finalization

Transfer exactly one OpenVPN `.ovpn` or WireGuard `.conf` privately, then run:

```bash
sudo /opt/vine-drop-hub/host/finalize-install.sh \
  --project-dir /opt/vine-drop-hub \
  --profile /private/path/provider-profile.ovpn-or.conf
```

Do not manually create `active.env`, `wg0.conf`, or a prepared OpenVPN file.
The root manager validates and renders those files consistently. The finalizer
will refuse an absent profile, disabled host IPv6, missing TUN, invalid Compose,
unexpected topology, failed offline test total, or failed health/egress check.

## Runtime file boundary

All are root-owned mode 0600 and excluded from release payloads:

```text
vpn/client.ovpn
vpn/client.gluetun.ovpn
vpn/wireguard.conf
vpn/wg0.conf
vpn/active.env
```

`wireguard.conf` is the canonical complete profile. `wg0.conf` is the minimal
private Gluetun secret source. `active.env` contains only protocol and public
routing values. The five files are always backed up/restored as one state.

Do not put profile content, private keys, endpoints, or provider credentials in
support messages, shell history, Compose YAML, or environment overrides.

## Fixed dual-stack bridge

The authenticated Compose file uses:

```text
IPv4: 172.30.77.0/29
IPv6: fd30:7725:9::/64
```

Check local Docker networks for overlap before installation. Do not edit the
subnets in-place because doing so invalidates the managed release manifest.

## Health and logs

```bash
cd /opt/vine-drop-hub
sudo docker compose -f compose.vpn.yml ps
sudo systemctl --no-pager status vine-vpn-profile-manager.service
sudo journalctl -u vine-vpn-profile-manager.service -n 100 --no-pager
```

Gluetun logs can include endpoint/public-network information. Review them
locally and redact before sharing. Never share profile bodies or key strings.

## Dashboard access

```bash
ssh -N -T -L 127.0.0.1:3001:127.0.0.1:3001 ubuntu@YOUR_SERVER
```

Open <http://127.0.0.1:3001>. Never publish port 3001.

## Profile replacement

Use **Settings → VPN Profile Manager** rather than copying runtime files.
Choose OpenVPN file, WireGuard file, or WireGuard manual; type
`APPLY VPN PROFILE`; wait for `applied`. To restore the last complete state,
type `ROLL BACK VPN`.

See `DASHBOARD_VPN_UPLOAD.md` for accepted inputs, transaction/recovery states,
and cross-protocol rollback details.
