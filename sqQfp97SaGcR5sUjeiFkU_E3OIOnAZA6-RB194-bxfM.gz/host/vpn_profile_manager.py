#!/usr/bin/env python3
"""Privileged, protocol-aware VPN transaction manager for Vine Drop Hub.

The unprivileged dashboard can write only a private candidate and a small JSON
request. This host service independently validates OpenVPN or WireGuard input,
resolves endpoints before entering Gluetun's leak-blocking namespace, maintains
root-only protocol state and bounded backups, recreates only VPN-bound services,
checks health (including WireGuard IPv6 egress when configured), and restores the
previous complete protocol state after activation failure or interruption.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import contextlib
import datetime as dt
import fcntl
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any
import uuid

MAX_OVPN_BYTES = 1024 * 1024
MAX_WIREGUARD_BYTES = 64 * 1024
MAX_REQUEST_BYTES = 64 * 1024
MAX_STATE_BYTES = 64 * 1024
MAX_ENV_BYTES = 16 * 1024
REQUEST_ID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
)
HOST_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$")
KEY_RE = re.compile(r"^[A-Za-z0-9+/]{43}=$")
RUNTIME_FILES = (
    "client.ovpn",
    "client.gluetun.ovpn",
    "wireguard.conf",
    "wg0.conf",
    "active.env",
)
ACTIVE_ENV_KEYS = (
    "VPN_TYPE",
    "WIREGUARD_ENDPOINT_IP",
    "WIREGUARD_ENDPOINT_PORT",
    "WIREGUARD_PUBLIC_KEY",
    "WIREGUARD_ALLOWED_IPS",
    "WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL",
    "WIREGUARD_MTU",
    "WIREGUARD_IMPLEMENTATION",
)

FORBIDDEN_DIRECTIVES = {
    "up", "down", "route-up", "route-pre-down", "up-restart", "down-pre", "ipchange",
    "client-connect", "client-disconnect", "learn-address",
    "auth-user-pass-verify", "tls-verify", "plugin", "script-security",
    "management", "management-client", "management-hold",
    "management-query-passwords", "management-external-key",
    "management-external-cert", "daemon", "config", "cd", "chroot", "tmp-dir",
    "tls-export-cert", "log", "log-append", "status", "writepid", "client-nat", "http-proxy",
    "http-proxy-option", "socks-proxy", "remote-random-hostname",
    "server", "server-bridge", "mode",
}

FILE_DIRECTIVES = {
    "ca": "ca", "cert": "cert", "key": "key", "pkcs12": "pkcs12",
    "dh": "dh", "tls-auth": "tls-auth", "tls-crypt": "tls-crypt",
    "tls-crypt-v2": "tls-crypt-v2", "secret": "secret",
    "auth-user-pass": "auth-user-pass", "askpass": "askpass",
    "crl-verify": "crl-verify", "extra-certs": "extra-certs",
    "auth-gen-token-secret": "auth-gen-token-secret",
}
ALLOWED_INLINE_TAGS = set(FILE_DIRECTIVES.values())
WG_INTERFACE_KEYS = {"privatekey", "address", "dns", "mtu"}
WG_PEER_KEYS = {"publickey", "presharedkey", "allowedips", "endpoint", "persistentkeepalive"}
WG_HOOK_KEYS = {"preup", "postup", "predown", "postdown"}
WG_UNSUPPORTED_KEYS = {"listenport", "table", "saveconfig", "fwmark"}
SECRET_PATTERN = re.compile(r"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{43}=(?![A-Za-z0-9+/=])")


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sanitize_public_error(value: object, maximum: int = 1800) -> str:
    text = str(value or "VPN operation failed")
    text = SECRET_PATTERN.sub("[redacted-key]", text)
    text = re.sub(
        r"(?i)(privatekey|presharedkey|wireguard_private_key|wireguard_preshared_key)\s*[=:]\s*\S+",
        r"\1=[redacted]",
        text,
    )
    text = text.replace("\x00", "")
    return text[:maximum]


def atomic_bytes(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), mode)
        os.replace(temporary_name, path)
        os.chmod(path, mode)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temporary_name)


def atomic_json(path: Path, value: dict[str, Any], mode: int = 0o644) -> None:
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    atomic_bytes(path, data, mode)


def read_regular_file(path: Path, maximum: int, *, allow_missing: bool = False) -> bytes:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except FileNotFoundError:
        if allow_missing:
            return b""
        raise
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError(f"{path.name} is not a regular file")
        if info.st_size > maximum:
            raise ValueError(f"{path.name} exceeds the size limit")
        chunks: list[bytes] = []
        total = 0
        while total <= maximum:
            chunk = os.read(descriptor, min(65536, maximum + 1 - total))
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
        if total > maximum:
            raise ValueError(f"{path.name} exceeds the size limit")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def normalize_protocol(value: str | None) -> str:
    protocol = (value or "udp").strip().lower()
    if protocol in {"udp", "udp4"}:
        return "udp"
    if protocol in {"tcp", "tcp4", "tcp-client", "tcp4-client"}:
        return "tcp"
    raise ValueError(f"Unsupported OpenVPN protocol: {protocol or '<empty>'}")


def valid_hostname(host: str) -> bool:
    host = host.rstrip(".")
    if not host or len(host) > 253 or ".." in host:
        return False
    for label in host.split("."):
        if not 1 <= len(label) <= 63:
            return False
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?", label):
            return False
    return True


def valid_remote_host(host: str) -> bool:
    host = host.strip()
    if not host or len(host) > 253:
        return False
    try:
        return ipaddress.ip_address(host).version == 4
    except ValueError:
        return valid_hostname(host)


def parse_profile(data: bytes) -> dict[str, Any]:
    """Independently parse the accepted self-contained OpenVPN subset."""
    if not data:
        raise ValueError("The OpenVPN profile is empty")
    if len(data) > MAX_OVPN_BYTES:
        raise ValueError("The OpenVPN profile exceeds the size limit")
    if b"\x00" in data:
        raise ValueError("The OpenVPN profile contains a NUL byte")
    try:
        text = data.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
    except UnicodeDecodeError as error:
        raise ValueError("The OpenVPN profile must be UTF-8 text") from error
    encrypted_key_marker = "".join(("-----", "BEGIN ENCRYPTED PRIVATE KEY", "-----"))
    if encrypted_key_marker in text:
        raise ValueError("Encrypted private keys are not supported for unattended switching")

    lines = text.splitlines()
    if len(lines) > 20000:
        raise ValueError("The OpenVPN profile has too many lines")

    directives: list[tuple[str, list[str], int]] = []
    inline_tags: set[str] = set()
    active_tag: str | None = None

    for line_number, raw_line in enumerate(lines, 1):
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith(";"):
            continue
        opening = re.fullmatch(r"<([A-Za-z0-9_-]+)>", stripped)
        closing = re.fullmatch(r"</([A-Za-z0-9_-]+)>", stripped)
        if active_tag:
            if closing:
                closing_tag = closing.group(1).lower()
                if closing_tag != active_tag:
                    raise ValueError(f"Mismatched inline closing tag on line {line_number}")
                active_tag = None
            continue
        if closing:
            raise ValueError(f"Unexpected inline closing tag on line {line_number}")
        if opening:
            active_tag = opening.group(1).lower()
            if active_tag not in ALLOWED_INLINE_TAGS:
                raise ValueError(f"Unsupported OpenVPN inline section <{active_tag}> on line {line_number}")
            inline_tags.add(active_tag)
            continue
        try:
            tokens = shlex.split(stripped, comments=False, posix=True)
        except ValueError as error:
            raise ValueError(f"Invalid quoting on line {line_number}") from error
        if not tokens:
            continue
        name = tokens[0].removeprefix("--").lower()
        directives.append((name, tokens, line_number))

    if active_tag:
        raise ValueError(f"Unclosed <{active_tag}> inline block")

    for name, tokens, line_number in directives:
        if name in FORBIDDEN_DIRECTIVES:
            raise ValueError(f"Forbidden OpenVPN directive '{name}' on line {line_number}")
        inline_tag = FILE_DIRECTIVES.get(name)
        if not inline_tag:
            continue
        value = tokens[1].strip() if len(tokens) > 1 else ""
        explicitly_inline = value.lower() == "[inline]"
        has_inline = inline_tag in inline_tags
        if name == "auth-user-pass" and not value and not has_inline:
            raise ValueError("The profile requires separate username/password credentials")
        if value and not explicitly_inline:
            raise ValueError(f"External file reference '{name} {value}' is not supported")
        if explicitly_inline and not has_inline:
            raise ValueError(f"The profile refers to missing inline <{inline_tag}> data")

    remotes: list[dict[str, Any]] = []
    global_protocol: str | None = None
    for name, tokens, line_number in directives:
        if name == "proto":
            if len(tokens) < 2:
                raise ValueError(f"Missing protocol on line {line_number}")
            global_protocol = normalize_protocol(tokens[1])
        if name != "remote":
            continue
        if len(tokens) < 2 or not valid_remote_host(tokens[1]):
            raise ValueError(f"Invalid remote host on line {line_number}")
        port_text = tokens[2] if len(tokens) > 2 else "1194"
        if not port_text.isdigit() or not (1 <= int(port_text) <= 65535):
            raise ValueError(f"Invalid remote port on line {line_number}")
        remote_protocol = normalize_protocol(tokens[3]) if len(tokens) > 3 else None
        remotes.append({"host": tokens[1], "port": int(port_text), "protocol": remote_protocol})

    if not remotes:
        raise ValueError("The profile has no remote directive")
    if len(remotes) > 16:
        raise ValueError("The profile has too many remote endpoints")

    protocol = remotes[0]["protocol"] or global_protocol or "udp"
    for remote in remotes:
        remote["protocol"] = remote["protocol"] or global_protocol or protocol
        if remote["protocol"] != protocol:
            raise ValueError("Mixed UDP and TCP remotes are not supported")

    for name, tokens, _line_number in directives:
        if name == "dev" and len(tokens) > 1 and tokens[1].lower().startswith("tap"):
            raise ValueError("TAP profiles are not supported")

    normalized = text if text.endswith("\n") else text + "\n"
    return {
        "content": normalized,
        "fingerprint": sha256_bytes(normalized.encode("utf-8")),
        "vpnProtocol": "openvpn",
        "transport": protocol,
        "protocol": protocol,
        "remotes": remotes,
        "inlineTags": sorted(inline_tags),
        "tunnelFamilies": ["ipv4"],
    }


def validate_wg_key(value: str | None, label: str, optional: bool = False) -> str:
    value = (value or "").strip()
    if not value and optional:
        return ""
    if not KEY_RE.fullmatch(value):
        raise ValueError(f"{label} must be one canonical 32-byte WireGuard key")
    try:
        decoded = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as error:
        raise ValueError(f"{label} must be one canonical 32-byte WireGuard key") from error
    if len(decoded) != 32 or base64.b64encode(decoded).decode("ascii") != value or not any(decoded):
        raise ValueError(f"{label} must be one non-zero canonical 32-byte WireGuard key")
    return value


def canonical_interface(value: str) -> tuple[str, int]:
    try:
        interface = ipaddress.ip_interface(value.strip())
    except ValueError as error:
        raise ValueError("WireGuard Address must contain valid IPv4 or IPv6 CIDR values") from error
    return f"{interface.ip.compressed}/{interface.network.prefixlen}", interface.version


def canonical_network(value: str) -> tuple[str, int]:
    try:
        network = ipaddress.ip_network(value.strip(), strict=False)
    except ValueError as error:
        raise ValueError("WireGuard AllowedIPs must contain valid IPv4 or IPv6 CIDR values") from error
    return network.compressed, network.version


def parse_wg_endpoint(value: str) -> dict[str, Any]:
    value = value.strip()
    if not value or len(value) > 512 or any(character.isspace() for character in value):
        raise ValueError("WireGuard Endpoint must be a host and port")
    if value.startswith("["):
        match = re.fullmatch(r"\[([^]]+)]:(\d{1,5})", value)
        if not match:
            raise ValueError("A WireGuard IPv6 Endpoint must use [address]:port syntax")
        host, port_text = match.groups()
    else:
        if value.count(":") != 1:
            raise ValueError("WireGuard Endpoint must use host:port or [IPv6]:port syntax")
        host, port_text = value.rsplit(":", 1)
    if not port_text.isdigit() or not 1 <= int(port_text) <= 65535:
        raise ValueError("WireGuard Endpoint port must be from 1 through 65535")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        host = host.lower().rstrip(".")
        if not valid_hostname(host):
            raise ValueError("WireGuard Endpoint host is invalid")
        family = "hostname"
    else:
        host = address.compressed
        family = "ipv4" if address.version == 4 else "ipv6"
    port = int(port_text)
    rendered = f"[{host}]:{port}" if family == "ipv6" else f"{host}:{port}"
    return {"host": host, "port": port, "family": family, "value": rendered}


def split_wg_values(values: list[str], label: str, maximum: int) -> list[str]:
    flattened = [part.strip() for value in values for part in value.split(",") if part.strip()]
    if not flattened:
        raise ValueError(f"WireGuard {label} is required")
    if len(flattened) > maximum:
        raise ValueError(f"WireGuard {label} has too many entries")
    return flattened


def render_wireguard(values: dict[str, Any]) -> str:
    lines = [
        "# Vine managed canonical WireGuard client profile.",
        "# Gluetun manages encrypted DNS and the full-tunnel firewall.",
        "[Interface]",
        f"PrivateKey = {values['privateKey']}",
        f"Address = {', '.join(values['addresses'])}",
        f"MTU = {values['mtu']}",
        "",
        "[Peer]",
        f"PublicKey = {values['publicKey']}",
    ]
    if values["presharedKey"]:
        lines.append(f"PresharedKey = {values['presharedKey']}")
    lines.extend([
        "AllowedIPs = 0.0.0.0/0, ::/0",
        f"Endpoint = {values['endpoint']['value']}",
        f"PersistentKeepalive = {values['persistentKeepalive']}",
        "",
    ])
    return "\n".join(lines)


def parse_wireguard_profile(data: bytes) -> dict[str, Any]:
    """Independently parse and canonicalize the accepted WireGuard subset."""
    if not data:
        raise ValueError("The WireGuard profile is empty")
    if len(data) > MAX_WIREGUARD_BYTES:
        raise ValueError("The WireGuard profile exceeds the size limit")
    if b"\x00" in data:
        raise ValueError("The WireGuard profile contains a NUL byte")
    try:
        text = data.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
    except UnicodeDecodeError as error:
        raise ValueError("The WireGuard profile must be UTF-8 text") from error
    lines = text.split("\n")
    if len(lines) > 2000:
        raise ValueError("The WireGuard profile has too many lines")

    sections: dict[str, list[tuple[str, str, int]]] = {"interface": [], "peer": []}
    counts = {"interface": 0, "peer": 0}
    section: str | None = None
    for line_number, raw_line in enumerate(lines, 1):
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        line = re.sub(r"\s+[;#].*$", "", line).strip()
        if not line:
            continue
        section_match = re.fullmatch(r"\[([^]]+)]", line)
        if section_match:
            name = section_match.group(1).strip().lower()
            if name not in sections:
                raise ValueError(f"Unsupported WireGuard section [{section_match.group(1).strip()}] on line {line_number}")
            counts[name] += 1
            if counts[name] > 1:
                label = "Interface" if name == "interface" else "Peer"
                raise ValueError(f"WireGuard profile must contain exactly one [{label}] section")
            section = name
            continue
        if section is None:
            raise ValueError(f"WireGuard setting appears before a section on line {line_number}")
        setting = re.fullmatch(r"([A-Za-z][A-Za-z0-9]*)\s*=\s*(.*?)\s*", line)
        if not setting:
            raise ValueError(f"Malformed WireGuard setting on line {line_number}")
        original_key, value = setting.groups()
        key = original_key.lower()
        if key in WG_HOOK_KEYS:
            raise ValueError(f"Executable WireGuard hook '{original_key}' is forbidden")
        if key in WG_UNSUPPORTED_KEYS:
            raise ValueError(
                f"Unsupported WireGuard setting '{original_key}'; routing and interface state are managed by Gluetun"
            )
        allowed = WG_INTERFACE_KEYS if section == "interface" else WG_PEER_KEYS
        if key not in allowed:
            label = "Interface" if section == "interface" else "Peer"
            raise ValueError(f"Unsupported WireGuard setting '{original_key}' in [{label}]")
        sections[section].append((key, value.strip(), line_number))

    if counts != {"interface": 1, "peer": 1}:
        raise ValueError("WireGuard profile must contain exactly one [Interface] and one [Peer] section")

    def collect(section_name: str, key: str, repeatable: bool = False) -> list[str]:
        found = [value for found_key, value, _line in sections[section_name] if found_key == key]
        if not repeatable and len(found) > 1:
            raise ValueError(f"WireGuard setting '{key}' may appear only once")
        return found

    private_key = validate_wg_key((collect("interface", "privatekey") or [None])[0], "WireGuard PrivateKey")
    public_key = validate_wg_key((collect("peer", "publickey") or [None])[0], "WireGuard PublicKey")
    preshared_key = validate_wg_key(
        (collect("peer", "presharedkey") or [None])[0], "WireGuard PresharedKey", optional=True
    )

    address_inputs = split_wg_values(collect("interface", "address", repeatable=True), "Address", 8)
    addresses: list[str] = []
    address_families: set[int] = set()
    for address_text in address_inputs:
        address, family = canonical_interface(address_text)
        ip_text = address.rsplit("/", 1)[0]
        ip = ipaddress.ip_address(ip_text)
        if ip.is_unspecified or ip.is_loopback or ip.is_multicast:
            raise ValueError("WireGuard Address contains an unusable interface address")
        if address not in addresses:
            addresses.append(address)
        address_families.add(family)
    if 4 not in address_families:
        raise ValueError("WireGuard Address must include an IPv4 interface address for this application stack")

    allowed_inputs = split_wg_values(collect("peer", "allowedips", repeatable=True), "AllowedIPs", 8)
    allowed: set[str] = set()
    for allowed_text in allowed_inputs:
        network, _family = canonical_network(allowed_text)
        if network not in {"0.0.0.0/0", "::/0"}:
            raise ValueError(
                "Split-tunnel WireGuard AllowedIPs are not supported; this stack requires a full-tunnel profile"
            )
        allowed.add(network)
    if "0.0.0.0/0" not in allowed:
        raise ValueError("WireGuard AllowedIPs must include 0.0.0.0/0 for full-tunnel IPv4 routing")
    if 6 in address_families and "::/0" not in allowed:
        raise ValueError("A WireGuard profile with an IPv6 Address must include ::/0 in AllowedIPs")

    endpoint_values = collect("peer", "endpoint")
    if len(endpoint_values) != 1 or not endpoint_values[0]:
        raise ValueError("WireGuard Endpoint is required")
    endpoint = parse_wg_endpoint(endpoint_values[0])

    mtu_text = (collect("interface", "mtu") or ["1320"])[0]
    if not mtu_text.isdigit() or not 1280 <= int(mtu_text) <= 9000:
        raise ValueError("WireGuard MTU must be an integer from 1280 through 9000")
    persistent_text = (collect("peer", "persistentkeepalive") or ["0"])[0]
    if not persistent_text.isdigit() or not 0 <= int(persistent_text) <= 65535:
        raise ValueError("WireGuard PersistentKeepalive must be an integer from 0 through 65535 seconds")

    dns_inputs = [
        part.strip()
        for value in collect("interface", "dns", repeatable=True)
        for part in value.split(",")
        if part.strip()
    ]
    if len(dns_inputs) > 8:
        raise ValueError("WireGuard DNS has too many entries")
    for dns_value in dns_inputs:
        try:
            ipaddress.ip_address(dns_value)
        except ValueError as error:
            raise ValueError("WireGuard DNS entries must be valid IPv4 or IPv6 addresses") from error

    values: dict[str, Any] = {
        "privateKey": private_key,
        "publicKey": public_key,
        "presharedKey": preshared_key,
        "addresses": addresses,
        "endpoint": endpoint,
        "mtu": int(mtu_text),
        "persistentKeepalive": int(persistent_text),
    }
    canonical = render_wireguard(values)
    return {
        "content": canonical,
        "fingerprint": sha256_bytes(canonical.encode("utf-8")),
        "vpnProtocol": "wireguard",
        "transport": "udp",
        "protocol": "udp",
        "remotes": [{"host": endpoint["host"], "port": endpoint["port"], "protocol": "udp"}],
        "endpoint": endpoint["host"],
        "endpointPort": endpoint["port"],
        "endpointFamily": endpoint["family"],
        "tunnelFamilies": ["ipv4", *( ["ipv6"] if 6 in address_families else [] )],
        "hasPresharedKey": bool(preshared_key),
        "ignoredProfileDns": bool(dns_inputs),
        "mtu": values["mtu"],
        "persistentKeepalive": values["persistentKeepalive"],
        "_privateKey": private_key,
        "_publicKey": public_key,
        "_presharedKey": preshared_key,
        "_addresses": addresses,
        "_endpoint": endpoint,
    }


def infer_profile_protocol(path: Path, explicit: str | None = None) -> str:
    if explicit:
        protocol = explicit.strip().lower()
        if protocol not in {"openvpn", "wireguard"}:
            raise ValueError("VPN protocol must be openvpn or wireguard")
        return protocol
    suffix = path.suffix.lower()
    if suffix == ".ovpn":
        return "openvpn"
    if suffix == ".conf":
        return "wireguard"
    raise ValueError("VPN profile filename must end in .ovpn or .conf")


def parse_any_profile(data: bytes, protocol: str) -> dict[str, Any]:
    if protocol == "openvpn":
        return parse_profile(data)
    if protocol == "wireguard":
        return parse_wireguard_profile(data)
    raise ValueError("Unsupported VPN protocol")


class Manager:
    def __init__(self, project_dir: Path, health_timeout: int = 180) -> None:
        self.project = project_dir.resolve()
        self.compose = self.project / "compose.vpn.yml"
        self.vpn_dir = self.project / "vpn"
        self.control = self.project / "vpn-control"
        self.inbox = self.control / "inbox"
        self.processing = self.control / "processing"
        self.status_dir = self.control / "status"
        self.status_file = self.status_dir / "status.json"
        self.state_file = self.status_dir / "manager-state.json"
        self.transaction_file = self.control / "transaction.json"
        self.lock_file = self.control / "manager.lock"
        self.backups = self.vpn_dir / "profile-backups"
        self.prepare_script = self.vpn_dir / "prepare-profile.sh"
        self.health_timeout = health_timeout
        self.ensure_directories()
        self.ensure_runtime_layout()

    def ensure_directories(self) -> None:
        self.vpn_dir.mkdir(parents=True, exist_ok=True)
        self.inbox.mkdir(parents=True, exist_ok=True)
        self.processing.mkdir(parents=True, exist_ok=True)
        self.status_dir.mkdir(parents=True, exist_ok=True)
        self.backups.mkdir(parents=True, exist_ok=True)
        os.chmod(self.vpn_dir, 0o700)
        os.chmod(self.processing, 0o700)
        os.chmod(self.status_dir, 0o755)
        os.chmod(self.backups, 0o700)
        self.lock_file.touch(mode=0o600, exist_ok=True)
        os.chmod(self.lock_file, 0o600)
        if not self.status_file.exists():
            self.write_status("idle", "VPN profile manager is ready.", canRollback=self.rollback_available())

    def render_active_env(self, protocol: str, parsed: dict[str, Any] | None = None) -> bytes:
        values = {key: "" for key in ACTIVE_ENV_KEYS}
        values["VPN_TYPE"] = protocol
        values["WIREGUARD_ALLOWED_IPS"] = "0.0.0.0/0,::/0"
        values["WIREGUARD_IMPLEMENTATION"] = "auto"
        if protocol == "wireguard":
            if not parsed:
                raise ValueError("WireGuard settings are required for the active environment")
            endpoint = parsed["_endpoint"]
            values.update({
                "WIREGUARD_ENDPOINT_IP": endpoint["host"],
                "WIREGUARD_ENDPOINT_PORT": str(endpoint["port"]),
                "WIREGUARD_PUBLIC_KEY": parsed["_publicKey"],
                # Gluetun v3.41.1 parses this environment value as a Go
                # duration. Zero may be written as "0", but every non-zero
                # value requires an explicit unit (for example "25s"). Keep
                # the manager output canonical and unambiguous for all values.
                "WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL": f"{parsed['persistentKeepalive']}s",
                "WIREGUARD_MTU": str(parsed["mtu"]),
            })
        return ("\n".join(f"{key}={values[key]}" for key in ACTIVE_ENV_KEYS) + "\n").encode("utf-8")

    def parse_active_env(self, data: bytes | None = None) -> dict[str, str]:
        if data is None:
            data = read_regular_file(self.vpn_dir / "active.env", MAX_ENV_BYTES)
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as error:
            raise ValueError("active.env must be UTF-8") from error
        values: dict[str, str] = {}
        for number, line in enumerate(text.splitlines(), 1):
            if not line:
                continue
            if "=" not in line:
                raise ValueError(f"Malformed active VPN environment line {number}")
            key, value = line.split("=", 1)
            if key not in ACTIVE_ENV_KEYS or key in values or any(character.isspace() for character in value):
                raise ValueError(f"Invalid active VPN environment line {number}")
            values[key] = value
        if set(values) != set(ACTIVE_ENV_KEYS):
            raise ValueError("Active VPN environment has an incomplete key inventory")
        if values["VPN_TYPE"] not in {"openvpn", "wireguard"}:
            raise ValueError("Active VPN environment has an invalid protocol")
        if values["WIREGUARD_ALLOWED_IPS"] != "0.0.0.0/0,::/0":
            raise ValueError("Active VPN environment lost full-tunnel WireGuard routes")
        if values["WIREGUARD_IMPLEMENTATION"] != "auto":
            raise ValueError("Active VPN environment has an unsupported WireGuard implementation")
        dynamic_keys = (
            "WIREGUARD_ENDPOINT_IP", "WIREGUARD_ENDPOINT_PORT", "WIREGUARD_PUBLIC_KEY",
            "WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL", "WIREGUARD_MTU",
        )
        if values["VPN_TYPE"] == "openvpn":
            if any(values[key] for key in dynamic_keys):
                raise ValueError("Inactive WireGuard environment values must be empty")
        else:
            try:
                endpoint_ip = ipaddress.ip_address(values["WIREGUARD_ENDPOINT_IP"])
            except ValueError as error:
                raise ValueError("Active WireGuard endpoint must be a resolved IP address") from error
            if endpoint_ip.is_unspecified or endpoint_ip.is_multicast:
                raise ValueError("Active WireGuard endpoint IP is unusable")
            port = values["WIREGUARD_ENDPOINT_PORT"]
            if not port.isdigit() or not 1 <= int(port) <= 65535:
                raise ValueError("Active WireGuard endpoint port is invalid")
            validate_wg_key(values["WIREGUARD_PUBLIC_KEY"], "Active WireGuard public key")
            keepalive = values["WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL"]
            mtu = values["WIREGUARD_MTU"]
            # Gluetun v3.41.1 consumes this as a Go duration. Newly rendered
            # state is always canonical integer seconds with an "s" suffix.
            # Accept the legacy bare "0" only so a healthy -9 profile using
            # Gluetun's special zero-duration spelling remains upgradeable and
            # rollback-compatible; reject every non-zero unitless value.
            keepalive_match = re.fullmatch(r"(0|([0-9]+)s)", keepalive)
            keepalive_seconds = int(keepalive_match.group(2) or 0) if keepalive_match else -1
            if not keepalive_match or not 0 <= keepalive_seconds <= 65535:
                raise ValueError("Active WireGuard keepalive must be zero or integer seconds with an s suffix")
            if not mtu.isdigit() or not 1280 <= int(mtu) <= 9000:
                raise ValueError("Active WireGuard MTU is invalid")
        return values

    def ensure_runtime_layout(self) -> None:
        for name in RUNTIME_FILES[:-1]:
            path = self.vpn_dir / name
            if not path.exists():
                atomic_bytes(path, b"", 0o600)
            else:
                read_regular_file(path, MAX_OVPN_BYTES)
                os.chmod(path, 0o600)
        env_path = self.vpn_dir / "active.env"
        if not env_path.exists():
            wireguard_data = read_regular_file(self.vpn_dir / "wireguard.conf", MAX_WIREGUARD_BYTES)
            openvpn_data = read_regular_file(self.vpn_dir / "client.gluetun.ovpn", MAX_OVPN_BYTES)
            if wireguard_data and not openvpn_data:
                parsed = parse_wireguard_profile(wireguard_data)
                atomic_bytes(env_path, self.render_active_env("wireguard", parsed), 0o600)
            else:
                atomic_bytes(env_path, self.render_active_env("openvpn"), 0o600)
        else:
            self.parse_active_env(read_regular_file(env_path, MAX_ENV_BYTES))
            os.chmod(env_path, 0o600)

    def write_status(self, state: str, message: str, **extra: Any) -> None:
        safe_extra = dict(extra)
        if safe_extra.get("error") is not None:
            safe_extra["error"] = sanitize_public_error(safe_extra["error"])
        status = {
            "schemaVersion": 2,
            "managerAvailable": True,
            "state": state,
            "message": str(message)[:1000],
            "updatedAt": utc_now(),
            **safe_extra,
        }
        atomic_json(self.status_file, status, 0o644)

    def load_state(self) -> dict[str, Any]:
        try:
            data = read_regular_file(self.state_file, MAX_STATE_BYTES)
            value = json.loads(data.decode("utf-8"))
            return value if isinstance(value, dict) else {"schemaVersion": 2}
        except (FileNotFoundError, UnicodeDecodeError, json.JSONDecodeError, OSError, ValueError):
            return {"schemaVersion": 2}

    def save_state(self, value: dict[str, Any]) -> None:
        atomic_json(self.state_file, {"schemaVersion": 2, **value}, 0o600)

    def active_protocol(self) -> str:
        return self.parse_active_env()["VPN_TYPE"]

    def active_profile_path(self, protocol: str | None = None) -> Path:
        protocol = protocol or self.active_protocol()
        return self.vpn_dir / ("client.gluetun.ovpn" if protocol == "openvpn" else "wireguard.conf")

    def has_active_profile(self) -> bool:
        path = self.active_profile_path()
        try:
            return path.stat().st_size > 0 and path.is_file() and not path.is_symlink()
        except FileNotFoundError:
            return False

    def rollback_available(self) -> bool:
        relative = self.load_state().get("rollbackBackup")
        if not relative:
            return False
        try:
            target = (self.project / str(relative)).resolve()
            return self.backups.resolve() in target.parents and target.is_dir()
        except (OSError, RuntimeError):
            return False

    def command(self, args: list[str], timeout: int = 240, check: bool = True) -> subprocess.CompletedProcess[str]:
        result = subprocess.run(
            args,
            cwd=self.project,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            env={**os.environ, "COMPOSE_PROJECT_NAME": "vine-drop-hub-vpn"},
        )
        if check and result.returncode != 0:
            # Command output can include provider endpoints and Gluetun's
            # obfuscated settings. Keep only a scrubbed bounded tail.
            tail = "\n".join(result.stdout.splitlines()[-20:])
            raise RuntimeError(
                f"Command failed ({' '.join(args[:4])}): {sanitize_public_error(tail or 'no output', 1200)}"
            )
        return result

    def compose_command(self, *args: str, timeout: int = 240, check: bool = True) -> subprocess.CompletedProcess[str]:
        return self.command(
            ["docker", "compose", "-f", str(self.compose), *args], timeout=timeout, check=check
        )

    def safe_profile_metadata(self, parsed: dict[str, Any]) -> dict[str, Any]:
        first = parsed["remotes"][0]
        endpoint_family = parsed.get("endpointFamily")
        if not endpoint_family:
            try:
                endpoint_family = "ipv4" if ipaddress.ip_address(first["host"]).version == 4 else "ipv6"
            except ValueError:
                endpoint_family = "hostname"
        return {
            "vpnProtocol": parsed["vpnProtocol"],
            "transport": parsed["transport"],
            "protocol": parsed["transport"],
            "endpoint": first["host"],
            "port": first["port"],
            "endpointFamily": endpoint_family,
            "tunnelFamilies": list(parsed.get("tunnelFamilies") or ["ipv4"]),
            "fingerprint": parsed["fingerprint"][:16],
        }

    def profile_metadata(self, protocol: str | None = None) -> dict[str, Any]:
        protocol = protocol or self.active_protocol()
        path = self.active_profile_path(protocol)
        maximum = MAX_OVPN_BYTES if protocol == "openvpn" else MAX_WIREGUARD_BYTES
        parsed = parse_any_profile(read_regular_file(path, maximum), protocol)
        return self.safe_profile_metadata(parsed)

    def backup_manifest(self, backup: Path) -> tuple[int, dict[str, Any]]:
        raw = read_regular_file(backup / "manifest.json", MAX_STATE_BYTES)
        try:
            manifest = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise RuntimeError("Backup manifest is invalid") from error
        if not isinstance(manifest, dict):
            raise RuntimeError("Backup manifest is invalid")
        schema = manifest.get("schemaVersion")
        if schema not in {1, 2}:
            raise RuntimeError("Backup manifest schema is unsupported")
        return int(schema), manifest

    def make_backup(self, request_id: str, label: str = "previous") -> Path:
        timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        backup = self.backups / f"{timestamp}-{request_id}-{label}"
        backup.mkdir(mode=0o700)
        hashes: dict[str, str] = {}
        sizes: dict[str, int] = {}
        for name in RUNTIME_FILES:
            source = self.vpn_dir / name
            data = read_regular_file(source, MAX_OVPN_BYTES)
            atomic_bytes(backup / name, data, 0o600)
            hashes[name] = sha256_bytes(data)
            sizes[name] = len(data)
        manifest = {
            "schemaVersion": 2,
            "requestId": request_id,
            "createdAt": utc_now(),
            "label": label,
            "activeProtocol": self.active_protocol(),
            "hasActiveProfile": self.has_active_profile(),
            "files": hashes,
            "sizes": sizes,
        }
        atomic_json(backup / "manifest.json", manifest, 0o600)
        return backup

    def validated_backup_files(self, backup: Path) -> dict[str, bytes]:
        resolved = backup.resolve()
        if self.backups.resolve() not in resolved.parents:
            raise RuntimeError("Refusing backup path outside the private profile backup directory")
        schema, manifest = self.backup_manifest(resolved)
        if schema == 1:
            # Backward-compatible exact -8 backups contain only the OpenVPN
            # source/prepared pair. Synthesize the successor's inactive
            # WireGuard placeholders and OpenVPN protocol selector.
            files: dict[str, bytes] = {}
            for name in ("client.ovpn", "client.gluetun.ovpn"):
                files[name] = read_regular_file(resolved / name, MAX_OVPN_BYTES)
                parse_profile(files[name])
            files["wireguard.conf"] = b""
            files["wg0.conf"] = b""
            files["active.env"] = self.render_active_env("openvpn")
            return files

        expected = set(RUNTIME_FILES)
        hashes = manifest.get("files")
        sizes = manifest.get("sizes")
        if not isinstance(hashes, dict) or set(hashes) != expected or not isinstance(sizes, dict) or set(sizes) != expected:
            raise RuntimeError("Backup file inventory is invalid")
        files = {}
        for name in RUNTIME_FILES:
            data = read_regular_file(resolved / name, MAX_OVPN_BYTES)
            if sha256_bytes(data) != hashes[name] or len(data) != sizes[name]:
                raise RuntimeError(f"Backup integrity check failed for {name}")
            files[name] = data
        env = self.parse_active_env(files["active.env"])
        protocol = env["VPN_TYPE"]
        active_name = "client.gluetun.ovpn" if protocol == "openvpn" else "wireguard.conf"
        has_active_profile = manifest.get("hasActiveProfile", True)
        if not isinstance(has_active_profile, bool):
            raise RuntimeError("Backup active-profile marker is invalid")
        if has_active_profile:
            parse_any_profile(files[active_name], protocol)
        elif files[active_name]:
            raise RuntimeError("Backup marked inactive but contains an active profile")
        return files

    def install_runtime_files(self, files: dict[str, bytes]) -> None:
        if set(files) != set(RUNTIME_FILES):
            raise RuntimeError("Staged VPN runtime file inventory is incomplete")
        self.parse_active_env(files["active.env"])
        for name in RUNTIME_FILES:
            atomic_bytes(self.vpn_dir / name, files[name], 0o600)

    def restore_backup_files(self, backup: Path) -> None:
        self.install_runtime_files(self.validated_backup_files(backup))

    def resolve_wireguard_endpoint(self, parsed: dict[str, Any]) -> dict[str, Any]:
        endpoint = parsed["_endpoint"]
        if endpoint["family"] in {"ipv4", "ipv6"}:
            return endpoint
        try:
            answers = socket.getaddrinfo(
                endpoint["host"], endpoint["port"], socket.AF_UNSPEC, socket.SOCK_DGRAM, socket.IPPROTO_UDP
            )
        except socket.gaierror as error:
            raise ValueError("WireGuard Endpoint hostname could not be resolved on the host") from error
        addresses: dict[str, ipaddress.IPv4Address | ipaddress.IPv6Address] = {}
        for family, _kind, _protocol, _canonical, socket_address in answers:
            if family not in {socket.AF_INET, socket.AF_INET6}:
                continue
            try:
                address = ipaddress.ip_address(socket_address[0])
            except ValueError:
                continue
            if address.is_unspecified or address.is_multicast:
                continue
            addresses[address.compressed] = address
        if not addresses:
            raise ValueError("WireGuard Endpoint hostname has no usable IPv4 or IPv6 address")
        # Prefer IPv4 for compatibility with hosts lacking native IPv6. An
        # explicit IPv6 endpoint, or a hostname with only AAAA records, still
        # exercises the fully supported IPv6 endpoint path.
        selected = sorted(addresses.values(), key=lambda value: (value.version, value.packed))[0]
        family = "ipv4" if selected.version == 4 else "ipv6"
        host = selected.compressed
        return {
            "host": host,
            "port": endpoint["port"],
            "family": family,
            "value": f"[{host}]:{endpoint['port']}" if family == "ipv6" else f"{host}:{endpoint['port']}",
        }

    def prepare_wireguard_runtime(self, parsed: dict[str, Any]) -> tuple[bytes, bytes]:
        resolved = self.resolve_wireguard_endpoint(parsed)
        prepared = dict(parsed)
        prepared["_endpoint"] = resolved
        secret_lines = [
            "# Vine private Gluetun WireGuard secret source.",
            "[Interface]",
            f"PrivateKey = {parsed['_privateKey']}",
            f"Address = {', '.join(parsed['_addresses'])}",
        ]
        if parsed["_presharedKey"]:
            secret_lines.extend(["", "[Peer]", f"PresharedKey = {parsed['_presharedKey']}"])
        secret_content = ("\n".join(secret_lines) + "\n").encode("utf-8")
        return secret_content, self.render_active_env("wireguard", prepared)

    def stage_candidate(self, protocol: str, data: bytes, temp_dir: Path) -> tuple[dict[str, bytes], dict[str, Any]]:
        parsed = parse_any_profile(data, protocol)
        if protocol == "openvpn":
            source = temp_dir / "client.ovpn"
            prepared = temp_dir / "client.gluetun.ovpn"
            atomic_bytes(source, parsed["content"].encode("utf-8"), 0o600)
            self.command(["/bin/bash", str(self.prepare_script), str(source), str(prepared)], timeout=45)
            prepared_data = read_regular_file(prepared, MAX_OVPN_BYTES)
            prepared_parsed = parse_profile(prepared_data)
            files = {
                "client.ovpn": parsed["content"].encode("utf-8"),
                "client.gluetun.ovpn": prepared_data,
                "wireguard.conf": b"",
                "wg0.conf": b"",
                "active.env": self.render_active_env("openvpn"),
            }
            return files, prepared_parsed

        canonical_data = parsed["content"].encode("utf-8")
        # The Node boundary always emits this canonical representation. The
        # root manager accepts standard .conf input for CLI/fresh installs but
        # re-renders it before any runtime use.
        secret_content, active_env = self.prepare_wireguard_runtime(parsed)
        files = {
            "client.ovpn": b"",
            "client.gluetun.ovpn": b"",
            "wireguard.conf": canonical_data,
            "wg0.conf": secret_content,
            "active.env": active_env,
        }
        resolved_values = self.parse_active_env(active_env)
        resolved = dict(parsed)
        resolved_endpoint = {
            "host": resolved_values["WIREGUARD_ENDPOINT_IP"],
            "port": int(resolved_values["WIREGUARD_ENDPOINT_PORT"]),
            "family": "ipv6" if ":" in resolved_values["WIREGUARD_ENDPOINT_IP"] else "ipv4",
        }
        resolved["remotes"] = [{
            "host": resolved_endpoint["host"],
            "port": resolved_endpoint["port"],
            "protocol": "udp",
        }]
        resolved["endpointFamily"] = resolved_endpoint["family"]
        return files, resolved

    def inspect_health(self, container: str) -> tuple[str, str]:
        result = self.command(
            [
                "docker", "inspect", "--format",
                "{{.State.Status}}|{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}",
                container,
            ],
            timeout=15,
            check=False,
        )
        if result.returncode != 0:
            return "missing", "missing"
        value = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else "missing|missing"
        status, _, health = value.partition("|")
        return status, health

    def wait_for_health(self) -> None:
        deadline = time.monotonic() + self.health_timeout
        last = ""
        while time.monotonic() < deadline:
            vpn_status, vpn_health = self.inspect_health("vine-vpn")
            sv_status, sv_health = self.inspect_health("vine-sv-vpn-proxy")
            app_status, app_health = self.inspect_health("vine-drop-hub")
            last = (
                f"vpn={vpn_status}/{vpn_health}, "
                f"sv-proxy={sv_status}/{sv_health}, "
                f"app={app_status}/{app_health}"
            )
            if (
                vpn_status == "running" and vpn_health == "healthy"
                and sv_status == "running" and sv_health == "healthy"
                and app_status == "running" and app_health == "healthy"
            ):
                return
            time.sleep(2)
        raise RuntimeError(f"Container health did not recover before timeout ({last})")

    def verify_wireguard_egress(self, metadata: dict[str, Any]) -> None:
        # The app shares Gluetun's namespace. Explicit DNS-family selection and
        # HTTPS certificate validation prove that the configured tunnel carries
        # each claimed family rather than merely creating a healthy interface.
        families = [4]
        if "ipv6" in metadata.get("tunnelFamilies", []):
            families.append(6)
        probe_script = r"""
const dns = require('dns');
const https = require('https');
const family = Number(process.argv[1]);
const hostname = family === 6 ? 'ipv6.google.com' : 'ipv4.google.com';
const lookup = (name, options, callback) => dns.lookup(name, { ...options, family, all: false }, callback);
const request = https.get({ hostname, path: '/generate_204', family, lookup, timeout: 12000, headers: { 'User-Agent': 'Vine-VPN-Health/1' } }, response => {
  response.resume();
  process.exit(response.statusCode >= 200 && response.statusCode < 400 ? 0 : 2);
});
request.on('timeout', () => request.destroy(new Error('timeout')));
request.on('error', () => process.exit(3));
setTimeout(() => process.exit(4), 15000).unref();
""".strip()
        for family in families:
            result = self.command(
                ["docker", "exec", "vine-drop-hub", "node", "-e", probe_script, str(family)],
                timeout=20,
                check=False,
            )
            if result.returncode != 0:
                label = "IPv6" if family == 6 else "IPv4"
                raise RuntimeError(f"WireGuard {label} HTTPS egress validation failed")

    def recreate_and_verify(self, metadata: dict[str, Any] | None = None) -> None:
        self.compose_command("config", "--quiet", timeout=60)
        # sv-proxy uses network_mode: service:vpn, so it must be recreated with
        # the VPN container rather than left attached to the old namespace.
        self.compose_command(
            "up", "-d", "--force-recreate", "vpn", "sv-proxy", "app",
            timeout=self.health_timeout + 60,
        )
        self.wait_for_health()
        metadata = metadata or self.profile_metadata()
        if metadata.get("vpnProtocol") == "wireguard":
            self.verify_wireguard_egress(metadata)

    def write_transaction(self, **value: Any) -> None:
        atomic_json(self.transaction_file, {"schemaVersion": 2, "updatedAt": utc_now(), **value}, 0o600)

    def load_transaction(self) -> dict[str, Any] | None:
        try:
            data = read_regular_file(self.transaction_file, MAX_STATE_BYTES)
        except FileNotFoundError:
            return None
        try:
            value = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise RuntimeError("VPN transaction journal is invalid") from error
        if not isinstance(value, dict) or value.get("schemaVersion") != 2:
            raise RuntimeError("VPN transaction journal schema is invalid")
        return value

    def clear_transaction(self) -> None:
        with contextlib.suppress(FileNotFoundError):
            self.transaction_file.unlink()

    def cleanup_request_artifacts(self, request_id: str) -> None:
        if not REQUEST_ID_RE.fullmatch(request_id):
            return
        for path in (
            self.processing / f"{request_id}.request.json",
            self.inbox / f"{request_id}.ovpn",
            self.inbox / f"{request_id}.conf",
        ):
            with contextlib.suppress(FileNotFoundError):
                path.unlink()

    def recover_interrupted_transaction(self) -> bool:
        transaction = self.load_transaction()
        if not transaction:
            return True
        request_id = str(transaction.get("requestId") or "unknown")
        phase = str(transaction.get("phase") or "unknown")
        relative = transaction.get("recoveryBackup")
        if phase == "backed_up":
            # No managed runtime file has been touched yet.
            self.write_status(
                "failed",
                "An interrupted VPN request was cancelled before activation; the active profile was unchanged.",
                requestId=request_id,
                finishedAt=utc_now(),
                canRollback=self.rollback_available(),
            )
            self.clear_transaction()
            self.cleanup_request_artifacts(request_id)
            return True
        try:
            if not relative:
                raise RuntimeError("Interrupted transaction has no recovery backup")
            backup = (self.project / str(relative)).resolve()
            self.write_status(
                "rolling_back",
                "Recovering an interrupted VPN transaction by restoring its previous complete protocol state.",
                requestId=request_id,
            )
            self.restore_backup_files(backup)
            recreate_after_restore = transaction.get("recreateAfterRestore", True) is not False
            if recreate_after_restore:
                metadata = self.profile_metadata()
                self.recreate_and_verify(metadata)
                self.write_status(
                    "rolled_back",
                    "The interrupted VPN transaction was recovered and the previous profile is healthy.",
                    requestId=request_id,
                    finishedAt=utc_now(),
                    activeProfile=metadata,
                    canRollback=self.rollback_available(),
                )
            else:
                self.write_status(
                    "failed",
                    "Interrupted initial VPN preparation was recovered before activation; no profile is active.",
                    requestId=request_id,
                    finishedAt=utc_now(),
                    canRollback=False,
                )
            self.clear_transaction()
            self.cleanup_request_artifacts(request_id)
            return True
        except Exception as error:
            self.write_status(
                "failed",
                "Interrupted VPN transaction recovery did not complete; no new request will be processed.",
                requestId=request_id,
                error=error,
                canRollback=False,
            )
            return False

    def cleanup_orphaned_claims(self) -> None:
        for claimed in sorted(self.processing.glob("*.request.json")):
            match = re.fullmatch(f"({REQUEST_ID_RE.pattern[1:-1]})\\.request\\.json", claimed.name)
            request_id = match.group(1) if match else "unknown"
            self.cleanup_request_artifacts(request_id)
            with contextlib.suppress(FileNotFoundError):
                claimed.unlink()
            self.write_status(
                "failed",
                "A request interrupted before activation was discarded; the active VPN profile was unchanged.",
                requestId=request_id,
                finishedAt=utc_now(),
                canRollback=self.rollback_available(),
            )

    def rollback_after_failure(self, backup: Path, request_id: str, reason: str) -> None:
        self.write_status(
            "rolling_back",
            "The new VPN profile failed health checks; restoring the previous complete protocol state.",
            requestId=request_id,
            error=reason,
        )
        self.write_transaction(
            phase="rolling_back",
            requestId=request_id,
            recoveryBackup=str(backup.relative_to(self.project)),
        )
        self.restore_backup_files(backup)
        active = self.profile_metadata()
        self.recreate_and_verify(active)
        self.write_status(
            "rolled_back",
            "The new profile failed and the previous working VPN profile was restored automatically.",
            requestId=request_id,
            finishedAt=utc_now(),
            activeProfile=active,
            error=reason,
            canRollback=self.rollback_available(),
        )
        self.clear_transaction()

    def process_apply(self, request: dict[str, Any], candidate_path: Path, protocol: str) -> None:
        request_id = request["requestId"]
        default_name = "profile.ovpn" if protocol == "openvpn" else "profile.conf"
        original_name = Path(str(request.get("originalName") or default_name)).name[:180]
        self.write_status(
            "validating",
            f"Validating the uploaded {'OpenVPN' if protocol == 'openvpn' else 'WireGuard'} profile.",
            requestId=request_id,
            originalName=original_name,
            submittedAt=request.get("submittedAt"),
        )

        maximum = MAX_OVPN_BYTES if protocol == "openvpn" else MAX_WIREGUARD_BYTES
        candidate_data = read_regular_file(candidate_path, maximum)
        digest = sha256_bytes(candidate_data)
        if digest != request.get("sha256"):
            raise ValueError("Uploaded profile checksum does not match its request")
        parse_any_profile(candidate_data, protocol)

        with tempfile.TemporaryDirectory(prefix=".vpn-switch-", dir=self.vpn_dir) as temp_dir_name:
            temp_dir = Path(temp_dir_name)
            os.chmod(temp_dir, 0o700)
            staged_files, prepared = self.stage_candidate(protocol, candidate_data, temp_dir)
            backup = self.make_backup(request_id)
            backup_relative = str(backup.relative_to(self.project))
            self.write_transaction(
                phase="backed_up", requestId=request_id, recoveryBackup=backup_relative, targetProtocol=protocol
            )
            try:
                self.write_transaction(
                    phase="installing", requestId=request_id, recoveryBackup=backup_relative, targetProtocol=protocol
                )
                self.install_runtime_files(staged_files)
                self.compose_command("config", "--quiet", timeout=60)
                new_profile = self.safe_profile_metadata(prepared)
                self.write_transaction(
                    phase="activating", requestId=request_id, recoveryBackup=backup_relative, targetProtocol=protocol
                )
                self.write_status(
                    "applying",
                    "Applying the new VPN profile. The dashboard will reconnect automatically.",
                    requestId=request_id,
                    originalName=original_name,
                    startedAt=utc_now(),
                    candidateProfile=new_profile,
                )
                self.recreate_and_verify(new_profile)
            except Exception as error:
                self.rollback_after_failure(backup, request_id, str(error))
                return

        state = self.load_state()
        state.update({
            "rollbackBackup": str(backup.relative_to(self.project)),
            "activeProtocol": protocol,
            "lastAppliedRequestId": request_id,
            "lastAppliedAt": utc_now(),
        })
        self.save_state(state)
        active = self.profile_metadata()
        self.write_status(
            "applied",
            "The new VPN profile is active and the VPN, SmartViner proxy, and application containers are healthy.",
            requestId=request_id,
            originalName=original_name,
            finishedAt=utc_now(),
            activeProfile=active,
            canRollback=True,
        )
        self.clear_transaction()
        self.prune_backups()

    def process_rollback(self, request: dict[str, Any]) -> None:
        request_id = request["requestId"]
        state = self.load_state()
        relative = state.get("rollbackBackup")
        if not relative:
            raise RuntimeError("No previous dashboard-managed VPN profile is available for rollback")
        target = (self.project / str(relative)).resolve()
        if self.backups.resolve() not in target.parents or not target.is_dir():
            raise RuntimeError("The recorded rollback backup is unavailable")
        self.validated_backup_files(target)

        current_backup = self.make_backup(request_id, "before-manual-rollback")
        current_relative = str(current_backup.relative_to(self.project))
        self.write_transaction(
            phase="backed_up", requestId=request_id, recoveryBackup=current_relative, targetBackup=str(relative)
        )
        self.write_status(
            "rolling_back",
            "Restoring the previous dashboard-managed VPN profile.",
            requestId=request_id,
            startedAt=utc_now(),
        )
        try:
            self.write_transaction(
                phase="installing", requestId=request_id, recoveryBackup=current_relative, targetBackup=str(relative)
            )
            self.restore_backup_files(target)
            metadata = self.profile_metadata()
            self.write_transaction(
                phase="activating", requestId=request_id, recoveryBackup=current_relative, targetBackup=str(relative)
            )
            self.recreate_and_verify(metadata)
        except Exception:
            self.write_transaction(
                phase="rolling_back", requestId=request_id, recoveryBackup=current_relative, targetBackup=str(relative)
            )
            self.restore_backup_files(current_backup)
            self.recreate_and_verify(self.profile_metadata())
            # Leave the journal until the next manager iteration performs the
            # same conservative recovery and publishes a terminal status.
            raise

        state.update({
            "rollbackBackup": current_relative,
            "activeProtocol": self.active_protocol(),
            "lastRollbackRequestId": request_id,
            "lastRollbackAt": utc_now(),
        })
        self.save_state(state)
        active = self.profile_metadata()
        self.write_status(
            "rolled_back",
            "The previous VPN profile was restored successfully.",
            requestId=request_id,
            finishedAt=utc_now(),
            activeProfile=active,
            canRollback=True,
        )
        self.clear_transaction()
        self.prune_backups()

    def install_profile_without_start(self, profile_path: Path, protocol: str | None = None) -> dict[str, Any]:
        """Prepare an initial/replacement profile without starting Compose.

        Finalization still gets the same complete-state journal and recovery
        guarantees as a dashboard switch. A fresh installation backs up its
        empty placeholders so an interrupted five-file install can be returned
        to a coherent no-profile state on the next manager start.
        """
        protocol = infer_profile_protocol(profile_path, protocol)
        maximum = MAX_OVPN_BYTES if protocol == "openvpn" else MAX_WIREGUARD_BYTES
        data = read_regular_file(profile_path, maximum)
        request_id = str(uuid.uuid4())
        previous_profile_present = self.has_active_profile()

        with tempfile.TemporaryDirectory(prefix=".vpn-initial-", dir=self.vpn_dir) as temp_name:
            files, prepared = self.stage_candidate(protocol, data, Path(temp_name))
            backup = self.make_backup(request_id, "before-finalize")
            backup_relative = str(backup.relative_to(self.project))
            self.write_transaction(
                phase="backed_up",
                requestId=request_id,
                recoveryBackup=backup_relative,
                targetProtocol=protocol,
                recreateAfterRestore=previous_profile_present,
            )
            try:
                self.write_transaction(
                    phase="installing",
                    requestId=request_id,
                    recoveryBackup=backup_relative,
                    targetProtocol=protocol,
                    recreateAfterRestore=previous_profile_present,
                )
                self.install_runtime_files(files)
            except Exception as error:
                self.write_transaction(
                    phase="rolling_back",
                    requestId=request_id,
                    recoveryBackup=backup_relative,
                    targetProtocol=protocol,
                    recreateAfterRestore=False,
                )
                try:
                    self.restore_backup_files(backup)
                    self.write_status(
                        "failed",
                        "VPN profile preparation failed; the previous complete runtime state was restored.",
                        requestId=request_id,
                        finishedAt=utc_now(),
                        error=error,
                        canRollback=self.rollback_available(),
                    )
                    self.clear_transaction()
                except Exception:
                    # Keep the journal so the service retries conservative
                    # recovery before it accepts any dashboard request.
                    raise
                raise

        state = self.load_state()
        state["activeProtocol"] = protocol
        if previous_profile_present:
            state["rollbackBackup"] = backup_relative
        else:
            state.pop("rollbackBackup", None)
        self.save_state(state)
        metadata = self.safe_profile_metadata(prepared)
        self.write_status(
            "prepared",
            "VPN profile is prepared; Compose has not yet been started by this command.",
            requestId=request_id,
            activeProfile=metadata,
            canRollback=previous_profile_present,
        )
        self.clear_transaction()
        self.prune_backups()
        return metadata

    def prune_backups(self, keep: int = 12) -> None:
        protected: set[Path] = set()
        state_relative = self.load_state().get("rollbackBackup")
        if state_relative:
            with contextlib.suppress(OSError, RuntimeError):
                protected.add((self.project / str(state_relative)).resolve())
        with contextlib.suppress(Exception):
            transaction = self.load_transaction()
            if transaction and transaction.get("recoveryBackup"):
                protected.add((self.project / str(transaction["recoveryBackup"])).resolve())
        directories = sorted(
            (entry for entry in self.backups.iterdir() if entry.is_dir()),
            key=lambda entry: entry.name,
            reverse=True,
        )
        retained = 0
        for entry in directories:
            if entry.resolve() in protected:
                continue
            retained += 1
            if retained > keep:
                shutil.rmtree(entry)

    def claim_request(self) -> Path | None:
        for request_path in sorted(self.inbox.glob("*.request.json")):
            claimed = self.processing / request_path.name
            try:
                os.replace(request_path, claimed)
                return claimed
            except FileNotFoundError:
                continue
        return None

    def process_once(self) -> bool:
        with self.lock_file.open("r+") as lock_handle:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
            if not self.recover_interrupted_transaction():
                return False
            self.cleanup_orphaned_claims()
            claimed = self.claim_request()
            if not claimed:
                return False

            request_id = "unknown"
            candidate: Path | None = None
            try:
                request_data = read_regular_file(claimed, MAX_REQUEST_BYTES)
                request = json.loads(request_data.decode("utf-8"))
                if not isinstance(request, dict):
                    raise ValueError("VPN manager request must be an object")
                request_id = str(request.get("requestId") or "")
                if not REQUEST_ID_RE.fullmatch(request_id):
                    raise ValueError("Invalid request identifier")
                if request.get("schemaVersion") not in {1, 2}:
                    raise ValueError("Unsupported VPN manager request schema")
                action = request.get("action")
                if action == "apply":
                    protocol = str(request.get("vpnProtocol") or "openvpn").lower()
                    if protocol not in {"openvpn", "wireguard"}:
                        raise ValueError("Invalid VPN protocol")
                    extension = "ovpn" if protocol == "openvpn" else "conf"
                    candidate_name = str(request.get("candidateFile") or "")
                    if candidate_name != f"{request_id}.{extension}":
                        raise ValueError("Invalid candidate filename")
                    candidate = self.inbox / candidate_name
                    self.process_apply(request, candidate, protocol)
                elif action == "rollback":
                    self.process_rollback(request)
                else:
                    raise ValueError("Unsupported VPN manager action")
            except Exception as error:
                self.write_status(
                    "failed",
                    "The VPN profile request failed before a new profile became active, or its recovery remains pending.",
                    requestId=request_id,
                    finishedAt=utc_now(),
                    error=error,
                    canRollback=self.rollback_available(),
                )
            finally:
                with contextlib.suppress(FileNotFoundError):
                    claimed.unlink()
                if candidate:
                    with contextlib.suppress(FileNotFoundError):
                        candidate.unlink()
            return True

    def watch(self, interval: float) -> None:
        print(f"VPN profile manager watching {self.inbox}", flush=True)
        while True:
            handled = self.process_once()
            if not handled:
                time.sleep(interval)


def safe_cli_profile(parsed: dict[str, Any]) -> dict[str, Any]:
    first = parsed["remotes"][0]
    return {
        "valid": True,
        "vpnProtocol": parsed["vpnProtocol"],
        "transport": parsed["transport"],
        "endpoint": first["host"],
        "port": first["port"],
        "endpointFamily": parsed.get("endpointFamily", "hostname"),
        "tunnelFamilies": parsed.get("tunnelFamilies", ["ipv4"]),
        "fingerprint": parsed["fingerprint"][:16],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir", default=os.environ.get("VINE_PROJECT_DIR", "/opt/vine-drop-hub"))
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--validate-profile")
    parser.add_argument("--install-profile")
    parser.add_argument("--protocol", choices=("openvpn", "wireguard"))
    parser.add_argument("--initialize-runtime", action="store_true")
    parser.add_argument("--verify-active", action="store_true")
    parser.add_argument("--interval", type=float, default=1.0)
    parser.add_argument("--health-timeout", type=int, default=180)
    args = parser.parse_args()

    if args.validate_profile:
        profile_path = Path(args.validate_profile)
        protocol = infer_profile_protocol(profile_path, args.protocol)
        maximum = MAX_OVPN_BYTES if protocol == "openvpn" else MAX_WIREGUARD_BYTES
        parsed = parse_any_profile(read_regular_file(profile_path, maximum), protocol)
        print(json.dumps(safe_cli_profile(parsed), indent=2))
        return 0

    if os.geteuid() != 0:
        print("VPN profile manager must run as root", file=sys.stderr)
        return 1

    manager = Manager(Path(args.project_dir), health_timeout=args.health_timeout)
    if args.initialize_runtime:
        print(json.dumps({"initialized": True, "activeProtocol": manager.active_protocol()}, indent=2))
        return 0
    if args.install_profile:
        metadata = manager.install_profile_without_start(Path(args.install_profile), args.protocol)
        print(json.dumps({"installed": True, "profile": metadata}, indent=2))
        return 0
    if args.verify_active:
        metadata = manager.profile_metadata()
        manager.wait_for_health()
        if metadata.get("vpnProtocol") == "wireguard":
            manager.verify_wireguard_egress(metadata)
        manager.write_status(
            "applied",
            "The active VPN profile and all VPN-bound containers passed health validation.",
            activeProfile=metadata,
            finishedAt=utc_now(),
            canRollback=manager.rollback_available(),
        )
        print(json.dumps({"healthy": True, "profile": metadata}, indent=2))
        return 0
    if args.once:
        manager.process_once()
        return 0
    manager.watch(max(0.2, args.interval))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
