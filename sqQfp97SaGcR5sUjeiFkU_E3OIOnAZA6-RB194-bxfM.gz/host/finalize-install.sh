#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

PROJECT_DIR="${VINE_PROJECT_DIR:-/opt/vine-drop-hub}"
PROFILE_SOURCE=""
START_SERVICES=1
HEALTH_TIMEOUT="${VINE_INSTALL_HEALTH_TIMEOUT:-300}"

usage() {
  cat <<'EOF'
Usage: sudo finalize-install.sh [--project-dir PATH] [--profile /private/path/profile.ovpn-or.conf] [--no-start]

For a clean installation, privately transfer either one self-contained OpenVPN
.ovpn profile or one standard WireGuard .conf profile and supply it with
--profile. Profile contents, credentials, private keys, tokens, and populated
private state must never be pasted into chat.
EOF
}

while (($#)); do
  case "$1" in
    --project-dir) PROJECT_DIR="$2"; shift 2 ;;
    --profile) PROFILE_SOURCE="$2"; shift 2 ;;
    --no-start) START_SERVICES=0; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ $EUID -eq 0 ]] || { echo "ERROR: run this script with sudo." >&2; exit 1; }
[[ $HEALTH_TIMEOUT =~ ^[0-9]+$ ]] && ((HEALTH_TIMEOUT >= 60 && HEALTH_TIMEOUT <= 1800)) || {
  echo "ERROR: VINE_INSTALL_HEALTH_TIMEOUT must be an integer from 60 through 1800." >&2
  exit 1
}
for command_name in awk bash docker mktemp python3 sha256sum systemctl; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "ERROR: missing required command: $command_name" >&2
    exit 1
  }
done

test_log="$(mktemp /tmp/vine-fresh-tests.XXXXXXXX)"
cleanup() { rm -f "$test_log"; }
trap cleanup EXIT

cd "$PROJECT_DIR"
[[ -f compose.vpn.yml ]] || { echo "ERROR: compose.vpn.yml missing in $PROJECT_DIR" >&2; exit 1; }
[[ -x vpn/prepare-profile.sh ]] || { echo "ERROR: vpn/prepare-profile.sh is not executable" >&2; exit 1; }
[[ -f host/vpn_profile_manager.py ]] || { echo "ERROR: VPN manager is missing" >&2; exit 1; }
docker compose version >/dev/null
if ((START_SERVICES)) && [[ ! -c /dev/net/tun ]]; then
  echo "ERROR: /dev/net/tun is unavailable. Enable TUN/TAP with the VPS provider, then rerun this finalizer." >&2
  exit 1
fi
if ((START_SERVICES)); then
  [[ -r /proc/sys/net/ipv6/conf/all/disable_ipv6 ]] || {
    echo "ERROR: the host kernel does not expose IPv6 controls required by the dual-stack Docker network." >&2
    exit 1
  }
  read -r host_ipv6_disabled </proc/sys/net/ipv6/conf/all/disable_ipv6
  [[ $host_ipv6_disabled == 0 ]] || {
    echo "ERROR: host IPv6 is globally disabled. Enable IPv6 before starting this dual-stack release." >&2
    exit 1
  }
fi
mem_total_kib="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
swap_total_kib="$(awk '/^SwapTotal:/ {print $2}' /proc/meminfo)"
[[ $mem_total_kib =~ ^[0-9]+$ && $swap_total_kib =~ ^[0-9]+$ ]] || {
  echo "ERROR: could not read host memory totals." >&2
  exit 1
}
if ((mem_total_kib + swap_total_kib < 1572864)); then
  echo "ERROR: RAM plus swap must total at least 1.5 GiB before the bounded build/tests (RAM=${mem_total_kib} KiB, swap=${swap_total_kib} KiB)." >&2
  exit 1
fi

install -d -m 700 vpn vpn/profile-backups vpn-control/processing
install -d -m 755 vpn-control/status
install -d -m 700 -o 1000 -g 1000 vpn-control/inbox data

if [[ ! -f config.json ]]; then
  install -m 600 -o 1000 -g 1000 config.portable.example.json config.json
else
  chown 1000:1000 config.json
  chmod 600 config.json
fi
chown -R 1000:1000 data vpn-control/inbox
chmod 700 data vpn-control/inbox

# Materialize only root-owned runtime placeholders and an OpenVPN selector for
# an exact predecessor. This never creates or prints key material.
python3 host/vpn_profile_manager.py --project-dir "$PROJECT_DIR" --initialize-runtime >/dev/null
active_protocol="$(awk -F= '$1 == "VPN_TYPE" { print $2 }' vpn/active.env)"
case "$active_protocol" in
  openvpn) active_source="vpn/client.ovpn" ;;
  wireguard) active_source="vpn/wireguard.conf" ;;
  *) echo "ERROR: active VPN protocol state is invalid." >&2; exit 1 ;;
esac

backup_dir=""
if [[ -n "$PROFILE_SOURCE" ]]; then
  [[ -s "$PROFILE_SOURCE" ]] || {
    echo "ERROR: initial profile is missing or empty: $PROFILE_SOURCE" >&2
    exit 1
  }
  case "${PROFILE_SOURCE,,}" in
    *.ovpn|*.conf) ;;
    *) echo "ERROR: --profile must end in .ovpn or .conf." >&2; exit 1 ;;
  esac
  python3 host/vpn_profile_manager.py --validate-profile "$PROFILE_SOURCE" >/dev/null
  if [[ -s "$active_source" ]]; then
    backup_dir="/opt/vine-backups/profile-before-finalize-$(date -u +%Y%m%dT%H%M%SZ)"
    install -d -m 700 "$backup_dir"
    for runtime_name in client.ovpn client.gluetun.ovpn wireguard.conf wg0.conf active.env; do
      cp -a "vpn/$runtime_name" "$backup_dir/$runtime_name"
    done
  fi
  python3 host/vpn_profile_manager.py \
    --project-dir "$PROJECT_DIR" \
    --install-profile "$PROFILE_SOURCE" >/dev/null
  active_protocol="$(awk -F= '$1 == "VPN_TYPE" { print $2 }' vpn/active.env)"
  [[ $active_protocol == openvpn ]] && active_source="vpn/client.ovpn" || active_source="vpn/wireguard.conf"
fi

[[ -s "$active_source" ]] || {
  echo "ERROR: no initial VPN profile is installed. Use --profile with a privately transferred .ovpn or .conf file." >&2
  exit 1
}
python3 host/vpn_profile_manager.py --validate-profile "$active_source" --protocol "$active_protocol" >/dev/null
chown root:root vpn/client.ovpn vpn/client.gluetun.ovpn vpn/wireguard.conf vpn/wg0.conf vpn/active.env
chmod 600 vpn/client.ovpn vpn/client.gluetun.ovpn vpn/wireguard.conf vpn/wg0.conf vpn/active.env

docker compose -f compose.vpn.yml config --quiet
mapfile -t compose_services < <(docker compose -f compose.vpn.yml config --services)
[[ ${#compose_services[@]} -eq 4 ]] || {
  echo "ERROR: expected exactly four Compose services." >&2
  exit 1
}
for required in vpn vh-proxy sv-proxy app; do
  found=0
  for service in "${compose_services[@]}"; do [[ $service == "$required" ]] && found=1; done
  ((found)) || { echo "ERROR: Compose is missing service: $required" >&2; exit 1; }
done

python3 - host/vpn_profile_manager.py <<'PY_COMPILE_MANAGER'
import pathlib, sys
source = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
compile(source, sys.argv[1], 'exec')
PY_COMPILE_MANAGER
bash -n install-new-ubuntu.sh host/finalize-install.sh vpn/prepare-profile.sh
PYTHONDONTWRITEBYTECODE=1 python3 -B scripts/package_companion.py --check

echo "Building fresh local application images..."
docker compose -f compose.vpn.yml build app vh-proxy
docker compose -f compose.vpn.yml pull vpn

echo "Running all offline source tests in resource-bounded mode..."
if ! docker run --rm --network none --memory 384m --memory-swap 896m --pids-limit 160 --cpus 1 \
  --user 0:0 --entrypoint sh \
  -v "$PROJECT_DIR:/candidate:ro" vine-drop-hub:local -ceu '
    node --check /candidate/server.js
    node --check /candidate/sv-connect-proxy.js
    for file in /candidate/lib/*.js /candidate/companion/*.js /candidate/companion/*.mjs /candidate/companion/src/*.mjs; do node --check "$file"; done
    node -e "JSON.parse(require(\"fs\").readFileSync(\"/candidate/companion/manifest.json\", \"utf8\"))"
    cd /candidate
    node --test --test-concurrency=1 test/*.test.js
  ' >"$test_log" 2>&1; then
  cat "$test_log" >&2
  echo "ERROR: offline Node validation failed." >&2
  exit 1
fi
node_pass="$(awk '/^# pass / { value=$3 } END { print value+0 }' "$test_log")"
node_fail="$(awk '/^# fail / { value=$3 } END { print value+0 }' "$test_log")"
[[ $node_pass == 250 && $node_fail == 0 ]] || {
  cat "$test_log" >&2
  echo "ERROR: unexpected Node test totals: pass=$node_pass fail=$node_fail" >&2
  exit 1
}
PYTHONNOUSERSITE=1 PYTHONPATH="$PROJECT_DIR" PYTHONDONTWRITEBYTECODE=1 \
  python3 -B test/test_vpn_profile_manager.py -v

docker run --rm --network none --memory 128m --memory-swap 256m --pids-limit 64 --cpus 0.5 \
  --entrypoint node \
  -v "$PROJECT_DIR/vh-direct-proxy.js:/proxy/vh-direct-proxy.js:ro" \
  vine-vh-direct-proxy:local --check /proxy/vh-direct-proxy.js

echo "Offline validation passed: 250/250 Node tests and 17/17 Python tests."
systemctl enable --now vine-vpn-profile-manager.service

if ((START_SERVICES == 0)); then
  echo "Installation finalized without starting Compose (--no-start)."
  exit 0
fi

wait_for_stack() {
  local deadline=$((SECONDS + HEALTH_TIMEOUT)) service cid state all_ready
  local -a services=(vpn vh-proxy sv-proxy app)
  while ((SECONDS < deadline)); do
    all_ready=1
    for service in "${services[@]}"; do
      cid="$(docker compose -f compose.vpn.yml ps -q "$service" 2>/dev/null || true)"
      [[ -n $cid ]] || { all_ready=0; continue; }
      state="$(docker inspect -f '{{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$cid" 2>/dev/null || true)"
      case "$state" in
        'running healthy'|'running none') ;;
        exited*|dead*|restarting*|'running unhealthy')
          echo "ERROR: $service entered $state during startup." >&2
          docker compose -f compose.vpn.yml ps >&2 || true
          return 1
          ;;
        *) all_ready=0 ;;
      esac
    done
    ((all_ready)) && return 0
    sleep 5
  done
  echo "ERROR: four-service health did not settle within ${HEALTH_TIMEOUT}s." >&2
  docker compose -f compose.vpn.yml ps >&2 || true
  return 1
}

echo "Starting VPN, VHelper proxy, VPN-bound SmartViner proxy, and application..."
if ! docker compose -f compose.vpn.yml up -d --no-build --pull never || \
   ! wait_for_stack || \
   ! python3 host/vpn_profile_manager.py --project-dir "$PROJECT_DIR" --health-timeout "$HEALTH_TIMEOUT" --verify-active >/dev/null; then
  if [[ -n "$backup_dir" && -f "$backup_dir/active.env" ]]; then
    echo "Start failed; restoring and revalidating the previous complete VPN protocol state..." >&2
    for runtime_name in client.ovpn client.gluetun.ovpn wireguard.conf wg0.conf active.env; do
      install -m 600 "$backup_dir/$runtime_name" "vpn/$runtime_name"
    done
    if docker compose -f compose.vpn.yml up -d --force-recreate --no-build --pull never && \
       wait_for_stack && \
       python3 host/vpn_profile_manager.py --project-dir "$PROJECT_DIR" --health-timeout "$HEALTH_TIMEOUT" --verify-active >/dev/null; then
      echo "Previous VPN protocol state was restored and is healthy." >&2
    else
      echo "URGENT: previous VPN state was restored on disk but did not pass startup validation." >&2
    fi
  else
    echo "Initial VPN startup failed; stopping the incomplete clean-install stack." >&2
    docker compose -f compose.vpn.yml down --remove-orphans >/dev/null 2>&1 || true
  fi
  exit 1
fi

docker compose -f compose.vpn.yml ps
cat <<EOF

Clean installation started successfully.
Application release: r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18
Dashboard remains bound to 127.0.0.1:3001 on the VPS.
From your computer, open an SSH tunnel:

  ssh -N -T -L 127.0.0.1:3001:127.0.0.1:3001 YOUR_USER@YOUR_NEW_SERVER

Then open http://127.0.0.1:3001 locally. Configure UV, Telegram/Discord,
SmartViner, and PC pairing only through that private dashboard. The clean
installation starts with empty cards/history, cleared memory, order rules,
pairing, and job ledger. Download the Windows companion from Settings only
after this tunnel is active.
EOF
