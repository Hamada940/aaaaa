# R25 UV authentication recovery and Live Feed capacity hotfix

Release: `r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18`  
Accepted predecessor: exact authenticated `r25-vh-4-7-4-dashboard-usability-hotfix-20260910-17` only

## What changes

- A silent UV identification/authentication timeout is transient. It records diagnostics, closes that socket generation, and automatically retries instead of permanently requiring a manual reconnect.
- Consecutive timeout recovery uses one non-overlapping exponential cooldown from the existing five-second base, adds bounded 20% jitter, and caps at five minutes.
- A valid non-empty UV plan or genuine supported live-alert frame resets the consecutive timeout state. Process-total timeout evidence remains available in diagnostics.
- **Reconnect UV** cancels a pending cooldown and attempts immediately.
- Explicit WebSocket `invalidToken` remains terminal and reconnect-blocking. A scheduled signed-search health success cannot clear or bypass it; an explicit user action is required.
- UV diagnostics expose consecutive/process-total timeout counts, last timeout, retry state and reason, next retry time, pending delay, policy bounds, reset evidence, and terminal block reason.
- Live Feed requests the newest **500** matching retained items initially and adds **Load 500 more** through the **2,000**-item retained ceiling.
- Changing search, source, Vine queue, UV Alert queue, alert origin, pinned, priority, zero-ETV, or hidden filters cancels stale work and restarts from the newest 500 matching records.
- A bounded ASIN-keyed WebSocket overlay wins over older HTTP snapshots, so new drops and enrichment remain visible synchronously while older pages load.

## What does not change

- UltraViner 26.11.62 identification fields, account identity, token, Amazon hash, device, screens, queues, passive event types, and signed-search request separation are unchanged.
- VHelper 4.7.4/build-3637 contracts, SmartViner, one-card source merging, first-alert behavior, health-alert deduplication, order safety, and companion behavior are unchanged.
- Explicit `invalidToken` is not treated as a transient timeout and receives no automatic reconnect.
- No history, `getLast100`, polling, automatic signed read, contribution reporting, identity mutation, entitlement behavior, or reconnect catch-up is added.
- VPN, notification, feed history, order ledgers, pairing/rules/watches, credentials, identities, sessions, and all other private runtime state remain outside the managed payload and are preserved.
- No authenticated UV, Amazon, VHelper, SmartViner, Telegram, Discord, or other private endpoint is called during release validation.

## In-place update

Run the checksum-verifying updater only against exact `-17`:

```bash
sudo -n bash ./update-existing-r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18.sh \
  --project-dir /home/ubuntu/vine \
  --validate-only

sudo -n bash ./update-existing-r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18.sh \
  --project-dir /home/ubuntu/vine
```

The updater authenticates every predecessor managed byte, validates the complete private-state-free target before downtime, creates a checksum-backed snapshot and standalone rollback, preserves every unlisted/private path, and activates with `--no-build --pull never`.

## After update

1. Hard-refresh the dashboard.
2. Confirm Live Feed initially reports at most 500 loaded records and offers **Load 500 more** when older retained matches exist.
3. Press **Load 500 more** and verify fresh incoming drops still appear immediately at their normal pinned/priority/time position.
4. Change a filter and confirm progressive loading resets to the newest matching page.
5. Open **Settings → UV Diagnostics** and confirm timeout and retry fields are visible.
6. If a silent UV timeout is observed, confirm diagnostics show one scheduled retry and later reset the consecutive count after a non-empty plan or live alert.
7. If UV explicitly reports `invalidToken`, correct the account condition and use **Reconnect UV** manually; do not expect signed-search health checks to reconnect it.

The dashboard remains loopback-only. Keep using the existing SSH tunnel and private deployment procedure.
