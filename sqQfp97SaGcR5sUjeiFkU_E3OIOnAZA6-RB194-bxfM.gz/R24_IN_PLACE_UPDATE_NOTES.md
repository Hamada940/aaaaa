# R24 cleared-item memory in-place update

> **Historical existing-server route only.** Do not use this updater on a clean
> VPS. Release `r24-cleared-item-memory-new-vps-20261104-1` must follow
> `MIGRATE_TO_NEW_UBUNTU.md` and its dedicated new-VPS pasteable installer.

**Target:** `r24-cleared-item-memory-20261104-2`

The updater accepts only the byte-exact working release already installed:

- `r24-smartviner-global-only-20261103-3`
- managed-manifest SHA-256 `09b5fdceb9f33c011329386bb72a0d53e255d14d4ab921016182956af91a9ad5`

Any different release, modified managed file, or mismatched manifest is rejected before backup, downtime, or mutation.

The superseded `20261104-1` wrapper could abort during its network-disabled candidate smoke because one local `fetch()` Promise was passed to a response-only reader; its POSIX `sh` cleanup also emitted a harmless `status: not found` warning. Both occurred before shutdown, backup, or live-tree mutation. Corrected release `20261104-2` makes the reader Promise-aware and uses a portable POSIX numeric test.

## One-paste update

Open `PASTEABLE_UPDATE_R24_CLEARED_ITEM_MEMORY_20261104_2.txt`, copy its complete contents, and paste it once into the existing VPS SSH terminal.

The updater auto-detects `/opt/vine-drop-hub` or `/home/ubuntu/vine`. It requires Ubuntu 22.04/24.04 amd64, Docker Compose, the currently running exact four-service stack, and at least 1.5 GiB total RAM plus swap.

Do not paste a SmartViner password, token, `.ovpn`, VPN credential, private key, Telegram credential, or other secret into the updater or chat.

## Transaction guarantees

1. Authenticates exact `r24-smartviner-global-only-20261103-3` release metadata and every managed file.
2. Extracts and checksum-verifies a deterministic, private-state-free payload.
3. Validates the four-service Compose topology without pulling or building images.
4. Runs all 136 Node tests and five Python tests serially in network-disabled, resource-bounded containers.
5. Starts a network-disabled candidate using a private scratch copy with feeds and outbound notifications disabled.
6. Proves clear, delayed cross-source confirmation, restart persistence, expiry, zero-duration disablement, ledger bounds, typed reset, and Settings validation offline.
7. Rechecks SmartViner global-only enforcement, endpoint/event scope, credential isolation, fail-closed egress, SSH-only dashboard binding, and no history/catch-up path.
8. Stops Compose only after all offline validation passes.
9. Creates and checksum-verifies a complete pre-mutation snapshot.
10. Installs only declared managed source while proving every private/unlisted path is byte-identical.
11. Restarts Compose with the existing local app/VH/VPN images, then waits for `vpn`, `vh-proxy`, `sv-proxy`, and `app` health.

The low-resource update does not pull, build, commit, load, import, or otherwise mutate an image layer. `sv-proxy` reuses the existing local Node application image and runs only the read-only destination-locking script.

`config.json`, `.env`, existing `data/` content, identities/history, notification credentials, VPN profiles/keys/credentials, VPN-control state, profile backups, and every unlisted path are preserved. The payload contains none of them. The running application creates private `data/cleared_items.json` only when the updated source starts; normal rollback does not replace or reactivate stale data snapshots.

## What this patch changes

- Clear View, individual clears, and selected-item clears durably remember visible ASINs before removing their cards.
- The hidden ledger is separate from visible items/activity and short notification dedupe. It stores only canonical ASIN, clear/confirmation times, and UV/VH/SV source names—never product titles, images, prices, credentials, or notification payloads.
- While active, a delayed UV, VH, or global-only SV discovery is rejected before card lookup, activity, dashboard broadcast/sound, Telegram, and Discord.
- Delayed confirmations update only the tombstone source set and remain silent.
- Restart loading makes the tombstone authoritative even if a process stop interrupted asynchronous item/activity persistence.
- **Settings → Cleared-Item Memory** edits retention from 0 through 8760 hours; default is 24 hours.
- `0` disables and erases cleared-item memory, restoring legacy clear behavior.
- **Reset cleared-item memory** is separate, exposes no retained ASIN list, requires typing `RESET CLEARED ITEM MEMORY`, and never restores removed cards.
- The ledger retains at most the newest 50,000 ASINs and prunes exact expirations.
- A genuinely new or expired ASIN still starts normal browser/Telegram/Discord delivery immediately; no debounce, batch, timer, frame scheduler, or alert delay was added.

Everything else remains unchanged: one-card source merging, first-genuine-source notification semantics, Telegram `sendPhoto`, UV/VH identities and behavior, VHelper `getLast100` prohibition, SmartViner global-only enforcement, application-only VPN routing, SSH-tunnel-only dashboard access, existing authentication, and all excluded endpoints/scopes.

## Optional validate-only run

With the standalone updater file:

```bash
sudo bash update-existing-ubuntu-22.04-r24-cleared-item-memory-20261104-2.sh --validate-only
```

This performs all pre-downtime checks and exits without backup, shutdown, or mutation. The pasteable wrapper performs the full update directly.

## After successful update

Hard-refresh the SSH-tunneled dashboard. Open **Settings → Cleared-Item Memory** and confirm the default is **24 hours**. Existing cards/history, source sessions, identities, notification credentials, VPN state, and SmartViner global-only status are preserved.

No assistant-side live service check was performed. Live verification must be user-run from the intended VPS egress, using only non-secret output when seeking help.

## Rollback

A successful update prints a snapshot-specific command and installs the stable command:

```bash
sudo /opt/vine-backups/rollback-latest.sh
```

Normal automatic/manual rollback restores only exact predecessor-managed source and preserved image tags. It retains the **current** config, data/history, cleared-item ledger, `data/sv_auth.json`, UV/VH identities, Telegram/Discord settings, VPN/control state, and unlisted files instead of activating stale private state from the full snapshot.

The complete snapshot remains available for manual disaster recovery, but it is never activated as a normal rollback over newer private state.

## Offline validation target

- Node tests: **136/136**
- Python tests: **5/5**
- Exact installed predecessor guard
- Deterministic payload/updater/wrapper regeneration
- Managed-source rollback while newer private/unlisted state, including `data/cleared_items.json`, remains active
- Offline clear/restart/expiry/source-confirmation/zero-duration/bounds/reset behavior
- Existing global-only SmartViner and no-live-endpoint policy
- Live SmartViner/UV/VH/Telegram/Discord/Amazon/VPS endpoint testing: **not performed**

Artifact checksums are in `R24_CLEARED_ITEM_MEMORY_20261104_2_SHA256SUMS.txt`.
