# R25 PC Order Companion and AFA/AI watch safety

## Scope and trust boundary

R25 keeps detection, source merging, rules, and the bounded public job ledger on the Ubuntu VPS. It keeps Amazon authentication and ordering on the user's Windows Chrome/Edge profile.

- The VPS never receives Amazon cookies, CSRF tokens, offer listing IDs, checkout state, or the raw Amazon customer ID.
- A newly issued pairing starts unbound. Its first valid challenge response is authenticated by the one-time pairing secret, carries only `SHA-256(customerId)` from the real Amazon.ca session in that browser, and durably establishes the pairing's one-way account binding before the channel is authenticated.
- Every later connection must present that same browser-derived hash. A genuine Amazon account change closes the channel and blocks jobs.
- Synthetic Amazon-like IDs used by the Hub, Ultraviner, or VHelper are outside this trust boundary and are never account-binding inputs.
- The Hub and PC communicate only through `ws://127.0.0.1:<port>` over the user's SSH local forward.
- Order jobs/results and the independent read-only Amazon variant lookup requests/results are HMAC-signed, timestamp-bound, ASIN-bound, nonce-protected, short-lived, and one-time.
- Terminal results remain in local extension storage until the VPS returns a signed acknowledgement. A lost acknowledgement can cause only an idempotent same-state ledger replay, never another checkout attempt.
- The companion does not call, inspect, modify, disable, or bypass Ultraviner, VHelper, or SmartViner. Those extensions may remain enabled.

The Hub dashboard and its APIs remain unauthenticated and therefore **must remain bound to `127.0.0.1:3001` and accessed only through SSH forwarding**.

## Actual Vine order path

The local companion performs this flow with the browser's own authenticated Amazon.ca session:

1. Validate the signed job and accept it only once.
2. Reconstruct the full Vine recommendation ID transiently on the PC.
3. For a parent item, either read Amazon's variation list in response order and try the first candidate still accepted as orderable, or—when an exact watch child was signed—require that one child to be present and never substitute another.
4. **See Details** for the exact child/item ASIN and validate the Vine promotion/purchase-policy response.
5. **Request Product** and validate the returned checkout offer.
6. POST the exact allowlisted fields to Amazon's Vine Chewbacca checkout.
7. Advance Amazon's address/payment confirmation pages when they appear.
8. Parse the final payable total and apply the signed policy.
9. Request a fresh, one-use click permit and click **Place your order** once.
10. Report `placed` only after a thank-you URL contains a verifiable purchase ID. An uncertain click becomes `ambiguous` and is never retried automatically.

This is Vine's Place Your Order flow, not a separate ordinary retail-cart checkout.

## Rule semantics

Automatic ordering is disabled by default. Rules are evaluated top-to-bottom and the first enabled matching rule wins.

Each rule supports:

- action: unattended when safe, or always require PC approval;
- words/phrases: any or all;
- text mode: legacy substring, contiguous exact phrase, whole-word/bounded phrase, or exact full title/brand;
- excluded words/phrases using the same text mode;
- item-price source: retail, ETV, or either;
- item-price comparison: at least, at most, or inclusive range;
- logic: word-only, price-only, word AND price, or word OR price;
- optional queue filters: RFY, AFA, AI;
- optional source filters: UV, VH, SV;
- an optional per-rule final-total cap that can only tighten the global cap.

Incomplete enabled rules fail closed and never match. A prior automatic attempt for the same ASIN always prevents another one.

A fresh isolated UV/VH live event that is missing usable retail price/ETV may hold one memory-only completion permit for 60 seconds. UV `alertDetail`/`pageData` or VH `newPrice`/`newETV` can add only missing money fields; every other rule/job field remains pinned to the original event. The permit exists only when rules, the paired account-matched agent, pause/circuit state, and active-job state were ready at event time. It is destroyed by expiry, restart, disconnect, rule/safety/watch changes, any dispatch boundary, or its first resulting attempt. It is never persisted, queued, or replayed.

UV and VH `unavailable` flags are informational for automatic rules and one-shot watches. They do not veto the one attempt because either feed can be wrong; Amazon availability and variant acceptance are checked by the paired browser. Manual hide, history/backfill, source/queue/rule mismatch, and all companion/checkout safety gates still fail closed. SmartViner does not receive this availability exception.

The dashboard keeps unsaved rule edits as a local draft. Periodic companion-status polling and WebSocket connection events may update status and job history, but they do not replace or redraw a dirty rule editor. A visible **UNSAVED DRAFT** badge and browser unload warning remain until **Save Order Rules & Safety Limits** succeeds; a failed save keeps the draft visible. Rules can be duplicated before editing. **Automatic Order Rules** and **One-shot AFA/AI Watches** are collapsed-by-default `<details>` panels, matching **Recent PC order jobs**; collapsing them does not reset controls, watches, or an unsaved draft.

**Preview Draft** is a simulator, not an order action. It evaluates enabled individual rules against up to 200 recent live Hub items even if the global broad-rule switch is off. It neither creates a signed job nor contacts Amazon or any feed. Each match explains the rule, words, item-price values, queue, sources, effective cap, rolling-limit escalation, and resulting automatic/approval action.

## Exact-ASIN one-shot AFA/AI watches

A VHelper RFY Server Explorer result or UV Explorer RFY/AFA result is historical/read-only and cannot be sent directly to the companion. Its **Watch for AFA/AI** action creates only an exact-ASIN waiting record:

- target queues are fixed to AFA and AI; UV AI Explorer cards cannot arm a watch;
- expiry defaults to 30 days and is editable from 1 through 30 days;
- an optional per-watch final-total cap can only tighten the global cap;
- bounded child variants already embedded in the current source response appear immediately without another request;
- a separately labeled **Load variants from VHelper** button may make one signed official 4.7.4 `item_explorer_variants` request per deliberate click;
- UV RFY/AFA dialogs also expose **Load variants from Amazon via PC**. This sends an independent signed `variant_lookup_request` only to authenticated/account-bound companion 25.0.4, which force-refreshes the local Amazon identity and performs one GET of the current Vine recommendation variations;
- the Amazon read-only handler cannot call See Details, Request Product/`voiceOrders`, checkout, or Place Order, and returns only unique non-parent child ASINs plus bounded non-sensitive dimensions;
- opening or arming never runs either source; neither source retries or falls back to the other, and a failed explicit refresh does not erase choices previously loaded in that open dialog;
- loaded choices are browser-memory-only for the current dialog generation: they are not persisted, merged into Explorer/live history, notified, or used by manual **Order on PC**;
- the user may retain first-available behavior or sign one exact selected child ASIN from embedded/Amazon/VHelper choices into the future job;
- an exact child is revalidated against Amazon's current parent variation response and Request Product acceptance when a later qualifying event triggers; if absent or no longer orderable, no other variant is substituted, no checkout is opened, and the one-shot watch finishes Missed;
- existing watches without variant fields remain first-available and configuration export/import retains exact child selections without credentials;
- RFY, backfill/history, default queue guesses, and events before arming do not consume it;
- UV/VH unavailable markers are advisory and do not suppress an otherwise qualifying event; Amazon on the paired PC remains authoritative;
- the first later fresh trusted event with explicit/derived AFA or AI confidence is the one dispatch opportunity;
- the order item is allowlisted solely from that qualifying event; merged/historical RFY enrollment or recommendation metadata is never reused;
- a successful signed socket write marks **Triggered**;
- any first-attempt failure, including an offline PC, marks **Missed** and is never queued or retried;
- untouched watches may be **Armed**, **Expired**, or **Cancelled**; and
- an armed watch reserves its ASIN from broad-rule automatic dispatch.

Variant lookup is not watch arming and is not an order job. The VPS correlates at most one pending Amazon lookup, rejects unknown/replayed/mismatched/late results, and clears pending state on timeout, disconnect, or companion replacement. A watch is an explicit automation instruction and remains armed when the broad-rule enable switch is off. The emergency pause and circuit breaker still apply. Later same-ASIN source confirmation remains a silent update to one card; watch evaluation runs before that silent branch without creating a second sound or notification.

### Two separate price decisions

1. **Item matching** uses the retail price and/or ETV present in the live Hub item.
2. **Checkout safety** uses the final Amazon payable total rendered on the local checkout page.

The item-price rule never raises or bypasses the final-total safety gate.

## Final-total policy

The global maximum unattended charge is editable in Settings. The proposed initial value is **C$30.00**.

- C$0.00 and exact CAD totals at or below the effective limit may proceed unattended for an `auto` rule.
- A rule with action `approval` always opens a local approval window.
- An exact total above the effective limit opens a local approval window.
- Approval is bound to that exact amount and currency. If the amount changes, the old approval is invalid.
- Missing, conflicting, negative, malformed, or non-CAD totals stop.
- The companion never blindly retries Place your order.

### Rolling 24-hour automatic limits

The automatic placement-count and cumulative-known-final-total limits are both disabled initially. When configured, they apply to rule/watch jobs only, not explicit dashboard jobs. A job enters the placement count at the reported Place Order click boundary (or a terminal placed/ambiguous result). Reaching the count or exhausting the cumulative charge allowance changes the next automatic job to exact-total PC approval. A positive remaining charge allowance narrows that job's unattended cap. Rolling controls never increase a global, per-rule, or per-watch cap.

## Emergency pause and circuit breaker

**Pause Automatic Ordering** durably stops rule/watch dispatch without deleting configuration. A watched event seen during the pause is not queued or replayed, and the watch remains armed for a different later fresh event. Explicit dashboard ordering remains available while only this manual pause is active. Resuming requires the exact phrase displayed in Settings.

The separate durable circuit breaker blocks every new order job, including explicit dashboard jobs, until acknowledged. Armed watches are preserved and blocked events are not queued or replayed. It trips on terminal ambiguity; unsafe account, final-total, currency, origin, or click-boundary uncertainty; a socket-dispatched job that receives no signed PC acknowledgement before its short deadline; companion loss after Place Order submission was reported but before a terminal result reached the Hub; or failure to save the durable job/watch safety record. The Hub records an intent before socket dispatch, acknowledges a signed PC result only after the ledger transition is saved, and reconstructs unacknowledged unsafe boundaries after restart. Check the job ledger and Amazon Orders first, then use the exact acknowledgement phrase. Acknowledgement does not clear an independent manual pause.

The readiness banner combines dashboard/tunnel reachability, signed companion authentication, browser-derived account match, pause/circuit state, final-total cap, active jobs, rolling usage, and armed watches.

## Configuration export/import

The dashboard export contains normalized rules and armed watches only. It excludes pairing secrets, browser account hashes, job/safety ledgers, cookies, feed/notification credentials, and VPN material. Import requires an exact confirmation, leaves all private identity/credential/job/safety state untouched, forces broad rules disabled for review, and keeps valid unexpired imported watches armed while any pre-existing pause or circuit continues to block dispatch.

## Pairing and installation

The downloadable extension package is served from:

`http://127.0.0.1:3001/downloads/vine-drop-hub-pc-companion.zip`

Detailed Windows steps are included inside the ZIP as `README-WINDOWS.md`. In summary:

1. Extract to a stable Windows folder.
2. establish the loopback SSH forward to VPS `127.0.0.1:3001`;
3. load the folder with Chrome/Edge **Load unpacked**;
4. sign in to Amazon.ca Vine in that browser profile;
5. create a pairing secret (shown once) in Hub Settings;
6. paste it only into the companion Options page and enable the companion;
7. confirm Hub status reads **Ready** and **account matched**;
8. configure the final-total cap, optional disabled-by-default rolling limits, and broad rules; arm any exact-ASIN watches deliberately; then enable broad automatic rules only when ready.

Pairing creation and revocation require exact confirmation phrases in the dashboard. Pairing replacement immediately disconnects and invalidates the prior PC secret.

### One-time migration from the original R25 pairing format

Original R25 pairing records could have been initialized from a synthetic Hub identity that was unrelated to the real Amazon.ca browser customer ID. Version 25.0.2 and later quarantine every such legacy pairing record without comparing its saved value with the PC. The status shows **Re-pair required** and ordering remains blocked. Create one new pairing secret, paste it into companion 25.0.4, and save. That explicit replacement creates the new schema in `pending` state; the first signed browser connection then learns the real one-way hash. This migration never disables or weakens account checking.

## Dashboard order action

Every live Hub card includes **Order on PC**, and its **Live Feed product photo** invokes that exact same action. The photo is not a shortcut around safety: it only opens the dashboard confirmation and cannot dispatch or place an order by itself. Primary pointer interaction is captured on the stable document rather than on the replaceable card node: if UV/VH detail or source enrichment replaces the card between pointer-down and pointer-up, the original ASIN still opens exactly one dashboard confirmation immediately. There is no settle delay, debounce, or required repeat press. A drag, cancelled pointer, non-primary pointer, or right-click does not activate it; the browser's following synthetic click is consumed so one physical press cannot open twice. Keyboard activation remains supported. UV Explorer and VH server/history photos remain Open Vine links and never receive direct manual-order behavior.

The button never silently ignores a not-ready state. It remains interactive but visibly unavailable and explains the exact circuit, companion/account, active-job, or in-flight-request reason. The dashboard confirmation:

- sends nothing until **Send to PC** is explicitly pressed;
- single-flights the submit before any network await;
- sends only the ASIN to the local Hub API;
- resolves the current live item server-side;
- creates one signed expiring job;
- opens the checkout tab on the PC; and
- still enforces the final CAD total gate.

Server-search/history records are read-only and do not receive an order button. A VH RFY Server record may receive only the one-shot **Watch for AFA/AI** control described above; arming it does not dispatch that record.

## Warm-path timing target

The implementation introduces no debounce, batch window, animation-frame wait, or deliberate order-path sleep. A matching job is written to the authenticated PC socket before dashboard card delivery, notifications, and persistence. The companion records server detection/dispatch, PC receipt, details completion, checkout load, Place Order click, and confirmation timestamps in the sanitized ledger.

The engineering target is **under three seconds from dashboard detection to Place your order submission on a warm local path**. The PC still revalidates the current Amazon account for every accepted job, and real Amazon/VPN/SSH/browser latency can exceed the target. No live Amazon claim is made by offline validation; review the recorded timing fields during the user-run local test.

## Data retained on the VPS

The new private files are:

- `data/order_agent.json` — pairing secret, schema/state metadata, browser-derived `SHA-256(customerId)` binding, and label; mode 0600; no raw customer ID or synthetic Hub/UV/VH identity is written;
- `data/order_rules.json` — normalized rules and final-total cap; mode 0600;
- `data/order_jobs.json` — bounded sanitized ledger; mode 0600;
- `data/order_watches.json` — exact-ASIN watch lifecycle and optional stricter caps; mode 0600; and
- `data/order_safety.json` — emergency pause, unresolved circuit event, and last acknowledgement; mode 0600.

They are private runtime state. In-place update and normal rollback tooling must preserve them rather than replacing the whole data directory. Rolling usage is derived from the sanitized job ledger rather than a separate counter. Variant lookup seeds, pending correlations, replay IDs, and loaded choices are intentionally memory-only and create no additional data file or job-ledger entry.

## Offline validation

From the source tree, without starting the service:

```bash
npm ci --ignore-scripts --no-audit --no-fund
npm run validate:offline
```

This performs JavaScript syntax checks, manifest/dashboard parsing checks, all Node tests, and the Python VPN-manager tests. It does not contact Amazon, UV, VHelper, SmartViner, Telegram, Discord, a token/feed, or a VPS endpoint.

A real browser/Amazon flow cannot be validated offline. After installation, the user must perform that test locally with their own authenticated browser while monitoring the exact total and order history.

## Safe operational response

- `failed`: correct the stated local/session/metadata issue and use a new explicit job if appropriate.
- `rejected`: the person at the PC declined the exact order.
- `ambiguous`: the circuit breaker activates; check Amazon Orders manually before acknowledging it or doing anything else.
- `expired`: the PC did not acknowledge the short-lived signed job in time; it was not queued for later.
- watch `missed`: the first qualifying event was consumed but could not be dispatched (including offline); it will not retry.
- safety pause: review the readiness reason and relevant job/Amazon Orders before entering the exact acknowledgement phrase.
- account mismatch: sign back into the Amazon.ca account first learned by this pairing. For an intentional account replacement, explicitly create a new pairing secret; never remove or bypass the binding check.
- re-pair required: the old R25 synthetic-era value is quarantined. Replace the pairing once so 25.0.4 can learn the real browser-derived hash.
