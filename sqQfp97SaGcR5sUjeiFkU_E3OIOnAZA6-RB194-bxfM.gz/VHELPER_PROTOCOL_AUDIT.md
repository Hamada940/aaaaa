# Official VHelper 4.5.2 Static Protocol Audit

**Audit date:** 2026-09-11  
**Target compared:** `vine-drop-hub/server.js`  
**Method:** static package inspection only; the extension was not executed.

> **Implementation follow-up (2026-09-11):** The comparisons in this audit describe the pre-Package-B `server.js` that was audited. Package B has since been implemented in the workspace: the working legacy synthetic identity is preserved without automatic migration; future generated identities use per-install P-256 keys and bounded best-effort FID registration; audited readiness/recovery/watchdog/error/enrichment behavior and diagnostics are present; and every `getLast100` emission remains prohibited. Offline tests pass. See `PACKAGE_B_IMPLEMENTATION.md`. No live endpoint validation was performed.
>
> **R20 scope note (2026-10-05):** A separate static audit of official Firefox VHelper 4.7.1 authorized one narrow server-database search outside the live transport: signed API-version-5 `action: "item_explorer"` with queue fixed to RFY `potluck`, using the current saved identity only after an explicit Search or pagination action. This does not relax the `getLast100` prohibition or backfill the live feed. Separate variants actions/APIs, broadcast logs, signed `get_info`, identity recovery/mutation, entitlement bypass, automatic polling, and assistant-side live endpoint testing remain excluded. See `PACKAGE_B_IMPLEMENTATION.md`.
>
> **R21 scope note (2026-10-06):** The signed Firefox 4.7.1 settings code was statically rechecked for `trial_active` and `trial_ends_at`. R21 authorizes API-v5 `action: "get_user_stats"` only after the user presses **Check Trial Status**, using the current saved UUID/CID/FID. The implementation accepts only trial state, exact expiry, calculated days remaining, and a safely bounded reported tier. It ignores `resolved_uuid` and discards linked devices, contribution statistics, payment fields, and every unrelated property. It shares Item Explorer's in-flight/replay/cooldown controls, does not persist the reply, and adds no polling, retry, identity mutation/recovery, entitlement bypass, or assistant-side live request.
>
> **R25 exact-watch-variant predecessor scope note (2026-09-10):** Release `r25-watch-variant-selection-20260910-5` allowed exact watch variants only from passive child-ASIN data already embedded in the ordinary `item_explorer` response. Its sanitizer retained at most 100 valid offered child ASINs per returned record plus eight bounded display dimensions and discarded recommendation, enrollment, customer, offer, and signing fields. At that release boundary, `item_explorer_variants` remained prohibited.
>
> **R25 click-variants successor scope note (2026-09-10):** Release `r25-vh-click-variants-20260910-7` narrowly supersedes only that variants-action prohibition. Static audit of official Firefox VHelper 4.7.1 confirms that its `.load-variants` click signs ordered fields `api_version`, `version`, `action: "item_explorer_variants"`, `country`, `uuid`, `cid`, and `asin`, then consumes `data.variants` fields `asin`, `title`, and `etv`. Vine Drop Hub may perform exactly one such request per deliberate **Load variants from VHelper** click inside **Watch for AFA/AI**. No dialog/card/tab/startup/arming/timer trigger, automatic retry, alternate source, identity change, persistence, live-store merge, manual-order use, Amazon detail request, broadcast log, or other variants action is authorized.
>
> **R25 VHelper 4.7.4 authenticated refresh (2026-09-10):** Release `r25-vh-4-7-4-dashboard-usability-hotfix-20260910-17` authenticates a fresh official Chrome Web Store CRX3 for extension ID `jlglbhebbkfjcofdplbkanckkipkgfle`, version `4.7.4`, internal build `3637`. Static extraction and 284 JS/MJS syntax parses passed. Live identity, API-v5 Item Explorer, `item_explorer_variants` (`version`, not `app_version`), and `get_user_stats` field order remain compatible, so all four audited contract pins advance to 4.7.4 without changing saved identity or signed field order. Diagnostics expose the live pin/build and each signed-read pin separately. This refresh authorizes no history, polling, automatic signed read, contribution, identity mutation, recovery, entitlement bypass, or additional endpoint.

## 1. Provenance and analysis boundary

The audited package is the public Chrome Web Store CRX3 for extension ID `jlglbhebbkfjcofdplbkanckkipkgfle`.

| Artifact | Result |
|---|---|
| Chrome Web Store version | `4.5.2` |
| Internal build | `3483` |
| CRX size | `3,919,629` bytes |
| Unpacked files | `648` |
| CRX SHA-256 | `33a788a200e31a130baa3afb77472049c3376ca5f45e2e47af8906e7ebf17d1b` |
| ZIP payload SHA-256 | `97c8eb0280f724f0cc28ade415875a62f873bbd1e2efa76b3e07ca8fa4f` |
| Manifest SHA-256 | `c5c45ba350d622158ed969df3d4fe0db345ce4cf77b09f6f6244feaea4c37bdd` |
| File-hash manifest | `vhelper-extension/files.sha256` (648 entries) |

The CRX3 signed header identifies the expected extension ID. Offline OpenSSL verification succeeded for all package proofs present: two SHA-256/RSA proofs and one SHA-256/ECDSA proof. Details are in `vhelper-extension/crx3-verification.json`; the verifier is `vhelper-extension/verify_crx3.py`.

No VHelper, Amazon, Ultraviner, Telegram, Discord, or application endpoint was contacted during this audit. The package was not loaded into a browser, and none of its JavaScript was run.

## 2. Executive conclusion

Vine Drop Hub's current VHelper receiver has the correct broad transport family—Socket.IO v4 over WebSocket through the direct-egress proxy—and its first-live-source merge/notification policy is already aligned with the requested dual-feed behavior. Its VHelper **identity and liveness model, however, are not faithful to the official client**.

The consequential protocol differences are:

1. The app creates a synthetic random customer identity. Official VHelper derives `cid` from the real Amazon Vine customer ID: `SHA-256(countryCode + customerId)`.
2. The app embeds one fixed ECDSA private key. Official VHelper generates a fresh P-256 key pair for each installation and persists it locally.
3. The app does not provision a device fingerprint and sends an empty `fid`. Official VHelper normally uploads a signed fingerprint and sends the returned `fingerprint_id`.
4. The app identifies itself as VHelper `4.7.0`, while the audited official package is `4.5.2`.
5. The app treats a Socket.IO transport connection as healthy without confirming application/authentication state and omits official stale-connection, broadcast-sync, invalid-UUID, connection-limit, and enrichment-event handling.
6. “Rotate VH Identity” is not distinguished as creating a new isolated synthetic VH identity rather than linking the user's official Amazon-derived VH identity.

### Functional compatibility versus official parity

A synthetic CID can still work. The official `get_uuid` request sends only a CID hash plus a public key/signature generated by the client itself; it sends no Amazon token, cookie, or server-verifiable proof of the underlying customer ID. The server can therefore accept a previously unknown synthetic CID as a new isolated VH identity, and the user's existing runtime experience confirms that this path currently works for the passive feed. A blank FID may likewise be tolerated as a legacy/compatibility path.

That means “different from the official extension” does **not** mean “currently rejected.” The practical distinctions are account continuity and future robustness: a synthetic identity is not linked to the user's official VH UUID/tier/devices, and permissive handling of blank FID or nonstandard identity may change. Implementation should preserve a working generated-identity mode, label it accurately, and add official linked-identity provisioning as an option rather than automatically replacing a working UUID.

The identity hardening and reliability gaps should be addressed without removing current generated-ID functionality. No protocol-based application changes were made as part of this audit.

## 3. Official identity and authentication lifecycle

VHelper does not use a conventional password or bearer token for its notification feed. It uses a pseudonymous Amazon-account identity plus a server UUID and a registered device fingerprint.

### 3.1 Country and Amazon identity

The extension determines a lowercase VHelper country code from the Amazon domain. Canada is `ca`.

On a Vine page, it reads `customerId` from the page's `vvp-context`. It computes:

```text
cid = lowercase_hex(SHA-256(UTF-8(countryCode + customerId)))
```

There is no separator between the country code and customer ID. For Canada, the input begins with `ca`.

The official extension caches the resulting 64-character CID. It also caches the full VVP context locally in Chrome storage, which can include the raw customer ID and CSRF data. Vine Drop Hub does not need to copy that privacy behavior: it can derive the CID once and persist only the CID.

**Important integration constraint:** Vine Drop Hub's UV `azUser` is `SHA-256(customerId)`. A VH CID is `SHA-256(countryCode + customerId)`. A VH CID cannot be derived from an already-hashed UV `azUser`; the raw customer ID or a separately precomputed VH CID is required.

Relevant official source: `scripts/core/services/Environment.js:513-717`.

### 3.2 Per-install cryptographic keys

Official VHelper generates and stores two key pairs atomically:

- **ECDSA P-256**, extractable, usages `sign`/`verify`.
- **RSA-OAEP 2048/SHA-256**, extractable, usages `encrypt`/`decrypt`.

It validates restored keys by importing and exercising them; missing/corrupt keys are regenerated.

For VH API requests, only the ECDSA key pair matters. The client:

1. builds a `content` object;
2. signs the exact UTF-8 bytes of `JSON.stringify(content)` using ECDSA/SHA-256;
3. encodes the 64-byte raw IEEE-P1363 signature with standard Base64 as `s`;
4. adds the ECDSA public JWK as `pk`.

The RSA pair is used only to encrypt extension-local BroadcastChannel relays, with hybrid AES-GCM for large messages. It is not part of the observed VH API or Socket.IO authentication. A single-process Node receiver does not need to port that RSA layer.

Relevant official source: `scripts/core/utils/CryptoKeys.js`.

### 3.3 UUID provisioning

When no UUID exists, the official client POSTs JSON to the selected VH API root:

```json
{
  "api_version": 5,
  "app_version": "4.5.2",
  "action": "get_uuid",
  "country": "ca",
  "cid": "<64 lowercase hex characters>",
  "s": "<Base64 raw P-256 signature>",
  "pk": "<ECDSA public JWK>"
}
```

The signature is over the five fields preceding `s` and `pk`. A successful response has `ok: "ok"` and `uuid`.

Relevant official source: `scripts/core/services/Environment.js:395-437`.

### 3.4 Device name

The extension generates a persistent, human-readable steampunk-style device name. Names must be 15–100 characters. The exact word lists are presentation, not protocol; stability and length are the meaningful requirements.

Relevant official source: `scripts/core/services/DeviceMgr.js`.

### 3.5 Device fingerprint and `fid`

After obtaining a UUID and device name, a browser-context client builds a fingerprint object containing:

- hardware concurrency and device memory;
- screen width/height, colour depth, and pixel ratio;
- browser language(s) and maximum touch points;
- timezone and locale;
- `performance.memory` where available;
- canvas output;
- WebGL vendor/renderer/version/extensions;
- a detected-font list.

It hashes `JSON.stringify(fingerprintObject)` with SHA-256 and encodes the 32-byte digest as standard Base64 (44 characters). The UUID argument is deliberately not included in that object.

It then POSTs this signed body:

```json
{
  "api_version": 5,
  "app_version": "4.5.2",
  "country": "ca",
  "action": "upload_fingerprint",
  "uuid": "<server UUID>",
  "cid": "<VH CID>",
  "fingerprint": "<44-character Base64 SHA-256 digest>",
  "device_name": "<persistent name>",
  "s": "<signature over the preceding content>",
  "pk": "<ECDSA public JWK>"
}
```

A successful response contains `fingerprint_id`; the extension stores it as `general.fingerprint.id`. This is the official normal provisioning path, although current server compatibility evidently permits the dashboard's legacy blank-FID identity to connect.

A manually imported UUID is validated/linked by uploading this installation's fingerprint to that UUID. A device may be unlinked with the signed `delete_device` action using UUID, CID, and device record ID.

Relevant official source: `scripts/core/services/DeviceFingerprintMgr.js`.

### 3.6 What a server implementation should do

A Node service has no real browser canvas, WebGL renderer, or screen. It should not pretend to have those. For a server-side receiver, the defensible equivalent is a stable, random, per-install pseudonymous 32-byte value represented as a 44-character Base64 digest, then registered through the exact signed `upload_fingerprint` protocol. Whether VH applies any server-side assumptions beyond “stable opaque hash” cannot be proven from client source and needs a user-run VPS test.

The app should persist, with mode `0600`:

- schema version;
- country and VH CID;
- optional user-supplied existing official UUID;
- generated ECDSA private/public JWKs;
- UUID returned/validated by VH;
- stable device name;
- stable fingerprint hash and returned `fid`;
- creation/update timestamps and audited app version.

It should not store a raw Amazon customer ID.

## 4. Official Socket.IO contract

### 4.1 Connection endpoints and options

Primary:

```text
wss://api.v-helper.com
```

Fallback:

```text
wss://api.vinehelper.ovh
```

The fallback selection is persisted with an expiry. The current UI text and implementation select it for seven days, despite a legacy method name mentioning 48 hours.

Official client options:

```js
{
  query: {
    app_version,
    countryCode,
    uuid,
    fid,
    cid,
    device_name
  },
  transports: ["websocket"],
  reconnection: false
}
```

There is no observed Socket.IO `auth` object, cookie, bearer token, custom namespace, or custom path. The default Socket.IO path is used. The bundled browser client is Socket.IO `4.8.1`.

Relevant official source: `scripts/notifications-monitor/stream/Websocket.js:1-177`.

### 4.2 Incoming events

| Event | Observed client interpretation |
|---|---|
| `connect` | Transport connected; inspect `socket.recovered`. |
| `newItem` | Payload contains `data.item`; this is a genuine live broadcast. |
| `connection_info` | Connection/account metadata. Stored fields include socket ID, tier, connection usage/allowance, and devices. |
| `last100` | Payload contains `products`; response to history, gap-fill, or health-probe requests. |
| `newETV` | `data.item` contains at least ASIN and ETV; enrich an existing item. |
| `newPrice` | `data.item` contains ASIN/price and may include additional images. |
| `newVariants` | Payload contains ASIN and variants; enrich an existing item. |
| `unavailableItem` | `data.item` contains ASIN; mark an existing item unavailable. |
| `reloadPage` | Server-coordinated assisted-load request with queue/page. |
| `orderAttempts` | Counts for successful/failed order attempts for an ASIN. |
| `serverDisconnect` | Server denial/forced disconnect; stop reconnecting and display its message. |
| `connection_error` | Application-level error. Certain values identify a missing/old UUID. |
| `disconnect` | Transport closed; ordinary retry remains active. |
| `connect_error` | Socket.IO/transport setup error. |
| `broadcastSyncPong` | Server's latest-broadcast marker for gap detection. |

### 4.3 Outgoing events

| Event | Payload/use |
|---|---|
| `broadcastSyncPing` | No payload; sent every 60 seconds while connected. |
| `getLast100` | Signed identity is not used here; fields are app version, UUID, CID, FID, country, limit, optional `since`, and `request_variants`. |
| `disconnectRequest` | Requests another socket ID be disconnected; includes account/device identity. |
| `reloadRequest` | Assisted-load request with UUID/CID/FID/country. |

The passive Vine Drop Hub should not emit assisted-load/reload or contribution traffic.

## 5. Recovery and health state machine

The official client does substantially more than test `socket.connected`:

1. **10-second supervisor:** checks transport health and attempts manual reconnects.
2. **Socket reuse:** when URL and all identity fields are unchanged, it reconnects the same Socket object so Socket.IO's recovery session/offset survive.
3. **Connection-state recovery:** on `connect`, it reads `socket.recovered`. Official comments state that the server can replay missed broadcasts for up to roughly one minute.
4. **Gap backfill:** if a prior connection existed, recovery failed, and a latest item-date cursor exists, it emits `getLast100` with `limit: 100` and `since: <last item.date>`.
5. **Engine activity:** Engine.IO `packet`, `ping`, and `pong` events refresh a transport activity timestamp.
6. **Engine silence:** more than two minutes without engine activity forces reconnect.
7. **Maximum connection age:** a connection older than three hours is refreshed.
8. **Broadcast synchronization:** every 60 seconds, it emits `broadcastSyncPing`. The pong is `{available, asin, timestamp}`. If the server's different ASIN is newer than the last locally received broadcast, it reconnects to attempt recovery.
9. **Application health probe:** after 15 minutes without an application event, it emits `getLast100` with `limit: 1`; no response within 30 seconds forces reconnect.
10. **Invalid UUID:** `connection_error.invalid_uuid === true`, `"UUID does not exist"`, or `"Old UUID"` clears/re-provisions UUID.
11. **Server denial:** `serverDisconnect` stops the reconnect interval and tears down the socket, avoiding an infinite denial loop.

Relevant official source: `scripts/notifications-monitor/stream/Websocket.js` and `broadcastSync.js`.

### Required no-history adaptation

The user's standing requirement keeps VH `last100` disabled. Therefore Vine Drop Hub should implement socket reuse/recovery, engine-silence detection, maximum age, broadcast sync, and explicit server/error handling, but **must not copy**:

- the 15-minute `getLast100 limit: 1` health probe; or
- the `getLast100 limit: 100, since: ...` gap backfill.

The unavoidable trade-off is that a gap longer than the server's recoverable Socket.IO session cannot be repaired from VH history. The app should mark such a case as **degraded / possible missed VH broadcasts**, alert once using the existing delayed health system, and continue with new live traffic.

**2026-10-03 correction after exact-CRX revalidation:** a `broadcastSyncPong` timeout must not be used as a forced-disconnect health probe. The official 4.5.2 client sends the ping but defines no pong deadline; it reconnects only when a returned pong proves a newer, different broadcast marker. The official 30-second timeout belongs to its prohibited `getLast100 limit: 1` probe. Because Vine Drop Hub cannot use that history probe, it must treat healthy Socket.IO/Engine.IO transport as connected and retain application events/pongs as supplemental evidence.

## 6. Official item semantics

### 6.1 Core item fields

The official `Item` model requires these fields to be present (values may be null, but not undefined):

- `asin`
- `queue`
- `is_parent_asin`
- `enrollment_guid`

Other observed fields include:

- `is_pre_release`
- `title`
- `img_url`
- `etv_min`, `etv_max`
- `price`
- `tier`
- `date` — UTC MySQL-format broadcast time (`YYYY-MM-DD HH:mm:ss`)
- `date_added` — UTC server first-added time
- `unavailable`
- `variants`, `variant_asin`
- `additional_img`
- `order_success`, `order_failed`
- local keyword/blur flags and timestamps.

Queue mapping is:

| VH queue | Dashboard abbreviation |
|---|---|
| `potluck` | RFY |
| `last_chance` | AFA |
| `encore` | AI |
| `all_items` | ALL |

A live item's `reason` can identify rebroadcast causes such as enrollment-guid or queue changes. Official UI storage is keyed by ASIN and updates an existing tile rather than displaying a second tile.

Relevant official source: `scripts/core/models/Item.js`, `ServerCom.js`, and `NotificationMonitor.js`.

### 6.2 Live events versus enrichment

Only `newItem` is a live item detection for the dual-feed race. These are silent enrichments and must not add a VH live-source timestamp or notify:

- `newETV`
- `newPrice`
- `newVariants`
- `unavailableItem`
- `orderAttempts`

For enrichments arriving before their live item, a short-lived pending-enrichment map is safer than creating a card: apply it if the item arrives; otherwise discard it.

`reloadPage` is an active Amazon assisted-load command and should be ignored/logged by the passive service.

### 6.3 Current item-model losses

Vine Drop Hub currently handles `newItem`'s wrapper, queue, title, image, and much of ETV/price normalization, but its persisted merged record discards or conflates several official semantics:

- snake-case `is_parent_asin` and `is_pre_release`;
- `enrollment_guid`;
- `tier` and `reason`;
- VH server `date` and `date_added` as separate diagnostic clocks;
- unknown ETV versus retail price in some fallback paths;
- explicit numeric/string unavailable flags;
- all update-only events listed above.

UTC MySQL dates should be parsed explicitly as UTC rather than with implementation-dependent `Date.parse` behavior.

## 7. Official notification behavior

After receiving a live item, the extension performs local processing:

1. HTML-decodes the title twice.
2. Evaluates highlight keyword groups, including optional ETV conditions.
3. Evaluates hide keywords only if no highlight matched; highlight therefore wins over hide.
4. Evaluates blur keywords independently.
5. Builds a search phrase from up to approximately 40 title characters, removes punctuation and one-letter words, and records a Unix timestamp from `item.date`.

Optional OS notifications are generated only by the master monitor for:

- matching highlight keywords when push notifications are enabled; or
- AFA (`last_chance`) when AFA push is enabled.

The notification ID is `notification_<ASIN>`, so later notifications for that ASIN replace the prior OS notification. A click opens a VH modal URL when enough item identity is available, otherwise a Vine title search.

User-configured webhooks can be sent for a matching keyword group, AFA, RFY, and separately zero ETV. Webhooks explicitly skip `fetchLatest` history. The OS-notification transformer does not contain the same explicit history guard, another reason not to enable `last100` in this deployment.

### Vine Drop Hub policy to retain

The dashboard's required policy is different and should remain authoritative:

- one card for the same ASIN;
- the first genuine live source sends the app's configured Telegram/Discord alert;
- the second source only records the race time;
- history and enrichment never notify;
- persisted ASIN/time deduplication prevents immediate duplicate alerts.

Do not add VHelper's own webhook pipeline on top of the app's notification pipeline; that would recreate duplicates.

A later enhancement can represent a truly new “drop episode” for the same ASIN (for example, a changed enrollment GUID after the dedupe window) while retaining one card and one notification per episode.

## 8. Other outbound behavior and telemetry

The official extension includes much more than a passive receiver:

- `get_info` uploads current Vine-page item data for server enrichment;
- `record_etv`, `record_order`, and `record_unavailable` contribute observations;
- variant, review, pin, hidden-list, keyword-list, item-explorer, subscription, and reporting APIs;
- `reloadRequest`/`reloadPage` coordinate Amazon page loads;
- optional user webhooks and Brenda/Llama Stories integration;
- signed parse/API-validation/integrity reports;
- a signed `submit_settings_analytics` submission every seven days.

The weekly settings submission contains UUID/CID/FID, an account/device-derived client hash, and a booleanized settings map. It blocks exact secrets such as UUID, CID, device name, crypto keys, fingerprints, custom CSS, webhook URLs/content, VVP context, and checkout state from the map itself. Parse failures are rate-limited per parser/page context to once per hour and sent in batches of up to ten after redaction.

None of these contribution, analytics, autoload, Amazon-order, or error-reporting paths is necessary for Vine Drop Hub's passive notification feed. They should **not** be ported implicitly. The one useful optional diagnostic API is signed `get_connection_details`, and that should be user-triggered rather than telemetry.

The manifest does not permit remote executable scripts, and the non-vendor application source contains no `eval`, `new Function`, or remote dynamic import. Network behavior is nevertheless broad because the extension implements the features above and can request optional arbitrary host permissions for user webhooks.

## 9. Comparison with current Vine Drop Hub

| Area | Official 4.5.2 | Current Vine Drop Hub | Decision |
|---|---|---|---|
| App version | Manifest `4.5.2` | Advertises `4.7.0` | Pin to audited `4.5.2`; update only after another static audit. |
| CID | Hash of country + real Amazon customer ID | Hash of country + generated synthetic ID | Preserve as clearly labelled isolated mode; add official linked mode. |
| ECDSA | Fresh per-install P-256 pair | Fixed embedded private/public JWK | Use fresh keys for new identities; remove the shared key from source without silently invalidating a working legacy UUID. |
| RSA | Local relay encryption only | Not implemented | Keep omitted; not needed in one process. |
| UUID | Signed `get_uuid` using Amazon-derived CID | Signed request using a synthetic CID/fixed key | Existing UUID may remain functional; new identities should use the hardened per-install flow. |
| Fingerprint | Signed upload returns `fid` | None; sends blank FID | Add for hardened/official mode; retain a bounded legacy compatibility path if necessary. |
| Device name | Persistent random 15–100 chars | Fixed `cat-dashboard-v9` | Generate/persist per install. |
| Socket query | Six normally populated fields | Correct names; synthetic identity, nonofficial version, blank FID | Preserve compatible legacy mode; populate exact values for new hardened/linked identities. |
| Readiness | Identity/device plus connection metadata/events | Treats transport `connect` as healthy | Track transport versus authenticated/application-ready. |
| Incoming events | Full event set | Primarily `newItem`, `connection_info`, optional history, compatibility wrappers | **P1 add explicit handlers.** |
| Server denial | Stops reconnecting | Not handled | **P0/P1 add.** |
| Invalid UUID | Re-provisions | Generic reconnect with stale identity | Preserve/latch locally under the explicit identity-continuity requirement; no automatic replacement. |
| Session recovery | Reuses same socket and checks `recovered` | Built-in reconnect usually reuses manager, but no recovery/gap state | Make reuse and recovery state explicit. |
| Engine silence | Two-minute detection | No engine-level silence check | **P1 add.** |
| Broadcast sync | 60-second ping/pong comparison | None | **P1 add without history.** |
| Max connection age | Three hours | None | **P1 add.** |
| History probe/backfill | Uses `getLast100` | Disabled by deployment policy | Keep disabled; report unresolved gap/degraded state. |
| Enrichment | ETV/price/variants/unavailable/order counts | Ignored | **P1 merge silently.** |
| Item schema | Preserves VH identity and server times | Drops several fields | **P1 preserve/map.** |
| Duplicate notification | Master-local policy; ASIN OS ID | First-live-source app policy with persistent dedupe | Keep Vine Drop Hub behavior. |
| Routing | Browser's normal route | VH through exact direct-egress proxy, UV through Gluetun | Keep; extend exact allowlist only if fallback is enabled. |
| Telemetry/contribution | Broad, signed, feature-dependent | Not ported | Keep omitted for passive mode. |

## 10. Concrete implementation plan

### P0 — required before calling VH production-ready

1. **Introduce VH identity schema v2.** Record `identityMode` (`synthetic` or `amazon-linked`) and store CID, UUID, per-install ECDSA JWKs, device name, fingerprint hash, FID, and metadata. Never persist a raw customer ID.
2. **Preserve a working legacy identity.** Detect the current `{uuid, customerId, country}` record as legacy, retain it and a `0600` rollback copy, and do not silently rotate or replace its UUID. Surface its mode and limitations in diagnostics.
3. **Keep explicit synthetic-ID generation.** It currently works for the passive feed. Label it “Generate isolated VH identity,” use a fresh random CID seed and per-install key for new identities, and require confirmation because it creates a separate server-side identity.
4. **Add optional official VH onboarding.** Accept either:
   - a raw Amazon customer ID, hash it in memory as `SHA-256(country + ID)`, then discard it; or
   - a precomputed 64-character VH CID.
   An optional official VHelper App ID/UUID can link this VPS as another device for the same VH account. VH onboarding must be independent of UV onboarding unless the user explicitly chooses to use the same raw Amazon identity for both.
5. **Generate a fresh P-256 key pair for every new v2 identity.** Remove the shared embedded private JWK from source. Validate restored keys before use, while providing a controlled legacy path for an already-working UUID.
6. **Generate a stable device identity.** Persist a valid random device name and a stable per-install Base64 fingerprint hash.
7. **Provision hardened identities exactly.** Call signed `get_uuid` when an existing official UUID is not supplied, then signed `upload_fingerprint`. Prefer UUID+FID before Socket.IO, while reporting—not silently destroying—a legacy blank-FID identity that the server still accepts.
8. **Use protocol constants from the audited package.** API version 5 and app version `4.5.2` for official-parity mode.
9. **Clarify identity controls.** Provide “Generate isolated VH identity,” “Link/provision official VH account,” “Repair device,” and a separate destructive reset, each with confirmation.
10. **Secure persistence.** Fix `saveJSON` so atomic temp-file replacement preserves/sets sensitive modes. Use `0700` for the data directory and `0600` for config/identity/private-key files.
11. **Handle denial/auth events.** Treat invalid-UUID `connection_error` and `serverDisconnect` as latched health incidents that do not hammer the service or automatically mutate saved identity material.

### P1 — reliability and data correctness

12. **Split state:** disabled → setup-required → provisioning → transport-connecting → transport-connected → application-ready → degraded/denied.
13. **Store `connection_info`.** Surface tier, socket ID, connection usage/limit, and device names in diagnostics without exposing private keys or raw IDs.
14. **Reuse the same Socket object** when parameters are unchanged; record `socket.recovered` and recovery outcomes.
15. **Port non-history health logic:** 10-second supervisor, two-minute engine silence, three-hour refresh, and 60-second broadcast-sync ping. Returned pongs support marker comparison; no pong deadline may force a disconnect.
16. **Respect no-history mode absolutely:** never emit `getLast100`, including limit-1 probes and `since` backfill. Mark unrecoverable gaps degraded and alert through the existing deduplicated feed-health system.
17. **Handle all passive incoming events.** `newItem` is live; ETV/price/variants/unavailable/order attempts are silent enrichment; `reloadPage` is ignored/logged; unsolicited `last100` is ignored and never ingested/notified.
18. **Preserve official fields.** Add reason, tier, enrollment GUID, parent/pre-release flags, raw VH queue, server sent/added timestamps, and explicit UTC parsing.
19. **Normalize types defensively.** Do not turn string `"0"` into boolean true; do not represent unknown VH ETV as retail price.
20. **Queue orphan enrichments briefly** without creating live cards.
21. **Keep existing dual-feed behavior.** Local receipt time remains the race clock; the second feed and enrichments remain silent.

### P2 — diagnostics, migration, and maintainability

22. Add an on-demand signed `get_connection_details` diagnostic; do not schedule analytics.
23. Optionally support the official fallback host through an explicit dashboard choice/expiry. If enabled, extend the CONNECT proxy to the two exact VH hosts only; never make it a general proxy.
24. Track same-ASIN drop episodes by enrollment GUID/time while retaining one card and one first-source notification per episode.
25. Add bounded/redacted unknown-event diagnostics and counters for last engine activity, last app event, last sync pong, last live item, recovery success, and suspected gaps.
26. Update configuration examples, deployment docs, the pasteable updater, portable-package exclusions, and migration instructions.
27. Add offline mock tests for payload shape/signatures, legacy migration, FID gating, Socket.IO options, recovery, all event mappings, notification suppression, no `getLast100` emission, and proxy policy.

## 11. What must remain unchanged

The implementation should preserve all existing accepted behavior:

- UV remains pinned to the Ultraviner 26.9.38 protocol baseline.
- UV stays inside the application-only Canadian Gluetun route.
- VH stays on the normal VPS route through the destination-locked proxy.
- UV new-account onboarding still requires both a new token and new Amazon identity and rejects reuse of either.
- Changing UV accounts does not reset VH unless explicitly requested.
- Existing screens, custom queues, feed history, keywords, pins/hides, notifications, and health persistence remain.
- Matching ASINs share one card; only the first genuine live source notifies.
- VH `last100` stays disabled.
- The assistant performs no live credential/feed tests.

## 12. Static-analysis limits

The package contains only the client. Static inspection cannot prove:

- the server's exact UUID/CID/FID validation rules;
- whether an opaque stable server-install fingerprint is accepted;
- the actual Socket.IO recovery retention window (the one-minute value is from official client comments);
- every server-side error payload or subscription/device-limit rule;
- whether `get_uuid` always resolves an existing UUID for a known CID.

Those points require a later user-run test from the intended VPS/direct route. They do not require or justify assistant-side endpoint contact.
