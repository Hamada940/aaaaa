# App-only OpenVPN or WireGuard deployment

> For the packaged Ubuntu 22.04/24.04 installation and dashboard profile switching, use `MIGRATE_TO_NEW_UBUNTU.md` and `DASHBOARD_VPN_UPLOAD.md`. This file documents the underlying manual setup. Read `GLUETUN_V3_41_1_WIREGUARD_AUDIT.md` before changing the pinned image or its secret-file adaptation.

This dual-stack deployment sends UV and SmartViner through either a custom self-contained OpenVPN profile or a standard WireGuard client profile while VH uses the VPS's normal route through a CONNECT-only proxy restricted to `api.v-helper.com:443`. SmartViner has its own CONNECT process on VPN-loopback `127.0.0.1:8889`, restricted to `smartviner.com:443`; it never uses VH's direct exception. Other VPS programs keep their normal network route. The dashboard is published only on VPS loopback (`127.0.0.1:3001`).

Three-source behavior is deliberately deduplicated by ASIN: the first genuine UV/VH/SV live source creates the card and notification; every later source updates that card's provenance/timing without a duplicate notification. VH `getLast100` and SmartViner catalogue/history/catch-up are disabled. See `VH_SPLIT_ROUTE.md` and `SMARTVINER_LIVE_SOURCE.md`.

Use this only where the VPN provider and upstream services permit it. It changes network routing; it does not override server-side authorization.

## Legacy OpenVPN example

The originally inspected OpenVPN profile is self-contained and uses:

- client certificate/private key embedded in the `.ovpn` file
- UDP
- `AES-256-CBC`
- `SHA512`
- endpoint `ca.vpnunlimitedapp.com`
- no `auth-user-pass` credential file

Do not paste or commit the profile because it contains a private key.

## 1. Install Docker

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-v2
sudo systemctl enable --now docker
sudo docker version
sudo docker compose version
```

## 2. Install the private profile through the host manager

Privately transfer either `profile.ovpn` or `profile.conf`; never paste it into
chat or commit it. From `~/vine`:

```bash
sudo install -d -m 700 vpn vpn/profile-backups vpn-control/processing
sudo install -d -m 755 vpn-control/status
sudo install -d -m 700 -o 1000 -g 1000 vpn-control/inbox data
sudo python3 host/vpn_profile_manager.py \
  --project-dir "$PWD" \
  --install-profile /FULL/PRIVATE/PATH/profile.ovpn-or.conf
```

The manager validates and normalizes the profile, resolves endpoint hostnames
on the host, creates root-only runtime files, and keeps private keys out of
Compose and environment values. OpenVPN still uses a prepared
`client.gluetun.ovpn`; WireGuard uses canonical `wireguard.conf`, a minimal
private `wg0.conf`, and public routing values in `active.env`. All five files
are mode 0600 and must not be copied into a release payload.

## 3. Stop conflicting host processes

Do not run the manual Node process and Docker copy simultaneously. Temporarily stop PM2-managed feed programs:

```bash
sudo systemctl stop pm2-ubuntu
sudo ss -ltnp '( sport = :3001 )'
```

The `ss` command should show nothing listening on port 3001.

## 4. UV identity is automatic

Do not hand-generate or copy device, screen, Alert, Chat, or Explore queue IDs. On first start the application writes a complete UUIDv4 profile to `data/uv_profile.json`.

To configure an account, submit the **new UV token** and that **new Amazon account's Vine `customerId` or SHA-256 hash** together on **Screens & Queues**. Same-account token-only renewal and reuse of either saved credential are intentionally rejected. All device, screen, and queue IDs are regenerated or synchronized automatically.

## 5. Build and start

The host kernel and Docker daemon must permit IPv6 on a user-defined bridge.
The authenticated installer/updater preflights this before activation. Do not
replace the release ULA subnet with a public prefix.

```bash
cd ~/vine
sudo docker compose -f compose.vpn.yml up -d --build
sudo docker compose -f compose.vpn.yml ps
```

Follow the VPN, application, and destination-locked SV proxy logs:

```bash
sudo docker compose -f compose.vpn.yml logs -f vpn sv-proxy app
```

Expected VPN log state includes a healthy tunnel and a Canadian public IP. Expected application state includes:

```text
[UV FRAME] type=connected products=0
[UV WS] Session authenticated.
[UV FRAME] type=plan products=0
[UV WS] Plan: ultimate
```

Press `Ctrl+C` only to stop following logs; it does not stop the containers.

## 6. Verify app-only routing

Host route (normal VPS connection):

```bash
curl -4s https://ipinfo.io/json | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d.get("country"), d.get("org"))'
```

Application route (VPN connection):

```bash
sudo docker compose -f compose.vpn.yml exec app node -e \
"fetch('https://ipinfo.io/json').then(r=>r.json()).then(d=>console.log(d.country,d.org)).catch(e=>{console.error(e.message);process.exit(1)})"
```

The outputs should differ, and the application result should report `CA`. Do not post either public IP.

Test the local dashboard/API:

```bash
curl http://127.0.0.1:3001/api/status
curl -sS -X POST -H 'Content-Type: application/json' -d '{}' \
  http://127.0.0.1:3001/api/uv/test-token
```

## 7. Dashboard access

From your own computer:

```bash
ssh -L 3001:127.0.0.1:3001 ubuntu@YOUR_SERVER_IP
```

Then open `http://127.0.0.1:3001` locally.

## Operations

Show status:

```bash
sudo docker compose -f compose.vpn.yml ps
```

Follow application logs only:

```bash
sudo docker compose -f compose.vpn.yml logs -f app
```

Restart the four-service stack without changing profile state:

```bash
sudo docker compose -f compose.vpn.yml restart
```

Stop without deleting persisted files:

```bash
sudo docker compose -f compose.vpn.yml down
```

Do not hand-delete or replace an individual VPN runtime file. Use the dashboard
manager so all five files remain one transaction. To decommission the server,
stop Compose first and securely remove the complete `vpn/`, `vpn-control/`,
`data/`, and populated `config.json` private state according to local policy.

The OpenVPN/WireGuard profiles, derived runtime files, populated `config.json`,
and `data/` directory are excluded from Docker's build context and release
manifests and must not be committed or shared.
