# Clean R25 OpenVPN/WireGuard dual-stack installation

Release: `r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18`  
Target: clean Ubuntu 22.04 or 24.04 amd64 VPS

This path installs a private-state-free release under `/opt/vine-drop-hub`.
Detection remains on the VPS; Amazon-authenticated ordering remains in the
separately installed Windows Chrome/Edge companion. The dashboard binds only to
`127.0.0.1:3001` and must be reached through SSH. This successor preserves authenticated VHelper 4.7.4/build-3637 and UltraViner 26.11.62 compatibility, adds automatic bounded recovery from silent UV authentication timeouts, and progressively loads the Live Feed in 500-item increments through 2,000 retained records. Explicit UV `invalidToken` remains terminal/manual-only; no history, polling, identity, ordering, VPN, or private-state boundary is widened.

## Requirements

- Clean Ubuntu 22.04 or 24.04 amd64
- sudo-capable account
- provider-enabled `/dev/net/tun`
- host IPv6 enabled (`/proc/sys/net/ipv6/conf/all/disable_ipv6` equals `0`)
- Docker Engine/Compose v2, or network access for the installer to install them
- at least 1.5 GiB RAM plus swap for bounded image build and tests
- one self-contained OpenVPN `.ovpn` **or** standard WireGuard `.conf`
- to preserve the exact working VHelper identity: private access to the complete
  current `data/identity.json`, not just visible CID/UUID values
- for PC ordering: Windows 10/11, Chrome or Edge 120+, OpenSSH Client, and the
  existing authenticated Amazon.ca Vine browser profile

Never paste a VPN profile, private key, populated config, bearer token, VHelper
identity/signing key, notification credential, SmartViner password/session, or
pairing secret into chat.

## 1. Install the authenticated release

Preferred terminal-paste artifact:

```text
PASTEABLE_NEW_VPS_R25_UV_AUTH_RECOVERY_LIVE_FEED_CAPACITY_HOTFIX_20260910_18.txt
```

It creates and authenticates:

```text
vine-drop-hub-r25-uv-auth-recovery-live-feed-capacity-hotfix-new-vps-installer-20260910-18.sh
```

Run the exact command printed by the wrapper, normally:

```bash
sudo bash ./vine-drop-hub-r25-uv-auth-recovery-live-feed-capacity-hotfix-new-vps-installer-20260910-18.sh
```

Equivalent separate artifacts are:

```text
vine-drop-hub-r25-uv-auth-recovery-live-feed-capacity-hotfix-new-vps-20260910-18.tar.gz
install-new-ubuntu-r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18.sh
```

Run them from the same private directory:

```bash
sudo bash ./install-new-ubuntu-r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18.sh \
  --payload ./vine-drop-hub-r25-uv-auth-recovery-live-feed-capacity-hotfix-new-vps-20260910-18.tar.gz
```

The installer authenticates the archive and exact inventory, installs Docker
from Docker's signed Ubuntu repository only if needed, installs code under
`/opt/vine-drop-hub`, and starts only the narrow host VPN manager. It leaves
Compose stopped when no private profile was provided.

## 2. Privately transfer one VPN profile

From a trusted machine, stream the bytes over SSH. Choose one source; do not
print it:

```bash
OLD_SERVER=ubuntu@YOUR_OLD_SERVER
NEW_SERVER=ubuntu@YOUR_NEW_SERVER
OLD_PROJECT=/home/ubuntu/vine

# Existing OpenVPN state:
ssh "$OLD_SERVER" "sudo cat '$OLD_PROJECT/vpn/client.ovpn'" \
  | ssh "$NEW_SERVER" 'umask 077; cat > ~/vine-vpn-profile.ovpn'

# Or an existing successor WireGuard state:
# ssh "$OLD_SERVER" "sudo cat '$OLD_PROJECT/vpn/wireguard.conf'" \
#   | ssh "$NEW_SERVER" 'umask 077; cat > ~/vine-vpn-profile.conf'
```

A WireGuard `.conf` may instead come directly from the VPN provider. Keep the
extra transfer copy mode 0600 and delete it after finalization.

## 3. Preserve only intended configuration and identity

For a fresh card/history/order state while retaining current connection
settings and the exact working synthetic VHelper identity, transfer only
`config.json` and complete `data/identity.json`:

```bash
ssh "$OLD_SERVER" "sudo cat '$OLD_PROJECT/config.json'" \
  | ssh "$NEW_SERVER" 'umask 077; cat > ~/vine-config.json'

ssh "$OLD_SERVER" "sudo cat '$OLD_PROJECT/data/identity.json'" \
  | ssh "$NEW_SERVER" 'umask 077; cat > ~/vine-vh-identity.json'
```

On the new VPS:

```bash
sudo install -m 600 -o 1000 -g 1000 \
  ~/vine-config.json /opt/vine-drop-hub/config.json
sudo install -d -m 700 -o 1000 -g 1000 /opt/vine-drop-hub/data
sudo install -m 600 -o 1000 -g 1000 \
  ~/vine-vh-identity.json /opt/vine-drop-hub/data/identity.json
rm -f ~/vine-config.json ~/vine-vh-identity.json
```

Do not transfer the rest of `data/` when cards, history, cleared memory,
SmartViner session, pairing, rules, jobs, watches, and safety state must start
fresh. Do not generate a replacement VHelper identity.

## 4. Finalize and start

If the old VPS still receives the same feeds, stop it immediately before the
new stack starts to avoid duplicate sessions/notifications:

```bash
ssh "$OLD_SERVER" \
  "cd '$OLD_PROJECT' && sudo docker compose -f compose.vpn.yml down"
```

Then on the new VPS, use the extension matching the transferred profile:

```bash
sudo /opt/vine-drop-hub/host/finalize-install.sh \
  --project-dir /opt/vine-drop-hub \
  --profile /home/ubuntu/vine-vpn-profile.ovpn
# Or: --profile /home/ubuntu/vine-vpn-profile.conf

rm -f ~/vine-vpn-profile.ovpn ~/vine-vpn-profile.conf
```

The finalizer independently validates and canonicalizes the profile, builds
only the local application/VHelper-proxy images, pulls pinned Gluetun
`v3.41.1`, verifies Compose, runs all **250 Node tests and 17 Python manager
tests** offline, starts four services, waits for health, and performs
protocol-aware egress verification. Dual-stack WireGuard must pass IPv4 and
IPv6 HTTPS probes; IPv4-only profiles must pass IPv4.

If cutover fails, leave the new stack stopped and restart the old stack while
investigating locally:

```bash
ssh "$OLD_SERVER" \
  "cd '$OLD_PROJECT' && sudo docker compose -f compose.vpn.yml up -d --no-build --pull never"
```

## 5. Open the private dashboard

From your normal computer:

```bash
ssh -N -T \
  -L 127.0.0.1:3001:127.0.0.1:3001 \
  ubuntu@YOUR_NEW_SERVER
```

Open <http://127.0.0.1:3001>. Never expose port 3001 in a VPS firewall or cloud
security group.

## 6. Verify without disclosing secrets

On the VPS:

```bash
cd /opt/vine-drop-hub
sudo docker compose -f compose.vpn.yml ps
sudo systemctl --no-pager status vine-vpn-profile-manager.service
```

In Settings, verify the VPN manager reports `applied`, the expected protocol,
and the required tunnel families. Do not share endpoint/IP output. Confirm UV,
VHelper, and (after local sign-in) global-only SmartViner independently.

The clean state should have empty cards/activity/notification history, cleared
memory, SmartViner session, order rules, pairing, watches, safety state, and job
ledger unless you deliberately transferred more private state.

## Network and rollback notes

- UV and SmartViner use Gluetun; VHelper alone uses its destination-locked
  direct CONNECT proxy.
- The fixed private Docker subnets are `172.30.77.0/29` and
  `fd30:7725:9::/64`. Resolve any local conflict before installation; do not
  modify an authenticated payload.
- The root manager stores OpenVPN/WireGuard state mode 0600, backs up all five
  protocol files together, and can roll back across protocols from Settings.
- See `DASHBOARD_VPN_UPLOAD.md` and `GLUETUN_V3_41_1_WIREGUARD_AUDIT.md` for the
  exact accepted profile surface and pinned-source behavior.
