[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9._-]+(?:@[A-Za-z0-9.-]+)?$')]
    [string]$SshTarget,

    [ValidateRange(1024, 65535)]
    [int]$LocalPort = 3001,

    [ValidateRange(1, 65535)]
    [int]$RemotePort = 3001,

    [Parameter(Mandatory = $true)]
    [string]$IdentityFile,

    [string]$TaskName = 'Vine Drop Hub SSH Tunnel'
)

$ErrorActionPreference = 'Stop'
$starter = Join-Path $PSScriptRoot 'Start-VineDropHubTunnel.ps1'
if (-not (Test-Path -LiteralPath $starter -PathType Leaf)) {
    throw "Tunnel launcher not found beside this installer: $starter"
}
$starter = (Resolve-Path -LiteralPath $starter).Path
$IdentityFile = [Environment]::ExpandEnvironmentVariables($IdentityFile)
if (-not (Test-Path -LiteralPath $IdentityFile -PathType Leaf)) {
    throw "SSH private key not found: $IdentityFile"
}
$IdentityFile = (Resolve-Path -LiteralPath $IdentityFile).Path

# Task Scheduler receives one command-line string. Quote only paths controlled
# by the current user, and escape embedded quotes defensively.
function Quote-TaskArgument([string]$Value) {
    return '"' + ($Value -replace '"', '\"') + '"'
}

$powerShell = Join-Path $PSHOME 'powershell.exe'
$taskArguments = @(
    '-NoLogo',
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy', 'Bypass',
    '-WindowStyle', 'Hidden',
    '-File', (Quote-TaskArgument $starter),
    '-SshTarget', $SshTarget,
    '-LocalPort', [string]$LocalPort,
    '-RemotePort', [string]$RemotePort,
    '-IdentityFile', (Quote-TaskArgument $IdentityFile)
) -join ' '

$user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute $powerShell -Argument $taskArguments
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -MultipleInstances IgnoreNew

Register-ScheduledTask `
    -TaskName $TaskName `
    -Description 'Loopback-only SSH forward for the Vine Drop Hub dashboard and PC order companion.' `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Force | Out-Null

Start-ScheduledTask -TaskName $TaskName
Write-Host "Installed and started scheduled task: $TaskName"
Write-Host "Local endpoint: http://127.0.0.1:$LocalPort"
Write-Host "Log: $env:LOCALAPPDATA\VineDropHub\logs\ssh-tunnel.log"
