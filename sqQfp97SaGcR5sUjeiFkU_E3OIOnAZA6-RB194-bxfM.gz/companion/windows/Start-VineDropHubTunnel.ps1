[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9._-]+(?:@[A-Za-z0-9.-]+)?$')]
    [string]$SshTarget,

    [ValidateRange(1024, 65535)]
    [int]$LocalPort = 3001,

    [ValidateRange(1, 65535)]
    [int]$RemotePort = 3001,

    [string]$IdentityFile = '',

    [switch]$Once
)

$ErrorActionPreference = 'Stop'

function Resolve-SshExecutable {
    $systemSsh = Join-Path $env:WINDIR 'System32\OpenSSH\ssh.exe'
    if (Test-Path -LiteralPath $systemSsh -PathType Leaf) {
        return $systemSsh
    }
    $command = Get-Command ssh.exe -ErrorAction SilentlyContinue
    if ($null -eq $command) {
        throw 'Windows OpenSSH Client is not installed. Add it in Settings > Optional features.'
    }
    return $command.Source
}

$ssh = Resolve-SshExecutable
if ($IdentityFile) {
    $IdentityFile = [Environment]::ExpandEnvironmentVariables($IdentityFile)
    if (-not (Test-Path -LiteralPath $IdentityFile -PathType Leaf)) {
        throw "SSH private key not found: $IdentityFile"
    }
    $IdentityFile = (Resolve-Path -LiteralPath $IdentityFile).Path
}

$stateRoot = Join-Path $env:LOCALAPPDATA 'VineDropHub'
$logRoot = Join-Path $stateRoot 'logs'
New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
$logPath = Join-Path $logRoot 'ssh-tunnel.log'

function Write-TunnelLog([string]$Message) {
    if ((Test-Path -LiteralPath $logPath) -and (Get-Item -LiteralPath $logPath).Length -gt 1MB) {
        Move-Item -LiteralPath $logPath -Destination "$logPath.previous" -Force
    }
    $line = '{0:u} {1}' -f (Get-Date), $Message
    Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
}

$arguments = @(
    '-N',
    '-T',
    '-L', "127.0.0.1:${LocalPort}:127.0.0.1:${RemotePort}",
    '-o', 'ExitOnForwardFailure=yes',
    '-o', 'ServerAliveInterval=15',
    '-o', 'ServerAliveCountMax=3',
    '-o', 'TCPKeepAlive=yes',
    '-o', 'StrictHostKeyChecking=yes',
    '-o', 'BatchMode=yes'
)
if ($IdentityFile) {
    $arguments += @('-i', $IdentityFile, '-o', 'IdentitiesOnly=yes')
}
$arguments += $SshTarget

Write-TunnelLog "Starting loopback-only SSH forward on 127.0.0.1:$LocalPort."
do {
    try {
        & $ssh @arguments
        $exitCode = $LASTEXITCODE
        Write-TunnelLog "ssh.exe exited with code $exitCode."
    }
    catch {
        Write-TunnelLog "ssh.exe failed: $($_.Exception.Message)"
        $exitCode = 1
    }
    if ($Once) { exit $exitCode }
    Start-Sleep -Seconds 5
} while ($true)
