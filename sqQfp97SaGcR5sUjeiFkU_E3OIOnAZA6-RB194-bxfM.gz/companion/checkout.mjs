const status = document.getElementById('status');
const jobId = new URL(location.href).searchParams.get('job') || '';

function fail(message, { report = true } = {}) {
  status.textContent = message;
  document.querySelector('.spinner')?.remove();
  document.querySelector('h1').textContent = 'Checkout stopped safely';
  if (report && jobId) {
    void chrome.runtime.sendMessage({
      type: 'checkout_relay_failed',
      jobId,
      message: String(message || 'Transient checkout relay failed').slice(0, 300)
    }).catch(() => {});
  }
}

if (!/^[A-Za-z0-9._:-]{8,80}$/.test(jobId)) {
  fail('The one-time job identifier is invalid.');
} else {
  const key = `checkoutRelay:${jobId}`;
  const stored = await chrome.storage.session.get(key);
  const relay = stored[key];
  const allowedNames = new Set([
    'skipCart',
    'quantity',
    'asin',
    'offerListingID',
    'vinePromotionId',
    'vinePurchasePolicyCode'
  ]);
  let action;
  try { action = new URL(relay?.action || ''); } catch (_) { action = null; }
  if (
    !action ||
    action.protocol !== 'https:' ||
    action.hostname !== 'www.amazon.ca' ||
    action.port ||
    action.username ||
    action.password ||
    action.hash ||
    action.pathname !== '/checkout/entry/buynow' ||
    action.searchParams.get('pipelineType') !== 'Chewbacca' ||
    [...action.searchParams.keys()].some(name => name !== 'pipelineType') ||
    !Array.isArray(relay?.fields)
  ) {
    fail('The transient checkout metadata is missing or invalid. The companion will not guess.');
  } else {
    const fields = relay.fields.filter(entry =>
      Array.isArray(entry) && entry.length === 2 && allowedNames.has(String(entry[0]))
    );
    const values = new Map(fields.map(([name, value]) => [String(name), String(value ?? '')]));
    const fieldsValid = fields.length === allowedNames.size &&
      new Set(fields.map(entry => String(entry[0]))).size === allowedNames.size &&
      values.get('skipCart') === '1' &&
      values.get('quantity') === '1' &&
      /^[A-Z0-9]{10,13}$/.test(values.get('asin') || '') &&
      (values.get('offerListingID') || '').length >= 1 &&
      (values.get('offerListingID') || '').length <= 4096 &&
      (values.get('vinePromotionId') || '').length >= 1 &&
      (values.get('vinePromotionId') || '').length <= 160 &&
      values.get('vinePurchasePolicyCode') === 'AmazonVine';
    if (!fieldsValid) {
      fail('The transient checkout form is incomplete or invalid.');
    } else {
      const form = document.createElement('form');
      form.method = 'post';
      form.action = action.href;
      form.target = '_self';
      form.hidden = true;
      for (const [name, value] of fields) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = String(name);
        input.value = String(value ?? '');
        form.appendChild(input);
      }
      document.body.appendChild(form);
      try { await chrome.runtime.sendMessage({ type: 'relay_submitted', jobId }); } catch (_) {}
      status.textContent = 'Request Product completed. Loading Vine checkout…';
      try {
        form.submit();
      } catch (error) {
        fail(`Amazon checkout could not be opened: ${error?.message || 'form submission failed'}`);
      }
    }
  }
}
