# Vine Drop Hub PC Companion — Windows quick start

This is an unpacked Manifest V3 extension for Chrome or Edge 120+. Package 25.0.4 retains Chromium service-worker startup, browser-derived account binding, and fail-closed exact-child ordering, and adds an independent signed **read-only Amazon variant lookup** for UV Explorer RFY/AFA watch dialogs. It does not modify or communicate with Ultraviner, VHelper, or SmartViner, and synthetic IDs held by those services or the Hub are never compared with the browser account.

## 1. Keep this folder in a stable location

Extract the companion ZIP to a permanent folder, for example:

`%LOCALAPPDATA%\VineDropHub\Companion`

Do not load it directly from a temporary ZIP/extraction folder. Future updates must replace files in this **same folder** so the browser retains the same extension storage and pairing.

## 2. Create the loopback SSH forward

Install Windows **OpenSSH Client** and use a key-based SSH login whose host key you have already verified. Nothing is exposed on the LAN: the helper binds only `127.0.0.1`.

From PowerShell in this folder, first test once:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\windows\Start-VineDropHubTunnel.ps1 `
  -SshTarget 'ubuntu@YOUR_VPS' `
  -IdentityFile "$env:USERPROFILE\.ssh\id_ed25519" `
  -Once
```

After that connection succeeds, install the reconnecting logon task:

```powershell
.\windows\Install-VineDropHubTunnelTask.ps1 `
  -SshTarget 'ubuntu@YOUR_VPS' `
  -IdentityFile "$env:USERPROFILE\.ssh\id_ed25519"
```

Verify `http://127.0.0.1:3001` opens. The task log is under `%LOCALAPPDATA%\VineDropHub\logs`.

## 3. Load the extension

- Chrome: open `chrome://extensions`.
- Edge: open `edge://extensions`.
- Enable **Developer mode**.
- Choose **Load unpacked** and select this folder (the folder containing `manifest.json`).
- Pin **Vine Drop Hub PC Companion** if desired.

Keep UV, VHelper, and SmartViner enabled if you use them; this companion does not replace or alter them.

## 4. Pair once

1. Sign in to **Amazon.ca Vine** in this exact browser profile.
2. Open `http://127.0.0.1:3001` and go to **Settings → Windows PC Order Companion**.
3. Click **Create New Pairing Secret** and type the displayed confirmation phrase.
4. Open the companion's **Options** page, keep port `3001`, paste the one-time secret, enable the companion, and save.
5. Click **Refresh Amazon.ca session** if needed.
6. Return to Hub Settings and confirm the PC status is **Ready** and the account binding is **matched**.

A new pairing begins unbound. The first valid signed connection persists only `SHA-256(customerId)` from this browser's real Amazon.ca session; every later connection and every accepted job must remain on that account. The raw ID, cookies, and checkout credentials never leave the PC.

If Hub status says **Re-pair required** after upgrading from the original R25 release, click **Create New Pairing Secret** once and replace the old secret in Options. The legacy synthetic-era value is quarantined rather than compared with your browser account.

Never paste the pairing secret into chat, logs, or a VPS shell. Revoking or replacing pairing invalidates the old secret immediately.

## 5. Configure safety before enabling rules

Automatic rules are disabled by default. In Hub Settings:

- Set the maximum unattended **final Amazon payable total** (initial proposal: C$30.00).
- Add rules in priority order; the first enabled match wins.
- Choose word-only, item-price-only, word AND price, or word OR price.
- Optionally require local PC approval for an entire rule.
- Save, review validation warnings, and only then enable automatic rule dispatch.

Item retail price/ETV matching is not the final-total safety gate. C$0 and totals at or below the configured limit can proceed unattended; a higher exact CAD total opens a PC approval window. Unknown, conflicting, or non-CAD totals stop.

When an eligible VH RFY or UV Explorer RFY/AFA result contains targetable children, **Watch for AFA/AI** can retain either **Any currently available variant** or one exact child ASIN. UV dialogs have a separately labeled **Load variants from Amazon via PC** button. Only that deliberate click sends a short-lived signed read-only request. Package 25.0.4 refreshes this browser's Amazon.ca identity, verifies it still matches the pairing, performs one current recommendation-variations GET, and returns only bounded child ASIN/dimension choices. This lookup cannot call Request Product, checkout, or Place Order; it does not arm the watch, retry, persist choices, or fall back to VHelper. The separate VHelper button is controlled by the Hub and is never called by this extension.

When a later fresh AFA/AI event actually triggers an exact watch, package 25.0.4 re-reads Amazon's current variation response before Request Product. An exact child that is absent or no longer orderable stops with `selected_variant_unavailable`; no other child is substituted, checkout is not opened, and the job is never retried. The search record supplies only the user's child-ASIN choice and display label—never historical enrollment or checkout metadata.

## Updating

Replace the files in this same folder, then click **Reload** on the browser extension card. Updating 25.0.3 to 25.0.4 this way retains the existing pairing and Amazon account binding and does not sign out of Amazon. Do not delete and re-add the folder unless necessary. If the extension ID/storage changes, revoke the old Hub pairing and pair the new installation.

## Removal

1. Revoke pairing in Hub Settings.
2. Remove the browser extension.
3. Run:

```powershell
.\windows\Remove-VineDropHubTunnelTask.ps1
```

## Troubleshooting

```powershell
Test-NetConnection 127.0.0.1 -Port 3001
Get-ScheduledTask -TaskName 'Vine Drop Hub SSH Tunnel'
Get-Content "$env:LOCALAPPDATA\VineDropHub\logs\ssh-tunnel.log" -Tail 40
```

- **Amazon session not ready:** open Amazon.ca Vine manually, complete sign-in/CAPTCHA, then refresh the companion session.
- **Re-pair required:** replace the original R25 pairing once; 25.0.4 will then learn the real browser-derived one-way hash.
- **Account mismatch:** the browser profile no longer matches the real Amazon.ca account learned by this pairing. Sign back into that account, or intentionally replace the pairing for a planned account change. Do not bypass the check.
- **Approval changed/expired:** the exact total changed or the job is no longer active; let the companion stop safely.
- **Ambiguous placement:** check Amazon Orders manually before any retry. The companion never blindly retries Place your order.
