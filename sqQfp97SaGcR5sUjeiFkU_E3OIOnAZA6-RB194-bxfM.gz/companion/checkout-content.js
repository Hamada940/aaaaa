(() => {
  'use strict';

  if (window.top !== window) return;

  const startedAt = Date.now();
  const PLACE_SELECTORS = [
    '#placeOrder',
    'input[name="placeYourOrder1"]',
    'input[data-testid="SPC_selectPlaceOrder"]',
    'input[data-csa-c-slot-id="checkout-place-your-order-button"]',
    '.place-your-order-button',
    '#submitOrderButtonId input.a-button-input',
    '#bottomSubmitOrderButtonId input.a-button-input',
    '#turbo-checkout-pyo-button input'
  ];
  const ADDRESS_SELECTORS = [
    'input[data-csa-c-slot-id="checkout-primary-continue-shipaddressselect"]',
    '[data-action="checkout-continue-button-click-action"] input[type="submit"]',
    '#checkout-primary-continue-button-id input[type="submit"]',
    'input[data-testid="bottom-continue-button"]'
  ];
  const PAYMENT_SELECTORS = [
    'input[name*="SetPaymentPlanSelectContinueEvent"]',
    '#checkout-primary-continue-button-id input[type="submit"]',
    'input[data-testid="secondary-continue-button"]',
    'input[data-csa-c-slot-id="checkout-secondary-continue-payselect"]'
  ];
  let inFlight = false;
  let rerun = false;
  let stopped = false;
  let placeAttempted = false;
  const clickedSteps = new Set();

  function isVisible(element) {
    if (!element || element.hidden || element.getAttribute('aria-hidden') === 'true') return false;
    if (element.classList.contains('a-hidden') || element.classList.contains('hidden')) return false;
    const style = getComputedStyle(element);
    return style.display !== 'none' && style.visibility !== 'hidden' && style.visibility !== 'collapse';
  }

  function firstVisible(selectors) {
    for (const selector of selectors) {
      for (const element of document.querySelectorAll(selector)) {
        if (!isVisible(element)) continue;
        if (element.disabled || element.getAttribute('aria-disabled') === 'true') continue;
        return element;
      }
    }
    return null;
  }

  function placeButton() {
    return firstVisible(PLACE_SELECTORS);
  }

  function disabled(element) {
    return !element || Boolean(
      element.disabled ||
      element.getAttribute('aria-disabled') === 'true' ||
      element.classList.contains('a-button-disabled') ||
      element.closest('.a-button-disabled')
    );
  }

  function totalCandidates() {
    const selectors = [
      ['ul#subtotals-marketplace-table li:last-child .order-summary-line-definition', 1],
      ['[data-testid="order-summary-grand-total"]', 2],
      ['#subtotals-marketplace-table .grand-total-price', 3],
      ['.grand-total .a-price .a-offscreen', 4],
      ['#order-summary-grand-total', 5]
    ];
    const output = [];
    for (const [selector, priority] of selectors) {
      for (const node of document.querySelectorAll(selector)) {
        const text = String(node.textContent || '').trim();
        if (text) output.push({ selector, priority, text: text.slice(0, 200) });
      }
      if (output.some(entry => entry.priority === priority)) break;
    }
    if (output.length) return output;

    const totalLabel = /^(?:order total|grand total|total(?: de la commande)?|total général)\s*:?$/i;
    let inspected = 0;
    for (const row of document.querySelectorAll('li, tr, .a-row, [data-testid*="total"]')) {
      if (++inspected > 800) break;
      const children = [...row.children];
      if (children.length < 2) continue;
      const label = String(children[0].textContent || '').replace(/\s+/g, ' ').trim();
      if (!totalLabel.test(label)) continue;
      const text = String(children.at(-1).textContent || '').replace(/\s+/g, ' ').trim();
      if (text) output.push({ selector: 'labelled-order-total', priority: 20, text: text.slice(0, 200) });
    }
    return output;
  }

  function fatalError() {
    const outOfStock = document.querySelector(
      'div[data-messageid="OfferListingUnavailableCvMessage"], div[data-messageid="ItemQuantityUnavailableCVMessage"]'
    );
    const vineError = document.querySelector('div[data-messageid="VineCVMessage"]');
    if (outOfStock || vineError) {
      return String((vineError || outOfStock).textContent || 'Amazon Vine could not process this order')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 300);
    }
    return '';
  }

  function snapshot() {
    const pathname = location.pathname;
    const place = placeButton();
    const bodyText = String(document.body?.innerText || '').slice(0, 100_000);
    const thankYou = pathname.includes('/gp/buy/thankyou/') || location.href.includes('/buy/thankyou');
    const addressPage = /\/checkout\/p\/p-[^/]+\/address(?:\/|$)/.test(pathname) ||
      Boolean(document.querySelector('input[data-csa-c-slot-id="checkout-primary-continue-shipaddressselect"]'));
    const paymentPage = !pathname.includes('/spc') && (
      /\/checkout\/p\/p-[^/]+\/(?:pay|payment)(?:\/|$)/.test(pathname) ||
      Boolean(firstVisible(PAYMENT_SELECTORS))
    );
    return {
      url: location.href,
      thankYou,
      orderId: thankYou ? new URL(location.href).searchParams.get('purchaseId') : null,
      login: /\/ap\/(?:signin|login)/i.test(pathname) || Boolean(document.querySelector('#ap_email, input[name="password"]')),
      captcha: /captcha|captchacharacters/i.test(bodyText),
      fatalError: fatalError(),
      addressPage,
      paymentPage,
      totalCandidates: totalCandidates(),
      placeButtonFound: Boolean(place),
      placeButtonDisabled: disabled(place),
      settled: Date.now() - startedAt >= 12_000
    };
  }

  function clickStep(kind, selectors) {
    const key = `${kind}:${location.pathname}`;
    if (clickedSteps.has(key)) return;
    const element = firstVisible(selectors);
    if (!element) return;
    clickedSteps.add(key);
    try {
      element.scrollIntoView({ block: 'center', inline: 'center' });
      element.click();
    } catch (_) {
      clickedSteps.delete(key);
    }
  }

  function placeSnapshotFingerprint(value) {
    return JSON.stringify({
      url: String(value?.url || ''),
      thankYou: value?.thankYou === true,
      login: value?.login === true,
      captcha: value?.captcha === true,
      fatalError: String(value?.fatalError || ''),
      addressPage: value?.addressPage === true,
      paymentPage: value?.paymentPage === true,
      totalCandidates: Array.isArray(value?.totalCandidates) ? value.totalCandidates : [],
      placeButtonFound: value?.placeButtonFound === true,
      placeButtonDisabled: value?.placeButtonDisabled === true
    });
  }

  async function act(response) {
    if (!response || stopped) return;
    if (response.action === 'stop' || response.action === 'done' || response.action === 'ignore') {
      stopped = true;
      observer.disconnect();
      return;
    }
    if (response.action === 'click_address') {
      clickStep('address', ADDRESS_SELECTORS);
      return;
    }
    if (response.action === 'click_payment') {
      const checked = document.querySelector('input[type="radio"][name*="instrumentRowSelection"]:checked');
      if (!checked) {
        const first = document.querySelector('input[type="radio"][name*="instrumentRowSelection"], .pmts-instrument-box input[type="radio"]');
        if (first && !first.disabled) {
          first.click();
          first.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
      clickStep('payment', PAYMENT_SELECTORS);
      return;
    }
    if (response.action !== 'place' || placeAttempted) return;

    const button = placeButton();
    if (!button || disabled(button)) return;
    const intentSnapshot = snapshot();
    const permission = await chrome.runtime.sendMessage({
      type: 'checkout_place_intent',
      token: response.token,
      snapshot: intentSnapshot
    });
    if (!permission?.click) {
      if (permission?.reevaluate) rerun = true;
      return;
    }
    placeAttempted = true;
    const finalSnapshot = snapshot();
    if (placeSnapshotFingerprint(finalSnapshot) !== placeSnapshotFingerprint(intentSnapshot)) {
      await chrome.runtime.sendMessage({ type: 'checkout_click_cancelled' });
      return;
    }
    try {
      const finalButton = placeButton();
      if (!finalButton || disabled(finalButton)) {
        await chrome.runtime.sendMessage({ type: 'checkout_click_cancelled' });
        return;
      }
      finalButton.scrollIntoView({ block: 'center', inline: 'center' });
      finalButton.focus();
      finalButton.click();
    } catch (_) {
      await chrome.runtime.sendMessage({ type: 'checkout_click_uncertain' });
    }
  }

  async function evaluate() {
    if (stopped) return;
    if (inFlight) {
      rerun = true;
      return;
    }
    inFlight = true;
    try {
      const response = await chrome.runtime.sendMessage({ type: 'checkout_snapshot', snapshot: snapshot() });
      await act(response);
    } catch (_) {
      // A service-worker restart is safe: the next DOM mutation or safety pass
      // asks again. Place your order is never clicked without a fresh permit.
    } finally {
      inFlight = false;
      if (rerun) {
        rerun = false;
        void evaluate();
      }
    }
  }

  const observer = new MutationObserver(() => void evaluate());
  observer.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true });
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type === 'approval_granted') void evaluate();
  });
  void evaluate();
  setTimeout(() => void evaluate(), 12_000);
})();
