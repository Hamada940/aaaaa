async function render() {
  const response = await chrome.runtime.sendMessage({ type: 'get_status' });
  const value = response?.status;
  if (!value) throw new Error(response?.error || 'Status unavailable');
  const hub = document.getElementById('hub');
  hub.textContent = value.authenticated ? 'Connected and authenticated' : value.enabled ? 'Connecting / unavailable' : 'Disabled';
  hub.className = value.authenticated ? 'good' : value.enabled ? 'warn' : 'bad';
  const amazon = document.getElementById('amazon');
  amazon.textContent = value.amazonSession?.ready ? `Ready · ${value.amazonSession.accountHashPreview}` : 'Not verified';
  amazon.className = value.amazonSession?.ready ? 'good' : 'bad';
  const job = document.getElementById('job');
  job.textContent = value.activeJob ? `${value.activeJob.state} · ${value.activeJob.asin}` : 'None';
  job.className = value.activeJob ? 'warn' : 'good';
  document.getElementById('error').textContent = value.lastError || '';
}
document.getElementById('options').addEventListener('click', () => chrome.runtime.openOptionsPage());
document.getElementById('reconnect').addEventListener('click', () => void (async () => {
  await chrome.runtime.sendMessage({ type: 'connect_now' });
  await render();
})());
void render().catch(error => { document.getElementById('error').textContent = error.message; });
