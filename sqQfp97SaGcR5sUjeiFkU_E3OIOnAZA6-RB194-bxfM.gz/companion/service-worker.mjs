import {
  ORDER_PROTOCOL_VERSION,
  PAIRING_SECRET_RE,
  normalizeAsin,
  randomNonce,
  signedEnvelope,
  verifyPayloadSignature,
  validateVariantLookupRequest,
  validateOrderJob
} from './src/protocol.mjs';
import {
  AMAZON_BASE_URL,
  AmazonFlowError,
  checkoutFormFields,
  fetchAmazonSessionContext,
  pageFailureCode,
  recommendationIdForJob,
  recommendationTypeForQueue,
  referrerForQueue,
  validateSeeDetailsResponse,
  validateVoiceOrderResponse,
  variationsFromResponse,
  amazonVariationChoices,
  variationCandidatesForPolicy
} from './src/amazon.mjs';
import { evaluateCheckoutPolicy, selectCheckoutTotal } from './src/checkout-policy.mjs';

const VERSION = chrome.runtime.getManifest().version;
const SETTINGS_KEY = 'companionSettings';
const PROCESSED_KEY = 'processedOrderJobs';
const PENDING_RESULTS_KEY = 'pendingOrderResults';
const ACTIVE_KEY = 'activeOrderJob';
const RELAY_PREFIX = 'checkoutRelay:';
const TAB_PREFIX = 'checkoutTab:';
const SESSION_MAX_AGE_MS = 10 * 60 * 1000;
const AMAZON_JSON_MAX_BYTES = 2 * 1024 * 1024;
const PROCESSED_LIMIT = 500;
const VARIANT_LOOKUP_REPLAY_LIMIT = 128;
const HEARTBEAT_MS = 20_000;
const TERMINAL_RESULT_STATES = new Set(['placed', 'rejected', 'failed', 'ambiguous', 'expired']);
const DEFAULT_SETTINGS = Object.freeze({
  enabled: false,
  hubPort: 3001,
  pairingSecret: '',
  agentId: '',
  amazonDomain: 'amazon.ca'
});

let settings = { ...DEFAULT_SETTINGS };
let socket = null;
let authenticated = false;
let authenticatedAccountHash = null;
let sessionContext = null;
let reconnectTimer = null;
let reconnectAttempt = 0;
let heartbeatTimer = null;
let connecting = false;
let lastError = null;
let connectedAtMs = null;
let lastSeenAtMs = null;
let activeJob = null;
let variantLookupInFlight = false;
const seenVariantLookupRequests = new Map();
let approvalWindowId = null;
let initializationPromise = null;

async function initializeWorker() {
  await loadSettings();
  await restoreActiveJob();
  if (settings.enabled) void connect();
}

function ensureInitialized() {
  if (!initializationPromise) {
    initializationPromise = initializeWorker().catch(error => {
      lastError = bounded(error?.message || error, 240);
      throw error;
    });
  }
  return initializationPromise;
}

function bounded(value, maximum = 500) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maximum);
}

const VARIANT_LOOKUP_FAILURES = Object.freeze({
  variant_lookup_request_invalid: 'The signed Amazon variant lookup request was invalid',
  variant_lookup_replayed: 'This one-time Amazon variant lookup request was already accepted',
  agent_busy: 'The PC companion is busy; no Amazon variant lookup was attempted',
  variant_lookup_timeout: 'The one-time Amazon variant lookup expired; no retry or order action was attempted',
  amazon_account_changed: 'The active Amazon account no longer matches this pairing',
  amazon_login_required: 'Sign in to Amazon.ca in this browser profile before loading variants',
  amazon_captcha: 'Complete Amazon verification manually in this browser profile before loading variants',
  amazon_error_page: 'Amazon returned an error page; open Amazon.ca manually before loading variants',
  session_page_invalid: 'The local Amazon Vine session page was invalid',
  amazon_network_error: 'The local Amazon Vine session could not be loaded',
  amazon_http_error: 'Amazon Vine did not return a successful response',
  amazon_session_context_missing: 'Amazon Vine did not expose the required local session context',
  metadata_incomplete: 'The signed lookup lacks valid Vine recommendation metadata',
  account_context_missing: 'The local Amazon account context is unavailable',
  queue_invalid: 'The Vine queue is unsupported for this lookup',
  item_not_in_enrollment: 'Amazon Vine no longer lists this item in the enrollment',
  recommendations_error: 'Amazon Vine could not return recommendation details for this item',
  amazon_variants_invalid: 'Amazon Vine returned an invalid variations response',
  amazon_response_too_large: 'Amazon Vine returned an oversized response',
  amazon_invalid_json: 'Amazon Vine did not return valid JSON',
  amazon_variant_lookup_failed: 'Amazon variant lookup failed without placing or preparing an order'
});

function normalizeVariantLookupFailure(value) {
  const requested = String(value || '').trim();
  const code = Object.prototype.hasOwnProperty.call(VARIANT_LOOKUP_FAILURES, requested)
    ? requested
    : 'amazon_variant_lookup_failed';
  return Object.freeze({ code, message: VARIANT_LOOKUP_FAILURES[code] });
}

function normalizeSettings(raw = {}) {
  const port = Math.trunc(Number(raw.hubPort));
  const pairingSecret = String(raw.pairingSecret || '').trim();
  return {
    enabled: raw.enabled === true,
    hubPort: Number.isInteger(port) && port >= 1024 && port <= 65535 ? port : 3001,
    pairingSecret: PAIRING_SECRET_RE.test(pairingSecret) ? pairingSecret : '',
    agentId: /^[A-Za-z0-9._:-]{8,120}$/.test(String(raw.agentId || ''))
      ? String(raw.agentId)
      : crypto.randomUUID(),
    amazonDomain: 'amazon.ca'
  };
}

async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  settings = normalizeSettings(stored[SETTINGS_KEY]);
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  return settings;
}

async function saveSettings(patch = {}) {
  settings = normalizeSettings({ ...settings, ...patch });
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  return settings;
}

function hubSocketUrl() {
  return `ws://127.0.0.1:${settings.hubPort}/ws-feed?role=order-agent`;
}

function safeSocketSend(value) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  try {
    socket.send(JSON.stringify(value));
    return true;
  } catch (_) {
    return false;
  }
}

function clearHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

function scheduleReconnect() {
  if (reconnectTimer || !settings.enabled || !settings.pairingSecret) return;
  const delays = [1000, 2000, 5000, 10_000, 20_000, 30_000];
  const delay = delays[Math.min(reconnectAttempt, delays.length - 1)];
  reconnectAttempt += 1;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    void connect();
  }, delay);
}

async function publicStatus() {
  const current = activeJob || (await chrome.storage.session.get(ACTIVE_KEY))[ACTIVE_KEY] || null;
  return {
    version: VERSION,
    enabled: settings.enabled,
    configured: Boolean(settings.pairingSecret),
    hubPort: settings.hubPort,
    socketConnected: socket?.readyState === WebSocket.OPEN,
    authenticated,
    connectedAt: connectedAtMs ? new Date(connectedAtMs).toISOString() : null,
    lastSeenAt: lastSeenAtMs ? new Date(lastSeenAtMs).toISOString() : null,
    lastError,
    amazonSession: sessionContext
      ? {
          ready: true,
          accountHashPreview: `${sessionContext.accountHash.slice(0, 8)}…${sessionContext.accountHash.slice(-6)}`,
          refreshedAt: new Date(sessionContext.refreshedAtMs).toISOString(),
          domain: sessionContext.domain
        }
      : { ready: false, domain: 'amazon.ca' },
    activeJob: current
      ? {
          jobId: current.job?.jobId || null,
          asin: current.job?.item?.asin || null,
          title: current.job?.item?.title || null,
          state: current.state || null,
          finalTotal: current.finalTotal ?? null,
          currency: current.currency || null
        }
      : null
  };
}

async function broadcastStatus() {
  try {
    await chrome.runtime.sendMessage({ type: 'companion_status', status: await publicStatus() });
  } catch (_) {}
  try {
    const status = await publicStatus();
    await chrome.action.setBadgeText({ text: status.authenticated ? 'ON' : status.enabled ? '…' : '' });
    await chrome.action.setBadgeBackgroundColor({ color: status.authenticated ? '#15803d' : '#b45309' });
  } catch (_) {}
}

async function refreshAmazonSession({ force = false, signal = null } = {}) {
  if (!force && sessionContext && Date.now() - sessionContext.refreshedAtMs < SESSION_MAX_AGE_MS) {
    return sessionContext;
  }
  const sessionFetch = signal
    ? (input, init = {}) => fetch(input, { ...init, signal })
    : fetch;
  sessionContext = await fetchAmazonSessionContext(sessionFetch);
  await broadcastStatus();
  return sessionContext;
}

async function sendProtocol(type, payload) {
  if (!settings.pairingSecret) return false;
  return safeSocketSend(await signedEnvelope(settings.pairingSecret, type, payload));
}

async function queuePendingResult(jobId, result) {
  const stored = await chrome.storage.local.get(PENDING_RESULTS_KEY);
  const values = Array.isArray(stored[PENDING_RESULTS_KEY]) ? stored[PENDING_RESULTS_KEY] : [];
  const filtered = values.filter(entry => entry?.jobId !== jobId);
  filtered.push({ jobId, result, queuedAtMs: Date.now() });
  await chrome.storage.local.set({ [PENDING_RESULTS_KEY]: filtered.slice(-100) });
}

async function acknowledgePendingResult(jobId, state) {
  const stored = await chrome.storage.local.get(PENDING_RESULTS_KEY);
  const values = Array.isArray(stored[PENDING_RESULTS_KEY]) ? stored[PENDING_RESULTS_KEY] : [];
  const remaining = values.filter(entry => !(entry?.jobId === jobId && entry?.result?.state === state));
  if (remaining.length !== values.length) {
    await chrome.storage.local.set({ [PENDING_RESULTS_KEY]: remaining });
  }
}

async function flushPendingResults() {
  if (!authenticated) return;
  const stored = await chrome.storage.local.get(PENDING_RESULTS_KEY);
  const values = Array.isArray(stored[PENDING_RESULTS_KEY]) ? stored[PENDING_RESULTS_KEY] : [];
  const retained = values.filter(entry =>
    /^[A-Za-z0-9._:-]{8,80}$/.test(String(entry?.jobId || '')) &&
    TERMINAL_RESULT_STATES.has(String(entry?.result?.state || ''))
  ).slice(-100);
  // Persist pruning before sends so an acknowledgement racing this recovery
  // pass cannot be overwritten by a stale full-list write afterward.
  await chrome.storage.local.set({ [PENDING_RESULTS_KEY]: retained });
  for (const entry of retained) {
    await sendProtocol('agent_result', {
      ...entry.result,
      nonce: randomNonce('result'),
      eventAtMs: Date.now()
    });
  }
}

async function sendResult(job, state, extras = {}) {
  const payload = {
    jobId: job.jobId,
    state,
    nonce: randomNonce('result'),
    eventAtMs: Date.now(),
    asin: job.item.asin,
    variantAsin: extras.variantAsin || null,
    finalTotal: extras.finalTotal ?? null,
    currency: extras.currency || null,
    reasonCode: extras.reasonCode || null,
    message: bounded(extras.message, 500) || null,
    amazonOrderId: extras.amazonOrderId || null,
    timings: extras.timings || {}
  };
  const durableResult = { ...payload, nonce: undefined, eventAtMs: undefined };
  if (TERMINAL_RESULT_STATES.has(state)) {
    // A successful WebSocket write is not delivery acknowledgement. Retain
    // terminal outcomes locally until the VPS signs an agent_result_ack.
    await queuePendingResult(job.jobId, durableResult);
  }
  await sendProtocol('agent_result', payload);
}

async function processedJobs() {
  const stored = await chrome.storage.local.get(PROCESSED_KEY);
  return Array.isArray(stored[PROCESSED_KEY]) ? stored[PROCESSED_KEY] : [];
}

async function rememberProcessedJob(jobId) {
  const values = (await processedJobs()).filter(entry => entry?.jobId !== jobId);
  values.push({ jobId, acceptedAtMs: Date.now() });
  await chrome.storage.local.set({ [PROCESSED_KEY]: values.slice(-PROCESSED_LIMIT) });
}

async function hasProcessedJob(jobId) {
  return (await processedJobs()).some(entry => entry?.jobId === jobId);
}

async function connect() {
  if (connecting || socket?.readyState === WebSocket.OPEN || socket?.readyState === WebSocket.CONNECTING) return;
  if (!settings.enabled || !settings.pairingSecret) {
    lastError = settings.enabled ? 'Enter the Hub pairing secret in Companion options.' : null;
    await broadcastStatus();
    return;
  }
  connecting = true;
  authenticated = false;
  authenticatedAccountHash = null;
  lastError = null;
  await broadcastStatus();
  try {
    const ws = new WebSocket(hubSocketUrl());
    socket = ws;
    ws.addEventListener('open', () => {
      reconnectAttempt = 0;
      lastError = null;
      void broadcastStatus();
    });
    ws.addEventListener('message', event => void handleSocketMessage(ws, event.data).catch(error => {
      lastError = bounded(error?.message || error, 240);
      try { ws.close(4104, 'Companion session validation failed'); } catch (_) {}
      void broadcastStatus();
    }));
    ws.addEventListener('error', () => {
      lastError = 'Could not reach the SSH-forwarded Vine Drop Hub port on this PC.';
      void broadcastStatus();
    });
    ws.addEventListener('close', event => {
      if (socket === ws) socket = null;
      authenticated = false;
      authenticatedAccountHash = null;
      clearHeartbeat();
      if (event.code && event.code !== 1000) lastError = bounded(event.reason || `Hub connection closed (${event.code})`, 240);
      void broadcastStatus();
      scheduleReconnect();
    });
  } catch (error) {
    lastError = bounded(error?.message || error, 240);
    authenticated = false;
    authenticatedAccountHash = null;
    await broadcastStatus();
    scheduleReconnect();
  } finally {
    connecting = false;
  }
}

function disconnect({ reconnect = false } = {}) {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = null;
  clearHeartbeat();
  const current = socket;
  socket = null;
  authenticated = false;
  authenticatedAccountHash = null;
  try { current?.close(1000, 'Companion disconnected'); } catch (_) {}
  if (reconnect) scheduleReconnect();
  void broadcastStatus();
}

async function handleSocketMessage(ws, raw) {
  if (ws !== socket) return;
  let envelope;
  try {
    if (typeof raw !== 'string' || raw.length > 256 * 1024) throw new Error('invalid message size');
    envelope = JSON.parse(raw);
  } catch (_) {
    lastError = 'Hub sent an invalid protocol message.';
    ws.close(4100, 'Invalid server message');
    return;
  }
  const type = String(envelope?.type || '');
  const payload = envelope?.payload;

  if (type === 'agent_challenge') {
    if (payload?.protocolVersion !== ORDER_PROTOCOL_VERSION || !/^[A-Za-z0-9_-]{20,100}$/.test(String(payload?.challenge || ''))) {
      ws.close(4101, 'Invalid server challenge');
      return;
    }
    const session = await refreshAmazonSession();
    await sendProtocol('agent_hello', {
      challenge: payload.challenge,
      timestampMs: Date.now(),
      nonce: randomNonce('hello'),
      accountHash: session.accountHash,
      agentId: settings.agentId,
      agentVersion: VERSION,
      capabilities: {
        fastCheckout: true,
        localApproval: true,
        firstAvailableVariant: true,
        exactVariantSelection: true,
        readOnlyAmazonVariantLookup: true,
        currency: 'CAD'
      }
    });
    return;
  }

  if (!settings.pairingSecret || !(await verifyPayloadSignature(settings.pairingSecret, type, payload, envelope?.signature))) {
    lastError = 'Hub message signature verification failed.';
    ws.close(4102, 'Invalid server signature');
    return;
  }
  lastSeenAtMs = Date.now();

  if (type === 'agent_ready') {
    if (payload?.protocolVersion !== ORDER_PROTOCOL_VERSION || payload?.expectedAccountHash !== sessionContext?.accountHash) {
      lastError = 'Hub and local Amazon account binding did not match.';
      ws.close(4103, 'Account binding mismatch');
      return;
    }
    authenticatedAccountHash = sessionContext.accountHash;
    authenticated = true;
    connectedAtMs = Date.now();
    lastError = null;
    clearHeartbeat();
    heartbeatTimer = setInterval(() => {
      if (authenticated) void sendProtocol('agent_heartbeat', { nonce: randomNonce('heartbeat'), timestampMs: Date.now() });
    }, HEARTBEAT_MS);
    await flushPendingResults();
    await broadcastStatus();
    return;
  }

  if (type === 'agent_result_ack') {
    const jobId = String(payload?.jobId || '');
    const state = String(payload?.state || '');
    if (/^[A-Za-z0-9._:-]{8,80}$/.test(jobId) && TERMINAL_RESULT_STATES.has(state)) {
      await acknowledgePendingResult(jobId, state);
    }
    return;
  }
  if (type === 'server_heartbeat') return;
  if (type === 'variant_lookup_request' && authenticated) {
    await handleVariantLookupRequest(payload);
    return;
  }
  if (type === 'order_job' && authenticated) await acceptOrderJob(payload);
}

function pruneVariantLookupReplays(now = Date.now()) {
  for (const [lookupId, expiresAtMs] of seenVariantLookupRequests.entries()) {
    if (!Number.isFinite(expiresAtMs) || expiresAtMs <= now) seenVariantLookupRequests.delete(lookupId);
  }
  while (seenVariantLookupRequests.size > VARIANT_LOOKUP_REPLAY_LIMIT) {
    seenVariantLookupRequests.delete(seenVariantLookupRequests.keys().next().value);
  }
}

async function sendVariantLookupResult(request, {
  success,
  variants = [],
  discardedVariants = 0,
  errorCode = null
} = {}) {
  const failure = success === true ? null : normalizeVariantLookupFailure(errorCode);
  return sendProtocol('variant_lookup_result', {
    protocolVersion: ORDER_PROTOCOL_VERSION,
    lookupId: request.lookupId,
    requestNonce: request.nonce,
    nonce: randomNonce('variant-result'),
    eventAtMs: Date.now(),
    parentAsin: request.item.asin,
    source: 'amazon_companion',
    success: success === true,
    persisted: false,
    orderAttempted: false,
    variants: success === true ? variants : [],
    discardedVariants: success === true ? discardedVariants : 0,
    errorCode: failure?.code || null,
    message: failure?.message || null
  });
}

async function handleVariantLookupRequest(rawPayload) {
  let request;
  try {
    request = validateVariantLookupRequest(rawPayload, { now: Date.now() });
  } catch (error) {
    const lookupId = String(rawPayload?.lookupId || '');
    const requestNonce = String(rawPayload?.nonce || '');
    const asin = normalizeAsin(rawPayload?.item?.asin);
    if (
      /^[A-Za-z0-9._:-]{12,120}$/.test(lookupId) &&
      /^[A-Za-z0-9._:-]{12,160}$/.test(requestNonce) &&
      /^[A-Z0-9]{10}$/.test(asin)
    ) {
      await sendVariantLookupResult({ lookupId, nonce: requestNonce, item: { asin } }, {
        success: false,
        errorCode: 'variant_lookup_request_invalid',
        message: error?.message || 'Amazon variant lookup request was invalid'
      });
    }
    return;
  }

  const now = Date.now();
  pruneVariantLookupReplays(now);
  if (seenVariantLookupRequests.has(request.lookupId)) {
    await sendVariantLookupResult(request, {
      success: false,
      errorCode: 'variant_lookup_replayed',
      message: 'This one-time Amazon variant lookup request was already accepted'
    });
    return;
  }
  seenVariantLookupRequests.set(request.lookupId, request.expiresAtMs + 10 * 60 * 1000);
  pruneVariantLookupReplays(now);

  if (variantLookupInFlight || activeJob) {
    await sendVariantLookupResult(request, {
      success: false,
      errorCode: 'agent_busy',
      message: activeJob
        ? 'The PC companion is handling an order job; no variant lookup was attempted'
        : 'Another Amazon variant lookup is already in progress'
    });
    return;
  }

  variantLookupInFlight = true;
  const lookupController = new AbortController();
  const lookupTimer = setTimeout(
    () => lookupController.abort(),
    Math.max(1, request.expiresAtMs - Date.now())
  );
  try {
    // This read-only path performs only a local-session refresh and one GET of
    // Amazon's recommendation variations. It never calls voiceOrders, See
    // Details, checkout, Place Order, or any retry/fallback source.
    const session = await refreshAmazonSession({ force: true, signal: lookupController.signal });
    if (!authenticatedAccountHash || session.accountHash !== authenticatedAccountHash) {
      throw new AmazonFlowError('amazon_account_changed', 'The active Amazon account no longer matches this pairing');
    }
    const recommendationId = recommendationIdForJob({ item: request.item }, session);
    const encoded = encodeURIComponent(recommendationId);
    const payload = await amazonGetJson(
      `${AMAZON_BASE_URL}/vine/api/recommendations/${encoded}`,
      referrerForQueue(request.item.queue),
      'Vine variation lookup',
      { signal: lookupController.signal }
    );
    const sanitized = amazonVariationChoices(payload, {
      parentAsin: request.item.asin,
      limit: 100
    });
    await sendVariantLookupResult(request, {
      success: true,
      variants: [...sanitized.variants],
      discardedVariants: sanitized.discardedVariants
    });
  } catch (error) {
    const expired = error?.name === 'AbortError' || Date.now() >= request.expiresAtMs;
    await sendVariantLookupResult(request, {
      success: false,
      errorCode: expired ? 'variant_lookup_timeout' : error?.code || 'amazon_variant_lookup_failed',
      message: expired
        ? 'The one-time Amazon variant lookup expired; no retry or order action was attempted'
        : error?.message || 'Amazon variant lookup failed'
    });
    if (error?.code === 'amazon_account_changed') disconnect({ reconnect: true });
  } finally {
    clearTimeout(lookupTimer);
    variantLookupInFlight = false;
  }
}

async function acceptOrderJob(rawPayload) {
  let job;
  try {
    job = validateOrderJob(rawPayload, { now: Date.now() });
  } catch (error) {
    const jobId = String(rawPayload?.jobId || '');
    const asin = normalizeAsin(rawPayload?.item?.asin);
    if (/^[A-Za-z0-9._:-]{8,80}$/.test(jobId) && asin) {
      const minimal = { jobId, item: { asin } };
      await sendResult(minimal, Date.now() > Number(rawPayload?.expiresAtMs) ? 'expired' : 'failed', {
        reasonCode: Date.now() > Number(rawPayload?.expiresAtMs) ? 'job_expired' : 'job_invalid',
        message: error.message
      });
    }
    return;
  }
  if (await hasProcessedJob(job.jobId)) {
    await sendResult(job, 'failed', { reasonCode: 'duplicate_job', message: 'This one-time order job was already accepted by the PC' });
    return;
  }
  await rememberProcessedJob(job.jobId);
  await sendResult(job, 'received', {
    timings: { ...job.timings, agentReceivedAtMs: Date.now() }
  });

  const recovered = activeJob || (await chrome.storage.session.get(ACTIVE_KEY))[ACTIVE_KEY];
  if (recovered) {
    await sendResult(job, 'failed', { reasonCode: 'agent_busy', message: 'The PC companion is already handling another order job' });
    return;
  }

  activeJob = {
    job,
    state: 'evaluating',
    createdAtMs: Date.now(),
    timings: { ...job.timings, agentReceivedAtMs: Date.now() },
    submissionStarted: false,
    approval: null,
    approvalPrompted: false,
    finalTotal: null,
    currency: null,
    variantAsin: null,
    tabId: null
  };
  await persistActiveJob();
  await sendResult(job, 'evaluating', { timings: activeJob.timings });
  await broadcastStatus();
  void executeOrderJob(activeJob).catch(error => handleOrderExecutionFailure(error));
}

async function persistActiveJob() {
  if (!activeJob) {
    await chrome.storage.session.remove(ACTIVE_KEY);
    return;
  }
  await chrome.storage.session.set({ [ACTIVE_KEY]: activeJob });
}

async function readBoundedJsonResponse(response, operation) {
  const failureUrl = pageFailureCode('', response.url);
  if (failureUrl) throw new AmazonFlowError(failureUrl, 'Amazon redirected the local session to sign-in or verification');
  const length = Number(response.headers.get('content-length'));
  if (Number.isFinite(length) && length > AMAZON_JSON_MAX_BYTES) {
    throw new AmazonFlowError('amazon_response_too_large', `${operation} response was too large`);
  }
  const text = await response.text();
  if (new TextEncoder().encode(text).byteLength > AMAZON_JSON_MAX_BYTES) {
    throw new AmazonFlowError('amazon_response_too_large', `${operation} response was too large`);
  }
  const pageFailure = pageFailureCode(text, response.url);
  if (pageFailure) throw new AmazonFlowError(pageFailure, `Amazon interrupted ${operation} with sign-in or verification`);
  let payload;
  try { payload = JSON.parse(text); } catch (_) {
    throw new AmazonFlowError('amazon_invalid_json', `${operation} did not return valid JSON`);
  }
  if (!response.ok && response.status !== 403) {
    throw new AmazonFlowError('amazon_http_error', `${operation} returned HTTP ${response.status}`);
  }
  return payload;
}

async function amazonGetJson(url, _referrer, operation = 'Vine See Details', { signal = null } = {}) {
  const response = await fetch(url, {
    method: 'GET',
    credentials: 'include',
    cache: 'no-store',
    redirect: 'follow',
    headers: { accept: '*/*', 'accept-language': 'en-CA,en;q=0.9' },
    referrerPolicy: 'no-referrer',
    ...(signal ? { signal } : {})
  });
  return readBoundedJsonResponse(response, operation);
}

async function amazonVoiceOrder(asin, recommendationId, queue, csrfRetried = false) {
  const body = {
    recommendationId,
    recommendationType: recommendationTypeForQueue(queue),
    itemAsin: asin
  };
  const response = await fetch(`${AMAZON_BASE_URL}/vine/api/voiceOrders`, {
    method: 'POST',
    mode: 'cors',
    credentials: 'include',
    cache: 'no-store',
    redirect: 'follow',
    headers: {
      accept: '*/*',
      'accept-language': 'en-CA,en;q=0.9',
      'cache-control': 'max-age=0',
      'content-type': 'application/json',
      'anti-csrftoken-a2z': sessionContext.csrfToken
    },
    body: JSON.stringify(body),
    referrerPolicy: 'no-referrer'
  });
  if (response.status === 403 && !csrfRetried) {
    await refreshAmazonSession({ force: true });
    if (!authenticatedAccountHash || sessionContext.accountHash !== authenticatedAccountHash) {
      throw new AmazonFlowError('amazon_account_changed', 'The Amazon account changed after the signed job was accepted');
    }
    return amazonVoiceOrder(asin, recommendationId, queue, true);
  }
  return readBoundedJsonResponse(response, 'Vine Request Product');
}

async function fetchCheckoutMetadata(asin, recommendationId, queue) {
  const encoded = encodeURIComponent(recommendationId);
  const referrer = referrerForQueue(queue);
  const detailsUrl = `${AMAZON_BASE_URL}/vine/api/recommendations/${encoded}/item/${asin}?imageSize=180`;

  // Preserve Amazon Vine's actual order path. Request Product is not issued
  // until See Details has returned valid metadata for this exact candidate.
  const detailsPayload = await amazonGetJson(detailsUrl, referrer);
  const details = validateSeeDetailsResponse(detailsPayload, asin);
  const voicePayload = await amazonVoiceOrder(asin, recommendationId, queue);
  const voice = validateVoiceOrderResponse(voicePayload, asin);
  return { details, voice };
}

async function executeOrderJob(record) {
  const { job } = record;
  // Re-read the local Vine identity for every accepted job. Compare it with the
  // immutable hash authenticated by this socket handshake, not with a mutable
  // session cache that a manual refresh can replace after an account switch.
  const session = await refreshAmazonSession({ force: true });
  if (!authenticatedAccountHash || session.accountHash !== authenticatedAccountHash) {
    throw new AmazonFlowError('amazon_account_changed', 'The active Amazon account no longer matches this pairing');
  }
  let recommendationId = recommendationIdForJob(job, session);
  const exactVariantAsin = job.policy.variantPolicy === 'exact'
    ? job.policy.selectedVariantAsin
    : null;
  if (exactVariantAsin) {
    // Record the signed requested child before any Amazon lookup so a safe
    // unavailable result still carries the exact attempted variant.
    activeJob.variantAsin = exactVariantAsin;
    await persistActiveJob();
  }
  let candidateAsins = [job.item.asin];
  if (job.item.isParentAsin || exactVariantAsin) {
    const encoded = encodeURIComponent(recommendationId);
    const payload = await amazonGetJson(
      `${AMAZON_BASE_URL}/vine/api/recommendations/${encoded}`,
      referrerForQueue(job.item.queue)
    );
    let variations;
    try {
      variations = variationsFromResponse(payload);
    } catch (error) {
      if (exactVariantAsin && error?.code === 'item_not_in_enrollment') {
        throw new AmazonFlowError(
          'selected_variant_unavailable',
          `Selected variant ${exactVariantAsin} is no longer offered for this AFA/AI item`
        );
      }
      throw error;
    }
    if (variations.recommendationId) recommendationId = variations.recommendationId;
    candidateAsins = variationCandidatesForPolicy(variations, job.policy);
  }

  let selected = null;
  let lastUnavailable = null;
  for (const candidateAsin of candidateAsins.slice(0, 50)) {
    try {
      const metadata = await fetchCheckoutMetadata(candidateAsin, recommendationId, job.item.queue);
      selected = { asin: candidateAsin, ...metadata };
      break;
    } catch (error) {
      if (error?.code === 'item_not_in_enrollment') {
        if (exactVariantAsin) {
          throw new AmazonFlowError(
            'selected_variant_unavailable',
            `Selected variant ${exactVariantAsin} is no longer orderable for this AFA/AI item`
          );
        }
        lastUnavailable = error;
        continue;
      }
      throw error;
    }
  }
  if (!selected) {
    if (exactVariantAsin) {
      throw new AmazonFlowError(
        'selected_variant_unavailable',
        `Selected variant ${exactVariantAsin} is no longer orderable for this AFA/AI item`
      );
    }
    throw lastUnavailable || new AmazonFlowError('no_available_variant', 'No currently available variation could be requested');
  }
  if (activeJob?.job?.jobId !== job.jobId) return;

  activeJob.variantAsin = exactVariantAsin || (selected.asin === job.item.asin ? null : selected.asin);
  activeJob.timings.detailsCompletedAtMs = Date.now();
  activeJob.state = 'opening_checkout';
  const relay = checkoutFormFields({
    asin: selected.asin,
    offerListingId: selected.voice.offerListingId,
    promotionId: selected.details.promotionId,
    purchasePolicyCode: selected.details.purchasePolicyCode
  });
  await persistActiveJob();
  await openCheckoutRelay(job.jobId, relay, job.policy.manualDashboardApproval === true);
}

async function openCheckoutRelay(jobId, relay, active) {
  const tab = await chrome.tabs.create({ url: 'about:blank', active });
  if (!Number.isInteger(tab.id)) throw new Error('Chrome did not create a checkout tab');
  activeJob.tabId = tab.id;
  await chrome.storage.session.set({
    [`${RELAY_PREFIX}${jobId}`]: relay,
    [`${TAB_PREFIX}${tab.id}`]: jobId,
    [ACTIVE_KEY]: activeJob
  });
  await chrome.tabs.update(tab.id, { url: chrome.runtime.getURL(`checkout.html?job=${encodeURIComponent(jobId)}`) });
}

function activeForSender(sender) {
  const tabId = sender?.tab?.id;
  return Number.isInteger(tabId) && activeJob?.tabId === tabId ? activeJob : null;
}

async function restoreActiveJob() {
  const stored = await chrome.storage.session.get(ACTIVE_KEY);
  activeJob = stored[ACTIVE_KEY] || null;
}

async function failActiveJob(error, fallbackCode = 'order_failed') {
  if (!activeJob) return;
  const record = activeJob;
  const code = bounded(error?.code || fallbackCode, 80) || fallbackCode;
  const message = bounded(error?.message || error || 'Order job failed', 500);
  await sendResult(record.job, 'failed', {
    variantAsin: record.variantAsin,
    finalTotal: record.finalTotal,
    currency: record.currency,
    reasonCode: code,
    message,
    timings: record.timings
  });
  await cleanupActiveJob({ closeCheckout: false });
  lastError = message;
  await broadcastStatus();
}

async function handleOrderExecutionFailure(error) {
  await failActiveJob(error);
  if (error?.code === 'amazon_account_changed') {
    // Do not leave a socket authenticated to the old browser identity. The
    // reconnect presents the newly observed hash and the Hub rejects it unless
    // the user explicitly replaces the pairing for an intentional change.
    disconnect({ reconnect: true });
  }
}

async function cleanupActiveJob({ closeCheckout = false } = {}) {
  const record = activeJob;
  activeJob = null;
  const removals = [ACTIVE_KEY];
  if (record?.job?.jobId) removals.push(`${RELAY_PREFIX}${record.job.jobId}`);
  if (Number.isInteger(record?.tabId)) removals.push(`${TAB_PREFIX}${record.tabId}`);
  await chrome.storage.session.remove(removals);
  if (closeCheckout && Number.isInteger(record?.tabId)) {
    try { await chrome.tabs.remove(record.tabId); } catch (_) {}
  }
  if (approvalWindowId !== null) {
    try { await chrome.windows.remove(approvalWindowId); } catch (_) {}
    approvalWindowId = null;
  }
  await broadcastStatus();
}

async function openApproval(record, decision) {
  const totalChanged = !record.approvalPrompted ||
    Number(record.approvalPrompted.total) !== Number(decision.total) ||
    record.approvalPrompted.currency !== decision.currency;
  if (totalChanged) {
    record.approvalPrompted = {
      approvalId: randomNonce('approval'),
      total: decision.total,
      currency: decision.currency,
      reasonCode: decision.reasonCode,
      promptedAtMs: Date.now()
    };
    record.state = 'approval_required';
    await persistActiveJob();
    await sendResult(record.job, 'approval_required', {
      variantAsin: record.variantAsin,
      finalTotal: decision.total,
      currency: decision.currency,
      reasonCode: decision.reasonCode,
      message: decision.message,
      timings: record.timings
    });
  }
  if (approvalWindowId !== null && totalChanged) {
    // Never leave a stale amount visible. The approval ID below also rejects a
    // click racing this close/reopen boundary.
    try { await chrome.windows.remove(approvalWindowId); } catch (_) {}
    approvalWindowId = null;
  } else if (approvalWindowId !== null) {
    try { await chrome.windows.update(approvalWindowId, { focused: true }); return; } catch (_) { approvalWindowId = null; }
  }
  const created = await chrome.windows.create({
    url: chrome.runtime.getURL(`approval.html?job=${encodeURIComponent(record.job.jobId)}`),
    type: 'popup',
    width: 520,
    height: 650,
    focused: true
  });
  approvalWindowId = created.id ?? null;
}

async function handleCheckoutSnapshot(message, sender) {
  const record = activeForSender(sender);
  if (!record) return { action: 'ignore' };
  const snapshot = message?.snapshot && typeof message.snapshot === 'object' ? message.snapshot : {};
  const url = String(snapshot.url || sender.tab.url || '');
  let parsed;
  try { parsed = new URL(url); } catch (_) { return { action: 'fail', message: 'Invalid Amazon checkout URL' }; }
  if (parsed.origin !== 'https://www.amazon.ca' || parsed.username || parsed.password) {
    await failActiveJob(new AmazonFlowError('checkout_origin_invalid', 'Checkout left the allowed Amazon.ca origin'));
    return { action: 'stop' };
  }

  if (snapshot.login || snapshot.captcha) {
    await failActiveJob(new AmazonFlowError(snapshot.captcha ? 'amazon_captcha' : 'amazon_login_required', 'Amazon requires manual sign-in or CAPTCHA'));
    return { action: 'stop' };
  }
  if (snapshot.thankYou) {
    const orderId = String(parsed.searchParams.get('purchaseId') || snapshot.orderId || '').slice(0, 160);
    if (!orderId) {
      await completeAmbiguous('Amazon reached a confirmation page without a verifiable order ID');
      return { action: 'stop' };
    }
    record.timings.confirmedAtMs = Date.now();
    await sendResult(record.job, 'placed', {
      variantAsin: record.variantAsin,
      finalTotal: record.finalTotal,
      currency: record.currency,
      amazonOrderId: orderId,
      timings: record.timings
    });
    await cleanupActiveJob({ closeCheckout: false });
    return { action: 'done' };
  }
  if (snapshot.fatalError) {
    await failActiveJob(new AmazonFlowError('amazon_checkout_error', bounded(snapshot.fatalError, 300)));
    return { action: 'stop' };
  }
  if (snapshot.addressPage) return { action: 'click_address' };
  if (snapshot.paymentPage) return { action: 'click_payment' };

  const total = selectCheckoutTotal(snapshot.totalCandidates, record.job.policy.currency);
  if (!total.ok) {
    if (snapshot.settled === true) {
      await failActiveJob(new AmazonFlowError(total.reasonCode, total.message));
      return { action: 'stop' };
    }
    return { action: 'wait' };
  }
  record.finalTotal = total.amount;
  record.currency = total.currency;
  record.timings.checkoutLoadedAtMs ||= Date.now();
  await persistActiveJob();

  const decision = evaluateCheckoutPolicy({
    total: total.amount,
    currency: total.currency,
    expectedCurrency: record.job.policy.currency,
    unattendedCheckoutLimit: record.job.policy.unattendedCheckoutLimit,
    mode: record.job.policy.mode,
    localApproval: record.approval
  });
  if (decision.action === 'fail') {
    await failActiveJob(new AmazonFlowError(decision.reasonCode, decision.message));
    return { action: 'stop' };
  }
  if (decision.action === 'approval') {
    await openApproval(record, decision);
    return { action: 'wait_for_approval' };
  }
  if (!snapshot.placeButtonFound || snapshot.placeButtonDisabled) {
    if (snapshot.settled === true) {
      await failActiveJob(new AmazonFlowError('place_order_unavailable', 'Amazon Place your order was not available'));
      return { action: 'stop' };
    }
    return { action: 'wait' };
  }
  if (record.submissionStarted) return { action: 'wait' };
  record.placeToken = randomNonce('place');
  await persistActiveJob();
  return { action: 'place', token: record.placeToken };
}

async function handlePlaceIntent(message, sender) {
  const record = activeForSender(sender);
  if (!record || record.submissionStarted || message?.token !== record.placeToken) return { click: false };

  // Re-read the DOM at the click boundary. A token created for C$0.00 must not
  // authorize a button after Amazon changes the total, currency, page, or
  // button state between the earlier snapshot and this final message.
  const snapshot = message?.snapshot && typeof message.snapshot === 'object' ? message.snapshot : {};
  let parsed;
  try { parsed = new URL(String(snapshot.url || '')); } catch (_) { parsed = null; }
  const total = selectCheckoutTotal(snapshot.totalCandidates, record.job.policy.currency);
  const decision = total.ok
    ? evaluateCheckoutPolicy({
        total: total.amount,
        currency: total.currency,
        expectedCurrency: record.job.policy.currency,
        unattendedCheckoutLimit: record.job.policy.unattendedCheckoutLimit,
        mode: record.job.policy.mode,
        localApproval: record.approval
      })
    : { action: 'fail' };
  const exactSnapshot = authenticated === true &&
    Boolean(authenticatedAccountHash) &&
    parsed?.origin === 'https://www.amazon.ca' &&
    !parsed.username &&
    !parsed.password &&
    snapshot.login !== true &&
    snapshot.captcha !== true &&
    snapshot.thankYou !== true &&
    !snapshot.fatalError &&
    snapshot.addressPage !== true &&
    snapshot.paymentPage !== true &&
    snapshot.placeButtonFound === true &&
    snapshot.placeButtonDisabled !== true &&
    total.ok &&
    total.amount === record.finalTotal &&
    total.currency === record.currency &&
    decision.action === 'place';
  if (!exactSnapshot) {
    record.placeToken = null;
    await persistActiveJob();
    return { click: false, reevaluate: true };
  }

  record.submissionStarted = true;
  record.state = 'submitting';
  record.placeToken = null;
  record.timings.placeOrderClickedAtMs = Date.now();
  await persistActiveJob();
  await sendResult(record.job, 'submitting', {
    variantAsin: record.variantAsin,
    finalTotal: record.finalTotal,
    currency: record.currency,
    timings: record.timings
  });
  await chrome.alarms.create(`submission:${record.job.jobId}`, { delayInMinutes: 0.5 });
  return { click: true };
}

async function completeAmbiguous(message) {
  if (!activeJob) return;
  const record = activeJob;
  await sendResult(record.job, 'ambiguous', {
    variantAsin: record.variantAsin,
    finalTotal: record.finalTotal,
    currency: record.currency,
    reasonCode: 'placement_unconfirmed',
    message,
    timings: record.timings
  });
  await cleanupActiveJob({ closeCheckout: false });
}

async function handleApprovalDecision(message) {
  if (!activeJob || message?.jobId !== activeJob.job.jobId) return { ok: false, error: 'Order job is no longer active' };
  if (!activeJob.approvalPrompted) return { ok: false, error: 'No approval is pending' };
  if (message.approvalId !== activeJob.approvalPrompted.approvalId) {
    return { ok: false, error: 'The exact total changed; review the refreshed approval window' };
  }
  if (message.approved !== true) {
    const record = activeJob;
    await sendResult(record.job, 'rejected', {
      variantAsin: record.variantAsin,
      finalTotal: record.finalTotal,
      currency: record.currency,
      reasonCode: 'local_approval_rejected',
      message: 'The order was rejected on the PC',
      timings: record.timings
    });
    await cleanupActiveJob({ closeCheckout: true });
    return { ok: true };
  }
  activeJob.approval = {
    approved: true,
    total: activeJob.approvalPrompted.total,
    currency: activeJob.approvalPrompted.currency,
    approvedAtMs: Date.now()
  };
  activeJob.state = 'approval_granted';
  await persistActiveJob();
  if (Number.isInteger(activeJob.tabId)) {
    try { await chrome.tabs.sendMessage(activeJob.tabId, { type: 'approval_granted' }); } catch (_) {}
  }
  if (approvalWindowId !== null) {
    try { await chrome.windows.remove(approvalWindowId); } catch (_) {}
    approvalWindowId = null;
  }
  return { ok: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  void (async () => {
    await ensureInitialized();
    switch (message?.type) {
      case 'get_status':
        sendResponse({ ok: true, status: await publicStatus() });
        break;
      case 'save_settings': {
        const previous = { ...settings };
        await saveSettings(message.settings || {});
        if (previous.pairingSecret !== settings.pairingSecret || previous.hubPort !== settings.hubPort || previous.enabled !== settings.enabled) {
          disconnect();
          if (settings.enabled) void connect();
        }
        sendResponse({ ok: true, settings: { enabled: settings.enabled, hubPort: settings.hubPort, configured: Boolean(settings.pairingSecret) } });
        break;
      }
      case 'clear_pairing':
        await saveSettings({ enabled: false, pairingSecret: '' });
        disconnect();
        sendResponse({ ok: true });
        break;
      case 'connect_now':
        disconnect();
        void connect();
        sendResponse({ ok: true });
        break;
      case 'refresh_amazon_session':
        try {
          const refreshed = await refreshAmazonSession({ force: true });
          if (authenticated && (!authenticatedAccountHash || refreshed.accountHash !== authenticatedAccountHash)) {
            const accountChanged = new AmazonFlowError(
              'amazon_account_changed',
              'The active Amazon account changed; the companion disconnected and must authenticate against the saved pairing.'
            );
            if (activeJob?.submissionStarted) {
              await completeAmbiguous('The Amazon account changed after Place your order was submitted; check Amazon Orders before any retry.');
            } else if (activeJob) {
              await failActiveJob(accountChanged);
            }
            lastError = accountChanged.message;
            disconnect({ reconnect: true });
            sendResponse({ ok: false, error: lastError, status: await publicStatus() });
            break;
          }
          if (settings.enabled && !authenticated) void connect();
          sendResponse({ ok: true, status: await publicStatus() });
        } catch (error) {
          lastError = bounded(error?.message || error, 240);
          sendResponse({ ok: false, error: lastError });
        }
        break;
      case 'relay_submitted':
        if (activeForSender(sender)?.job?.jobId === message.jobId) {
          await chrome.storage.session.remove(`${RELAY_PREFIX}${message.jobId}`);
        }
        sendResponse({ ok: true });
        break;
      case 'checkout_relay_failed': {
        const relayRecord = activeForSender(sender);
        if (!relayRecord) {
          sendResponse({ ok: false, error: 'Order job is no longer active' });
        } else {
          await failActiveJob(new AmazonFlowError(
            'checkout_relay_invalid',
            bounded(message.message || 'Transient checkout relay failed', 300)
          ));
          sendResponse({ ok: true });
        }
        break;
      }
      case 'checkout_snapshot':
        sendResponse(await handleCheckoutSnapshot(message, sender));
        break;
      case 'checkout_place_intent':
        sendResponse(await handlePlaceIntent(message, sender));
        break;
      case 'checkout_click_cancelled':
        if (activeForSender(sender)?.submissionStarted) {
          await failActiveJob(new AmazonFlowError(
            'checkout_changed_before_click',
            'Amazon checkout changed after the final safety check; Place your order was not clicked'
          ));
        }
        sendResponse({ ok: true });
        break;
      case 'checkout_click_uncertain':
        if (activeForSender(sender)?.submissionStarted) await completeAmbiguous('The Place your order click could not be confirmed and will not be retried');
        sendResponse({ ok: true });
        break;
      case 'get_approval':
        if (!activeJob || message.jobId !== activeJob.job.jobId || !activeJob.approvalPrompted) {
          sendResponse({ ok: false, error: 'Approval request is no longer active' });
        } else {
          sendResponse({
            ok: true,
            approval: {
              approvalId: activeJob.approvalPrompted.approvalId,
              jobId: activeJob.job.jobId,
              asin: activeJob.job.item.asin,
              variantAsin: activeJob.variantAsin,
              title: activeJob.job.item.title,
              imageUrl: activeJob.job.item.imageUrl,
              total: activeJob.approvalPrompted.total,
              currency: activeJob.approvalPrompted.currency,
              limit: activeJob.job.policy.unattendedCheckoutLimit,
              reasonCode: activeJob.approvalPrompted.reasonCode,
              ruleName: activeJob.job.policy.ruleName
            }
          });
        }
        break;
      case 'approval_decision':
        sendResponse(await handleApprovalDecision(message));
        break;
      default:
        sendResponse({ ok: false, error: 'Unsupported companion message' });
    }
  })().catch(error => sendResponse({ ok: false, error: bounded(error?.message || error, 500) }));
  return true;
});

chrome.tabs.onRemoved.addListener(tabId => {
  void (async () => {
    await ensureInitialized();
    if (!activeJob || activeJob.tabId !== tabId) return;
    if (activeJob.submissionStarted) await completeAmbiguous('The checkout tab closed before Amazon confirmation; do not retry until Amazon Orders is checked');
    else await failActiveJob(new AmazonFlowError('checkout_tab_closed', 'The Amazon checkout tab was closed before placement'));
  })().catch(error => {
    lastError = bounded(error?.message || error, 240);
  });
});

chrome.windows.onRemoved.addListener(windowId => {
  if (approvalWindowId === windowId) approvalWindowId = null;
});

chrome.alarms.onAlarm.addListener(alarm => {
  void (async () => {
    await ensureInitialized();
    if (!alarm.name.startsWith('submission:')) return;
    const jobId = alarm.name.slice('submission:'.length);
    if (activeJob?.job?.jobId === jobId && activeJob.submissionStarted) {
      await completeAmbiguous('Amazon did not provide a verifiable order confirmation within 30 seconds; the companion will not retry');
    }
  })().catch(error => {
    lastError = bounded(error?.message || error, 240);
  });
});

chrome.runtime.onInstalled.addListener(details => {
  void (async () => {
    await ensureInitialized();
    if (details.reason === 'install') await chrome.runtime.openOptionsPage();
  })().catch(error => {
    lastError = bounded(error?.message || error, 240);
  });
});

chrome.runtime.onStartup.addListener(() => {
  void ensureInitialized().catch(error => {
    lastError = bounded(error?.message || error, 240);
  });
});

// Chromium rejects asynchronous service-worker module graphs, so never use
// top-level await here. Every listener above is registered synchronously; each
// event awaits the same fail-closed initialization promise before using state.
void ensureInitialized().catch(() => {});
