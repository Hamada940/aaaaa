const ORDER_PROTOCOL_VERSION = 1;
const PAIRING_SECRET_RE = /^vdh1\.([A-Za-z0-9_-]{43})$/;
const NONCE_RE = /^[A-Za-z0-9._:-]{12,160}$/;
const ASIN_RE = /^[A-Z0-9]{10,13}$/;
const ENROLLMENT_GUID_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{7,159}$/;
const VARIANT_LOOKUP_ID_RE = /^[A-Za-z0-9._:-]{12,120}$/;
const VARIANT_LOOKUP_TTL_MAX_MS = 30_000;

function canonicalize(value) {
  if (value === null || value === undefined) return value === undefined ? null : value;
  if (Array.isArray(value)) return value.map(canonicalize);
  if (typeof value !== 'object') return value;
  const output = {};
  for (const key of Object.keys(value).sort()) {
    if (value[key] !== undefined) output[key] = canonicalize(value[key]);
  }
  return output;
}

function canonicalJson(value) {
  return JSON.stringify(canonicalize(value));
}

function base64UrlEncode(value) {
  const bytes = value instanceof Uint8Array ? value : new Uint8Array(value);
  let binary = '';
  for (let index = 0; index < bytes.length; index += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  }
  return btoa(binary).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function base64UrlDecode(value) {
  const text = String(value || '').trim();
  if (!text || !/^[A-Za-z0-9_-]+$/.test(text)) throw new Error('Invalid base64url value');
  const padded = text.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (text.length % 4)) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, character => character.charCodeAt(0));
}

function pairingSecretBytes(secret) {
  const match = String(secret || '').trim().match(PAIRING_SECRET_RE);
  if (!match) throw new Error('Invalid Vine Drop Hub pairing secret');
  const bytes = base64UrlDecode(match[1]);
  if (bytes.length !== 32) throw new Error('Invalid Vine Drop Hub pairing secret length');
  return bytes;
}

async function signPayload(secret, type, payload) {
  const key = await crypto.subtle.importKey(
    'raw',
    pairingSecretBytes(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const message = new TextEncoder().encode(canonicalJson({ type: String(type || '').slice(0, 80), payload }));
  return base64UrlEncode(await crypto.subtle.sign('HMAC', key, message));
}

async function verifyPayloadSignature(secret, type, payload, signature) {
  let expected;
  let supplied;
  try {
    expected = base64UrlDecode(await signPayload(secret, type, payload));
    supplied = base64UrlDecode(signature);
  } catch (_) {
    return false;
  }
  if (expected.length !== supplied.length) return false;
  let difference = 0;
  for (let index = 0; index < expected.length; index += 1) difference |= expected[index] ^ supplied[index];
  return difference === 0;
}

async function signedEnvelope(secret, type, payload) {
  const normalizedType = String(type || '').trim().slice(0, 80);
  return {
    type: normalizedType,
    payload,
    signature: await signPayload(secret, normalizedType, payload)
  };
}

function randomNonce(prefix = 'nonce') {
  const bytes = new Uint8Array(18);
  crypto.getRandomValues(bytes);
  const nonce = `${String(prefix || 'nonce').replace(/[^A-Za-z0-9._:-]/g, '').slice(0, 24)}-${base64UrlEncode(bytes)}`;
  if (!NONCE_RE.test(nonce)) throw new Error('Could not create a protocol nonce');
  return nonce;
}

async function sha256Hex(value) {
  const bytes = new TextEncoder().encode(String(value ?? ''));
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return [...digest].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function normalizeAsin(value) {
  const asin = String(value || '').trim().toUpperCase();
  return ASIN_RE.test(asin) ? asin : '';
}

function validateVariantLookupRequest(payload, { now = Date.now(), maxClockSkewMs = 120_000 } = {}) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new Error('Amazon variant lookup request is missing');
  }
  if (payload.protocolVersion !== ORDER_PROTOCOL_VERSION) {
    throw new Error('Unsupported Amazon variant lookup protocol version');
  }
  const allowed = new Set([
    'protocolVersion', 'lookupId', 'issuedAtMs', 'expiresAtMs', 'nonce', 'operation', 'item'
  ]);
  const unexpected = Object.keys(payload).filter(key => !allowed.has(key));
  if (unexpected.length) throw new Error('Amazon variant lookup request contains unsupported fields');
  const lookupId = String(payload.lookupId || '').trim();
  if (!VARIANT_LOOKUP_ID_RE.test(lookupId)) throw new Error('Invalid Amazon variant lookup ID');
  const nonce = String(payload.nonce || '').trim();
  if (!NONCE_RE.test(nonce)) throw new Error('Invalid Amazon variant lookup nonce');
  if (payload.operation !== 'read_only_amazon_variants') {
    throw new Error('Unsupported Amazon variant lookup operation');
  }
  const issuedAtMs = payload.issuedAtMs;
  const expiresAtMs = payload.expiresAtMs;
  if (
    !Number.isSafeInteger(issuedAtMs) ||
    !Number.isSafeInteger(expiresAtMs) ||
    expiresAtMs <= issuedAtMs ||
    expiresAtMs - issuedAtMs > VARIANT_LOOKUP_TTL_MAX_MS
  ) {
    throw new Error('Invalid Amazon variant lookup lifetime');
  }
  if (issuedAtMs - now > maxClockSkewMs) throw new Error('Amazon variant lookup was issued in the future');
  if (now > expiresAtMs) throw new Error('Amazon variant lookup expired before the PC accepted it');
  const item = payload.item && typeof payload.item === 'object' && !Array.isArray(payload.item)
    ? payload.item
    : {};
  if (Object.keys(item).some(key => !['asin', 'queue', 'enrollmentGuid'].includes(key))) {
    throw new Error('Amazon variant lookup item contains unsupported fields');
  }
  const asin = normalizeAsin(item.asin);
  const queue = String(item.queue || '').trim().toUpperCase();
  const enrollmentGuid = String(item.enrollmentGuid || '').trim();
  if (!/^[A-Z0-9]{10}$/.test(asin)) throw new Error('Amazon variant lookup parent ASIN is invalid');
  if (!['RFY', 'AFA'].includes(queue)) throw new Error('Amazon variant lookup queue is invalid');
  if (!ENROLLMENT_GUID_RE.test(enrollmentGuid)) {
    throw new Error('Amazon variant lookup enrollment metadata is invalid');
  }
  return Object.freeze({
    protocolVersion: ORDER_PROTOCOL_VERSION,
    lookupId,
    issuedAtMs,
    expiresAtMs,
    nonce,
    operation: 'read_only_amazon_variants',
    item: Object.freeze({ asin, queue, enrollmentGuid })
  });
}

function validateOrderJob(payload, { now = Date.now(), maxClockSkewMs = 120_000 } = {}) {
  if (!payload || typeof payload !== 'object') throw new Error('Order job is missing');
  if (payload.protocolVersion !== ORDER_PROTOCOL_VERSION) throw new Error('Unsupported order protocol version');
  const jobId = String(payload.jobId || '').trim();
  if (!/^[A-Za-z0-9._:-]{8,80}$/.test(jobId)) throw new Error('Invalid order job ID');
  const issuedAtMs = Math.trunc(Number(payload.issuedAtMs));
  const expiresAtMs = Math.trunc(Number(payload.expiresAtMs));
  if (!Number.isFinite(issuedAtMs) || !Number.isFinite(expiresAtMs) || expiresAtMs <= issuedAtMs) {
    throw new Error('Invalid order job lifetime');
  }
  if (issuedAtMs - now > maxClockSkewMs) throw new Error('Order job was issued in the future');
  if (now > expiresAtMs) throw new Error('Order job expired before the PC accepted it');

  const item = payload.item && typeof payload.item === 'object' ? payload.item : {};
  const asin = normalizeAsin(item.asin);
  const queue = String(item.queue || '').trim().toUpperCase();
  const enrollmentGuid = String(item.enrollmentGuid || '').trim();
  if (!asin) throw new Error('Order job ASIN is invalid');
  if (!['AI', 'AFA', 'RFY'].includes(queue)) throw new Error('Order job queue is invalid');
  if (!ENROLLMENT_GUID_RE.test(enrollmentGuid)) throw new Error('Order job enrollment metadata is invalid');

  const policy = payload.policy && typeof payload.policy === 'object' ? payload.policy : {};
  const mode = policy.mode === 'approval' ? 'approval' : policy.mode === 'auto' ? 'auto' : '';
  const limit = Number(policy.unattendedCheckoutLimit);
  const currency = String(policy.currency || '').trim().toUpperCase();
  if (!mode) throw new Error('Order job policy mode is invalid');
  if (!Number.isFinite(limit) || limit < 0 || limit > 10_000) throw new Error('Order job checkout limit is invalid');
  if (currency !== 'CAD') throw new Error('Order job currency must be CAD for Amazon.ca');
  const variantPolicy = ['first_available', 'exact'].includes(policy.variantPolicy)
    ? policy.variantPolicy
    : '';
  if (!variantPolicy) throw new Error('Unsupported order job variant policy');
  const selectedVariantAsin = variantPolicy === 'exact'
    ? normalizeAsin(policy.selectedVariantAsin)
    : '';
  if (variantPolicy === 'exact' && !selectedVariantAsin) {
    throw new Error('Exact-variant order job is missing its selected variant ASIN');
  }
  if (variantPolicy === 'exact' && selectedVariantAsin === asin) {
    throw new Error('Exact-variant order job must select a child ASIN distinct from its parent item');
  }

  return {
    protocolVersion: ORDER_PROTOCOL_VERSION,
    jobId,
    issuedAtMs,
    expiresAtMs,
    item: {
      asin,
      title: String(item.title || 'Unknown Product').slice(0, 500),
      queue,
      enrollmentGuid,
      isParentAsin: item.isParentAsin === true,
      isPreRelease: item.isPreRelease === true,
      price: Number.isFinite(Number(item.price)) ? Number(item.price) : null,
      etv: Number.isFinite(Number(item.etv)) ? Number(item.etv) : null,
      imageUrl: String(item.imageUrl || '').slice(0, 2048),
      sources: Array.isArray(item.sources) ? item.sources.map(String).slice(0, 3) : [],
      detectedAtMs: Number.isFinite(Number(item.detectedAtMs)) ? Math.trunc(Number(item.detectedAtMs)) : issuedAtMs
    },
    policy: {
      mode,
      manualDashboardApproval: policy.manualDashboardApproval === true,
      variantPolicy,
      selectedVariantAsin: selectedVariantAsin || null,
      unattendedCheckoutLimit: Math.round(limit * 100) / 100,
      currency,
      ruleId: policy.ruleId ? String(policy.ruleId).slice(0, 80) : null,
      ruleName: policy.ruleName ? String(policy.ruleName).slice(0, 160) : null
    },
    timings: payload.timings && typeof payload.timings === 'object' ? { ...payload.timings } : {}
  };
}

export {
  ORDER_PROTOCOL_VERSION,
  PAIRING_SECRET_RE,
  NONCE_RE,
  canonicalize,
  canonicalJson,
  base64UrlEncode,
  base64UrlDecode,
  pairingSecretBytes,
  signPayload,
  verifyPayloadSignature,
  signedEnvelope,
  randomNonce,
  sha256Hex,
  normalizeAsin,
  validateVariantLookupRequest,
  validateOrderJob
};
