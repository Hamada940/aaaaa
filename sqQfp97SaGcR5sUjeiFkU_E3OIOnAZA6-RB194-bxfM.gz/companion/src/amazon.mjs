import { normalizeAsin, sha256Hex } from './protocol.mjs';

const AMAZON_DOMAIN = 'amazon.ca';
const AMAZON_BASE_URL = `https://www.${AMAZON_DOMAIN}`;
const MAX_SESSION_HTML_BYTES = 8 * 1024 * 1024;
const QUEUE_PATH = Object.freeze({ AI: 'encore', AFA: 'last_chance', RFY: 'potluck' });
const RECOMMENDATION_TYPE = Object.freeze({
  AI: 'VINE_FOR_ALL',
  AFA: 'VENDOR_VINE_FOR_ALL',
  RFY: 'VENDOR_TARGETED'
});

class AmazonFlowError extends Error {
  constructor(code, message, details = null) {
    super(message);
    this.name = 'AmazonFlowError';
    this.code = String(code || 'amazon_error').slice(0, 80);
    this.details = details;
  }
}

function decodeHtmlEntities(value) {
  return String(value || '')
    .replace(/&quot;/gi, '"')
    .replace(/&#34;/g, '"')
    .replace(/&#x22;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&amp;/gi, '&');
}

function pageFailureCode(html, finalUrl = '') {
  const source = String(html || '');
  const url = String(finalUrl || '');
  if (/\/ap\/signin|\/ap\/login|authportal/i.test(url) || /name=["']password["']|id=["']ap_email["']/i.test(source)) {
    return 'amazon_login_required';
  }
  if (/captcha|captchacharacters/i.test(source)) return 'amazon_captcha';
  if (/id=["']d["'][^>]+alt=["'][^"']*(?:Dogs of Amazon|Chiens d['’]Amazon)/i.test(source)) {
    return 'amazon_error_page';
  }
  return null;
}

function sessionContextCandidate(value) {
  if (!value || typeof value !== 'object') return null;
  const customerId = String(value.customerId || value.customer_id || '').trim();
  const marketplaceId = String(
    value.marketplaceId || value.marketplaceID || value.marketplace_id || value.obfuscatedMarketId || ''
  ).trim();
  const csrfToken = String(value.csrfToken || value.csrf_token || '').trim();
  if (!customerId || !marketplaceId || !csrfToken) return null;
  if (customerId.length > 256 || marketplaceId.length > 80 || csrfToken.length > 4096) return null;
  return { customerId, marketplaceId, csrfToken };
}

function extractVvpContextFromHtml(html) {
  const source = String(html || '');
  if (!source || new TextEncoder().encode(source).byteLength > MAX_SESSION_HTML_BYTES) {
    throw new AmazonFlowError('session_page_invalid', 'Amazon Vine session page was empty or too large');
  }
  const scriptPattern = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi;
  let match;
  let scanned = 0;
  while ((match = scriptPattern.exec(source)) && scanned < 3000) {
    scanned += 1;
    const attributes = decodeHtmlEntities(match[1]);
    const body = decodeHtmlEntities(match[2]).trim();
    if (!body || body.length > 256 * 1024) continue;
    const hinted = /vvp-context/i.test(attributes) || /"(?:csrfToken|customerId|marketplaceId)"/.test(body);
    if (!hinted || body[0] !== '{') continue;
    try {
      const parsed = JSON.parse(body);
      const candidate = sessionContextCandidate(parsed);
      if (candidate) return candidate;
    } catch (_) {}
  }

  // Bounded fallback for layout variants that wrap the context object in a
  // larger script. This deliberately requires all three exact JSON keys.
  const customer = source.match(/"customerId"\s*:\s*"([^"\\]{1,256})"/);
  const marketplace = source.match(/"(?:marketplaceId|obfuscatedMarketId)"\s*:\s*"([^"\\]{1,80})"/);
  const csrf = source.match(/"csrfToken"\s*:\s*"([^"\\]{1,4096})"/);
  return sessionContextCandidate({
    customerId: customer?.[1],
    marketplaceId: marketplace?.[1],
    csrfToken: csrf?.[1]
  });
}

async function fetchAmazonSessionContext(fetchImpl = fetch, { queue = 'AI' } = {}) {
  const queuePath = QUEUE_PATH[String(queue || '').toUpperCase()] || QUEUE_PATH.AI;
  const url = `${AMAZON_BASE_URL}/vine/vine-items?queue=${encodeURIComponent(queuePath)}&page=1`;
  let response;
  try {
    response = await fetchImpl(url, {
      method: 'GET',
      credentials: 'include',
      cache: 'no-store',
      redirect: 'follow',
      referrerPolicy: 'no-referrer',
      headers: {
        accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'en-CA,en;q=0.9,fr-CA;q=0.7',
        'cache-control': 'no-cache',
        pragma: 'no-cache'
      }
    });
  } catch (_) {
    throw new AmazonFlowError('amazon_network_error', 'Could not load the local Amazon Vine session');
  }
  const html = await response.text();
  const failure = pageFailureCode(html, response.url);
  if (failure) {
    const labels = {
      amazon_login_required: 'Sign in to Amazon.ca in this Chrome/Edge profile, then refresh the companion session.',
      amazon_captcha: 'Amazon requires a CAPTCHA in this browser profile. Complete it manually before ordering.',
      amazon_error_page: 'Amazon returned an error page. Open Amazon.ca manually before retrying.'
    };
    throw new AmazonFlowError(failure, labels[failure]);
  }
  if (!response.ok) {
    throw new AmazonFlowError('amazon_http_error', `Amazon Vine returned HTTP ${response.status}`);
  }
  const context = extractVvpContextFromHtml(html);
  if (!context) {
    throw new AmazonFlowError('amazon_session_context_missing', 'Amazon Vine did not expose the local account and CSRF context');
  }
  return {
    ...context,
    accountHash: await sha256Hex(context.customerId),
    refreshedAtMs: Date.now(),
    domain: AMAZON_DOMAIN
  };
}

function recommendationIdForJob(job, session) {
  const asin = normalizeAsin(job?.item?.asin);
  const queue = String(job?.item?.queue || '').toUpperCase();
  const enrollmentGuid = String(job?.item?.enrollmentGuid || '').trim();
  const marketplaceId = String(session?.marketplaceId || '').trim();
  const customerId = String(session?.customerId || '').trim();
  if (!asin || !QUEUE_PATH[queue] || !enrollmentGuid || !marketplaceId) {
    throw new AmazonFlowError('metadata_incomplete', 'The signed job lacks valid Vine recommendation metadata');
  }
  if (queue === 'RFY') {
    if (!customerId) throw new AmazonFlowError('account_context_missing', 'The local Amazon account ID is unavailable');
    return `${marketplaceId}#${asin}#${customerId}#vine.enrollment.${enrollmentGuid}`;
  }
  return `${marketplaceId}#${asin}#vine.enrollment.${enrollmentGuid}`;
}

function recommendationTypeForQueue(queue) {
  const value = RECOMMENDATION_TYPE[String(queue || '').toUpperCase()];
  if (!value) throw new AmazonFlowError('queue_invalid', 'Unsupported Vine queue');
  return value;
}

function referrerForQueue(queue) {
  const value = QUEUE_PATH[String(queue || '').toUpperCase()];
  if (!value) throw new AmazonFlowError('queue_invalid', 'Unsupported Vine queue');
  return `${AMAZON_BASE_URL}/vine/vine-items?queue=${value}`;
}

function explicitFalse(value) {
  if (value === false || value === 0 || value === '0') return true;
  return ['false', 'no', 'off', 'unavailable', 'not_orderable'].includes(
    String(value ?? '').trim().toLowerCase()
  );
}

function explicitUnavailable(value) {
  if (value === true || value === 1 || value === '1') return true;
  return ['true', 'yes', 'unavailable', 'not_available', 'not_orderable', 'out_of_stock'].includes(
    String(value ?? '').trim().toLowerCase()
  );
}

function throwRecommendationPayloadError(payload) {
  if (!payload?.error) return;
  const remoteCode = String(payload.error?.exceptionType || payload.error || '').trim().toUpperCase();
  if (remoteCode === 'ITEM_NOT_IN_ENROLLMENT') {
    throw new AmazonFlowError(
      'item_not_in_enrollment',
      'Amazon Vine no longer lists this item in the enrollment'
    );
  }
  throw new AmazonFlowError(
    'recommendations_error',
    'Amazon Vine could not return recommendation details for this item'
  );
}

function isExplicitlyUnavailable(entry) {
  return explicitFalse(entry?.available) ||
    explicitFalse(entry?.isAvailable) ||
    explicitFalse(entry?.orderable) ||
    explicitFalse(entry?.isOrderable) ||
    explicitFalse(entry?.availability) ||
    explicitFalse(entry?.status) ||
    explicitUnavailable(entry?.unavailable) ||
    explicitUnavailable(entry?.isUnavailable) ||
    explicitUnavailable(entry?.availability) ||
    explicitUnavailable(entry?.status);
}

function safeVariationText(value, maximum) {
  if (!['string', 'number', 'boolean'].includes(typeof value)) return '';
  const text = String(value).replace(/\s+/g, ' ').trim();
  if (
    !text ||
    text.length > maximum ||
    /[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(text)
  ) return '';
  return text;
}

function safeVariationDimensions(rawDimensions) {
  if (!rawDimensions || typeof rawDimensions !== 'object' || Array.isArray(rawDimensions)) return [];
  const blockedName = /(?:account|address|cookie|csrf|customer|email|enrollment|marketplace|offer|phone|policy|promotion|recommendation|session|token)/i;
  const entries = [];
  for (const [rawName, rawValue] of Object.entries(rawDimensions)) {
    if (entries.length >= 8) break;
    const name = safeVariationText(rawName, 120);
    const value = safeVariationText(rawValue, 120);
    if (!name || !value || blockedName.test(name)) continue;
    entries.push({ name, value });
  }
  return entries;
}

function amazonVariationChoices(payload, { parentAsin = '', limit = 100 } = {}) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new AmazonFlowError('amazon_variants_invalid', 'Amazon Vine returned an invalid variations response');
  }
  throwRecommendationPayloadError(payload);
  if (!payload.result || typeof payload.result !== 'object' || Array.isArray(payload.result)) {
    throw new AmazonFlowError('amazon_variants_invalid', 'Amazon Vine returned an invalid variations result');
  }
  const values = payload.result.variations;
  if (!Array.isArray(values) || values.length > 1000) {
    throw new AmazonFlowError('amazon_variants_invalid', 'Amazon Vine returned an invalid variations collection');
  }
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) {
    throw new AmazonFlowError('amazon_variants_invalid', 'The local variations limit is invalid');
  }
  const normalizedParent = normalizeAsin(parentAsin);
  const variants = [];
  const seen = new Set();
  let discardedVariants = 0;
  for (const entry of values) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      discardedVariants += 1;
      continue;
    }
    const asin = normalizeAsin(entry.asin);
    if (
      !/^[A-Z0-9]{10}$/.test(asin) ||
      asin === normalizedParent ||
      seen.has(asin) ||
      isExplicitlyUnavailable(entry) ||
      variants.length >= limit
    ) {
      discardedVariants += 1;
      continue;
    }
    const dimensionEntries = safeVariationDimensions(entry.dimensions);
    const label = dimensionEntries
      .map(({ name, value }) => `${name}: ${value}`)
      .join(' • ')
      .slice(0, 240) || asin;
    seen.add(asin);
    variants.push({ asin, label, dimensionEntries });
  }
  return { variants, discardedVariants };
}

function variationsFromResponse(payload) {
  throwRecommendationPayloadError(payload);
  const values = payload?.result?.variations ?? payload?.recommendation?.children ?? payload?.children ?? [];
  const output = [];
  const seen = new Set();
  for (const entry of Array.isArray(values) ? values : []) {
    if (isExplicitlyUnavailable(entry)) continue;
    const asin = normalizeAsin(entry?.asin);
    if (!asin || seen.has(asin)) continue;
    seen.add(asin);
    output.push(asin);
  }
  return {
    recommendationId: String(payload?.result?.recommendationId || '').trim() || null,
    asins: output
  };
}

function variationCandidatesForPolicy(variations, policy = {}) {
  const available = Array.isArray(variations?.asins)
    ? variations.asins.map(normalizeAsin).filter(Boolean)
    : [];
  if (policy.variantPolicy === 'exact') {
    const selected = normalizeAsin(policy.selectedVariantAsin);
    if (!selected || !available.includes(selected)) {
      throw new AmazonFlowError(
        'selected_variant_unavailable',
        `Selected variant ${selected || 'unknown'} is no longer offered for this AFA/AI item`
      );
    }
    return [selected];
  }
  if (policy.variantPolicy !== 'first_available') {
    throw new AmazonFlowError('variant_policy_invalid', 'The signed order job has an unsupported variant policy');
  }
  if (!available.length) {
    throw new AmazonFlowError('no_available_variant', 'Amazon Vine returned no currently available variation');
  }
  return available;
}

function validateSeeDetailsResponse(payload, expectedAsin) {
  const remoteCode = String(payload?.error?.exceptionType || payload?.error || '').trim().toUpperCase();
  if (remoteCode) {
    throw new AmazonFlowError(
      remoteCode === 'ITEM_NOT_IN_ENROLLMENT' ? 'item_not_in_enrollment' : 'see_details_error',
      remoteCode === 'ITEM_NOT_IN_ENROLLMENT'
        ? 'Amazon Vine no longer lists this item in the enrollment'
        : 'Amazon Vine could not return See Details for this item'
    );
  }
  const result = payload?.result;
  const asin = normalizeAsin(result?.asin);
  if (!result || !asin || asin !== normalizeAsin(expectedAsin)) {
    throw new AmazonFlowError('see_details_invalid', 'Amazon Vine See Details returned an unexpected item');
  }
  const promotionId = String(result.promotionId || '').trim();
  const purchasePolicyCode = String(result.purchasePolicyCode || '').trim();
  if (!promotionId || purchasePolicyCode !== 'AmazonVine') {
    throw new AmazonFlowError('see_details_invalid', 'Amazon Vine See Details did not return a valid Vine purchase policy');
  }
  return {
    asin,
    promotionId: promotionId.slice(0, 160),
    purchasePolicyCode,
    limitedQuantity: result.limitedQuantity === true
  };
}

function validateVoiceOrderResponse(payload, expectedAsin) {
  const remoteCode = String(payload?.error?.exceptionType || payload?.error || '').trim().toUpperCase();
  if (remoteCode) {
    throw new AmazonFlowError(
      remoteCode === 'ITEM_NOT_IN_ENROLLMENT' ? 'item_not_in_enrollment' : 'voice_order_error',
      remoteCode === 'ITEM_NOT_IN_ENROLLMENT'
        ? 'Amazon Vine no longer lists this item in the enrollment'
        : 'Amazon Vine could not prepare this item for checkout'
    );
  }
  const result = payload?.result;
  if (!result || result.proceedToCheckout !== true || !String(result.offerListingId || '').trim()) {
    throw new AmazonFlowError('voice_order_invalid', 'Amazon Vine Request Product did not return a checkout offer');
  }
  const responseAsin = normalizeAsin(result.itemAsin);
  if (responseAsin && responseAsin !== normalizeAsin(expectedAsin)) {
    throw new AmazonFlowError('voice_order_invalid', 'Amazon Vine Request Product returned a different item');
  }
  return { offerListingId: String(result.offerListingId).trim().slice(0, 4096) };
}

function checkoutFormFields({ asin, offerListingId, promotionId, purchasePolicyCode }) {
  const normalizedAsin = normalizeAsin(asin);
  if (!normalizedAsin || !offerListingId || !promotionId || purchasePolicyCode !== 'AmazonVine') {
    throw new AmazonFlowError('checkout_metadata_invalid', 'Vine checkout metadata is incomplete');
  }
  return {
    action: `${AMAZON_BASE_URL}/checkout/entry/buynow?pipelineType=Chewbacca`,
    fields: [
      ['skipCart', '1'],
      ['quantity', '1'],
      ['asin', normalizedAsin],
      ['offerListingID', String(offerListingId)],
      ['vinePromotionId', String(promotionId)],
      ['vinePurchasePolicyCode', 'AmazonVine']
    ]
  };
}

export {
  AMAZON_DOMAIN,
  AMAZON_BASE_URL,
  MAX_SESSION_HTML_BYTES,
  QUEUE_PATH,
  RECOMMENDATION_TYPE,
  AmazonFlowError,
  decodeHtmlEntities,
  pageFailureCode,
  sessionContextCandidate,
  extractVvpContextFromHtml,
  fetchAmazonSessionContext,
  recommendationIdForJob,
  recommendationTypeForQueue,
  referrerForQueue,
  variationsFromResponse,
  amazonVariationChoices,
  variationCandidatesForPolicy,
  validateSeeDetailsResponse,
  validateVoiceOrderResponse,
  checkoutFormFields
};
