const CURRENCY_MARKERS = Object.freeze([
  { pattern: /\b(?:USD)\b|US\$/i, currency: 'USD' },
  { pattern: /\b(?:CAD|CDN)\b|C\$/i, currency: 'CAD' },
  { pattern: /\bEUR\b|€/i, currency: 'EUR' },
  { pattern: /\bGBP\b|£/i, currency: 'GBP' }
]);

function normalizeNumericMoney(text) {
  let value = String(text || '')
    .replace(/[\u00a0\u202f]/g, ' ')
    .replace(/[^0-9.,+-]/g, '');
  if (!value || !/\d/.test(value)) return null;
  if ((value.match(/-/g) || []).length || value.includes('+')) return null;

  const lastComma = value.lastIndexOf(',');
  const lastDot = value.lastIndexOf('.');
  if (lastComma >= 0 && lastDot >= 0) {
    const decimal = lastComma > lastDot ? ',' : '.';
    const thousands = decimal === ',' ? /\./g : /,/g;
    value = value.replace(thousands, '').replace(decimal, '.');
  } else if (lastComma >= 0) {
    const fractionLength = value.length - lastComma - 1;
    value = fractionLength === 2
      ? value.replace(/\./g, '').replace(',', '.')
      : value.replace(/,/g, '');
  } else if (lastDot >= 0) {
    const dotCount = (value.match(/\./g) || []).length;
    const fractionLength = value.length - lastDot - 1;
    if (dotCount > 1 || (fractionLength !== 2 && fractionLength !== 1)) value = value.replace(/\./g, '');
  }
  if (!/^\d+(?:\.\d{1,2})?$/.test(value)) return null;
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount < 0 || amount > 100_000) return null;
  return Math.round(amount * 100) / 100;
}

function currencyFromText(text, expectedCurrency = 'CAD') {
  const source = String(text || '');
  const matches = CURRENCY_MARKERS.filter(entry => entry.pattern.test(source)).map(entry => entry.currency);
  const unique = [...new Set(matches)];
  if (unique.length > 1) return null;
  if (unique.length === 1) return unique[0];
  // Amazon.ca commonly renders an unqualified "$". It is safe only because
  // the signed job already fixes the expected currency to CAD.
  if (source.includes('$')) return String(expectedCurrency || '').toUpperCase() || null;
  return String(expectedCurrency || '').toUpperCase() || null;
}

function parseMoneyText(text, expectedCurrency = 'CAD') {
  const amount = normalizeNumericMoney(text);
  const currency = currencyFromText(text, expectedCurrency);
  if (amount === null || !currency) return null;
  return { amount, currency, raw: String(text || '').trim().slice(0, 200) };
}

function selectCheckoutTotal(candidates, expectedCurrency = 'CAD') {
  const parsed = (Array.isArray(candidates) ? candidates : [])
    .map((candidate, index) => {
      const priority = Number.isFinite(Number(candidate?.priority)) ? Number(candidate.priority) : 100 + index;
      const money = parseMoneyText(candidate?.text, expectedCurrency);
      return money ? { ...money, priority, selector: String(candidate?.selector || '').slice(0, 200) } : null;
    })
    .filter(Boolean)
    .sort((left, right) => left.priority - right.priority);
  if (!parsed.length) return { ok: false, reasonCode: 'checkout_total_unknown', message: 'Final Amazon payable total is unavailable' };
  const bestPriority = parsed[0].priority;
  const best = parsed.filter(value => value.priority === bestPriority);
  const unique = new Map(best.map(value => [`${value.currency}:${value.amount.toFixed(2)}`, value]));
  if (unique.size !== 1) {
    return { ok: false, reasonCode: 'checkout_total_ambiguous', message: 'Amazon displayed conflicting final totals' };
  }
  const selected = [...unique.values()][0];
  const expected = String(expectedCurrency || '').toUpperCase();
  if (selected.currency !== expected) {
    return {
      ok: false,
      reasonCode: 'checkout_currency_mismatch',
      message: `Final total currency ${selected.currency} does not match ${expected}`
    };
  }
  return { ok: true, amount: selected.amount, currency: selected.currency, raw: selected.raw };
}

function evaluateCheckoutPolicy({
  total,
  currency,
  expectedCurrency,
  unattendedCheckoutLimit,
  mode,
  localApproval = null
} = {}) {
  const amount = Number(total);
  const limit = Number(unattendedCheckoutLimit);
  const actualCurrency = String(currency || '').toUpperCase();
  const requiredCurrency = String(expectedCurrency || '').toUpperCase();
  if (!Number.isFinite(amount) || amount < 0 || !Number.isFinite(limit) || limit < 0) {
    return { action: 'fail', reasonCode: 'checkout_total_unknown', message: 'Final checkout total could not be validated' };
  }
  if (!requiredCurrency || actualCurrency !== requiredCurrency) {
    return { action: 'fail', reasonCode: 'checkout_currency_mismatch', message: 'Final checkout currency could not be validated' };
  }

  const approvalReason = mode === 'approval'
    ? 'rule_requires_approval'
    : amount > limit
      ? 'checkout_limit_exceeded'
      : null;
  if (approvalReason) {
    const approvalMatches = localApproval?.approved === true &&
      Number(localApproval.total) === amount &&
      String(localApproval.currency || '').toUpperCase() === actualCurrency;
    if (!approvalMatches) {
      return {
        action: 'approval',
        reasonCode: approvalReason,
        message: approvalReason === 'checkout_limit_exceeded'
          ? `Final total ${actualCurrency} ${amount.toFixed(2)} exceeds the unattended limit ${limit.toFixed(2)}`
          : 'This rule requires approval on the PC before Place your order',
        total: amount,
        currency: actualCurrency,
        limit
      };
    }
  }
  return { action: 'place', total: amount, currency: actualCurrency, limit };
}

export {
  normalizeNumericMoney,
  currencyFromText,
  parseMoneyText,
  selectCheckoutTotal,
  evaluateCheckoutPolicy
};
