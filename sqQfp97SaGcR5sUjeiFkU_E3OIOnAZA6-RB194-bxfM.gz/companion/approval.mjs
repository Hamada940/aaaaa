const jobId = new URL(location.href).searchParams.get('job') || '';
const approve = document.getElementById('approve');
const reject = document.getElementById('reject');
const status = document.getElementById('status');
let approvalId = '';

function money(currency, value) {
  try {
    return new Intl.NumberFormat('en-CA', { style: 'currency', currency }).format(Number(value));
  } catch (_) {
    return `${currency} ${Number(value).toFixed(2)}`;
  }
}

function disable(message) {
  approve.disabled = true;
  reject.disabled = true;
  status.textContent = message;
}

async function load() {
  if (!/^[A-Za-z0-9._:-]{8,80}$/.test(jobId)) return disable('This approval request is invalid.');
  const response = await chrome.runtime.sendMessage({ type: 'get_approval', jobId });
  if (!response?.ok) return disable(response?.error || 'This approval request is no longer active.');
  const value = response.approval;
  approvalId = String(value.approvalId || '');
  if (!/^[A-Za-z0-9._:-]{12,160}$/.test(approvalId)) return disable('This exact-total approval is invalid.');
  document.getElementById('product-title').textContent = value.title || 'Unknown Vine product';
  document.getElementById('product-asin').textContent = value.variantAsin
    ? `${value.asin} → ${value.variantAsin}`
    : value.asin;
  document.getElementById('final-total').textContent = money(value.currency, value.total);
  document.getElementById('limit').textContent = money(value.currency, value.limit);
  document.getElementById('rule-name').textContent = value.ruleName ? `Rule: ${value.ruleName}` : 'Explicit dashboard order';
  document.getElementById('reason').textContent = value.reasonCode === 'checkout_limit_exceeded'
    ? 'The final Amazon payable total is above your unattended limit. Review the exact charge before approving.'
    : 'This matching rule requires a person at this PC to approve before Place your order.';
  if (/^https:\/\/[^/]*amazon\./i.test(value.imageUrl || '')) {
    const image = document.getElementById('product-image');
    image.src = value.imageUrl;
    image.hidden = false;
  }
}

async function decide(approved) {
  approve.disabled = true;
  reject.disabled = true;
  status.textContent = approved ? 'Approving this exact total…' : 'Rejecting the order…';
  const response = await chrome.runtime.sendMessage({ type: 'approval_decision', jobId, approvalId, approved });
  if (!response?.ok) {
    status.textContent = response?.error || 'The approval decision could not be applied.';
    return;
  }
  status.textContent = approved
    ? 'Approved. The companion is returning to Amazon checkout.'
    : 'Rejected. The checkout tab is being closed.';
  window.close();
}

approve.addEventListener('click', () => void decide(true));
reject.addEventListener('click', () => void decide(false));
void load().catch(error => disable(error?.message || 'Could not load approval details.'));
