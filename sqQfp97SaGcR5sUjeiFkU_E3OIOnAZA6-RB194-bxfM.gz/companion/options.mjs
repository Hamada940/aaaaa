const port = document.getElementById('port');
const secret = document.getElementById('secret');
const enabled = document.getElementById('enabled');
const saveStatus = document.getElementById('save-status');

function setClass(element, state) {
  element.className = state === true ? 'good' : state === false ? 'bad' : 'warn';
}

async function refreshStatus() {
  const response = await chrome.runtime.sendMessage({ type: 'get_status' });
  if (!response?.ok) throw new Error(response?.error || 'Could not read companion status');
  const value = response.status;
  port.value = value.hubPort || 3001;
  enabled.checked = value.enabled === true;
  const hub = document.getElementById('hub-status');
  hub.textContent = value.socketConnected ? 'Connected to localhost' : value.enabled ? 'Disconnected / connecting' : 'Disabled';
  setClass(hub, value.socketConnected ? true : value.enabled ? null : false);
  const auth = document.getElementById('auth-status');
  auth.textContent = value.authenticated ? 'Authenticated and account-bound' : value.configured ? 'Not authenticated' : 'Not paired';
  setClass(auth, value.authenticated ? true : false);
  const amazon = document.getElementById('amazon-status');
  amazon.textContent = value.amazonSession?.ready
    ? `Ready · ${value.amazonSession.accountHashPreview} · ${new Date(value.amazonSession.refreshedAt).toLocaleTimeString()}`
    : 'Not verified';
  setClass(amazon, value.amazonSession?.ready ? true : false);
  const job = document.getElementById('job-status');
  job.textContent = value.activeJob
    ? `${value.activeJob.state || 'active'} · ${value.activeJob.asin} · ${value.activeJob.title || ''}`
    : 'None';
  setClass(job, value.activeJob ? null : true);
  const error = document.getElementById('last-error');
  error.textContent = value.lastError ? `Last error: ${value.lastError}` : '';
  error.className = value.lastError ? 'status-text bad' : 'status-text';
}

async function save() {
  saveStatus.textContent = '';
  const parsedPort = Math.trunc(Number(port.value));
  if (!Number.isInteger(parsedPort) || parsedPort < 1024 || parsedPort > 65535) {
    saveStatus.textContent = 'Enter a local port from 1024 to 65535.';
    return;
  }
  const enteredSecret = secret.value.trim();
  if (enteredSecret && !/^vdh1\.[A-Za-z0-9_-]{43}$/.test(enteredSecret)) {
    saveStatus.textContent = 'The pairing secret format is invalid.';
    return;
  }
  const patch = { enabled: enabled.checked, hubPort: parsedPort };
  if (enteredSecret) patch.pairingSecret = enteredSecret;
  const response = await chrome.runtime.sendMessage({ type: 'save_settings', settings: patch });
  if (!response?.ok) throw new Error(response?.error || 'Could not save settings');
  secret.value = '';
  saveStatus.textContent = enabled.checked
    ? 'Saved. Keep the SSH forward running while the companion connects.'
    : 'Saved. The companion is disabled.';
  await refreshStatus();
}

document.getElementById('save').addEventListener('click', () => void save().catch(error => {
  saveStatus.textContent = error.message;
}));
document.getElementById('clear').addEventListener('click', () => void (async () => {
  if (!confirm('Remove the pairing secret from this browser and disable the companion?')) return;
  await chrome.runtime.sendMessage({ type: 'clear_pairing' });
  secret.value = '';
  saveStatus.textContent = 'Local pairing removed.';
  await refreshStatus();
})());
document.getElementById('reconnect').addEventListener('click', () => void (async () => {
  await chrome.runtime.sendMessage({ type: 'connect_now' });
  saveStatus.textContent = 'Reconnect requested.';
  await refreshStatus();
})());
document.getElementById('refresh-session').addEventListener('click', () => void (async () => {
  saveStatus.textContent = 'Refreshing the local Amazon.ca session…';
  const response = await chrome.runtime.sendMessage({ type: 'refresh_amazon_session' });
  saveStatus.textContent = response?.ok ? 'Amazon.ca session refreshed.' : (response?.error || 'Session refresh failed.');
  await refreshStatus();
})());
chrome.runtime.onMessage.addListener(message => {
  if (message?.type === 'companion_status') void refreshStatus();
});
void refreshStatus().catch(error => { saveStatus.textContent = error.message; });
