'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const dockerfile = fs.readFileSync(path.join(root, 'Dockerfile'), 'utf8');
const coordinator = fs.readFileSync(path.join(root, 'lib', 'order-coordinator.js'), 'utf8');

function section(source, start, end) {
  const from = source.indexOf(start);
  const to = source.indexOf(end, from + start.length);
  assert.ok(from >= 0, `missing start marker: ${start}`);
  assert.ok(to > from, `missing end marker: ${end}`);
  return source.slice(from, to);
}

function manualPointerHarness() {
  const source = section(
    dashboard,
    'function createManualOrderPointerController({',
    'function bindOrderButtonInteraction()'
  );
  const context = {};
  vm.runInNewContext(`${source}\nthis.factory = createManualOrderPointerController;`, context);
  let clock = 100;
  const activations = [];
  const controller = context.factory({
    activate: asin => activations.push(asin),
    now: () => clock
  });
  const button = asin => ({
    dataset: { orderAsin: asin },
    closest: selector => selector === '.btn-order-pc[data-order-asin]'
      ? { dataset: { orderAsin: asin } }
      : null
  });
  const event = ({ asin = null, pointerId = 1, pointerType = 'mouse', buttonNumber = 0, x = 10, y = 10 } = {}) => {
    const state = { prevented: 0, stopped: 0 };
    return {
      pointerId,
      pointerType,
      button: buttonNumber,
      isPrimary: true,
      clientX: x,
      clientY: y,
      target: asin ? button(asin) : { closest: () => null },
      preventDefault: () => { state.prevented += 1; },
      stopPropagation: () => { state.stopped += 1; },
      state
    };
  };
  return {
    controller,
    activations,
    event,
    advance: milliseconds => { clock += milliseconds; }
  };
}

function openVinePointerHarness() {
  const source = section(
    dashboard,
    'function createOpenVinePointerController({',
    'function bindOpenVineInteraction()'
  );
  const context = {};
  vm.runInNewContext(`${source}\nthis.factory = createOpenVinePointerController;`, context);
  let clock = 100;
  const activations = [];
  const controller = context.factory({
    activate: url => activations.push(url),
    now: () => clock
  });
  const link = url => ({
    href: url,
    getAttribute: name => name === 'href' ? url : null,
    closest: selector => selector === 'a[data-open-vine][href]'
      ? { href: url, getAttribute: name => name === 'href' ? url : null }
      : null
  });
  const event = ({ url = null, pointerId = 1, pointerType = 'touch', buttonNumber = 0, x = 10, y = 10 } = {}) => {
    const state = { prevented: 0, stopped: 0 };
    return {
      pointerId,
      pointerType,
      button: buttonNumber,
      isPrimary: true,
      clientX: x,
      clientY: y,
      target: url ? link(url) : { closest: () => null },
      preventDefault: () => { state.prevented += 1; },
      stopPropagation: () => { state.stopped += 1; },
      state
    };
  };
  return {
    controller,
    activations,
    event,
    advance: milliseconds => { clock += milliseconds; }
  };
}

test('dashboard exposes pairing, exact-total safety, first-match rules, and a sanitized ledger', () => {
  const orderUi = section(dashboard, '<div class="settings-section" id="order-agent-settings-section">', '<div class="settings-section" id="smartviner-settings-section">');
  assert.match(dashboard, /id="order-agent-status-pill"/);
  assert.match(orderUi, /Create New Pairing Secret/);
  assert.match(orderUi, /Maximum unattended final Amazon charge \(CAD\)/);
  assert.match(orderUi, /C\$0 orders and totals at or below this limit may proceed unattended/);
  assert.match(orderUi, /first enabled match wins/i);
  for (const value of ['word_only', 'price_only', 'and', 'or']) {
    assert.match(dashboard, new RegExp(`option value="${value}"`));
  }
  for (const value of ['retail', 'etv', 'either', 'at_least', 'at_most', 'between']) {
    assert.match(dashboard, new RegExp(`option value="${value}"`));
  }
  assert.match(dashboard, /data-rule-excluded/);
  assert.match(dashboard, /data-rule-word-mode/);
  assert.match(orderUi, /<details class="order-settings-details" id="order-rules-details">[\s\S]*<summary[^>]*>⚡ Automatic Order Rules<\/summary>/);
  assert.match(orderUi, /<details class="order-settings-details" id="order-watches-details">[\s\S]*<summary[^>]*>🎯 One-shot AFA\/AI Watches<\/summary>/);
  assert.doesNotMatch(orderUi, /<details class="order-settings-details"[^>]*\sopen(?:\s|>)/);
  assert.match(dashboard, /class="order-jobs"/);
  assert.match(dashboard, /Detect → Place/);
  assert.match(dashboard, /placeOrderClickedAtMs/);
  assert.doesNotMatch(orderUi, /customerId|csrfToken|offerListingId|amazonCookies/i);
});

test('periodic companion status refresh preserves an unsaved order-rule draft', () => {
  assert.match(dashboard, /let orderRulesDirty = false;/);
  assert.match(dashboard, /function markOrderRulesDirty\(\)/);
  assert.match(dashboard, /bindOrderRuleDraftTracking\(\);[\s\S]*initWebSocket\(\);/);
  assert.match(dashboard, /target\.closest\?\.\('#order-rule-list'\)[\s\S]*markOrderRulesDirty\(\)/);

  const addRule = section(dashboard, 'function addOrderRule()', 'function removeOrderRule(index)');
  assert.match(addRule, /orderRuleSet\.rules\.push\(newDashboardOrderRule\(\)\);[\s\S]*markOrderRulesDirty\(\);/);

  const refresh = section(dashboard, 'async function refreshOrderAgentStatus(showErrors = true)', 'async function pairOrderAgent()');
  assert.match(refresh, /if \(!orderRulesDirty\) orderRuleSet =/);
  assert.match(refresh, /if \(!orderRulesDirty\) renderOrderRules\(\);/);

  const socketEvents = section(dashboard, 'function handleWsEvent(type, data', 'function statusClass(value)');
  assert.match(socketEvents, /data\?\.rules && !orderRulesDirty/);
  assert.match(dashboard, /orderRulesDirty = false;[\s\S]*Saved and applied/);
});

test('explicit Order on PC exists only for live stored cards and posts only an ASIN after dashboard confirmation', () => {
  const card = section(
    dashboard,
    "function createProductCardHtml(item, cardView = 'feed')",
    'function escapeHtml(value)'
  );
  assert.match(card, /viewKey === 'feed'/);
  assert.match(card, /Order on PC/);
  assert.match(card, /data-order-asin="\$\{escapeHtml\(item\.asin\)\}"/);
  assert.match(card, /card-image-order-trigger btn-order-pc/);
  assert.match(card, /const imageOrderButtonHtml = isLiveFeedCard/);
  assert.doesNotMatch(card, /onclick="orderItemOnPc/);
  assert.doesNotMatch(card, /btn-order-pc[^>]*\sdisabled(?:\s|>)/);

  const openConfirmation = section(dashboard, 'async function orderItemOnPc(asin, event)', 'async function confirmOrderItemOnPc(event)');
  assert.match(openConfirmation, /modal-order-confirm/);
  assert.match(openConfirmation, /pendingManualOrderAsin = normalizedAsin/);
  assert.doesNotMatch(openConfirmation, /\bconfirm\s*\(|fetch\s*\(/);

  const submit = section(dashboard, 'async function confirmOrderItemOnPc(event)', 'function renderSmartVinerStatus()');
  const requestGuard = submit.indexOf('manualOrderRequestInFlight = true');
  const requestPost = submit.indexOf("fetch('/api/order-agent/jobs'");
  assert.ok(requestGuard >= 0 && requestGuard < requestPost);
  assert.equal((submit.match(/fetch\('\/api\/order-agent\/jobs'/g) || []).length, 1);
  assert.match(submit, /body:\s*JSON\.stringify\(\{ asin \}\)/);
  assert.doesNotMatch(submit, /recommendationId|customerId|csrf|offerListing|cookie/i);

  const serverAction = section(
    server,
    "app.post('/api/order-agent/jobs'",
    "app.get('/api/vpn/status'"
  );
  assert.match(serverAction, /allItems\.find\(candidate => candidate\.asin === asin && isLiveItem\(candidate\)\)/);
  assert.match(serverAction, /orderCoordinator\.dispatchManual\(item\)/);
  assert.doesNotMatch(serverAction, /axios|fetch\s*\(|https\.request/);
});

test('stable pointer capture preserves first-press Order on PC and Open Vine activation across card replacement', () => {
  const h = manualPointerHarness();
  assert.equal(h.controller.pointerDown(h.event({ asin: 'B000000201', pointerId: 7 })), true);
  h.advance(25);
  const releaseAfterReplacement = h.event({ asin: null, pointerId: 7 });
  assert.equal(h.controller.pointerUp(releaseAfterReplacement), true);
  assert.deepEqual(h.activations, ['B000000201']);
  assert.equal(releaseAfterReplacement.state.prevented, 1);
  assert.equal(releaseAfterReplacement.state.stopped, 1);

  const vine = openVinePointerHarness();
  const url = 'https://www.amazon.ca/vine/vine-items?search=Coffee%20Grinder';
  assert.equal(vine.controller.pointerDown(vine.event({ url, pointerId: 8 })), true);
  vine.advance(20);
  const vineReleaseAfterReplacement = vine.event({ url: null, pointerId: 8 });
  assert.equal(vine.controller.pointerUp(vineReleaseAfterReplacement), true);
  assert.deepEqual(vine.activations, [url]);
  const syntheticClick = vine.event({ url });
  assert.equal(vine.controller.click(syntheticClick), true);
  assert.deepEqual(vine.activations, [url]);
});

test('pointer activation suppresses its synthetic click while a later keyboard click remains usable', () => {
  const h = manualPointerHarness();
  h.controller.pointerDown(h.event({ asin: 'B000000202' }));
  h.controller.pointerUp(h.event({ asin: null }));
  const syntheticClick = h.event({ asin: 'B000000202' });
  assert.equal(h.controller.click(syntheticClick), true);
  assert.deepEqual(h.activations, ['B000000202']);

  h.advance(1_501);
  const keyboardClick = h.event({ asin: 'B000000202' });
  assert.equal(h.controller.click(keyboardClick), true);
  assert.deepEqual(h.activations, ['B000000202', 'B000000202']);
});

test('manual order pointer capture rejects drags, cancellations, non-primary pointers, and right clicks', () => {
  const dragged = manualPointerHarness();
  dragged.controller.pointerDown(dragged.event({ asin: 'B000000203', x: 0, y: 0 }));
  assert.equal(dragged.controller.pointerUp(dragged.event({ asin: null, x: 30, y: 0 })), false);
  assert.deepEqual(dragged.activations, []);

  const cancelled = manualPointerHarness();
  cancelled.controller.pointerDown(cancelled.event({ asin: 'B000000204', pointerId: 9 }));
  assert.equal(cancelled.controller.pointerCancel(cancelled.event({ asin: null, pointerId: 9 })), true);
  assert.equal(cancelled.controller.pointerUp(cancelled.event({ asin: null, pointerId: 9 })), false);
  assert.deepEqual(cancelled.activations, []);

  const rightClick = manualPointerHarness();
  assert.equal(rightClick.controller.pointerDown(rightClick.event({ asin: 'B000000205', buttonNumber: 2 })), false);
  const nonPrimary = rightClick.event({ asin: 'B000000205' });
  nonPrimary.isPrimary = false;
  assert.equal(rightClick.controller.pointerDown(nonPrimary), false);

  const mismatched = manualPointerHarness();
  mismatched.controller.pointerDown(mismatched.event({ asin: 'B000000206', pointerId: 11 }));
  assert.equal(mismatched.controller.pointerUp(mismatched.event({ asin: null, pointerId: 12 })), false);
  assert.deepEqual(mismatched.activations, []);
  assert.equal(mismatched.controller.pointerCancel(mismatched.event({ asin: null, pointerId: 11 })), true);

  const overlong = manualPointerHarness();
  overlong.controller.pointerDown(overlong.event({ asin: 'B000000207' }));
  overlong.advance(10_001);
  assert.equal(overlong.controller.pointerUp(overlong.event({ asin: null })), false);
  assert.deepEqual(overlong.activations, []);
});

test('manual order controls never silently disable and bind stable capture before live WebSocket updates', () => {
  assert.match(dashboard, /id="modal-order-confirm"[\s\S]*No job has been sent\./);
  assert.match(dashboard, /function manualOrderAvailability[\s\S]*safety circuit breaker[\s\S]*not authenticated and account-matched[\s\S]*already active/);
  assert.match(dashboard, /document\.addEventListener\('pointerdown', manualOrderPointerController\.pointerDown, true\)/);
  assert.match(dashboard, /document\.addEventListener\('pointerup', manualOrderPointerController\.pointerUp, true\)/);
  assert.match(dashboard, /document\.addEventListener\('pointerdown', openVinePointerController\.pointerDown, true\)/);
  assert.match(dashboard, /window\.open\(url, '_blank', 'noopener,noreferrer'\)/);
  assert.match(dashboard, /bindOpenVineInteraction\(\);[\s\S]*bindOrderButtonInteraction\(\);[\s\S]*initWebSocket\(\);/);
  assert.match(dashboard, /btn-order-pc\[data-order-asin\]/);
  assert.match(dashboard, /aria-disabled="\$\{orderAvailability\.ready \? 'false' : 'true'\}"/);
  assert.doesNotMatch(dashboard, /btn-order-pc[^>]*\sdisabled(?:\s|>)/);
  assert.match(dashboard, /if \(manualOrderRequestInFlight\)[\s\S]*already being sent/);
});

test('first-event dispatch remains immediate while one fresh later UV/VH confirmation can newly qualify silently', () => {
  const ingest = section(server, 'function ingestItem(raw', 'function applyUvAlertDetail(raw');
  const firstDispatch = ingest.indexOf('maybeDispatchAutomaticOrder(newItem, {');
  const firstBroadcast = ingest.indexOf("broadcastLocal('new_item', withOrderRuleMatch(newItem)");
  const firstNotify = ingest.indexOf('notifyLiveItem(newItem)');
  assert.ok(firstDispatch >= 0 && firstDispatch < firstBroadcast && firstDispatch < firstNotify);

  const mergeDispatch = ingest.indexOf('maybeDispatchAutomaticOrder(mergedItem, {');
  const silentUpdate = ingest.indexOf("broadcastLocal('update_item', withOrderRuleMatch(mergedItem)", mergeDispatch);
  assert.ok(mergeDispatch >= 0 && mergeDispatch < silentUpdate);
  assert.match(ingest, /first later independent UV or VH live-source confirmation|later trustworthy UV↔VH cross-feed confirmation/);
  assert.match(ingest, /allowLaterRuleDispatch[\s\S]*previousLiveSources[\s\S]*previousMergedItem: existing[\s\S]*liveEventItem: liveEventOrderItem/);
  assert.match(coordinator, /item already matched before later source confirmation/);
  assert.match(coordinator, /automatic attempt already recorded for ASIN/);
});

test('UV/VH delayed money completion is event-linked, bounded, advisory on feed availability, and precedes UI persistence', () => {
  const ingest = section(server, 'function ingestItem(raw', 'function applyUvAlertDetail(raw');
  assert.equal((ingest.match(/feedUnavailableAdvisory: \['UV', 'VH'\]\.includes\(source\)/g) || []).length, 2);
  assert.equal((ingest.match(/allowDelayedPriceCompletion: \['UV', 'VH'\]\.includes\(source\)/g) || []).length, 2);

  const uvDetail = section(server, 'function applyUvAlertDetail(raw', 'function extractUvProducts(message)');
  const uvCompletion = uvDetail.indexOf('orderCoordinator.dispatchForDelayedPriceCompletion(updated, {');
  const uvBroadcast = uvDetail.indexOf("broadcastLocal('update_item'");
  const uvPersist = uvDetail.indexOf('persistItemUpsert(updated)');
  assert.ok(uvCompletion >= 0 && uvCompletion < uvBroadcast && uvCompletion < uvPersist);
  assert.match(uvDetail, /source: 'UV'[\s\S]*eventType: messageType[\s\S]*price: detail\.price[\s\S]*etv: detail\.etv/);

  const vhEnrichment = section(server, 'function applyVhEnrichment(', 'function ingestVhLivePayload(');
  const vhCompletion = vhEnrichment.indexOf('orderCoordinator.dispatchForDelayedPriceCompletion(updated, {');
  const vhBroadcast = vhEnrichment.indexOf("broadcastLocal('update_item'");
  const vhPersist = vhEnrichment.indexOf('persistItemUpsert(updated)');
  assert.ok(vhCompletion >= 0 && vhCompletion < vhBroadcast && vhCompletion < vhPersist);
  assert.match(vhEnrichment, /allowDelayedPriceCompletion: false/);
  assert.match(coordinator, /LIVE_PRICE_COMPLETION_WINDOW_MS = 60_000/);
  assert.match(coordinator, /No title, source, queue, recommendation, or enrollment metadata is copied/);
  assert.match(coordinator, /candidate\.agentSocket !== this\.socket/);
  assert.match(coordinator, /this\.livePriceCompletionCandidates\.delete\(asin\);[\s\S]*return this\.#dispatch\(dispatchItem/);
});

test('order-agent channel is isolated from dashboard frames and bound to the existing loopback listener', () => {
  const socket = section(server, "localWss.on('connection'", '// ============================================================================\n// REST API');
  assert.match(socket, /isAllowedLocalWebSocketOrigin\(request\?\.headers\?\.origin\)/);
  assert.ok(server.includes('^chrome-extension:\\/\\/[a-p]{32}$'));
  assert.match(socket, /role === 'order-agent'/);
  assert.match(socket, /orderCoordinator\.attachSocket\(socket\)/);
  assert.match(server, /if \(client\.vdhRole === 'order-agent'\) return/);
  assert.match(server, /websocketPath: '\/ws-feed\?role=order-agent'/);
  assert.match(fs.readFileSync(path.join(root, 'compose.vpn.yml'), 'utf8'), /127\.0\.0\.1:3001:3001\/tcp/);
  assert.match(dockerfile, /COPY public \.\/public/);
});

test('pairing and rule APIs require explicit local actions and never disclose the saved pairing secret', () => {
  const routes = section(server, '// PC ORDER COMPANION', "app.get('/api/vpn/status'");
  assert.match(routes, /confirmation !== ORDER_PAIR_CONFIRMATION/);
  assert.match(routes, /confirmation !== ORDER_REVOKE_CONFIRMATION/);
  assert.match(routes, /orderCoordinator\.issuePairing/);
  assert.match(routes, /orderCoordinator\.updateRuleSet/);
  assert.match(routes, /orderCoordinator\.recentJobs\(100\)/);
  assert.doesNotMatch(routes, /pairing\.secret|pairingSecret:\s*orderCoordinator/);
});

test('order account binding is browser-derived and never consumes synthetic Hub, UV, or VH identity data', () => {
  const construction = section(server, 'orderCoordinator = new OrderCoordinator({', 'function maybeDispatchAutomaticOrder');
  assert.doesNotMatch(construction, /azUser|getExpectedAccountHash/);
  assert.doesNotMatch(coordinator, /getExpectedAccountHash|config\.azUser/);
  assert.match(coordinator, /ACCOUNT_BINDING_KIND = 'amazon_customer_id_sha256'/);
  assert.match(coordinator, /accountBindingState: 'pending'/);
  assert.match(coordinator, /pairingMigrationRequired/);
});
