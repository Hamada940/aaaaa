#!/usr/bin/env python3

import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import unittest
import uuid

from host.vpn_profile_manager import (
    Manager,
    RUNTIME_FILES,
    parse_profile,
    parse_wireguard_profile,
)


def profile(endpoint: str) -> bytes:
    return f"""client
dev tun
proto udp
remote {endpoint} 1194
remote-cert-tls server
<ca>
-----BEGIN CERTIFICATE-----
TEST
-----END CERTIFICATE-----
</ca>
<cert>
-----BEGIN CERTIFICATE-----
TEST
-----END CERTIFICATE-----
</cert>
<key>
TEST-INLINE-KEY-DATA
</key>
""".encode()


WG_PRIVATE_KEY = base64.b64encode(bytes([1]) * 32).decode()
WG_PUBLIC_KEY = base64.b64encode(bytes([2]) * 32).decode()
WG_PRESHARED_KEY = base64.b64encode(bytes([3]) * 32).decode()


def wireguard(
    endpoint: str = "198.51.100.20:51820",
    *,
    dual_stack: bool = True,
    preshared: bool = True,
    allowed_ips: str | None = None,
) -> bytes:
    addresses = "10.2.0.2/32, 2a07:b944::2:2/128" if dual_stack else "10.2.0.2/32"
    allowed = allowed_ips or ("0.0.0.0/0, ::/0" if dual_stack else "0.0.0.0/0")
    psk = f"PresharedKey = {WG_PRESHARED_KEY}\n" if preshared else ""
    return f"""[Interface]
PrivateKey = {WG_PRIVATE_KEY}
Address = {addresses}
DNS = 10.2.0.1
MTU = 1320

[Peer]
PublicKey = {WG_PUBLIC_KEY}
{psk}AllowedIPs = {allowed}
Endpoint = {endpoint}
PersistentKeepalive = 25
""".encode()


class FakeManager(Manager):
    def __init__(self, project_dir: Path, fail_first_apply: bool = False):
        self.fail_first_apply = fail_first_apply
        self.up_calls = 0
        self.compose_calls = []
        self.inspect_calls = []
        self.prepare_calls = []
        self.egress_families = []
        super().__init__(project_dir, health_timeout=2)

    def command(self, args, timeout=240, check=True):
        if args[:2] == ["/bin/bash", str(self.prepare_script)]:
            self.prepare_calls.append(tuple(args))
            shutil.copy2(args[2], args[3])
            return subprocess.CompletedProcess(args, 0, "prepared\n", "")
        if len(args) > 1 and args[0] == "docker" and args[1] == "inspect":
            self.inspect_calls.append(args[-1])
        if args[:3] == ["docker", "exec", "vine-drop-hub"]:
            self.egress_families.append(int(args[-1]))
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "running|healthy\n", "")

    def compose_command(self, *args, timeout=240, check=True):
        self.compose_calls.append(args)
        if args and args[0] == "up":
            self.up_calls += 1
            if self.fail_first_apply and self.up_calls == 1:
                raise RuntimeError("forced candidate startup failure")
        return subprocess.CompletedProcess(args, 0, "ok\n", "")



class ProfileManagerTests(unittest.TestCase):
    def make_project(self):
        temporary = tempfile.TemporaryDirectory()
        project = Path(temporary.name)
        (project / "vpn").mkdir()
        (project / "compose.vpn.yml").write_text("services: {}\n")
        prepare = project / "vpn" / "prepare-profile.sh"
        prepare.write_text("#!/bin/sh\nexit 0\n")
        # Reproduce the inherited managed-file mode that caused dashboard VPN
        # switching to fail before this hotfix. /bin/bash must still run it.
        prepare.chmod(0o600)
        (project / "vpn" / "client.ovpn").write_bytes(profile("10.0.0.1"))
        (project / "vpn" / "client.gluetun.ovpn").write_bytes(profile("10.0.0.1"))
        return temporary, project

    def queue_apply(self, manager: Manager, content: bytes, protocol: str = "openvpn"):
        request_id = str(uuid.uuid4())
        extension = "ovpn" if protocol == "openvpn" else "conf"
        candidate = manager.inbox / f"{request_id}.{extension}"
        candidate.write_bytes(content)
        request = {
            "schemaVersion": 2,
            "action": "apply",
            "requestId": request_id,
            "vpnProtocol": protocol,
            "candidateFile": candidate.name,
            "originalName": f"new.{extension}",
            "submittedAt": "2026-09-18T00:00:00.000Z",
            "sha256": hashlib.sha256(content).hexdigest(),
        }
        (manager.inbox / f"{request_id}.request.json").write_text(json.dumps(request))
        return request_id

    def test_profile_parser_rejects_script_hook(self):
        with self.assertRaisesRegex(ValueError, "Forbidden OpenVPN directive"):
            parse_profile(profile("10.0.0.2") + b"script-security 2\nup /tmp/x\n")

    def test_successful_transaction_keeps_new_profile_and_backup(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        request_id = self.queue_apply(manager, profile("10.0.0.2"))
        self.assertTrue(manager.process_once())
        self.assertEqual(len(manager.prepare_calls), 1)
        self.assertEqual(manager.prepare_calls[0][0:2], ("/bin/bash", str(manager.prepare_script)))
        self.assertIn(b"10.0.0.2", (project / "vpn" / "client.ovpn").read_bytes())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "applied")
        self.assertEqual(status["requestId"], request_id)
        state = json.loads(manager.state_file.read_text())
        backup = project / state["rollbackBackup"]
        self.assertIn(b"10.0.0.1", (backup / "client.ovpn").read_bytes())

    def test_profile_switch_recreates_vpn_bound_smartviner_proxy(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        manager.recreate_and_verify()
        up_calls = [call for call in manager.compose_calls if call and call[0] == "up"]
        self.assertEqual(len(up_calls), 1)
        self.assertEqual(
            up_calls[0],
            ("up", "-d", "--force-recreate", "vpn", "sv-proxy", "app"),
        )
        self.assertEqual(
            manager.inspect_calls,
            ["vine-vpn", "vine-sv-vpn-proxy", "vine-drop-hub"],
        )

    def test_failed_candidate_is_automatically_restored(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project, fail_first_apply=True)
        self.queue_apply(manager, profile("10.0.0.2"))
        self.assertTrue(manager.process_once())
        self.assertIn(b"10.0.0.1", (project / "vpn" / "client.ovpn").read_bytes())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "rolled_back")
        self.assertIn("forced candidate startup failure", status["error"])
        self.assertEqual(manager.up_calls, 2)

    def test_checksum_mismatch_never_changes_active_profile(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        request_id = self.queue_apply(manager, profile("10.0.0.2"))
        request_path = manager.inbox / f"{request_id}.request.json"
        request = json.loads(request_path.read_text())
        request["sha256"] = "0" * 64
        request_path.write_text(json.dumps(request))
        manager.process_once()
        self.assertIn(b"10.0.0.1", (project / "vpn" / "client.ovpn").read_bytes())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "failed")
        self.assertIn("checksum", status["error"])

    def test_manual_rollback_restores_previous_profile_and_can_be_reversed(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        self.queue_apply(manager, profile("10.0.0.2"))
        manager.process_once()
        self.assertIn(b"10.0.0.2", (project / "vpn" / "client.ovpn").read_bytes())

        request_id = str(uuid.uuid4())
        request = {
            "schemaVersion": 1,
            "action": "rollback",
            "requestId": request_id,
            "submittedAt": "2026-09-18T00:01:00.000Z",
        }
        (manager.inbox / f"{request_id}.request.json").write_text(json.dumps(request))
        manager.process_once()
        self.assertIn(b"10.0.0.1", (project / "vpn" / "client.ovpn").read_bytes())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "rolled_back")
        state = json.loads(manager.state_file.read_text())
        reverse_backup = project / state["rollbackBackup"]
        self.assertIn(b"10.0.0.2", (reverse_backup / "client.ovpn").read_bytes())


    def test_wireguard_parser_canonicalizes_dual_stack_and_rejects_unsafe_surface(self):
        parsed = parse_wireguard_profile(wireguard(endpoint="[2001:4860:4860::8888]:51820"))
        self.assertEqual(parsed["vpnProtocol"], "wireguard")
        self.assertEqual(parsed["transport"], "udp")
        self.assertEqual(parsed["endpointFamily"], "ipv6")
        self.assertEqual(parsed["tunnelFamilies"], ["ipv4", "ipv6"])
        self.assertIn("AllowedIPs = 0.0.0.0/0, ::/0", parsed["content"])
        self.assertNotIn("DNS =", parsed["content"])
        self.assertEqual(len(parsed["fingerprint"]), 64)

        with self.assertRaisesRegex(ValueError, "hook.*forbidden"):
            parse_wireguard_profile(wireguard() + b"PostUp = curl bad.example\n")
        with self.assertRaisesRegex(ValueError, "Split-tunnel"):
            parse_wireguard_profile(wireguard(dual_stack=False, allowed_ips="10.0.0.0/8"))
        with self.assertRaisesRegex(ValueError, r"exactly one \[Peer\]"):
            parse_wireguard_profile(wireguard() + f"\n[Peer]\nPublicKey = {WG_PUBLIC_KEY}\n".encode())
        with self.assertRaisesRegex(ValueError, "IPv4 interface address"):
            parse_wireguard_profile(
                wireguard().replace(b"10.2.0.2/32, ", b"")
            )

    def test_successful_wireguard_transaction_keeps_secrets_out_of_env_and_status(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        request_id = self.queue_apply(manager, wireguard(), "wireguard")
        self.assertTrue(manager.process_once())

        self.assertEqual((project / "vpn" / "client.ovpn").read_bytes(), b"")
        self.assertEqual((project / "vpn" / "client.gluetun.ovpn").read_bytes(), b"")
        canonical = (project / "vpn" / "wireguard.conf").read_text()
        secret = (project / "vpn" / "wg0.conf").read_text()
        active_env = (project / "vpn" / "active.env").read_text()
        self.assertIn(WG_PRIVATE_KEY, canonical)
        self.assertIn(WG_PRIVATE_KEY, secret)
        self.assertIn(WG_PRESHARED_KEY, secret)
        self.assertNotIn(WG_PUBLIC_KEY, secret)
        self.assertNotIn("Endpoint", secret)
        self.assertIn("VPN_TYPE=wireguard", active_env)
        self.assertIn(WG_PUBLIC_KEY, active_env)
        self.assertIn("WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL=25s", active_env)
        self.assertNotIn("WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL=25\n", active_env)
        self.assertNotIn(WG_PRIVATE_KEY, active_env)
        self.assertNotIn(WG_PRESHARED_KEY, active_env)
        self.assertEqual(manager.parse_active_env()["WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL"], "25s")
        with self.assertRaisesRegex(ValueError, "seconds with an s suffix"):
            manager.parse_active_env(active_env.replace("=25s\n", "=25\n").encode())
        legacy_zero = active_env.replace("=25s\n", "=0\n").encode()
        self.assertEqual(manager.parse_active_env(legacy_zero)["WIREGUARD_PERSISTENT_KEEPALIVE_INTERVAL"], "0")
        self.assertEqual(manager.egress_families, [4, 6])

        status_text = manager.status_file.read_text()
        self.assertNotIn(WG_PRIVATE_KEY, status_text)
        self.assertNotIn(WG_PRESHARED_KEY, status_text)
        self.assertNotIn(WG_PUBLIC_KEY, status_text)
        status = json.loads(status_text)
        self.assertEqual(status["state"], "applied")
        self.assertEqual(status["requestId"], request_id)
        self.assertEqual(status["activeProfile"]["vpnProtocol"], "wireguard")
        self.assertEqual(status["activeProfile"]["tunnelFamilies"], ["ipv4", "ipv6"])

        for name in RUNTIME_FILES:
            mode = stat.S_IMODE((project / "vpn" / name).stat().st_mode)
            self.assertEqual(mode, 0o600, name)

    def test_ipv4_only_wireguard_runs_only_ipv4_egress_probe(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        self.queue_apply(manager, wireguard(dual_stack=False), "wireguard")
        manager.process_once()
        self.assertEqual(manager.egress_families, [4])
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "applied")
        self.assertEqual(status["activeProfile"]["tunnelFamilies"], ["ipv4"])

    def test_failed_wireguard_activation_restores_complete_openvpn_runtime(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project, fail_first_apply=True)
        old_runtime = {name: (project / "vpn" / name).read_bytes() for name in RUNTIME_FILES}
        self.queue_apply(manager, wireguard(), "wireguard")
        manager.process_once()
        restored = {name: (project / "vpn" / name).read_bytes() for name in RUNTIME_FILES}
        self.assertEqual(restored, old_runtime)
        self.assertEqual(manager.active_protocol(), "openvpn")
        self.assertFalse(manager.transaction_file.exists())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "rolled_back")

    def test_cross_protocol_manual_rollback_restores_wireguard_and_is_reversible(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        self.queue_apply(manager, wireguard(), "wireguard")
        manager.process_once()
        self.assertEqual(manager.active_protocol(), "wireguard")

        rollback_id = str(uuid.uuid4())
        rollback = {
            "schemaVersion": 2,
            "action": "rollback",
            "requestId": rollback_id,
            "submittedAt": "2026-09-18T00:01:00.000Z",
        }
        (manager.inbox / f"{rollback_id}.request.json").write_text(json.dumps(rollback))
        manager.process_once()
        self.assertEqual(manager.active_protocol(), "openvpn")
        self.assertIn(b"10.0.0.1", (project / "vpn" / "client.ovpn").read_bytes())

        reverse_id = str(uuid.uuid4())
        rollback["requestId"] = reverse_id
        (manager.inbox / f"{reverse_id}.request.json").write_text(json.dumps(rollback))
        manager.process_once()
        self.assertEqual(manager.active_protocol(), "wireguard")
        self.assertIn(WG_PRIVATE_KEY, (project / "vpn" / "wireguard.conf").read_text())

    def test_interrupted_install_is_recovered_before_another_request(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        request_id = str(uuid.uuid4())
        backup = manager.make_backup(request_id)
        with tempfile.TemporaryDirectory(dir=project / "vpn") as temporary_stage:
            files, _metadata = manager.stage_candidate("wireguard", wireguard(), Path(temporary_stage))
        manager.write_transaction(
            phase="installing",
            requestId=request_id,
            recoveryBackup=str(backup.relative_to(project)),
            targetProtocol="wireguard",
        )
        manager.install_runtime_files(files)
        self.assertEqual(manager.active_protocol(), "wireguard")

        self.assertFalse(manager.process_once())
        self.assertEqual(manager.active_protocol(), "openvpn")
        self.assertFalse(manager.transaction_file.exists())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "rolled_back")
        self.assertIn("interrupted", status["message"].lower())

    def test_finalize_install_path_uses_complete_journaled_backup(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        source = project / "initial.conf"
        source.write_bytes(wireguard())

        metadata = manager.install_profile_without_start(source)

        self.assertEqual(metadata["vpnProtocol"], "wireguard")
        self.assertEqual(manager.active_protocol(), "wireguard")
        self.assertFalse(manager.transaction_file.exists())
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "prepared")
        self.assertTrue(status["canRollback"])
        state = json.loads(manager.state_file.read_text())
        backup = project / state["rollbackBackup"]
        manifest = json.loads((backup / "manifest.json").read_text())
        self.assertEqual(set(manifest["files"]), set(RUNTIME_FILES))
        self.assertIn(b"10.0.0.1", (backup / "client.ovpn").read_bytes())

    def test_interrupted_initial_prepare_recovers_coherent_no_profile_state(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        project = Path(temporary.name)
        (project / "vpn").mkdir()
        (project / "compose.vpn.yml").write_text("services: {}\n")
        prepare = project / "vpn" / "prepare-profile.sh"
        prepare.write_text("#!/bin/sh\nexit 0\n")
        manager = FakeManager(project)
        request_id = str(uuid.uuid4())
        backup = manager.make_backup(request_id, "before-finalize")
        with tempfile.TemporaryDirectory(dir=project / "vpn") as temporary_stage:
            files, _metadata = manager.stage_candidate("wireguard", wireguard(), Path(temporary_stage))
        manager.write_transaction(
            phase="installing",
            requestId=request_id,
            recoveryBackup=str(backup.relative_to(project)),
            targetProtocol="wireguard",
            recreateAfterRestore=False,
        )
        manager.install_runtime_files(files)

        self.assertTrue(manager.recover_interrupted_transaction())
        self.assertEqual(manager.active_protocol(), "openvpn")
        self.assertFalse(manager.has_active_profile())
        self.assertFalse(manager.transaction_file.exists())
        self.assertEqual(manager.up_calls, 0)
        status = json.loads(manager.status_file.read_text())
        self.assertEqual(status["state"], "failed")
        self.assertIn("no profile is active", status["message"].lower())

    def test_schema_one_openvpn_backup_from_predecessor_remains_rollback_compatible(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        legacy = manager.backups / f"20260918T000000Z-{uuid.uuid4()}-legacy"
        legacy.mkdir(mode=0o700)
        (legacy / "client.ovpn").write_bytes(profile("10.10.10.1"))
        (legacy / "client.gluetun.ovpn").write_bytes(profile("10.10.10.1"))
        (legacy / "manifest.json").write_text(json.dumps({"schemaVersion": 1}))

        self.queue_apply(manager, wireguard(), "wireguard")
        manager.process_once()
        manager.restore_backup_files(legacy)
        self.assertEqual(manager.active_protocol(), "openvpn")
        self.assertIn(b"10.10.10.1", (project / "vpn" / "client.gluetun.ovpn").read_bytes())
        self.assertEqual((project / "vpn" / "wireguard.conf").read_bytes(), b"")

    def test_backup_hash_tampering_is_rejected_before_runtime_changes(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        backup = manager.make_backup(str(uuid.uuid4()))
        (backup / "client.ovpn").write_bytes(profile("10.99.99.99"))
        before = {name: (project / "vpn" / name).read_bytes() for name in RUNTIME_FILES}
        with self.assertRaisesRegex(RuntimeError, "integrity"):
            manager.restore_backup_files(backup)
        after = {name: (project / "vpn" / name).read_bytes() for name in RUNTIME_FILES}
        self.assertEqual(after, before)

    def test_status_error_scrubber_removes_wireguard_keys(self):
        temporary, project = self.make_project()
        self.addCleanup(temporary.cleanup)
        manager = FakeManager(project)
        manager.write_status(
            "failed",
            "safe message",
            error=f"PrivateKey = {WG_PRIVATE_KEY}; PresharedKey={WG_PRESHARED_KEY}",
        )
        text = manager.status_file.read_text()
        self.assertNotIn(WG_PRIVATE_KEY, text)
        self.assertNotIn(WG_PRESHARED_KEY, text)
        self.assertIn("redacted", text)


if __name__ == "__main__":
    unittest.main()
