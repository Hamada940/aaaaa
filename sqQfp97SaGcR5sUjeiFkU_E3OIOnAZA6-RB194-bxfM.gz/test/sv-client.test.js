'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter, once } = require('events');
const { SmartVinerClient, sanitizeStoredAuth } = require('../lib/sv-client');

const ACCESS = 'a'.repeat(40), REFRESH = 'r'.repeat(40), NEW_ACCESS = 'b'.repeat(40), NEW_REFRESH = 's'.repeat(40);
const ACCOUNT = { id: 42, marketplace_id: 'ATVPDKIKX0DER', name: 'Member', email: 'member@example.test' };
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const quietLogger = { log() {}, warn() {}, error() {} };
function jsonResponse(status, body) { return { status, data: JSON.stringify(body), headers: { 'content-type': 'application/json' } }; }

class FakeWebSocket extends EventEmitter {
  static instances = [];
  constructor(url, options) {
    super(); this.url = url; this.options = options; this.readyState = 0; this.sent = [];
    FakeWebSocket.instances.push(this);
    queueMicrotask(() => { if (this.readyState === 0) { this.readyState = 1; this.emit('open'); } });
  }
  send(value) { this.sent.push(JSON.parse(value)); }
  close(code = 1000, reason = '') {
    if (this.readyState === 3) return;
    this.readyState = 3;
    queueMicrotask(() => this.emit('close', code, Buffer.from(reason)));
  }
}

function validStoredAuth() {
  return {
    schemaVersion: 1, installId: 'install-test-1234', apiOrigin: 'https://attacker.invalid',
    accessToken: ACCESS, accessExp: Date.now() + 3600_000,
    refreshToken: REFRESH, refreshExp: Date.now() + 86400_000,
    account: { id: 42, marketplaceId: 'ATVPDKIKX0DER', name: 'Member', emailHint: 'me***@example.test' }
  };
}

test('HTTP request gate rejects unreviewed paths and alternate origins before Axios', async () => {
  let calls = 0;
  const client = new SmartVinerClient({ axios: { request: async () => { calls += 1; return jsonResponse(200, {}); } }, logger: quietLogger });
  await assert.rejects(client._requestJson('https://smartviner.com/api/v1/feed/discoveries'), /not allowlisted/i);
  await assert.rejects(client._requestJson('https://smartviner.com/api/v1/me?extra=1'), /not allowlisted/i);
  await assert.rejects(client._requestJson('https://example.test/api/v1/me'), /not allowlisted/i);
  await assert.rejects(client._requestJson('https://smartviner.com/api/v1/me', { method: 'POST' }), /not allowlisted/i);
  await assert.rejects(client._requestJson('https://smartviner.com/api/v1/auth/login'), /not allowlisted/i);
  await assert.rejects(client._requestJson('https://user@smartviner.com/api/v1/me'), /not allowlisted/i);
  assert.equal(calls, 0);
});

test('stored authentication is pinned to SmartViner and rejects malformed tokens and null expiries', () => {
  const clean = sanitizeStoredAuth(validStoredAuth());
  assert.equal(clean.apiOrigin, 'https://smartviner.com');
  assert.equal(clean.accessToken, ACCESS);
  const malformed = sanitizeStoredAuth({ installId: 'valid-id-123', accessToken: 'short', refreshToken: 'short', accessExp: null });
  assert.equal(malformed.accessToken, null);
  assert.equal(malformed.refreshToken, null);
  assert.equal(malformed.accessExp, null);
});

test('onboarding verifies the account atomically and never persists the password', async () => {
  const saved = [];
  const client = new SmartVinerClient({
    axios: { request: async options => {
      assert.ok(options.url.endsWith('/auth/login'));
      const body = JSON.parse(options.data);
      assert.equal(body.password, 'top secret local password');
      return jsonResponse(200, { access_token: ACCESS, refresh_token: REFRESH, user: ACCOUNT });
    } },
    loadAuth: () => ({ installId: 'install-test-1234' }),
    saveAuth: value => saved.push(JSON.parse(JSON.stringify(value))),
    isEnabled: () => false, logger: quietLogger
  });
  await client.initialize();
  const result = await client.onboard({ email: 'member@example.test', password: 'top secret local password' });
  assert.equal(result.account.id, 42);
  assert.equal(saved.at(-1).accessToken, ACCESS);
  assert.doesNotMatch(JSON.stringify(saved), /top secret local password|member@example\.test/);
  assert.equal(client.publicStatus().accessToken, undefined);
  assert.equal(client.publicStatus().channel, 'private-alerts.marketplace.ATVPDKIKX0DER');
  client.shutdown();
});

test('failed onboarding leaves the existing working account unchanged', async () => {
  const client = new SmartVinerClient({
    axios: { request: async () => jsonResponse(401, { message: 'bad credentials' }) },
    loadAuth: validStoredAuth, saveAuth: () => {}, isEnabled: () => false, logger: quietLogger
  });
  await client.initialize();
  await assert.rejects(client.onboard({ email: 'member@example.test', password: 'wrong' }), /sign-in failed/i);
  assert.equal(client.auth.accessToken, ACCESS);
  assert.equal(client.auth.account.id, 42);
  client.shutdown();
});

test('failed session persistence rolls an otherwise successful replacement back', async () => {
  const client = new SmartVinerClient({
    axios: { request: async () => jsonResponse(200, { access_token: NEW_ACCESS, refresh_token: NEW_REFRESH, user: { ...ACCOUNT, id: 77 } }) },
    loadAuth: validStoredAuth,
    saveAuth: value => { if (value.accessToken === NEW_ACCESS) throw new Error('disk unavailable'); },
    isEnabled: () => false, logger: quietLogger
  });
  await client.initialize();
  await assert.rejects(client.onboard({ email: 'replacement@example.test', password: 'one time' }), /disk unavailable/i);
  assert.equal(client.auth.accessToken, ACCESS);
  assert.equal(client.auth.account.id, 42);
  client.shutdown();
});

test('access-token refresh is single-flight and preserves a rotating refresh token atomically', async () => {
  let refreshCalls = 0;
  const saved = [];
  const expired = { ...validStoredAuth(), accessExp: Date.now() - 1000 };
  const client = new SmartVinerClient({
    axios: { request: async options => {
      assert.ok(options.url.endsWith('/auth/refresh'));
      refreshCalls += 1;
      await wait(10);
      return jsonResponse(200, { access_token: NEW_ACCESS });
    } },
    loadAuth: () => expired,
    saveAuth: value => saved.push(JSON.parse(JSON.stringify(value))),
    isEnabled: () => false,
    logger: quietLogger
  });
  await client.initialize();
  const [left, right] = await Promise.all([client._accessToken(), client._accessToken()]);
  assert.equal(left, NEW_ACCESS);
  assert.equal(right, NEW_ACCESS);
  assert.equal(refreshCalls, 1);
  assert.equal(client.auth.refreshToken, REFRESH);
  assert.equal(saved.at(-1).accessToken, NEW_ACCESS);
  client.shutdown();
});

test('a late failed refresh from an old account cannot erase a replacement session', async () => {
  let releaseRefresh;
  let refreshStarted;
  const started = new Promise(resolve => { refreshStarted = resolve; });
  const refreshResponse = new Promise(resolve => { releaseRefresh = resolve; });
  const client = new SmartVinerClient({
    axios: { request: async options => {
      if (options.url.endsWith('/auth/refresh')) {
        refreshStarted();
        return refreshResponse;
      }
      if (options.url.endsWith('/auth/login')) {
        return jsonResponse(200, {
          access_token: NEW_ACCESS,
          refresh_token: NEW_REFRESH,
          user: { ...ACCOUNT, id: 77, email: 'replacement@example.test' }
        });
      }
      throw new Error('unexpected request');
    } },
    loadAuth: validStoredAuth,
    saveAuth: () => {},
    isEnabled: () => false,
    logger: quietLogger
  });
  await client.initialize();
  const oldRefresh = client._refreshAccessToken();
  await started;
  await client.onboard({ email: 'replacement@example.test', password: 'one time only' });
  releaseRefresh(jsonResponse(401, { message: 'old refresh expired' }));
  await assert.rejects(oldRefresh, /account changed during refresh/i);
  assert.equal(client.auth.accessToken, NEW_ACCESS);
  assert.equal(client.auth.refreshToken, NEW_REFRESH);
  assert.equal(client.auth.account.id, 77);
  assert.equal(client.authBlocked, false);
  client.shutdown();
});

test('client authorizes the private channel and emits only normalized live items', async () => {
  FakeWebSocket.instances = [];
  const requests = [];
  const client = new SmartVinerClient({
    axios: { request: async options => {
      requests.push(options);
      if (options.url.endsWith('/api/v1/me')) return jsonResponse(200, ACCOUNT);
      if (options.url.endsWith('/broadcasting/auth')) return jsonResponse(200, { auth: 'public:signature' });
      throw new Error('unexpected request');
    } },
    WebSocket: FakeWebSocket, loadAuth: validStoredAuth, saveAuth: () => {}, isEnabled: () => true,
    logger: quietLogger, random: () => 0.5
  });
  const itemPromise = once(client, 'item');
  await client.initialize(); await wait(20);
  const ws = FakeWebSocket.instances[0];
  ws.emit('message', JSON.stringify({ event: 'pusher:connection_established', data: JSON.stringify({ socket_id: '123.456' }) }));
  await wait(20);
  const subscribe = ws.sent.find(frame => frame.event === 'pusher:subscribe');
  assert.equal(subscribe.data.channel, 'private-alerts.marketplace.ATVPDKIKX0DER');
  ws.emit('message', JSON.stringify({ event: 'pusher_internal:subscription_succeeded', channel: subscribe.data.channel, data: '{}' }));
  ws.emit('message', JSON.stringify({ event: 'ChatMessage', channel: subscribe.data.channel, data: '{}' }));
  ws.emit('message', JSON.stringify({
    event: 'RfyItemDiscovered', channel: subscribe.data.channel,
    data: JSON.stringify({ userId: 42, product: { asin: 'B000000099', title: 'Blocked personal RFY' } })
  }));
  ws.emit('message', JSON.stringify({ event: 'NewGlobalItemDiscovered', channel: subscribe.data.channel, data: JSON.stringify({ _queueType: 'encore', product: { asin: 'B000000004', title: 'Live SmartViner item', marketplace_id: 'ATVPDKIKX0DER' } }) }));
  const [item, meta] = await itemPromise;
  assert.equal(item.asin, 'B000000004');
  assert.equal(item.queueType, 'AI');
  assert.equal(meta.source, 'SV');
  assert.equal(client.publicStatus().state, 'healthy');
  assert.equal(client.publicStatus().personalRfyEnabled, false);
  assert.deepEqual(client.publicStatus().allowedEvents, ['NewGlobalItemDiscovered']);
  assert.deepEqual(client.publicStatus().blockedPersonalEvents, ['RfyItemDiscovered']);
  assert.equal(requests.filter(request => request.url.endsWith('/broadcasting/auth')).length, 1);
  client.shutdown(); await wait(5);
});

test('a late account lookup cannot repopulate a disconnected session', async () => {
  FakeWebSocket.instances = [];
  let releaseMe;
  let meStarted;
  const started = new Promise(resolve => { meStarted = resolve; });
  const meResponse = new Promise(resolve => { releaseMe = resolve; });
  const client = new SmartVinerClient({
    axios: { request: async options => {
      if (options.url.endsWith('/api/v1/me')) { meStarted(); return meResponse; }
      throw new Error('unexpected request');
    } },
    WebSocket: FakeWebSocket,
    loadAuth: validStoredAuth,
    saveAuth: () => {},
    isEnabled: () => true,
    logger: quietLogger
  });
  await client.initialize();
  // The production reconnect timer is intentionally unref'd; keep this test's
  // event loop alive long enough for the zero-delay connection attempt.
  await wait(5);
  await started;
  await client.disconnectAccount();
  releaseMe(jsonResponse(200, ACCOUNT));
  await wait(20);
  assert.equal(client.auth.accessToken, null);
  assert.equal(client.auth.refreshToken, null);
  assert.equal(client.auth.account, null);
  assert.equal(FakeWebSocket.instances.length, 0);
  client.shutdown();
});

test('manual reconnect replaces an existing socket without requesting history', async () => {
  FakeWebSocket.instances = [];
  const client = new SmartVinerClient({
    axios: { request: async options => options.url.endsWith('/api/v1/me') ? jsonResponse(200, ACCOUNT) : Promise.reject(new Error('unexpected')) },
    WebSocket: FakeWebSocket, loadAuth: validStoredAuth, saveAuth: () => {}, isEnabled: () => true, logger: quietLogger
  });
  await client.initialize(); await wait(20);
  const first = FakeWebSocket.instances[0];
  await client.reconnect(); await wait(20);
  assert.equal(first.readyState, 3);
  assert.equal(FakeWebSocket.instances.length, 2);
  client.shutdown();
});

test('disconnect removes only SmartViner tokens while retaining the install identity', async () => {
  const saved = [];
  const client = new SmartVinerClient({ loadAuth: validStoredAuth, saveAuth: value => saved.push(JSON.parse(JSON.stringify(value))), isEnabled: () => false, logger: quietLogger });
  await client.initialize(); await client.disconnectAccount();
  assert.equal(saved.at(-1).installId, 'install-test-1234');
  assert.equal(saved.at(-1).accessToken, null);
  assert.equal(saved.at(-1).refreshToken, null);
  assert.equal(client.publicStatus().channel, null);
  assert.equal(client.publicStatus().lastLiveItemAt, null);
  client.shutdown();
});
