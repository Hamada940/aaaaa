'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  SOURCE_IDS,
  normalizeSourceId,
  normalizeSourceList,
  sourceQueueField,
  deriveLiveSources,
  liveMergeDecision,
  observeSource,
  sourceRaceSummary
} = require('../lib/source-registry');

test('source registry accepts only the three reviewed live sources', () => {
  assert.deepEqual(SOURCE_IDS, ['UV', 'VH', 'SV']);
  assert.equal(normalizeSourceId(' sv '), 'SV');
  assert.equal(normalizeSourceId('unknown'), null);
  assert.deepEqual(normalizeSourceList(['vh', 'SV', 'VH', 'bad', 'uv']), ['VH', 'SV', 'UV']);
  assert.equal(sourceQueueField('SV'), 'svQueue');
  assert.throws(() => sourceQueueField('bad'), /unsupported/i);
});

test('deriveLiveSources retains R23 compatibility and recognizes SmartViner clocks', () => {
  assert.deepEqual(deriveLiveSources({ liveSources: ['SV', 'UV'] }), ['SV', 'UV']);
  assert.deepEqual(deriveLiveSources({ live_uv_ms: 100, live_sv_ms: 200 }), ['UV', 'SV']);
  assert.deepEqual(deriveLiveSources({ sources: ['VH'], last_live_event_ms: 100 }), ['VH']);
  assert.deepEqual(deriveLiveSources({ sources: ['SV'], live_sv_ms: null, last_live_event_ms: null }), []);
  assert.deepEqual(deriveLiveSources({ sources: ['SV'], live_sv_ms: '' }), []);
});

test('every UV/VH/SV arrival order produces one first notification and silent confirmations', () => {
  const permutations = values => values.length === 1
    ? [values]
    : values.flatMap((value, index) =>
        permutations(values.filter((_, candidate) => candidate !== index)).map(rest => [value, ...rest])
      );
  for (const order of permutations(SOURCE_IDS)) {
    let item = null;
    let notifications = 0;
    order.forEach((source, index) => {
      const decision = liveMergeDecision(item, source, false);
      if (decision.notify) notifications += 1;
      item = {
        ...(item || {}),
        liveSources: decision.liveSources,
        sources: decision.liveSources,
        ...observeSource(item || {}, source, { nowMs: 1000 + index * 25, live: true })
      };
    });
    assert.equal(notifications, 1, order.join(' -> '));
    assert.deepEqual(new Set(item.sources), new Set(SOURCE_IDS));
    assert.equal(sourceRaceSummary(item).firstDiscoveredBy, order[0]);
  }
});

test('history promotion notifies once while later live confirmation stays silent', () => {
  const history = { sources: [], liveSources: [], historySources: ['SV'] };
  const promoted = liveMergeDecision(history, 'UV', false);
  assert.equal(promoted.promotedFromBackfill, true);
  assert.equal(promoted.notify, true);
  const confirmed = liveMergeDecision({ ...history, liveSources: ['UV'], live_uv_ms: 10 }, 'SV', false);
  assert.equal(confirmed.crossFeedConfirmation, true);
  assert.equal(confirmed.notify, false);
});

test('observeSource writes only missing source clocks and treats null as missing', () => {
  assert.deepEqual(observeSource({ live_sv_ms: null }, 'SV', { nowMs: 1234, live: true }), {
    discovered_sv_at: new Date(1234).toISOString(),
    discovered_sv_ms: 1234,
    live_sv_at: new Date(1234).toISOString(),
    live_sv_ms: 1234
  });
  assert.deepEqual(observeSource({ discovered_sv_ms: 100, live_sv_ms: 100 }, 'SV', { nowMs: 200 }), {});
  assert.deepEqual(observeSource({}, 'VH', { nowMs: 300, live: false }), {
    discovered_vh_at: new Date(300).toISOString(),
    discovered_vh_ms: 300
  });
});

test('three-source race reports first source, first-to-second lead, and all offsets', () => {
  const race = sourceRaceSummary({
    live_sv_ms: 1000,
    live_sv_at: new Date(1000).toISOString(),
    live_uv_ms: 1080,
    live_uv_at: new Date(1080).toISOString(),
    live_vh_ms: 1240,
    live_vh_at: new Date(1240).toISOString()
  });
  assert.equal(race.firstDiscoveredBy, 'SV');
  assert.equal(race.firstDiscoveredMs, 1000);
  assert.equal(race.leadMs, 80);
  assert.deepEqual(race.sourceArrivalOrder, ['SV', 'UV', 'VH']);
  assert.deepEqual(race.sourceLeadMs, { SV: 0, UV: 80, VH: 240 });
});

test('two-source race preserves R23 lead semantics', () => {
  const race = sourceRaceSummary({ live_vh_ms: 20, live_uv_ms: 65 });
  assert.equal(race.firstDiscoveredBy, 'VH');
  assert.equal(race.leadMs, 45);
  assert.deepEqual(race.sourceArrivalOrder, ['VH', 'UV']);
});

test('same-millisecond confirmations cannot rewrite the genuine first source', () => {
  const race = sourceRaceSummary({
    liveSources: ['SV', 'UV', 'VH'],
    sources: ['SV', 'UV', 'VH'],
    live_sv_ms: 1000,
    live_uv_ms: 1000,
    live_vh_ms: 1000
  });
  assert.equal(race.firstDiscoveredBy, 'SV');
  assert.deepEqual(race.sourceArrivalOrder, ['SV', 'UV', 'VH']);
  assert.equal(race.leadMs, 0);
  assert.deepEqual(race.sourceLeadMs, { SV: 0, UV: 0, VH: 0 });
});

test('a backward wall-clock correction cannot steal first-source provenance', () => {
  const race = sourceRaceSummary({
    firstDiscoveredBy: 'VH',
    sourceArrivalOrder: ['VH'],
    liveSources: ['VH', 'SV'],
    live_vh_ms: 2000,
    live_sv_ms: 1900
  });
  assert.equal(race.firstDiscoveredBy, 'VH');
  assert.deepEqual(race.sourceArrivalOrder, ['VH', 'SV']);
  assert.equal(race.leadMs, 0);
  assert.deepEqual(race.sourceLeadMs, { VH: 0, SV: 0 });
});
