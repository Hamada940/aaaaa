'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  SV_API_BASE, SV_LIVE_EVENTS, SV_BLOCKED_PERSONAL_EVENTS, SV_HEARTBEAT_EVENT,
  normalizeTokenBundle, sanitizeAccount, smartVinerChannel, smartVinerWsUrl,
  normalizeBroadcastAuth, parsePusherFrame, normalizeSvLiveEvent,
  reconnectDelay, redactSmartVinerError
} = require('../lib/sv-protocol');

const ACCESS = 'a'.repeat(40);
const REFRESH = 'r'.repeat(40);

test('SmartViner protocol pins the statically reviewed production contract', () => {
  assert.equal(SV_API_BASE, 'https://smartviner.com/api/v1');
  assert.equal(smartVinerWsUrl(), 'wss://smartviner.com:443/app/s4wdexm1oqwqaejnytze?protocol=7&client=js&version=8.4.0');
  assert.equal(smartVinerChannel('ATVPDKIKX0DER'), 'private-alerts.marketplace.ATVPDKIKX0DER');
  assert.deepEqual(SV_LIVE_EVENTS, ['NewGlobalItemDiscovered']);
  assert.deepEqual(SV_BLOCKED_PERSONAL_EVENTS, ['RfyItemDiscovered']);
  assert.equal(SV_HEARTBEAT_EVENT, 'AlertsHeartbeat');
  assert.throws(() => smartVinerChannel('../bad'), /invalid/i);
});

test('token bundles are bounded and preserve an existing refresh token on rotation', () => {
  const now = Date.parse('2026-11-02T12:00:00Z');
  const bundle = normalizeTokenBundle({ access_token: ACCESS }, now, REFRESH);
  assert.equal(bundle.accessToken, ACCESS);
  assert.equal(bundle.refreshToken, REFRESH);
  assert.ok(bundle.accessExp > now);
  assert.throws(() => normalizeTokenBundle({ access_token: 'short' }, now), /invalid access token/i);
  assert.throws(() => normalizeTokenBundle({ access_token: `${'x'.repeat(20)} bad` }, now), /invalid access token/i);
});

test('account responses expose only bounded identity metadata', () => {
  assert.deepEqual(sanitizeAccount({ id: 42, marketplace_id: 'atvpdkikx0der', name: 'Member', email: 'member@example.test', payment: 'discard' }), {
    id: 42, marketplaceId: 'ATVPDKIKX0DER', name: 'Member', emailHint: 'me***@example.test'
  });
  assert.throws(() => sanitizeAccount({ id: 42 }), /missing identity or marketplace/i);
});

test('private-channel authorization accepts only the expected unencrypted response', () => {
  assert.deepEqual(normalizeBroadcastAuth({ auth: 'public:signature' }), { auth: 'public:signature' });
  assert.throws(() => normalizeBroadcastAuth({ shared_secret: 'x', auth: 'a' }), /encrypted/i);
  assert.throws(() => normalizeBroadcastAuth({}), /invalid/i);
});

test('Pusher frames decode global data but discard personalized RFY inner payloads', () => {
  assert.deepEqual(parsePusherFrame(JSON.stringify({ event: 'NewGlobalItemDiscovered', channel: 'private-alerts.marketplace.ATVPDKIKX0DER', data: JSON.stringify({ product: { asin: 'B000000001' } }) })).data, { product: { asin: 'B000000001' } });
  const blocked = parsePusherFrame(JSON.stringify({
    event: 'RfyItemDiscovered',
    channel: 'private-alerts.marketplace.ATVPDKIKX0DER',
    data: JSON.stringify({ product: { asin: 'B000000099', secretMarker: 'must-not-parse' } })
  }));
  assert.equal(blocked.blockedPersonal, true);
  assert.equal(blocked.data, null);
  assert.doesNotMatch(JSON.stringify(blocked), /B000000099|must-not-parse/);
  assert.equal(parsePusherFrame('not-json'), null);
});

test('global discovery normalizes only allowlisted product fields', () => {
  const item = normalizeSvLiveEvent({
    event: 'NewGlobalItemDiscovered', accountId: 42, marketplaceId: 'ATVPDKIKX0DER',
    payload: { id: 99, _queueType: 'VENDOR_VINE_FOR_ALL', product: {
      asin: 'b000000002', title: ' Live product ', marketplace_id: 'ATVPDKIKX0DER',
      image: 'https://images.example/item.jpg', images: ['https://images.example/two.jpg', 'javascript:alert(1)'],
      amounts: { etv_amount: '0.00', retail_amount: '45.99' }, privateAccountData: 'discard'
    } }
  });
  assert.equal(item.asin, 'B000000002');
  assert.equal(item.queueType, 'AFA');
  assert.equal(item.etv, 0);
  assert.equal(item.price, 45.99);
  assert.deepEqual(item.additional_img, ['https://images.example/two.jpg']);
  assert.equal(item.privateAccountData, undefined);
});

test('personalized RFY and RFY-shaped global discoveries are always rejected', () => {
  const base = { event: 'RfyItemDiscovered', accountId: 42, marketplaceId: 'ATVPDKIKX0DER' };
  assert.equal(normalizeSvLiveEvent({ ...base, payload: { userId: 42, product: { asin: 'B000000003', title: 'Mine' } } }), null);
  assert.equal(normalizeSvLiveEvent({ ...base, payload: { userId: 99, product: { asin: 'B000000003', title: 'Not mine' } } }), null);
  assert.equal(normalizeSvLiveEvent({
    event: 'NewGlobalItemDiscovered', accountId: 42, marketplaceId: 'ATVPDKIKX0DER',
    payload: { _queueType: 'RFY', product: { asin: 'B000000003', title: 'Unscoped RFY' } }
  }), null);
});

test('malformed, unrelated and oversized SmartViner events are rejected', () => {
  const args = { accountId: 42, marketplaceId: 'ATVPDKIKX0DER' };
  assert.equal(normalizeSvLiveEvent({ ...args, event: 'ChatMessage', payload: {} }), null);
  assert.equal(normalizeSvLiveEvent({ ...args, event: 'NewGlobalItemDiscovered', payload: { product: { asin: 'bad' } } }), null);
  assert.equal(normalizeSvLiveEvent({ ...args, event: 'NewGlobalItemDiscovered', payload: { pad: 'x'.repeat(300 * 1024), product: { asin: 'B000000004' } } }), null);
});

test('reconnect backoff is immediate then bounded with jitter', () => {
  assert.equal(reconnectDelay(0, () => 0.5), 0);
  assert.equal(reconnectDelay(1, () => 0.5), 500);
  assert.equal(reconnectDelay(999, () => 1), 12000);
});

test('diagnostic errors redact bearer, token query values, password fields and email', () => {
  const bare = 'z'.repeat(48);
  const text = redactSmartVinerError(`Bearer ${ACCESS} https://x.test?a=1&token=${REFRESH} member@example.test password=hunter2 bare ${bare}`);
  assert.doesNotMatch(text, new RegExp(ACCESS));
  assert.doesNotMatch(text, new RegExp(REFRESH));
  assert.doesNotMatch(text, new RegExp(bare));
  assert.doesNotMatch(text, /member@example\.test|hunter2/);
  assert.match(text, /redacted/i);
});
