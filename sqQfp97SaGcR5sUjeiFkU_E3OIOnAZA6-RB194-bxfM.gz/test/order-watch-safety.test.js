'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { signedEnvelope } = require('../lib/order-protocol');
const {
  OrderCoordinator,
  LIVE_PRICE_COMPLETION_WINDOW_MS,
  SAFETY_CIRCUIT_REASON_CODES
} = require('../lib/order-coordinator');
const {
  ORDER_SAFETY_ACK_CONFIRMATION,
  ORDER_AUTOMATION_RESUME_CONFIRMATION
} = require('../lib/order-safety');
const { normalizeWatchStore } = require('../lib/order-watches');

class FakeSocket {
  constructor() {
    this.readyState = 1;
    this.sent = [];
    this.closed = null;
  }
  send(value) { this.sent.push(JSON.parse(value)); }
  close(code, reason) {
    this.closed = { code, reason };
    this.readyState = 3;
  }
}

function harness() {
  const files = new Map();
  const events = [];
  let now = 1_800_000_000_000;
  const coordinator = new OrderCoordinator({
    pairingFile: '/pairing',
    rulesFile: '/rules',
    jobsFile: '/jobs',
    watchesFile: '/watches',
    safetyFile: '/safety',
    loadJSON: (file, fallback) => files.has(file) ? structuredClone(files.get(file)) : fallback,
    saveJSON: (file, value) => files.set(file, structuredClone(value)),
    onEvent: (type, data) => events.push({ type, data }),
    now: () => now
  });
  return {
    coordinator,
    files,
    events,
    get now() { return now; },
    set now(value) { now = value; },
    advance(ms) { now += ms; }
  };
}

function connect(h, { accountHash = 'a'.repeat(64), exactVariantSelection = true } = {}) {
  const pairing = h.coordinator.issuePairing();
  const socket = new FakeSocket();
  h.coordinator.attachSocket(socket);
  const challenge = socket.sent.at(-1).payload.challenge;
  const hello = {
    challenge,
    timestampMs: h.now,
    nonce: `hello-${Math.random().toString(36).slice(2)}-123456`,
    accountHash,
    agentId: 'windows-test-agent',
    agentVersion: '25.0.4',
    capabilities: {
      fastCheckout: true,
      localApproval: true,
      firstAvailableVariant: true,
      exactVariantSelection,
      currency: 'CAD'
    }
  };
  assert.equal(h.coordinator.handleSocketMessage(
    socket,
    JSON.stringify(signedEnvelope(pairing.pairingSecret, 'agent_hello', hello))
  ).ok, true);
  return { pairing, socket };
}

function item(asin, overrides = {}) {
  return {
    asin,
    title: `Live item ${asin}`,
    queue: 'AI',
    enrollmentGuid: `enrollment-${asin}`,
    price: 20,
    etv: 0,
    liveSources: ['VH'],
    firstDiscoveredMs: 1_800_000_000_000,
    ...overrides
  };
}

function observation(h, currentItem, overrides = {}) {
  return {
    queue: currentItem.queue,
    confidence: 'explicit',
    observedAtMs: h.now,
    source: 'VH',
    isBackfill: false,
    watchOnly: true,
    liveEventItem: { ...currentItem },
    ...overrides
  };
}

function enableCatchAllRule(h, overrides = {}) {
  return h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    rollingMaxAutomaticPlacements: null,
    rollingMaxAutomaticCharge: null,
    rules: [{
      id: 'catch-all-rule',
      name: 'Any priced live item',
      enabled: true,
      action: 'auto',
      logic: 'price_only',
      priceField: 'retail',
      priceOperator: 'at_least',
      priceMinimum: 0
    }],
    ...overrides
  });
}

function sendResult(h, socket, secret, job, state, overrides = {}) {
  const payload = {
    jobId: job.jobId,
    state,
    nonce: `result-${Math.random().toString(36).slice(2)}-123456`,
    eventAtMs: h.now,
    asin: job.asin,
    ...overrides
  };
  return h.coordinator.handleSocketMessage(
    socket,
    JSON.stringify(signedEnvelope(secret, 'agent_result', payload))
  );
}

test('one bounded VH price enrichment completes an event-time AND rule with only isolated original metadata', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000150';
  h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    rules: [{
      id: 'delayed-power-rule',
      name: 'Power station over C$249',
      enabled: true,
      action: 'auto',
      logic: 'and',
      words: ['power station'],
      excludedWords: [],
      wordMode: 'any',
      textMatchMode: 'whole_word',
      priceField: 'either',
      priceOperator: 'at_least',
      priceMinimum: 249,
      queues: ['AI'],
      sources: []
    }]
  });
  const original = item(asin, {
    title: 'Krisdonia portable power station',
    queue: 'AI',
    price: 'N/A',
    etv: 'N/A',
    enrollmentGuid: 'original-live-enrollment',
    liveSources: ['UV'],
    unavailable: true
  });
  const initial = h.coordinator.dispatchForLiveItem(original, observation(h, original, {
    source: 'UV',
    watchOnly: false,
    allowDelayedPriceCompletion: true,
    feedUnavailableAdvisory: true
  }));
  assert.equal(initial.skipped, true);
  assert.equal(initial.reason, 'no matching enabled rule');
  assert.equal(h.coordinator.recentJobs().length, 0);

  h.advance(27_000);
  const merged = item(asin, {
    title: 'Mutated merged title must not enter the order job',
    queue: 'RFY',
    price: 399.99,
    etv: 'N/A',
    enrollmentGuid: 'stale-merged-enrollment',
    img_url: 'https://stale.invalid/merged.jpg',
    liveSources: ['UV', 'VH'],
    unavailable: true
  });
  const outcome = h.coordinator.dispatchForDelayedPriceCompletion(merged, {
    asin,
    source: 'VH',
    eventType: 'newPrice',
    receivedAtMs: h.now,
    price: 'C$399.99'
  });
  assert.equal(outcome.ok, true);
  const orderMessages = socket.sent.filter(message => message.type === 'order_job');
  assert.equal(orderMessages.length, 1);
  const payload = orderMessages[0].payload;
  assert.equal(payload.policy.ruleId, 'delayed-power-rule');
  assert.equal(payload.item.title, 'Krisdonia portable power station');
  assert.equal(payload.item.queue, 'AI');
  assert.equal(payload.item.enrollmentGuid, 'original-live-enrollment');
  assert.equal(payload.item.price, 399.99);
  assert.equal(payload.item.etv, null);
  assert.deepEqual(payload.item.sources, ['UV']);
  assert.doesNotMatch(JSON.stringify(payload), /Mutated merged|stale-merged|stale\.invalid/);

  const duplicate = h.coordinator.dispatchForDelayedPriceCompletion(merged, {
    asin,
    source: 'VH',
    eventType: 'newPrice',
    receivedAtMs: h.now,
    price: 399.99
  });
  assert.equal(duplicate.skipped, true);
  assert.equal(duplicate.reason, 'no fresh event-linked price completion candidate');
  assert.equal(socket.sent.filter(message => message.type === 'order_job').length, 1);
});

test('UV detail and VH enrichment can fill distinct missing money fields but create only the first match', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000151';
  h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    rules: [{
      id: 'either-price-completion',
      name: 'Power station either price',
      enabled: true,
      action: 'auto',
      logic: 'and',
      words: ['power station'],
      textMatchMode: 'whole_word',
      priceField: 'either',
      priceOperator: 'at_least',
      priceMinimum: 249,
      queues: ['AI']
    }]
  });
  const original = item(asin, {
    title: 'Compact power station',
    price: 'N/A',
    etv: 'N/A',
    enrollmentGuid: 'event-enrollment-151',
    liveSources: ['VH'],
    unavailable: true
  });
  const initial = h.coordinator.dispatchForLiveItem(original, observation(h, original, {
    source: 'VH',
    watchOnly: false,
    allowDelayedPriceCompletion: true,
    feedUnavailableAdvisory: true
  }));
  assert.equal(initial.reason, 'no matching enabled rule');

  h.advance(1_000);
  const lowEtv = h.coordinator.dispatchForDelayedPriceCompletion(original, {
    asin,
    source: 'UV',
    eventType: 'alertDetail',
    receivedAtMs: h.now,
    etv: 0
  });
  assert.equal(lowEtv.skipped, true);
  assert.equal(lowEtv.reason, 'delayed price fields do not yet complete an enabled rule');
  assert.equal(h.coordinator.recentJobs().length, 0);

  h.advance(1_000);
  const matchedRetail = h.coordinator.dispatchForDelayedPriceCompletion(
    { ...original, price: 299.99, etv: 0, unavailable: true },
    {
      asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: h.now,
      price: 299.99
    }
  );
  assert.equal(matchedRetail.ok, true);
  assert.equal(socket.sent.filter(message => message.type === 'order_job').length, 1);
  assert.equal(socket.sent.filter(message => message.type === 'order_job')[0].payload.item.price, 299.99);
  assert.equal(socket.sent.filter(message => message.type === 'order_job')[0].payload.item.etv, 0);
});

test('delayed-price completion expires from original observation time, is destroyed by rule changes, and cannot borrow a merged title', () => {
  const makeCandidate = (asin, title = 'Event power station', observedAgeMs = 0) => {
    const h = harness();
    connect(h);
    h.coordinator.updateRuleSet({
      enabled: true,
      currency: 'CAD',
      unattendedCheckoutLimit: 30,
      rules: [{
        id: `bounded-rule-${asin}`,
        name: 'Bounded delayed rule',
        enabled: true,
        action: 'auto',
        logic: 'and',
        words: ['power station'],
        textMatchMode: 'whole_word',
        priceField: 'retail',
        priceOperator: 'at_least',
        priceMinimum: 249,
        queues: ['AI']
      }]
    });
    const original = item(asin, {
      title,
      price: 'N/A',
      etv: 'N/A',
      enrollmentGuid: `event-enrollment-${asin}`,
      liveSources: ['UV']
    });
    h.coordinator.dispatchForLiveItem(original, observation(h, original, {
      source: 'UV',
      watchOnly: false,
      observedAtMs: h.now - observedAgeMs,
      allowDelayedPriceCompletion: true,
      feedUnavailableAdvisory: true
    }));
    return { h, original };
  };

  const expired = makeCandidate('B000000152');
  expired.h.advance(LIVE_PRICE_COMPLETION_WINDOW_MS + 1);
  const stale = expired.h.coordinator.dispatchForDelayedPriceCompletion(
    { ...expired.original, price: 400 },
    {
      asin: expired.original.asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: expired.h.now,
      price: 400
    }
  );
  assert.equal(stale.skipped, true);
  assert.equal(stale.reason, 'no fresh event-linked price completion candidate');
  assert.equal(expired.h.coordinator.recentJobs().length, 0);

  const expiredAtCreation = makeCandidate(
    'B000000159',
    'Event power station',
    LIVE_PRICE_COMPLETION_WINDOW_MS
  );
  const neverRetained = expiredAtCreation.h.coordinator.dispatchForDelayedPriceCompletion(
    { ...expiredAtCreation.original, price: 400 },
    {
      asin: expiredAtCreation.original.asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: expiredAtCreation.h.now,
      price: 400
    }
  );
  assert.equal(neverRetained.skipped, true);
  assert.equal(neverRetained.reason, 'no fresh event-linked price completion candidate');

  const agedAtCreation = makeCandidate('B000000158', 'Event power station', 30_000);
  agedAtCreation.h.advance(30_001);
  const expiredFromObservation = agedAtCreation.h.coordinator.dispatchForDelayedPriceCompletion(
    { ...agedAtCreation.original, price: 400 },
    {
      asin: agedAtCreation.original.asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: agedAtCreation.h.now,
      price: 400
    }
  );
  assert.equal(expiredFromObservation.skipped, true);
  assert.equal(expiredFromObservation.reason, 'no fresh event-linked price completion candidate');
  assert.equal(agedAtCreation.h.coordinator.recentJobs().length, 0);

  const changed = makeCandidate('B000000153');
  enableCatchAllRule(changed.h);
  const afterRuleChange = changed.h.coordinator.dispatchForDelayedPriceCompletion(
    { ...changed.original, price: 400 },
    {
      asin: changed.original.asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: changed.h.now,
      price: 400
    }
  );
  assert.equal(afterRuleChange.skipped, true);
  assert.equal(afterRuleChange.reason, 'no fresh event-linked price completion candidate');

  const wrongTitle = makeCandidate('B000000154', 'Ordinary battery pack');
  const borrowed = wrongTitle.h.coordinator.dispatchForDelayedPriceCompletion(
    { ...wrongTitle.original, title: 'Merged power station', price: 400 },
    {
      asin: wrongTitle.original.asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: wrongTitle.h.now,
      price: 400
    }
  );
  assert.equal(borrowed.skipped, true);
  assert.equal(borrowed.reason, 'no fresh event-linked price completion candidate');
  assert.equal(wrongTitle.h.coordinator.recentJobs().length, 0);

  const offline = harness();
  enableCatchAllRule(offline);
  const offlineItem = item('B000000157', {
    price: 'N/A',
    etv: 'N/A',
    enrollmentGuid: 'offline-event-enrollment',
    liveSources: ['UV']
  });
  offline.coordinator.dispatchForLiveItem(offlineItem, observation(offline, offlineItem, {
    source: 'UV',
    watchOnly: false,
    allowDelayedPriceCompletion: true,
    feedUnavailableAdvisory: true
  }));
  connect(offline);
  const noReconnectReplay = offline.coordinator.dispatchForDelayedPriceCompletion(
    { ...offlineItem, price: 20 },
    {
      asin: offlineItem.asin,
      source: 'VH',
      eventType: 'newPrice',
      receivedAtMs: offline.now,
      price: 20
    }
  );
  assert.equal(noReconnectReplay.skipped, true);
  assert.equal(noReconnectReplay.reason, 'no fresh event-linked price completion candidate');
});

test('UV and VH unavailable flags are advisory only for explicitly trusted automatic observations', () => {
  for (const source of ['UV', 'VH']) {
    const broad = harness();
    connect(broad);
    enableCatchAllRule(broad);
    const asin = source === 'UV' ? 'B000000155' : 'B000000156';
    const unavailable = item(asin, { unavailable: true, liveSources: [source] });
    const broadOutcome = broad.coordinator.dispatchForLiveItem(unavailable, observation(broad, unavailable, {
      source,
      watchOnly: false,
      feedUnavailableAdvisory: true
    }));
    assert.equal(broadOutcome.ok, true, `${source} broad rule`);

    const watched = harness();
    connect(watched);
    watched.coordinator.armWatch({ asin, title: `${source} watched unavailable`, expiryDays: 30 });
    watched.advance(1);
    const watchedOutcome = watched.coordinator.dispatchForLiveItem(unavailable, observation(watched, unavailable, {
      source,
      feedUnavailableAdvisory: true
    }));
    assert.equal(watchedOutcome.ok, true, `${source} watch`);
    assert.equal(watchedOutcome.job.trigger, 'watch');
  }
});

test('a later trusted UV/VH confirmation can create the first deduplicated broad-rule attempt from isolated current order metadata', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000140';
  h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    rollingMaxAutomaticPlacements: null,
    rollingMaxAutomaticCharge: null,
    rules: [{
      id: 'late-source-rule',
      name: 'HP or high retail price',
      enabled: true,
      action: 'auto',
      logic: 'or',
      words: ['HP'],
      excludedWords: [],
      wordMode: 'any',
      textMatchMode: 'whole_word',
      priceField: 'retail',
      priceOperator: 'at_least',
      priceMinimum: 498,
      queues: ['AI'],
      sources: []
    }]
  });

  const first = item(asin, {
    title: 'Kreg fixed-base router',
    queue: 'AI',
    price: 100,
    enrollmentGuid: 'first-vh-enrollment',
    liveSources: ['VH']
  });
  const firstOutcome = h.coordinator.dispatchForLiveItem(first, observation(h, first, {
    source: 'VH',
    watchOnly: false,
    allowLaterRuleDispatch: false
  }));
  assert.equal(firstOutcome.skipped, true);
  assert.equal(firstOutcome.reason, 'no matching enabled rule');
  assert.equal(h.coordinator.recentJobs().length, 0);

  h.advance(1);
  const merged = item(asin, {
    title: 'Kreg 3-1/4 HP SureSpeed Fixed-Base Router',
    queue: 'AI',
    price: 535.96,
    enrollmentGuid: 'stale-merged-enrollment-must-not-be-used',
    img_url: 'https://stale.invalid/merged-image.jpg',
    liveSources: ['VH', 'UV']
  });
  const freshUv = item(asin, {
    title: 'Current UV confirmation',
    queue: 'AI',
    price: null,
    enrollmentGuid: 'fresh-uv-enrollment',
    liveSources: ['UV']
  });

  const stillSilent = h.coordinator.dispatchForLiveItem(merged, observation(h, freshUv, {
    source: 'UV',
    watchOnly: true,
    allowLaterRuleDispatch: false
  }));
  assert.equal(stillSilent.skipped, true);
  assert.equal(h.coordinator.recentJobs().length, 0);

  const outcome = h.coordinator.dispatchForLiveItem(merged, observation(h, freshUv, {
    source: 'UV',
    watchOnly: true,
    allowLaterRuleDispatch: true,
    previousLiveSources: ['VH'],
    previousMergedItem: first
  }));
  assert.equal(outcome.ok, true);
  const orderMessages = socket.sent.filter(message => message.type === 'order_job');
  assert.equal(orderMessages.length, 1);
  const payload = orderMessages[0].payload;
  assert.equal(payload.item.asin, asin);
  assert.equal(payload.item.queue, 'AI');
  assert.equal(payload.item.enrollmentGuid, 'fresh-uv-enrollment');
  assert.equal(payload.item.title, 'Current UV confirmation');
  assert.deepEqual(payload.item.sources, ['UV']);
  assert.equal(payload.policy.ruleId, 'late-source-rule');
  assert.doesNotMatch(
    JSON.stringify(payload),
    /stale-merged-enrollment-must-not-be-used|stale\.invalid\/merged-image/
  );

  h.advance(1);
  const duplicate = h.coordinator.dispatchForLiveItem(merged, observation(h, freshUv, {
    source: 'UV',
    watchOnly: true,
    allowLaterRuleDispatch: true,
    previousLiveSources: ['VH'],
    previousMergedItem: first
  }));
  assert.equal(duplicate.skipped, true);
  assert.equal(duplicate.reason, 'automatic attempt already recorded for ASIN');
  assert.equal(socket.sent.filter(message => message.type === 'order_job').length, 1);
});

test('the first fresh VH confirmation after UV can newly satisfy a source-filtered rule', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000144';
  h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    rules: [{
      id: 'vh-source-rule',
      name: 'VH-confirmed item',
      enabled: true,
      action: 'auto',
      logic: 'price_only',
      priceField: 'retail',
      priceOperator: 'at_least',
      priceMinimum: 0,
      sources: ['VH'],
      queues: ['AI']
    }]
  });
  const previous = item(asin, {
    title: 'UV-first item',
    price: 10,
    liveSources: ['UV']
  });
  const merged = item(asin, {
    title: 'UV and VH item',
    price: 10,
    liveSources: ['UV', 'VH']
  });
  const freshVh = item(asin, {
    title: 'Fresh VH confirmation',
    enrollmentGuid: 'fresh-vh-enrollment',
    liveSources: ['VH']
  });
  const outcome = h.coordinator.dispatchForLiveItem(merged, observation(h, freshVh, {
    source: 'VH',
    allowLaterRuleDispatch: true,
    previousLiveSources: ['UV'],
    previousMergedItem: previous
  }));
  assert.equal(outcome.ok, true);
  const jobs = socket.sent.filter(message => message.type === 'order_job');
  assert.equal(jobs.length, 1);
  assert.equal(jobs[0].payload.item.enrollmentGuid, 'fresh-vh-enrollment');
  assert.deepEqual(jobs[0].payload.item.sources, ['VH']);
});

test('later-source broad-rule exception rejects backfill, non-UV/VH, malformed payloads, unavailable items, and no-match confirmations', () => {
  const asin = 'B000000141';
  const cases = [
    {
      name: 'backfill',
      observation: { source: 'UV', isBackfill: true, allowLaterRuleDispatch: true },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'untrusted source',
      observation: { source: 'SV', allowLaterRuleDispatch: true },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'same-source stale replay',
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        previousLiveSources: ['UV']
      },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'SmartViner-only prior source is not a UV/VH counterpart confirmation',
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        previousLiveSources: ['SV']
      },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'passive/default-confidence enrichment',
      observation: { source: 'UV', confidence: 'default', allowLaterRuleDispatch: true },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'missing fresh observation clock',
      observation: { source: 'UV', observedAtMs: null, allowLaterRuleDispatch: true },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'stale observation clock',
      observation: { source: 'UV', observedAtMs: 1, allowLaterRuleDispatch: true },
      expected: 'no armed watch for ASIN'
    },
    {
      name: 'missing isolated payload',
      observation: { source: 'UV', allowLaterRuleDispatch: true, liveEventItem: null },
      expected: 'later source confirmation lacks a valid isolated order payload'
    },
    {
      name: 'ASIN mismatch',
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        liveEventItem: item('B000000142', { price: 40 })
      },
      expected: 'later source confirmation lacks a valid isolated order payload'
    },
    {
      name: 'unavailable current event',
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        liveEventItem: item(asin, { price: 40, unavailable: true })
      },
      expected: 'item is not eligible for automatic rule ordering'
    },
    {
      name: 'manually hidden merged card',
      mergedOverrides: { isHiddenManual: true },
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        liveEventItem: item(asin, { price: 40 })
      },
      expected: 'item is not eligible for automatic rule ordering'
    },
    {
      name: 'rule-hidden merged card',
      mergedOverrides: { isHide: true },
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        liveEventItem: item(asin, { price: 40 })
      },
      expected: 'item is not eligible for automatic rule ordering'
    },
    {
      name: 'missing prior-card state',
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        liveEventItem: item(asin, { price: 40 })
      },
      expected: 'later source confirmation lacks prior-card match state'
    },
    {
      name: 'card already matched before confirmation',
      observation: {
        source: 'UV',
        allowLaterRuleDispatch: true,
        previousMergedItem: item(asin, { price: 40 }),
        liveEventItem: item(asin, { price: 40 })
      },
      expected: 'item already matched before later source confirmation'
    }
  ];

  for (const current of cases) {
    const h = harness();
    const { socket } = connect(h);
    enableCatchAllRule(h);
    const merged = item(asin, {
      price: 40,
      liveSources: ['VH', 'UV'],
      ...(current.mergedOverrides || {})
    });
    const baseObservation = observation(h, item(asin, { price: 40 }), {
      previousLiveSources: ['VH']
    });
    const result = h.coordinator.dispatchForLiveItem(
      merged,
      { ...baseObservation, ...current.observation }
    );
    assert.equal(result.skipped, true, current.name);
    assert.equal(result.reason, current.expected, current.name);
    assert.equal(h.coordinator.recentJobs().length, 0, current.name);
    assert.equal(socket.sent.filter(message => message.type === 'order_job').length, 0, current.name);
  }

  const h = harness();
  const { socket } = connect(h);
  h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    rules: [{
      id: 'does-not-match',
      enabled: true,
      action: 'auto',
      logic: 'word_only',
      words: ['impossible needle'],
      queues: ['AI']
    }]
  });
  const merged = item(asin, { title: 'ordinary item', liveSources: ['VH', 'UV'] });
  const fresh = item(asin, { title: 'ordinary confirmation', liveSources: ['UV'] });
  const noMatch = h.coordinator.dispatchForLiveItem(merged, observation(h, fresh, {
    source: 'UV',
    allowLaterRuleDispatch: true,
    previousLiveSources: ['VH'],
    previousMergedItem: item(asin, { title: 'ordinary item', liveSources: ['VH'] })
  }));
  assert.equal(noMatch.skipped, true);
  assert.equal(noMatch.reason, 'no matching enabled rule');
  assert.equal(h.coordinator.recentJobs().length, 0);
  assert.equal(socket.sent.filter(message => message.type === 'order_job').length, 0);
});

test('an armed watch keeps reservation precedence over the later-source broad-rule exception', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000143';
  enableCatchAllRule(h);
  h.coordinator.armWatch({ asin, title: 'Reserved item', expiryDays: 30 });
  h.advance(1);
  const merged = item(asin, { queue: 'AI', price: 40, liveSources: ['VH', 'UV'] });
  const fresh = item(asin, {
    title: 'Fresh watched confirmation',
    queue: 'AI',
    price: 40,
    enrollmentGuid: 'fresh-watch-enrollment',
    liveSources: ['UV']
  });
  const outcome = h.coordinator.dispatchForLiveItem(merged, observation(h, fresh, {
    source: 'UV',
    allowLaterRuleDispatch: true
  }));
  assert.equal(outcome.ok, true);
  assert.equal(outcome.job.trigger, 'watch');
  assert.equal(socket.sent.filter(message => message.type === 'order_job').length, 1);
  const watch = h.coordinator.publicWatches().watches[0];
  assert.equal(watch.state, 'triggered');
  assert.equal(watch.jobId, outcome.job.jobId);
});

test('one-shot watch ignores historical RFY metadata and dispatches only the isolated fresh AFA/AI event', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000101';
  const armed = h.coordinator.armWatch({ asin, title: 'Historical RFY title', expiryDays: 30 });
  assert.equal(armed.created, true);
  h.advance(1);
  assert.equal(h.coordinator.publicRules().enabled, false, 'broad automatic rules remain disabled');

  const historicalMergedCard = item(asin, {
    title: 'Historical RFY title',
    queue: 'AFA',
    enrollmentGuid: 'historical-rfy-enrollment',
    recommendation: 'historical-rfy-recommendation',
    liveSources: ['VH', 'UV']
  });
  const freshEvent = item(asin, {
    title: 'Fresh AFA title',
    queue: 'AFA',
    enrollmentGuid: 'fresh-afa-enrollment',
    liveSources: ['UV']
  });
  const outcome = h.coordinator.dispatchForLiveItem(
    historicalMergedCard,
    observation(h, freshEvent, { source: 'UV' })
  );

  assert.equal(outcome.ok, true);
  const envelope = socket.sent.at(-1);
  assert.equal(envelope.type, 'order_job');
  assert.equal(envelope.payload.item.asin, asin);
  assert.equal(envelope.payload.item.queue, 'AFA');
  assert.equal(envelope.payload.item.enrollmentGuid, 'fresh-afa-enrollment');
  assert.equal(envelope.payload.item.title, 'Fresh AFA title');
  assert.deepEqual(envelope.payload.item.sources, ['UV']);
  assert.doesNotMatch(JSON.stringify(envelope), /historical-rfy-enrollment|historical-rfy-recommendation/);

  const watch = h.coordinator.publicWatches().watches[0];
  assert.equal(watch.state, 'triggered');
  assert.equal(watch.observedQueue, 'AFA');
  assert.equal(watch.observedSource, 'UV');
  assert.equal(watch.jobId, outcome.job.jobId);
});

test('watch can bind one offered child ASIN and the signed PC job forbids variant substitution', () => {
  const h = harness();
  const { socket, pairing } = connect(h);
  const parentAsin = 'B000000121';
  const childAsin = 'B000000122';
  const armed = h.coordinator.armWatch({
    asin: parentAsin,
    title: 'Historical parent with variants',
    expiryDays: 30,
    variantPolicy: 'exact',
    selectedVariantAsin: childAsin,
    selectedVariantLabel: 'Colour: Blue • Size: Large'
  });
  assert.equal(armed.watch.variantPolicy, 'exact');
  assert.equal(armed.watch.selectedVariantAsin, childAsin);
  assert.equal(armed.watch.selectedVariantLabel, 'Colour: Blue • Size: Large');
  h.advance(1);

  const fresh = item(parentAsin, {
    queue: 'AFA',
    isParentAsin: true,
    enrollmentGuid: 'fresh-parent-enrollment'
  });
  const outcome = h.coordinator.dispatchForLiveItem(
    fresh,
    observation(h, fresh, { queue: 'AFA', source: 'UV' })
  );
  assert.equal(outcome.ok, true);
  const envelope = socket.sent.at(-1);
  assert.equal(envelope.type, 'order_job');
  assert.equal(envelope.payload.item.asin, parentAsin);
  assert.equal(envelope.payload.item.enrollmentGuid, 'fresh-parent-enrollment');
  assert.equal(envelope.payload.policy.variantPolicy, 'exact');
  assert.equal(envelope.payload.policy.selectedVariantAsin, childAsin);
  assert.equal(outcome.job.requestedVariantAsin, childAsin);

  h.advance(1);
  assert.equal(sendResult(h, socket, pairing.pairingSecret, outcome.job, 'failed', {
    variantAsin: childAsin,
    reasonCode: 'selected_variant_unavailable',
    message: `Selected variant ${childAsin} is no longer offered for this AFA/AI item`
  }).ok, true);
  const watch = h.coordinator.publicWatches().watches[0];
  assert.equal(watch.state, 'missed');
  assert.equal(watch.outcomeState, 'failed');
  assert.equal(watch.reasonCode, 'selected_variant_unavailable');
  assert.equal(watch.message, 'Missed — selected variant unavailable');
  assert.equal(h.coordinator.publicSafety().circuitBreaker.active, false);
});

test('watch variant instructions validate strictly and existing any-variant behavior remains the default', () => {
  const h = harness();
  const any = h.coordinator.armWatch({ asin: 'B000000123', expiryDays: 30 }).watch;
  assert.equal(any.variantPolicy, 'first_available');
  assert.equal(any.selectedVariantAsin, null);
  assert.throws(() => h.coordinator.armWatch({
    asin: 'B000000124',
    expiryDays: 30,
    variantPolicy: 'exact',
    selectedVariantAsin: 'bad'
  }), /valid child ASIN/i);
  assert.throws(() => h.coordinator.armWatch({
    asin: 'B000000124',
    expiryDays: 30,
    variantPolicy: 'exact',
    selectedVariantAsin: 'B000000124'
  }), /child ASIN.*parent ASIN/i);
  assert.throws(() => h.coordinator.armWatch({
    asin: 'B000000124',
    expiryDays: 30,
    variantPolicy: 'first_available',
    selectedVariantAsin: 'B000000125'
  }), /requires the exact variant policy/i);
  assert.throws(() => h.coordinator.armWatch({
    asin: 'B000000124',
    expiryDays: 30,
    variantPolicy: 'fallback_random'
  }), /variant policy/i);
});

test('persisted pre-variant watches migrate to any while malformed exact instructions never widen silently', () => {
  const now = 1_800_000_000_000;
  const store = normalizeWatchStore({
    schemaVersion: 1,
    watches: [
      {
        id: 'watch-old-12345',
        asin: 'B000000132',
        title: 'Old watch',
        state: 'armed',
        armedAtMs: now,
        expiresAtMs: now + 86_400_000
      },
      {
        id: 'watch-bad-12345',
        asin: 'B000000133',
        title: 'Malformed exact watch',
        state: 'armed',
        armedAtMs: now - 1,
        expiresAtMs: now + 86_400_000,
        variantPolicy: 'exact',
        selectedVariantAsin: 'invalid'
      }
    ]
  }, now);
  assert.equal(store.schemaVersion, 2);
  assert.equal(store.watches.find(watch => watch.asin === 'B000000132').variantPolicy, 'first_available');
  const malformed = store.watches.find(watch => watch.asin === 'B000000133');
  assert.equal(malformed.variantPolicy, 'exact');
  assert.equal(malformed.selectedVariantAsin, null);
});

test('an exact watch fails closed without dispatch when the connected companion lacks exact-variant capability', () => {
  const h = harness();
  const { socket } = connect(h, { exactVariantSelection: false });
  const parentAsin = 'B000000126';
  h.coordinator.armWatch({
    asin: parentAsin,
    expiryDays: 30,
    variantPolicy: 'exact',
    selectedVariantAsin: 'B000000127',
    selectedVariantLabel: 'Colour: Black'
  });
  assert.equal(h.coordinator.publicSafety().armedExactVariantWatches, 1);
  assert.equal(h.coordinator.publicSafety().exactVariantCompanionReady, false);
  assert.equal(h.coordinator.publicSafety().automaticDispatchReady, false);
  h.advance(1);
  const fresh = item(parentAsin, { queue: 'AI', isParentAsin: true });
  const outcome = h.coordinator.dispatchForLiveItem(fresh, observation(h, fresh));
  assert.equal(outcome.ok, false);
  assert.equal(outcome.job.reasonCode, 'agent_exact_variant_unsupported');
  assert.equal(socket.sent.some(message => message.type === 'order_job'), false);
  assert.equal(h.coordinator.publicWatches().watches[0].state, 'missed');
});

test('a qualifying watch fails closed rather than falling back to a merged RFY enrollment', () => {
  const h = harness();
  const { socket } = connect(h);
  const asin = 'B000000102';
  h.coordinator.armWatch({ asin, expiryDays: 30 });
  h.advance(1);
  const merged = item(asin, {
    queue: 'AI',
    enrollmentGuid: 'historical-rfy-only-guid'
  });
  const freshWithoutEnrollment = item(asin, {
    queue: 'AI',
    enrollmentGuid: null
  });
  delete freshWithoutEnrollment.recommendation;

  const outcome = h.coordinator.dispatchForLiveItem(
    merged,
    observation(h, freshWithoutEnrollment)
  );
  assert.equal(outcome.ok, false);
  assert.equal(outcome.job.reasonCode, 'metadata_incomplete');
  assert.equal(socket.sent.some(message => message.type === 'order_job'), false);
  const watch = h.coordinator.publicWatches().watches[0];
  assert.equal(watch.state, 'missed');
  assert.equal(watch.reasonCode, 'metadata_incomplete');
});

test('RFY, default-confidence, backfill, pre-arm and unavailable events do not consume a watch', () => {
  const h = harness();
  connect(h);
  const asin = 'B000000103';
  h.coordinator.armWatch({ asin, expiryDays: 30 });
  const armedAt = h.coordinator.publicWatches().watches[0].armedAtMs;
  h.advance(1);

  for (const attempt of [
    observation(h, item(asin, { queue: 'RFY' }), { queue: 'RFY' }),
    observation(h, item(asin, { queue: 'AI' }), { confidence: 'default' }),
    observation(h, item(asin, { queue: 'AFA' }), { isBackfill: true }),
    observation(h, item(asin, { queue: 'AI' }), { observedAtMs: armedAt - 1 }),
    observation(h, item(asin, { queue: 'AI', unavailable: true }))
  ]) {
    const outcome = h.coordinator.dispatchForLiveItem(item(asin), attempt);
    assert.equal(outcome.skipped, true);
    assert.equal(h.coordinator.publicWatches().watches[0].state, 'armed');
  }
});

test('an offline qualifying opportunity is consumed as Missed and is never queued or retried', () => {
  const h = harness();
  h.coordinator.issuePairing();
  const asin = 'B000000104';
  h.coordinator.armWatch({ asin, expiryDays: 30 });
  h.advance(1);
  const live = item(asin, { queue: 'AI' });

  const first = h.coordinator.dispatchForLiveItem(live, observation(h, live));
  assert.equal(first.ok, false);
  assert.equal(first.job.reasonCode, 'agent_offline');
  assert.equal(h.coordinator.publicWatches().watches[0].state, 'missed');

  const second = h.coordinator.dispatchForLiveItem(live, observation(h, live));
  assert.equal(second.skipped, true);
  assert.match(second.reason, /no armed watch/i);
  assert.equal(h.coordinator.recentJobs().length, 1);
});

test('watch lifecycle exposes cancellation and expiry with a strict 1–30 day input bound', () => {
  const h = harness();
  assert.throws(() => h.coordinator.armWatch({ asin: 'B000000105', expiryDays: 0 }), /1 to 30/);
  assert.throws(() => h.coordinator.armWatch({ asin: 'B000000105', expiryDays: 31 }), /1 to 30/);
  assert.throws(() => h.coordinator.armWatch({ asin: 'B000000105', expiryDays: 2.5 }), /whole number/);
  assert.throws(() => h.coordinator.armWatch({ asin: 'B000000105', unattendedCheckoutLimit: -1 }), /cap/);

  const cancelled = h.coordinator.armWatch({ asin: 'B000000105', expiryDays: 1 }).watch;
  assert.equal(h.coordinator.cancelWatch(cancelled.id).state, 'cancelled');
  assert.throws(() => h.coordinator.cancelWatch(cancelled.id), /Only an armed/);

  h.coordinator.armWatch({ asin: 'B000000106', expiryDays: 1 });
  h.advance(86_400_001);
  const watches = h.coordinator.publicWatches();
  assert.equal(watches.counts.expired, 1);
  assert.equal(watches.counts.cancelled, 1);
  assert.equal(watches.counts.armed, 0);
});

test('emergency pause preserves rules and an armed watch without queuing the paused event, while manual action remains available', () => {
  const h = harness();
  const { socket, pairing } = connect(h);
  const watchAsin = 'B000000107';
  h.coordinator.armWatch({ asin: watchAsin, expiryDays: 30 });
  h.advance(1);
  enableCatchAllRule(h);
  h.coordinator.setAutomaticPause(true, { reason: 'Emergency dashboard pause' });
  assert.equal(h.coordinator.publicSafety().manualPaused, true);
  assert.equal(h.coordinator.publicRules().rules.length, 1);
  assert.equal(h.coordinator.publicWatches().counts.armed, 1);

  const watched = item(watchAsin);
  const pausedObservation = h.coordinator.dispatchForLiveItem(watched, observation(h, watched));
  assert.equal(pausedObservation.skipped, true);
  assert.match(pausedObservation.reason, /watch preserved/i);
  assert.equal(h.coordinator.publicWatches().watches[0].state, 'armed');
  assert.equal(h.coordinator.recentJobs().length, 0, 'the paused event was not queued or recorded as an attempt');

  const manual = h.coordinator.dispatchManual(item('B000000108'));
  assert.equal(manual.ok, true);
  assert.equal(socket.sent.at(-1).type, 'order_job');
  const concurrent = h.coordinator.dispatchManual(item('B000000119'));
  assert.equal(concurrent.ok, false);
  assert.equal(concurrent.job.reasonCode, 'active_order_job');
  assert.equal(sendResult(h, socket, pairing.pairingSecret, manual.job, 'placed', {
    finalTotal: 0,
    currency: 'CAD'
  }).ok, true);
  assert.throws(
    () => h.coordinator.setAutomaticPause(false, { confirmation: 'resume' }),
    /exactly match/
  );
  h.coordinator.setAutomaticPause(false, { confirmation: ORDER_AUTOMATION_RESUME_CONFIRMATION });
  assert.equal(h.coordinator.publicSafety().manualPaused, false);
  h.advance(1);
  const laterFreshEvent = h.coordinator.dispatchForLiveItem(watched, observation(h, watched));
  assert.equal(laterFreshEvent.ok, true);
  assert.equal(h.coordinator.publicWatches().watches[0].state, 'triggered');
});

test('ambiguous, account, total, currency, and checkout uncertainty trip the persistent circuit breaker', () => {
  for (const reasonCode of [
    'checkout_total_unknown',
    'checkout_total_ambiguous',
    'checkout_currency_mismatch',
    'checkout_changed_before_click',
    'amazon_account_changed'
  ]) {
    assert.equal(SAFETY_CIRCUIT_REASON_CODES.has(reasonCode), true);
  }

  const h = harness();
  const { pairing, socket } = connect(h);
  const first = h.coordinator.dispatchManual(item('B000000109')).job;
  const failed = sendResult(h, socket, pairing.pairingSecret, first, 'failed', {
    reasonCode: 'checkout_total_ambiguous',
    message: 'Amazon displayed conflicting final totals'
  });
  assert.equal(failed.ok, true);
  let safety = h.coordinator.publicSafety();
  assert.equal(safety.circuitBreaker.active, true);
  assert.equal(safety.circuitBreaker.reasonCode, 'checkout_total_ambiguous');
  assert.equal(h.files.get('/safety').circuitBreaker.active, true);

  const blocked = h.coordinator.dispatchManual(item('B000000110'));
  assert.equal(blocked.ok, false);
  assert.equal(blocked.job.reasonCode, 'safety_circuit_breaker');
  assert.throws(() => h.coordinator.acknowledgeSafetyPause('ACK'), /exactly match/);
  h.coordinator.acknowledgeSafetyPause(ORDER_SAFETY_ACK_CONFIRMATION);
  safety = h.coordinator.publicSafety();
  assert.equal(safety.circuitBreaker.active, false);
  assert.equal(safety.lastAcknowledgement.previousReasonCode, 'checkout_total_ambiguous');

  const second = h.coordinator.dispatchManual(item('B000000111')).job;
  h.advance(1);
  assert.equal(sendResult(h, socket, pairing.pairingSecret, second, 'ambiguous', {
    reasonCode: 'placement_unconfirmed',
    message: 'Check Amazon Orders before retrying'
  }).ok, true);
  assert.equal(h.coordinator.publicSafety().circuitBreaker.reasonCode, 'ambiguous_order_result');

  h.coordinator.acknowledgeSafetyPause(ORDER_SAFETY_ACK_CONFIRMATION);
  const malformedCurrency = h.coordinator.dispatchManual(item('B000000118')).job;
  h.advance(1);
  assert.equal(sendResult(h, socket, pairing.pairingSecret, malformedCurrency, 'placed', {
    finalTotal: 0,
    currency: 'NOT-CAD'
  }).ok, true);
  assert.equal(h.coordinator.recentJobs(1)[0].currency, null);
  assert.equal(h.coordinator.publicSafety().circuitBreaker.reasonCode, 'placement_total_unavailable');

  h.coordinator.acknowledgeSafetyPause(ORDER_SAFETY_ACK_CONFIRMATION);
  const third = h.coordinator.dispatchManual(item('B000000117')).job;
  h.advance(1);
  assert.equal(sendResult(h, socket, pairing.pairingSecret, third, 'submitting', {
    finalTotal: 0,
    currency: 'CAD',
    timings: { placeOrderClickedAtMs: h.now }
  }).ok, true);
  h.coordinator.detachSocket(socket, 'connection lost');
  assert.equal(h.coordinator.publicSafety().circuitBreaker.reasonCode, 'agent_disconnected_after_submission');

  const recoveredFiles = new Map([...h.files].map(([key, value]) => [key, structuredClone(value)]));
  recoveredFiles.delete('/safety');
  const recovered = new OrderCoordinator({
    pairingFile: '/pairing', rulesFile: '/rules', jobsFile: '/jobs', watchesFile: '/watches', safetyFile: '/safety',
    loadJSON: (file, fallback) => recoveredFiles.has(file) ? structuredClone(recoveredFiles.get(file)) : fallback,
    saveJSON: (file, value) => recoveredFiles.set(file, structuredClone(value)),
    now: () => h.now
  });
  assert.equal(recovered.publicSafety().circuitBreaker.active, true);
  assert.equal(recovered.publicSafety().circuitBreaker.reasonCode, 'submission_outcome_unresolved_after_restart');
});

test('placement-stage exact-variant mismatch is circuit breaking', () => {
  const h = harness();
  const { pairing, socket } = connect(h);
  const parentAsin = 'B000000128';
  const selectedAsin = 'B000000129';
  h.coordinator.armWatch({
    asin: parentAsin,
    expiryDays: 30,
    variantPolicy: 'exact',
    selectedVariantAsin: selectedAsin,
    selectedVariantLabel: 'Size: Selected'
  });
  h.advance(1);
  const fresh = item(parentAsin, { queue: 'AFA', isParentAsin: true });
  const job = h.coordinator.dispatchForLiveItem(
    fresh,
    observation(h, fresh, { queue: 'AFA' })
  ).job;
  h.advance(1);
  const result = sendResult(h, socket, pairing.pairingSecret, job, 'submitting', {
    variantAsin: 'B000000130',
    finalTotal: 0,
    currency: 'CAD',
    timings: { placeOrderClickedAtMs: h.now }
  });
  assert.equal(result.ok, true);
  assert.equal(result.job.reasonCode, 'placement_variant_mismatch');
  assert.equal(h.coordinator.publicSafety().circuitBreaker.active, true);
  assert.equal(h.coordinator.publicSafety().circuitBreaker.reasonCode, 'placement_variant_mismatch');
});

test('rolling 24-hour count escalates automatic jobs to local approval and charge allowance narrows the cap', () => {
  const countHarness = harness();
  const countConnection = connect(countHarness);
  enableCatchAllRule(countHarness, { rollingMaxAutomaticPlacements: 1 });
  const first = countHarness.coordinator.dispatchForLiveItem(item('B000000112'), { watchOnly: false }).job;
  assert.equal(sendResult(
    countHarness,
    countConnection.socket,
    countConnection.pairing.pairingSecret,
    first,
    'placed',
    {
      finalTotal: 0,
      currency: 'CAD',
      timings: { placeOrderClickedAtMs: countHarness.now, confirmedAtMs: countHarness.now }
    }
  ).ok, true);
  countHarness.advance(1);
  const countOutcome = countHarness.coordinator.dispatchForLiveItem(item('B000000113'), { watchOnly: false });
  assert.equal(countOutcome.ok, true);
  assert.equal(countOutcome.job.requestedMode, 'auto');
  assert.equal(countOutcome.job.mode, 'approval');
  assert.equal(countOutcome.job.safetyEscalation, 'rolling_placement_limit');
  assert.equal(countConnection.socket.sent.at(-1).payload.policy.mode, 'approval');

  const chargeHarness = harness();
  const chargeConnection = connect(chargeHarness);
  enableCatchAllRule(chargeHarness, { rollingMaxAutomaticCharge: 10 });
  const chargeFirst = chargeHarness.coordinator.dispatchForLiveItem(item('B000000114'), { watchOnly: false }).job;
  assert.equal(sendResult(
    chargeHarness,
    chargeConnection.socket,
    chargeConnection.pairing.pairingSecret,
    chargeFirst,
    'placed',
    {
      finalTotal: 8,
      currency: 'CAD',
      timings: { placeOrderClickedAtMs: chargeHarness.now, confirmedAtMs: chargeHarness.now }
    }
  ).ok, true);
  chargeHarness.advance(1);
  const chargeOutcome = chargeHarness.coordinator.dispatchForLiveItem(item('B000000115'), { watchOnly: false });
  assert.equal(chargeOutcome.ok, true);
  const chargeEnvelope = chargeConnection.socket.sent.at(-1);
  assert.equal(chargeEnvelope.payload.policy.mode, 'auto');
  assert.equal(chargeEnvelope.payload.policy.unattendedCheckoutLimit, 2);
  const explanation = chargeHarness.coordinator.explainRuleMatch(item('B000000116'));
  assert.equal(explanation.effectiveCheckoutLimit, 2);
  assert.equal(explanation.action, 'auto');

  assert.equal(harness().coordinator.publicRules().rollingMaxAutomaticPlacements, null);
  assert.equal(harness().coordinator.publicRules().rollingMaxAutomaticCharge, null);
  assert.throws(
    () => harness().coordinator.updateRuleSet({ rollingMaxAutomaticPlacements: 2.5, rules: [] }),
    /whole number/
  );
  assert.throws(
    () => harness().coordinator.updateRuleSet({ rollingMaxAutomaticCharge: -1, rules: [] }),
    /final-charge/
  );
});

test('credential-free export/import retains rule/watch configuration, preserves private state, and disables broad rules', () => {
  const h = harness();
  const { pairing } = connect(h);
  enableCatchAllRule(h, { rollingMaxAutomaticPlacements: 5, rollingMaxAutomaticCharge: 25 });
  h.coordinator.armWatch({
    asin: 'B000000116',
    title: 'Exported watch',
    expiryDays: 12,
    unattendedCheckoutLimit: 4.5,
    variantPolicy: 'exact',
    selectedVariantAsin: 'B000000131',
    selectedVariantLabel: 'Colour: Exported Blue'
  });
  h.coordinator.setAutomaticPause(true, { reason: 'Keep this private safety state' });
  const pairingBefore = structuredClone(h.files.get('/pairing'));
  const safetyBefore = structuredClone(h.files.get('/safety'));

  const exported = h.coordinator.exportConfiguration();
  assert.equal(exported.containsSecrets, false);
  assert.equal(exported.kind, 'vine-drop-hub-order-automation');
  assert.equal(exported.watches.length, 1);
  assert.equal(exported.watches[0].variantPolicy, 'exact');
  assert.equal(exported.watches[0].selectedVariantAsin, 'B000000131');
  assert.equal(exported.watches[0].selectedVariantLabel, 'Colour: Exported Blue');
  assert.match(exported.watches[0].expiresAt, /^\d{4}-\d{2}-\d{2}T/);
  assert.equal(Object.hasOwn(exported, 'pairing'), false);
  assert.equal(Object.hasOwn(exported, 'jobs'), false);
  assert.equal(Object.hasOwn(exported, 'safety'), false);
  assert.equal(JSON.stringify(exported).includes(pairing.pairingSecret), false);
  assert.equal(JSON.stringify(exported).includes('a'.repeat(64)), false);

  const imported = h.coordinator.importConfiguration(exported);
  assert.equal(imported.rules.enabled, false);
  assert.equal(imported.rules.rollingMaxAutomaticPlacements, 5);
  assert.equal(imported.rules.rollingMaxAutomaticCharge, 25);
  assert.equal(imported.watches.counts.armed, 1);
  assert.equal(imported.watches.watches[0].unattendedCheckoutLimit, 4.5);
  assert.equal(imported.watches.watches[0].variantPolicy, 'exact');
  assert.equal(imported.watches.watches[0].selectedVariantAsin, 'B000000131');
  assert.match(imported.warning, /broad automatic rules are disabled/i);
  assert.deepEqual(h.files.get('/pairing'), pairingBefore);
  assert.deepEqual(h.files.get('/safety'), safetyBefore);
  assert.equal(h.coordinator.publicStatus().accountMatched, true);
  assert.equal(h.coordinator.publicSafety().manualPaused, true);

  const bad = structuredClone(exported);
  bad.watches[0].unattendedCheckoutLimit = -1;
  assert.throws(() => h.coordinator.importConfiguration(bad), /Imported watch final-total cap/);
  assert.equal(h.coordinator.publicWatches().counts.armed, 1);
  const badVariant = structuredClone(exported);
  delete badVariant.watches[0].selectedVariantAsin;
  assert.throws(() => h.coordinator.importConfiguration(badVariant), /valid child ASIN/i);
  assert.equal(h.coordinator.publicWatches().counts.armed, 1);

  const active = h.coordinator.dispatchManual(item('B000000120'));
  assert.equal(active.ok, true);
  assert.throws(() => h.coordinator.importConfiguration(exported), /active PC order job/);
});
