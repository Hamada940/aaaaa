'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  normalizeOrderRuleSet,
  validateRuleCompleteness,
  termMatchesItem,
  evaluateOrderRule,
  firstMatchingOrderRule,
  explainFirstMatchingOrderRule,
  previewOrderRules
} = require('../lib/order-rules');

const ITEM = {
  asin: 'B000000001',
  title: 'Premium Coffee Grinder with Burr Settings',
  brand: 'Example',
  queue: 'AI',
  price: 149.99,
  etv: 0,
  sources: ['VH', 'UV']
};

function rule(overrides = {}) {
  return {
    id: 'rule-1234',
    name: 'Rule',
    enabled: true,
    action: 'auto',
    logic: 'word_only',
    words: ['coffee'],
    excludedWords: [],
    wordMode: 'any',
    priceField: 'retail',
    priceOperator: 'at_least',
    priceMinimum: 100,
    priceMaximum: null,
    queues: [],
    sources: [],
    ...overrides
  };
}

test('word-only, price-only, AND, and OR modes behave independently', () => {
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'word_only' })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'price_only', words: [] })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'and' })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'and', priceMinimum: 200 })).matched, false);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'or', words: ['television'], priceMinimum: 100 })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'or', words: ['television'], priceMinimum: 200 })).matched, false);
});

test('any/all words, exclusions, queue and source filters are enforced', () => {
  assert.equal(evaluateOrderRule(ITEM, rule({ words: ['coffee', 'grinder'], wordMode: 'all' })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ words: ['coffee', 'television'], wordMode: 'all' })).matched, false);
  assert.equal(evaluateOrderRule(ITEM, rule({ excludedWords: ['burr'] })).matched, false);
  assert.equal(evaluateOrderRule(ITEM, rule({ queues: ['RFY'] })).matched, false);
  assert.equal(evaluateOrderRule(ITEM, rule({ sources: ['SV'] })).matched, false);
  assert.equal(evaluateOrderRule(ITEM, rule({ sources: ['VH'] })).matched, true);
});

test('price source and operators support retail, ETV, either, limits, and ranges', () => {
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'price_only', priceField: 'etv', priceMinimum: 1 })).matched, false);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'price_only', priceField: 'either', priceMinimum: 100 })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'price_only', priceOperator: 'at_most', priceMinimum: 150 })).matched, true);
  assert.equal(evaluateOrderRule(ITEM, rule({ logic: 'price_only', priceOperator: 'between', priceMinimum: 125, priceMaximum: 175 })).matched, true);
});

test('incomplete rules fail closed and first enabled matching rule wins', () => {
  const invalid = rule({ logic: 'and', words: [] });
  assert.match(validateRuleCompleteness(invalid), /both/i);
  assert.equal(evaluateOrderRule(ITEM, invalid).matched, false);
  const ruleSet = normalizeOrderRuleSet({
    enabled: true,
    unattendedCheckoutLimit: 30,
    rules: [
      rule({ id: 'first', name: 'Does not match', words: ['television'] }),
      rule({ id: 'second', name: 'Matches coffee', action: 'approval' }),
      rule({ id: 'third', name: 'Would also match' })
    ]
  });
  const match = firstMatchingOrderRule(ITEM, ruleSet);
  assert.equal(match.rule.id, 'second');
  assert.equal(match.rule.action, 'approval');
});

test('automatic ordering is disabled by default and checkout limit is independent from item price', () => {
  const ruleSet = normalizeOrderRuleSet({ currency: 'USD', rules: [rule()] });
  assert.equal(ruleSet.enabled, false);
  assert.equal(ruleSet.currency, 'CAD');
  assert.equal(ruleSet.unattendedCheckoutLimit, 30);
  assert.equal(ruleSet.rollingMaxAutomaticPlacements, null);
  assert.equal(ruleSet.rollingMaxAutomaticCharge, null);
  assert.equal(firstMatchingOrderRule(ITEM, ruleSet), null);
});

test('substring, exact-phrase, whole-word, and exact-title modes remain distinct and Unicode-safe', () => {
  const candidate = { title: 'Catering set — premium coffee grinder', brand: 'Acme Tools' };
  assert.equal(termMatchesItem(candidate, 'cat', 'substring'), true);
  assert.equal(termMatchesItem(candidate, 'cat', 'whole_word'), false);
  assert.equal(termMatchesItem(candidate, 'coffee grinder', 'exact_phrase'), true);
  assert.equal(termMatchesItem(candidate, 'coffee   grinder', 'exact_phrase'), true);
  assert.equal(termMatchesItem(candidate, 'premium coffee', 'whole_word'), true);
  assert.equal(termMatchesItem(candidate, 'acme tools', 'exact'), true);
  assert.equal(termMatchesItem(candidate, 'coffee grinder', 'exact'), false);
  assert.equal(
    termMatchesItem({ title: 'Coffee', brand: 'Grinder' }, 'coffee grinder', 'whole_word'),
    false,
    'a phrase must not be fabricated across the title/brand boundary'
  );
});

test('preview evaluates a disabled global draft without dispatching and returns detailed cap explanations', () => {
  const draft = normalizeOrderRuleSet({
    enabled: false,
    unattendedCheckoutLimit: 30,
    rules: [rule({ unattendedCheckoutLimit: 12.5 })]
  });
  const preview = previewOrderRules([ITEM], draft);
  assert.equal(preview.ruleSetEnabled, false);
  assert.equal(preview.evaluated, 1);
  assert.equal(preview.matched, 1);
  assert.equal(preview.matches[0].effectiveCheckoutLimit, 12.5);
  assert.deepEqual(preview.matches[0].explanation.matchedWords, ['coffee']);
  assert.deepEqual(preview.matches[0].explanation.candidatePrices, [149.99]);
  assert.equal(preview.matches[0].explanation.queue, 'AI');
  assert.deepEqual(preview.matches[0].explanation.sources, ['VH', 'UV']);

  assert.equal(explainFirstMatchingOrderRule(ITEM, draft), null, 'disabled saved automation has no live match');
  const enabled = { ...draft, enabled: true };
  const explanation = explainFirstMatchingOrderRule(ITEM, enabled);
  assert.equal(explanation.ruleName, 'Rule');
  assert.equal(explanation.action, 'auto');
  assert.equal(explanation.globalCheckoutLimit, 30);
  assert.equal(explanation.effectiveCheckoutLimit, 12.5);
  assert.equal(explanation.currency, 'CAD');
});
