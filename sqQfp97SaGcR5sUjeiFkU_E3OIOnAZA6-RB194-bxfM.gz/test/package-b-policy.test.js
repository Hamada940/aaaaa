'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');

const root = path.join(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const compose = fs.readFileSync(path.join(root, 'compose.vpn.yml'), 'utf8');
const proxy = fs.readFileSync(path.join(root, 'vh-direct-proxy.js'), 'utf8');
const freshInstaller = fs.readFileSync(path.join(root, 'install-new-ubuntu.sh'), 'utf8');
const freshFinalizer = fs.readFileSync(path.join(root, 'host', 'finalize-install.sh'), 'utf8');

function assertHas(pattern, label) {
  assert.match(server, pattern, label);
}

test('live transport never emits getLast100 and diagnostics expose only the three narrow signed reads', () => {
  assert.doesNotMatch(
    server,
    /\.emit\s*\(\s*['"]getLast100['"]/,
    'server.js must not emit getLast100 from startup, recovery, health, or manual refresh'
  );
  assertHas(/getLast100Prohibited:\s*true/, 'diagnostics must expose the getLast100 policy');
  assertHas(/signedItemExplorerEnabled:\s*true/, 'diagnostics must expose the signed search exception');
  assertHas(/itemExplorerUserInitiatedOnly:\s*true/, 'Item Explorer must remain explicit');
  assertHas(/itemExplorerIdentityMutationAllowed:\s*false/, 'searches cannot mutate identity');
  assertHas(/signedItemExplorerVariantsEnabled:\s*true/, 'diagnostics must expose the Watch variants exception');
  assertHas(/itemExplorerVariantsWatchClickOnly:\s*true/, 'variants must remain Watch-click-only');
  assertHas(/itemExplorerVariantsAutomaticRetry:\s*false/, 'variants cannot retry automatically');
  assertHas(/itemExplorerVariantsResponsePersisted:\s*false/, 'variant replies must remain ephemeral');
  assertHas(/itemExplorerVariantsLiveStoreMerged:\s*false/, 'variant replies cannot merge into live items');
  assertHas(/itemExplorerVariantsIdentityMutationAllowed:\s*false/, 'variant reads cannot mutate identity');
  assertHas(/signedTrialStatusEnabled:\s*true/, 'diagnostics must expose the trial-status exception');
  assertHas(/trialStatusUserInitiatedOnly:\s*true/, 'trial status must remain click-only');
  assertHas(/trialStatusResponsePersisted:\s*false/, 'trial response must remain ephemeral');
  assertHas(/trialStatusIdentityMutationAllowed:\s*false/, 'trial checks cannot mutate identity');
  assertHas(
    /else if \(uvStatus === 'Authenticated'\) \{[\s\S]*uvStatus = 'Disconnected; manual reconnect required'/,
    'a blocked UV close must not retain a stale Authenticated label'
  );
  assertHas(/const VH_APP_VERSION = '4\.7\.4'/, 'live VHelper identity must use the authenticated 4.7.4 pin');
  assertHas(/const VH_BUILD_VERSION = '3637'/, 'diagnostics must report audited build 3637');
  assertHas(/function publicVhProtocolVersions\(\)[\s\S]*liveIdentity[\s\S]*itemExplorer[\s\S]*itemExplorerVariants[\s\S]*trialStatus/, 'each VHelper contract must expose its own version pin');
  assert.match(dashboard, /Live socket identity: VHelper \$\{protocolVersions\.liveIdentity/);
  assert.match(dashboard, /Signed Item Explorer contract: VHelper \$\{protocolVersions\.itemExplorer/);
  assert.match(dashboard, /Signed watch-variant contract: VHelper \$\{protocolVersions\.itemExplorerVariants/);
  assert.match(dashboard, /Signed trial-status contract: VHelper \$\{protocolVersions\.trialStatus/);

  assert.match(
    freshInstaller,
    /metadata\.get\('releaseId'\) != 'r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18'/,
    'fresh installer must authenticate this exact successor release'
  );
  assert.match(
    freshInstaller,
    /Application release: r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18/,
    'fresh installer must report this exact successor release'
  );
  assert.match(
    freshFinalizer,
    /\[\[ \$node_pass == 250 && \$node_fail == 0 \]\]/,
    'fresh finalizer must require all 250 Node tests'
  );
  assert.match(
    freshFinalizer,
    /Offline validation passed: 250\/250 Node tests and 17\/17 Python tests\./,
    'fresh finalizer must report the current complete offline suite'
  );
  assert.match(
    freshFinalizer,
    /Application release: r25-uv-auth-recovery-live-feed-capacity-hotfix-20260910-18/,
    'fresh finalizer must report this exact successor release'
  );
  assert.doesNotMatch(freshInstaller, /r25-pc-order-companion-new-vps-20260910-1/);
  assert.doesNotMatch(freshFinalizer, /176\/176|node_pass == 176/);
});

test('Socket.IO uses official passive options and history-free recovery signals', () => {
  assertHas(/transports:\s*\[['"]websocket['"]\]/, 'websocket-only transport');
  assertHas(/reconnection:\s*false/, 'manual same-Socket recovery');
  assertHas(/vhSocket\.emit\(['"]broadcastSyncPing['"]\)/, 'broadcast sync liveness ping');
  assertHas(/VH_ENGINE_SILENCE_MS\s*=\s*120000/, 'two-minute engine watchdog');
  assertHas(/VH_MAX_CONNECTION_AGE_MS\s*=\s*3\s*\*\s*60\s*\*\s*60\s*\*\s*1000/, 'three-hour connection refresh');
  assertHas(/VH_SUPERVISOR_INTERVAL_MS\s*=\s*10000/, 'ten-second supervisor');
  assertHas(/socket\.recovered/, 'Socket.IO recovery state is inspected');
});

test('optional application evidence cannot tear down an official-client-healthy transport', () => {
  const supervisorStart = server.indexOf('function runVhSupervisor');
  const supervisorEnd = server.indexOf('function startVhSupervisor', supervisorStart);
  const supervisor = server.slice(supervisorStart, supervisorEnd);
  assert.ok(supervisorStart > 0 && supervisorEnd > supervisorStart);
  assert.doesNotMatch(supervisor, /reconnectVhSameSocket\(['"]application-ready timeout/);
  assert.doesNotMatch(supervisor, /reconnectVhSameSocket\(['"]broadcast sync timeout/);
  assert.doesNotMatch(supervisor, /reportVhFeedProblem\(['"]broadcastSyncPong timeout/);
  assert.match(supervisor, /official client has no broadcastSyncPong deadline/);
  assertHas(/applicationEvidenceRequiredForHealth:\s*false/, 'transport is the official health criterion');
  assertHas(/broadcastSyncPongRequired:\s*false/, 'pong is explicitly optional');
});

test('planned same-socket recovery is incident-safe and broadcast gaps cannot reconnect-loop', () => {
  const handlerStart = server.indexOf("socket.on('disconnect'");
  const handlerEnd = server.indexOf("socket.on('connect_error'", handlerStart);
  const handler = server.slice(handlerStart, handlerEnd);
  assert.ok(handlerStart > 0 && handlerEnd > handlerStart);
  assert.match(handler, /plannedRecovery/);
  assert.match(handler, /if \(plannedRecovery\)/);
  assert.match(handler, /else \{[\s\S]*reportVhFeedProblem/);
  assert.match(handler, /planned recovery:/);

  const syncStart = server.indexOf("socket.on('broadcastSyncPong'");
  const syncEnd = server.indexOf("socket.on('serverDisconnect'", syncStart);
  const syncHandler = server.slice(syncStart, syncEnd);
  assert.ok(syncStart > 0 && syncEnd > syncStart);
  assert.match(syncHandler, /decideBroadcastMismatchRecovery/);
  assert.match(syncHandler, /decision\.action === 'reconnect-once'/);
  assert.match(syncHandler, /decision\.action === 'keep-connected'/);
  assert.match(syncHandler, /keeping the healthy socket connected until a new live VH broadcast arrives/);
  assert.equal((syncHandler.match(/reconnectVhSameSocket\('broadcast marker mismatch'\)/g) || []).length, 1);
});

test('invalid UUID errors preserve the stored identity instead of mutating it automatically', () => {
  const handlerStart = server.indexOf('async function handleVhConnectionError');
  const handlerEnd = server.indexOf('function detachVhEngineActivity', handlerStart);
  const handler = server.slice(handlerStart, handlerEnd);
  assert.ok(handlerStart > 0 && handlerEnd > handlerStart);
  assert.doesNotMatch(handler, /repairInvalidUuid/);
  assert.match(handler, /Automatic identity replacement is disabled/);
  assert.match(handler, /latchVhDenial/);
});

test('all audited passive VH events are bound', () => {
  for (const event of [
    'connection_info',
    'newItem',
    'newETV',
    'newPrice',
    'newVariants',
    'unavailableItem',
    'reloadPage',
    'orderAttempts',
    'serverDisconnect',
    'connection_error',
    'broadcastSyncPong'
  ]) {
    assert.ok(server.includes(`'${event}'`), `missing event mapping: ${event}`);
  }
  assert.doesNotMatch(server, /\.emit\s*\(\s*['"](?:disconnectRequest|reloadRequest)['"]/);
});

test('VH enrichment and second-feed confirmation remain silent', () => {
  const enrichmentStart = server.indexOf('function applyVhEnrichment');
  const enrichmentEnd = server.indexOf('function applyPendingVhEnrichments', enrichmentStart);
  const enrichment = server.slice(enrichmentStart, enrichmentEnd);
  assert.ok(enrichmentStart > 0 && enrichmentEnd > enrichmentStart);
  assert.doesNotMatch(enrichment, /notifyLiveItem|sendTelegramNotification|sendDiscordNotification/);

  const ingestionStart = server.indexOf('function ingestItem');
  const ingestionEnd = server.indexOf('function applyUvAlertDetail', ingestionStart);
  const ingestion = server.slice(ingestionStart, ingestionEnd);
  assert.match(ingestion, /crossFeedConfirmation/);
  assert.match(
    ingestion,
    /broadcastLocal\(['"]update_item['"], withOrderRuleMatch\(mergedItem\), finishLiveDeliveryTiming\(liveTiming\)\)/
  );
  assert.equal((ingestion.match(/notifyLiveItem\(/g) || []).length, 2);
  assert.match(ingestion, /Every later live source updates the same card/);
});

test('split-route policy remains app-only VPN for UV and destination-locked VH proxy', () => {
  assert.match(compose, /network_mode:\s*["']service:(?:gluetun|vpn)["']/);
  assert.match(compose, /VH_PROXY_URL/);
  assert.match(proxy, /const ALLOWED_HOST = ['"]api\.v-helper\.com['"]/);
  assert.match(proxy, /const ALLOWED_PORT = 443/);
  assert.match(proxy, /Destination not allowed/);
});

test('legacy identities are explicitly preserved and new identities use fresh keys', () => {
  const identity = fs.readFileSync(path.join(root, 'lib', 'vh-identity.js'), 'utf8');
  assert.match(identity, /identityMode:\s*['"]legacy-synthetic['"]/);
  assert.match(identity, /Never rewrite, rotate, register/);
  assert.match(identity, /generateKeyPairSync\(['"]ec['"]/);
  assert.match(identity, /compatibility-blank-bounded/);
  const rotateStart = server.indexOf("app.post('/api/identity/rotate'");
  const rotateEnd = server.indexOf("app.get('/api/config'", rotateStart);
  assert.ok(rotateStart > 0 && rotateEnd > rotateStart);
  assert.doesNotMatch(server.slice(rotateStart, rotateEnd), /req\.body\?\.confirmation/);
});
