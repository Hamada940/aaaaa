'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  canonicalJson,
  generatePairingSecret,
  signPayload,
  verifyPayloadSignature,
  signedEnvelope,
  normalizeQueue,
  extractEnrollmentGuid,
  finiteMoney,
  sanitizeRecommendationMetadata,
  buildOrderJob,
  buildVariantLookupRequest,
  sanitizeVariantLookupResult,
  sanitizeOrderResult
} = require('../lib/order-protocol');

test('canonical JSON and HMAC signatures are deterministic and tamper evident', () => {
  const secret = generatePairingSecret();
  assert.match(secret, /^vdh1\.[A-Za-z0-9_-]{43}$/);
  assert.equal(canonicalJson({ z: 1, a: { y: 2, x: 3 } }), '{"a":{"x":3,"y":2},"z":1}');
  const payload = { z: 1, a: 'value' };
  const signature = signPayload(secret, 'order_job', payload);
  assert.equal(verifyPayloadSignature(secret, 'order_job', payload, signature), true);
  assert.equal(verifyPayloadSignature(secret, 'order_job', { ...payload, z: 2 }, signature), false);
  assert.equal(verifyPayloadSignature(secret, 'other', payload, signature), false);
  assert.deepEqual(signedEnvelope(secret, 'order_job', payload), {
    type: 'order_job',
    payload,
    signature
  });
});

test('queue and enrollment metadata normalize without retaining a full account recommendation ID', () => {
  assert.equal(normalizeQueue('potluck'), 'RFY');
  assert.equal(normalizeQueue('last_chance'), 'AFA');
  assert.equal(normalizeQueue('encore'), 'AI');
  assert.equal(extractEnrollmentGuid('market#B000000001#customer#vine.enrollment.12345678-1234-1234-1234-123456789abc'), '12345678-1234-1234-1234-123456789abc');
  assert.equal(extractEnrollmentGuid({ enrollment_guid: '12345678-1234-1234-1234-123456789abc' }), '12345678-1234-1234-1234-123456789abc');
});

test('missing money sentinels never normalize to zero', () => {
  assert.equal(finiteMoney('N/A'), null);
  assert.equal(finiteMoney('Unavailable'), null);
  assert.equal(finiteMoney('CAD'), null);
  assert.equal(finiteMoney('$0.00'), 0);
  assert.equal(finiteMoney('C$399.99'), 399.99);
});

test('persisted recommendation metadata drops account IDs but retains enrollment and variant details', () => {
  const full = 'MARKET#B000000001#CUSTOMER-SECRET#vine.enrollment.12345678-1234-1234-1234-123456789abc';
  const scrubbed = sanitizeRecommendationMetadata({
    recommendationId: full,
    customerId: 'CUSTOMER-SECRET',
    nested: {
      amazon_customer_id: 'CUSTOMER-SECRET',
      variants: [{ asin: 'B000000002', recommendation: full, dimensions: { Colour: 'Blue' } }]
    }
  });
  assert.equal(scrubbed.recommendationId, '12345678-1234-1234-1234-123456789abc');
  assert.equal(scrubbed.customerId, undefined);
  assert.equal(scrubbed.nested.amazon_customer_id, undefined);
  assert.equal(scrubbed.nested.variants[0].recommendation, '12345678-1234-1234-1234-123456789abc');
  assert.deepEqual(scrubbed.nested.variants[0].dimensions, { Colour: 'Blue' });
  assert.equal(JSON.stringify(scrubbed).includes('CUSTOMER-SECRET'), false);
});

test('order job carries only minimum product metadata and an expiring policy', () => {
  const job = buildOrderJob({
    now: 1_700_000_000_000,
    ttlMs: 15_000,
    jobId: 'job-12345678',
    item: {
      asin: 'b000000001',
      title: 'Coffee machine',
      queue: 'RFY',
      enrollment_guid: '12345678-1234-1234-1234-123456789abc',
      is_parent_asin: true,
      price: '$129.99',
      etv: '0',
      sources: ['VH', 'UV']
    },
    policy: {
      mode: 'auto',
      unattendedCheckoutLimit: 30,
      currency: 'CAD',
      ruleId: 'coffee-rule',
      ruleName: 'Coffee'
    }
  });
  assert.equal(job.expiresAtMs - job.issuedAtMs, 15_000);
  assert.equal(job.item.asin, 'B000000001');
  assert.equal(job.item.queue, 'RFY');
  assert.equal(job.item.enrollmentGuid, '12345678-1234-1234-1234-123456789abc');
  assert.equal(job.item.price, 129.99);
  assert.equal(job.item.etv, 0);
  assert.equal(job.policy.variantPolicy, 'first_available');
  assert.equal(job.policy.selectedVariantAsin, null);
  assert.equal(job.policy.unattendedCheckoutLimit, 30);
  assert.equal(JSON.stringify(job).includes('customer#'), false);
});

test('exact child selection is signed into the order policy and invalid instructions fail closed', () => {
  const base = {
    now: 1_700_000_000_000,
    ttlMs: 15_000,
    jobId: 'job-exact-12345',
    item: {
      asin: 'B000000010',
      title: 'Parent item',
      queue: 'AFA',
      enrollmentGuid: '12345678-1234-1234-1234-123456789abc',
      isParentAsin: true
    }
  };
  const job = buildOrderJob({
    ...base,
    policy: {
      mode: 'auto',
      variantPolicy: 'exact',
      selectedVariantAsin: 'b000000011',
      unattendedCheckoutLimit: 30
    }
  });
  assert.equal(job.policy.variantPolicy, 'exact');
  assert.equal(job.policy.selectedVariantAsin, 'B000000011');
  assert.throws(() => buildOrderJob({
    ...base,
    jobId: 'job-exact-bad01',
    policy: { mode: 'auto', variantPolicy: 'exact', selectedVariantAsin: 'bad', unattendedCheckoutLimit: 30 }
  }), /valid selected variant ASIN/i);
  assert.throws(() => buildOrderJob({
    ...base,
    jobId: 'job-exact-bad02',
    policy: { mode: 'auto', variantPolicy: 'exact', selectedVariantAsin: 'B000000010', unattendedCheckoutLimit: 30 }
  }), /child ASIN distinct from its parent/i);
  assert.throws(() => buildOrderJob({
    ...base,
    jobId: 'job-exact-bad03',
    policy: { mode: 'auto', variantPolicy: 'random', unattendedCheckoutLimit: 30 }
  }), /variant policy/i);
});

test('read-only Amazon variant request carries only bounded transient lookup metadata', () => {
  const request = buildVariantLookupRequest({
    now: 1_700_000_000_000,
    ttlMs: 15_000,
    lookupId: 'lookup-amazon-123456',
    nonce: 'lookup-nonce-123456',
    asin: 'b000000010',
    queue: 'last_chance',
    enrollmentGuid: 'MARKET#B000000010#CUSTOMER#vine.enrollment.12345678-1234-1234-1234-123456789abc'
  });
  assert.deepEqual(request, {
    protocolVersion: 1,
    lookupId: 'lookup-amazon-123456',
    issuedAtMs: 1_700_000_000_000,
    expiresAtMs: 1_700_000_015_000,
    nonce: 'lookup-nonce-123456',
    operation: 'read_only_amazon_variants',
    item: {
      asin: 'B000000010',
      queue: 'AFA',
      enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
    }
  });
  assert.equal(JSON.stringify(request).includes('CUSTOMER'), false);
  assert.equal(JSON.stringify(request).includes('title'), false);
  assert.throws(() => buildVariantLookupRequest({
    ...request,
    lookupId: 'short',
    enrollmentGuid: request.item.enrollmentGuid
  }), /lookup ID/i);
  assert.throws(() => buildVariantLookupRequest({
    ...request,
    asin: request.item.asin,
    queue: 'AI',
    enrollmentGuid: request.item.enrollmentGuid
  }), /RFY or AFA/i);
  assert.throws(() => buildVariantLookupRequest({
    ...request,
    asin: 'B000000010-extra',
    enrollmentGuid: request.item.enrollmentGuid
  }), /parent ASIN/i);
});

test('Amazon variant result sanitizer is strict, bounded, child-only, and secret-free', () => {
  const base = {
    protocolVersion: 1,
    lookupId: 'lookup-amazon-123456',
    requestNonce: 'lookup-request-nonce-123456',
    nonce: 'variant-result-123456',
    eventAtMs: 1_700_000_000_100,
    parentAsin: 'B000000010',
    source: 'amazon_companion',
    success: true,
    persisted: false,
    orderAttempted: false,
    variants: [{
      asin: 'B000000011',
      label: 'Colour: Blue',
      dimensionEntries: [{ name: 'Colour', value: 'Blue' }]
    }],
    discardedVariants: 2,
    errorCode: null,
    message: null
  };
  const result = sanitizeVariantLookupResult(base, { now: 1_700_000_000_200 });
  assert.deepEqual(result.variants, [{
    asin: 'B000000011',
    label: 'Colour: Blue',
    dimensionEntries: [{ name: 'Colour', value: 'Blue' }],
    source: 'amazon_companion'
  }]);
  assert.equal(Object.isFrozen(result), true);
  assert.equal(Object.isFrozen(result.variants), true);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    cookie: 'secret'
  }, { now: base.eventAtMs }), /unsupported fields/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    variants: [{ ...base.variants[0], offerListingId: 'SECRET' }]
  }, { now: base.eventAtMs }), /unsupported fields/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    variants: [{ ...base.variants[0], asin: base.parentAsin }]
  }, { now: base.eventAtMs }), /parent/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    variants: Array.from({ length: 101 }, (_, index) => ({
      asin: `B${String(index).padStart(9, '0')}`,
      label: 'x',
      dimensionEntries: []
    }))
  }, { now: base.eventAtMs }), /collection/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    success: false,
    variants: [],
    discardedVariants: 0,
    errorCode: 'agent busy with spaces',
    message: 'busy'
  }, { now: base.eventAtMs }), /error code/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    eventAtMs: String(base.eventAtMs)
  }, { now: base.eventAtMs }), /timestamp/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    discardedVariants: '2'
  }, { now: base.eventAtMs }), /discarded-variant/i);
  assert.throws(() => sanitizeVariantLookupResult({
    ...base,
    persisted: true
  }, { now: base.eventAtMs }), /read-only boundary/i);
});

test('order result sanitizer allows bounded status only and strips arbitrary fields', () => {
  const result = sanitizeOrderResult({
    jobId: 'job-12345678',
    state: 'placed',
    nonce: 'result-nonce-123456',
    asin: 'B000000001',
    variantAsin: 'B000000002',
    finalTotal: 'C$2.75',
    currency: 'cad',
    message: 'done',
    amazonOrderId: 'ORDER-1',
    cookie: 'must-not-survive',
    timings: { placeOrderClickedAtMs: 100, confirmedAtMs: 200, arbitrary: 300 }
  }, { now: 500 });
  assert.equal(result.finalTotal, 2.75);
  assert.equal(result.currency, 'CAD');
  assert.equal(result.cookie, undefined);
  assert.deepEqual(result.timings, { placeOrderClickedAtMs: 100, confirmedAtMs: 200 });
  assert.throws(() => sanitizeOrderResult({ jobId: 'job-12345678', state: 'unknown' }), /state/i);
});
