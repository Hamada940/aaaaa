'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { signedEnvelope, verifyPayloadSignature } = require('../lib/order-protocol');
const { OrderCoordinator, isAllowedResultTransition } = require('../lib/order-coordinator');

class FakeSocket {
  constructor() {
    this.readyState = 1;
    this.sent = [];
  }
  send(value) { this.sent.push(JSON.parse(value)); }
  close() { this.readyState = 3; }
}

function connectedHarness() {
  const files = new Map();
  let now = 1_700_000_000_000;
  let failNextSavePath = null;
  const coordinator = new OrderCoordinator({
    pairingFile: '/pairing',
    rulesFile: '/rules',
    jobsFile: '/jobs',
    watchesFile: '/watches',
    safetyFile: '/safety',
    loadJSON: (file, fallback) => files.has(file) ? structuredClone(files.get(file)) : fallback,
    saveJSON: (file, value) => {
      if (file === failNextSavePath) {
        failNextSavePath = null;
        return false;
      }
      files.set(file, structuredClone(value));
      return true;
    },
    now: () => now
  });
  const pairing = coordinator.issuePairing();
  const socket = new FakeSocket();
  coordinator.attachSocket(socket);
  const challenge = socket.sent.at(-1).payload.challenge;
  const hello = {
    challenge,
    timestampMs: now,
    nonce: 'hello-security-12345',
    accountHash: 'a'.repeat(64),
    agentId: 'test-agent',
    agentVersion: '1.0.0',
    capabilities: {
      localApproval: true,
      fastCheckout: true,
      firstAvailableVariant: true,
      exactVariantSelection: true,
      readOnlyAmazonVariantLookup: true,
      currency: 'CAD'
    }
  };
  assert.equal(coordinator.handleSocketMessage(
    socket,
    JSON.stringify(signedEnvelope(pairing.pairingSecret, 'agent_hello', hello))
  ).ok, true);
  return {
    coordinator,
    socket,
    files,
    secret: pairing.pairingSecret,
    get now() { return now; },
    advance(ms) { now += ms; },
    failNextSave(path) { failNextSavePath = path; }
  };
}

const ITEM = {
  asin: 'B000000001',
  title: 'Security test item',
  queue: 'AI',
  enrollmentGuid: '12345678-1234-1234-1234-123456789abc',
  price: 10,
  etv: 0,
  sources: ['UV']
};

function sendResult(h, jobId, overrides = {}) {
  const payload = {
    jobId,
    state: 'received',
    nonce: `result-${Math.random().toString(36).slice(2)}-123456`,
    eventAtMs: h.now,
    asin: ITEM.asin,
    ...overrides
  };
  const envelope = signedEnvelope(h.secret, 'agent_result', payload);
  return {
    envelope,
    outcome: h.coordinator.handleSocketMessage(h.socket, JSON.stringify(envelope))
  };
}

test('Amazon variant lookup uses one signed read-only request and correlated sanitized result without a job', async () => {
  const h = connectedHarness();
  const promise = h.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-coordinator-123456',
    asin: 'B000000010',
    queue: 'AFA',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  const request = h.socket.sent.at(-1);
  assert.equal(request.type, 'variant_lookup_request');
  assert.equal(verifyPayloadSignature(h.secret, request.type, request.payload, request.signature), true);
  assert.deepEqual(request.payload.item, {
    asin: 'B000000010',
    queue: 'AFA',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  assert.equal(request.payload.operation, 'read_only_amazon_variants');
  assert.equal(h.coordinator.recentJobs().length, 0);
  assert.throws(() => h.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-coordinator-654321',
    asin: 'B000000010',
    queue: 'AFA',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  }), error => error?.code === 'variant_lookup_in_flight');

  const resultPayload = {
    protocolVersion: 1,
    lookupId: request.payload.lookupId,
    requestNonce: request.payload.nonce,
    nonce: 'variant-coordinator-result-123456',
    eventAtMs: h.now,
    parentAsin: 'B000000010',
    source: 'amazon_companion',
    success: true,
    persisted: false,
    orderAttempted: false,
    variants: [{
      asin: 'B000000011',
      label: 'Colour: Blue',
      dimensionEntries: [{ name: 'Colour', value: 'Blue' }]
    }],
    discardedVariants: 0,
    errorCode: null,
    message: null
  };
  const resultEnvelope = signedEnvelope(h.secret, 'variant_lookup_result', resultPayload);
  const accepted = h.coordinator.handleSocketMessage(h.socket, JSON.stringify(resultEnvelope));
  assert.deepEqual(accepted, {
    ok: true,
    lookupId: 'lookup-coordinator-123456',
    success: true
  });
  const resolved = await promise;
  assert.equal(resolved.persisted, false);
  assert.equal(resolved.orderAttempted, false);
  assert.deepEqual(resolved.variants[0], {
    asin: 'B000000011',
    label: 'Colour: Blue',
    dimensionEntries: [{ name: 'Colour', value: 'Blue' }],
    source: 'amazon_companion'
  });
  assert.equal(h.coordinator.recentJobs().length, 0);
  const replay = h.coordinator.handleSocketMessage(h.socket, JSON.stringify(resultEnvelope));
  assert.equal(replay.ok, false);
  assert.match(replay.error, /replayed/i);
});

test('Amazon variant lookup fails closed on companion error, disconnect, mismatch, and unknown result', async () => {
  const outdated = connectedHarness();
  outdated.coordinator.agentCapabilities.readOnlyAmazonVariantLookup = false;
  assert.throws(() => outdated.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-outdated-123456',
    asin: 'B000000020',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  }), error => error?.code === 'companion_update_required' && /25\.0\.4/.test(error.message));

  const failed = connectedHarness();
  const failedPromise = failed.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-failure-123456',
    asin: 'B000000020',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  const failedRequest = failed.socket.sent.at(-1).payload;
  const failureOutcome = failed.coordinator.handleSocketMessage(failed.socket, JSON.stringify(signedEnvelope(
    failed.secret,
    'variant_lookup_result',
    {
      protocolVersion: 1,
      lookupId: failedRequest.lookupId,
      requestNonce: failedRequest.nonce,
      nonce: 'variant-failure-result-123456',
      eventAtMs: failed.now,
      parentAsin: failedRequest.item.asin,
      source: 'amazon_companion',
      success: false,
      persisted: false,
      orderAttempted: false,
      variants: [],
      discardedVariants: 0,
      errorCode: 'agent_busy',
      message: 'No Amazon request was attempted because an order job was active'
    }
  )));
  assert.equal(failureOutcome.ok, true);
  await assert.rejects(failedPromise, error =>
    error?.code === 'agent_busy' && /No Amazon request was attempted/i.test(error.message)
  );
  assert.equal(failed.coordinator.recentJobs().length, 0);

  const disconnected = connectedHarness();
  const disconnectedPromise = disconnected.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-disconnect-123456',
    asin: 'B000000020',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  disconnected.coordinator.detachSocket(disconnected.socket, 'test disconnect');
  await assert.rejects(disconnectedPromise, error =>
    error?.code === 'agent_disconnected' && /disconnect/i.test(error.message)
  );

  const replaced = connectedHarness();
  const replacedPromise = replaced.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-replaced-123456',
    asin: 'B000000020',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  const replacementSocket = new FakeSocket();
  replaced.coordinator.attachSocket(replacementSocket);
  const replacementChallenge = replacementSocket.sent.at(-1).payload.challenge;
  const replacementHello = {
    challenge: replacementChallenge,
    timestampMs: replaced.now,
    nonce: 'hello-replacement-123456',
    accountHash: 'a'.repeat(64),
    agentId: 'replacement-agent',
    agentVersion: '25.0.4',
    capabilities: {
      localApproval: true,
      fastCheckout: true,
      firstAvailableVariant: true,
      exactVariantSelection: true,
      readOnlyAmazonVariantLookup: true,
      currency: 'CAD'
    }
  };
  assert.equal(replaced.coordinator.handleSocketMessage(
    replacementSocket,
    JSON.stringify(signedEnvelope(replaced.secret, 'agent_hello', replacementHello))
  ).ok, true);
  await assert.rejects(replacedPromise, error =>
    error?.code === 'agent_replaced' && /replaced/i.test(error.message)
  );

  const mismatch = connectedHarness();
  const mismatchPromise = mismatch.coordinator.requestAmazonVariantLookup({
    lookupId: 'lookup-mismatch-123456',
    asin: 'B000000020',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  const mismatchRequest = mismatch.socket.sent.at(-1).payload;
  const mismatchPayload = {
    protocolVersion: 1,
    lookupId: 'lookup-mismatch-123456',
    requestNonce: mismatchRequest.nonce,
    nonce: 'variant-mismatch-result-123456',
    eventAtMs: mismatch.now,
    parentAsin: 'B000000099',
    source: 'amazon_companion',
    success: true,
    persisted: false,
    orderAttempted: false,
    variants: [],
    discardedVariants: 0,
    errorCode: null,
    message: null
  };
  const mismatchOutcome = mismatch.coordinator.handleSocketMessage(
    mismatch.socket,
    JSON.stringify(signedEnvelope(mismatch.secret, 'variant_lookup_result', mismatchPayload))
  );
  assert.equal(mismatchOutcome.ok, false);
  assert.match(mismatchOutcome.error, /does not match/i);
  const nonceMismatchOutcome = mismatch.coordinator.handleSocketMessage(
    mismatch.socket,
    JSON.stringify(signedEnvelope(mismatch.secret, 'variant_lookup_result', {
      ...mismatchPayload,
      requestNonce: 'different-request-nonce-123456',
      nonce: 'variant-nonce-mismatch-result-123456',
      parentAsin: mismatchRequest.item.asin
    }))
  );
  assert.equal(nonceMismatchOutcome.ok, false);
  assert.match(nonceMismatchOutcome.error, /does not match/i);
  mismatch.coordinator.detachSocket(mismatch.socket, 'cleanup');
  await assert.rejects(mismatchPromise, error => error?.code === 'agent_disconnected');

  const unknown = connectedHarness();
  const unknownPayload = {
    ...mismatchPayload,
    lookupId: 'lookup-unknown-123456',
    nonce: 'variant-unknown-result-123456',
    parentAsin: 'B000000020'
  };
  const unknownOutcome = unknown.coordinator.handleSocketMessage(
    unknown.socket,
    JSON.stringify(signedEnvelope(unknown.secret, 'variant_lookup_result', unknownPayload))
  );
  assert.equal(unknownOutcome.ok, false);
  assert.match(unknownOutcome.error, /unknown or expired/i);
});

test('result state machine allows forward progress and makes terminal outcomes immutable', () => {
  assert.equal(isAllowedResultTransition('dispatched', 'received'), true);
  assert.equal(isAllowedResultTransition('received', 'evaluating'), true);
  assert.equal(isAllowedResultTransition('evaluating', 'submitting'), true);
  assert.equal(isAllowedResultTransition('submitting', 'placed'), true);
  assert.equal(isAllowedResultTransition('placed', 'received'), false);
  assert.equal(isAllowedResultTransition('submitting', 'approval_required'), false);

  const h = connectedHarness();
  const job = h.coordinator.dispatchManual(ITEM).job;
  assert.equal(sendResult(h, job.jobId, { state: 'received', nonce: 'result-forward-0001' }).outcome.ok, true);
  assert.equal(sendResult(h, job.jobId, { state: 'evaluating', nonce: 'result-forward-0002' }).outcome.ok, true);
  assert.equal(sendResult(h, job.jobId, { state: 'submitting', nonce: 'result-forward-0003', finalTotal: 0, currency: 'CAD' }).outcome.ok, true);
  assert.equal(sendResult(h, job.jobId, { state: 'placed', nonce: 'result-forward-0004', finalTotal: 0, currency: 'CAD' }).outcome.ok, true);
  const regression = sendResult(h, job.jobId, { state: 'received', nonce: 'result-forward-0005' }).outcome;
  assert.equal(regression.ok, false);
  assert.match(regression.error, /transition/i);
  assert.equal(h.coordinator.recentJobs(1)[0].state, 'placed');
});

test('terminal results are acknowledged only after durable save and same-state retransmission is idempotent', () => {
  const h = connectedHarness();
  const job = h.coordinator.dispatchManual(ITEM).job;
  const messagesBeforeFailure = h.socket.sent.length;
  h.failNextSave('/jobs');
  const rejectedUntilDurable = sendResult(h, job.jobId, {
    state: 'placed',
    nonce: 'result-terminal-persist-0001',
    finalTotal: 0,
    currency: 'CAD'
  }).outcome;
  assert.equal(rejectedUntilDurable.ok, false);
  assert.match(rejectedUntilDurable.error, /could not be saved/i);
  assert.equal(h.socket.sent.length, messagesBeforeFailure, 'no signed acknowledgement was sent');
  assert.equal(h.coordinator.recentJobs(1)[0].state, 'dispatched', 'the in-memory transition rolled back');
  assert.equal(h.coordinator.publicSafety().circuitBreaker.reasonCode, 'job_persistence_failed');

  const first = sendResult(h, job.jobId, {
    state: 'placed',
    nonce: 'result-terminal-ack-0001',
    finalTotal: 0,
    currency: 'CAD'
  }).outcome;
  assert.equal(first.ok, true);
  const firstAck = h.socket.sent.at(-1);
  assert.equal(firstAck.type, 'agent_result_ack');
  assert.equal(firstAck.payload.jobId, job.jobId);
  assert.equal(firstAck.payload.state, 'placed');
  assert.equal(firstAck.payload.duplicate, false);
  assert.equal(verifyPayloadSignature(h.secret, firstAck.type, firstAck.payload, firstAck.signature), true);

  h.advance(10);
  const retransmitted = sendResult(h, job.jobId, {
    state: 'placed',
    nonce: 'result-terminal-ack-0002',
    finalTotal: 999,
    currency: 'CAD'
  }).outcome;
  assert.equal(retransmitted.ok, true);
  assert.equal(retransmitted.duplicate, true);
  const duplicateAck = h.socket.sent.at(-1);
  assert.equal(duplicateAck.type, 'agent_result_ack');
  assert.equal(duplicateAck.payload.duplicate, true);
  assert.equal(h.coordinator.recentJobs(1)[0].finalTotal, 0);
});

test('a socket-dispatched job with no PC acknowledgement becomes ambiguous and trips the circuit', () => {
  const h = connectedHarness();
  const job = h.coordinator.dispatchManual(ITEM).job;
  assert.equal(job.state, 'dispatched');
  h.advance(15_001);
  const retained = h.coordinator.recentJobs(1)[0];
  assert.equal(retained.state, 'ambiguous');
  assert.equal(retained.reasonCode, 'dispatch_acknowledgement_missing');
  assert.equal(h.coordinator.publicSafety().circuitBreaker.reasonCode, 'dispatch_acknowledgement_missing');

  h.advance(1);
  const lateTerminal = sendResult(h, job.jobId, {
    state: 'placed',
    nonce: 'result-late-after-missing-ack-0001',
    finalTotal: 0,
    currency: 'CAD'
  }).outcome;
  assert.equal(lateTerminal.ok, true, 'a durable late terminal result can resolve the ledger');
  assert.equal(h.coordinator.recentJobs(1)[0].state, 'placed');
  assert.equal(h.coordinator.publicSafety().circuitBreaker.active, true, 'human acknowledgement is still required');

  const restartFiles = new Map([...h.files].map(([key, value]) => [key, structuredClone(value)]));
  restartFiles.get('/jobs')[0].state = 'created';
  restartFiles.get('/jobs')[0].reasonCode = null;
  restartFiles.delete('/safety');
  const recovered = new OrderCoordinator({
    pairingFile: '/pairing', rulesFile: '/rules', jobsFile: '/jobs', watchesFile: '/watches', safetyFile: '/safety',
    loadJSON: (file, fallback) => restartFiles.has(file) ? structuredClone(restartFiles.get(file)) : fallback,
    saveJSON: (file, value) => { restartFiles.set(file, structuredClone(value)); return true; },
    now: () => h.now
  });
  assert.equal(recovered.recentJobs(1)[0].state, 'ambiguous');
  assert.equal(recovered.recentJobs(1)[0].reasonCode, 'dispatch_outcome_unresolved_after_restart');
  assert.equal(recovered.publicSafety().circuitBreaker.reasonCode, 'dispatch_outcome_unresolved_after_restart');
});

test('signed order results are nonce-protected, account-job-bound, and time-bounded', () => {
  const h = connectedHarness();
  const first = h.coordinator.dispatchManual(ITEM).job;
  const accepted = sendResult(h, first.jobId, { state: 'received', nonce: 'result-replay-0001' });
  assert.equal(accepted.outcome.ok, true);
  const replay = h.coordinator.handleSocketMessage(h.socket, JSON.stringify(accepted.envelope));
  assert.equal(replay.ok, false);
  assert.match(replay.error, /replay/i);

  const secondItem = { ...ITEM, asin: 'B000000002' };
  const second = h.coordinator.dispatchManual(secondItem).job;
  const mismatch = sendResult(h, second.jobId, {
    state: 'failed',
    nonce: 'result-mismatch-001',
    asin: ITEM.asin
  }).outcome;
  assert.equal(mismatch.ok, false);
  assert.match(mismatch.error, /ASIN mismatch/i);

  const stale = sendResult(h, second.jobId, {
    state: 'failed',
    nonce: 'result-stale-000001',
    asin: secondItem.asin,
    eventAtMs: h.now - 5 * 60 * 1000
  }).outcome;
  assert.equal(stale.ok, false);
  assert.match(stale.error, /timestamp/i);
});
