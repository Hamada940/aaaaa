'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

async function policyModule() {
  return import(pathToFileURL(path.join(__dirname, '..', 'companion', 'src', 'checkout-policy.mjs')).href);
}

test('Canadian final totals parse across common Amazon formats without guessing conflicts', async () => {
  const policy = await policyModule();
  assert.deepEqual(policy.parseMoneyText('C$0.00', 'CAD'), { amount: 0, currency: 'CAD', raw: 'C$0.00' });
  assert.equal(policy.parseMoneyText('CDN$ 1,234.56', 'CAD').amount, 1234.56);
  assert.equal(policy.parseMoneyText('30,00 $', 'CAD').amount, 30);
  assert.equal(policy.parseMoneyText('US$2.00', 'CAD').currency, 'USD');

  const selected = policy.selectCheckoutTotal([
    { priority: 1, selector: '#total-a', text: 'C$2.50' },
    { priority: 1, selector: '#total-b', text: 'CAD 2.50' }
  ], 'CAD');
  assert.equal(selected.ok, true);
  assert.equal(selected.amount, 2.5);
  assert.equal(policy.selectCheckoutTotal([
    { priority: 1, text: 'C$2.50' },
    { priority: 1, text: 'C$3.50' }
  ], 'CAD').reasonCode, 'checkout_total_ambiguous');
  assert.equal(policy.selectCheckoutTotal([{ priority: 1, text: 'US$2.50' }], 'CAD').reasonCode, 'checkout_currency_mismatch');
});

test('C$0 and totals within the editable limit proceed; approval is exact-total-bound', async () => {
  const policy = await policyModule();
  const evaluate = values => policy.evaluateCheckoutPolicy({
    total: 0,
    currency: 'CAD',
    expectedCurrency: 'CAD',
    unattendedCheckoutLimit: 30,
    mode: 'auto',
    ...values
  });
  assert.equal(evaluate({ total: 0 }).action, 'place');
  assert.equal(evaluate({ total: 30 }).action, 'place');
  assert.equal(evaluate({ total: 30.01 }).action, 'approval');
  assert.equal(evaluate({ total: 30.01, localApproval: { approved: true, total: 30.01, currency: 'CAD' } }).action, 'place');
  assert.equal(evaluate({ total: 30.02, localApproval: { approved: true, total: 30.01, currency: 'CAD' } }).action, 'approval');
  assert.equal(evaluate({ total: 0, mode: 'approval' }).action, 'approval');
  assert.equal(evaluate({ total: 0, mode: 'approval', localApproval: { approved: true, total: 0, currency: 'CAD' } }).action, 'place');
  assert.equal(evaluate({ currency: 'USD' }).action, 'fail');
});
