'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const test = require('node:test');

const { buildSignedBody } = require('../lib/vh-identity');
const {
  ITEM_EXPLORER_API_VERSION,
  ITEM_EXPLORER_APP_VERSION,
  ITEM_EXPLORER_ACTION,
  ITEM_EXPLORER_QUEUE,
  ITEM_EXPLORER_PAGE_SIZE,
  ITEM_EXPLORER_VARIANT_LIMIT,
  ItemExplorerValidationError,
  normalizeItemExplorerRequest,
  buildItemExplorerContent,
  normalizeEmbeddedVariants,
  sanitizeItemExplorerResponse,
  isEntitlementMessage,
  safeUpstreamMessage
} = require('../lib/vh-item-explorer');

const validRequest = Object.freeze({
  requestId: 'f8a041ef-5709-4a7c-a724-d6fc58a3ce5b',
  asin: 'b0abc12345',
  title: 'coffee * grinder',
  orderBy: 'last_broadcast_desc',
  page: 3,
  etvMin: '10',
  etvMax: '99.95',
  priceMin: '',
  priceMax: '250.00',
  unavailable: 'available'
});

function legacyIdentity() {
  return {
    identityMode: 'legacy-synthetic',
    country: 'ca',
    uuid: 'saved-working-uuid'
  };
}

test('normalizes only the official practical Item Explorer filter surface', () => {
  const normalized = normalizeItemExplorerRequest(validRequest);
  assert.deepEqual(normalized, {
    ...validRequest,
    asin: 'B0ABC12345'
  });
  assert.equal(Object.isFrozen(normalized), true);

  assert.throws(
    () => normalizeItemExplorerRequest({ ...validRequest, queue: 'all' }),
    error => error instanceof ItemExplorerValidationError && /Unsupported search field/.test(error.message)
  );
  assert.throws(
    () => normalizeItemExplorerRequest({ ...validRequest, action: 'get_info' }),
    error => error instanceof ItemExplorerValidationError && /Unsupported search field/.test(error.message)
  );
  assert.throws(
    () => normalizeItemExplorerRequest({ ...validRequest, etvMin: '100', etvMax: '10' }),
    /minimum cannot exceed maximum/
  );
  assert.throws(
    () => normalizeItemExplorerRequest({ ...validRequest, page: 0 }),
    /Page must be an integer/
  );
  assert.throws(
    () => normalizeItemExplorerRequest({ ...validRequest, unavailable: 'maybe' }),
    /Availability must be/
  );
  assert.throws(
    () => normalizeItemExplorerRequest({ ...validRequest, title: 'coffee\u202eabc' }),
    /unsupported control characters/
  );
});

test('builds the exact RFY-only official 4.7.4 action without mutation or extra actions', () => {
  const normalized = normalizeItemExplorerRequest(validRequest);
  const content = buildItemExplorerContent(normalized, legacyIdentity(), 'saved-customer-id');
  assert.deepEqual(Object.keys(content), [
    'api_version',
    'app_version',
    'action',
    'country',
    'uuid',
    'cid',
    'asin',
    'title',
    'orderBy',
    'queue',
    'page',
    'etvMin',
    'etvMax',
    'priceMin',
    'priceMax',
    'unavailable',
    'matchHighlightKeywords',
    'ignoreHideKeywords'
  ]);
  assert.equal(content.api_version, ITEM_EXPLORER_API_VERSION);
  assert.equal(content.app_version, ITEM_EXPLORER_APP_VERSION);
  assert.equal(content.action, ITEM_EXPLORER_ACTION);
  assert.equal(content.queue, ITEM_EXPLORER_QUEUE);
  assert.equal(content.country, 'ca');
  assert.equal(content.uuid, 'saved-working-uuid');
  assert.equal(content.cid, 'saved-customer-id');
  assert.equal(content.matchHighlightKeywords, false);
  assert.equal(content.ignoreHideKeywords, false);
  assert.doesNotMatch(
    JSON.stringify(content),
    /getLast100|"action":"get_info"|item_explorer_(?:variants|broadcast_log|stats)/i
  );
});

test('signs the pre-signature Item Explorer object with the saved compatibility identity', () => {
  const content = buildItemExplorerContent(
    normalizeItemExplorerRequest(validRequest),
    legacyIdentity(),
    'saved-customer-id'
  );
  const body = buildSignedBody(content, legacyIdentity());
  const { s, pk, ...signedContent } = body;
  assert.deepEqual(signedContent, content);
  assert.equal(Buffer.from(s, 'base64').length, 64);
  const publicKey = crypto.createPublicKey({ key: pk, format: 'jwk' });
  assert.equal(
    crypto.verify(
      'sha256',
      Buffer.from(JSON.stringify(signedContent), 'utf8'),
      { key: publicKey, dsaEncoding: 'ieee-p1363' },
      Buffer.from(s, 'base64')
    ),
    true
  );
});

test('sanitizes a bounded official response and decodes server text without retaining secrets', () => {
  const result = sanitizeItemExplorerResponse(
    {
      query_time: '0.25',
      total_items: 51,
      wait_time: '2.2',
      page: 2,
      items: {
        first: {
          asin: 'B0ABC12345',
          title: 'Coffee &amp;amp; Tea &lt;b&gt;Maker&lt;/b&gt;',
          img_url: 'https://m.media-amazon.com/images/I/example.jpg',
          etv: '12.34',
          price: 35,
          unavailable: 'true',
          order_success: '4',
          order_failed: 2,
          date_added: '2026-09-01T12:00:00Z',
          last_broadcast: 1788282000,
          is_parent_asin: 1,
          variants: JSON.stringify([
            {
              asin: 'B0VARIANT1',
              dimensions: { Colour: 'Blue', Size: 'Large' },
              recommendationId: 'must-not-leave-backend',
              offerListingId: 'secret-offer'
            },
            { asin: 'B0VARIANT2', dimensions: { Colour: 'Red' }, available: false },
            { asin: 'invalid', dimensions: { Colour: 'Discard' } }
          ]),
          enrollment_guid: 'must-not-leave-backend'
        },
        invalid: {
          asin: '<script>',
          title: 'discard me'
        }
      }
    },
    2
  );
  assert.equal(result.page, 2);
  assert.equal(result.pageSize, ITEM_EXPLORER_PAGE_SIZE);
  assert.equal(result.totalItems, 51);
  assert.equal(result.waitTime, 3);
  assert.equal(result.queryTime, 0.25);
  assert.equal(result.discardedItems, 1);
  assert.equal(result.items.length, 1);
  assert.deepEqual(result.items[0], {
    asin: 'B0ABC12345',
    title: 'Coffee & Tea <b>Maker</b>',
    imageUrl: 'https://m.media-amazon.com/images/I/example.jpg',
    etv: '12.34',
    price: '35',
    unavailable: true,
    orderSuccess: 4,
    orderFailed: 2,
    dateAdded: '2026-09-01T12:00:00Z',
    lastBroadcast: '1788282000',
    isParentAsin: true,
    isPreRelease: false,
    variants: [{
      asin: 'B0VARIANT1',
      dimensionEntries: [
        { name: 'Colour', value: 'Blue' },
        { name: 'Size', value: 'Large' }
      ]
    }],
    queue: 'potluck'
  });
  assert.doesNotMatch(JSON.stringify(result), /enrollment_guid|must-not-leave-backend|secret-offer|offerListing|recommendation|uuid|cid|signature/i);
});

test('embedded Item Explorer variants are passive, bounded, targetable, and secret-free', () => {
  const variants = normalizeEmbeddedVariants({
    B0CHILD001: {
      variation_values: [{ name: 'Style', value: 'Pro' }],
      customerId: 'secret-customer',
      enrollmentGuid: 'secret-enrollment'
    },
    B0CHILD002: {
      dimension_values: { Colour: 'Black' },
      unavailable: 'true'
    },
    B0CHILD006: 'secret scalar must not leave',
    invalid_key: { asin: 'bad' }
  });
  assert.deepEqual(variants, [{
    asin: 'B0CHILD001',
    dimensionEntries: [{ name: 'Style', value: 'Pro' }]
  }, {
    asin: 'B0CHILD006',
    dimensionEntries: []
  }]);
  assert.doesNotMatch(JSON.stringify(variants), /secret|customer|enrollment/i);
  assert.deepEqual(normalizeEmbeddedVariants(['B0CHILD007']), [{
    asin: 'B0CHILD007',
    dimensionEntries: []
  }]);
  assert.deepEqual(normalizeEmbeddedVariants('{not-json'), []);
});

test('singular and URI-encoded embedded variants retain only bounded display-safe child data', () => {
  const singular = sanitizeItemExplorerResponse({
    items: [{
      asin: 'B0PARENT01',
      title: 'Parent',
      variants: [{ asin: 'B0PARENT01', dimensions: { Type: 'Parent must not be selectable' } }],
      variant_asin: 'B0SINGLE01',
      variant_dimensions: encodeURIComponent(JSON.stringify({
        Secret: { offerListingId: 'must-not-leave' },
        customerId: 'must-not-leave',
        offerListingId: 'must-not-leave',
        Colour: 'Green',
        Size: 'Medium'
      })),
      customer_id: 'must-not-leave'
    }],
    total_items: 1,
    wait_time: 0,
    page: 1,
    query_time: 0.01
  });
  assert.deepEqual(singular.items[0].variants, [{
    asin: 'B0SINGLE01',
    dimensionEntries: [
      { name: 'Colour', value: 'Green' },
      { name: 'Size', value: 'Medium' }
    ]
  }]);

  const encoded = normalizeEmbeddedVariants(encodeURIComponent(JSON.stringify([
    {
      variantAsin: 'B0URI00001',
      dimensions: Object.fromEntries(Array.from({ length: 12 }, (_, index) => [`Option ${index + 1}`, `Value ${index + 1}`])),
      label: `Blue\u202e${'x'.repeat(300)}`,
      signature: 'must-not-leave'
    },
    { asin: 'B0URI00002', available: 'FALSE' },
    { asin: 'B0URI00003', isUnavailable: 'yes' },
    { asin: 'B0URI00004', orderable: 'no' },
    { asin: 'B0URI00005', status: 'out_of_stock' }
  ])));
  assert.equal(encoded.length, 1);
  assert.equal(encoded[0].asin, 'B0URI00001');
  assert.equal(encoded[0].dimensionEntries.length, 8);
  assert.equal(encoded[0].label.includes('\u202e'), false);
  assert.equal(encoded[0].label.length, 240);
  assert.doesNotMatch(JSON.stringify(encoded), /must-not-leave|signature/i);

  const bounded = normalizeEmbeddedVariants(Array.from({ length: 105 }, (_, index) => ({
    asin: `B${String(index).padStart(9, '0')}`,
    dimensions: { Index: index }
  })));
  assert.equal(bounded.length, ITEM_EXPLORER_VARIANT_LIMIT);
});

test('rejects oversized pages and classifies only genuine entitlement wording', () => {
  assert.throws(
    () =>
      sanitizeItemExplorerResponse({
        items: Array(ITEM_EXPLORER_PAGE_SIZE + 1).fill({}),
        total_items: ITEM_EXPLORER_PAGE_SIZE + 1,
        wait_time: 0,
        page: 1,
        query_time: 0.1
      }),
    /too many items/
  );
  assert.equal(isEntitlementMessage('Invalid UUID or Patreon subscription insufficient.'), true);
  assert.equal(isEntitlementMessage('Tier 3 required'), true);
  assert.equal(isEntitlementMessage('temporary gateway failure'), false);
  assert.equal(safeUpstreamMessage('<b>Tier 3 &amp; trial</b>'), '<b>Tier 3 & trial</b>');
  assert.equal(safeUpstreamMessage('x'.repeat(1000)).length, 300);
});
