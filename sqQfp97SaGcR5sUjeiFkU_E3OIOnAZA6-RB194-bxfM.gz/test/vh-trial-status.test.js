'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');
const {
  TRIAL_STATUS_ACTION,
  TRIAL_STATUS_API_VERSION,
  TRIAL_STATUS_APP_VERSION,
  TRIAL_STATUS_MAX_RESPONSE_BYTES,
  TrialStatusValidationError,
  normalizeTrialStatusRequest,
  buildTrialStatusContent,
  sanitizeTrialStatusResponse
} = require('../lib/vh-trial-status');

const REQUEST_ID = 'trial-status-click_0123456789';
const NOW_MS = Date.parse('2026-10-06T12:00:00.000Z');

test('trial-status request accepts only one browser-generated replay ID', () => {
  assert.deepEqual(normalizeTrialStatusRequest({ requestId: REQUEST_ID }), {
    requestId: REQUEST_ID
  });
  for (const body of [
    null,
    [],
    {},
    { requestId: 'short' },
    { requestId: REQUEST_ID, uuid: 'replacement' },
    { requestId: REQUEST_ID, action: 'anything' },
    { requestId: REQUEST_ID, filters: {} }
  ]) {
    assert.throws(
      () => normalizeTrialStatusRequest(body),
      error => error instanceof TrialStatusValidationError && error.statusCode === 400
    );
  }
});

test('signed content is the exact official get_user_stats shape and excludes the local request ID', () => {
  const content = buildTrialStatusContent(
    normalizeTrialStatusRequest({ requestId: REQUEST_ID }),
    { country: 'CA', uuid: 'saved-uuid', fid: 'saved-fid' },
    'saved-cid'
  );
  assert.deepEqual(content, {
    api_version: TRIAL_STATUS_API_VERSION,
    app_version: TRIAL_STATUS_APP_VERSION,
    action: TRIAL_STATUS_ACTION,
    country: 'ca',
    uuid: 'saved-uuid',
    fid: 'saved-fid',
    cid: 'saved-cid'
  });
  assert.equal(TRIAL_STATUS_API_VERSION, 5);
  assert.equal(TRIAL_STATUS_APP_VERSION, '4.7.4');
  assert.equal(TRIAL_STATUS_ACTION, 'get_user_stats');
  assert.ok(TRIAL_STATUS_MAX_RESPONSE_BYTES <= 512 * 1024);
  assert.equal(Object.hasOwn(content, 'requestId'), false);
  assert.equal(Object.hasOwn(content, 'resolved_uuid'), false);

  const legacyBlankFid = buildTrialStatusContent(
    normalizeTrialStatusRequest({ requestId: `${REQUEST_ID}-blank` }),
    { country: 'ca', uuid: 'saved-legacy-uuid', fid: '' },
    'saved-legacy-cid'
  );
  assert.equal(legacyBlankFid.fid, '');
  assert.equal(legacyBlankFid.uuid, 'saved-legacy-uuid');
  assert.equal(legacyBlankFid.cid, 'saved-legacy-cid');
});

test('active response returns only sanitized entitlement fields and computes UTC-day ceiling', () => {
  const trialEndsAt = Math.floor((NOW_MS + (2 * 86400000) + 1000) / 1000);
  const result = sanitizeTrialStatusResponse({
    trial_active: true,
    trial_ends_at: trialEndsAt,
    patreon_membership_tier: 2,
    wait_time: 12.1,
    resolved_uuid: 'must-never-be-used',
    uuid_mismatch: true,
    devices: [{ id: 'private-device' }],
    contribution_stats: { items: 999 },
    active_payment_method: 'private-payment',
    arbitrary_secret: 'discard-me'
  }, NOW_MS);

  assert.deepEqual(result, {
    trialActive: true,
    trialEndsAt,
    trialEndsAtIso: new Date(trialEndsAt * 1000).toISOString(),
    daysRemaining: 3,
    membershipTier: 2,
    waitTime: 13
  });
  assert.equal(Object.hasOwn(result, 'resolved_uuid'), false);
  assert.equal(Object.hasOwn(result, 'devices'), false);
  assert.equal(Object.hasOwn(result, 'contribution_stats'), false);
  assert.equal(Object.hasOwn(result, 'active_payment_method'), false);
});

test('inactive response remains inactive and never infers entitlement from an expiry', () => {
  const futureEnd = Math.floor((NOW_MS + 10 * 86400000) / 1000);
  assert.deepEqual(sanitizeTrialStatusResponse({
    trial_active: false,
    trial_ends_at: futureEnd,
    patreon_membership_tier: 0
  }, NOW_MS), {
    trialActive: false,
    trialEndsAt: futureEnd,
    trialEndsAtIso: new Date(futureEnd * 1000).toISOString(),
    daysRemaining: 0,
    membershipTier: 0,
    waitTime: 0
  });
  assert.deepEqual(sanitizeTrialStatusResponse({
    trial_active: false,
    trial_ends_at: null
  }, NOW_MS), {
    trialActive: false,
    trialEndsAt: null,
    trialEndsAtIso: null,
    daysRemaining: null,
    membershipTier: null,
    waitTime: 0
  });
});

test('malformed or unsafe authoritative fields fail closed', () => {
  for (const value of [
    null,
    [],
    {},
    { trial_active: 'true', trial_ends_at: 1791290000 },
    { trial_active: true },
    { trial_active: true, trial_ends_at: 'tomorrow' },
    { trial_active: true, trial_ends_at: 999999999999 },
    { trial_active: true, trial_ends_at: 1791290000, patreon_membership_tier: '2' },
    { trial_active: true, trial_ends_at: 1791290000, patreon_membership_tier: 99 }
  ]) {
    assert.throws(() => sanitizeTrialStatusResponse(value, NOW_MS));
  }
});
