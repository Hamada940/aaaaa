'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const test = require('node:test');

const { buildSignedBody } = require('../lib/vh-identity');
const {
  ITEM_EXPLORER_VARIANTS_API_VERSION,
  ITEM_EXPLORER_VARIANTS_VERSION,
  ITEM_EXPLORER_VARIANTS_ACTION,
  ITEM_EXPLORER_VARIANTS_LIMIT,
  ITEM_EXPLORER_VARIANTS_MAX_CANDIDATES,
  ITEM_EXPLORER_VARIANTS_MAX_RESPONSE_BYTES,
  ItemExplorerVariantsValidationError,
  normalizeItemExplorerVariantsRequest,
  buildItemExplorerVariantsContent,
  sanitizeItemExplorerVariantsResponse
} = require('../lib/vh-item-explorer-variants');

const REQUEST_ID = 'load-variants-click_0123456789';
const PARENT_ASIN = 'B0PARENT01';

function legacyIdentity() {
  return {
    identityMode: 'legacy-synthetic',
    country: 'ca',
    uuid: 'saved-working-uuid'
  };
}

test('load-variants request accepts only one replay ID and one complete parent ASIN', () => {
  assert.deepEqual(normalizeItemExplorerVariantsRequest({
    requestId: REQUEST_ID,
    asin: PARENT_ASIN.toLowerCase()
  }), {
    requestId: REQUEST_ID,
    asin: PARENT_ASIN
  });

  for (const body of [
    null,
    [],
    {},
    { requestId: 'short', asin: PARENT_ASIN },
    { requestId: REQUEST_ID, asin: 'B0PARTIAL' },
    { requestId: REQUEST_ID, asin: PARENT_ASIN, action: 'item_explorer_variants' },
    { requestId: REQUEST_ID, asin: PARENT_ASIN, uuid: 'replacement' },
    { requestId: REQUEST_ID, asin: PARENT_ASIN, variants: [] }
  ]) {
    assert.throws(
      () => normalizeItemExplorerVariantsRequest(body),
      error => error instanceof ItemExplorerVariantsValidationError && error.statusCode === 400
    );
  }
});

test('builds the exact official VHelper 4.7.4 click contract with version, not app_version', () => {
  const request = normalizeItemExplorerVariantsRequest({
    requestId: REQUEST_ID,
    asin: PARENT_ASIN
  });
  const content = buildItemExplorerVariantsContent(
    request,
    legacyIdentity(),
    'saved-customer-id'
  );

  assert.deepEqual(Object.keys(content), [
    'api_version',
    'version',
    'action',
    'country',
    'uuid',
    'cid',
    'asin'
  ]);
  assert.deepEqual(content, {
    api_version: ITEM_EXPLORER_VARIANTS_API_VERSION,
    version: ITEM_EXPLORER_VARIANTS_VERSION,
    action: ITEM_EXPLORER_VARIANTS_ACTION,
    country: 'ca',
    uuid: 'saved-working-uuid',
    cid: 'saved-customer-id',
    asin: PARENT_ASIN
  });
  assert.equal(ITEM_EXPLORER_VARIANTS_API_VERSION, 5);
  assert.equal(ITEM_EXPLORER_VARIANTS_VERSION, '4.7.4');
  assert.equal(ITEM_EXPLORER_VARIANTS_ACTION, 'item_explorer_variants');
  assert.equal(Object.hasOwn(content, 'app_version'), false);
  assert.equal(Object.hasOwn(content, 'requestId'), false);
});

test('signs only the ordered official pre-signature fields with the saved identity', () => {
  const content = buildItemExplorerVariantsContent(
    normalizeItemExplorerVariantsRequest({ requestId: REQUEST_ID, asin: PARENT_ASIN }),
    legacyIdentity(),
    'saved-customer-id'
  );
  const body = buildSignedBody(content, legacyIdentity());
  const { s, pk, ...signedContent } = body;
  assert.deepEqual(signedContent, content);
  assert.equal(Buffer.from(s, 'base64').length, 64);
  const publicKey = crypto.createPublicKey({ key: pk, format: 'jwk' });
  assert.equal(
    crypto.verify(
      'sha256',
      Buffer.from(JSON.stringify(signedContent), 'utf8'),
      { key: publicKey, dsaEncoding: 'ieee-p1363' },
      Buffer.from(s, 'base64')
    ),
    true
  );
});

test('sanitizes only bounded child ASIN, display combination, and ETV fields', () => {
  const sanitized = sanitizeItemExplorerVariantsResponse({
    variants: [
      {
        asin: 'B0CHILD001',
        title: JSON.stringify({
          Colour: 'Blue &amp; White',
          Size: 'Large',
          customerId: 'must-not-leave',
          offerListingId: 'must-not-leave',
          Nested: { secret: 'must-not-leave' }
        }),
        etv: '12.34',
        enrollment_guid: 'must-not-leave',
        recommendation_id: 'must-not-leave'
      },
      {
        asin: 'B0CHILD002',
        title: 'Starter &amp; Deluxe',
        etv: 0,
        arbitrary_secret: 'must-not-leave'
      },
      { asin: PARENT_ASIN, title: 'Parent must not be selectable', etv: 99 },
      { asin: 'B0CHILD001', title: 'Duplicate', etv: 88 },
      { asin: 'invalid', title: 'Invalid ASIN', etv: 1 },
      null
    ],
    wait_time: '2.2',
    uuid: 'must-not-leave',
    cid: 'must-not-leave',
    signature: 'must-not-leave'
  }, PARENT_ASIN);

  assert.deepEqual(sanitized, {
    parentAsin: PARENT_ASIN,
    variants: [
      {
        asin: 'B0CHILD001',
        label: 'Colour: Blue & White • Size: Large',
        dimensionEntries: [
          { name: 'Colour', value: 'Blue & White' },
          { name: 'Size', value: 'Large' }
        ],
        etv: '12.34'
      },
      {
        asin: 'B0CHILD002',
        label: 'Starter & Deluxe',
        dimensionEntries: [],
        etv: '0'
      }
    ],
    discardedVariants: 4,
    waitTime: 3
  });
  assert.equal(Object.isFrozen(sanitized), true);
  assert.equal(Object.isFrozen(sanitized.variants), true);
  assert.doesNotMatch(
    JSON.stringify(sanitized),
    /must-not-leave|customer|offer|enrollment|recommendation|uuid|cid|signature|secret/i
  );
});

test('variant response bounds, deduplication, labels, and malformed shapes fail closed', () => {
  assert.equal(ITEM_EXPLORER_VARIANTS_LIMIT, 100);
  assert.ok(ITEM_EXPLORER_VARIANTS_MAX_RESPONSE_BYTES <= 512 * 1024);
  assert.ok(ITEM_EXPLORER_VARIANTS_MAX_CANDIDATES >= ITEM_EXPLORER_VARIANTS_LIMIT);

  const many = sanitizeItemExplorerVariantsResponse({
    variants: Array.from({ length: ITEM_EXPLORER_VARIANTS_LIMIT + 5 }, (_, index) => ({
      asin: `B${String(index).padStart(9, '0')}`,
      title: JSON.stringify(Object.fromEntries(
        Array.from({ length: 12 }, (__, dimension) => [`Option ${dimension + 1}`, `Value ${dimension + 1}`])
      )),
      etv: index === 0 ? 'not-money' : index
    }))
  }, PARENT_ASIN);
  assert.equal(many.variants.length, ITEM_EXPLORER_VARIANTS_LIMIT);
  assert.equal(many.discardedVariants, 5);
  assert.equal(many.variants[0].dimensionEntries.length, 8);
  assert.equal(many.variants[0].etv, null);
  assert.ok(many.variants.every(variant => variant.label.length <= 240));

  const secretOnlyTitle = sanitizeItemExplorerVariantsResponse({
    variants: [{ asin: 'B0SECRET01', title: '{"token":"discard"}', etv: null }]
  }, PARENT_ASIN);
  assert.equal(secretOnlyTitle.variants[0].label, 'B0SECRET01');
  assert.doesNotMatch(JSON.stringify(secretOnlyTitle), /"(?:token|discard)"/i);

  for (const value of [null, [], {}, { variants: null }, { variants: {} }]) {
    assert.throws(() => sanitizeItemExplorerVariantsResponse(value, PARENT_ASIN));
  }
  assert.throws(
    () => sanitizeItemExplorerVariantsResponse({
      variants: Array(ITEM_EXPLORER_VARIANTS_MAX_CANDIDATES + 1).fill({})
    }, PARENT_ASIN),
    /too many variant candidates/
  );
});
