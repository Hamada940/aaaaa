'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  MAX_OVPN_BYTES,
  MAX_WIREGUARD_BYTES,
  parseOvpnProfile,
  validateOvpnUpload,
  parseWireGuardConfig,
  validateWireGuardUpload,
  validateWireGuardManual,
  validateVpnSubmission,
  canonicalizeIp,
  canonicalizeCidr
} = require('../lib/vpn-profile');

function validProfile(overrides = '') {
  return `client
dev tun
proto udp
remote ca-one.example.test 1194
remote-cert-tls server
auth SHA512
cipher AES-256-CBC
${overrides}
<ca>
-----BEGIN CERTIFICATE-----
up this-is-certificate-data-not-a-directive
-----END CERTIFICATE-----
</ca>
<cert>
-----BEGIN CERTIFICATE-----
TEST
-----END CERTIFICATE-----
</cert>
<key>
TEST-INLINE-KEY-DATA
</key>
`;
}

test('accepts a self-contained UDP profile without exposing inline blocks as directives', () => {
  const result = validateOvpnUpload('canada.ovpn', validProfile());
  assert.equal(result.protocol, 'udp');
  assert.equal(result.remotes.length, 1);
  assert.equal(result.remotes[0].host, 'ca-one.example.test');
  assert.match(result.fingerprint, /^[a-f0-9]{64}$/);
  assert.deepEqual(result.inlineTags, ['ca', 'cert', 'key']);
});

test('accepts a TCP client profile and normalizes its protocol', () => {
  const profile = validProfile().replace('proto udp', 'proto tcp-client');
  assert.equal(parseOvpnProfile(profile).protocol, 'tcp');
});

test('rejects path components and non-ovpn upload names', () => {
  assert.throws(() => validateOvpnUpload('../secret.ovpn', validProfile()), /without path components/);
  assert.throws(() => validateOvpnUpload('profile.txt', validProfile()), /Only a single \.ovpn/);
});

test('rejects OpenVPN script hooks, config includes, plugins, and control sections', () => {
  assert.throws(() => parseOvpnProfile(validProfile('script-security 2\nup /tmp/run-me')), /Forbidden.*script-security/);
  assert.throws(() => parseOvpnProfile(validProfile('plugin malicious.so')), /Forbidden.*plugin/);
  assert.throws(() => parseOvpnProfile(validProfile('config /etc/shadow')), /Forbidden.*config/);
  assert.throws(
    () => parseOvpnProfile(validProfile('<connection>\nup /tmp/run-me\n</connection>')),
    /Unsupported OpenVPN inline section/
  );
});

test('rejects external certificate and key file references', () => {
  assert.throws(() => parseOvpnProfile(validProfile('ca /etc/shadow')), /External file reference/);
  assert.throws(() => parseOvpnProfile(validProfile('key client.key')), /External file reference/);
});

test('rejects profiles requiring separate username and password credentials', () => {
  assert.throws(() => parseOvpnProfile(validProfile('auth-user-pass')), /separate OpenVPN username\/password/);
});

test('accepts explicitly inline tls-crypt material', () => {
  const profile = validProfile('tls-crypt [inline]\n<tls-crypt>\n-----BEGIN OpenVPN Static key V1-----\nTEST\n-----END OpenVPN Static key V1-----\n</tls-crypt>');
  const result = parseOvpnProfile(profile);
  assert.ok(result.inlineTags.includes('tls-crypt'));
});

test('rejects encrypted private keys and TAP profiles', () => {
  const encryptedKeyMarker = ['-----', 'BEGIN ENCRYPTED PRIVATE KEY', '-----'].join('');
  assert.throws(
    () => parseOvpnProfile(validProfile().replace('TEST-INLINE-KEY-DATA', encryptedKeyMarker)),
    /Password-encrypted/
  );
  assert.throws(() => parseOvpnProfile(validProfile().replace('dev tun', 'dev tap')), /TAP profiles/);
});

test('rejects invalid endpoints, mixed protocols, and oversized profiles', () => {
  assert.throws(() => parseOvpnProfile(validProfile().replace('ca-one.example.test', 'bad/host')), /Invalid OpenVPN remote host/);
  assert.throws(
    () => parseOvpnProfile(validProfile('remote second.example.test 443 tcp-client')),
    /Mixed UDP and TCP/
  );
  assert.throws(() => parseOvpnProfile('x'.repeat(MAX_OVPN_BYTES + 1)), /exceeds/);
});

const WG_PRIVATE_KEY = Buffer.alloc(32, 1).toString('base64');
const WG_PUBLIC_KEY = Buffer.alloc(32, 2).toString('base64');
const WG_PRESHARED_KEY = Buffer.alloc(32, 3).toString('base64');

function validWireGuard(overrides = {}) {
  const address = overrides.address ?? '10.2.0.2/32, 2a07:b944::2:2/128';
  const allowedIPs = overrides.allowedIPs ?? '0.0.0.0/0, ::/0';
  const endpoint = overrides.endpoint ?? '[2001:4860:4860::8888]:51820';
  const preshared = overrides.presharedKey === false
    ? ''
    : `PresharedKey = ${overrides.presharedKey || WG_PRESHARED_KEY}\n`;
  return `[Interface]\nPrivateKey = ${overrides.privateKey || WG_PRIVATE_KEY}\nAddress = ${address}\nDNS = 10.2.0.1, 2001:4860:4860::8888\nMTU = ${overrides.mtu || 1320}\n\n[Peer]\nPublicKey = ${overrides.publicKey || WG_PUBLIC_KEY}\n${preshared}AllowedIPs = ${allowedIPs}\nEndpoint = ${endpoint}\nPersistentKeepalive = ${overrides.keepalive ?? 25}\n`;
}

test('accepts and canonicalizes a dual-stack WireGuard profile without exposing provider DNS', () => {
  const result = validateWireGuardUpload('canada.conf', validWireGuard());
  assert.equal(result.vpnProtocol, 'wireguard');
  assert.equal(result.transport, 'udp');
  assert.equal(result.endpoint, '2001:4860:4860::8888');
  assert.equal(result.endpointFamily, 'ipv6');
  assert.equal(result.endpointPort, 51820);
  assert.deepEqual(result.tunnelFamilies, ['ipv4', 'ipv6']);
  assert.equal(result.hasPresharedKey, true);
  assert.equal(result.ignoredProfileDns, true);
  assert.match(result.content, /AllowedIPs = 0\.0\.0\.0\/0, ::\/0/);
  assert.match(result.content, /Endpoint = \[2001:4860:4860::8888]:51820/);
  assert.doesNotMatch(result.content, /^DNS\s*=/m);
  assert.match(result.fingerprint, /^[a-f0-9]{64}$/);
});

test('manual WireGuard fields and equivalent .conf upload produce one canonical private representation', () => {
  const upload = parseWireGuardConfig(validWireGuard());
  const manual = validateWireGuardManual({
    privateKey: WG_PRIVATE_KEY,
    addresses: '10.2.0.2/32, 2a07:b944::2:2/128',
    publicKey: WG_PUBLIC_KEY,
    presharedKey: WG_PRESHARED_KEY,
    endpointHost: '2001:4860:4860::8888',
    endpointPort: '51820',
    allowedIPs: '0.0.0.0/0, ::/0',
    persistentKeepalive: '25',
    mtu: '1320'
  });
  assert.equal(manual.source, 'manual');
  assert.equal(manual.filename, 'manual-wireguard.conf');
  assert.equal(manual.content, upload.content);
  assert.equal(manual.fingerprint, upload.fingerprint);
});

test('WireGuard hostname endpoints normalize and IPv4-only provider profiles remain leak-safe', () => {
  const result = parseWireGuardConfig(validWireGuard({
    address: '10.7.0.2/32',
    allowedIPs: '0.0.0.0/0',
    endpoint: 'VPN-CA.EXAMPLE.TEST.:443',
    presharedKey: false,
    keepalive: 0
  }));
  assert.equal(result.endpoint, 'vpn-ca.example.test');
  assert.equal(result.endpointFamily, 'hostname');
  assert.deepEqual(result.tunnelFamilies, ['ipv4']);
  assert.equal(result.hasPresharedKey, false);
  assert.match(result.content, /AllowedIPs = 0\.0\.0\.0\/0, ::\/0/);
});

test('WireGuard IP and CIDR canonicalization is deterministic across compressed IPv6 forms', () => {
  assert.deepEqual(canonicalizeIp('2001:0DB8:0:0:0:0:0:1'), {
    family: 6,
    address: '2001:db8::1',
    words: [0x2001, 0xdb8, 0, 0, 0, 0, 0, 1]
  });
  assert.equal(canonicalizeCidr('2001:db8::1234/64', true).value, '2001:db8::/64');
  assert.equal(canonicalizeCidr('010.002.000.002/32', false).value, '10.2.0.2/32');
});

test('rejects WireGuard hooks, interface-state directives, unknown sections, and multiple peers', () => {
  assert.throws(
    () => parseWireGuardConfig(validWireGuard().replace('MTU = 1320', 'PostUp = curl bad.example')),
    /hook.*forbidden/i
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard().replace('MTU = 1320', 'Table = off')),
    /routing and interface state are managed/i
  );
  assert.throws(
    () => parseWireGuardConfig(`${validWireGuard()}\n[Peer]\nPublicKey = ${WG_PUBLIC_KEY}\n`),
    /exactly one \[Peer]/
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard().replace('[Peer]', '[Server]')),
    /Unsupported WireGuard section/
  );
});

test('rejects split-tunnel routes and incomplete dual-stack routing', () => {
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ allowedIPs: '10.0.0.0/8' })),
    /Split-tunnel/
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ allowedIPs: '::/0' })),
    /must include 0\.0\.0\.0\/0/
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ allowedIPs: '0.0.0.0/0' })),
    /IPv6 Address must include ::\/0/
  );
});

test('rejects missing IPv4 interface address, unusable addresses, malformed keys, and bad endpoint syntax', () => {
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ address: '2a07:b944::2:2/128' })),
    /must include an IPv4 interface address/
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ address: '127.0.0.1/32' })),
    /unusable interface address/
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ privateKey: 'not-a-key' })),
    /PrivateKey.*32-byte/
  );
  assert.throws(
    () => parseWireGuardConfig(validWireGuard({ endpoint: '2001:db8::1:51820' })),
    /\[IPv6]:port syntax|host:port or \[IPv6]/
  );
});

test('rejects non-conf WireGuard names, paths, oversized files, and duplicate secrets', () => {
  assert.throws(() => validateWireGuardUpload('../private.conf', validWireGuard()), /without path components/);
  assert.throws(() => validateWireGuardUpload('private.ovpn', validWireGuard()), /single \.conf/);
  assert.throws(() => parseWireGuardConfig('x'.repeat(MAX_WIREGUARD_BYTES + 1)), /exceeds/);
  assert.throws(
    () => parseWireGuardConfig(validWireGuard().replace(
      `PrivateKey = ${WG_PRIVATE_KEY}`,
      `PrivateKey = ${WG_PRIVATE_KEY}\nPrivateKey = ${WG_PRIVATE_KEY}`
    )),
    /may appear only once/
  );
});

test('protocol-aware submission keeps legacy OpenVPN requests and supports both WireGuard sources', () => {
  const legacy = validateVpnSubmission({ filename: 'legacy.ovpn', content: validProfile() });
  assert.equal(legacy.vpnProtocol, 'openvpn');
  assert.equal(legacy.candidateExtension, 'ovpn');

  const upload = validateVpnSubmission({
    protocol: 'wireguard', source: 'upload', filename: 'wg.conf', content: validWireGuard()
  });
  assert.equal(upload.vpnProtocol, 'wireguard');
  assert.equal(upload.candidateExtension, 'conf');

  const manual = validateVpnSubmission({
    protocol: 'wireguard', source: 'manual', wireguard: {
      privateKey: WG_PRIVATE_KEY,
      addresses: '10.2.0.2/32',
      publicKey: WG_PUBLIC_KEY,
      endpointHost: '198.51.100.10',
      endpointPort: 51820,
      allowedIPs: '0.0.0.0/0',
      persistentKeepalive: 25,
      mtu: 1320
    }
  });
  assert.equal(manual.vpnProtocol, 'wireguard');
  assert.equal(manual.endpointFamily, 'ipv4');
});
