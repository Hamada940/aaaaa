'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const test = require('node:test');
const { LivePersistence } = require('../lib/live-persistence');

const root = path.join(__dirname, '..');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const persistenceSource = fs.readFileSync(path.join(root, 'lib', 'live-persistence.js'), 'utf8');

function section(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start + startMarker.length);
  assert.ok(start >= 0, `missing section start: ${startMarker}`);
  assert.ok(end > start, `missing section end: ${endMarker}`);
  return source.slice(start, end);
}

function createPersistenceFixture(t, maximumItems = 2000) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'vine-live-persistence-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const files = {
    items: path.join(directory, 'items.json'),
    activity: path.join(directory, 'activity.json'),
    notified: path.join(directory, 'notified.json')
  };
  const store = new LivePersistence({
    files,
    initial: { items: [], activity: [], notified: {} },
    maximumItems
  });
  t.after(async () => store.close().catch(() => {}));
  return { store, files };
}

test('live dashboard handlers perform immediate keyed updates with no batching wait', () => {
  const livePath = section(
    dashboard,
    'function upsertLiveItemImmediately(item, isNewEvent = false)',
    'async function fetchItems(options = {})'
  );

  assert.match(livePath, /updateLiveCardImmediately\(item, removedItem, itemIndex\)/);
  assert.match(livePath, /function handleNewItemEvent\([^\n]+\)[\s\S]*playChime\(item\.isHighlight\)/);
  assert.match(livePath, /function handleUpdateItemEvent\([^\n]+\)[\s\S]*upsertLiveItemImmediately\(item\)/);
  assert.doesNotMatch(livePath, /sortAndRenderFeed|renderFeed\s*\(/);
  assert.doesNotMatch(livePath, /setTimeout|requestAnimationFrame|queueMicrotask/);
});

test('live dashboard path patches one card and updates only relevant UV queues', () => {
  const cardPath = section(
    dashboard,
    'function updateLiveCardImmediately(item, removedItem = null, itemIndex = -1)',
    'function upsertLiveItemImmediately(item, isNewEvent = false)'
  );
  const uvPath = section(
    dashboard,
    'function updateUvScreenBoardItemImmediately(previous, current)',
    'function openUvQueueInFeed(queueId)'
  );

  assert.match(cardPath, /productCardElement\(item\)/);
  assert.match(cardPath, /document\.getElementById\(`card-\$\{asin\}`\)/);
  assert.match(cardPath, /container\.insertBefore\(card, anchor\)/);
  assert.doesNotMatch(cardPath, /new Map|\.map\(node|sortAndRenderFeed/);
  assert.match(uvPath, /uvItemMatchesQueue\(previous, queue\)/);
  assert.match(uvPath, /existing\.replaceWith/);
  assert.doesNotMatch(uvPath, /setTimeout|requestAnimationFrame/);
});

test('unchanged feed status and diagnostics work stay off the live-item hot path', () => {
  const router = section(dashboard, 'function handleWsEvent(', 'function statusClass(');
  const statusBranch = section(
    router,
    "} else if (type === 'status')",
    "} else if (type === 'feed_health')"
  );
  const vhActivity = section(
    server,
    'function markVhApplicationActivity(reason)',
    'function noteVhPossibleGap('
  );

  assert.match(server, /const statusChanged = !uvAuthenticated \|\| uvStatus !== 'Authenticated'/);
  assert.match(server, /if \(statusChanged\) broadcastLocal\('status', \{ uvStatus, vhStatus, svStatus \}\)/);
  assert.match(vhActivity, /const statusChanged = vhStatus !== 'Connected'/);
  assert.match(vhActivity, /if \(firstReady \|\| statusChanged\) broadcastLocal\('status'/);
  assert.doesNotMatch(statusBranch, /refreshUvDiagnostics|refreshVhDiagnostics|fetch\s*\(/);
  assert.match(
    dashboard,
    /currentTab === 'settings' && document\.visibilityState === 'visible'/
  );
  assert.doesNotMatch(
    dashboard,
    /currentTab === 'settings' \|\| document\.visibilityState === 'visible'/
  );
});

test('bounded monotonic latency metrics add no timer or frame-scheduling wait', () => {
  const serverMetrics = section(
    server,
    'const LIVE_DELIVERY_SAMPLE_LIMIT = 256',
    'function addActivity(type, data)'
  );
  const dashboardMetrics = section(
    dashboard,
    'const LIVE_LATENCY_SAMPLE_LIMIT = 256',
    'function initWebSocket()'
  );

  assert.match(serverMetrics, /process\.hrtime\.bigint\(\)/);
  assert.match(serverMetrics, /samples\.splice\(0, samples\.length - LIVE_DELIVERY_SAMPLE_LIMIT\)/);
  assert.match(serverMetrics, /serverProcessingUs: elapsedUs/);
  assert.match(serverMetrics, /client\.send\(message\);[\s\S]*appendLiveDeliverySample\(meta\.source, elapsedUs\)/);
  assert.doesNotMatch(serverMetrics, /setTimeout|setInterval|requestAnimationFrame|queueMicrotask|await\s/);
  assert.match(dashboard, /performance\.now\(\)/);
  assert.match(dashboardMetrics, /samples\.length - LIVE_LATENCY_SAMPLE_LIMIT/);
  assert.doesNotMatch(dashboardMetrics, /setTimeout|setInterval|requestAnimationFrame|queueMicrotask|await\s/);
  assert.match(server, /liveDeliveryPerformance: publicLiveDeliveryPerformance\(\)/);
  assert.match(dashboard, /appendDashboardDeliverySample\('new_item'/);
  assert.match(dashboard, /appendDashboardDeliverySample\('update_item'/);
});

test('server starts dashboard and Telegram photo delivery before background persistence', () => {
  const ingestion = section(server, 'function ingestItem(', 'function applyUvAlertDetail(');
  const notification = section(server, 'function notifyLiveItem(item)', "localWss.on('connection'");
  const telegramLinks = section(server, 'function telegramItemLinks(item)', 'function buildTelegramMessage(item');
  const telegramMarkup = section(server, 'function telegramItemReplyMarkup(item)', 'function sendTelegramTextOnly(');
  const telegramText = section(server, 'function sendTelegramTextOnly(', 'function sendTelegramPhoto(item)');
  const telegramPhoto = section(server, 'function sendTelegramPhoto(item)', 'function sendTelegramNotification(item)');
  const telegramItem = section(server, 'function sendTelegramNotification(item)', 'async function sendDiscordWebhook(item)');

  assert.doesNotMatch(ingestion, /saveJSON\(ITEMS_FILE/);
  assert.doesNotMatch(ingestion, /sortItemsArray\(allItems\)/);
  assert.match(
    ingestion,
    /broadcastLocal\('new_item', withOrderRuleMatch\(newItem\), finishLiveDeliveryTiming\(liveTiming\)\);[\s\S]*notifyLiveItem\(newItem\);[\s\S]*persistItemUpsert\(newItem\)/
  );
  assert.match(
    ingestion,
    /broadcastLocal\('new_item', withOrderRuleMatch\(mergedItem\), finishLiveDeliveryTiming\(liveTiming\)\);[\s\S]*notifyLiveItem\(mergedItem\);[\s\S]*persistItemUpsert\(mergedItem\)/
  );
  assert.match(
    notification,
    /sendTelegramNotification\(item\);[\s\S]*sendDiscordWebhook\(item\);[\s\S]*livePersistence\?\.setNotified/
  );
  assert.doesNotMatch(notification, /saveJSON|setTimeout|await\s/);

  assert.match(telegramLinks, /item\.vineSearchUrl/);
  assert.match(telegramLinks, /getTwoWordSearchUrl|vine\/vine-items\?search=/);
  assert.match(telegramMarkup, /🔍 Open Vine Search/);
  assert.match(telegramMarkup, /url:\s*links\.searchUrl/);
  assert.match(telegramMarkup, /🛒 View on Amazon/);
  assert.match(telegramMarkup, /url:\s*links\.productUrl/);

  assert.match(telegramText, /\/sendMessage/);
  assert.match(telegramText, /disable_web_page_preview:\s*true/);
  assert.match(telegramText, /reply_markup/);
  assert.match(telegramText, /agent:\s*notificationHttpsAgent/);

  assert.match(telegramPhoto, /item\.img_url/);
  assert.match(telegramPhoto, /\/sendPhoto/);
  assert.match(telegramPhoto, /photo:\s*imageUrl/);
  assert.match(telegramPhoto, /caption:\s*buildTelegramMessage\(item,\s*\{\s*compact:\s*true\s*\}\)/);
  assert.match(telegramPhoto, /reply_markup:\s*replyMarkup/);
  assert.match(telegramPhoto, /sendTelegramTextOnly\(buildTelegramMessage\(item\),\s*replyMarkup\)/);
  assert.match(telegramItem, /return sendTelegramPhoto\(item\)/);
  assert.doesNotMatch(telegramPhoto + telegramItem, /await\s|setTimeout|requestAnimationFrame|queueMicrotask/);
});

test('persistence worker accepts a representative multiple-item burst and merges a repeated ASIN', async t => {
  const { store, files } = createPersistenceFixture(t);

  for (let index = 0; index < 10; index += 1) {
    assert.equal(
      store.upsertItem({
        asin: `B00000000${index}`,
        title: `Item ${index}`,
        date_added_ms: index,
        isPinned: false,
        isHighlight: false,
        isPriorityDismissed: false
      }),
      true
    );
  }
  store.upsertItem({
    asin: 'B000000005',
    title: 'Item 5 updated by second source',
    date_added_ms: 5,
    sources: ['UV', 'VH'],
    isPinned: false,
    isHighlight: false,
    isPriorityDismissed: false
  });
  store.prependActivity({ type: 'new_item', data: { asin: 'B000000005' } });
  store.setNotified('B000000005', 123456789);

  await store.flush();

  const items = JSON.parse(fs.readFileSync(files.items, 'utf8'));
  const activity = JSON.parse(fs.readFileSync(files.activity, 'utf8'));
  const notified = JSON.parse(fs.readFileSync(files.notified, 'utf8'));
  assert.equal(items.length, 10);
  assert.equal(new Set(items.map(item => item.asin)).size, 10);
  assert.equal(items.find(item => item.asin === 'B000000005').sources.join('+'), 'UV+VH');
  assert.equal(activity[0].data.asin, 'B000000005');
  assert.equal(notified.B000000005, 123456789);
});

test('live statistics use exact synchronous deltas and remain equal to a full recount', () => {
  const originHelpers = section(
    dashboard,
    'function normalizeAlertOrigin(value)',
    'function alertOriginLabel(originValue)'
  );
  const statsCode = section(dashboard, '// Update Stats Bar.', '// Filter Handlers');
  const elements = new Map();
  const context = {
    items: [],
    pinnedAsins: new Set(),
    dismissedPriorityAsins: new Set(['A000000019']),
    document: {
      getElementById(id) {
        if (!elements.has(id)) elements.set(id, { textContent: '' });
        return elements.get(id);
      }
    }
  };
  vm.createContext(context);
  vm.runInContext(
    `${originHelpers}\n${statsCode}\nthis.statsApi = {\n` +
      `  full: updateStats, delta: updateStatsForLiveUpsert,\n` +
      `  counts: () => ({ ...liveStatsCounts })\n};`,
    context
  );

  const makeItem = index => ({
    asin: `A${String(index).padStart(9, '0')}`,
    sources: index % 3 === 0 ? ['UV', 'VH'] : index % 3 === 1 ? ['UV'] : ['VH'],
    queue: index % 4 === 0 ? 'RFY' : index % 4 === 1 ? 'AFA' : 'AI',
    alertOrigins: index % 7 === 0 ? ['brenda'] : index % 11 === 0 ? ['redrop'] : ['ultraviner'],
    isZeroEtv: index % 13 === 0,
    isHighlight: index % 17 === 0
  });
  context.items = Array.from({ length: 2000 }, (_, index) => makeItem(index));
  context.statsApi.full();

  function expectedCounts() {
    const counts = { uv: 0, vh: 0, sv: 0, both: 0, rfy: 0, brenda: 0, redrop: 0, zero: 0, highlight: 0 };
    for (const item of context.items) {
      const sources = item.sources || [];
      const hasUv = sources.includes('UV');
      const hasVh = sources.includes('VH');
      const hasSv = sources.includes('SV');
      if (hasUv) counts.uv += 1;
      if (hasVh) counts.vh += 1;
      if (hasSv) counts.sv += 1;
      if ([hasUv, hasVh, hasSv].filter(Boolean).length > 1) counts.both += 1;
      if ((item.queue || '').toUpperCase() === 'RFY') counts.rfy += 1;
      const origins = (item.alertOrigins || []).map(value => String(value).toLowerCase());
      if (origins.includes('brenda')) counts.brenda += 1;
      if (origins.includes('redrop')) counts.redrop += 1;
      if (item.isZeroEtv) counts.zero += 1;
      if (item.isHighlight && !context.dismissedPriorityAsins.has(item.asin)) counts.highlight += 1;
    }
    return counts;
  }

  for (let operation = 0; operation < 300; operation += 1) {
    const itemIndex = operation % context.items.length;
    const previous = context.items[itemIndex];
    const current = {
      ...previous,
      sources: operation % 2 ? ['UV', 'VH'] : ['VH'],
      queue: operation % 5 ? 'AI' : 'RFY',
      alertOrigins: operation % 3 ? ['ultraviner'] : ['brenda', 'redrop'],
      isZeroEtv: operation % 7 === 0,
      isHighlight: operation % 11 === 0
    };
    context.items[itemIndex] = current;
    context.statsApi.delta(previous, current, null);

    if (operation % 25 === 0) {
      const added = makeItem(3000 + operation);
      context.items.unshift(added);
      const removed = context.items.length > 2000 ? context.items.pop() : null;
      context.statsApi.delta(null, added, removed);
    }

    assert.deepEqual(
      JSON.parse(JSON.stringify(context.statsApi.counts())),
      expectedCounts(),
      `stats diverged after operation ${operation}`
    );
  }
  assert.doesNotMatch(statsCode, /setTimeout|requestAnimationFrame|queueMicrotask/);
});

test('ordinary Ultraviner card origin is hidden only when the UV source badge already says it', () => {
  const helpers = section(
    dashboard,
    'function normalizeAlertOrigin(value)',
    'function queueBadgeClass(queueValue)'
  );
  const context = {};
  vm.createContext(context);
  vm.runInContext(`${helpers}\nthis.visible = visibleCardAlertOrigins;`, context);
  const visible = item => Array.from(context.visible(item));

  assert.deepEqual(visible({ sources: ['UV', 'VH'], alertOrigins: ['ultraviner'] }), []);
  assert.deepEqual(
    visible({ sources: ['UV', 'VH'], alertOrigins: ['ultraviner', 'brenda', 'redrop'] }),
    ['brenda', 'redrop']
  );
  assert.deepEqual(visible({ sources: ['VH'], alertOrigins: ['ultraviner'] }), ['ultraviner']);
  assert.match(dashboard, /retain all[\s\S]*filters, details, statistics, and notifications/);
});

test('server reuses immutable routing data and trusts a proven absent ASIN', () => {
  const upsert = section(server, 'function upsertItemInMemory(', 'function persistItemUpsert(');
  const uvHandler = section(server, "socket.on('message', raw => {", "socket.on('close',");
  const pending = section(
    server,
    'const pendingVhEnrichments = new Map()',
    'function applyVhEnrichment('
  );

  assert.match(upsert, /Number\.isInteger\(knownIndex\)/);
  assert.match(server, /upsertItemInMemory\(newItem, existingIndex\)/);
  assert.match(server, /const UV_HOUSEKEEPING_TYPES = new Set\(/);
  assert.match(uvHandler, /UV_HOUSEKEEPING_TYPES\.has\(type\)/);
  assert.doesNotMatch(uvHandler, /const housekeepingTypes = new Set/);
  assert.match(uvHandler, /const frameUvAlertQueueIds =[\s\S]*products\.forEach/);
  assert.match(uvHandler, /itemObj\.uvAlertQueueIds = frameUvAlertQueueIds/);
  assert.match(pending, /function sweepPendingVhEnrichments/);
  assert.match(pending, /sweepPendingVhEnrichments\(now\)/);
  assert.doesNotMatch(
    section(pending, 'function sweepPendingVhEnrichments', 'function rememberPendingVhEnrichment'),
    /setTimeout|setInterval/
  );
  assert.match(server, /const VERBOSE_LIVE_ITEM_LOGS = parseBoolean/);
  assert.match(server, /liveItemLog\(`\[UV FRAME\]/);
});

test('activity updates append one local row instead of refetching or accumulating forever', () => {
  const router = section(dashboard, 'function handleWsEvent(', 'function statusClass(');
  const activityBranch = section(
    router,
    "} else if (type === 'activity')",
    '\n      }\n    }'
  );
  assert.match(activityBranch, /prependActivityEntry\(data\)/);
  assert.doesNotMatch(activityBranch, /renderActivity|fetch\s*\(|unshift/);
  assert.doesNotMatch(dashboard, /let activityLog = \[\]/);
  assert.match(dashboard, /for \(let index = 100; index < rows\.length; index \+= 1\)/);
});

test('main-thread dedupe pruning preserves the full active window', () => {
  const setup = section(
    server,
    'let nextNotifiedSweepAt = 0',
    'const persistedFeedHealth'
  );
  const methods = section(server, 'function wasRecentlyNotified(', 'function itemSortTime(');
  const context = {
    config: { notificationDedupeMinutes: 5 },
    notifiedAt: new Map(),
    Date,
    Number,
    Math
  };
  vm.createContext(context);
  vm.runInContext(
    `${setup}\n${methods}\nthis.dedupeApi={` +
      'mark:markNotified,recent:wasRecentlyNotified,prune:pruneExpiredNotified};',
    context
  );
  const start = 1_000_000;
  context.dedupeApi.mark('B000000001', start);
  assert.equal(context.dedupeApi.recent('B000000001', start + 299999), true);
  assert.equal(context.dedupeApi.recent('B000000001', start + 300000), false);
  assert.equal(context.notifiedAt.has('B000000001'), false);
  assert.doesNotMatch(setup, /setTimeout|setInterval/);
});

test('persistence worker prunes expired notification records without a timer', async t => {
  const { store, files } = createPersistenceFixture(t);
  store.setNotified('OLDASIN000', 1000, 100);
  store.setNotified('NEWASIN000', 2100, 100);
  await store.flush();

  const notified = JSON.parse(fs.readFileSync(files.notified, 'utf8'));
  assert.equal(notified.OLDASIN000, undefined);
  assert.equal(notified.NEWASIN000, 2100);
  const workerPrune = section(
    persistenceSource,
    'function pruneExpiredNotified(now, force = false)',
    'function notifiedSnapshot()'
  );
  assert.doesNotMatch(workerPrune, /setTimeout|setInterval/);
});

test('persistence worker starts writes without a debounce timer and flushes clear operations', async t => {
  const markDirty = section(
    persistenceSource,
    'function markDirty(key)',
    'function upsertItem(item)'
  );
  assert.match(markDirty, /void pump\(\)/);
  assert.doesNotMatch(markDirty, /setTimeout|setInterval/);

  const { store, files } = createPersistenceFixture(t, 3);
  for (let index = 0; index < 5; index += 1) {
    store.upsertItem({ asin: `A${index}`, date_added_ms: index });
  }
  await store.flush();
  assert.equal(JSON.parse(fs.readFileSync(files.items, 'utf8')).length, 3);

  store.clearItems();
  store.clearActivity();
  store.clearNotified();
  await store.flush();
  assert.deepEqual(JSON.parse(fs.readFileSync(files.items, 'utf8')), []);
  assert.deepEqual(JSON.parse(fs.readFileSync(files.activity, 'utf8')), []);
  assert.deepEqual(JSON.parse(fs.readFileSync(files.notified, 'utf8')), {});
});
