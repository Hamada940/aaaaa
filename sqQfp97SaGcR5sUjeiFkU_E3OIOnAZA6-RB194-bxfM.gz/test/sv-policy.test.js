'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const server = read('server.js'), client = read('lib/sv-client.js'), protocol = read('lib/sv-protocol.js');
const proxy = read('sv-connect-proxy.js'), compose = read('compose.vpn.yml'), dashboard = read('public/index.html');
function section(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker), end = source.indexOf(endMarker, start + startMarker.length);
  assert.ok(start >= 0, `missing section start: ${startMarker}`);
  assert.ok(end > start, `missing section end: ${endMarker}`);
  return source.slice(start, end);
}

test('SmartViner transport exposes only login, refresh, me, channel auth and the live socket', () => {
  const request = section(client, 'async _requestJson(url,', 'async _invalidateAuth(');
  assert.match(request, /auth\\\/\(\?:login\|refresh\)/);
  assert.match(request, /parsed\.pathname === '\/api\/v1\/me'/);
  assert.match(request, /parsed\.pathname === '\/broadcasting\/auth'/);
  assert.match(client, /smartVinerWsUrl\(\)/);
  assert.match(protocol, /SV_LIVE_EVENTS = Object\.freeze\(\['NewGlobalItemDiscovered'\]\)/);
  assert.match(protocol, /SV_BLOCKED_PERSONAL_EVENTS = Object\.freeze\(\['RfyItemDiscovered'\]\)/);
  assert.match(protocol, /data:\s*blockedPersonal \? null : parseJsonData\(frame\.data\)/);
  assert.match(client, /frame\.blockedPersonal \|\| SV_BLOCKED_PERSONAL_EVENTS\.includes\(frame\.event\)/);
  assert.doesNotMatch(client, /\/api\/v1\/(?:feed|catalog|review|chat|order|telemetry|webhook|shopper)/i);
  const liveEmitIndex = client.indexOf("this.emit('item', item");
  const supervisionIndex = client.indexOf('  _startSupervision()', liveEmitIndex);
  assert.ok(liveEmitIndex > 0 && supervisionIndex > liveEmitIndex);
  assert.doesNotMatch(client.slice(liveEmitIndex, supervisionIndex), /_emitStatus\(/);
});

test('reconnect is live-only and contains no history or catch-up cursor path', () => {
  assert.doesNotMatch(client, /getLast100|feed\/discoveries|\bsince\b|\bcursor\b|catch.?up/i);
  assert.match(client, /gapRecoveryEnabled:\s*false/);
  assert.match(client, /historyEnabled:\s*false/);
  assert.match(client, /catalogueEnabled:\s*false/);
  assert.match(server, /SV remains on[\s\S]*private live-alert channel without a catch-up call/);
});

test('SmartViner credentials use a private file and never enter generic Settings', () => {
  assert.match(server, /const SV_AUTH_FILE = path\.join\(DATA_DIR, 'sv_auth\.json'\)/);
  assert.match(server, /saveJSON\(SV_AUTH_FILE, value, \{ sensitive: true, mode: 0o600 \}\)/);
  assert.match(server, /SmartViner account state and enablement are isolated from ordinary settings/);
  const genericGet = section(server, "app.get('/api/config'", "app.post('/api/config'");
  const genericSave = section(dashboard, 'async function saveSettings(options = {})', 'async function disableVhCompletely');
  assert.match(genericGet, /enableSV:\s*_isolatedSmartVinerEnablement/);
  assert.match(genericGet, /\.\.\.genericConfig/);
  assert.doesNotMatch(genericSave.replace(/\/\/.*$/gm, ''), /enableSV|sv-onboard|SmartViner/i);
  assert.match(genericSave, /every SmartViner field[\s\S]*intentionally[\s\S]*excluded/);
});

test('onboarding clears the browser password and server request body without persisting it', () => {
  const browserOnboard = section(dashboard, 'async function onboardSmartViner()', 'async function toggleSmartViner()');
  const serverOnboard = section(server, "app.post('/api/sv/onboard'", "app.post('/api/sv/enable'");
  const clientOnboard = section(client, 'async onboard({ email, password })', 'async disconnectAccount()');
  assert.match(browserOnboard, /passwordInput\.value = ''/);
  assert.doesNotMatch(browserOnboard, /console\.|localStorage|sessionStorage|indexedDB/);
  assert.match(serverOnboard, /req\.body\.password = ''/);
  assert.ok(serverOnboard.indexOf("req.body.password = ''") < serverOnboard.indexOf('if (!svHttpsProxyAgent)'));
  assert.doesNotMatch(serverOnboard, /console\.|saveJSON|SV_AUTH_FILE/);
  assert.match(clientOnboard, /password exists only in this request scope and is never persisted/);
  assert.doesNotMatch(clientOnboard, /this\.auth\.(?:password|email)/);
});

test('browser status and API responses expose metadata but no SmartViner tokens', () => {
  const publicStatus = section(client, 'publicStatus()', 'async initialize()');
  assert.match(publicStatus, /hasAccessToken/);
  assert.match(publicStatus, /hasRefreshToken/);
  assert.match(publicStatus, /personalRfyEnabled:\s*false/);
  assert.match(publicStatus, /blockedPersonalEvents:\s*\[\.\.\.SV_BLOCKED_PERSONAL_EVENTS\]/);
  assert.doesNotMatch(publicStatus, /accessToken:\s*this\.auth|refreshToken:\s*this\.auth/);
  const statusRoute = section(server, "app.get('/api/sv/status'", "app.post('/api/sv/onboard'");
  assert.match(statusRoute, /passwordStored:\s*false/);
  assert.match(statusRoute, /personalRfyEnabled:\s*false/);
  assert.doesNotMatch(statusRoute, /accessToken|refreshToken|Authorization/);
});

test('only authenticated private-channel code owns SV ingestion provenance', () => {
  assert.match(server, /const SV_LIVE_INGRESS = Symbol/);
  assert.match(server, /source === 'SV' && ingress !== SV_LIVE_INGRESS/);
  const listener = section(server, "svClient.on('item'", 'try {\n    await svClient.initialize()');
  assert.match(listener, /eventType !== 'NewGlobalItemDiscovered'\) return/);
  assert.ok(listener.indexOf("eventType !== 'NewGlobalItemDiscovered'") < listener.indexOf('ingestItem('));
  assert.match(listener, /ingestItem\([\s\S]*'SV'[\s\S]*SV_LIVE_INGRESS/);
  assert.match(server, /incomingSvPublishedAtMs[\s\S]*Number\.isFinite\(value\) && value > 0/);
  assert.equal((server.match(/SV_LIVE_INGRESS/g) || []).length, 3);
  assert.doesNotMatch(dashboard, /test.*SV drop|simulate.*SV/i);
});

test('SmartViner uses its own destination-locked proxy inside the VPN namespace', () => {
  assert.match(proxy, /const LISTEN_HOST = '127\.0\.0\.1'/);
  assert.match(proxy, /const ALLOWED_HOST = 'smartviner\.com'/);
  assert.match(proxy, /const ALLOWED_PORT = 443/);
  assert.match(proxy, /target\.host !== ALLOWED_HOST \|\| target\.port !== ALLOWED_PORT/);
  assert.match(proxy, /net\.createConnection\(\{ host: ALLOWED_HOST, port: ALLOWED_PORT \}\)/);
  assert.match(compose, /sv-proxy:[\s\S]*image:\s*vine-drop-hub:local[\s\S]*network_mode:\s*"service:vpn"/);
  assert.doesNotMatch(section(compose, '  sv-proxy:', '  app:'), /\n\s+build:/);
  assert.match(compose, /\.\/sv-connect-proxy\.js:\/app\/sv-connect-proxy\.js:ro/);
  assert.match(compose, /SV_HTTPS_PROXY:\s*http:\/\/127\.0\.0\.1:8889/);
  assert.match(compose, /VH_PROXY_URL:\s*http:\/\/172\.30\.77\.2:8888/);
  assert.doesNotMatch(section(compose, '  sv-proxy:', '  app:'), /\n\s+ports:/);
});

test('production server fails SmartViner closed when dedicated egress is absent', () => {
  assert.match(server, /isEnabled:\s*\(\) => Boolean\(config\.enableSV && svHttpsProxyAgent\)/);
  assert.match(server, /proxy must be exactly http:\/\/127\.0\.0\.1:8889/);
  assert.match(server, /if \(!svHttpsProxyAgent\)[\s\S]*Dedicated SmartViner egress is unavailable/);
  assert.match(server, /state: config\.enableSV && !svHttpsProxyAgent \? 'egress_unavailable'/);
});

test('feed-health notifications identify SmartViner rather than relabeling it as VHelper', () => {
  assert.match(server, /feed === 'VH'[\s\S]*'VHelper \(VH\)'[\s\S]*'SmartViner \(SV\)'/);
});

test('dashboard displays SV status, source filter, account isolation and three-source timing', () => {
  assert.match(dashboard, /id="sv-status-pill"/);
  assert.match(dashboard, /setSourceFilter\('SV_ONLY'/);
  assert.match(dashboard, /setSourceFilter\('MULTI'/);
  assert.match(dashboard, /id="smartviner-settings-section"/);
  assert.match(dashboard, /Password \(one login request only\)/i);
  assert.match(dashboard, /id="sv-onboard-password"[^>]*autocomplete="off"/);
  assert.match(dashboard, /SmartViner personal RFY: disabled \(global discoveries only\)/);
  assert.match(dashboard, /itemSourceArrivalOrder\(item\)/);
  assert.match(dashboard, /\['UV', 'VH', 'SV'\]/);
});

test('Compose retains SSH-tunnel-only dashboard exposure and no SmartViner host port', () => {
  assert.match(compose, /127\.0\.0\.1:3001:3001\/tcp/);
  assert.match(compose, /Dashboard\/API stay private/);
  const svService = section(compose, '  sv-proxy:', '  app:');
  assert.doesNotMatch(svService, /0\.0\.0\.0|3001|:\s*443/);
});
