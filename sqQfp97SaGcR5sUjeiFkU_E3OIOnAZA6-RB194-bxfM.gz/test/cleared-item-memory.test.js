'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const {
  DEFAULT_SUPPRESSION_HOURS,
  MAX_SUPPRESSION_HOURS,
  MAX_CLEARED_ITEMS,
  canonicalAsin,
  normalizeSuppressionHours,
  validateSuppressionHours,
  loadClearedItemMemory,
  serializeClearedItemMemory,
  pruneClearedItemMemory,
  rememberClearedItems,
  observeClearedItem,
  clearedItemMemoryStatus
} = require('../lib/cleared-item-memory');

const root = path.join(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');

function section(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start + startMarker.length);
  assert.ok(start >= 0, `missing section start: ${startMarker}`);
  assert.ok(end > start, `missing section end: ${endMarker}`);
  return source.slice(start, end);
}

test('cleared-item memory defaults to 24 hours and validates the editable range', () => {
  assert.equal(DEFAULT_SUPPRESSION_HOURS, 24);
  assert.equal(MAX_SUPPRESSION_HOURS, 8760);
  assert.equal(normalizeSuppressionHours(undefined), 24);
  assert.equal(validateSuppressionHours(0), 0);
  assert.equal(validateSuppressionHours('12.25'), 12.25);
  assert.equal(validateSuppressionHours(0.001), 0.001);
  assert.equal(validateSuppressionHours(8760), 8760);
  assert.throws(() => validateSuppressionHours(-1), RangeError);
  assert.throws(() => validateSuppressionHours(8760.01), RangeError);
  assert.throws(() => validateSuppressionHours(null), RangeError);
  assert.throws(() => validateSuppressionHours(''), RangeError);
  assert.throws(() => validateSuppressionHours(true), RangeError);
});

test('clear records one canonical ASIN without retaining a visible item payload', () => {
  const memory = new Map();
  const now = Date.parse('2026-11-04T12:00:00.000Z');
  const result = rememberClearedItems(
    memory,
    [
      {
        asin: 'b0clear001',
        title: 'Private product title must not enter the ledger',
        liveSources: ['UV'],
        img_url: 'https://example.invalid/private.jpg'
      }
    ],
    { now, suppressionHours: 24 }
  );

  assert.deepEqual(result, { changed: true, remembered: 1, removed: 0 });
  assert.equal(canonicalAsin(' b0clear001 '), 'B0CLEAR001');
  assert.deepEqual(memory.get('B0CLEAR001'), {
    asin: 'B0CLEAR001',
    clearedAt: now,
    lastConfirmedAt: null,
    sources: ['UV']
  });
  const serialized = JSON.stringify(serializeClearedItemMemory(memory));
  assert.doesNotMatch(serialized, /Private product title|private\.jpg/);
});

test('delayed UV, VH, and SV confirmations remain suppressed and silently enrich only the tombstone', () => {
  const memory = new Map();
  const clearedAt = Date.parse('2026-11-04T12:00:00.000Z');
  rememberClearedItems(memory, [{ asin: 'B0RACE0001', sources: ['UV'] }], {
    now: clearedAt,
    suppressionHours: 24
  });

  for (const [index, source] of ['VH', 'SV', 'UV'].entries()) {
    const result = observeClearedItem(memory, 'b0race0001', source, {
      now: clearedAt + (index + 1) * 1000,
      suppressionHours: 24
    });
    assert.equal(result.suppressed, true);
    assert.equal(result.expired, false);
  }

  assert.equal(memory.size, 1);
  assert.deepEqual(memory.get('B0RACE0001').sources, ['SV', 'UV', 'VH']);
  assert.equal(memory.get('B0RACE0001').lastConfirmedAt, clearedAt + 2000);
});

test('versioned persistence survives restart and preserves active suppression', () => {
  const clearedAt = Date.parse('2026-11-04T12:00:00.000Z');
  const original = new Map();
  rememberClearedItems(original, [{ asin: 'B0RESTART1', observedSources: ['UV', 'VH'] }], {
    now: clearedAt,
    suppressionHours: 24
  });
  observeClearedItem(original, 'B0RESTART1', 'SV', {
    now: clearedAt + 5000,
    suppressionHours: 24
  });

  const restarted = loadClearedItemMemory(serializeClearedItemMemory(original), {
    now: clearedAt + 60 * 60 * 1000,
    suppressionHours: 24
  });
  assert.equal(restarted.size, 1);
  assert.equal(
    observeClearedItem(restarted, 'B0RESTART1', 'VH', {
      now: clearedAt + 2 * 60 * 60 * 1000,
      suppressionHours: 24
    }).suppressed,
    true
  );
});

test('suppression expires exactly at the configured boundary and permits the ASIN again', () => {
  const memory = new Map();
  const clearedAt = 1_000_000;
  rememberClearedItems(memory, ['B0EXPIRES1'], { now: clearedAt, suppressionHours: 2 });

  assert.equal(
    observeClearedItem(memory, 'B0EXPIRES1', 'VH', {
      now: clearedAt + 2 * 60 * 60 * 1000 - 1,
      suppressionHours: 2
    }).suppressed,
    true
  );
  const expired = observeClearedItem(memory, 'B0EXPIRES1', 'SV', {
    now: clearedAt + 2 * 60 * 60 * 1000,
    suppressionHours: 2
  });
  assert.deepEqual(
    { suppressed: expired.suppressed, changed: expired.changed, expired: expired.expired },
    { suppressed: false, changed: true, expired: true }
  );
  assert.equal(memory.size, 0);
});

test('reducing the Settings duration prunes old records and zero disables memory', () => {
  const memory = new Map();
  const clearedAt = 10_000_000;
  rememberClearedItems(memory, ['B0SETTING1', 'B0SETTING2'], {
    now: clearedAt,
    suppressionHours: 24
  });
  assert.equal(
    pruneClearedItemMemory(memory, clearedAt + 3 * 60 * 60 * 1000, 2),
    2
  );

  rememberClearedItems(memory, ['B0SETTING3'], {
    now: clearedAt + 4 * 60 * 60 * 1000,
    suppressionHours: 24
  });
  const disabled = rememberClearedItems(memory, ['B0IGNORED1'], {
    now: clearedAt + 5 * 60 * 60 * 1000,
    suppressionHours: 0
  });
  assert.equal(disabled.changed, true);
  assert.equal(disabled.remembered, 0);
  assert.equal(memory.size, 0);
  assert.equal(clearedItemMemoryStatus(memory, { suppressionHours: 0 }).enabled, false);
});

test('ledger is bounded by evicting the oldest cleared ASINs first', () => {
  const memory = new Map();
  for (let index = 1; index <= 4; index += 1) {
    rememberClearedItems(memory, [`B0BOUND00${index}`], {
      now: index * 1000,
      suppressionHours: 24,
      maxEntries: 2
    });
  }
  assert.equal(memory.size, 2);
  assert.deepEqual([...memory.keys()].sort(), ['B0BOUND003', 'B0BOUND004']);
  assert.equal(MAX_CLEARED_ITEMS, 50000);
});

test('malformed, duplicate, and expired persisted entries are normalized safely', () => {
  const memory = loadClearedItemMemory(
    {
      schemaVersion: 1,
      entries: [
        { asin: '', clearedAt: 100 },
        { asin: 'B0DUP00001', clearedAt: 99000, sources: ['UV', 'BAD'] },
        { asin: 'b0dup00001', clearedAt: 99200, sources: ['VH'] },
        { asin: 'B0EXPIRED1', clearedAt: 1, sources: ['SV'] },
        { asin: 'B0NODATE01', clearedAt: 'nope' },
        { asin: 'B0HUGEDATE', clearedAt: 9e15 }
      ]
    },
    { now: 100000, suppressionHours: 0.01 }
  );
  assert.equal(memory.size, 1);
  assert.deepEqual(memory.get('B0DUP00001').sources, ['VH']);
  assert.equal(memory.get('B0DUP00001').clearedAt, 99200);
});

test('server gates cleared ASINs before card lookup, activity, broadcasts, and notifications', () => {
  const ingest = section(
    server,
    'function ingestItem(raw, source =',
    'async function initializeSmartViner()'
  );
  const gate = ingest.indexOf('suppressFromClearedItemMemory(asin, source, nowMs)');
  assert.ok(gate >= 0);
  assert.ok(gate < ingest.indexOf('allItems.findIndex'));
  assert.ok(gate < ingest.indexOf("addActivity('new_item'"));
  assert.ok(gate < ingest.indexOf("broadcastLocal('new_item'"));
  assert.ok(gate < ingest.indexOf('notifyLiveItem('));
  assert.match(
    server,
    /allItems = allItems\.filter\(item => !clearedItemMemory\.has\([\s\S]*?item\?\.asin/
  );
});

test('all clear/delete paths remember visible records and preserve normal dedupe while enabled', () => {
  const routes = section(
    server,
    "app.post('/api/delete-item'",
    "app.get('/api/pinned'"
  );
  assert.equal((routes.match(/rememberClearedRecords\(/g) || []).length, 3);
  assert.match(routes, /const legacyClear = config\.clearedItemSuppressionHours === 0/g);
  assert.doesNotMatch(routes, /notifiedAt\.clear\(\);[\s\S]*?rememberClearedRecords/);
  assert.match(routes, /if \(legacyClear\) notifiedAt\.clear\(\)/);
  assert.match(routes, /if \(legacyClear\) notifiedAt\.delete\(asin\)/);
  assert.match(server, /const previousMemory = new Map\(clearedItemMemory\)/);
  assert.match(server, /if \(!persisted\) \{[\s\S]*clearedItemMemory = previousMemory/);
});

test('Settings exposes, validates, saves, and reports the editable suppression period', () => {
  const configRoute = section(
    server,
    "app.post('/api/config'",
    '// Explicit VHelper kill/enable endpoints.'
  );
  assert.match(configRoute, /validateSuppressionHours\([\s\S]*body\.clearedItemSuppressionHours/);
  assert.match(configRoute, /'clearedItemSuppressionHours'/);
  assert.match(configRoute, /reconfigureClearedItemMemory = true/);
  assert.match(configRoute, /pruneClearedItemMemory\([\s\S]*config\.clearedItemSuppressionHours/);

  assert.match(dashboard, /id="cfg-cleared-item-hours"[^>]*min="0"[^>]*max="8760"/);
  assert.match(dashboard, /clearedItemSuppressionHours:\s*[\s\S]*cfg-cleared-item-hours/);
  assert.match(dashboard, /fetch\('\/api\/cleared-items\/status'\)/);
  assert.match(dashboard, /Default: 24 hours/);
  assert.match(
    dashboard,
    /function setInputValue\(id, value\) \{[\s\S]*document\.getElementById\(id\)[\s\S]*input\.value = value === null \|\| value === undefined \? '' : String\(value\)/
  );
  assert.ok(
    dashboard.indexOf('function setInputValue(id, value)') <
      dashboard.indexOf('async function loadSettings()'),
    'settings input helper must exist before loadSettings can call it'
  );
});

test('reset is isolated, typed-confirmed, and never exposes retained ASINs', () => {
  const route = section(
    server,
    "app.get('/api/cleared-items/status'",
    "app.get('/api/pinned'"
  );
  assert.match(server, /CLEARED_MEMORY_RESET_CONFIRMATION = 'RESET CLEARED ITEM MEMORY'/);
  assert.match(route, /body\.confirmation !== CLEARED_MEMORY_RESET_CONFIRMATION/);
  assert.match(route, /clearedItemMemory = new Map\(\)/);
  assert.match(route, /res\.json\(\{ success: true, removed \}\)/);
  assert.doesNotMatch(route, /serializeClearedItemMemory|\[\.\.\.clearedItemMemory/);

  const resetUi = section(
    dashboard,
    'async function resetClearedItemMemory()',
    'async function loadSettings()'
  );
  assert.match(resetUi, /prompt\(/);
  assert.match(resetUi, /confirmation !== required/);
  assert.match(resetUi, /\/api\/cleared-items\/reset/);
});
