'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

async function amazonModule() {
  return import(pathToFileURL(path.join(__dirname, '..', 'companion', 'src', 'amazon.mjs')).href);
}

test('local Vine session parser extracts only account context and detects login/CAPTCHA', async () => {
  const amazon = await amazonModule();
  const html = `<!doctype html><script data-a-state='{&quot;key&quot;:&quot;vvp-context&quot;}'>
    {"customerId":"CUSTOMER-LOCAL","marketplaceId":"A2EUQ1WTGCTBG2","csrfToken":"csrf-local"}
  </script>`;
  assert.deepEqual(amazon.extractVvpContextFromHtml(html), {
    customerId: 'CUSTOMER-LOCAL',
    marketplaceId: 'A2EUQ1WTGCTBG2',
    csrfToken: 'csrf-local'
  });
  assert.equal(amazon.pageFailureCode('<input name="password">', 'https://www.amazon.ca/ap/signin'), 'amazon_login_required');
  assert.equal(amazon.pageFailureCode('<input id="captchacharacters">'), 'amazon_captcha');
});

test('recommendation IDs are reconstructed transiently with account data only for RFY', async () => {
  const amazon = await amazonModule();
  const baseJob = {
    item: {
      asin: 'B000000001',
      queue: 'AI',
      enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
    }
  };
  const session = { marketplaceId: 'MARKET', customerId: 'CUSTOMER-LOCAL' };
  assert.equal(
    amazon.recommendationIdForJob(baseJob, session),
    'MARKET#B000000001#vine.enrollment.12345678-1234-1234-1234-123456789abc'
  );
  assert.equal(
    amazon.recommendationIdForJob({ ...baseJob, item: { ...baseJob.item, queue: 'RFY' } }, session),
    'MARKET#B000000001#CUSTOMER-LOCAL#vine.enrollment.12345678-1234-1234-1234-123456789abc'
  );
});

test('read-only variation choices retain only bounded child ASINs and safe dimensions', async () => {
  const amazon = await amazonModule();
  const result = amazon.amazonVariationChoices({
    result: {
      variations: [
        { asin: 'B000000010', dimensions: { Colour: 'Parent' } },
        { asin: 'B000000011', dimensions: { Colour: 'Blue', Size: 'Large', customerId: 'SECRET' } },
        { asin: 'B000000012', available: false, dimensions: { Colour: 'Red' } },
        { asin: 'B000000013', dimensions: { recommendationId: 'SECRET', Style: 'Classic' } },
        { asin: 'B000000011', dimensions: { Colour: 'Duplicate' } },
        { asin: 'invalid', dimensions: { Colour: 'Unsafe' } }
      ]
    }
  }, { parentAsin: 'B000000010', limit: 100 });
  assert.deepEqual(result.variants, [
    {
      asin: 'B000000011',
      label: 'Colour: Blue • Size: Large',
      dimensionEntries: [
        { name: 'Colour', value: 'Blue' },
        { name: 'Size', value: 'Large' }
      ]
    },
    {
      asin: 'B000000013',
      label: 'Style: Classic',
      dimensionEntries: [{ name: 'Style', value: 'Classic' }]
    }
  ]);
  assert.equal(result.discardedVariants, 4);
  assert.equal(JSON.stringify(result).includes('SECRET'), false);
  assert.throws(
    () => amazon.amazonVariationChoices({ result: { variations: {} } }, { parentAsin: 'B000000010' }),
    error => error?.code === 'amazon_variants_invalid'
  );
  assert.throws(
    () => amazon.amazonVariationChoices({ result: { variations: Array(1001).fill({ asin: 'B000000011' }) } }),
    error => error?.code === 'amazon_variants_invalid'
  );
});

test('variant, See Details, Request Product, and checkout form validators fail closed', async () => {
  const amazon = await amazonModule();
  const variants = amazon.variationsFromResponse({
    result: {
      recommendationId: 'variant-recommendation',
      variations: [
        { asin: 'B000000009', available: false },
        { asin: 'B000000008', available: 'FALSE' },
        { asin: 'B000000007', orderable: 'no' },
        { asin: 'B000000006', status: 'out_of_stock' },
        { asin: 'B000000003' },
        { asin: 'B000000002' },
        { asin: 'B000000003' },
        { asin: 'invalid' }
      ]
    }
  });
  assert.deepEqual(variants.asins, ['B000000003', 'B000000002']);
  assert.equal(variants.recommendationId, 'variant-recommendation');
  assert.throws(
    () => amazon.variationsFromResponse({ error: { exceptionType: 'SECRET_REMOTE_EXCEPTION_TEXT' } }),
    error => error?.code === 'recommendations_error' &&
      /could not return recommendation details/i.test(error.message) &&
      !error.message.includes('SECRET_REMOTE_EXCEPTION_TEXT')
  );
  assert.deepEqual(
    amazon.variationCandidatesForPolicy(variants, { variantPolicy: 'first_available' }),
    ['B000000003', 'B000000002']
  );
  assert.deepEqual(
    amazon.variationCandidatesForPolicy(variants, {
      variantPolicy: 'exact',
      selectedVariantAsin: 'B000000002'
    }),
    ['B000000002']
  );
  assert.throws(
    () => amazon.variationCandidatesForPolicy(variants, {
      variantPolicy: 'exact',
      selectedVariantAsin: 'B000000008'
    }),
    error => error?.code === 'selected_variant_unavailable' && /no longer offered/i.test(error.message)
  );

  const details = amazon.validateSeeDetailsResponse({
    result: { asin: 'B000000003', promotionId: 'PROMOTION123', purchasePolicyCode: 'AmazonVine' }
  }, 'B000000003');
  const voice = amazon.validateVoiceOrderResponse({
    result: { itemAsin: 'B000000003', proceedToCheckout: true, offerListingId: 'OFFER-LOCAL' }
  }, 'B000000003');
  const relay = amazon.checkoutFormFields({ asin: details.asin, offerListingId: voice.offerListingId, ...details });
  assert.equal(relay.action, 'https://www.amazon.ca/checkout/entry/buynow?pipelineType=Chewbacca');
  assert.deepEqual(relay.fields.map(([name]) => name), [
    'skipCart', 'quantity', 'asin', 'offerListingID', 'vinePromotionId', 'vinePurchasePolicyCode'
  ]);

  assert.throws(
    () => amazon.validateSeeDetailsResponse({ result: { asin: 'B000000004' } }, 'B000000003'),
    /unexpected|valid Vine/i
  );
  assert.throws(
    () => amazon.validateVoiceOrderResponse({ result: { proceedToCheckout: false } }, 'B000000003'),
    /checkout offer/i
  );
});
