'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  signedEnvelope,
  verifyPayloadSignature
} = require('../lib/order-protocol');
const { OrderCoordinator } = require('../lib/order-coordinator');

class FakeSocket {
  constructor() {
    this.readyState = 1;
    this.sent = [];
    this.closed = null;
  }
  send(value) {
    this.sent.push(JSON.parse(value));
  }
  close(code, reason) {
    this.closed = { code, reason };
    this.readyState = 3;
  }
}

function harness({ initialPairing = null } = {}) {
  const files = new Map();
  if (initialPairing) files.set('/pairing', structuredClone(initialPairing));
  const events = [];
  let now = 1_700_000_000_000;
  let failNextPairingSave = false;
  const coordinator = new OrderCoordinator({
    pairingFile: '/pairing',
    rulesFile: '/rules',
    jobsFile: '/jobs',
    watchesFile: '/watches',
    safetyFile: '/safety',
    loadJSON: (file, fallback) => files.has(file) ? structuredClone(files.get(file)) : fallback,
    saveJSON: (file, value) => {
      if (file === '/pairing' && failNextPairingSave) {
        failNextPairingSave = false;
        return false;
      }
      files.set(file, structuredClone(value));
    },
    onEvent: (type, data) => events.push({ type, data }),
    now: () => now
  });
  return {
    coordinator,
    files,
    events,
    get now() { return now; },
    set now(value) { now = value; },
    failNextPairingSave() { failNextPairingSave = true; }
  };
}

function authenticateAgent(h, pairingSecret, {
  accountHash = 'a'.repeat(64),
  nonce = 'nonce-hello-123456'
} = {}) {
  const socket = new FakeSocket();
  h.coordinator.attachSocket(socket);
  const challengeMessage = socket.sent.at(-1);
  if (!challengeMessage || challengeMessage.type !== 'agent_challenge') {
    return { socket, result: null };
  }
  const helloPayload = {
    challenge: challengeMessage.payload.challenge,
    timestampMs: h.now,
    nonce,
    accountHash,
    agentId: 'windows-pc',
    agentVersion: '1.0.0',
    capabilities: {
      fastCheckout: true,
      localApproval: true,
      firstAvailableVariant: true,
      currency: 'CAD'
    }
  };
  const result = h.coordinator.handleSocketMessage(
    socket,
    JSON.stringify(signedEnvelope(pairingSecret, 'agent_hello', helloPayload))
  );
  return { socket, result };
}

function connectAgent(h, options = {}) {
  const pairing = h.coordinator.issuePairing();
  return { pairing, ...authenticateAgent(h, pairing.pairingSecret, options) };
}

const ITEM = {
  asin: 'B000000001',
  title: 'Coffee grinder',
  queue: 'AI',
  recommendation: '12345678-1234-1234-1234-123456789abc',
  price: 149.99,
  etv: 0,
  liveSources: ['UV', 'VH'],
  firstDiscoveredMs: 1_699_999_999_900
};

test('new pairing is account-pending, secret is returned once, and public status never exposes either secret or hash', () => {
  const h = harness();
  const issued = h.coordinator.issuePairing({ agentLabel: 'My PC' });
  const saved = h.files.get('/pairing');
  assert.match(issued.pairingSecret, /^vdh1\./);
  assert.equal(issued.accountBindingPending, true);
  assert.equal(saved.schemaVersion, 2);
  assert.equal(saved.accountBindingKind, 'amazon_customer_id_sha256');
  assert.equal(saved.accountBindingState, 'pending');
  assert.equal(saved.expectedAccountHash, '');
  assert.equal(h.coordinator.publicStatus().paired, true);
  assert.equal(h.coordinator.publicStatus().accountBound, false);
  assert.equal(JSON.stringify(h.coordinator.publicStatus()).includes(issued.pairingSecret), false);
  assert.equal(saved.secret, issued.pairingSecret);
});

test('first signed browser connection durably learns its real account hash and a later different account is rejected', () => {
  const first = harness();
  const connected = connectAgent(first, { accountHash: 'a'.repeat(64) });
  assert.equal(connected.result.ok, true);
  assert.equal(first.coordinator.publicStatus().authenticated, true);
  assert.equal(first.coordinator.publicStatus().accountMatched, true);
  const saved = first.files.get('/pairing');
  assert.equal(saved.accountBindingState, 'bound');
  assert.equal(saved.expectedAccountHash, 'a'.repeat(64));
  assert.match(saved.accountBoundAt, /^\d{4}-\d{2}-\d{2}T/);
  const ready = connected.socket.sent.at(-1);
  assert.equal(ready.type, 'agent_ready');
  assert.equal(ready.payload.expectedAccountHash, 'a'.repeat(64));
  assert.equal(verifyPayloadSignature(connected.pairing.pairingSecret, ready.type, ready.payload, ready.signature), true);
  assert.equal(JSON.stringify(first.coordinator.publicStatus()).includes('a'.repeat(64)), false);

  const restarted = harness({ initialPairing: saved });
  const mismatch = authenticateAgent(restarted, saved.secret, {
    accountHash: 'b'.repeat(64),
    nonce: 'nonce-hello-different-2'
  });
  assert.equal(mismatch.result.ok, false);
  assert.equal(mismatch.socket.closed.code, 4010);
  assert.equal(restarted.coordinator.publicStatus().authenticated, false);
  assert.equal(restarted.files.get('/pairing').expectedAccountHash, 'a'.repeat(64));
});

test('legacy v1 pairing hash is quarantined and explicit re-pair is required before browser binding', () => {
  const legacySecret = `vdh1.${'A'.repeat(43)}`;
  const h = harness({
    initialPairing: {
      schemaVersion: 1,
      enabled: true,
      secret: legacySecret,
      pairedAt: '2023-11-14T22:13:20.000Z',
      expectedAccountHash: 'f'.repeat(64),
      agentLabel: 'Legacy PC'
    }
  });
  const status = h.coordinator.publicStatus();
  assert.equal(status.paired, true);
  assert.equal(status.pairingMigrationRequired, true);
  assert.equal(status.accountBound, false);
  const blocked = authenticateAgent(h, legacySecret, { accountHash: 'f'.repeat(64) });
  assert.equal(blocked.result, null);
  assert.equal(blocked.socket.closed.code, 4012);
  assert.match(blocked.socket.closed.reason, /must be replaced/i);

  const replacement = h.coordinator.issuePairing();
  const rebound = authenticateAgent(h, replacement.pairingSecret, {
    accountHash: 'b'.repeat(64),
    nonce: 'nonce-hello-repaired-1'
  });
  assert.equal(rebound.result.ok, true);
  assert.equal(h.files.get('/pairing').expectedAccountHash, 'b'.repeat(64));
  assert.equal(h.coordinator.publicStatus().pairingMigrationRequired, false);
});

test('pairing creation and first account binding remain fail-closed on the production false-return persistence signal', () => {
  const creationFailure = harness();
  creationFailure.failNextPairingSave();
  assert.throws(() => creationFailure.coordinator.issuePairing(), /persistence failed/);
  assert.equal(creationFailure.coordinator.publicStatus().paired, false);
  assert.equal(creationFailure.files.has('/pairing'), false);

  const revokeFailure = harness();
  const revocable = revokeFailure.coordinator.issuePairing();
  revokeFailure.failNextPairingSave();
  assert.throws(() => revokeFailure.coordinator.revokePairing(), /persistence failed/);
  assert.equal(revokeFailure.coordinator.publicStatus().paired, false);
  assert.equal(revokeFailure.files.get('/pairing').secret, revocable.pairingSecret);

  const h = harness();
  const pairing = h.coordinator.issuePairing();
  h.failNextPairingSave();
  const failed = authenticateAgent(h, pairing.pairingSecret);
  assert.equal(failed.result.ok, false);
  assert.equal(failed.socket.closed.code, 4013);
  assert.equal(h.coordinator.publicStatus().authenticated, false);
  assert.equal(h.coordinator.publicStatus().accountBound, false);
  assert.equal(h.files.get('/pairing').accountBindingState, 'pending');
});

test('first matching rule dispatches one signed expiring job and source confirmation cannot duplicate it', () => {
  const h = harness();
  const { pairing, socket } = connectAgent(h);
  h.coordinator.updateRuleSet({
    enabled: true,
    currency: 'CAD',
    unattendedCheckoutLimit: 30,
    jobTtlMs: 15_000,
    rules: [{
      id: 'coffee-rule',
      name: 'Coffee over 100',
      enabled: true,
      action: 'auto',
      logic: 'and',
      words: ['coffee'],
      wordMode: 'any',
      priceField: 'retail',
      priceOperator: 'at_least',
      priceMinimum: 100
    }]
  });
  const dispatched = h.coordinator.dispatchForLiveItem(ITEM);
  assert.equal(dispatched.ok, true);
  const envelope = socket.sent.at(-1);
  assert.equal(envelope.type, 'order_job');
  assert.equal(verifyPayloadSignature(pairing.pairingSecret, envelope.type, envelope.payload, envelope.signature), true);
  assert.equal(envelope.payload.policy.unattendedCheckoutLimit, 30);
  assert.equal(envelope.payload.policy.ruleId, 'coffee-rule');
  assert.equal(envelope.payload.item.enrollmentGuid, '12345678-1234-1234-1234-123456789abc');
  assert.equal(envelope.payload.expiresAtMs - envelope.payload.issuedAtMs, 15_000);
  const duplicate = h.coordinator.dispatchForLiveItem({ ...ITEM, liveSources: ['UV', 'VH', 'SV'] });
  assert.equal(duplicate.skipped, true);
  assert.match(duplicate.reason, /already/i);
});

test('signed progress/result updates a bounded public ledger without accepting arbitrary fields', () => {
  const h = harness();
  const { pairing, socket } = connectAgent(h);
  const dispatched = h.coordinator.dispatchManual(ITEM);
  assert.equal(dispatched.ok, true);
  const jobId = dispatched.job.jobId;
  h.now += 500;
  const resultPayload = {
    jobId,
    state: 'placed',
    nonce: 'result-nonce-123456',
    eventAtMs: h.now,
    asin: ITEM.asin,
    variantAsin: 'B000000002',
    finalTotal: 2.25,
    currency: 'CAD',
    amazonOrderId: 'ORDER-1',
    cookie: 'must-not-persist',
    timings: { placeOrderClickedAtMs: h.now - 200, confirmedAtMs: h.now }
  };
  const accepted = h.coordinator.handleSocketMessage(
    socket,
    JSON.stringify(signedEnvelope(pairing.pairingSecret, 'agent_result', resultPayload))
  );
  assert.equal(accepted.ok, true);
  const saved = h.coordinator.recentJobs(1)[0];
  assert.equal(saved.state, 'placed');
  assert.equal(saved.finalTotal, 2.25);
  assert.equal(saved.cookie, undefined);
  assert.equal(h.coordinator.dispatchManual(ITEM).ok, false);
});

test('offline automatic matches fail immediately and are never queued for a later source', () => {
  const h = harness();
  h.coordinator.issuePairing();
  h.coordinator.updateRuleSet({
    enabled: true,
    rules: [{ id: 'word-rule', name: 'Coffee', enabled: true, action: 'auto', logic: 'word_only', words: ['coffee'] }]
  });
  const attempt = h.coordinator.dispatchForLiveItem(ITEM);
  assert.equal(attempt.ok, false);
  assert.equal(attempt.job.state, 'failed');
  assert.equal(attempt.job.reasonCode, 'agent_offline');
  const later = h.coordinator.dispatchForLiveItem({ ...ITEM, sources: ['SV'] });
  assert.equal(later.skipped, true);
});
