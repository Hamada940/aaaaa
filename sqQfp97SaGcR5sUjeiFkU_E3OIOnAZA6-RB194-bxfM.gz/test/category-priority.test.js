'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');

const {
  UV_CATEGORY_CATALOG,
  normalizeUvCategoryId,
  getUvCategory,
  normalizePriorityCategoryIds,
  categoryPriorityMatch,
  extractUvCategoryId
} = require('../lib/uv-categories');
const {
  compilePriorityRules,
  evaluateCompiledPriorityRules,
  evaluatePriorityRules
} = require('../lib/priority-rules');

const root = path.join(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');

const noKeywords = { highlight: [], hide: [], blur: [] };

function evaluate(overrides = {}) {
  return evaluatePriorityRules({
    title: 'ordinary product',
    price: 20,
    etv: 20,
    categoryId: null,
    keywords: noKeywords,
    minPriorityPrice: 100,
    priorityCategoryIds: [],
    ...overrides
  });
}

test('UV 26.9.38 category catalog is exact-sized, unique, and locally resolvable', () => {
  assert.equal(UV_CATEGORY_CATALOG.length, 90);
  assert.equal(new Set(UV_CATEGORY_CATALOG.map(category => category.id)).size, 90);
  assert.equal(
    crypto.createHash('sha256').update(JSON.stringify(UV_CATEGORY_CATALOG)).digest('hex'),
    '8758d5b90a10eece38986fec6fa21441e6d8ab2fc70c936c8f91196a430eea19'
  );
  assert.deepEqual(getUvCategory('9'), { id: '9', name: 'Electronics', emoji: '💻' });
  assert.deepEqual(getUvCategory(1727), {
    id: '1727',
    name: 'Vitamins, Minerals & Supplements',
    emoji: '💊'
  });
  assert.deepEqual(getUvCategory('-1'), { id: '-1', name: 'Uncategorized', emoji: '❌' });
});

test('category IDs normalize and priority selections deduplicate by exact ID', () => {
  assert.equal(normalizeUvCategoryId(9), '9');
  assert.equal(normalizeUvCategoryId(' 1727 '), '1727');
  assert.equal(normalizeUvCategoryId('electronics'), null);
  assert.deepEqual(normalizePriorityCategoryIds(['9', 9, '1727', '', null]), ['9', '1727']);
  assert.equal(categoryPriorityMatch('9', ['9']), true);
  assert.equal(categoryPriorityMatch('30', ['9']), false);
});

test('UV category capture accepts direct/nested aliases but never trusts VH category data', () => {
  assert.equal(extractUvCategoryId({ categoryId: 9 }, 'UV'), '9');
  assert.equal(extractUvCategoryId({ details: { category_id: '30' } }, 'UV'), '30');
  assert.equal(extractUvCategoryId({ brenda_category_id: 1721 }, 'UV'), '1721');
  assert.equal(extractUvCategoryId({ categoryId: 9 }, 'VH'), null);
  assert.equal(extractUvCategoryId({ categoryId: 9 }, 'VH', '30'), '30');
});

test('priority is the OR of keyword, price/ETV, and selected category', () => {
  const keyword = evaluate({
    title: 'Portable OLED display',
    keywords: { ...noKeywords, highlight: ['oled'] }
  });
  assert.equal(keyword.isHighlight, true);
  assert.equal(keyword.isPriceHighlight, false);
  assert.equal(keyword.isCategoryPriority, false);
  assert.deepEqual(keyword.priorityReasons, ['Keyword: oled']);

  const price = evaluate({ price: '$149.99' });
  assert.equal(price.isHighlight, true);
  assert.equal(price.isPriceHighlight, true);
  assert.equal(price.isCategoryPriority, false);
  assert.deepEqual(price.priorityReasons, ['Price/ETV ≥ $100']);

  const category = evaluate({ categoryId: '9', priorityCategoryIds: ['9'] });
  assert.equal(category.isHighlight, true);
  assert.equal(category.isPriceHighlight, false);
  assert.equal(category.isCategoryPriority, true);
  assert.deepEqual(category.priorityReasons, ['Category: Electronics']);
});

test('all matching priority reasons are retained and non-priority rules still work', () => {
  const result = evaluate({
    title: 'OLED cable privacy cover',
    price: 125,
    categoryId: 9,
    priorityCategoryIds: ['9'],
    keywords: { highlight: ['oled'], hide: ['cable'], blur: ['privacy'] }
  });
  assert.equal(result.isHighlight, true);
  assert.equal(result.isPriceHighlight, true);
  assert.equal(result.isCategoryPriority, true);
  assert.deepEqual(result.priorityReasons, [
    'Keyword: oled',
    'Price/ETV ≥ $100',
    'Category: Electronics'
  ]);
  assert.equal(result.isHide, true);
  assert.equal(result.isBlur, true);
});

test('compiled priority settings preserve exact rule output without per-item normalization', () => {
  const settings = {
    keywords: {
      highlight: [' OLED ', 'Coffee'],
      hide: ['Cable'],
      blur: ['Privacy']
    },
    minPriorityPrice: '$100.00',
    priorityCategoryIds: ['9', 9, '30']
  };
  const compiled = compilePriorityRules(settings);
  const fixtures = [
    { title: 'OLED cable privacy cover', price: 125, etv: 80, categoryId: 9 },
    { title: 'Coffee filters', price: 10, etv: 10, categoryId: 30 },
    { title: 'Ordinary product', price: 1, etv: 0, categoryId: null }
  ];

  for (const fixture of fixtures) {
    assert.deepEqual(
      evaluateCompiledPriorityRules({ ...fixture, compiled }),
      evaluatePriorityRules({ ...fixture, ...settings })
    );
  }
  assert.deepEqual(compiled.priorityCategoryIds, ['9', '30']);
  assert.equal(compiled.priorityCategoryIdSet.has('9'), true);
});

test('server refreshes the compiled priority cache before bulk rechecks', () => {
  assert.match(server, /let compiledPriorityRules = null/);
  assert.match(server, /function refreshCompiledPriorityRules\(\)/);
  assert.match(
    server,
    /function recheckAllKeywords\(\) \{\s*refreshCompiledPriorityRules\(\);/
  );
  assert.match(server, /evaluateCompiledPriorityRules\(\{/);
});

test('category names in titles do not infer category priority', () => {
  const result = evaluate({
    title: 'Electronics organizer',
    categoryId: null,
    priorityCategoryIds: ['9']
  });
  assert.equal(result.isHighlight, false);
  assert.equal(result.isCategoryPriority, false);
  assert.deepEqual(result.priorityReasons, []);
});

test('stored rechecks and APIs are category-aware with persistent empty defaults', () => {
  assert.match(server, /app\.get\(['"]\/api\/categories['"]/);
  assert.match(server, /app\.post\(['"]\/api\/categories\/priority['"]/);
  assert.match(server, /config\.priorityCategoryIds\s*=\s*normalizedIds/);
  assert.match(server, /checkKeywordMatches\(item\.title, item\.price, item\.etv, categoryId\)/);
  assert.match(server, /item\.isCategoryPriority\s*=\s*matches\.isCategoryPriority/);
  assert.match(server, /item\.priorityReasons\s*=\s*matches\.priorityReasons/);

  for (const name of ['config.example.json', 'config.portable.example.json']) {
    const example = JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
    assert.deepEqual(example.priorityCategoryIds, []);
  }
});

test('UV detail/category enrichment and second-source card updates stay silent', () => {
  const detailStart = server.indexOf('function applyUvAlertDetail');
  const detailEnd = server.indexOf('function extractUvProducts', detailStart);
  const detail = server.slice(detailStart, detailEnd);
  assert.ok(detailStart > 0 && detailEnd > detailStart);
  assert.match(detail, /extractUvCategoryId\(detail, ['"]UV['"], null\)/);
  assert.match(detail, /isCategoryPriority:\s*matches\.isCategoryPriority/);
  assert.match(detail, /broadcastLocal\(['"]update_item['"], withOrderRuleMatch\(updated\)\)/);
  assert.doesNotMatch(detail, /notifyLiveItem|sendTelegramNotification|sendDiscordWebhook|playChime/);

  const updateStart = dashboard.indexOf('function handleUpdateItemEvent');
  const updateEnd = dashboard.indexOf('async function fetchItems', updateStart);
  const updateHandler = dashboard.slice(updateStart, updateEnd);
  assert.match(updateHandler, /upsertLiveItemImmediately\(item\)/);
  assert.doesNotMatch(updateHandler, /sortAndRenderFeed|playChime|showToast|Notification/);
});

test('dashboard exposes searchable category checklist, badges, and priority reasons', () => {
  assert.match(dashboard, /id="category-priority-search"/);
  assert.match(dashboard, /id="category-priority-grid"/);
  assert.match(dashboard, /selectVisiblePriorityCategories/);
  assert.match(dashboard, /savePriorityCategories/);
  assert.match(dashboard, /card-category-badge/);
  assert.match(dashboard, /card-priority-reasons/);
  assert.match(dashboard, /Priority because:/);
  assert.match(dashboard, /VHelper does not supply category data/);
});
