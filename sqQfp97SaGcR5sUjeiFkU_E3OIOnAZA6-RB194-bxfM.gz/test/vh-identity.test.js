'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');

const {
  VHelperIdentityManager,
  LEGACY_PUBLIC_JWK,
  buildSignedBody
} = require('../lib/vh-identity');

function tempFile() {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'vdh-vh-identity-'));
  return { directory, file: path.join(directory, 'identity.json') };
}

function loadJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function saveJSON(file, value, options = {}) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), { mode: options.mode || 0o600 });
  fs.chmodSync(file, options.mode || 0o600);
}

function verifyRequestSignature(body) {
  const { s, pk, ...content } = body;
  assert.equal(Buffer.from(s, 'base64').length, 64);
  const publicKey = crypto.createPublicKey({ key: pk, format: 'jwk' });
  assert.equal(
    crypto.verify(
      'sha256',
      Buffer.from(JSON.stringify(content), 'utf8'),
      { key: publicKey, dsaEncoding: 'ieee-p1363' },
      Buffer.from(s, 'base64')
    ),
    true
  );
}

test('legacy single-record UUID/CID is used without migration or provisioning', async t => {
  const { directory, file } = tempFile();
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const legacy = {
    uuid: 'legacy-working-uuid',
    customerId: 'A1SYNTHETIC123',
    country: 'ca',
    createdAt: '2026-01-01T00:00:00.000Z'
  };
  fs.writeFileSync(file, JSON.stringify(legacy, null, 2), { mode: 0o644 });
  const before = fs.readFileSync(file, 'utf8');
  let apiCalls = 0;
  const manager = new VHelperIdentityManager({
    file,
    loadJSON,
    saveJSON,
    requestJson: async () => {
      apiCalls += 1;
      throw new Error('must not be called');
    }
  });

  const identity = await manager.getOrCreateIdentity('ca');
  assert.equal(identity.uuid, legacy.uuid);
  assert.equal(identity.customerId, legacy.customerId);
  assert.equal(identity.identityMode, 'legacy-synthetic');
  assert.equal(identity.legacyPreserved, true);
  assert.equal(identity.fid, '');
  assert.equal(identity.deviceName, 'cat-dashboard-v9');
  const afterMarketplaceChange = await manager.getOrCreateIdentity('us');
  assert.equal(afterMarketplaceChange.uuid, legacy.uuid);
  assert.equal(afterMarketplaceChange.country, 'ca');
  assert.equal(manager.getCID('us', afterMarketplaceChange), manager.getCID('ca', identity));
  assert.equal(apiCalls, 0);
  assert.equal(fs.readFileSync(file, 'utf8'), before);
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);
});

test('new synthetic identity uses a fresh valid P-256 key and registers a stable FID', async t => {
  const { directory, file } = tempFile();
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const requests = [];
  const manager = new VHelperIdentityManager({
    file,
    loadJSON,
    saveJSON,
    requestJson: async body => {
      requests.push(body);
      verifyRequestSignature(body);
      if (body.action === 'get_uuid') return { ok: 'ok', uuid: 'new-hardened-uuid' };
      if (body.action === 'upload_fingerprint') {
        assert.match(body.fingerprint, /^[A-Za-z0-9+/]{43}=$/);
        assert.ok(body.device_name.length >= 15 && body.device_name.length <= 100);
        return { ok: 'ok', fingerprint_id: 'fid-123' };
      }
      throw new Error(`unexpected action: ${body.action}`);
    }
  });

  const identity = await manager.getOrCreateIdentity('ca');
  assert.equal(identity.schemaVersion, 2);
  assert.equal(identity.identityMode, 'hardened-synthetic');
  assert.equal(identity.uuid, 'new-hardened-uuid');
  assert.equal(identity.fid, 'fid-123');
  assert.equal(identity.fidState, 'registered');
  assert.match(identity.cid, /^[a-f0-9]{64}$/);
  assert.equal(identity.customerId, undefined);
  assert.equal(requests.length, 2);
  assert.deepEqual(
    Object.keys(requests[0]).slice(0, 5),
    ['api_version', 'app_version', 'action', 'country', 'cid']
  );
  assert.deepEqual(
    Object.keys(requests[1]).slice(0, 8),
    [
      'api_version',
      'app_version',
      'country',
      'action',
      'uuid',
      'cid',
      'fingerprint',
      'device_name'
    ]
  );
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);

  const other = tempFile();
  t.after(() => fs.rmSync(other.directory, { recursive: true, force: true }));
  const second = new VHelperIdentityManager({
    file: other.file,
    loadJSON,
    saveJSON,
    requestJson: async body =>
      body.action === 'get_uuid'
        ? { ok: 'ok', uuid: 'other-uuid' }
        : { fingerprint_id: 'other-fid' }
  });
  const secondIdentity = await second.getOrCreateIdentity('ca');
  assert.notEqual(secondIdentity.privateKeyJwk.d, identity.privateKeyJwk.d);
  assert.notEqual(secondIdentity.cid, identity.cid);
  assert.notEqual(secondIdentity.fingerprint, identity.fingerprint);
});

test('blank-FID compatibility is bounded to three upload attempts', async t => {
  const { directory, file } = tempFile();
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  let now = Date.parse('2026-01-01T00:00:00.000Z');
  let uploads = 0;
  const requestJson = async body => {
    verifyRequestSignature(body);
    if (body.action === 'get_uuid') return { ok: 'ok', uuid: 'blank-fid-uuid' };
    uploads += 1;
    throw new Error('mock fingerprint incompatibility');
  };
  const makeManager = () =>
    new VHelperIdentityManager({
      file,
      loadJSON,
      saveJSON,
      requestJson,
      now: () => now
    });

  let identity = await makeManager().getOrCreateIdentity('ca');
  assert.equal(uploads, 1);
  assert.equal(identity.fidState, 'compatibility-blank-retryable');

  now += 7 * 60 * 60 * 1000;
  identity = await makeManager().getOrCreateIdentity('ca');
  assert.equal(uploads, 2);
  now += 7 * 60 * 60 * 1000;
  identity = await makeManager().getOrCreateIdentity('ca');
  assert.equal(uploads, 3);
  assert.equal(identity.fidState, 'compatibility-blank-bounded');

  now += 24 * 60 * 60 * 1000;
  identity = await makeManager().getOrCreateIdentity('ca');
  assert.equal(uploads, 3);
  assert.equal(identity.fid, '');
});

test('legacy signing compatibility key remains internally consistent', () => {
  const identity = { identityMode: 'legacy-synthetic' };
  const body = buildSignedBody(
    {
      api_version: 5,
      app_version: '4.7.4',
      action: 'get_uuid',
      country: 'ca',
      cid: 'a'.repeat(64)
    },
    identity
  );
  assert.deepEqual(body.pk, LEGACY_PUBLIC_JWK);
  verifyRequestSignature(body);
});
