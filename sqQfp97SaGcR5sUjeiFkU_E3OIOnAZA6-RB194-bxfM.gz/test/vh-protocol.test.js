'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');

const {
  parseBoolean,
  normalizeVhDate,
  normalizeVhPayload,
  normalizeVhEnrichment,
  extractBroadcastSync,
  shouldReconnectForBroadcastMismatch,
  decideBroadcastMismatchRecovery
} = require('../lib/vh-protocol');

function assertIncludes(actual, expected) {
  for (const [key, value] of Object.entries(expected)) assert.deepEqual(actual[key], value);
}

test('VH booleans do not treat string false as true', () => {
  assert.equal(parseBoolean(false), false);
  assert.equal(parseBoolean('false'), false);
  assert.equal(parseBoolean('0'), false);
  assert.equal(parseBoolean('unavailable'), false);
  assert.equal(parseBoolean('true'), true);
  assert.equal(parseBoolean('1'), true);
});

test('UTC MySQL timestamps are normalized explicitly as UTC', () => {
  assert.equal(normalizeVhDate('2026-09-11 12:34:56'), '2026-09-11T12:34:56.000Z');
  assert.equal(normalizeVhDate(1750000000), '2025-06-15T15:06:40.000Z');
  assert.equal(normalizeVhDate('not-a-date'), null);
});

test('official data.item live payload maps all core fields', () => {
  const item = normalizeVhPayload(
    {
      data: {
        item: {
          asin: 'B012345678',
          queue: 'last_chance',
          is_parent_asin: 'false',
          enrollment_guid: 'enrol-1',
          is_pre_release: 'true',
          title: 'Test &amp; Product',
          img_url: 'image.jpg',
          additional_img: ['two.jpg'],
          etv_min: '0',
          etv_max: '12.50',
          price: '19.99',
          tier: 2,
          date: '2026-09-11 12:34:56',
          date_added: '2026-09-11 12:30:00',
          unavailable: 'false',
          variants: '[{"asin":"B087654321"}]',
          variant_asin: 'B087654321',
          order_success: 3,
          order_failed: 1,
          reason: null
        }
      }
    },
    { event: 'newItem' }
  );

  assert.equal(item.asin, 'B012345678');
  assert.equal(item.queue, 'last_chance');
  assert.equal(item.isParentAsin, false);
  assert.equal(item.enrollmentGuid, 'enrol-1');
  assert.equal(item.isPreRelease, true);
  assert.equal(item.vhServerDate, '2026-09-11T12:34:56.000Z');
  assert.equal(item.dateAdded, '2026-09-11T12:30:00.000Z');
  assert.deepEqual(item.variants, [{ asin: 'B087654321' }]);
  assert.equal(item.sourceEvent, 'newItem');
  assert.equal(item.variant_asin, 'B087654321');
});

test('all official passive enrichment events normalize without creating a live item', () => {
  assertIncludes(
    normalizeVhEnrichment('newETV', { data: { item: { asin: 'A', etv: 4.5 } } }),
    { asin: 'A', etv: 4.5 }
  );
  assertIncludes(
    normalizeVhEnrichment('newPrice', {
      data: { item: { asin: 'A', price: 10, additional_img: ['x'] } }
    }),
    { asin: 'A', price: 10, additional_img: ['x'] }
  );
  assertIncludes(
    normalizeVhEnrichment('newVariants', { asin: 'A', variants: '[{"v":1}]' }),
    { asin: 'A', variants: [{ v: 1 }] }
  );
  assertIncludes(
    normalizeVhEnrichment('unavailableItem', { data: { item: { asin: 'A' } } }),
    { asin: 'A', unavailable: true, available: false }
  );
  assertIncludes(
    normalizeVhEnrichment('orderAttempts', {
      asin: 'A',
      order_success: 7,
      order_failed: 2
    }),
    { asin: 'A', order_success: 7, order_failed: 2 }
  );
});

test('broadcast sync marker is extracted from official fields', () => {
  assert.deepEqual(
    extractBroadcastSync({ available: true, asin: 'B012345678', timestamp: '2026-09-11 12:34:56' }),
    {
      asin: 'B012345678',
      timestamp: '2026-09-11T12:34:56.000Z',
      raw: { available: true, asin: 'B012345678', timestamp: '2026-09-11 12:34:56' }
    }
  );
});

test('broadcast mismatch follows official newer-different-marker semantics', () => {
  const local = { asin: 'LOCALASIN1', timestamp: '2026-09-11T12:34:56.500Z' };
  assert.equal(
    shouldReconnectForBroadcastMismatch(
      { available: true, asin: 'SERVERASN1', timestamp: '2026-09-11T12:34:57.000Z' },
      local
    ),
    true
  );
  assert.equal(
    shouldReconnectForBroadcastMismatch(
      { available: true, asin: 'LOCALASIN1', timestamp: '2026-09-11T12:35:00.000Z' },
      local
    ),
    false
  );
  assert.equal(
    shouldReconnectForBroadcastMismatch(
      { available: true, asin: 'SERVERASN1', timestamp: '2026-09-11T12:34:55.000Z' },
      local
    ),
    false
  );
  assert.equal(
    shouldReconnectForBroadcastMismatch(
      { available: false, asin: false, timestamp: false },
      local
    ),
    false
  );
  assert.equal(
    shouldReconnectForBroadcastMismatch(
      { available: true, asin: 'SERVERASN1', timestamp: 'bad-date' },
      local
    ),
    false
  );
});

test('first newer broadcast mismatch permits exactly one recovery attempt', () => {
  const decision = decideBroadcastMismatchRecovery(
    { available: true, asin: 'SERVERASN1', timestamp: '2026-09-11T12:34:57.000Z' },
    { asin: 'LOCALASIN1', timestamp: '2026-09-11T12:34:56.500Z' },
    false
  );
  assert.equal(decision.action, 'reconnect-once');
  assert.equal(decision.mismatch, true);
  assert.equal(decision.markerKey, 'SERVERASN1\n2026-09-11T12:34:57.000Z');
});

test('persistent mismatch after recovery keeps the connected socket open', () => {
  const decision = decideBroadcastMismatchRecovery(
    { available: true, asin: 'SERVERASN1', timestamp: '2026-09-11T12:34:57.000Z' },
    { asin: 'LOCALASIN1', timestamp: '2026-09-11T12:34:56.500Z' },
    true
  );
  assert.equal(decision.action, 'keep-connected');
  assert.equal(decision.mismatch, true);
});

test('matching broadcast markers require no recovery', () => {
  const decision = decideBroadcastMismatchRecovery(
    { available: true, asin: 'LOCALASIN1', timestamp: '2026-09-11T12:35:00.000Z' },
    { asin: 'LOCALASIN1', timestamp: '2026-09-11T12:34:56.500Z' },
    true
  );
  assert.equal(decision.action, 'none');
  assert.equal(decision.mismatch, false);
});
