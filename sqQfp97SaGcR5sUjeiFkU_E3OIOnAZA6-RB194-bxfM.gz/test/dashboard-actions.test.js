'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const {
  UV_RUNTIME_VERSION,
  UV_LAUNCHER_VERSION,
  UV_SUPPORTS_ENROLLMENT_GATE,
  UV_IDENTIFICATION_CAPABILITIES,
  UV_ACCOUNT_HOUSEKEEPING_TYPES,
  buildUvSearchRequestBody,
  normalizeUvOrdersInProgress
} = require('../lib/uv-protocol');
const { normalizeSourceList, deriveLiveSources } = require('../lib/source-registry');
const {
  calculateUvRetryDelay,
  UvRetryController
} = require('../lib/uv-retry-controller');

const root = path.join(__dirname, '..');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');

function section(source, startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start + startMarker.length);
  assert.ok(start >= 0, `missing section start: ${startMarker}`);
  assert.ok(end > start, `missing section end: ${endMarker}`);
  return source.slice(start, end);
}

test('Clear Items stays immediate and Live Feed progressively loads 500 through the 2,000 ceiling', () => {
  const clearFeed = section(
    dashboard,
    'async function clearFeed()',
    'function clearExplorer()'
  );

  assert.match(clearFeed, /fetch\(['"]\/api\/clear-all['"],\s*\{\s*method:\s*['"]POST['"]/);
  assert.doesNotMatch(clearFeed, /\b(?:confirm|prompt)\s*\(/);

  assert.match(dashboard, /const FEED_PAGE_SIZE = 500/);
  assert.match(dashboard, /const FEED_ITEM_CEILING = 2000/);
  assert.match(dashboard, /id="btn-feed-load-more"[^>]+onclick="loadMoreFeedItems\(\)"/);
  assert.match(dashboard, /Load 500 more/);

  const fetchFeed = section(
    dashboard,
    'async function fetchItems(options = {})',
    'function sortAndRenderFeed()'
  );
  assert.match(fetchFeed, /const reset = options\.reset !== false/);
  assert.match(fetchFeed, /page:\s*requestedPage/);
  assert.match(fetchFeed, /limit:\s*FEED_PAGE_SIZE/);
  assert.match(fetchFeed, /requestedPage \* FEED_PAGE_SIZE < FEED_ITEM_CEILING/);
  assert.match(fetchFeed, /mergeFeedRecords\([\s\S]*currentLiveFeedOverlay\(\)/);
  assert.match(fetchFeed, /function loadMoreFeedItems\(\)[\s\S]*fetchItems\(\{ reset: false \}\)/);
  assert.doesNotMatch(fetchFeed, /limit:\s*200\b/);

  const filters = section(dashboard, '// Filter Handlers', 'function setColumns');
  assert.equal((filters.match(/fetchItems\(\{ reset: true \}\)/g) || []).length, 8);
  assert.doesNotMatch(filters, /\brenderFeed\(\)/);
  const uvQueueFilter = section(
    dashboard,
    'function selectUvFeedQueue(queueId, queueType)',
    'function uvItemMatchesQueue(item, queue)'
  );
  assert.match(uvQueueFilter, /fetchItems\(\{ reset: true \}\)/);

  const mergeSource = section(
    dashboard,
    'function mergeFeedRecords(existingRecords, pageRecords, liveRecords, reset = false)',
    'function rememberLiveFeedOverlay(item)'
  );
  const mergeFeedRecords = new Function(
    'sortItemsList',
    'FEED_ITEM_CEILING',
    `${mergeSource}\nreturn mergeFeedRecords;`
  )(() => {}, 2000);
  const firstPage = Array.from({ length: 1999 }, (_, index) => ({
    asin: `PAGE-${index}`,
    revision: 'http'
  }));
  const mergedWithLive = mergeFeedRecords(
    [],
    firstPage,
    [
      { asin: 'PAGE-0', revision: 'websocket' },
      { asin: 'LIVE-NOW', revision: 'websocket' }
    ],
    true
  );
  assert.equal(mergedWithLive.length, 2000);
  assert.equal(mergedWithLive.find(item => item.asin === 'PAGE-0').revision, 'websocket');
  assert.ok(mergedWithLive.some(item => item.asin === 'LIVE-NOW'));
  assert.equal(
    mergeFeedRecords(
      Array.from({ length: 2501 }, (_, index) => ({ asin: `OVER-${index}` })),
      [],
      [],
      false
    ).length,
    2000
  );

  const itemsApi = section(server, "app.get('/api/items'", "app.get('/api/items/:asin'");
  assert.match(itemsApi, /Math\.min\(500, parseInt\(limit, 10\)/);
  assert.match(itemsApi, /uv_alert_queue_id/);
  assert.match(itemsApi, /item\.uvAlertQueueIds\.includes\(expectedQueueId\)/);
});

test('live-feed photos use Order on PC confirmation while Explorer/server photos remain Open Vine links', () => {
  const card = section(
    dashboard,
    "function createProductCardHtml(item, cardView = 'feed')",
    'function escapeHtml(value)'
  );

  assert.match(card, /const isLiveFeedCard = viewKey === 'feed' && !isVhServerRecord/);
  assert.match(
    card,
    /const imageWrapOpen = isLiveFeedCard[\s\S]*\? '<div class="card-image-wrap">'[\s\S]*: `<a href="\$\{vineSearchUrl\}"[^`]+data-open-vine/
  );
  assert.match(
    card,
    /const imageOrderButtonHtml = isLiveFeedCard[\s\S]*card-image-order-trigger btn-order-pc[\s\S]*data-order-asin="\$\{escapeHtml\(item\.asin\)\}"/
  );
  assert.match(card, /\$\{imageOrderButtonHtml\}/);
  assert.match(
    card,
    /<a href="\$\{vineSearchUrl\}" target="_blank" rel="noopener noreferrer" class="btn-vine-search" data-open-vine/
  );
  assert.equal((card.match(/href="\$\{vineSearchUrl\}"/g) || []).length, 2);
  assert.doesNotMatch(card, /card-image-wrap" onclick="openProductModal/);
  assert.match(card, /onclick="openProductModal\('\$\{item\.asin\}'\)" title="Full Details"/);
});

test('two-token Vine search preserves punctuation inside brand names and migrates stored links', () => {
  const utilities = section(
    server,
    'function decodeHtmlEntities(str)',
    'function normalizeQueue(queueValue'
  );
  const migration = section(
    server,
    '// Normalize category metadata, priority sources, queue provenance',
    'saveJSON(ITEMS_FILE, allItems);'
  );
  const makeUtilities = new Function(
    `${utilities}\nreturn { getFirstTwoWords, getTwoWordSearchUrl };`
  );
  const { getFirstTwoWords, getTwoWordSearchUrl } = makeUtilities();

  assert.equal(getFirstTwoWords('GL.iNet Flint 4 Tri-Band Router'), 'GL.iNet Flint');
  assert.equal(getFirstTwoWords('**GL.iNet Flint 4'), 'GL.iNet Flint');
  assert.equal(getFirstTwoWords('e.l.f. Cosmetics Primer'), 'e.l.f. Cosmetics');
  assert.equal(getFirstTwoWords('AT&amp;T Smart Router'), 'AT&T Smart');
  assert.equal(getFirstTwoWords("O'Keeffe's Working Hands"), "O'Keeffe's Working");
  assert.equal(getFirstTwoWords('L’Oréal Paris Serum'), 'L’Oréal Paris');
  assert.equal(getFirstTwoWords('Wi-Fi 7 Router'), 'Wi-Fi 7');
  assert.equal(getFirstTwoWords('Salt & Pepper Grinder'), 'Salt Pepper');
  assert.equal(
    getTwoWordSearchUrl('GL.iNet Flint 4 Tri-Band Router', 'amazon.ca'),
    'https://www.amazon.ca/vine/vine-items?search=GL.iNet%20Flint'
  );
  assert.match(migration, /\bfirstTwoWords,/);
  assert.match(migration, /vineSearchUrl:\s*getTwoWordSearchUrl\(searchTitle\)/);
});

test('official UV queue type stays separate from alert origin and weak merges cannot relabel AFA', () => {
  const queueHelpers = section(
    server,
    "function normalizeKnownQueue(queueValue, eventType = '')",
    'function parseItemTime(raw)'
  );
  const makeQueueHelpers = new Function(
    'normalizeSourceList', 'deriveLiveSources',
    `const QUEUE_CONFIDENCE_RANK = Object.freeze({ default: 0, legacy: 1, derived: 2, explicit: 3 });\nconst ALERT_ORIGIN_CONFIDENCE_RANK = Object.freeze({ default: 0, event: 1, explicit: 2 });\n${queueHelpers}\nreturn { normalizeKnownQueue, classifyItemQueue, classifyItemAlertOrigin, resolveMergedQueue, resolveMergedAlertOrigin };`
  );
  const {
    normalizeKnownQueue,
    classifyItemQueue,
    classifyItemAlertOrigin,
    resolveMergedQueue,
    resolveMergedAlertOrigin
  } = makeQueueHelpers(normalizeSourceList, deriveLiveSources);

  assert.deepEqual(classifyItemQueue({ type: 'VENDOR_VINE_FOR_ALL' }), {
    queue: 'AFA',
    confidence: 'explicit',
    raw: 'VENDOR_VINE_FOR_ALL'
  });
  assert.equal(classifyItemQueue({ type: 'VENDOR_TARGETED' }).queue, 'RFY');
  assert.equal(classifyItemQueue({ type: 'VINE_FOR_ALL' }).queue, 'AI');
  assert.equal(
    classifyItemQueue({ type: 'VENDOR_VINE_FOR_ALL' }, 'alertFromBrenda').queue,
    'AFA'
  );
  assert.equal(classifyItemQueue({}, 'alertFromBrenda').queue, 'AI');
  assert.equal(normalizeKnownQueue('Discord/Brenda'), null);
  assert.equal(
    classifyItemQueue({
      queue: 'Discord/Brenda',
      recommendationType: 'VENDOR_VINE_FOR_ALL'
    }).queue,
    'AFA'
  );
  assert.deepEqual(classifyItemAlertOrigin({}, 'alertFromBrenda', 'UV'), {
    origin: 'brenda',
    confidence: 'event',
    raw: 'alertFromBrenda'
  });
  assert.equal(classifyItemAlertOrigin({}, 'alertFromRedrop', 'UV').origin, 'redrop');
  assert.equal(classifyItemAlertOrigin({ origin: 'brenda' }, 'alerts', 'UV').confidence, 'explicit');
  assert.equal(classifyItemAlertOrigin({}, 'alerts', 'UV').origin, 'ultraviner');
  assert.deepEqual(classifyItemQueue({ type: 'newItem' }), {
    queue: 'AI',
    confidence: 'default',
    raw: null
  });
  assert.equal(classifyItemQueue({ afaOrders: 2 }).queue, 'AFA');

  const knownAfa = {
    queue: 'AFA',
    queueConfidence: 'explicit',
    queueRaw: 'last_chance',
    queueObservedFrom: 'VH',
    queueObservedAt: '2026-10-01T12:00:00.000Z'
  };
  const weakUv = resolveMergedQueue(
    knownAfa,
    { queue: 'AI', confidence: 'default', raw: null },
    'UV',
    '2026-10-01T12:00:00.050Z'
  );
  assert.equal(weakUv.queue, 'AFA');
  assert.equal(weakUv.source, 'VH');

  const corrected = resolveMergedQueue(
    { queue: 'AI', queueConfidence: 'default' },
    { queue: 'AFA', confidence: 'explicit', raw: 'VENDOR_VINE_FOR_ALL' },
    'UV',
    '2026-10-01T12:00:00.050Z'
  );
  assert.equal(corrected.queue, 'AFA');
  assert.equal(corrected.source, 'UV');

  const retainedBrenda = resolveMergedAlertOrigin(
    {
      origin: 'brenda',
      alertOrigin: 'brenda',
      alertOrigins: ['brenda'],
      alertOriginConfidence: 'event'
    },
    { origin: 'ultraviner', confidence: 'default', raw: 'alertFromEtv' }
  );
  assert.equal(retainedBrenda.origin, 'brenda');
  assert.deepEqual(retainedBrenda.origins, ['brenda']);
});

test('UV live handler does not hide the official product type behind queue AI', () => {
  const liveHandler = section(
    server,
    'itemObj.uv_event_at = data?.now',
    "socket.on('close', (code, reasonBuffer)"
  );
  assert.doesNotMatch(liveHandler, /itemObj\.queue\s*=/);
  assert.match(liveHandler, /Official UV products carry their queue in[\s\S]*`type`/);
  assert.match(liveHandler, /origin provenance[\s\S]*never as a fourth Vine queue/);
  assert.match(liveHandler, /ingestItem\(itemObj, 'UV', type, null, liveFrameTiming\)/);

  const batchIngest = section(
    server,
    "app.post('/api/ingest/items'",
    "app.post('/api/ingest/html'"
  );
  assert.doesNotMatch(batchIngest, /value\.queue\s*=/);
  assert.match(batchIngest, /ingestItem\(value, source, 'BATCH_INGEST', defaultQueue\)/);
});

test('startup repairs only evidenced legacy VH-specific to UV-default queue collisions', () => {
  const queueHelpers = section(
    server,
    "function normalizeKnownQueue(queueValue, eventType = '')",
    'function parseItemTime(raw)'
  );
  const makeRepair = new Function(
    'normalizeSourceList', 'deriveLiveSources',
    `const QUEUE_CONFIDENCE_RANK = Object.freeze({ default: 0, legacy: 1, derived: 2, explicit: 3 });\n${queueHelpers}\nreturn repairLegacyUvQueueCollision;`
  );
  const repair = makeRepair(normalizeSourceList, deriveLiveSources);
  const item = { asin: 'B0QUEUEFIX', queue: 'AI', sources: ['VH', 'UV'] };
  const activity = [
    {
      type: 'source_confirmation',
      date: '2026-10-01T12:00:02.000Z',
      data: { asin: 'B0QUEUEFIX', source: 'UV', queue: 'AI' }
    },
    {
      type: 'new_item',
      date: '2026-10-01T12:00:00.000Z',
      data: { asin: 'B0QUEUEFIX', source: 'VH', queue: 'AFA' }
    }
  ];
  assert.deepEqual(repair(item, activity), {
    queue: 'AFA',
    repaired: true,
    reason: 'legacy-uv-default-overwrite'
  });
  assert.deepEqual(repair({ ...item, asin: 'OTHER' }, activity), {
    queue: 'AI',
    repaired: false
  });
  const lateActivity = structuredClone(activity);
  lateActivity[0].date = '2026-10-01T12:06:00.000Z';
  assert.deepEqual(repair(item, lateActivity), { queue: 'AI', repaired: false });

  const migration = section(
    server,
    '// Normalize category metadata, priority sources, queue provenance',
    'saveJSON(ITEMS_FILE, allItems);'
  );
  assert.match(migration, /repairLegacyUvQueueCollision\(item, activityLog\)/);
  assert.match(migration, /legacyBrendaQueue/);
  assert.match(migration, /classifyItemQueue\(item, '', null\)/);
  assert.match(migration, /alertOrigin:\s*startupOrigin\.origin/);
  assert.match(migration, /queueConfidence:\s*startupQueue\.confidence/);
});

test('card and detail modal display Vine queue and alert origin as separate dimensions', () => {
  const helper = section(dashboard, 'function queueBadgeClass(queueValue)', "function createProductCardHtml(item, cardView = 'feed')");
  const makeHelper = new Function(`${helper}\nreturn queueBadgeClass;`);
  const queueBadgeClass = makeHelper();
  assert.equal(queueBadgeClass('AFA'), 'tag-queue-afa');
  assert.equal(queueBadgeClass('RFY'), 'tag-queue-rfy');
  assert.equal(queueBadgeClass('AI'), 'tag-queue-ai');
  assert.equal(queueBadgeClass('Discord/Brenda'), 'tag-queue-ai');
  assert.doesNotMatch(dashboard, /setQueueFilter\('Discord\/Brenda'/);
  assert.match(dashboard, /setAlertOriginFilter\('brenda'/);
  assert.match(dashboard, /title="Alert origin \(not Vine queue\)"/);
  const modal = section(dashboard, 'function openProductModal(asin)', 'function closeProductModal()');
  assert.match(modal, /<strong>Merged Vine Queue:<\/strong> <span class="tag-badge \$\{queueBadgeClass\(item\.queue\)\}"/);
  assert.match(modal, /<strong>Source-Specific Queues:<\/strong> \$\{sourceQueueDetailHtml\}/);
  assert.match(modal, /<strong>Alert Origin:<\/strong> \$\{modalAlertOriginHtml\}/);
  assert.doesNotMatch(modal, /<strong>Queue:<\/strong> <span class="tag-badge tag-queue-ai"/);
});

test('passive VH variants and additional images stay available while card-image count badges remain hidden', () => {
  const helpers = section(
    dashboard,
    'function safeProductImageUrl(value)',
    "function createProductCardHtml(item, cardView = 'feed')"
  );
  const makeHelpers = new Function(
    `${helpers}\nreturn { safeProductImageUrl, normalizeProductImageUrls, normalizeItemVariants, variantDisplayLabel };`
  );
  const {
    safeProductImageUrl,
    normalizeProductImageUrls,
    normalizeItemVariants,
    variantDisplayLabel
  } = makeHelpers();

  assert.equal(safeProductImageUrl('javascript:alert(1)'), '');
  assert.equal(safeProductImageUrl('https://user:secret@images.example/private.jpg'), '');
  assert.deepEqual(
    normalizeProductImageUrls({
      img_url: 'https://images.example/main.jpg',
      additional_img: [
        'https://images.example/main.jpg',
        'https://images.example/two.jpg',
        { url: 'https://images.example/three.jpg' },
        'javascript:alert(1)'
      ]
    }),
    [
      'https://images.example/main.jpg',
      'https://images.example/two.jpg',
      'https://images.example/three.jpg'
    ]
  );

  const variants = normalizeItemVariants({
    variants: JSON.stringify([
      {
        asin: 'B000000001',
        dimensions: encodeURIComponent(JSON.stringify([
          { name: 'Color', value: 'Blue' },
          { name: 'Size', value: 'Large' }
        ]))
      },
      { asin: 'B000000002', dimensions: { Color: 'Red' } },
      { asin: 'B000000002', dimensions: { Color: 'Duplicate' } }
    ])
  });
  assert.equal(variants.length, 2);
  assert.equal(variantDisplayLabel(variants[0]), 'Color: Blue • Size: Large');
  assert.equal(variantDisplayLabel(variants[1]), 'Color: Red');

  const card = section(dashboard, "function createProductCardHtml(item, cardView = 'feed')", 'function escapeHtml(value)');
  assert.match(card, /normalizeProductImageUrls\(item\)/);
  assert.match(card, /primaryImageUrl/);
  assert.doesNotMatch(card, /tag-variants|tag-images/);
  assert.doesNotMatch(card, /variantBadgeHtml|imageBadgeHtml/);
  assert.doesNotMatch(dashboard, /class="tag-badge tag-(?:variants|images)"/);
  assert.doesNotMatch(card, /productImages\.length[^\n]*(?:photo|image)/i);

  const modal = section(dashboard, 'function openProductModal(asin)', 'function closeProductModal()');
  assert.match(modal, /normalizeProductImageUrls\(item\)/);
  assert.match(modal, /normalizeItemVariants\(item\)/);
  assert.match(modal, /modal-image-thumbs/);
  assert.match(modal, /modal-variant-grid/);
  assert.match(modal, /selectModalProductImage/);
  assert.doesNotMatch(modal, /\bfetch\s*\(/);

  const updateHandler = section(
    dashboard,
    'function handleUpdateItemEvent(item',
    'async function fetchItems(options = {})'
  );
  assert.match(updateHandler, /openProductModalAsin === item\.asin/);
  assert.match(updateHandler, /openProductModal\(item\.asin\)/);
  assert.doesNotMatch(updateHandler, /playChime|showToast|setTimeout|requestAnimationFrame/);
});

test('source-specific live VH queue powers an exact passive RFY filter', () => {
  const sourceHelpers = section(
    server,
    'function appendSource(value, source)',
    'function trustedStoredUvCategoryId(item)'
  );
  const normalizeQueueHelper = section(
    server,
    "function normalizeKnownQueue(queueValue, eventType = '')",
    'function normalizeAlertOrigin(value)'
  );
  const makeHelpers = new Function(
    'normalizeSourceList', 'deriveLiveSources',
    `${sourceHelpers}\n${normalizeQueueHelper}\nreturn { storedLiveQueueForSource, isPassiveVhRfyItem };`
  );
  const { storedLiveQueueForSource, isPassiveVhRfyItem } = makeHelpers(normalizeSourceList, deriveLiveSources);

  assert.equal(isPassiveVhRfyItem({
    sources: ['UV', 'VH'],
    liveSources: ['UV', 'VH'],
    queue: 'AI',
    queueObservedFrom: 'UV',
    vhQueue: 'RFY'
  }), true);
  assert.equal(isPassiveVhRfyItem({
    sources: ['UV', 'VH'],
    queue: 'RFY',
    queueObservedFrom: 'UV',
    vhQueue: 'AFA'
  }), false);
  assert.equal(isPassiveVhRfyItem({
    sources: [],
    observedSources: ['VH'],
    historySources: ['VH'],
    queue: 'RFY',
    vhQueue: 'RFY'
  }), false);
  assert.equal(storedLiveQueueForSource({
    sources: ['VH'],
    last_live_event_ms: 1,
    queue: 'RFY'
  }, 'VH'), 'RFY');
  assert.equal(storedLiveQueueForSource({
    sources: ['UV', 'VH'],
    last_live_event_ms: 1,
    queue: 'RFY',
    queueObservedFrom: 'VH'
  }, 'VH'), 'RFY');
  assert.equal(storedLiveQueueForSource({
    sources: ['UV', 'VH'],
    last_live_event_ms: 1,
    queue: 'RFY',
    queueObservedFrom: 'UV'
  }, 'VH'), null);

  const ingest = section(server, 'function ingestItem(raw', 'function applyUvAlertDetail(raw');
  assert.match(ingest, /vhQueue:\s*!isBackfill && source === 'VH' \? queue : null/);
  assert.match(ingest, /source === 'VH' \? queue : storedLiveQueueForSource\(existing, 'VH'\)/);

  const localItemsApi = section(server, "app.get('/api/items'", "app.get('/api/items/:asin'");
  assert.match(localItemsApi, /vh_rfy_only = 'false'/);
  assert.match(localItemsApi, /items\.filter\(isPassiveVhRfyItem\)/);
  assert.doesNotMatch(localItemsApi, /\bfetch\s*\(/);
});

test('separate VH RFY server explorer is explicit, signed, read-only, and off the first-alert path', () => {
  assert.match(dashboard, /switchTab\('vh-rfy'\)/);
  assert.match(dashboard, /id="tab-vh-rfy"/);
  assert.match(dashboard, /VH RFY Server Explorer/);
  assert.match(dashboard, /RFY \/ potluck only/);
  assert.match(dashboard, /id="badge-vh-rfy-items"/);
  assert.match(dashboard, /onsubmit="submitVhRfyServerSearch\(event\)"/);

  const explorer = section(
    dashboard,
    'function collectVhRfyServerFilters()',
    'function formatMsTime(ms)'
  );
  assert.match(explorer, /fetch\(['"]\/api\/vh\/item-explorer\/search['"]\s*,\s*\{/);
  assert.match(explorer, /method:\s*['"]POST['"]/);
  assert.match(explorer, /requestId:\s*newVhSignedRequestId\(\)/);
  assert.match(explorer, /createProductCardHtml\(item, 'vh-rfy'\)/);
  assert.match(explorer, /function submitVhRfyServerSearch/);
  assert.match(explorer, /function searchVhRfyServerPage/);
  assert.doesNotMatch(explorer, /\/api\/items\?|vh_rfy_only|include_history/);
  assert.doesNotMatch(explorer, /\b(?:setTimeout|setInterval|requestAnimationFrame|queueMicrotask)\s*\(/);
  assert.doesNotMatch(explorer, /\b(?:playChime|sendTelegram|sendDiscord)\s*\(/);

  const tabSwitch = section(dashboard, 'function switchTab(tabId)', '// Product Modal');
  assert.match(tabSwitch, /renderVhRfyServerExplorer\(\)/);
  assert.doesNotMatch(tabSwitch, /runVhRfyServerSearch|requestVhRfyServerPage|fetch\s*\(/);

  const newItemHandler = section(
    dashboard,
    'function handleNewItemEvent(item',
    'function handleUpdateItemEvent(item'
  );
  assert.match(newItemHandler, /playChime\(item\.isHighlight\)/);
  assert.doesNotMatch(newItemHandler, /VhRfyServer|item-explorer/);

  const endpoint = section(
    server,
    "app.post('/api/vh/item-explorer/search'",
    '// Explicit-only VHelper entitlement read.'
  );
  assert.match(endpoint, /normalizeItemExplorerRequest\(req\.body\)/);
  assert.match(endpoint, /identityManager\.materialize/);
  assert.match(endpoint, /buildItemExplorerContent/);
  assert.match(endpoint, /identityManager\.callApi\(content, identity\)/);
  assert.match(endpoint, /vhSignedRequestInFlight/);
  assert.match(endpoint, /rememberVhSignedRequest/);
  assert.match(endpoint, /applyVhSignedCooldown/);
  assert.match(endpoint, /invalid_uuid_or_subscription_insufficient/);
  assert.doesNotMatch(endpoint, /getOrCreateIdentity|explicitlyGenerate|repairInvalidUuid|recoverFromInvalidUuid/);
  assert.doesNotMatch(endpoint, /persistItems|saveJSON|notifyLiveItem|sendTelegram|sendDiscord/);

  const card = section(
    dashboard,
    "function createProductCardHtml(item, cardView = 'feed')",
    'function escapeHtml(value)'
  );
  assert.match(card, /data-card-view="\$\{viewKey\}"/);
  assert.match(card, /viewKey === 'vh-rfy' \? 'RFY'/);
  assert.match(card, /VH Server/);
  assert.match(card, /not a live observation/);
  assert.match(card, /Server-search records are read-only/);

  const serverModal = section(
    dashboard,
    'function openVhRfyServerModal(item)',
    'function openProductModal(asin)'
  );
  const modalDispatcher = section(
    dashboard,
    'function openProductModal(asin)',
    'const isPinned = pinnedAsins.has'
  );
  assert.match(serverModal, /VHelper server record — not a live drop/);
  assert.doesNotMatch(serverModal, /togglePin\(/);
  assert.match(modalDispatcher, /vhRfyServerItems\.find/);
  assert.match(modalDispatcher, /openVhRfyServerModal\(item\)/);
});

test('trial status is an explicit-only signed read with sanitized browser-only output', () => {
  assert.match(dashboard, /id="btn-vh-trial-status"[^>]+onclick="checkVhTrialStatus\(\)"/);
  assert.match(dashboard, /id="vh-trial-active"/);
  assert.match(dashboard, /id="vh-trial-days"/);
  assert.match(dashboard, /id="vh-trial-ends"/);
  assert.match(dashboard, /id="vh-trial-tier"/);
  assert.equal((dashboard.match(/checkVhTrialStatus\(\)/g) || []).length, 2);

  const client = section(
    dashboard,
    'function validateVhTrialStatusPayload(data)',
    'function collectVhRfyServerFilters()'
  );
  assert.match(client, /async function checkVhTrialStatus\(\)/);
  assert.match(client, /fetch\(['"]\/api\/vh\/trial-status['"]\s*,\s*\{/);
  assert.match(client, /method:\s*['"]POST['"]/);
  assert.match(client, /body:\s*JSON\.stringify\(\{ requestId: newVhSignedRequestId\(\) \}\)/);
  assert.match(client, /trialEndsAtIso/);
  assert.match(client, /daysRemaining/);
  assert.match(client, /membershipTier/);
  assert.match(client, /No entitlement was inferred/);
  assert.doesNotMatch(client, /\b(?:setTimeout|setInterval|requestAnimationFrame|queueMicrotask)\s*\(/);
  assert.doesNotMatch(client, /localStorage|sessionStorage|indexedDB/);
  assert.doesNotMatch(client, /devices|contribution|payment|resolved_uuid/i);

  const tabSwitch = section(dashboard, 'function switchTab(tabId)', '// Product Modal');
  assert.match(tabSwitch, /renderVhTrialStatus\(\)/);
  assert.doesNotMatch(tabSwitch, /checkVhTrialStatus|\/api\/vh\/trial-status|fetch\s*\(/);

  const endpoint = section(
    server,
    "app.post('/api/vh/trial-status'",
    "app.post('/api/identity/rotate'"
  );
  assert.match(endpoint, /normalizeTrialStatusRequest\(req\.body\)/);
  assert.match(endpoint, /identityManager\.materialize/);
  assert.match(endpoint, /buildTrialStatusContent\(request, identity, cid\)/);
  assert.match(endpoint, /identityManager\.callApi\(content, identity\)/);
  assert.match(endpoint, /sanitizeTrialStatusResponse\(result, checkedAtMs\)/);
  assert.match(endpoint, /vhSignedRequestInFlight/);
  assert.match(endpoint, /rememberVhSignedRequest/);
  assert.match(endpoint, /applyVhSignedCooldown/);
  assert.match(endpoint, /trialActive:\s*sanitized\.trialActive/);
  assert.match(endpoint, /trialEndsAtIso:\s*sanitized\.trialEndsAtIso/);
  assert.match(endpoint, /daysRemaining:\s*sanitized\.daysRemaining/);
  assert.match(endpoint, /membershipTier:\s*sanitized\.membershipTier/);
  assert.doesNotMatch(endpoint, /getOrCreateIdentity|explicitlyGenerate|repairInvalidUuid|recoverFromInvalidUuid/);
  assert.doesNotMatch(endpoint, /persistItems|saveJSON|notifyLiveItem|sendTelegram|sendDiscord/);
  assert.doesNotMatch(endpoint, /resolved_uuid|\.devices|contribution|active_payment_method/);

  const signedControls = section(
    server,
    'const VH_SIGNED_REQUEST_TTL_MS',
    '// ============================================================================\n// ULTRAVINER CRYPTOGRAPHY & UTILS'
  );
  assert.match(signedControls, /let vhSignedRequestInFlight = false/);
  assert.match(signedControls, /let vhSignedNextAllowedAtMs = 0/);
  assert.match(signedControls, /function rememberVhSignedRequest/);
  assert.match(signedControls, /function applyVhSignedCooldown/);
});

test('VH identity rotation uses one click warning and no typed phrase', () => {
  const rotate = section(
    dashboard,
    'async function rotateVhIdentity()',
    '// RFY & Catalog Explorer'
  );
  const endpoint = section(
    server,
    "app.post('/api/identity/rotate'",
    "app.get('/api/vh/diagnostics'"
  );

  assert.match(rotate, /\bconfirm\s*\(/);
  assert.doesNotMatch(rotate, /\bprompt\s*\(/);
  assert.match(rotate, /fetch\(['"]\/api\/identity\/rotate['"],\s*\{\s*method:\s*['"]POST['"]\s*\}\)/);
  assert.doesNotMatch(rotate, /confirmation/);
  assert.match(endpoint, /identityManager\.explicitlyGenerate/);
  assert.doesNotMatch(endpoint, /req\.body\?\.confirmation/);
});

test('UV 26.11.62 compatibility separates session authentication, live delivery, and signed search', () => {
  assert.equal(UV_RUNTIME_VERSION, '26.11.62');
  assert.equal(UV_LAUNCHER_VERSION, '1.0.20');
  assert.equal(UV_SUPPORTS_ENROLLMENT_GATE, true);
  assert.deepEqual(UV_IDENTIFICATION_CAPABILITIES, {
    syncSettings: true,
    deviceType: 'desktop',
    isNearClaimLimit: false,
    isClaimLimitReached: false,
    supportsEnrollmentGate: true
  });
  assert.deepEqual(UV_ACCOUNT_HOUSEKEEPING_TYPES, ['subscription', 'patreon']);

  const signedPayload = {
    pageSize: '10',
    page: '1',
    searchTerm: '',
    countryId: '2',
    categories: '',
    queueTypes: 'RFY,AI,AFA',
    queueId: 'explore-id',
    queueName: 'Explore'
  };
  const requestBody = buildUvSearchRequestBody('opaque-token', signedPayload);
  assert.deepEqual(requestBody, {
    token: 'opaque-token',
    ...signedPayload,
    supportsEnrollmentGate: true
  });
  assert.equal(Object.hasOwn(signedPayload, 'supportsEnrollmentGate'), false);
  assert.throws(
    () => buildUvSearchRequestBody('token', { ...signedPayload, supportsEnrollmentGate: true }),
    /unsigned body-only field/
  );

  assert.equal(normalizeUvOrdersInProgress('7.9'), 7);
  assert.equal(normalizeUvOrdersInProgress(-2), 0);
  assert.equal(normalizeUvOrdersInProgress(undefined, 4), 4);
  assert.equal(normalizeUvOrdersInProgress('invalid', 3), 3);

  assert.match(server, /version:\s*UV_RUNTIME_VERSION/);
  assert.match(server, /launcherVersion:\s*UV_LAUNCHER_VERSION/);
  assert.match(server, /\.\.\.UV_ACCOUNT_HOUSEKEEPING_TYPES/);
  assert.match(server, /flattened\.ordersInProgress/);
  assert.match(server, /ordersInProgress:\s*normalizeUvOrdersInProgress/);
  assert.match(dashboard, /tag-ordering/);
  assert.match(dashboard, /UV Orders in Progress:/);
  assert.doesNotMatch(server, /type:\s*['"]orderInProgress['"]/);

  const identification = section(
    server,
    'function buildUvIdentificationPayload()',
    'function sendUvIdentification'
  );
  for (const field of [
    'syncSettings',
    'deviceType',
    'isNearClaimLimit',
    'isClaimLimitReached',
    'supportsEnrollmentGate'
  ]) {
    assert.match(identification, new RegExp(`${field}:\\s*UV_IDENTIFICATION_CAPABILITIES\\.${field}`));
  }
  assert.match(server, /'syncedSettings'/);

  const exploreIdentity = section(server, 'function effectiveUvExploreQueue()', 'function syncLegacyUvConfig()');
  assert.match(exploreIdentity, /getUvQueues\('Explore'\)\[0\]/);
  assert.doesNotMatch(exploreIdentity, /Alert/);
  const legacyMirror = section(server, 'function syncLegacyUvConfig()', 'function persistUvProfile()');
  assert.match(legacyMirror, /config\.exploreQueueId = exploreQueue\?\.id \|\| ''/);
  assert.doesNotMatch(legacyMirror, /exploreQueue\?\.id \|\| alertQueue/);

  const connectedFrame = section(server, "if (type === 'connected')", "if (type === 'invalidToken')");
  assert.match(connectedFrame, /Transport greeting received; awaiting identification result/);
  assert.doesNotMatch(connectedFrame, /uvAuthenticated\s*=\s*true/);
  assert.doesNotMatch(connectedFrame, /markFeedHealthy/);

  const invalidTokenFrame = section(server, "if (type === 'invalidToken')", "if (type === 'plan')");
  assert.match(invalidTokenFrame, /terminalUvAuthFailure\s*=\s*true/);
  assert.match(invalidTokenFrame, /uvRetryController\.blockTerminal\('invalid-token'\)/);
  assert.match(invalidTokenFrame, /uvStatus\s*=\s*'Invalid \/ Expired Token'/);
  assert.doesNotMatch(invalidTokenFrame, /scheduleUvReconnect/);

  const planFrame = section(server, "if (type === 'plan')", "if (type === 'screens')");
  assert.match(planFrame, /typeof data === 'string' \? data\.trim\(\) : ''/);
  assert.match(planFrame, /if \(!plan\)/);
  assert.match(planFrame, /resetAfterEvidence\('non-empty-plan'\)/);
  assert.match(planFrame, /markFeedHealthy\('UV', uvSessionHealthReason\(\)\)/);

  const initialCatalog = section(
    server,
    'async function fetchInitialUvCatalog()',
    '// VHELPER PASSIVE ITEM/ENRICHMENT HANDLING'
  );
  assert.match(initialCatalog, /const exploreQueue = effectiveUvExploreQueue\(\)/);
  assert.match(initialCatalog, /buildUvSearchRequestBody\(config\.token, signedPayload\)/);
  assert.doesNotMatch(initialCatalog, /config\.alertQueueId/);

  const tokenProbe = section(
    server,
    'async function probeUvToken(token)',
    'async function runConfiguredUvTokenHealthCheck()'
  );
  assert.match(tokenProbe, /const exploreQueue = effectiveUvExploreQueue\(\)/);
  assert.match(tokenProbe, /buildUvSearchRequestBody\(token, signedPayload\)/);
  assert.match(tokenProbe, /skipped:\s*true/);
  assert.doesNotMatch(tokenProbe, /config\.alertQueueId/);

  const scheduledCheck = section(
    server,
    'async function runConfiguredUvTokenHealthCheck()',
    "app.post('/api/uv/test-token'"
  );
  const rejectedSearch = section(
    scheduledCheck,
    'if (explicitlyRejected)',
    '// A search rejection'
  );
  assert.match(rejectedSearch, /diagnostic only/);
  assert.match(rejectedSearch, /authenticated WebSocket is preserved/);
  assert.doesNotMatch(
    rejectedSearch,
    /destroyUvSocket|clearUvTimers|uvGeneration\s*\+=|uvReconnectBlocked\s*=|uvAuthenticated\s*=\s*false|Invalid \/ Expired Token/
  );
  assert.doesNotMatch(scheduledCheck, /connectUltraviner\s*\(/);

  const authenticationTimeoutPath = section(
    server,
    'const authenticationTimeout = Math.max(',
    '      uvPingInterval = setInterval'
  );
  assert.match(authenticationTimeoutPath, /authenticationTimedOut = true/);
  assert.match(authenticationTimeoutPath, /uvRetryController\.recordAuthenticationTimeout\(\)/);
  assert.doesNotMatch(authenticationTimeoutPath, /blockTerminal|manual reconnect required/);
  const uvClosePath = section(
    server,
    "socket.on('close', (code, reasonBuffer)",
    "socket.on('error', error"
  );
  assert.match(uvClosePath, /authenticationTimedOut \? 'authentication-timeout' : 'transport-close'/);
  assert.match(uvClosePath, /scheduleUvReconnect/);
  const liveEvidencePath = section(
    server,
    "if (!UV_LIVE_ALERT_TYPES.has(type))",
    "if (!products.length)"
  );
  assert.match(liveEvidencePath, /resetAfterEvidence\('live-alert'\)/);

  assert.equal(calculateUvRetryDelay({
    baseDelayMs: 5000,
    maxDelayMs: 300000,
    jitterRatio: 0.2,
    consecutiveTimeouts: 1,
    randomValue: 0.5
  }), 5000);
  assert.equal(calculateUvRetryDelay({
    baseDelayMs: 5000,
    maxDelayMs: 300000,
    jitterRatio: 0.2,
    consecutiveTimeouts: 2,
    randomValue: 0.5
  }), 10000);
  assert.equal(calculateUvRetryDelay({
    baseDelayMs: 5000,
    maxDelayMs: 300000,
    jitterRatio: 0.2,
    consecutiveTimeouts: 1,
    randomValue: 0
  }), 4000);
  assert.equal(calculateUvRetryDelay({
    baseDelayMs: 5000,
    maxDelayMs: 300000,
    jitterRatio: 0.2,
    consecutiveTimeouts: 1,
    randomValue: 1
  }), 6000);
  assert.equal(calculateUvRetryDelay({
    baseDelayMs: 5000,
    maxDelayMs: 300000,
    jitterRatio: 0.2,
    consecutiveTimeouts: 20,
    randomValue: 1
  }), 300000);

  let nextTimerId = 0;
  let nowMs = Date.parse('2026-09-10T12:00:00.000Z');
  const timers = new Map();
  const retryCalls = [];
  const retryController = new UvRetryController({
    getBaseDelayMs: () => 5000,
    getMaxDelayMs: () => 300000,
    getJitterRatio: () => 0.2,
    nowFn: () => nowMs,
    randomFn: () => 0.5,
    setTimeoutFn: (callback, delayMs) => {
      const id = ++nextTimerId;
      timers.set(id, { callback, delayMs });
      return id;
    },
    clearTimeoutFn: id => timers.delete(id),
    onRetry: retry => retryCalls.push(retry)
  });

  assert.equal(retryController.recordAuthenticationTimeout(), 1);
  const firstRetry = retryController.schedule('authentication-timeout', {
    useAuthenticationBackoff: true
  });
  assert.equal(firstRetry.scheduled, true);
  assert.equal(firstRetry.delayMs, 5000);
  const overlappingRetry = retryController.schedule('authentication-timeout', {
    useAuthenticationBackoff: true
  });
  assert.deepEqual(overlappingRetry.cause, 'already-scheduled');
  assert.equal(timers.size, 1);
  const [firstTimerId, firstTimer] = [...timers.entries()][0];
  timers.delete(firstTimerId);
  nowMs += firstTimer.delayMs;
  firstTimer.callback();
  assert.equal(retryCalls.length, 1);
  assert.equal(retryCalls[0].reason, 'authentication-timeout');

  assert.equal(retryController.recordAuthenticationTimeout(), 2);
  const secondRetry = retryController.schedule('authentication-timeout', {
    useAuthenticationBackoff: true
  });
  assert.equal(secondRetry.delayMs, 10000);
  assert.equal(retryController.resetAfterEvidence('non-empty-plan'), 2);
  assert.equal(timers.size, 0);
  assert.equal(retryController.diagnostics().authenticationTimeoutCount, 0);
  assert.equal(retryController.diagnostics().authenticationTimeoutTotal, 2);
  assert.equal(retryController.diagnostics().retryPending, false);

  retryController.recordAuthenticationTimeout();
  retryController.schedule('authentication-timeout', { useAuthenticationBackoff: true });
  retryController.blockTerminal('invalid-token');
  assert.equal(timers.size, 0);
  assert.equal(retryController.diagnostics().terminalReason, 'invalid-token');
  assert.equal(retryController.schedule('transport-close').cause, 'terminal-blocked');
  retryController.clearTerminalBlock();
  assert.equal(retryController.schedule('manual-retry').scheduled, true);

  const manualReconnect = section(
    server,
    "app.post('/api/uv/reconnect'",
    "app.get('/api/uv/diagnostics'"
  );
  assert.match(manualReconnect, /manual-reconnect/);
  assert.match(manualReconnect, /allowTerminalReset: true/);
  const diagnosticsEndpoint = section(
    server,
    "app.get('/api/uv/diagnostics'",
    "app.post('/api/sync/refresh'"
  );
  assert.match(diagnosticsEndpoint, /authenticationTimeoutCount/);
  assert.match(diagnosticsEndpoint, /authenticationTimeoutTotal/);
  assert.match(diagnosticsEndpoint, /nextRetryAt/);
  assert.match(diagnosticsEndpoint, /retryStatus/);
  assert.match(dashboard, /Authentication timeouts \(consecutive \/ process total\)/);
  assert.match(dashboard, /Next automatic retry/);

  assert.match(dashboard, /Test UV Search Access/);
  assert.match(dashboard, /live WebSocket authentication is separate/);
  assert.match(dashboard, /signed-search diagnostic failed; WebSocket authentication is separate/);
  assert.match(dashboard, /Live-alert delivery on current connection/);
  assert.match(server, /WebSocket identification is a separate check/);
  assert.doesNotMatch(dashboard, /Valid token; search returned/);
});

test('ordinary settings cannot replace UV identity or erase blank notification credentials', () => {
  const settingsSave = section(
    dashboard,
    'async function saveSettings(options = {})',
    'async function disableVhCompletely'
  );
  assert.doesNotMatch(settingsSave, /newUvAccount/);
  assert.doesNotMatch(settingsSave, /getElementById\(['"]cfg-token['"]\)/);
  assert.doesNotMatch(settingsSave, /getElementById\(['"]cfg-az-user['"]\)/);
  assert.match(settingsSave, /if \(telegramToken\) payload\.telegramToken = telegramToken/);
  assert.match(settingsSave, /if \(telegramChatId\) payload\.telegramChatId = telegramChatId/);
  assert.match(dashboard, /id="cfg-token"[^>]*readonly/);
  assert.match(dashboard, /id="cfg-az-user"[^>]*readonly/);

  const genericConfig = section(
    server,
    "app.post('/api/config'",
    '// Explicit VHelper kill/enable endpoints.'
  );
  assert.match(genericConfig, /body\.token !== undefined/);
  assert.match(genericConfig, /body\.azUser !== undefined/);
  assert.match(genericConfig, /UV account credentials are isolated from ordinary settings/);
  assert.match(genericConfig, /delete body\[key\]/);

  const onboarding = section(server, "app.post('/api/uv/onboard'", "app.post('/api/uv/profile/reset'");
  assert.match(onboarding, /configureNewUvAccount\(body\.token, body\.azUser\)/);
});
