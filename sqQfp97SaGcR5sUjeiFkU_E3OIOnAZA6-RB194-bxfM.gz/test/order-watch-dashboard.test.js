'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const coordinator = fs.readFileSync(path.join(root, 'lib', 'order-coordinator.js'), 'utf8');

function section(source, start, end) {
  const from = source.indexOf(start);
  const to = source.indexOf(end, from + start.length);
  assert.ok(from >= 0, `missing start marker: ${start}`);
  assert.ok(to > from, `missing end marker: ${end}`);
  return source.slice(from, to);
}

test('dashboard exposes one-shot watch lifecycle on VH RFY and UV Explorer RFY/AFA records', () => {
  const card = section(
    dashboard,
    "function createProductCardHtml(item, cardView = 'feed')",
    'function escapeHtml(value)'
  );
  assert.match(card, /isVhServerRecord[\s\S]*isUvExplorerWatchRecord[\s\S]*Watch for AFA\/AI/);
  assert.match(card, /viewKey === 'uv-explorer' && \['RFY', 'AFA'\]\.includes\(q\)/);
  assert.match(card, /armAfaAiWatch\('\$\{item\.asin\}', event, '\$\{viewKey\}'\)/);
  assert.match(card, /never order this \$\{watchSeedDescription\}/i);
  assert.match(card, /viewKey === 'feed' && !isVhServerRecord[\s\S]*Order on PC/);

  const armAction = section(dashboard, 'function watchVariantChoices(item)', 'async function cancelAfaAiWatch(watchId)');
  assert.match(armAction, /normalizeItemVariants\(item, 100\)/);
  assert.match(armAction, /variantAsin\(variant\)/);
  assert.match(armAction, /asin === parentAsin/);
  assert.match(armAction, /Any currently available variant/);
  assert.match(armAction, /variantPolicy = selectedVariantAsin \? 'exact' : 'first_available'/);
  assert.match(armAction, /selectedVariantAsin/);
  assert.match(armAction, /watchVariantChoices\(item\)\.some\(variant => variant\.asin === selectedVariantAsin\)/);
  assert.match(armAction, /selectedVariantLabel/);
  assert.match(armAction, /separate trustworthy fresh AFA or AI live event/i);
  assert.match(armAction, /marked missed; nothing is queued or retried/i);
  assert.match(armAction, /fetch\('\/api\/order-agent\/watches'/);
  assert.doesNotMatch(armAction, /\/api\/order-agent\/jobs/);

  assert.match(dashboard, /id="modal-watch-arm"/);
  assert.match(dashboard, /id="watch-arm-variant"/);
  assert.match(dashboard, /Exact only:/);
  assert.match(dashboard, /id="order-watch-list"/);
  assert.match(dashboard, /ARMED|String\(watch\.state/);
  assert.match(dashboard, /cancelAfaAiWatch/);
});

test('Watch dialog variants load is one explicit official-contract request with ephemeral choices only', () => {
  assert.match(dashboard, /id="btn-watch-load-vh-variants"[^>]+onclick="loadAfaAiWatchVariantsFromVHelper\(\)"/);
  assert.match(dashboard, /id="watch-arm-variant-load-state"/);
  assert.match(dashboard, /Opening the dialog makes no request/);
  assert.match(dashboard, /Search and pagination use only explicit RFY[\s\S]*never load variants automatically/);
  assert.match(dashboard, /Exactly three narrow signed reads are permitted:[\s\S]*item_explorer_variants[\s\S]*get_user_stats/);
  assert.doesNotMatch(dashboard, /This tab does not call[\s\S]{0,120}<code>variants<\/code>/);

  const openDialog = section(
    dashboard,
    "function armAfaAiWatch(asin, event, cardView = 'vh-rfy')",
    'function closeAfaAiWatchDialog()'
  );
  assert.match(openDialog, /resetAfaAiWatchVariantLookupState\(\)/);
  assert.match(openDialog, /renderAfaAiWatchVariantOptions\(item, false\)/);
  assert.match(openDialog, /renderAfaAiWatchVariantLookupState\(\)/);
  assert.doesNotMatch(openDialog, /\bfetch\s*\(|loadAfaAiWatchVariantsFromVHelper\s*\(/);

  const clickHandler = section(
    dashboard,
    'async function loadAfaAiWatchVariantsFromVHelper()',
    'function updateAfaAiWatchVariantNote()'
  );
  assert.equal((clickHandler.match(/\bfetch\s*\(/g) || []).length, 1);
  assert.match(clickHandler, /fetch\('\/api\/vh\/item-explorer\/variants'/);
  assert.match(clickHandler, /body:\s*JSON\.stringify\(\{ requestId: newVhSignedRequestId\(\), asin \}\)/);
  assert.match(clickHandler, /validateVhWatchVariantsPayload\(data, asin\)/);
  assert.match(clickHandler, /There is no[\s\S]*retry/);
  assert.match(clickHandler, /no[\s\S]*retry, prefetch, poll, Amazon\/UV\/SmartViner fallback/i);
  assert.doesNotMatch(clickHandler, /\b(?:setTimeout|setInterval|requestAnimationFrame|queueMicrotask)\s*\(/);
  assert.doesNotMatch(clickHandler, /\b(?:localStorage|sessionStorage|indexedDB)\b/);
  assert.doesNotMatch(clickHandler, /item\.variants\s*=|vhRfyServerItems\s*=|\/api\/items|amazon\.ca|ultraviner|smartviner\.com/i);

  const choices = section(
    dashboard,
    'function watchVariantChoices(item)',
    'function updateAfaAiWatchVariantNote()'
  );
  assert.match(choices, /source: 'vh_item_explorer_variants'/);
  assert.match(choices, /pendingWatchArmAsin === parentAsin/);
  assert.match(choices, /data\.persisted !== false/);
  assert.match(choices, /data\.mergedIntoLiveFeed !== false/);
  assert.match(choices, /data\.variants\.length > 100/);
  assert.match(choices, /Any currently available variant/);
  assert.match(choices, /vhWatchVariants = \[\.\.\.sanitized\.variants\]/);

  const endpoint = section(
    server,
    "app.post('/api/vh/item-explorer/variants'",
    '// Explicit-only VHelper entitlement read.'
  );
  assert.match(endpoint, /normalizeItemExplorerVariantsRequest\(req\.body\)/);
  assert.match(endpoint, /buildItemExplorerVariantsContent\(request, identity, cid\)/);
  assert.equal((endpoint.match(/identityManager\.callApi\(content, identity\)/g) || []).length, 1);
  assert.match(endpoint, /sanitizeItemExplorerVariantsResponse\(result, request\.asin\)/);
  assert.match(endpoint, /rememberVhSignedRequest\(request\.requestId, now\)/);
  assert.match(endpoint, /vhSignedRequestInFlight/);
  assert.match(endpoint, /applyVhSignedCooldown/);
  assert.match(endpoint, /persisted: false/);
  assert.match(endpoint, /mergedIntoLiveFeed: false/);
  assert.match(endpoint, /There is no retry branch/);
  assert.doesNotMatch(endpoint, /getOrCreateIdentity|explicitlyGenerate|repairInvalidUuid|recoverFromInvalidUuid/);
  assert.doesNotMatch(endpoint, /persistItems|saveJSON|notifyLiveItem|sendTelegram|sendDiscord|allItems/);

  const manualOrder = section(
    dashboard,
    'async function orderItemOnPc(asin, event)',
    'function renderSmartVinerStatus()'
  );
  assert.doesNotMatch(manualOrder, /item-explorer\/variants|loadAfaAiWatchVariants|selectedVariant/);
});

test('watch evaluation precedes silent same-ASIN handling and receives isolated current-event metadata', () => {
  const ingest = section(server, 'function ingestItem(raw', 'function applyUvAlertDetail(raw');
  const mergeDispatch = ingest.indexOf('maybeDispatchAutomaticOrder(mergedItem, {');
  const notifyBranch = ingest.indexOf('if (mergeDecision.notify)', mergeDispatch);
  const silentUpdate = ingest.indexOf("broadcastLocal('update_item'", mergeDispatch);
  assert.ok(mergeDispatch >= 0 && mergeDispatch < notifyBranch && mergeDispatch < silentUpdate);
  assert.match(ingest.slice(mergeDispatch, notifyBranch), /watchOnly: !mergeDecision\.notify/);
  assert.match(ingest.slice(mergeDispatch, notifyBranch), /allowLaterRuleDispatch/);
  assert.match(ingest, /const allowLaterRuleDispatch = !mergeDecision\.notify &&[\s\S]*crossFeedConfirmation[\s\S]*\['UV', 'VH'\]\.includes\(source\)[\s\S]*previousLiveSources\.some/);
  assert.match(ingest.slice(mergeDispatch, notifyBranch), /previousLiveSources/);
  assert.match(ingest.slice(mergeDispatch, notifyBranch), /previousMergedItem: existing/);
  assert.match(ingest.slice(mergeDispatch, notifyBranch), /liveEventItem: liveEventOrderItem/);
  assert.match(ingest, /if \(!isBackfill\) \{[\s\S]*maybeDispatchAutomaticOrder\(mergedItem/);

  const isolated = section(
    ingest,
    'const liveEventOrderItem = {',
    'const reason = flattened.reason'
  );
  assert.match(isolated, /enrollmentGuid: incomingRecommendationGuid/);
  assert.match(isolated, /title: decodeHtmlEntities\(flattened\.title \|\| flattened\.name/);
  assert.match(isolated, /price: flattened\.price \?\? null/);
  assert.match(isolated, /liveSources: \[source\]/);
  assert.doesNotMatch(isolated, /previous/);

  assert.match(coordinator, /never pass a merged card's historical RFY[\s\S]*enrollment\/recommendation metadata/);
  assert.match(coordinator, /const freshItem = this\.#freshWatchDispatchItem/);
  assert.match(coordinator, /historical RFY metadata was not used/);

  const freshRule = section(coordinator, '#freshRuleDispatchItem(item, observation = {})', '#finishWatchAttempt(watch, outcome');
  assert.match(freshRule, /fresh\.enrollmentGuid \|\| fresh\.enrollment_guid \|\| null/);
  assert.match(freshRule, /liveSources: observation\.source \? \[String\(observation\.source\)\.toUpperCase\(\)\] : \[\]/);
  assert.doesNotMatch(freshRule, /item\?\.title|item\?\.img_url|item\?\.enrollment/);
});

test('dashboard has readiness, emergency pause, circuit acknowledgement, rolling controls, tester, and explanations', () => {
  const orderUi = section(dashboard, '<div class="settings-section" id="order-agent-settings-section">', '<div class="settings-section" id="smartviner-settings-section">');
  for (const id of [
    'order-readiness-grid',
    'order-safety-alert',
    'btn-order-pause',
    'btn-order-safety-ack',
    'order-rolling-count-limit',
    'order-rolling-charge-limit',
    'order-rule-preview'
  ]) {
    assert.match(orderUi, new RegExp(`id="${id}"`));
  }
  assert.match(dashboard, /toggleAutomaticOrderPause/);
  assert.match(dashboard, /ACKNOWLEDGE ORDER SAFETY PAUSE/);
  assert.match(dashboard, /RESUME AUTOMATIC ORDERING/);
  assert.match(dashboard, /previewOrderRules\(\)/);
  assert.match(dashboard, /recent live items/i);
  assert.match(dashboard, /Current merged-card match — not proof of an order attempt/);
  assert.match(dashboard, /effective unattended cap/);
  assert.match(dashboard, /item price:/);
  assert.match(dashboard, /queue:/);
  assert.match(dashboard, /sources:/);
  assert.match(dashboard, /action:/);
  assert.match(dashboard, /Number\(status\.jobs\?\.active \|\| 0\) === 0/);
  assert.match(coordinator, /reasonCode: 'active_order_job'/);
});

test('rule editor advertises dirty state, unload protection, duplication, and exact matching modes', () => {
  assert.match(dashboard, /id="order-rule-dirty-badge"/);
  assert.match(dashboard, /UNSAVED DRAFT/);
  assert.match(dashboard, /window\.addEventListener\('beforeunload'/);
  assert.match(dashboard, /event\.returnValue = ''/);
  assert.match(dashboard, /function duplicateOrderRule\(index\)/);
  assert.match(dashboard, /structuredClone\(source\)/);
  const renderRules = section(dashboard, 'function renderOrderRules()', 'function ruleWords(value)');
  assert.match(renderRules, /if \(!orderRulesDirty\) \{[\s\S]*order-checkout-limit[\s\S]*order-rolling-count-limit[\s\S]*order-rolling-charge-limit/);
  assert.match(dashboard, /last saved rules, not the visible unsaved draft/);
  assert.match(dashboard, /option value="exact_phrase"/);
  assert.match(dashboard, /option value="whole_word"/);
  assert.match(dashboard, /option value="exact"/);
});

test('credential-free export/import and all safety/watch APIs remain local coordinator actions', () => {
  const routes = section(server, '// PC ORDER COMPANION', "app.get('/api/vpn/status'");
  for (const route of [
    '/api/order-agent/rules/preview',
    '/api/order-agent/watches',
    '/api/order-agent/safety/pause',
    '/api/order-agent/safety/acknowledge',
    '/api/order-agent/export',
    '/api/order-agent/import'
  ]) {
    assert.ok(routes.includes(route), `missing route ${route}`);
  }
  const armRoute = section(routes, "app.post('/api/order-agent/watches'", "app.post('/api/order-agent/watches/:watchId/cancel'");
  assert.match(armRoute, /Do not consult a merged or persisted card/);
  assert.doesNotMatch(armRoute, /allItems|isLiveItem|already_live_target_queue/);
  assert.match(routes, /orderCoordinator\.armWatch/);
  assert.match(routes, /orderCoordinator\.cancelWatch/);
  assert.match(routes, /orderCoordinator\.setAutomaticPause/);
  assert.match(routes, /orderCoordinator\.acknowledgeSafetyPause/);
  assert.match(routes, /confirmation !== ORDER_IMPORT_CONFIRMATION/);
  assert.match(routes, /orderCoordinator\.exportConfiguration/);
  assert.match(routes, /orderCoordinator\.importConfiguration/);
  assert.doesNotMatch(routes, /axios|https\.request|vhSocket\.emit|uvSocket/);

  assert.match(dashboard, /exportOrderAutomation/);
  assert.match(dashboard, /importOrderAutomationFile/);
  assert.match(coordinator, /containsSecrets: false/);
  const exportSection = section(coordinator, 'exportConfiguration()', 'importConfiguration(raw = {})');
  assert.doesNotMatch(exportSection, /pairing\.secret|expectedAccountHash|this\.jobs|safetyState/);
});
