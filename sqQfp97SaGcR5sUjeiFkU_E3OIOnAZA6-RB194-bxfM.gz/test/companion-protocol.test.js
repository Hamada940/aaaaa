'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const nodeProtocol = require('../lib/order-protocol');

async function companionModule(name) {
  return import(pathToFileURL(path.join(__dirname, '..', 'companion', 'src', name)).href);
}

const SECRET = 'vdh1.AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';

test('browser companion canonical HMAC is byte-compatible with the VPS protocol', async () => {
  const protocol = await companionModule('protocol.mjs');
  const payload = { z: 1, a: { nested: true, values: [3, 2, 1] } };
  assert.equal(protocol.canonicalJson(payload), nodeProtocol.canonicalJson(payload));
  const browserSignature = await protocol.signPayload(SECRET, 'order_job', payload);
  const nodeSignature = nodeProtocol.signPayload(SECRET, 'order_job', payload);
  assert.equal(browserSignature, nodeSignature);
  assert.equal(await protocol.verifyPayloadSignature(SECRET, 'order_job', payload, nodeSignature), true);
  assert.equal(await protocol.verifyPayloadSignature(SECRET, 'order_job', { ...payload, z: 2 }, nodeSignature), false);
});

test('browser companion validates a short-lived read-only Amazon variant request exactly', async () => {
  const protocol = await companionModule('protocol.mjs');
  const now = 1_700_000_000_000;
  const raw = nodeProtocol.buildVariantLookupRequest({
    now,
    ttlMs: 15_000,
    lookupId: 'lookup-browser-123456',
    nonce: 'lookup-browser-nonce-123456',
    asin: 'B000000010',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  const request = protocol.validateVariantLookupRequest(raw, { now: now + 100 });
  assert.deepEqual(request.item, {
    asin: 'B000000010',
    queue: 'RFY',
    enrollmentGuid: '12345678-1234-1234-1234-123456789abc'
  });
  assert.equal(request.operation, 'read_only_amazon_variants');
  assert.throws(
    () => protocol.validateVariantLookupRequest({ ...raw, operation: 'voice_order' }, { now }),
    /operation/i
  );
  assert.throws(
    () => protocol.validateVariantLookupRequest({ ...raw, checkout: true }, { now }),
    /unsupported fields/i
  );
  assert.throws(
    () => protocol.validateVariantLookupRequest({
      ...raw,
      item: { ...raw.item, customerId: 'SECRET' }
    }, { now }),
    /unsupported fields/i
  );
  assert.throws(
    () => protocol.validateVariantLookupRequest({ ...raw, expiresAtMs: now + 30_001 }, { now }),
    /lifetime/i
  );
  assert.throws(
    () => protocol.validateVariantLookupRequest({ ...raw, issuedAtMs: String(now) }, { now }),
    /lifetime/i
  );
  assert.throws(
    () => protocol.validateVariantLookupRequest(raw, { now: now + 15_001 }),
    /expired/i
  );
});

test('browser companion accepts only complete live jobs with an allowlisted variant policy', async () => {
  const protocol = await companionModule('protocol.mjs');
  const now = 1_700_000_000_000;
  const raw = nodeProtocol.buildOrderJob({
    now,
    ttlMs: 15_000,
    jobId: 'job-browser-1234',
    item: {
      asin: 'B000000001',
      title: 'Coffee grinder',
      queue: 'RFY',
      enrollmentGuid: '12345678-1234-1234-1234-123456789abc',
      isParentAsin: true,
      price: 99.99,
      etv: 0,
      sources: ['UV']
    },
    policy: { mode: 'auto', unattendedCheckoutLimit: 30, currency: 'CAD' }
  });
  const job = protocol.validateOrderJob(raw, { now: now + 100 });
  assert.equal(job.item.asin, 'B000000001');
  assert.equal(job.policy.variantPolicy, 'first_available');
  assert.equal(job.policy.selectedVariantAsin, null);
  assert.equal(job.policy.unattendedCheckoutLimit, 30);
  const exactRaw = nodeProtocol.buildOrderJob({
    now,
    ttlMs: 15_000,
    jobId: 'job-browser-exact',
    item: {
      asin: 'B000000001',
      title: 'Coffee grinder parent',
      queue: 'AFA',
      enrollmentGuid: '12345678-1234-1234-1234-123456789abc',
      isParentAsin: true
    },
    policy: {
      mode: 'auto',
      variantPolicy: 'exact',
      selectedVariantAsin: 'B000000002',
      unattendedCheckoutLimit: 30
    }
  });
  const exact = protocol.validateOrderJob(exactRaw, { now: now + 100 });
  assert.equal(exact.policy.variantPolicy, 'exact');
  assert.equal(exact.policy.selectedVariantAsin, 'B000000002');
  assert.throws(
    () => protocol.validateOrderJob({
      ...exactRaw,
      policy: { ...exactRaw.policy, selectedVariantAsin: 'bad' }
    }, { now }),
    /selected variant ASIN/i
  );
  assert.throws(
    () => protocol.validateOrderJob({
      ...exactRaw,
      policy: { ...exactRaw.policy, selectedVariantAsin: exactRaw.item.asin }
    }, { now }),
    /child ASIN distinct from its parent/i
  );
  assert.throws(() => protocol.validateOrderJob(raw, { now: now + 15_001 }), /expired/i);
  assert.throws(
    () => protocol.validateOrderJob({ ...raw, policy: { ...raw.policy, variantPolicy: 'random' } }, { now }),
    /variant/i
  );
  assert.throws(
    () => protocol.validateOrderJob({ ...raw, policy: { ...raw.policy, currency: 'USD' } }, { now }),
    /CAD/i
  );
});
