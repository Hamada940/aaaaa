'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  UV_EXPLORER_PAGE_SIZE,
  UV_EXPLORER_MAX_PAGE,
  UV_EXPLORER_QUEUE_TYPES,
  UvExplorerValidationError,
  normalizeUvExplorerRequest,
  buildUvExplorerSignedPayload,
  uvExplorerPageMetadata
} = require('../lib/uv-explorer');

const root = path.join(__dirname, '..');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');

function section(source, start, end) {
  const from = source.indexOf(start);
  const to = source.indexOf(end, from + start.length);
  assert.ok(from >= 0, `missing start marker: ${start}`);
  assert.ok(to > from, `missing end marker: ${end}`);
  return source.slice(from, to);
}

test('UV Explorer request normalization fixes one bounded page size and canonical queues', () => {
  assert.equal(UV_EXPLORER_PAGE_SIZE, 36);
  assert.deepEqual(UV_EXPLORER_QUEUE_TYPES, ['RFY', 'AI', 'AFA']);
  assert.deepEqual(normalizeUvExplorerRequest({}), {
    searchTerm: '',
    queueTypes: ['RFY', 'AI', 'AFA'],
    page: 1,
    pageSize: 36
  });
  assert.deepEqual(normalizeUvExplorerRequest({
    searchTerm: '  coffee grinder  ',
    queueTypes: ['AFA', 'RFY'],
    page: '7',
    pageSize: '36'
  }), {
    searchTerm: 'coffee grinder',
    queueTypes: ['RFY', 'AFA'],
    page: 7,
    pageSize: 36
  });
  assert.deepEqual(normalizeUvExplorerRequest({ queueTypes: 'ALL' }).queueTypes, ['RFY', 'AI', 'AFA']);

  for (const value of [0, -1, 1.5, UV_EXPLORER_MAX_PAGE + 1, 'not-a-page']) {
    assert.throws(() => normalizeUvExplorerRequest({ page: value }), UvExplorerValidationError);
  }
  for (const value of [1, 35, 37, 100]) {
    assert.throws(() => normalizeUvExplorerRequest({ pageSize: value }), /fixed at 36/);
  }
  assert.throws(() => normalizeUvExplorerRequest({ queueTypes: ['AI', 'OTHER'] }), /unsupported/);
  assert.throws(() => normalizeUvExplorerRequest({ searchTerm: 'x'.repeat(201) }), /at most 200/);
  assert.throws(() => normalizeUvExplorerRequest({ searchTerm: 'coffee\u0000' }), /control/);
});

test('UV signed search payload matches official string paging fields and excludes the token', () => {
  const payload = buildUvExplorerSignedPayload({
    searchTerm: 'mask',
    queueTypes: ['AFA'],
    page: 3,
    pageSize: 36
  }, {
    countryId: 2,
    queueId: 'queue-explore-test',
    queueName: 'My Explore'
  });
  assert.deepEqual(Object.keys(payload), [
    'pageSize',
    'page',
    'searchTerm',
    'countryId',
    'categories',
    'queueTypes',
    'queueId',
    'queueName'
  ]);
  assert.deepEqual(payload, {
    pageSize: '36',
    page: '3',
    searchTerm: 'mask',
    countryId: '2',
    categories: '',
    queueTypes: 'AFA',
    queueId: 'queue-explore-test',
    queueName: 'My Explore'
  });
  assert.equal(Object.hasOwn(payload, 'token'), false);
  assert.equal(Object.hasOwn(payload, 'supportsEnrollmentGate'), false);
  assert.throws(
    () => buildUvExplorerSignedPayload({}, {
      countryId: 2,
      queueId: 'queue-explore-test',
      queueName: ''
    }),
    /Explore queue name/
  );
});

test('UV Explorer next-page availability is inferred only from one complete bounded page', () => {
  assert.deepEqual(uvExplorerPageMetadata(1, 0), {
    page: 1,
    pageSize: 36,
    returned: 0,
    hasPrevious: false,
    hasNext: false
  });
  assert.deepEqual(uvExplorerPageMetadata(2, 35), {
    page: 2,
    pageSize: 36,
    returned: 35,
    hasPrevious: true,
    hasNext: false
  });
  assert.deepEqual(uvExplorerPageMetadata(9, 36), {
    page: 9,
    pageSize: 36,
    returned: 36,
    hasPrevious: true,
    hasNext: true
  });
  assert.throws(() => uvExplorerPageMetadata(1, 37), UvExplorerValidationError);
});

test('Explorer endpoint validates and signs exactly the explicitly requested page without looping', () => {
  const endpoint = section(server, "app.post('/api/explore'", "app.post('/api/ingest/items'");
  assert.match(endpoint, /normalizeUvExplorerRequest\(req\.body \|\| \{\}\)/);
  assert.match(endpoint, /const exploreQueue = effectiveUvExploreQueue\(\)/);
  assert.match(endpoint, /queueId:\s*exploreQueue\.id/);
  assert.match(endpoint, /queueName:\s*exploreQueue\.name/);
  assert.match(endpoint, /signUvPayload\(signedPayload, config\.token\)/);
  assert.match(endpoint, /const body = buildUvSearchRequestBody\(config\.token, signedPayload\)/);
  assert.doesNotMatch(endpoint, /config\.exploreQueueId \|\| config\.alertQueueId/);
  assert.match(endpoint, /slice\(0, UV_EXPLORER_PAGE_SIZE\)/);
  assert.match(endpoint, /uvExplorerPageMetadata\(request\.page, products\.length\)/);
  assert.equal((endpoint.match(/fetch\('https:\/\/api\.ultraviner\.com\/ultraviner\/search'/g) || []).length, 1);
  assert.doesNotMatch(endpoint, /\b(?:for|while)\s*\([^)]*page|Promise\.all|setInterval|setTimeout/);

  const setup = section(
    server,
    "app.post('/api/uv/explore-queue/setup'",
    "app.post('/api/uv/onboard'"
  );
  assert.ok(setup.indexOf('if (existing)') < setup.indexOf('if (!config.token || !config.azUser)'));
  for (const code of [
    'uv_account_incomplete',
    'uv_screen_sync_disabled',
    'uv_session_not_authenticated',
    'uv_selected_screen_missing',
    'uv_selected_screen_queue_limit'
  ]) {
    assert.match(setup, new RegExp(`code: '${code}'`));
  }
  assert.match(setup, /const queue = newUvQueue\('Explore', screen\.id/);
  assert.match(setup, /touchUvScreen\(screen\.id\)/);
  assert.match(setup, /commitUvProfileMutation\('explore-queue-created', \[screen\.id\]\)/);
  assert.doesNotMatch(setup, /getUvQueues\('Alert'\)|alertQueue|queueType\s*=\s*['"]Explore['"]/i);
  assert.doesNotMatch(setup, /ultraviner\/search|buildUvExplorerSignedPayload|signUvPayload/);

  const readiness = section(server, 'function publicUvExploreReadiness()', 'function publicUvProfile()');
  assert.match(readiness, /ready: Boolean\(queue\)/);
  assert.match(readiness, /canCreate: !queue && blockers\.length === 0/);
  assert.match(readiness, /selectedScreenQueueCount < 40/);
  assert.match(readiness, /socketOpen[\s\S]*authenticated[\s\S]*syncEnabled/);
});

test('Explorer browser state resets filters to page one and makes one request per page action', () => {
  assert.match(dashboard, /id="explorer-pagination"/);
  assert.match(dashboard, /id="explorer-results-range"/);
  assert.match(dashboard, /← Previous/);
  assert.match(dashboard, /Next →/);
  assert.match(dashboard, /no automatic multi-page fetch/i);
  assert.match(dashboard, /id="explorer-readiness"/);
  assert.match(dashboard, />Create and sync Explore queue<\/button>/);
  assert.match(dashboard, /fetch\('\/api\/uv\/explore-queue\/setup'/);
  assert.match(dashboard, /currentUvExplorerReadiness\(\)\.ready/);
  assert.match(dashboard, /No signed catalog search runs until a genuine Explore queue exists/);
  assert.match(dashboard, /\(\(explorerPage - 1\) \* EXPLORER_PAGE_SIZE\) \+ 1/);
  assert.match(dashboard, /rangeStart \+ explorerItems\.length - 1/);
  assert.match(dashboard, /oninput="executeCatalogSearch\(\{ resetPage: true \}\)"/);
  assert.match(dashboard, /onchange="executeCatalogSearch\(\{ resetPage: true \}\)"/);

  const client = section(dashboard, 'function currentExplorerCriteria()', '// Toast Helper');
  const execute = section(
    dashboard,
    'async function executeCatalogSearch(options = {})',
    '// Toast Helper'
  );
  assert.equal((execute.match(/\bfetch\s*\(/g) || []).length, 1);
  assert.match(execute, /if \(!currentUvExplorerReadiness\(\)\.ready\)[\s\S]*return;/);
  assert.match(execute, /page: requestedPage/);
  assert.match(execute, /pageSize: EXPLORER_PAGE_SIZE/);
  assert.match(execute, /criteriaChanged[\s\S]*\? 1/);
  assert.match(execute, /generation !== explorerRequestGeneration/);
  assert.doesNotMatch(execute, /Promise\.all|\b(?:for|while)\s*\([^)]*page|setInterval|setTimeout/);
  const pager = section(client, 'async function searchExplorerPage(page)', 'function renderExplorer()');
  assert.match(pager, /await executeCatalogSearch\(\{ page: targetPage \}\)/);
});

test('UV RFY/AFA watch cards expose separate click-only Amazon-PC and VHelper sources but UV AI cannot arm', () => {
  const card = section(
    dashboard,
    "function createProductCardHtml(item, cardView = 'feed')",
    'function escapeHtml(value)'
  );
  assert.match(card, /viewKey === 'uv-explorer' && \['RFY', 'AFA'\]\.includes\(q\)/);
  assert.match(card, /isWatchSeedRecord = isVhServerRecord \|\| isUvExplorerWatchRecord/);
  assert.match(card, /armAfaAiWatch\('\$\{item\.asin\}', event, '\$\{viewKey\}'\)/);
  assert.doesNotMatch(card, /isUvExplorerWatchRecord[^\n]+\['RFY', 'AI', 'AFA'\]/);

  const seedResolver = section(dashboard, 'function afaAiWatchSeedItem(asin, cardView)', 'function watchVariantChoices(item)');
  assert.match(seedResolver, /cardView === 'uv-explorer'/);
  assert.match(seedResolver, /\['RFY', 'AFA'\]\.includes/);
  assert.doesNotMatch(seedResolver, /\['RFY', 'AI', 'AFA'\]\.includes/);

  assert.match(dashboard, />🟠 Load variants from Amazon via PC</);
  assert.match(dashboard, />🔵 Load variants from VHelper</);
  const amazonLoader = section(
    dashboard,
    'async function loadAfaAiWatchVariantsFromAmazon()',
    'async function loadAfaAiWatchVariantsFromVHelper()'
  );
  assert.ok(
    amazonLoader.indexOf("pendingWatchArmView !== 'uv-explorer'") <
      amazonLoader.indexOf("fetch('/api/order-agent/variant-lookup/amazon'"),
    'UV-only guard must run before the one Amazon lookup request'
  );
  assert.equal((amazonLoader.match(/\bfetch\s*\(/g) || []).length, 1);
  assert.doesNotMatch(amazonLoader, /amazonWatchVariants\s*=\s*\[\]/, 'a failed explicit refresh must retain prior dialog-local Amazon choices');
  assert.doesNotMatch(amazonLoader, /\/api\/vh\/item-explorer\/variants|\/api\/order-agent\/jobs|\/api\/order-agent\/watches/);
  assert.match(amazonLoader, /no retry, order route, VHelper fallback, persistence, or live-feed/i);

  const vhLoader = section(
    dashboard,
    'async function loadAfaAiWatchVariantsFromVHelper()',
    'function updateAfaAiWatchVariantNote()'
  );
  assert.ok(
    vhLoader.indexOf("!['vh-rfy', 'uv-explorer'].includes(pendingWatchArmView)") <
      vhLoader.indexOf("fetch('/api/vh/item-explorer/variants'"),
    'eligible VH/UV guard must run before the one VHelper request'
  );
  assert.equal((vhLoader.match(/\bfetch\s*\(/g) || []).length, 1);
  assert.doesNotMatch(vhLoader, /vhWatchVariants\s*=\s*\[\]/, 'a failed explicit refresh must retain prior dialog-local VHelper choices');
  assert.doesNotMatch(vhLoader, /\/api\/order-agent\/variant-lookup\/amazon|\/api\/order-agent\/jobs|\/api\/order-agent\/watches/);

  const openDialog = section(
    dashboard,
    "function armAfaAiWatch(asin, event, cardView = 'vh-rfy')",
    'function closeAfaAiWatchDialog()'
  );
  assert.equal((openDialog.match(/\bfetch\s*\(/g) || []).length, 0);
  const resetState = section(
    dashboard,
    'function resetAfaAiWatchVariantLookupState()',
    'function renderAfaAiWatchVariantLookupState()'
  );
  assert.match(resetState, /vhWatchVariants\s*=\s*\[\]/);
  assert.match(resetState, /amazonWatchVariants\s*=\s*\[\]/);
  const closeDialog = section(
    dashboard,
    'function closeAfaAiWatchDialog()',
    'async function submitAfaAiWatch()'
  );
  assert.match(closeDialog, /resetAfaAiWatchVariantLookupState\(\)/);
});

test('UV display preserves bounded embedded variants and issues opaque ephemeral lookup seeds', () => {
  const formatter = section(server, 'function normalizeUvEmbeddedVariants', 'async function readBoundedUvJson');
  assert.match(formatter, /normalizeEmbeddedVariants\(source\)/);
  assert.match(formatter, /variant\.asin === parentAsin/);
  assert.match(formatter, /output\.length >= 100/);
  assert.match(formatter, /variants,/);
  assert.match(formatter, /isParentAsin/);
  assert.match(formatter, /const seedId = `uv-variant-/);
  assert.match(formatter, /UV_EXPLORER_VARIANT_SEED_TTL_MS/);
  assert.doesNotMatch(formatter, /customerId|amazonCustomerId|offerListingId/);

  const endpoint = section(server, "app.post('/api/explore'", "app.post('/api/ingest/items'");
  assert.match(endpoint, /rememberUvExplorerVariantSeed\(product, formatted\)/);
  assert.match(endpoint, /\{ \.\.\.formatted, variantLookupId \}/);
  assert.doesNotMatch(endpoint, /enrollmentGuid:|recommendationId:|customerId:/);
  const choices = section(dashboard, 'function watchVariantChoices(item)', 'function validateVhWatchVariantsPayload');
  assert.match(choices, /normalizeItemVariants\(item, 100\)/);
  assert.match(choices, /source: 'embedded'/);
  assert.match(choices, /amazonWatchVariants/);
  assert.match(choices, /vhWatchVariants/);
  assert.match(choices, /sources\.join\('\+'\)/, 'duplicate child ASINs must retain attribution to every loaded source');

  const validatorSource = section(
    dashboard,
    'function validateAmazonWatchVariantsPayload(data, expectedParentAsin)',
    'function renderAfaAiWatchVariantOptions(item, preserveSelection = true)'
  );
  const validateAmazon = Function(`"use strict"; ${validatorSource}; return validateAmazonWatchVariantsPayload;`)();
  const valid = {
    success: true,
    source: 'amazon_companion',
    parentAsin: 'B000000010',
    variants: [{
      asin: 'B000000011',
      label: 'Colour: Blue',
      dimensionEntries: [{ name: 'Colour', value: 'Blue' }],
      source: 'amazon_companion'
    }],
    discardedVariants: 0,
    persisted: false,
    mergedIntoLiveFeed: false,
    orderAttempted: false,
    automaticRetry: false,
    fallbackSourceUsed: false
  };
  assert.deepEqual(validateAmazon(valid, valid.parentAsin).variants[0], {
    asin: 'B000000011',
    label: 'Colour: Blue',
    dimensionEntries: [{ name: 'Colour', value: 'Blue' }]
  });
  assert.throws(() => validateAmazon({ ...valid, customerId: 'SECRET' }, valid.parentAsin), /invalid/i);
  assert.throws(() => validateAmazon({
    ...valid,
    variants: [{ ...valid.variants[0], source: 'vh_item_explorer_variants' }]
  }, valid.parentAsin), /unsafe/i);
});

test('Amazon lookup HTTP route is one-shot, read-only, companion-correlated, and has no ordering fallback', () => {
  const route = section(
    server,
    "app.post('/api/order-agent/variant-lookup/amazon'",
    "app.post('/api/order-agent/pair'"
  );
  assert.match(route, /uvExplorerVariantRequestIds\.has\(requestId\)/);
  assert.match(route, /resolveUvExplorerVariantSeed\(seedId, asin, now\)/);
  assert.match(route, /fetchUvExplorerEnrollmentSeed\(seed\)/);
  assert.match(route, /orderCoordinator\.requestAmazonVariantLookup/);
  assert.equal((route.match(/requestAmazonVariantLookup\s*\(/g) || []).length, 1);
  assert.match(route, /persisted: false/);
  assert.match(route, /mergedIntoLiveFeed: false/);
  assert.match(route, /orderAttempted: false/);
  assert.match(route, /automaticRetry: false/);
  assert.match(route, /fallbackSourceUsed: false/);
  assert.doesNotMatch(route, /dispatchManual|dispatchForLiveItem|armWatch|\/api\/vh\/|setTimeout|Promise\.all/);
});

test('Explorer watch arming keeps the durable fresh-event safety boundary and never posts an order job', () => {
  const arm = section(
    dashboard,
    "function armAfaAiWatch(asin, event, cardView = 'vh-rfy')",
    'async function cancelAfaAiWatch(watchId)'
  );
  assert.match(arm, /afaAiWatchSeedItem\(normalizedAsin, cardView\)/);
  assert.match(arm, /search record cannot satisfy its own watch/i);
  assert.match(arm, /separate trustworthy fresh AFA or AI live event received after/);
  assert.match(arm, /fetch\('\/api\/order-agent\/watches'/);
  assert.doesNotMatch(arm, /\/api\/order-agent\/jobs/);

  const route = section(
    server,
    "app.post('/api/order-agent/watches'",
    "app.post('/api/order-agent/watches/:watchId/cancel'"
  );
  assert.match(route, /Eligibility begins at the durable armedAtMs boundary/);
  assert.match(route, /separate later trusted live event/);
  assert.doesNotMatch(route, /allItems|\/api\/explore|dispatchForLiveItem/);
});
