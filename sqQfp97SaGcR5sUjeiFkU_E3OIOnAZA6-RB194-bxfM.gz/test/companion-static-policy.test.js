'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const read = relative => fs.readFileSync(path.join(ROOT, relative), 'utf8');

test('MV3 companion is localhost/Amazon.ca scoped and does not request cookie or extension-control powers', () => {
  const manifest = JSON.parse(read('companion/manifest.json'));
  assert.equal(manifest.manifest_version, 3);
  assert.equal(manifest.minimum_chrome_version, '120');
  assert.equal(manifest.version, '25.0.4');
  assert.deepEqual(manifest.host_permissions.sort(), [
    'http://127.0.0.1/*',
    'https://www.amazon.ca/*'
  ]);
  for (const forbidden of ['cookies', 'management', 'debugger', 'webRequestBlocking', 'nativeMessaging']) {
    assert.equal(manifest.permissions.includes(forbidden), false, forbidden);
  }
  assert.match(manifest.background.service_worker, /service-worker\.mjs$/);
  assert.match(manifest.content_security_policy.extension_pages, /ws:\/\/127\.0\.0\.1/);
});

test('Chromium service worker registers listeners synchronously without a top-level await', () => {
  const worker = read('companion/service-worker.mjs');
  assert.doesNotMatch(worker, /^await\b/m);
  assert.doesNotMatch(worker, /^(?:const|let|var)\b[^\n]*\bawait\b/m);
  assert.match(worker, /function ensureInitialized\(\)/);
  assert.match(worker, /await ensureInitialized\(\);[\s\S]*switch \(message\?\.type\)/);
  const bootstrap = worker.lastIndexOf('void ensureInitialized().catch');
  assert.ok(bootstrap > 0);
  for (const listener of [
    'chrome.runtime.onMessage.addListener',
    'chrome.tabs.onRemoved.addListener',
    'chrome.windows.onRemoved.addListener',
    'chrome.alarms.onAlarm.addListener',
    'chrome.runtime.onInstalled.addListener',
    'chrome.runtime.onStartup.addListener'
  ]) {
    assert.ok(worker.indexOf(listener) >= 0 && worker.indexOf(listener) < bootstrap, listener);
  }
});

test('checkout executor uses transient local storage, one click permit, and no blind submit retry', () => {
  const worker = read('companion/service-worker.mjs');
  const content = read('companion/checkout-content.js');
  const relay = read('companion/checkout.mjs');
  const approval = read('companion/approval.mjs');
  assert.match(worker, /ws:\/\/127\.0\.0\.1:/);
  assert.doesNotMatch(worker, /chrome\.cookies|chrome\.management|runtime\.sendMessage\([^)]*extensionId/);
  assert.match(worker, /submissionStarted = true/);
  assert.match(worker, /agent_result_ack/);
  assert.match(worker, /TERMINAL_RESULT_STATES/);
  assert.match(worker, /await amazonGetJson\(detailsUrl, referrer\);[\s\S]*await amazonVoiceOrder\(asin, recommendationId, queue\);/);
  assert.doesNotMatch(worker, /Promise\.all\(\s*\[\s*amazonGetJson\(detailsUrl/);
  assert.match(worker, /placement_unconfirmed/);
  assert.match(worker, /will not retry|will not be retried|not blindly retry/i);
  assert.match(content, /checkout_place_intent/);
  assert.match(content, /token: response\.token,[\s\S]*snapshot: intentSnapshot/);
  assert.match(content, /placeSnapshotFingerprint\(finalSnapshot\) !== placeSnapshotFingerprint\(intentSnapshot\)/);
  assert.match(content, /checkout_click_cancelled/);
  assert.match(worker, /checkout_changed_before_click/);
  assert.match(worker, /total\.amount === record\.finalTotal/);
  assert.match(worker, /decision\.action === 'place'/);
  assert.match(content, /placeAttempted = true/);
  assert.match(worker, /approvalId: randomNonce\('approval'\)/);
  assert.match(worker, /message\.approvalId !== activeJob\.approvalPrompted\.approvalId/);
  assert.match(approval, /approvalId, approved/);
  assert.doesNotMatch(content, /form\.submit\(|requestSubmit\(/);
  assert.match(relay, /form\.submit\(\)/);
  assert.equal((relay.match(/form\.submit\(\)/g) || []).length, 1);
});

test('read-only Amazon lookup is separately signed, bounded, and cannot enter the order path', () => {
  const worker = read('companion/service-worker.mjs');
  const protocol = read('companion/src/protocol.mjs');
  const handlerStart = worker.indexOf('async function handleVariantLookupRequest(rawPayload)');
  const handlerEnd = worker.indexOf('async function acceptOrderJob(rawPayload)', handlerStart);
  assert.ok(handlerStart >= 0 && handlerEnd > handlerStart);
  const handler = worker.slice(handlerStart, handlerEnd);
  assert.match(worker, /readOnlyAmazonVariantLookup: true/);
  assert.match(worker, /type === 'variant_lookup_request'/);
  assert.match(handler, /validateVariantLookupRequest\(rawPayload/);
  assert.match(handler, /recommendations\/\$\{encoded\}/);
  assert.match(handler, /amazonVariationChoices/);
  const resultStart = worker.indexOf('async function sendVariantLookupResult(request');
  assert.ok(resultStart >= 0 && resultStart < handlerStart);
  const resultSender = worker.slice(resultStart, handlerStart);
  assert.match(resultSender, /requestNonce: request\.nonce/);
  assert.match(resultSender, /persisted: false/);
  assert.match(resultSender, /orderAttempted: false/);
  assert.match(resultSender, /normalizeVariantLookupFailure\(errorCode\)/);
  assert.doesNotMatch(resultSender, /\bmessage\s*=\s*null|safeVariantResultText/);
  assert.match(worker, /const VARIANT_LOOKUP_FAILURES = Object\.freeze/);
  assert.match(handler, /variantLookupInFlight/);
  assert.match(handler, /new AbortController\(\)/);
  assert.match(handler, /request\.expiresAtMs - Date\.now\(\)/);
  assert.match(handler, /signal: lookupController\.signal/);
  assert.doesNotMatch(handler, /amazonVoiceOrder\s*\(|\/vine\/api\/voiceOrders|openCheckout\s*\(|checkout\/entry|processJob\s*\(|acceptOrderJob\s*\(/);
  assert.match(protocol, /operation !== 'read_only_amazon_variants'/);
  assert.match(protocol, /expiresAtMs - issuedAtMs > VARIANT_LOOKUP_TTL_MAX_MS/);
});

test('exact watch-variant jobs revalidate the selected child and never fall back', () => {
  const worker = read('companion/service-worker.mjs');
  const amazon = read('companion/src/amazon.mjs');
  const protocol = read('companion/src/protocol.mjs');
  assert.match(worker, /exactVariantSelection: true/);
  assert.match(worker, /variationCandidatesForPolicy\(variations, job\.policy\)/);
  assert.match(worker, /selected_variant_unavailable/);
  assert.match(protocol, /\['first_available', 'exact'\]/);
  assert.match(protocol, /selectedVariantAsin/);
  assert.match(amazon, /policy\.variantPolicy === 'exact'/);
  assert.match(amazon, /return \[selected\]/);
  assert.match(amazon, /selected_variant_unavailable/);
  assert.doesNotMatch(amazon, /policy\.variantPolicy === 'exact'[\s\S]{0,500}return available/);
});

test('authenticated browser account hash is immutable for the socket and rechecked for every job', () => {
  const worker = read('companion/service-worker.mjs');
  assert.match(worker, /let authenticatedAccountHash = null;/);
  assert.match(worker, /authenticatedAccountHash = sessionContext\.accountHash;[\s\S]*authenticated = true;/);
  assert.match(worker, /const session = await refreshAmazonSession\(\{ force: true \}\);[\s\S]*session\.accountHash !== authenticatedAccountHash/);
  assert.doesNotMatch(worker, /session\.accountHash !== previousHash/);
  assert.match(worker, /refreshed\.accountHash !== authenticatedAccountHash[\s\S]*disconnect\(\{ reconnect: true \}\)/);
  assert.match(worker, /const exactSnapshot = authenticated === true &&[\s\S]*Boolean\(authenticatedAccountHash\)/);
});

test('companion flow remains independent of UV, VHelper, and SmartViner extension internals', () => {
  const files = fs.readdirSync(path.join(ROOT, 'companion'), { recursive: true })
    .filter(name => /\.(?:js|mjs|html|json|md)$/i.test(name));
  const source = files.map(name => read(path.join('companion', name))).join('\n');
  assert.doesNotMatch(source, /chrome\.runtime\.sendMessage\s*\(\s*["'][a-p]{32}["']/i);
  assert.doesNotMatch(source, /api\.v-helper\.com|(?:www\.)?ultraviner\.com|api\.[^\s"']*smartviner/i);
  assert.doesNotMatch(source, /getLast100|get_user_stats|get_info/);
});
