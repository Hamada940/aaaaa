'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');

const root = path.join(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const dashboard = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const compose = fs.readFileSync(path.join(root, 'compose.vpn.yml'), 'utf8');
const manager = fs.readFileSync(path.join(root, 'host', 'vpn_profile_manager.py'), 'utf8');

test('dashboard exposes transactional upload, status, and rollback without profile disclosure', () => {
  assert.match(dashboard, /id="vpn-profile-file"[^>]+accept="\.ovpn/);
  assert.match(dashboard, /APPLY VPN PROFILE/);
  assert.match(dashboard, /ROLL BACK VPN/);
  assert.match(dashboard, /\/api\/vpn\/profile/);
  assert.match(dashboard, /\/api\/vpn\/rollback/);
  assert.match(server, /app\.post\('\/api\/vpn\/profile'/);
  assert.match(server, /app\.get\('\/api\/vpn\/status'/);
  assert.match(server, /app\.post\('\/api\/vpn\/rollback'/);
  assert.doesNotMatch(server, /res\.json\([^\n]*profile\.content/);
});

test('unprivileged app receives no Docker socket and uses read-only managed source mounts', () => {
  assert.doesNotMatch(compose, /docker\.sock/);
  assert.match(compose, /\.\/server\.js:\/app\/server\.js:ro/);
  assert.match(compose, /\.\/lib:\/app\/lib:ro/);
  assert.match(compose, /\.\/public:\/app\/public:ro/);
  assert.match(compose, /\.\/package\.json:\/app\/package\.json:ro/);
  assert.match(compose, /\.\/package-lock\.json:\/app\/package-lock\.json:ro/);
  assert.match(compose, /\.\/vh-direct-proxy\.js:\/proxy\/vh-direct-proxy\.js:ro/);
  assert.match(compose, /\.\/vpn-control\/inbox:\/app\/vpn-control\/inbox/);
  assert.match(compose, /\.\/vpn-control\/status:\/app\/vpn-control\/status:ro/);
  assert.match(manager, /automatic.*roll|roll.*back/is);
  assert.match(manager, /docker", "compose"/);
});

test('working Google-only DoH bootstrap settings are packaged and Cloudflare is not explicit', () => {
  assert.match(compose, /DNS_UPSTREAM_RESOLVER_TYPE:\s*"doh"/);
  assert.match(compose, /DNS_UPSTREAM_RESOLVERS:\s*"google"/);
  assert.match(compose, /HEALTH_TARGET_ADDRESSES:\s*"8\.8\.8\.8:443"/);
  assert.match(compose, /BLOCK_MALICIOUS:\s*"off"/);
  assert.doesNotMatch(compose, /DNS_UPSTREAM_RESOLVERS:[^\n]*cloudflare/i);
  assert.doesNotMatch(compose, /HEALTH_TARGET_ADDRESSES:[^\n]*1\.1\.1\.1/);
});

test('dashboard upload remains local-only through the Gluetun port binding', () => {
  assert.match(compose, /127\.0\.0\.1:3001:3001\/tcp/);
  assert.doesNotMatch(compose, /(?:^|\s)-\s*3001:3001/m);
});

test('dashboard offers OpenVPN, WireGuard conf upload, and non-persistent manual fields', () => {
  assert.match(dashboard, /value="openvpn-upload"/);
  assert.match(dashboard, /value="wireguard-upload"/);
  assert.match(dashboard, /value="wireguard-manual"/);
  assert.match(dashboard, /id="vpn-wg-private-key"[^>]+type="password"/);
  assert.match(dashboard, /id="vpn-wg-preshared-key"[^>]+type="password"/);
  assert.match(dashboard, /id="vpn-wg-addresses"/);
  assert.match(dashboard, /id="vpn-wg-endpoint-host"/);
  assert.match(dashboard, /0\.0\.0\.0\/0, ::\/0/);
  assert.match(dashboard, /finally\s*\{[\s\S]*request\.wireguard\.privateKey = ''[\s\S]*request\.content = ''[\s\S]*input\.value = ''[\s\S]*clearWireGuardSecretInputs\(wireGuardManual\)/);
  assert.doesNotMatch(dashboard, /localStorage[^\n]*(?:vpn-wg|wireguard)/i);
});

test('server canonicalizes WireGuard privately and queues protocol-aware candidates without logging keys', () => {
  assert.match(server, /validateVpnSubmission\(body\)/);
  assert.match(server, /vpnProtocol: profile\.vpnProtocol/);
  assert.match(server, /profile\.candidateExtension/);
  assert.match(server, /body\.wireguard\.privateKey = ''/);
  assert.match(server, /body\.wireguard\.presharedKey = ''/);
  assert.doesNotMatch(server, /console\.(?:log|error)\([^\n]*(?:privateKey|presharedKey)/i);
  assert.doesNotMatch(server, /profile:\s*\{[^}]*content/s);
});

test('Compose is protocol-selectable and dual-stack without putting WireGuard secrets in environment', () => {
  assert.match(compose, /env_file:\s*\n\s*- \.\/vpn\/active\.env/);
  assert.match(compose, /WIREGUARD_CONF_SECRETFILE:\s*\/run\/secrets\/wg0\.conf/);
  assert.match(compose, /\.\/vpn\/wg0\.conf:\/run\/secrets\/wg0\.conf:ro/);
  assert.match(compose, /enable_ipv6:\s*true/);
  assert.match(compose, /net\.ipv6\.conf\.all\.disable_ipv6:\s*"0"/);
  assert.match(compose, /fd30:7725:9::\/64/);
  assert.match(compose, /FIREWALL_OUTBOUND_SUBNETS:[^\n]*fd30:7725:9::\/64/);
  assert.doesNotMatch(compose, /WIREGUARD_PRIVATE_KEY\s*:/);
  assert.doesNotMatch(compose, /WIREGUARD_PRESHARED_KEY\s*:/);
  assert.doesNotMatch(compose, /VPN_TYPE:\s*openvpn/);
});

test('host manager keeps full protocol backups, interruption recovery, and dual-family WireGuard probes', () => {
  assert.match(manager, /RUNTIME_FILES\s*=\s*\(/);
  assert.match(manager, /"wireguard\.conf"/);
  assert.match(manager, /"wg0\.conf"/);
  assert.match(manager, /"active\.env"/);
  assert.match(manager, /recover_interrupted_transaction/);
  assert.match(manager, /transaction\.json/);
  assert.match(manager, /verify_wireguard_egress/);
  assert.match(manager, /ipv6\.google\.com/);
  assert.match(manager, /schemaVersion["']?: 2|"schemaVersion": 2/);
});
