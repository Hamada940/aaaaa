# UV 26.9.38 Screens, Queues, and Paired New-Account Onboarding

This implementation was derived by static inspection of the saved Ultraviner 26.9.38 runtime. No UV, Amazon, VHelper, Telegram, or other external endpoint was contacted while implementing or reviewing this feature.

## What can be generated locally

The official client generates these values locally with UUIDv4-shaped IDs:

- device ID;
- screen IDs;
- Alert queue IDs;
- RFY, AFA, AI, Search, Explore, Sweep, Bookmark, and Chat queue IDs.

Vine Drop Hub now does the same and stores the canonical profile in:

```text
data/uv_profile.json
```

The Docker deployment already persists the entire `data` directory.

The legacy `device`, `selectedScreenId`, `alertQueueId`, and `exploreQueueId` keys remain mirrored into `config.json` for compatibility, but users no longer need to enter them.

## Why a brand-new account cannot be token-only

UV's identification frame sends two independent values:

- top-level `token`: the Ultraviner bearer credential;
- `data.azUser`: SHA-256 of Amazon's raw Vine `customerId`.

The official runtime does not derive Amazon `customerId` from the UV token. It parses `customerId` from an authenticated Amazon/Vine page and persists it locally. The configured token in this installation is structurally an opaque Base64URL account token whose decoded form is UUID-shaped; it has no JWT claims or embedded Amazon identity. The token-authenticated routes visible in the saved runtime (including sessions and user settings) are not used by UV to recover `azUser`, and no token-only identity-bootstrap route appears in the bundle.

Therefore this deployment deliberately supports only paired new-account onboarding:

- the new UV token and the new Amazon account's `customerId`/SHA-256 hash must be submitted together;
- same-account token-only renewal is rejected;
- a new-account request that reuses either saved value is rejected;
- fabricating `azUser`, retaining another Amazon account's value, or claiming to derive it from the token would not match UV 26.9.38 behavior.

The dashboard supplies a local snippet that reads `customerId` inside a logged-in Vine items page and returns only its SHA-256 hash. It does not request cookies, a password, or an Amazon session export.

## Identification behavior reproduced

Every identification contains:

```text
alertQueues: every Alert queue across every screen, reduced to { id, name }
chatQueues: every Chat queue across every screen, reduced to { id, selectedChatChannel }
selectedScreenId: the locally selected screen
syncScreens: the configured screen-sync switch
```

This is intentionally not limited to queues on the selected screen.

## Screen synchronization behavior

The implementation handles the same protocol frame names used by UV 26.9.38:

- incoming `screens` summaries;
- outgoing `requestScreen`;
- incoming `screen` payloads;
- outgoing `updateScreen`;
- incoming and outgoing `deleteScreen`.

Remote and local modified dates decide which copy is requested or uploaded. A genuinely fresh generated screen is marked as a bootstrap placeholder. If remote screens exist, the first restored screen replaces that placeholder so onboarding does not create an avoidable duplicate.

No remote screen is deleted merely because a local profile is reset. Explicit screen deletion and explicit replace-mode layout import may propagate deletion while connected.

## Dashboard operations

The **Screens & Queues** page supports:

- create, select, rename, reorder, clone, and delete screens;
- create, rename, reorder, clone, convert, and delete queues;
- custom Alert queue names;
- Chat channel selection;
- Search terms;
- official `.uv` layout import using only its `screens` and `queues` fields;
- credential-free layout export;
- optional UV server screen synchronization;
- fresh local UUID generation;
- live-feed filtering by UV Alert queue routing.

When an incoming live alert has `data.queueId`, that ID is stored on the merged item. When no queue ID is present, the item is associated with every configured Alert queue, matching the official client's routing behavior.

## Explicit Explorer-queue readiness and setup

The **RFY & Catalog Explorer** requires a genuine canonical `Explore` queue. Its readiness panel shows whether that queue exists and blocks signed catalog search when it does not. An Alert UUID is never borrowed, relabelled, or used as a fallback.

**Create and sync Explore queue** is explicit and idempotent. If an Explore queue already exists it creates nothing. Otherwise the server requires all of these before mutation: the saved UV token/Amazon-hash pair, enabled screen synchronization, an open authenticated UV socket, a selected screen, and fewer than 40 queues on that screen. It then creates a fresh `Explore` UUID through `newUvQueue`, updates the selected screen's modification date, persists the normalized profile, sends the ordinary UV `updateScreen` synchronization frame, and schedules normal re-identification. It does not issue a catalog search. A failed precondition leaves the profile unchanged and returns a specific readiness reason.

## Safe new-account onboarding workflow

1. Open a logged-in Amazon Vine items page for the **new** account.
2. Use **Copy safe Amazon-ID hash extractor** and run the copied expression in that page's DevTools console.
3. Copy the returned 64-character hash into the new Amazon identity field.
4. Paste the **new account's** UV token in the adjacent required field.
5. Click **Set up new account & auto-configure** and confirm the replacement.

The server validates that both values are present and that neither reuses its saved counterpart. It stores only the Amazon hash, generates a new device and bootstrap screen/queue profile, and reconnects. If the new UV account already has remote screens, they replace the generated placeholder during normal screen synchronization. VHelper configuration, Telegram credentials, and stored feed history are retained.

R23 isolates this paired operation from ordinary Settings. The saved UV token and Amazon hash are read-only on the Settings page; only **Screens & Queues → Set up new account & auto-configure** can replace them. Ordinary settings no longer resubmit UV credentials, and blank Telegram/Discord credential inputs preserve the saved values rather than erasing them.

Same-account token-only renewal is intentionally not part of this workflow.

## Local API surface

- `GET /api/uv/profile` — includes non-secret Explorer readiness and guarded setup blockers
- `POST /api/uv/explore-queue/setup` — explicit idempotent creation/synchronization of one real Explore queue; never performs search
- `POST /api/uv/onboard` — credential changes require `{ newAccount: true, token, azUser }` with both new values
- `POST /api/uv/profile/reset`
- `POST /api/uv/screens`
- `PATCH|DELETE /api/uv/screens/:id`
- `POST /api/uv/screens/:id/select`
- `POST /api/uv/screens/:id/clone`
- `POST /api/uv/screens/:screenId/queues`
- `PATCH|DELETE /api/uv/queues/:id`
- `POST /api/uv/queues/:id/clone`
- `POST /api/uv/layout/import`

These are exposed only through the application's existing private dashboard/API boundary. The Compose file publishes that boundary on VPS loopback.
