'use strict';

const http = require('http');
const net = require('net');

const LISTEN_HOST = '127.0.0.1';
const LISTEN_PORT = Number(process.env.PORT) || 8889;
const ALLOWED_HOST = 'smartviner.com';
const ALLOWED_PORT = 443;
const CONNECT_TIMEOUT_MS = 15_000;
const MAX_AUTHORITY_BYTES = 512;

function closeWithStatus(socket, status, message) {
  if (!socket || socket.destroyed) return;
  const body = `${message}\n`;
  socket.end(`HTTP/1.1 ${status}\r\nConnection: close\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: ${Buffer.byteLength(body)}\r\n\r\n${body}`);
}

function parseAuthority(authority) {
  const value = String(authority || '').trim();
  if (!value || Buffer.byteLength(value) > MAX_AUTHORITY_BYTES) return null;
  const splitAt = value.lastIndexOf(':');
  if (splitAt <= 0) return null;
  const host = value.slice(0, splitAt).replace(/^\[|\]$/g, '').toLowerCase();
  const port = Number(value.slice(splitAt + 1));
  if (!host || !Number.isInteger(port)) return null;
  return { host, port };
}

const server = http.createServer((_request, response) => {
  response.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8', Connection: 'close' });
  response.end('CONNECT only\n');
});

server.on('connect', (request, clientSocket, head) => {
  const target = parseAuthority(request.url);
  if (!target || target.host !== ALLOWED_HOST || target.port !== ALLOWED_PORT) {
    // Never log headers or the authority: either can contain caller-supplied
    // credential-shaped material. A denial count/message is sufficient.
    console.warn('[SV Proxy] Denied a non-allowlisted CONNECT target.');
    closeWithStatus(clientSocket, '403 Forbidden', 'Destination not allowed');
    return;
  }

  // The destination is hardcoded rather than copied from request.url.
  const upstream = net.createConnection({ host: ALLOWED_HOST, port: ALLOWED_PORT });
  let established = false;
  const terminate = () => {
    if (!clientSocket.destroyed) clientSocket.destroy();
    if (!upstream.destroyed) upstream.destroy();
  };
  upstream.setTimeout(CONNECT_TIMEOUT_MS, terminate);
  clientSocket.setTimeout(0);
  upstream.once('connect', () => {
    established = true;
    upstream.setTimeout(0);
    clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (head?.length) upstream.write(head);
    upstream.pipe(clientSocket);
    clientSocket.pipe(upstream);
  });
  upstream.once('error', error => {
    console.error(`[SV Proxy] Upstream error: ${String(error?.message || 'unavailable').slice(0, 300)}`);
    if (!established) closeWithStatus(clientSocket, '502 Bad Gateway', 'SmartViner upstream unavailable');
    else terminate();
  });
  clientSocket.once('error', terminate);
  clientSocket.once('close', () => { if (!upstream.destroyed) upstream.destroy(); });
});

server.on('clientError', (_error, socket) => closeWithStatus(socket, '400 Bad Request', 'Bad request'));
server.listen(LISTEN_PORT, LISTEN_HOST, () => {
  console.log(`[SV Proxy] Listening on ${LISTEN_HOST}:${LISTEN_PORT}; only ${ALLOWED_HOST}:${ALLOWED_PORT} is permitted.`);
});

let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`[SV Proxy] ${signal}; shutting down.`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 3000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
