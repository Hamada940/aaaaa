# Deploy the Independent UV/VH Health Monitor

This update is prepared for the existing split-egress installation:

- UV continues through Gluetun and the Canadian VPN.
- VH continues through `VH_PROXY_URL=http://172.30.77.2:8888` and the destination-locked direct proxy.
- VH `last100` history remains disabled.
- Product merging and first-live-source-only notification behavior are unchanged.

The assistant has **not** deployed or live-tested this update. The commands below are for you to run on the VPS when ready.

## What changes

Replace these two application files:

- `server.js`
- `public/index.html`

The documentation and safe example configurations are optional reference updates. Do **not** replace the working VPS `config.json` with an example file.

The existing `config.json`, VPN profile, identities, runtime data, and notification credentials remain untouched. Missing health settings receive these defaults in memory and are saved by the application on startup:

```json
"enableFeedHealthAlerts": true,
"uvTokenCheckIntervalMs": 21600000,
"feedOutageGraceMs": 120000
```

## Safe manual deployment

Assume the working installation is `/home/ubuntu/vine` and the two updated files have been copied to `/home/ubuntu/feed-health-update`.

### 1. Back up the current application files

```bash
cd /home/ubuntu/vine
stamp="$(date +%Y%m%d-%H%M%S)"
mkdir -p "backups/feed-health-$stamp/public"
cp -a server.js "backups/feed-health-$stamp/server.js"
cp -a public/index.html "backups/feed-health-$stamp/public/index.html"
printf '%s\n' "$stamp" > backups/LAST_FEED_HEALTH_BACKUP
```

This does not read or print any token.

### 2. Install only the two updated files

```bash
cd /home/ubuntu/vine
sudo install -o ubuntu -g ubuntu -m 0644 \
  /home/ubuntu/feed-health-update/server.js server.js
sudo install -o ubuntu -g ubuntu -m 0644 \
  /home/ubuntu/feed-health-update/public/index.html public/index.html
```

Do not copy `config.example.json` or `config.portable.example.json` over `config.json`.

### 3. Rebuild and replace only the app container

```bash
cd /home/ubuntu/vine
sudo docker compose -f compose.vpn.yml build app
sudo docker compose -f compose.vpn.yml up -d --no-deps app
```

This leaves the VPN and VH direct-proxy containers in place. Starting the app resumes the normal configured UV and VH connections from their existing egress paths.

## Passive observation only

The following commands inspect local state; they do not call a UV, VH, or Telegram test endpoint:

```bash
cd /home/ubuntu/vine
sudo docker compose -f compose.vpn.yml ps
sudo docker compose -f compose.vpn.yml logs --since=5m app
curl -sS http://127.0.0.1:3001/api/health | python3 -m json.tool
```

Do not press **Test Token** or **Send Test Alert**, and do not call `/api/uv/test-token`, if you do not want an explicit test request.

Expected health states:

- `healthy` — the enabled source transport/session is connected/authenticated; UV diagnostics separately state whether a live alert has been observed on the current connection.
- `checking` — startup or a short reconnect is still within the grace period.
- `down` — a continuing incident is active and the dashboard warning remains visible.
- `disabled` — that source is intentionally disabled and does not affect the other source.

On a fresh health-state file, the periodic signed UV search probe is first due after the configured interval (six hours by default), not immediately at container startup. Its last-check time is persisted, so ordinary container restarts do not add extra probes. The 26.11.62 probe runs only with a real synchronized Explore queue. Search acceptance or rejection describes only that REST path; neither result proves WebSocket identification, and a REST rejection cannot tear down an authenticated socket. A real UV `invalidToken` WebSocket frame is handled immediately and remains terminal for that socket generation.

## Telegram behavior

Feed-health messages require all of the following in the existing `config.json`:

```json
"enableTelegram": true,
"enableFeedHealthAlerts": true
```

The existing `telegramToken` and `telegramChatId` must also remain configured. The application sends:

1. one problem message when a connection outage survives the grace period, or immediately for a definite UV invalid-token event;
2. no repeated messages while the same incident remains active;
3. one recovery message after that source reconnects.

UV and VH incidents are independent. A VH outage does not mark UV down, and a UV outage does not mark VH down.

## Rollback

```bash
cd /home/ubuntu/vine
stamp="$(cat backups/LAST_FEED_HEALTH_BACKUP)"
cp -a "backups/feed-health-$stamp/server.js" server.js
cp -a "backups/feed-health-$stamp/public/index.html" public/index.html
sudo docker compose -f compose.vpn.yml build app
sudo docker compose -f compose.vpn.yml up -d --no-deps app
```

The old application ignores `data/feed_health.json`, so it may safely remain in the persistent data directory after rollback.
