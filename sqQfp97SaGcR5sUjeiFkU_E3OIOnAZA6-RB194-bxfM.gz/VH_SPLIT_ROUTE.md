# Split routing: UV through the app VPN, VH through normal VPS egress

## Why the split exists

The established deployment behavior is:

- UV needs the Canadian VPN route.
- VHelper’s edge challenges that VPN exit.
- The VPS’s normal route is accepted for VH.

Therefore the app container shares Gluetun’s network namespace for all ordinary traffic, while only VH HTTPS and Socket.IO use a minimal CONNECT proxy on the Compose bridge.

## Security design

- `vh-direct-proxy.js` accepts CONNECT only.
- The only permitted destination is `api.v-helper.com:443`.
- The proxy has no published host port.
- It runs as a non-root user, read-only, with all Linux capabilities dropped.
- TLS remains end-to-end between Node and VH; the proxy cannot decrypt it.
- `VH_PROXY_URL` is applied only to VH’s Axios and Engine.IO clients.
- UV has no reference to that proxy and remains in `network_mode: "service:vpn"`.
- Live-stream history (`getLast100`) is prohibited. The explicit signed RFY `item_explorer` search uses this same destination-locked route and never enters live storage. R25's separate `item_explorer_variants` request uses it only after **Load variants from VHelper** is pressed inside Watch arming, returns only bounded child choices, and is neither retried, persisted, nor live-merged. R21's `get_user_stats` request uses it only after **Check Trial Status** is pressed, discards all non-trial response data, and is neither polled nor persisted.

## Compose topology

```text
app (shares vpn namespace)
  ├─ UV HTTPS/WebSocket ──> Gluetun ──> Canadian VPN
  └─ VH HTTPS/Socket.IO ──> 172.30.77.2:8888 CONNECT proxy ──> normal VPS route
```

The private network uses `172.30.77.0/29` by default. Gluetun’s firewall allows that one small subnet so the app can reach only the proxy bridge address; ordinary app traffic continues through the tunnel.

## Existing working VPS

Use `update-working-vps.sh`; do not replay obsolete split-route patch files. The updater preserves the working Compose/VPN/config/data material in a complete local snapshot, validates Package B without networking, overlays the current source, and restarts the whole Compose deployment.

```bash
chmod 700 update-working-vps.sh
sudo ./update-working-vps.sh /home/ubuntu/vine
```

The updater prints `sudo /home/ubuntu/vine-backups/rollback-latest.sh` plus the snapshot-specific rollback command. Rollback restores the complete prior tree and preserved prior app/proxy image tags.

## Expected local state after restart

```bash
sudo docker compose -f /home/ubuntu/vine/compose.vpn.yml ps
sudo docker compose -f /home/ubuntu/vine/compose.vpn.yml logs --since=3m vpn vh-proxy app
```

Representative lines are:

```text
[VH Proxy] Listening on 0.0.0.0:8888; only api.v-helper.com:443 is permitted.
[VH NET] Destination-locked direct proxy configured: 172.30.77.2:8888
[VH WS] Transport connected (recovered=false).
[VH WS] Application-ready (connection_info).
[UV WS] Plan: ultimate
```

The existing legacy VH identity should not produce a provisioning call or identity replacement. A new installation with no VH identity may provision a hardened synthetic UUID and best-effort FID.

## Local diagnostics

These requests target only the local dashboard API:

```bash
curl -sS http://127.0.0.1:3001/api/status | python3 -m json.tool
curl -sS http://127.0.0.1:3001/api/vh/status | python3 -m json.tool
curl -sS http://127.0.0.1:3001/api/vh/diagnostics | python3 -m json.tool
```

Healthy VH transport requires:

```json
"transportConnected": true,
"transportHealthy": true,
"historyEnabled": false
```

`applicationReady` separately records whether an application event has been observed; it is not a forced-disconnect condition. Diagnostics also report `destinationLockedProxyConfigured: true` without exposing the proxy URL.

No standalone VH/API probe is required or recommended: normal configured startup is the user-run runtime validation from the intended VPS route.
