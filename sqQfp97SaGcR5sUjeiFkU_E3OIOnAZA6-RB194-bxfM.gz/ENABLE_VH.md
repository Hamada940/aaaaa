# Enable VH with Package B in the existing VPN deployment

Package B keeps the established dual-feed policy:

- first genuine live UV/VH source creates the merged card and notifies;
- the second live source silently adds its timestamp and lead comparison;
- enrichment never creates a live card or notification;
- every VH `getLast100` request is prohibited;
- the separate RFY Server Explorer may send an explicit signed `item_explorer` search only after Search/pagination, using the saved identity without mutation;
- **Load variants from VHelper** may send one signed `item_explorer_variants` request only after that separate button is pressed inside **Watch for AFA/AI**; it has no automatic trigger, retry, fallback source, persistence, or live-store merge;
- **Check Trial Status** may send signed `get_user_stats` only after that button is pressed; it displays allowlisted trial fields, discards identity/device/statistics/payment data, and never polls or saves the reply;
- all three signed reads share one in-flight request and VHelper cooldown;
- UV remains inside the app-only Canadian Gluetun route;
- VH remains on the normal VPS route through the destination-locked CONNECT proxy.

It also preserves the saved synthetic CID/UUID without automatic replacement and adds official-client transport health, supplemental application evidence, same-Socket recovery, watchdogs, optional broadcast sync, denial/error handling, audited enrichment events, redacted diagnostics, and hardened future generated identities.

## Existing working VPS

Use the transactional in-place updater instead of old patch files:

```bash
chmod 700 update-working-vps.sh
sudo ./update-working-vps.sh /home/ubuntu/vine
```

The updater validates offline before touching the running tree, stops Compose only after validation, creates a complete private local snapshot, installs the release, and restarts all existing Compose services. It prints the stable rollback command `sudo /home/ubuntu/vine-backups/rollback-latest.sh` and a snapshot-specific command. See `PACKAGE_B_IMPLEMENTATION.md`.

## Enable or re-enable VH

From the dashboard, select **Enable VHelper (VH)** and save, or use the local API:

```bash
curl -X POST http://127.0.0.1:3001/api/vh/enable
```

A re-enable action also clears a latched server denial so one controlled retry can occur. It does not rotate the identity.

## Check readiness

```bash
curl -sS http://127.0.0.1:3001/api/vh/status | python3 -m json.tool
curl -sS http://127.0.0.1:3001/api/vh/diagnostics | python3 -m json.tool
```

A connected healthy transport reports:

```json
"transportConnected": true,
"transportHealthy": true
```

`applicationReady: true` means a VH application event has also been observed. It is useful supplemental evidence, but—matching the freshly audited official 4.7.4 client—it is not required to keep a healthy Socket.IO transport connected. The same diagnostics response exposes `protocolVersions.liveIdentity` as `4.7.4`, `auditedBuild` as `3637`, and separate `itemExplorer`, `itemExplorerVariants`, and `trialStatus` pins; the dashboard renders each contract separately.

A legacy working identity should report:

```json
"identityMode": "legacy-synthetic",
"legacyPreserved": true
```

Its blank FID remains a labelled compatibility state and is not automatically changed.

## On-demand Watch variants

Open a VH RFY Server result's **Watch for AFA/AI** dialog. Embedded child choices appear without another request and **Any currently available variant** remains selected. Only pressing **Load variants from VHelper** runs one official-extension-contract request. A visible failure is not retried; loaded choices disappear when the dialog closes and never enter manual **Order on PC** or the live item store. Arming an exact child retains only that selected child under the existing no-substitution watch policy.

## On-demand trial status

Open **VH RFY Server → Check Trial Status**. Opening the tab does nothing; one request is made only when the button is pressed. The card shows VHelper's authoritative active/inactive flag, exact Unix/ISO expiry when reported, calculated days remaining, and a valid numeric membership tier when present. The result is kept only in that browser page. It never adopts `resolved_uuid`, lists linked devices, exposes contribution/payment details, changes identity, retries, or extends/resets entitlement.

## Explicit new generated identity

Do **not** use this for routine reconnects. The dashboard action **Generate New Synthetic VH Identity** abandons continuity with the current UUID. It shows one standard Continue/Cancel warning; no phrase must be typed, and the API does not require a phrase field.

The result is still an isolated synthetic identity, not official Amazon/VH account linking. Package B then uses a fresh P-256 key and attempts stable fingerprint/FID registration, with a bounded blank-FID fallback if that registration is not accepted.
