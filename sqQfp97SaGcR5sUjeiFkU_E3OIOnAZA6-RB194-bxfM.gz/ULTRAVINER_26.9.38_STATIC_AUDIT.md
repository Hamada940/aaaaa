# Ultraviner 26.9.38 full-file static compatibility audit

Audit date: 2026-09-24 (America/Toronto)  
Method boundary: offline/static only. No UV, VH, Amazon, Telegram, Discord, VPN, or authenticated endpoint was invoked, and no service was started.

## Live-identification compatibility addendum: runtime 26.11.36 / launcher 1.0.20

Release `r25-uv-websocket-compat-hotfix-20260910-11` added the narrow static refresh preserved unchanged by `r25-uv-explorer-pagination-watch-hotfix-20260910-12`, `r25-uv-explorer-variant-lookups-hotfix-20260910-13`, `r25-delayed-price-auto-order-hotfix-20260910-14`, and `r25-order-button-click-reliability-hotfix-20260910-15`. The two current public artifacts were downloaded from the documented launcher/runtime distribution URLs, stored outside the release payload, hashed in full, and syntax-parsed in full with Node. Neither artifact was executed, and no authenticated or private endpoint was called.

| Input | Bytes | SHA-256 | Result |
|---|---:|---|---|
| Public userscript launcher 1.0.20 | 4,901 | `e62b534636c11d522e068591d1869385ec8b118cbc3b95bf314934ceb899441b` | Complete loader; advertises launcher 1.0.20 |
| Public runtime 26.11.36 | 2,458,733 | `f0a55b1cb698b918552efbdc371231cc23072949cf4941fc495f8cefce269e15` | Complete runtime; advertises application 26.11.36 |

Direct inspection of the complete current identification section confirms the same top-level `type`, `token`, and `data` layout. The data fields remain:

`device`, `azUser`, `userAgent`, `height`, `width`, `isTouchDevice`, `syncBookmarks`, `syncScreens`, `version`, `domain`, `launcherVersion`, `launcherType`, `launcherPlatform`, `displayName`, `selectedScreenId`, `alertQueues`, `chatQueues`, `themeName`, `language`, `tier`, and `isFirefox`.

The current runtime still maps every Alert queue to `{ id, name }`, every Chat queue to `{ id, selectedChatChannel }`, hashes the separately obtained Amazon customer ID with SHA-256, uses `wss://api.ultraviner.com/`, and delays identification by 500 ms. No saved token, Amazon hash, device, screen, or queue migration is implied.

Authentication-state inspection found an important semantic boundary: the official client deliberately performs no authentication action for `connected`; it marks its authenticated state only on a `plan` frame and handles `invalidToken` as an account rejection. Vine Drop Hub therefore no longer treats `connected` as success, requires a non-empty plan or genuine live frame, and makes `invalidToken` terminal for that socket generation. This also prevents an already queued empty plan from replacing the explicit rejection while a graceful close is pending.

The adopted compatibility change is limited to advertising runtime `26.11.36`, launcher `1.0.20`, and enforcing those authentication-state semantics. The historical full 26.9.11→26.9.38 protocol/category/product audit below remains the baseline for all other implemented behavior.

### Static variation-retrieval finding used by release `-13`

Direct inspection of the saved complete 26.11.36 runtime also distinguishes UV product hydration from Amazon variation retrieval. The official client first obtains bounded UV deep-link authorization from `ultraviner/productDeepLink?asin=…`, signs `{ asin, type }`, and hydrates `ultraviner/product?asin=…&auth=…&type=…`. When a parent needs variation choices, it reconstructs the Vine recommendation identifier and reads `https://www.amazon.ca/vine/api/recommendations/{recommendationId}` in the authenticated browser session. The response's `result.variations` entries contain child `asin` and `dimensions` values. No separate UV variants endpoint was inferred or invented.

Release `-13` mirrors only that separation: the VPS may use the existing signed UV product-hydration shape transiently to recover enrollment metadata for a current opaque Explorer seed, while companion 25.0.4 performs the Amazon recommendation GET locally. The server/browser return path allowlists child ASINs and bounded non-sensitive dimensions only. UV authorization, token, recommendation/enrollment metadata, Amazon customer/account data, cookies, offer data, and signatures are not returned to the dashboard or persisted. This conclusion remains static/offline: no authenticated UV or Amazon endpoint was called during the audit or release validation.

## Inputs and complete-ingestion evidence

The supplied launcher URL was saved exactly and compared byte-for-byte with the previously preserved launcher.

| Input | Bytes | SHA-256 | Result |
|---|---:|---|---|
| `ultraviner.user.20260924.js` | 4,892 | `73f8d0b9da146b54da6e575e5be6ee159c5d12a331bf438e6696d2b2759b9f81` | Launcher 1.0.19; byte-identical to the prior launcher |
| Prior runtime 26.9.11 | 2,333,628 | `47ecc96e6be9a111707d5c4486cb7dedf151e05a5c8d12208ba814a9ad4b65f6` | Comparison baseline |
| Current runtime 26.9.38 | 2,324,929 | `170dfa363125f6f847ac7849f5dba3ab875e64dfee4e7b89dd8bf1f2b8609643` | New official runtime |

Both complete runtime files were parsed as ECMAScript with Acorn, not sampled or truncated. Parsing consumed the full files with zero syntax errors: 450,618 AST nodes for 26.9.11 and 449,643 for 26.9.38. Both were also formatted in full and compared (2,425 textual diff hunks; 10,830 formatted lines added and 11,159 removed). String-literal and property-identifier inventories were compared across the full ASTs, followed by direct inspection of every protocol-, identity-, screen-, queue-, category-, search-, alert-, and product-normalization section relevant to this application.

The 145-line launcher was read in full. Its behavior is unchanged: it adds an Ultraviner link on ordinary Vine pages, handles magnetic `asin=` links, stops/replaces the page for Ultraviner mode, caches the downloaded runtime in GM storage, purges incompatible pre-2.17 runtime content, and fetches `/dist/latest/ultraviner.js` with a cache-busting timestamp.

## Protocol inventory comparison

### Incoming WebSocket frame types

Both versions define 32 incoming frame types. One name changed:

- removed: `patreon`
- added: `subscription`

All other incoming names are unchanged:

`connected`, `connectionSummary`, `plan`, `status`, `pageData`, `invalidToken`, `alerts`, `alertFromRedrop`, `alertFromEtv`, `alertFromCategory`, `alertFromExternalData`, `alertFromBrenda`, `alertDetailsFromBrenda`, `alertDetail`, `categoryList`, `subcategoryList`, `screens`, `screen`, `deleteScreen`, `speedometer`, `version`, `electronVersion`, `refreshWebhooks`, `chatMessage`, `chatMessageHistory`, `chatChannels`, `chatMessageDeleted`, `chatMessageEdited`, `chatMessageRejected`, `hiveLoad`, and `promotion`.

The new `subscription` payload updates account metadata for Patreon plan, Paddle customer, Paddle subscription, Paddle plan, and beta-tester plan. Vine Drop Hub has no payment/subscription UI, so it safely classifies both `subscription` and the legacy `patreon` frame as non-product housekeeping.

### Outgoing WebSocket frame types

The outgoing set increased from 18 to 19. The sole addition is:

- `orderInProgress`

The official runtime emits it only while its own checkout path is proceeding to checkout, with the product queue/type, ASIN, and hashtag count. Vine Drop Hub is a passive alert receiver that opens Vine links and does not place orders or embed checkout, so it deliberately does not emit this frame.

All existing outgoing names remain unchanged: `identification`, `pageData`, `productData`, `orderData`, `addHiddenProducts`, `removeHiddenProducts`, `shareRfySummary`, `shareLoot`, `ping`, `updateScreen`, `requestScreen`, `deleteScreen`, `sendChatMessage`, `requestChatHistory`, `telemetry`, `log`, `dismissPromotion`, and `openPromotion`.

### Identification, connection, and device fields

The identification shape is unchanged. It still sends the top-level token and these data fields:

`device`, `azUser`, `userAgent`, `height`, `width`, `isTouchDevice`, `syncBookmarks`, `syncScreens`, `version`, `domain`, `launcherVersion`, `launcherType`, `launcherPlatform`, `displayName`, `selectedScreenId`, `alertQueues`, `chatQueues`, `themeName`, `language`, `tier`, and `isFirefox`.

The `azUser` value is still SHA-256 of the separately obtained Amazon Vine customer ID. No token-only Amazon-identity bootstrap appeared. The device ID remains locally generated/persisted. WebSocket URL, ping filtering/cadence, delayed identification, and identification-first send ordering are unchanged.

Historical adopted change: that release identified as runtime `26.9.38` while retaining launcher `1.0.19` and all established Package B identity/profile values. The addendum above supersedes only those two advertised compatibility versions and authentication-state handling.

### Screens and queues

The nine queue types are unchanged:

`RFY`, `AFA`, `AI`, `Search`, `Sweep`, `Bookmark`, `Alert`, `Explore`, and `Chat`.

The screen protocol and payload behavior are unchanged:

- summary reconciliation through `screens`;
- remote fetch through `requestScreen` with `screen_id`;
- full screen/queue receipt through `screen`;
- upload through `updateScreen` with `modified_date`, `screen_id`, and `{ screen, queues }` payload;
- incoming/outgoing `deleteScreen` with `screen_id`;
- device/provider-state filtering for synchronized screen updates.

No migration of existing device, screen, queue, Alert-name, or Chat-channel state is required.

### Alert routing and detail enrichment

The live alert set and routing logic are unchanged. A frame with `data.queueId` goes only to the matching Alert queue; a frame without it is delivered to every Alert queue. `alertDetail` and `pageData` remain enrichment paths rather than new live-drop paths. Brenda/redrop feature switches and the five-minute existing-alert suppression behavior are unchanged.

This preserves Package B’s one-card merge, silent second source, first-live notification, and race-clock semantics.

### Search request signing

The `/ultraviner/search` URL, POST shape, bearer authorization, canonical body fields, and HMAC-SHA-256 signing process are unchanged. Variable names changed in the compiled bundle, but the key/message operands and output are semantically identical.

## Product-model change adopted

Runtime 26.9.38 adds `ordersInProgress` to product hydration and displays the count on official product cards. This is fed by the new checkout-progress protocol and is a read-only demand signal.

Vine Drop Hub now:

- accepts camel-case `ordersInProgress` and compatibility alias `orders_in_progress` from UV;
- normalizes it to a non-negative integer;
- prevents VH data from overwriting the last UV value;
- retains it through live merges and `alertDetail`/`pageData` enrichment;
- shows a compact `⏳ N ordering` card badge and a Product Details row only when the count is positive.

It does not notify again, alter priority, reorder cards, place an order, or send `orderInProgress`.

## Category comparison

The category enum still contains exactly 90 unique IDs, including `-1` plus the same IDs through `1764`. English names and emoji mappings are unchanged. The canonical local catalog remains:

- 90 records / 90 unique IDs;
- canonical JSON SHA-256 `8758d5b90a10eece38986fec6fa21441e6d8ab2fc70c936c8f91196a430eea19`.

No saved priority-category migration is needed.

## Other runtime changes intentionally not imported

The remaining meaningful runtime changes are internal to the official full browser client:

- Paddle subscription purchase/management and richer subscription account fields;
- remote plan-data loading instead of the previous hard-coded feature/pricing list;
- checkout progress instrumentation, form/pagehide handling, 3DS/iframe waits, and additional checkout diagnostics;
- Amazon Business purchase-program/purchase-ID handling;
- official product-card visual changes and dependency/build churn.

These are not compatible additions for a passive server-side alert dashboard. Importing payment, checkout, order automation, or Amazon DOM behavior would expand scope and violate the established passive Package B boundary. They were therefore reviewed but deliberately excluded.

## Integration decisions

Adopted:

1. Runtime version `26.9.38` in identification and diagnostics.
2. Incoming `subscription` as housekeeping, while retaining legacy `patreon` compatibility.
3. Read-only `ordersInProgress` capture, persistence, enrichment, and display.
4. Documentation/tests updated to the 26.9.38 baseline.

Preserved unchanged:

- UV app-only VPN route;
- VH destination-locked direct proxy;
- passive dual-feed merge and silent second source;
- no VH `getLast100` in any path;
- Amazon identity pairing/onboarding rules;
- existing UV device/screens/queues and synthetic VH identity;
- dashboard loopback/SSH-only exposure;
- category priority and all stored-item semantics except the additive optional count.

Deliberately excluded:

- payment/subscription UI;
- checkout/order automation and outbound `orderInProgress`;
- Amazon DOM automation;
- any live compatibility probe from the assistant environment.

---

## 2026-10-01 notification/Brenda taxonomy addendum

The complete follow-up audit below resolves the distinction between Vine queue, alert origin, event subtype, local Alert queue, feed provenance, and output channel.

# Ultraviner 26.9.38 — product-alert, notification, and Brenda audit

**Audit date:** 2026-10-01 (America/Toronto)  
**Input:** `/home/user/ultraviner/ultraviner.latest.20260924.pretty.js`  
**Method:** complete offline/static inspection of the saved official 26.9.38 browser runtime. No Ultraviner, VHelper, Amazon, Discord, Telegram, webhook, VPN, or other live endpoint was contacted, and no official client code was executed.

## Bottom line

**Brenda is a Discord bot / alert origin, not a fourth Amazon Vine queue.**

Ultraviner models these as independent dimensions:

1. **Vine queue type:** RFY, AFA, or AI, derived from the product's official recommendation `type`.
2. **Alert origin:** `ultraviner`, `brenda`, or `redrop`.
3. **Inbound WebSocket event type:** for example `alerts`, `alertFromBrenda`, or `alertFromEtv`.
4. **Local UV Alert queue destination:** the configured Alert queue ID(s) that receive the product.
5. **Transport/feed observed by Vine Drop Hub:** UV, VH, or both.
6. **Output action/channel:** alert card, rule sound, UV inbox/toast, outbound Discord share, or generic webhook.

A product can therefore be, for example:

- event: `alertFromBrenda`
- alert origin: **Brenda**
- official product type: `VENDOR_VINE_FOR_ALL`
- Vine queue: **AFA**
- local destination: one or more configured UV **Alert** queues
- transport into Vine Drop Hub: **UV**

Calling that product's queue `Discord/Brenda` loses its real AFA classification and contradicts UV's own model.

## 1. Canonical alert origins

The runtime defines an origin enum at lines **24087–24099**:

| Stored origin | Display label | Meaning in this runtime |
|---|---|---|
| `ultraviner` | Ultraviner | UV's own alert origin |
| `brenda` | Brenda | Alert originating from Brenda/Discord |
| `redrop` | Redrop | Reappearance/redrop alert origin |
| `myself` | Myself | Used for locally added bookmarks; not offered as an Alert Source rule option |

UV's Alert Rule editor separately names the field **“Alert Source”** and offers only Ultraviner, Brenda, and Redrop (lines **51552–51629**, **51694–51706**, and **52020–52034**). This is direct evidence that Brenda and Redrop are provenance values, not queue values.

`Myself` is assigned when a local bookmark is created (around line **49447**). It is not one of the product-alert source choices.

## 2. Canonical Vine queue types

The official product/recommendation mapping is independent of origin (lines **23905–23936**):

| Official product `type` | UV queue |
|---|---|
| `VENDOR_TARGETED` | RFY |
| `VENDOR_VINE_FOR_ALL` | AFA |
| `VINE_FOR_ALL` | AI |
| `ALL_ITEMS` | AI |
| `SEARCH` | Search |

The rule editor calls this separate field **“Queue Type”** (lines **51530–51579**) and builds queue choices independently from Alert Source (lines **51939–52034**).

UV's Alert queue filter also evaluates product `type` through the queue mapping while category filtering is a separate predicate (lines **24824–24862**). Nothing in that filter turns Brenda into a queue.

### Terminology trap: three different uses of “queue”

- **RFY/AFA/AI** — Amazon Vine product location/type.
- **Alert** — a UV dashboard queue class that displays incoming alerts.
- **`data.queueId`** — a particular user-configured local Alert queue destination.

Brenda is none of these queue types. It is alert origin/provenance.

## 3. What Brenda is

The English runtime text is explicit (lines **34109–34121** and **34208–34214**):

- setting name: **“Alerts from Brenda (discord bot)”**;
- tooltip: receive product alerts when users send products to the Discord group;
- Discord integration: receive product alerts from Discord users directly in the Alert queue and share products/orders to the server.

Operationally, the saved client shows two Brenda directions:

### Inbound Brenda alerts

When enabled, the alert handler accepts:

- `alertFromBrenda`
- `alertDetailsFromBrenda`

Both are added to the live-alert event set (lines **96103–96118**). Product payloads retain `origin`, and cards display a Discord/Brenda icon when `origin === brenda` (lines **58134**, **58764–58767**).

`alertDetailsFromBrenda` is in the live-event set, not the always-enrichment-only set. In the usual duplicate sequence, its matching ASIN follows UV's existing-item enrichment path; if no matching recent/pending ASIN exists, the handler can admit it as a live product.

### Outbound Discord product sharing through Brenda

The product-details Share button is a distinct outbound action. It submits token, domain/tab, ASIN, ETV, options, colours, sizes, and limited status to UV's `/ultraviner/product/discord` route (around **58556–58655**). The button:

- has a ten-second client cooldown;
- reports unauthorized/too-fast errors;
- is disabled with **“Brenda alerted this product already”** when `brenda_status` is `blocked`.

That sharing action does not change the product's RFY/AFA/AI queue. It sends the product outward; Brenda-origin events are the inbound side.

### Availability and entitlement

- `hasBrenda` is true for **US, UK, CA, and JP** (lines **23854–23856**).
- Effective `enableAlertsFromBrenda` and `enableAlertsFromRedrops` require **Turbo or Ultimate** (lines **17115–17131**).
- Effective `enableDiscordIntegration` requires an account whose login type is Discord (lines **17108–17115**), and the product Share button is additionally gated by country capability and that setting (around **58821–59056**).
- The Alerts settings toggles and the Discord Integration toggle are distinct settings (around **69488–69525** and **69798–69815**).

Thus “receive Brenda alerts” and “show/use outbound Discord integration” are related but separate controls in the client.

## 4. Redrops

Redrop is another canonical alert origin, not Discord and not a Vine queue.

The English tooltip says Redrops are alerts when **previously available products return to the system** (lines **34115–34117**). The client conditionally accepts `alertFromRedrop` when `enableAlertsFromRedrops` is effective (lines **96103–96118**), and products with `origin === redrop` receive a separate redrop icon (lines **58764–58767**).

Like Brenda, Redrop alerts still carry a normal product `type`, so their Vine queue remains RFY, AFA, or AI.

## 5. Complete inbound product-alert event taxonomy

The incoming protocol enum lists these product-related names at lines **2706–2719**:

| Event | Client treatment | Canonical origin? |
|---|---|---|
| `alerts` | Baseline live-alert pipeline | Normally Ultraviner/payload `origin` |
| `alertFromEtv` | Baseline live-alert pipeline | No separate origin enum value |
| `alertFromCategory` | Baseline live-alert pipeline | No separate origin enum value |
| `alertFromExternalData` | Baseline live-alert pipeline | No separate origin enum value |
| `alertFromBrenda` | Optional live-alert pipeline | Brenda |
| `alertDetailsFromBrenda` | Optional live-alert pipeline; duplicate normally enriches | Brenda |
| `alertFromRedrop` | Optional live-alert pipeline | Redrop |
| `alertDetail` | Existing-product enrichment only | Preserve payload/existing origin |
| `pageData` | Existing-product enrichment only | Preserve payload/existing origin |

The active live set is assembled at **96103–96118**. `alertDetail` and `pageData` are in a separate enrichment set at **96120** and are dispatched only to the enrichment callback at **96391–96395**.

### Important limit of static client evidence

The browser bundle receives these frames; it does not contain the UV server logic that decides exactly when `alertFromEtv`, `alertFromCategory`, or `alertFromExternalData` is generated. Their names and client treatment are visible, but inventing more specific server-side semantics would go beyond the saved evidence.

What is provable is that those three names are **transport/trigger subtypes**, not canonical Alert Source values: UV's origin enum and Alert Source rule options remain Ultraviner/Brenda/Redrop.

## 6. Routing, duplicate handling, and local Alert queues

For every accepted live event, UV loops over each local queue whose queue class is `Alert` (around **96097–96131**):

- if the frame has `data.queueId`, only the matching local Alert queue receives it;
- without `data.queueId`, every local Alert queue receives it.

This local queue ID is not the product's RFY/AFA/AI type.

The handler checks dismissed, displayed/filtered, and pending products before inserting. Displayed/filtered duplicates are suppressed as new alerts for five minutes; duplicate products are routed to the enrichment callback instead (around **96291–96363**). New products enter `pendingAlerts`, then each Alert queue applies its own ETV, queue-type, and category filters before release/display (around **55390–55464**).

## 7. Rule sounds

Sound is an output action attached to matching rules; it is not an alert source.

Evidence:

- products can carry `sound`, `volume`, `soundOrder`, and `playOnce` during hydration (around **24031–24051**);
- the sound provider uses HTML Audio and a per-sound cooldown (`soundCooldown`, default 5 seconds) (lines **50843–50880**, default near **19878**);
- an Alert queue plays the product's rule sound when the pending alert is released and passes filters, unless that queue is muted (around **55431–55459**);
- ordinary refreshed product queues can also play unique matched rule sounds for visible/non-hidden products (around **53660–53697**);
- an autoplay failure displays a click/touch-to-resume overlay (around **50882–50900**).

UV also plays click/activation feedback and lets users preview sounds. Those are UI feedback, not new product-alert origins.

## 8. UV inbox and toast notifications

UV's alert-product cards are separate from its Inbox/Toast system.

The internal notification enum (lines **24568–24579**) contains:

- `OrderSuccess`
- `OrderFailure`
- `RocketOrderSuccess`
- `RocketOrderFailure`
- `ProductView`
- `Error`
- `Message`
- `PersistentMessage`
- `BackupReminder`

### Toasts

`addNotification` writes these to the toast store:

- normal and Rocket order success/failure;
- Error;
- Message;
- PersistentMessage;
- BackupReminder.

ProductView is not a toast. Non-persistent old toasts are cleared on provider startup. Ordinary toasts use `toastDuration`; errors remain until dismissed unless `autoDismissAllErrors` is enabled; PersistentMessage never auto-dismisses (lines **24591–24649**, **47550–47594**).

### Inbox

The same call writes to the persistent Inbox store unless:

- ProductView notifications are disabled;
- normal OrderFailure notifications are disabled; or
- normal OrderSuccess notifications are disabled.

Other types pass those three literal filters; the Inbox retains at most 1,000 records (lines **24636–24666**). Product-view events are emitted when a product is opened (around **53598**). Order result events are emitted by the checkout/order path (around **52315–52372**).

### Not operating-system push notifications

The saved runtime contains no use of the browser `Notification` constructor, notification permission request, service-worker `showNotification`, or equivalent OS push API. These are UV's in-page IndexedDB-backed Inbox and DOM toast surfaces.

A separate full-screen modal alert provider exists for checkout problems such as missing default address, CAPTCHA, age verification, sign-in, or total over the configured limit (around **96473–96502** and **97570–98030**). It is also not a product-alert origin.

## 9. Discord sharing versus Brenda alerts

UV exposes at least three outbound sharing paths:

1. **Single product to Discord/Brenda** — HTTP request from product details (around **58556–58655**).
2. **RFY summary** — outgoing WebSocket `shareRfySummary` with selected products, optional comment, and theme (around **54720–54769**).
3. **Recent order/loot share** — outgoing WebSocket `shareLoot` with selected orders, queue type, optional ETV/comment, and theme (around **74960–75045**).

These are user-initiated outbound share operations. They are not the same as:

- the inbound `alertFromBrenda` event;
- the product's Vine queue;
- UV's generic webhook engine;
- UV's in-page Inbox/toasts; or
- a rule sound.

Discord OAuth/account login handling near **96520–96830** is authentication for a Discord-linked UV account. It is likewise separate from the `origin: brenda` value on a product.

## 10. Generic webhooks

UV defines three webhook types at lines **50910–50920**:

| Webhook type | Trigger |
|---|---|
| `rule` | New product activates one of the configured rules |
| `order` | An order succeeds |
| `order-history` | An Orders page is loaded/navigated |

The Webhooks UI says they are processed locally in the UV client (lines **90848–90855**). A webhook can use GET/POST/PUT/DELETE/PATCH, custom URL/headers/body, substitutions, and configured batching (around **90541–90818**). Effective webhook settings require Ultimate (lines **17159–17179**).

Rule webhooks only include matched, non-hidden products and deduplicate by webhook/ASIN using a local cache capped at 1,000 records (around **51166–51283**). The Alert handler explicitly excludes the initial `alertFromBrenda` frame from its rule-webhook call (lines **96365–96370**); subsequent duplicate/detail handling normally enriches rather than creating a second webhook-triggering new product.

A user may configure a generic webhook URL that happens to belong to Discord, but that does not make UV webhooks synonymous with Brenda or with the built-in Discord integration.

## 11. Correct dashboard data model

The dashboard should preserve these independently:

| Dashboard field | Correct values/example |
|---|---|
| `queue` | `RFY`, `AFA`, or `AI` |
| `origin` / `alertOrigin` | `ultraviner`, `brenda`, or `redrop` |
| `alertOrigins` | union of evidenced origins when same-ASIN observations merge |
| `sources` | `UV`, `VH`, or both (transport/feed provenance) |
| `uvAlertQueueIds` | local configured UV Alert queue destination IDs |
| event provenance | `alertFromBrenda`, `alertFromRedrop`, etc., where retained |

### Merge rule

A later generic UV enrichment frame that omits `origin` must not erase an already evidenced Brenda or Redrop origin. Explicit payload origin or named Brenda/Redrop events can add/update origin provenance. RFY/AFA/AI continues to use evidence-ranked queue merging independently.

### Legacy migration rule

For an old card whose queue is literally `Discord/Brenda`:

1. retain/add Brenda as alert origin;
2. reclassify queue from already persisted official recommendation metadata (`type` / `recommendationType`) or unambiguous per-queue order counts;
3. if no queue evidence exists, use the existing low-confidence AI fallback rather than pretending Brenda is a queue;
4. do not fabricate missing old Redrop origins where no retained evidence exists.

## 12. Decision for Vine Drop Hub R15

The prior R15 v3 assertion that `alertFromBrenda` should classify the **queue** as `Discord/Brenda` is wrong and must not be retained.

The corrected successor keeps:

- `VENDOR_TARGETED` → RFY;
- `VENDOR_VINE_FOR_ALL` → AFA;
- `VINE_FOR_ALL` / `ALL_ITEMS` → AI;
- Brenda/Redrop/Ultraviner as separate alert-origin provenance;
- UV/VH as separate feed provenance;
- custom UV Alert queue IDs as separate routing provenance.

This is not merely a display rename. It prevents Brenda events from overriding authoritative product queue metadata and makes cards, filters, Product Details, API output/filtering, Telegram captions, and configured Discord notifications able to represent both dimensions.

## Offline boundary and confidence

All conclusions above are based on directly inspected static client code. The audit did not test the UV server, Discord bot, webhook targets, or account entitlements live. Therefore:

- client-side enums, gating, routing, rendering, and outbound call shapes are high-confidence;
- the exact server-side generation criteria for ETV/category/external-data events are intentionally left unspecified;
- no claim is made about current live server policy beyond what runtime 26.9.38 encodes.
