# VHelper Package B implementation

**Original Package B date:** 2026-09-11  
**UV compatibility refresh:** 2026-09-24, runtime 26.9.38  
**Current authenticated protocol reference:** official VHelper 4.7.4 / build 3637 CRX3, statically authenticated and audited 2026-09-10  
**Historical live-transport reference:** official VHelper 4.5.2 / build 3483 static audit (connection semantics rechecked unchanged in 4.7.4)  
**Item Explorer protocol reference:** official signed VHelper 4.7.4 static audit, 2026-09-10  
**Trial-status protocol reference:** official signed VHelper 4.7.4 `get_user_stats` handling, statically audited 2026-09-10  
**Watch variants protocol reference:** official VHelper 4.7.4 `.load-variants` click handler and `item_explorer_variants` rendering, statically audited 2026-09-10  
**Historical CRX revalidation:** 2026-10-03 user-supplied 4.5.2 CRX was byte-identical to the earlier live-transport package  
**Runtime boundary:** implemented and tested offline only; no UV, VH, Amazon, Telegram, Discord, or VPN endpoint was contacted during implementation.

## Preserved behavior

- The saved legacy synthetic VH `customerId`/CID and UUID are loaded exactly as before.
- A legacy record is classified as `legacy-synthetic`, retains the original fixed compatibility key and `cat-dashboard-v9` device name, and is never automatically migrated, rotated, fingerprint-registered, or linked to an account.
- Existing UV account/profile, multiple screens, all custom queues, VHelper settings, item history, race clocks, notifications, proxy/VPN routing, and feed-health files are not replaced by the updater.
- Matching live UV/VH ASINs still share one card. The first genuine live source is the only source that notifies; the other source silently records its live timestamp and lead comparison.

## UV category priority extension

The preserved UV 26.9.38 runtime supplies an optional product `categoryId`. Package B now keeps that ID, resolves its name/icon from a local exact 90-entry English taxonomy, and lets the user select Priority Categories in a searchable dashboard checklist. The default list is empty.

Priority is evaluated as an OR of Highlight keyword, price/ETV threshold, or selected UV category. Records include `isCategoryPriority` and `priorityReasons`. UV-first category matches can make the first live chime/notification priority. VH-first items still produce only their original normal first-live notification; later UV category enrichment silently updates and promotes the same card. VH-only products remain category-unknown, without title inference or an Amazon/category lookup.

The category catalog and selection are exposed through `GET /api/categories` and `POST /api/categories/priority`. Changing a selection persistently and silently rechecks all stored cards.

## Hardened future generated identities

The dashboard keeps an explicit **Generate New Synthetic VH Identity** action. It uses one standard Continue/Cancel warning with no typed phrase, and clearly states that this is a new isolated synthetic identity—not official Amazon/VH account linking. The server endpoint likewise accepts the confirmed button action without a phrase field.

A new identity uses schema v2:

- a fresh random synthetic CID;
- a fresh per-install P-256 signing key pair;
- local signing-key self-validation;
- a stable random 32-byte fingerprint digest;
- a persistent 15–100 character device name;
- signed `get_uuid` provisioning using official field order and raw IEEE-P1363 ECDSA signatures;
- signed `upload_fingerprint` registration;
- a returned FID when supported;
- at most three fingerprint-upload attempts, at least six hours apart, followed by the labelled `compatibility-blank-bounded` state if registration is not accepted.

Identity files and explicit-generation backups are mode `0600`; their parent backup directory is mode `0700`. The API/dashboard expose only redacted UUID/CID previews and never return private JWK material.

## VH connection state machine

Package B separates Socket.IO transport state from supplemental VH application evidence.

- Socket.IO uses websocket transport, `reconnection: false`, and manual 10-second supervision.
- A healthy Socket.IO `connect` is the connectivity criterion, matching the freshly audited official 4.7.4 client’s immediate `wsOpen` behavior.
- When URL and all identity query fields are unchanged, reconnects reuse the same Socket object and inspect `socket.recovered`.
- `connection_info`, `newItem`, recognized enrichments, or `broadcastSyncPong` establish supplemental application-activity evidence. The absence of such an event within 30 seconds is diagnostic only and never tears down a healthy transport.
- Engine.IO packet/ping/pong activity feeds a two-minute silence watchdog.
- Connections are refreshed after three hours.
- `broadcastSyncPing` is sent every 60 seconds. As in the official client, a returned pong is optional; an unobserved pong is diagnostic only and never forces recovery.
- A newer differing server broadcast marker records a possible-gap incident and permits one same-socket recovery attempt for that gap episode.
- If the marker remains different after that attempt, R22 keeps the healthy connected socket instead of entering R21's confirmed self-triggered reconnect loop. Additional marker-driven reconnects remain suppressed until a genuine new live VH broadcast arrives or the markers match.
- Planned same-socket recovery is tagged so its expected Socket.IO reason, `io client disconnect`, cannot overwrite the real recovery reason or create a false incident.
- A failed recovery after more than the approximate one-minute recovery window records an immediate possible-gap health incident. New live traffic continues.
- `connection_error` recognizes invalid/old UUID responses and latches the rejection without changing either legacy or hardened saved identity material.
- Connection-limit/denial errors and `serverDisconnect` latch a denial state and stop retry hammering until an explicit enable/reconnect action.
- `connection_info` account/connection/device counts are retained as redacted diagnostics.

## Strict live-history policy and three narrow signed-read exceptions

No startup, recovery, health, or manual-refresh code emits VH `getLast100`. A stale `vhLoadHistory: true` value is forced to `false` at startup and cannot be enabled through the configuration API. An unsolicited `last100` event is ignored and never ingested.

The live-stream history-free trade-off remains explicit: a gap beyond Socket.IO recovery cannot be backfilled into the Live Feed from VH. It is surfaced as a possible-gap health event instead.

R20 authorizes one separate operation: an explicit signed `action: "item_explorer"` request after the user presses Search, Previous, or Next in the distinct VH RFY Server Explorer. This is a read-only server-database search, not live-feed recovery. Its records never enter live ingestion, race clocks, persistence, source merging, or notification paths.

R21 authorizes one additional operation with a different button and no automatic trigger: signed API-v5 `action: "get_user_stats"` solely to report VHelper's authoritative `trial_active`, exact `trial_ends_at`, calculated days remaining, and numeric membership tier when safely present. The action uses the current saved UUID/CID/FID and never applies `resolved_uuid`, repairs or relinks identity, stores the response, or retains linked devices, contribution statistics, payment data, or unrelated fields.

R25 successor `r25-vh-click-variants-20260910-7` authorizes one still narrower operation: while arming **Watch for AFA/AI**, pressing **Load variants from VHelper** may issue one signed official-extension `action: "item_explorer_variants"` request for that displayed parent ASIN. Its ordered pre-signature fields are `api_version`, `version` (not `app_version`), `action`, `country`, `uuid`, `cid`, and `asin`. Opening the card/dialog, switching tabs, searching, arming, app startup, timers, and background paths never invoke it. There is no automatic retry or Amazon/UV/SmartViner/other-source fallback. All three signed reads share one in-flight mutex, replay protection, and VHelper-directed cooldown.

## Passive event and item handling

The following audited events are handled:

- live: `newItem` (`data.item` supported);
- metadata: `connection_info`;
- silent enrichment: `newETV`, `newPrice`, `newVariants`, `unavailableItem`, `orderAttempts`;
- passive/no assisted-load action: `reloadPage`;
- liveness/gap detection: `broadcastSyncPong`;
- denial/errors: `serverDisconnect`, `connection_error`, `disconnect`, `connect_error`;
- unsolicited history: `last100` ignored.

Normalization includes ASIN, queue mapping, parent/pre-release booleans, enrollment GUID, title/image/additional images, ETV range, price, tier, UTC server date/date-added, unavailable state, variants/variant ASIN, reason, and order counts. String booleans such as `"false"` are parsed explicitly rather than with JavaScript truthiness. MySQL-style VH dates are parsed as UTC.

Enrichment never creates a live item, never stamps a live race clock, and never notifies. Early enrichment is retained in a bounded five-minute/500-ASIN pending cache and applied if the live item follows.

R18 presents the already-received enrichment without any detail-fetch request. R21 removes only the compact variant-count and multi-image-count overlays from card photos. Product Details still normalizes array, object, JSON-string, and URI-encoded variant dimensions; displays variant ASINs as ordinary Amazon product links; validates/deduplicates HTTP(S) image URLs; and renders at most 12 received images as a thumbnail gallery. A passive `newPrice`, `newVariants`, or `additional_img` update synchronously replaces the ASIN-keyed card and refreshes an open Product Details modal for the same ASIN. This path has no timer, batching, sound, toast, Telegram, or Discord action.

R19's source-specific live `uvQueue` and `vhQueue` retention remains in place so a same-ASIN merge cannot erase the queue each live source actually supplied. R20 removes passive-explorer bookkeeping from the browser's live `new_item`/`update_item` handlers and makes the visible VH tab a separate server-search state that is never updated by live WebSocket events.

## Signed VH RFY Server Explorer

`POST /api/vh/item-explorer/search` accepts only a bounded JSON object containing a one-time request ID and official practical filters: ASIN, title/wildcard, ordering, page, ETV minimum/maximum, price minimum/maximum, and availability. Extra fields—including caller-controlled action, queue, country, identity, signature, or key fields—are rejected. The request is limited to 16 KiB.

The server fixes `action` to `item_explorer`, `queue` to `potluck`, `api_version` to 5, and `app_version` to 4.7.4. It materializes only the current saved identity with `identityManager.materialize`; it does not call `getOrCreateIdentity`, UUID provisioning, fingerprint registration, repair, rotation, replacement, relinking, or save. The exact official field order is signed with the identity's existing P-256 key and sent through the existing destination-locked VH route. UUID, CID, public/private keys, signature, and proxy URL remain server-side.

One request may be in flight. Reused request IDs are rejected from a bounded ten-minute in-memory replay set. The server records and enforces VHelper's `wait_time` without a background timer, caps the response at 2 MiB, requires the official response fields, accepts at most 50 records, and returns only an allowlisted sanitized shape. If that ordinary response already embeds variants, the allowlist retains at most 100 valid offered child ASINs per record plus eight bounded name/value dimensions; it discards every recommendation, enrollment, customer, offer, and signing field. The search itself never automatically follows with another request.

`invalid_uuid` and recognizable trial/subscription/Tier 3 denials are surfaced as entitlement errors. No recovery method runs. Search does not call `getLast100`, signed `get_info`, broadcast logs, statistics, Amazon details, or unrelated VH actions.

The browser adapts returned records into read-only **VH Server** cards held only in `vhRfyServerItems`. Those cards omit batch selection, pin, hide, delete, live-discovery provenance, priority handling, and live timing. Passive child-ASIN variants may populate only the local exact-watch selector; search results are not persisted, inserted into `allItems`, merged by ASIN, broadcast over `/ws-feed`, or passed to browser sound/priority-toast, Telegram, or Discord paths.

## Explicit Watch-flow VHelper variants

`POST /api/vh/item-explorer/variants` accepts only a one-time request ID and one complete ten-character parent ASIN. Caller-supplied action, version, country, identity, signature, keys, filters, or response data are rejected. The server reads only the saved identity and builds the exact official 4.7.4 pre-signature object with ordered fields `api_version: 5`, `version: "4.7.4"`, `action: "item_explorer_variants"`, `country`, `uuid`, `cid`, and `asin`. The local request ID is never disclosed upstream.

The route is limited to a 4-KiB request and a 512-KiB accepted response. It requires `data.variants`, examines at most 1,000 candidates, and returns at most 100 unique non-parent child ASINs. Each returned choice contains only a bounded title-derived label, at most eight non-sensitive name/value dimensions, and a valid optional ETV. Enrollment, recommendation, offer, customer, identity, signing, and unrelated fields are discarded. Entitlement/rate/size/shape failures remain visible and do not trigger recovery or retry.

The dashboard handler exists only behind **Load variants from VHelper** in the Watch arming dialog and contains exactly one fetch. Results are held in `vhWatchVariants` for that dialog generation only, cleared on close, and never assigned to `vhRfyServerItems`, `item.variants`, `allItems`, storage APIs, notifications, or manual **Order on PC**. **Any currently available variant** remains selected by default. If the user deliberately arms an exact watch, only that selected child ASIN and display label enter the existing watch schema; later companion handling remains strict no-substitution.

## Explicit VHelper trial status

`POST /api/vh/trial-status` accepts only a one-time request ID. Caller-supplied action, identity, country, filters, or arbitrary fields are rejected. The server reads the already-saved identity, fixes the signed content to ordered fields `api_version`, `app_version`, `action: "get_user_stats"`, `country`, `uuid`, `fid`, and `cid`, and uses the existing signing key and destination-locked route. A legacy compatibility-blank FID is forwarded exactly; the endpoint never generates or registers one.

The endpoint uses the same `vhSignedRequestInFlight`, replay cache, and `wait_time` deadline as Item Explorer search and Watch variants, so the three operations cannot overlap or evade one another's cooldown. The 4-KiB request and 512-KiB accepted-response bounds, strict booleans/Unix time/tier validation, and allowlist fail closed. The response contains only active/inactive state, Unix and ISO expiry, calculated whole days remaining, optional tier, check timestamp, and cooldown. It does not expose the raw response.

The dashboard calls this route only from the **Check Trial Status** click handler. Page initialization, WebSocket events, tab switching, diagnostics, timers, retries, and background tasks do not call it. Its state is ordinary page memory only and disappears on reload. `resolved_uuid` is ignored even if VHelper reports a mismatch; devices, contribution statistics, payment fields, and all unrelated fields are dropped before the response is built. An inactive status remains inactive even if an informational future timestamp appears; the client never infers entitlement from the date.

## Diagnostics

- `GET /api/vh/status` reports transport connection/health, supplemental application activity, denial, feed health, redacted identity mode, non-secret Item Explorer/Watch-variants/trial-status capability state, and an explicit per-contract version map; it never performs a check or returns entitlement or variant data.
- `GET /api/vh/diagnostics` reports watchdog/sync timestamps, optional-pong misses, planned recovery reason/state, possible gap, the R22 one-attempt gap-loop guard and suppression count, connection metadata, pending enrichments, route policy, redacted identity/FID state, signed-read in-flight/cooldown policy, and separate 4.7.4 live/Item-Explorer/variants/trial pins plus audited build 3637, without search terms, credentials, or a saved trial response.
- The Settings page has a **VH Package B Diagnostics** panel that renders each contract pin separately rather than implying that one generic version applies to every signed shape.

## Offline tests

Run:

```bash
npm run validate:offline
```

The suite checks:

- legacy identity preservation without API provisioning;
- fresh P-256 key generation and signed official request shapes;
- stable fingerprint/FID success and bounded blank-FID fallback;
- UTC dates, booleans, core item fields, all enrichment mappings, and sync markers;
- same-socket options/watchdog constants;
- official-client transport health semantics, optional application evidence/pongs, and planned-disconnect incident suppression;
- invalid UUID errors cannot mutate saved identity automatically;
- every required event binding;
- no `getLast100` emission;
- silent enrichment and second-feed notification suppression;
- the exact 90-category UV catalog, UV-only capture, exact-ID normalization, and no title inference;
- keyword/price/category OR evaluation, full priority reasons, persisted rechecks, category APIs, and dashboard controls;
- silent UV category enrichment and browser-sound suppression for existing VH-first cards;
- safe variant/image normalization, hidden card-image count overlays, retained modal details/gallery, and immediate open-modal enrichment refresh without fetch/timer/notification code;
- exact source-specific live VH queue retention plus a separate server-backed RFY explorer with strict filters, fixed `potluck` queue, saved-identity signing, shared serialization/replay/cooldown controls, and no first-alert-path dependency;
- exact click-only `item_explorer_variants` request shape using `version`, strict parent/child/title/ETV sanitization, one fetch per click, no automatic trigger/retry/fallback, and dialog-only browser state;
- exact click-only `get_user_stats` request shape, strict trial-field sanitization, calculated days, raw-response field discard, no persistence, and no automatic trigger;
- strict 50-item/2-MiB Item Explorer plus 100-child/512-KiB variants and 512-KiB trial-response sanitization, read-only browser state, honest entitlement errors, no identity mutation, and absence of all other prohibited VH actions;
- immediate Clear Items, exact shared photo/Open Vine URL behavior, and phrase-free VH rotation;
- UV 26.9.38 version/account-frame compatibility and normalized read-only order-progress counts;
- app-only Gluetun routing and destination-locked VH proxy policy.

These mocks and static checks do not claim live backend acceptance. The first live validation is intentionally left to the user’s existing VPS route after the updater completes and restarts Compose.

## Transactional updater and rollback

`update-working-vps.sh` is a self-contained in-place updater for `/home/ubuntu/vine` (or a path passed as argument). It:

1. extracts a hash-verified, secret-free release payload in a private temporary directory;
2. runs syntax, frontend, unit/policy, Compose, shell, and container-runtime checks with networking disabled;
3. creates and validates candidate app/proxy images from the already-working local images without pulling packages or starting the app;
4. stops the existing Compose deployment only after all candidate checks pass;
5. creates a full, local, root-owned mode-`0600` compressed snapshot of the entire project directory, including config, data/history, Compose/proxy files, and inline-certificate VPN material;
6. installs only release-managed source files, retaining runtime config/data/VPN material;
7. activates the prevalidated images and restarts the complete existing Compose deployment automatically;
8. automatically restores the snapshot and old image tags if any transactional step fails; and
9. writes a root-owned rollback script beside the snapshot, updates a stable `rollback-latest.sh` launcher, and prints both commands.

The rollback script stops the current deployment, verifies the snapshot hash, moves the post-update tree aside, restores the exact prior tree (owners/modes/xattrs/ACLs where supported), retags the preserved prior images, and restarts Compose without rebuilding.
