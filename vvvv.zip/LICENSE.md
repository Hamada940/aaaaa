# VIRAL VUE EXTENSION LICENSE

Copyright (c) 2024-present Viral Vue, LLC

Last Updated: 16 December 2025

This license applies specifically to the Viral Vue Chrome extension ("Software") developed and owned by Viral Vue, LLC ("Company"). By installing or using the Software, you agree to the following terms:

## 1. License Grant
The Company grants you a limited, non-exclusive, non-transferable license to install and use the Software for personal or business purposes, in accordance with the free or paid plans you have subscribed to through the Company’s website.

## 2. Restrictions on Use
You may not modify, adapt, reverse-engineer, decompile, disassemble, or create derivative works based on the Software or any part of its code.
You may not copy, distribute, sell, lease, sublicense, or share the Software or any part of its code.
Reverse engineering or attempting to access the source code or internal mechanisms of the Software is strictly prohibited.
You may only use the Software in the United States, Canada & United Kingdom; usage outside these territories is prohibited.

## 3. Ownership
The Software and all intellectual property rights therein remain the exclusive property of Viral Vue, LLC. No rights or title to the Software are transferred to you by this license.

## 4. Termination of License
Your license to use the Software will automatically terminate if you violate any of the terms in this Agreement. Upon termination, you must immediately cease using the Software and delete all copies of it from your devices.

## 5. Terms & Conditions
This License is a supplement to the Viral Vue [Terms & Conditions](https://www.viralvue.com/terms-and-conditions) which govern the use of the Software and the services provided by the Company. Please refer to the [Terms & Conditions](https://www.viralvue.com/terms-and-conditions) for additional terms regarding payment, warranties, and liability limitations.