window.popupView = true;

/**
 * The popup UI can also be opened as a normal browser tab (e.g. Orion mobile).
 * In tab mode we should use available width; in extension popup mode we keep
 * the compact fixed-width layout.
 */
function updatePopupLayoutMode() {
	const TAB_VIEW_THRESHOLD = 380;
	const isLikelyTabView = window.innerWidth > TAB_VIEW_THRESHOLD;
	document.documentElement.classList.toggle("vh-popup-tab-view", isLikelyTabView);
}

if (document.readyState === "loading") {
	document.addEventListener("DOMContentLoaded", updatePopupLayoutMode);
} else {
	updatePopupLayoutMode();
}

window.addEventListener("resize", updatePopupLayoutMode);
