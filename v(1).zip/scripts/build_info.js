/** Updated automatically by `scripts/increment-build.mjs` via the pre-commit hook. */
export const BUILD_NUMBER = 3447;
