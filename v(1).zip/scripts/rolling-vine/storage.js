import { ChromeStorageAdapter } from "/scripts/infrastructure/StorageAdapter.js";

const STORAGE_KEYS = {
	syncState: "rollingVine.syncState",
	metrics: "rollingVine.metrics",
	syncCache: "rollingVine.syncCache",
};

const storage = new ChromeStorageAdapter("local");

async function getSyncState() {
	const state = await storage.get(STORAGE_KEYS.syncState);
	return (
		state || {
			status: "idle",
			lastSuccessAt: null,
			lastError: null,
			stage: null,
			isRunning: false,
		}
	);
}

async function setSyncState(nextState) {
	const current = await getSyncState();
	const merged = { ...current, ...nextState };
	await storage.set(STORAGE_KEYS.syncState, merged);
	return merged;
}

async function getMetrics() {
	return (await storage.get(STORAGE_KEYS.metrics)) || null;
}

async function setMetrics(metrics) {
	await storage.set(STORAGE_KEYS.metrics, metrics);
	return metrics;
}

async function getSyncCache() {
	return (await storage.get(STORAGE_KEYS.syncCache)) || {};
}

async function setSyncCache(nextCache) {
	const current = await getSyncCache();
	const merged = { ...current, ...nextCache };
	await storage.set(STORAGE_KEYS.syncCache, merged);
	return merged;
}

const api = {
	STORAGE_KEYS,
	getSyncState,
	setSyncState,
	getMetrics,
	setMetrics,
	getSyncCache,
	setSyncCache,
};

export const RollingVineStorage = api;

globalThis.RollingVineStorage = api;
