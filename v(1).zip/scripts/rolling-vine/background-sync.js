/**
 * Rolling Vine background sync logic.
 * Integrated into VineHelper service worker.
 */

import { detectHtmlPageGuard } from "/scripts/core/amazon/parsers/guardsHtml.js";
import { RollingVineStorage } from "./storage.js";

const RV_MAX_PAGES_PER_SECTION = 72; // Max for Gold tier: 8 orders per day * 90 days = 720, 10 orders per page -> 72 pages
const RV_PAGE_SETTLE_MIN_MS = 700;
const RV_PAGE_SETTLE_MAX_MS = 1400;
const RV_PAGE_LOAD_TIMEOUT_MS = 25000;
const RV_EXTRACT_ATTEMPTS = 5;
const RV_EXTRACT_RETRY_DELAY_MS = 900;
const RV_LOG_PREFIX = "[rolling-vine/bg]";
const RV_SAFE_STOP_ERROR_CODES = {
	dog: "dog",
	captcha: "captcha",
	sessionExpired: "session-expired",
	timeout: "timeout",
	unknown: "unknown",
};

// -- Core metrics computation (inline) --

const RV_PERIODS = [90, 60, 30];
const RV_RISK_THRESHOLD = 60;

function rvComputeRate(reviews, orders) {
	if (!orders) return null;
	return Math.round((reviews / orders) * 1000) / 10;
}

function rvComputeStatus(rate) {
	if (rate === null) return "ok";
	return rate < RV_RISK_THRESHOLD ? "at-risk" : "ok";
}

function rvDaysAgoBucket(dateMs, nowMs) {
	const nowDayMs = rvStartOfDayMs(nowMs);
	const dateDayMs = rvStartOfDayMs(dateMs);
	const delta = nowDayMs - dateDayMs;
	if (delta < 0) return null;
	return Math.floor(delta / (24 * 60 * 60 * 1000));
}

function rvStartOfDayMs(timestampMs) {
	const date = new Date(timestampMs);
	date.setHours(0, 0, 0, 0);
	return date.getTime();
}

function rvBuildMetrics(orderDates, reviewDates, comparisonNowMs, generatedAtMs) {
	const metrics = {
		periods: {
			90: { orders: 0, reviews: 0, rate: null, status: "ok" },
			60: { orders: 0, reviews: 0, rate: null, status: "ok" },
			30: { orders: 0, reviews: 0, rate: null, status: "ok" },
		},
		generatedAt: null,
	};

	for (const dateMs of orderDates) {
		const age = rvDaysAgoBucket(dateMs, comparisonNowMs);
		if (age === null || age >= 90) continue;
		if (age < 90) metrics.periods[90].orders += 1;
		if (age < 60) metrics.periods[60].orders += 1;
		if (age < 30) metrics.periods[30].orders += 1;
	}

	for (const dateMs of reviewDates) {
		const age = rvDaysAgoBucket(dateMs, comparisonNowMs);
		if (age === null || age >= 90) continue;
		if (age < 90) metrics.periods[90].reviews += 1;
		if (age < 60) metrics.periods[60].reviews += 1;
		if (age < 30) metrics.periods[30].reviews += 1;
	}

	for (const period of RV_PERIODS) {
		const p = metrics.periods[period];
		p.rate = rvComputeRate(p.reviews, p.orders);
		p.status = rvComputeStatus(p.rate);
	}

	metrics.generatedAt = new Date(generatedAtMs).toISOString();
	return metrics;
}

function rvNormalizeText(value) {
	return (value || "")
		.toString()
		.toLowerCase()
		.normalize("NFD")
		.replace(/[\u0300-\u036f]/g, " ")
		.replace(/\s+/g, " ")
		.trim();
}

// -- Sync logic --

let rvRunningJob = null;

function rvClassifySafeStopError(error) {
	const fallbackMessage = "Sync stopped safely due to an unexpected issue";
	const message =
		error && typeof error.message === "string" && error.message.trim() ? error.message.trim() : fallbackMessage;
	const normalized = rvNormalizeText(message);

	if (normalized.includes("captcha")) return { code: RV_SAFE_STOP_ERROR_CODES.captcha, message };
	if (
		normalized.includes("dog page") ||
		normalized.includes("dog_page") ||
		(normalized.includes("dog") && normalized.includes("amazon"))
	)
		return { code: RV_SAFE_STOP_ERROR_CODES.dog, message };
	if (
		normalized.includes("login required") ||
		normalized.includes("session expired") ||
		normalized.includes("sign in") ||
		normalized.includes("signin")
	)
		return { code: RV_SAFE_STOP_ERROR_CODES.sessionExpired, message };
	if (normalized.includes("timeout") || normalized.includes("timed out"))
		return { code: RV_SAFE_STOP_ERROR_CODES.timeout, message };
	return { code: RV_SAFE_STOP_ERROR_CODES.unknown, message };
}

function rvNormalizeTimestampList(value) {
	if (!Array.isArray(value)) return [];
	return value.map((item) => Number(item)).filter((t) => Number.isFinite(t) && t > 0);
}

function rvMergeTimestamps(baseList, deltaList) {
	return rvNormalizeTimestampList(baseList).concat(rvNormalizeTimestampList(deltaList));
}

async function rvRunSync({ origin, accountTabId }) {
	console.log(`${RV_LOG_PREFIX} runSync started`, { origin, accountTabId });
	const startedAt = new Date().toISOString();
	const generatedAtMs = Date.now();
	const comparisonNowMs = rvStartOfDayMs(generatedAtMs);
	const ordersCutoffMs = comparisonNowMs - 90 * 24 * 60 * 60 * 1000;
	const syncCache = await RollingVineStorage.getSyncCache();
	const lastOrdersTopTimestamp = Number(syncCache && syncCache.lastOrdersTopTimestamp) || null;
	const cachedOrdersScannedCount = Number(syncCache && syncCache.lastOrdersScannedCount) || 0;
	const cachedOrdersDateMsList = rvNormalizeTimestampList(syncCache && syncCache.lastOrdersDateMsList).filter(
		(t) => t >= ordersCutoffMs
	);
	const hasOrdersBaseline =
		lastOrdersTopTimestamp && cachedOrdersScannedCount > 0 && cachedOrdersDateMsList.length > 0;

	await RollingVineStorage.setSyncState({
		status: "running",
		isRunning: true,
		stage: "orders",
		startedAt,
		lastError: null,
		lastErrorCode: null,
		progress: { section: "orders", page: 1 },
	});

	try {
		const ordersResult = await rvScanSection({
			origin,
			section: "orders",
			accountTabId,
			nowMs: comparisonNowMs,
			ordersCheckpointTimestamp: hasOrdersBaseline ? lastOrdersTopTimestamp : null,
		});

		let ordersDateMsForMetrics = rvNormalizeTimestampList(ordersResult.dateMsList).filter(
			(t) => t >= ordersCutoffMs
		);

		if (ordersResult.stopReason === "matched-last-orders-timestamp" && hasOrdersBaseline) {
			const ordersDeltaDateMsList = ordersDateMsForMetrics.filter((t) => t > lastOrdersTopTimestamp);
			ordersDateMsForMetrics = rvMergeTimestamps(cachedOrdersDateMsList, ordersDeltaDateMsList).filter(
				(t) => t >= ordersCutoffMs
			);
		}

		const ordersTopTimestamp = ordersDateMsForMetrics.length > 0 ? Math.max(...ordersDateMsForMetrics) : null;

		await RollingVineStorage.setSyncCache({
			lastOrdersTopTimestamp: ordersTopTimestamp,
			lastOrdersScannedCount: ordersDateMsForMetrics.length,
			lastOrdersDateMsList: ordersDateMsForMetrics,
			ordersCheckpointUpdatedAt: new Date().toISOString(),
		});

		await RollingVineStorage.setSyncState({
			status: "running",
			stage: "reviews",
			progress: { section: "reviews", page: 1 },
		});
		rvNotifyAccount(accountTabId, { type: "rollingVine.syncProgress", section: "reviews", page: 1 });

		const reviewsResult = await rvScanSection({
			origin,
			section: "reviews",
			accountTabId,
			nowMs: comparisonNowMs,
		});

		const metrics = rvBuildMetrics(
			ordersDateMsForMetrics,
			reviewsResult.dateMsList,
			comparisonNowMs,
			generatedAtMs
		);
		metrics.syncMeta = {
			startedAt,
			finishedAt: new Date().toISOString(),
			ordersPages: ordersResult.pagesScanned,
			reviewsPages: reviewsResult.pagesScanned,
			ordersStopReason: ordersResult.stopReason,
			reviewsStopReason: reviewsResult.stopReason,
			ordersCountUsedForMetrics: ordersDateMsForMetrics.length,
		};

		await RollingVineStorage.setMetrics(metrics);
		await RollingVineStorage.setSyncState({
			status: "idle",
			isRunning: false,
			stage: null,
			progress: null,
			lastSuccessAt: metrics.generatedAt,
			lastError: null,
			lastErrorCode: null,
		});

		rvNotifyAccount(accountTabId, { type: "rollingVine.syncFinished" });
	} catch (error) {
		console.error(`${RV_LOG_PREFIX} runSync failed`, error && error.stack ? error.stack : error);
		const safeStopError = rvClassifySafeStopError(error);
		if (error && error.errorCode) {
			safeStopError.code = error.errorCode;
		}
		await RollingVineStorage.setSyncState({
			status: "safe-stopped",
			isRunning: false,
			stage: null,
			progress: null,
			lastError: safeStopError.message,
			lastErrorCode: safeStopError.code,
		});
		rvNotifyAccount(accountTabId, {
			type: "rollingVine.syncFailed",
			error: safeStopError.message,
			errorCode: safeStopError.code,
		});
	}
}

// -- Fetch and HTML extraction --

async function rvFetchPage(url) {
	const controller = new AbortController();
	const timeout = setTimeout(() => controller.abort(), RV_PAGE_LOAD_TIMEOUT_MS);

	try {
		const acceptLanguage = navigator.language || navigator.languages?.join(",") || "en-US,en;q=0.9";
		const response = await fetch(url, {
			headers: {
				"User-Agent": navigator.userAgent,
				Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
				"Accept-Language": acceptLanguage,
				"Accept-Encoding": "gzip, deflate, br",
				"Cache-Control": "no-cache",
				Pragma: "no-cache",
				"Sec-Fetch-Dest": "document",
				"Sec-Fetch-Mode": "navigate",
				"Sec-Fetch-Site": "none",
				"Sec-Fetch-User": "?1",
				"Upgrade-Insecure-Requests": "1",
			},
			credentials: "include",
			signal: controller.signal,
		});
		clearTimeout(timeout);

		if (!response.ok) {
			throw new Error(`HTTP ${response.status} fetching ${url}`);
		}

		return await response.text();
	} catch (error) {
		clearTimeout(timeout);
		if (error.name === "AbortError") {
			throw new Error("Page load timeout");
		}
		throw error;
	}
}

function rvDetectSafetyStop(html) {
	const guard = detectHtmlPageGuard(html);

	if (guard === "dog") {
		return { code: RV_SAFE_STOP_ERROR_CODES.dog, reason: "dog page detected" };
	}
	if (guard === "captcha") {
		return { code: RV_SAFE_STOP_ERROR_CODES.captcha, reason: "captcha detected" };
	}
	if (guard === "login") {
		return { code: RV_SAFE_STOP_ERROR_CODES.sessionExpired, reason: "login required or session expired" };
	}

	return null;
}

function rvIsSafetyStopResponse(response) {
	if (!response || response.ok || !response.safetyStop) {
		return false;
	}
	return true;
}

function rvExtractTimestamps(html) {
	const items = [];
	// Match data-order-timestamp="<number>" in relevant context
	const regex = /data-order-timestamp="(\d+)"/g;
	let match;
	while ((match = regex.exec(html)) !== null) {
		const dateMs = Number(match[1]);
		if (!dateMs || dateMs <= 0) continue;
		items.push({ dateMs });
	}
	return items.sort((a, b) => b.dateMs - a.dateMs);
}

function rvHasNextPage(html) {
	// Amazon pagination: <li class="a-last"> without "a-disabled" means there's a next page
	// If "a-disabled" appears in the same <li> as "a-last", there's no next page
	const lastLiMatch = html.match(/<li[^>]*class="[^"]*a-last[^"]*"[^>]*>/i);
	if (!lastLiMatch) return false;
	return !lastLiMatch[0].includes("a-disabled");
}

function rvExtractPageData(html, section, nowMs) {
	const safetyIssue = rvDetectSafetyStop(html);
	if (safetyIssue) {
		return {
			ok: false,
			safetyStop: true,
			errorCode: safetyIssue.code,
			reason: safetyIssue.reason,
		};
	}

	const items = rvExtractTimestamps(html);
	if (items.length === 0) {
		return { ok: false, reason: "no parsable records found" };
	}

	const oldestMs = Math.min(...items.map((item) => item.dateMs));
	const oldestAge = rvDaysAgoBucket(oldestMs, nowMs);

	return {
		ok: true,
		items,
		reachedOlderThan90: oldestAge !== null && oldestAge >= 90,
		hasNextPage: rvHasNextPage(html),
		recordCount: items.length,
	};
}

async function rvFetchAndExtractWithRetries(url, section, nowMs) {
	let lastError = null;

	for (let attempt = 1; attempt <= RV_EXTRACT_ATTEMPTS; attempt += 1) {
		try {
			const html = await rvFetchPage(url);
			const response = rvExtractPageData(html, section, nowMs);

			if (response && response.ok) return response;

			if (rvIsSafetyStopResponse(response)) {
				return response;
			}

			lastError = new Error(response && response.reason ? response.reason : "no parsable records found");
			if (attempt < RV_EXTRACT_ATTEMPTS) {
				await rvRandomDelay(RV_EXTRACT_RETRY_DELAY_MS, RV_EXTRACT_RETRY_DELAY_MS + 400);
			}
		} catch (error) {
			lastError = error instanceof Error ? error : new Error(String(error));
			if (attempt < RV_EXTRACT_ATTEMPTS) {
				await rvRandomDelay(RV_EXTRACT_RETRY_DELAY_MS, RV_EXTRACT_RETRY_DELAY_MS + 400);
			}
		}
	}
	throw lastError || new Error("Unable to extract page data");
}

async function rvScanSection({ origin, section, accountTabId, nowMs, ordersCheckpointTimestamp = null }) {
	const dateMsList = [];
	const normalizedCheckpoint = section === "orders" ? Number(ordersCheckpointTimestamp) || null : null;
	let page = 1;
	let stopReason = "max-pages";

	while (page <= RV_MAX_PAGES_PER_SECTION) {
		const url = rvBuildSectionUrl(origin, section, page);
		await RollingVineStorage.setSyncState({ progress: { section, page } });
		rvNotifyAccount(accountTabId, { type: "rollingVine.syncProgress", section, page });

		if (page > 1) {
			await rvRandomDelay(RV_PAGE_SETTLE_MIN_MS, RV_PAGE_SETTLE_MAX_MS);
		}

		const response = await rvFetchAndExtractWithRetries(url, section, nowMs);

		if (!response || !response.ok) {
			const reason = response && response.reason ? response.reason : "Unexpected extraction failure";
			const error = new Error(`${section} sync stopped safely: ${reason}`);
			if (response && response.errorCode) {
				error.errorCode = response.errorCode;
			}
			throw error;
		}

		if (!response.items || response.items.length === 0) {
			throw new Error(`${section} sync stopped safely: empty page or unexpected markup`);
		}

		for (const item of response.items) {
			if (item && item.dateMs) dateMsList.push(item.dateMs);
		}

		if (
			section === "orders" &&
			normalizedCheckpoint &&
			response.items.some((item) => item && item.dateMs === normalizedCheckpoint)
		) {
			stopReason = "matched-last-orders-timestamp";
			break;
		}

		if (response.reachedOlderThan90) {
			stopReason = "older-than-90-days";
			break;
		}
		if (!response.hasNextPage) {
			stopReason = "no-next-page";
			break;
		}

		page += 1;
	}

	return {
		dateMsList,
		topTimestamp: dateMsList.length > 0 ? Math.max(...dateMsList) : null,
		pagesScanned: page,
		stopReason,
	};
}

// -- Helpers --

function rvBuildSectionUrl(origin, section, page) {
	if (section === "orders") return page === 1 ? `${origin}/vine/orders` : `${origin}/vine/orders?page=${page}`;
	if (section === "reviews")
		return page === 1
			? `${origin}/vine/vine-reviews?review-type=completed`
			: `${origin}/vine/vine-reviews?page=${page}&review-type=completed`;
	throw new Error(`Unsupported section: ${section}`);
}

function rvRandomDelay(minMs, maxMs) {
	const d = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
	return new Promise((resolve) => setTimeout(resolve, d));
}

function rvNotifyAccount(tabId, message) {
	if (typeof tabId !== "number") return;
	chrome.tabs.sendMessage(tabId, message, () => {
		void chrome.runtime.lastError;
	});
}

// -- Public handler to register with chrome.runtime.onMessage --

export function handleRollingVineMessage(message, sender, sendResponse) {
	if (!message || message.type !== "rollingVine.startSync") {
		return false;
	}

	console.log(`${RV_LOG_PREFIX} startSync requested`, sender && sender.tab ? sender.tab.url : "no-tab");

	(async () => {
		try {
			if (rvRunningJob) {
				const state = await RollingVineStorage.getSyncState();
				sendResponse({ ok: true, state });
				return;
			}

			const rawPageUrl =
				(message && typeof message.pageUrl === "string" && message.pageUrl) ||
				(sender && sender.tab && typeof sender.tab.url === "string" && sender.tab.url) ||
				(sender && typeof sender.url === "string" && sender.url) ||
				null;

			const senderUrl = rawPageUrl ? new URL(rawPageUrl) : null;
			if (!senderUrl) {
				sendResponse({ ok: false, error: "Unable to identify account page URL." });
				return;
			}

			const origin =
				message && typeof message.origin === "string" && message.origin ? message.origin : senderUrl.origin;
			const accountTabId = sender && sender.tab && typeof sender.tab.id === "number" ? sender.tab.id : null;

			rvRunningJob = rvRunSync({ origin, accountTabId })
				.catch(() => undefined)
				.finally(() => {
					rvRunningJob = null;
				});

			sendResponse({
				ok: true,
				state: {
					status: "running",
					isRunning: true,
					stage: "orders",
					lastError: null,
					progress: { section: "orders", page: 1 },
				},
			});
		} catch (error) {
			console.error(`${RV_LOG_PREFIX} startSync failed`, error && error.stack ? error.stack : error);
			sendResponse({ ok: false, error: error.message });
		}
	})();

	return true; // keep the message channel open for async sendResponse
}
