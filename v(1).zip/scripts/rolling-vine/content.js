import { RollingVineStorage } from "./storage.js";
import { getMessage, initLocaleOverride } from "/scripts/core/services/Internationalization.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";

const Settings = new SettingsMgr();

const ACCOUNT_PATH_REGEX = /^\/vine\/account\/?$/;
const LOG_PREFIX = "[rolling-vine/content]";
const HYDRATE_RETRY_DELAYS_MS = [0, 250, 800, 1600];
const START_SYNC_ATTEMPTS = 3;
const START_SYNC_RETRY_DELAY_MS = 500;
const PERIODS = [90, 60, 30];
const SAFE_STOP_ERROR_CODES = {
	dog: "dog",
	captcha: "captcha",
	sessionExpired: "session-expired",
	timeout: "timeout",
	unknown: "unknown",
};

let rootEl = null;
let lastKnownHref = location.href;
let lastAppliedLocale = null;
let delegationAttached = false;
let syncPollTimer = null;

function rvMsg(key, fallback = "", substitutions) {
	return getMessage(key, fallback, substitutions);
}

function normalizeText(value) {
	return (value || "")
		.toString()
		.toLowerCase()
		.normalize("NFD")
		.replace(/[\u0300-\u036f]/g, " ")
		.replace(/\s+/g, " ")
		.trim();
}

function rvRiskMessageKey(period) {
	if (period === 90) {
		return "rollingVineRisk90";
	}
	if (period === 60) {
		return "rollingVineRisk60";
	}
	return "rollingVineRisk30";
}

async function applyLocaleFromSettingsMgr() {
	const localeOverride = Settings.get("i18n.localeOverride", false);
	const locale = localeOverride != null && String(localeOverride).trim() !== "" ? String(localeOverride).trim() : "";
	if (locale === lastAppliedLocale) {
		return false;
	}
	lastAppliedLocale = locale;
	await initLocaleOverride(locale);
	return true;
}

function handleSettingsChange() {
	if (!Settings.get("general.rollingVine") && rootEl) {
		rootEl.style.display = "none";
	} else if (Settings.get("general.rollingVine") && rootEl) {
		rootEl.style.display = "";
	}
	if (Settings.get("general.rollingVine")) {
		scheduleAccountHydration();
	}

	applyLocaleFromSettingsMgr()
		.then((localeChanged) => {
			if (!localeChanged) {
				return;
			}
			remountRollingVineUI();
			if (Settings.get("general.rollingVine")) {
				scheduleAccountHydration();
			}
		})
		.catch(() => undefined);
}

function remountRollingVineUI() {
	if (rootEl) {
		rootEl.remove();
		rootEl = null;
		delegationAttached = false;
	}
}

window.addEventListener("error", (event) => {
	console.error(`${LOG_PREFIX} uncaught error`, event.message, event.filename, event.lineno);
});

window.addEventListener("unhandledrejection", (event) => {
	console.error(`${LOG_PREFIX} unhandled rejection`, event.reason);
});

init();

async function init() {
	// Register message handler for sync progress notifications
	chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
		if (!message || !message.type) {
			return;
		}

		if (
			message.type === "rollingVine.syncProgress" ||
			message.type === "rollingVine.syncFinished" ||
			message.type === "rollingVine.syncFailed"
		) {
			if (isAccountPage() && Settings.get("general.rollingVine")) {
				hydrateAccountUI().catch(() => undefined);
			}
		}
	});

	await Settings.waitForLoad();
	await applyLocaleFromSettingsMgr();

	if (isAccountPage()) {
		if (Settings.get("general.rollingVine")) {
			scheduleAccountHydration();
		}
	}
}

function scheduleAccountHydration() {
	const rollingVineEnabled = Settings.get("general.rollingVine");
	if (!isAccountPage() || !rollingVineEnabled) {
		return;
	}

	for (const delayMs of HYDRATE_RETRY_DELAYS_MS) {
		setTimeout(() => {
			if (isAccountPage() && rollingVineEnabled) {
				mountAndHydrateAccountUI();
			}
		}, delayMs);
	}
}

function mountAndHydrateAccountUI() {
	mountAccountUI()
		.then(() => hydrateAccountUI())
		.catch(() => undefined);
}

async function sendRuntimeMessage(message) {
	let lastError = null;

	for (let attempt = 1; attempt <= START_SYNC_ATTEMPTS; attempt += 1) {
		try {
			const response = await new Promise((resolve, reject) => {
				chrome.runtime.sendMessage(message, (nextResponse) => {
					const err = chrome.runtime.lastError;
					if (err) {
						reject(new Error(err.message));
						return;
					}
					resolve(nextResponse);
				});
			});

			if (!response && attempt < START_SYNC_ATTEMPTS) {
				await delay(START_SYNC_RETRY_DELAY_MS * attempt);
				continue;
			}

			return response;
		} catch (error) {
			lastError = error;
			if (attempt < START_SYNC_ATTEMPTS) {
				await delay(START_SYNC_RETRY_DELAY_MS * attempt);
			}
		}
	}

	if (lastError) {
		throw lastError;
	}

	throw new Error("No response from background sync handler");
}

function isAccountPage() {
	return ACCOUNT_PATH_REGEX.test(location.pathname);
}

function inferSafeStopErrorCode(lastError) {
	const normalized = normalizeText(lastError || "");

	if (normalized.includes("captcha")) {
		return SAFE_STOP_ERROR_CODES.captcha;
	}
	if (normalized.includes("dog page") || normalized.includes("dog_page")) {
		return SAFE_STOP_ERROR_CODES.dog;
	}
	if (
		normalized.includes("login required") ||
		normalized.includes("session expired") ||
		normalized.includes("sign in") ||
		normalized.includes("signin")
	) {
		return SAFE_STOP_ERROR_CODES.sessionExpired;
	}
	if (normalized.includes("timeout") || normalized.includes("timed out")) {
		return SAFE_STOP_ERROR_CODES.timeout;
	}

	return SAFE_STOP_ERROR_CODES.unknown;
}

function getSafeStopMessage(syncState) {
	const code = syncState.lastErrorCode || inferSafeStopErrorCode(syncState.lastError);

	if (code === SAFE_STOP_ERROR_CODES.dog) {
		return rvMsg(
			"rollingVineSafeStoppedDog",
			"Sync stopped: Amazon returned an error page. Reload this page and try syncing again."
		);
	}

	if (code === SAFE_STOP_ERROR_CODES.captcha) {
		return rvMsg(
			"rollingVineSafeStoppedCaptcha",
			"Sync stopped: Amazon returned a CAPTCHA page. Reload this page, complete the CAPTCHA if prompted, then try syncing again."
		);
	}

	if (code === SAFE_STOP_ERROR_CODES.sessionExpired) {
		return rvMsg(
			"rollingVineSafeStoppedSession",
			"Sync stopped: Amazon returned a login page. Reload this page, sign in if needed, then try syncing again."
		);
	}

	if (code === SAFE_STOP_ERROR_CODES.timeout) {
		return rvMsg(
			"rollingVineSafeStoppedTimeout",
			"Sync stopped: the page took too long to load. Reload this page, check your connection, then try syncing again."
		);
	}

	if (syncState.lastError) {
		return rvMsg(
			"rollingVineSafeStoppedWithError",
			`Sync stopped: ${syncState.lastError}. Reload this page and try again.`,
			[syncState.lastError]
		);
	}

	return rvMsg("rollingVineSafeStoppedDefault", "Sync stopped unexpectedly. Reload this page and try syncing again.");
}

function getSyncProgressMessage(syncState) {
	const progress = syncState && syncState.progress ? syncState.progress : null;
	const page = progress && Number(progress.page) > 0 ? Number(progress.page) : null;
	const section = progress && progress.section ? progress.section : syncState.stage;

	if (section === "reviews") {
		if (page) {
			return rvMsg("rollingVineSyncingReviewsPage", "Syncing completed reviews… (page $1$)", [String(page)]);
		}
		return rvMsg("rollingVineSyncingReviews", "Syncing completed reviews...");
	}

	if (page) {
		return rvMsg("rollingVineSyncingOrdersPage", "Syncing orders… (page $1$)", [String(page)]);
	}
	return rvMsg("rollingVineSyncingOrders", "Syncing orders...");
}

function startSyncPolling() {
	stopSyncPolling();
	syncPollTimer = setInterval(() => {
		if (!isAccountPage() || !Settings.get("general.rollingVine")) {
			stopSyncPolling();
			return;
		}
		hydrateAccountUI().catch(() => undefined);
	}, 2000);
}

function stopSyncPolling() {
	if (syncPollTimer) {
		clearInterval(syncPollTimer);
		syncPollTimer = null;
	}
}

async function mountAccountUI() {
	if (rootEl && !rootEl.isConnected) {
		rootEl = null;
		delegationAttached = false;
	}

	if (rootEl && rootEl.isConnected) {
		ensureDelegation();
		return;
	}

	const existingRoot = document.querySelector(".rolling-vine-root");
	if (existingRoot) {
		rootEl = existingRoot;
		ensureDelegation();
		return;
	}

	const anchor = findAccountAnchor();
	if (!anchor) {
		return;
	}

	rootEl = document.createElement("section");
	rootEl.className = "rolling-vine-root";
	rootEl.appendChild(buildAccountLayout());
	anchor.appendChild(rootEl);

	ensureDelegation();
}

function ensureDelegation() {
	if (delegationAttached || !rootEl) {
		return;
	}

	rootEl.addEventListener("click", async (event) => {
		const syncBtn = event.target.closest(".rolling-vine-sync-btn");
		if (!syncBtn) {
			return;
		}

		syncBtn.disabled = true;
		syncBtn.classList.add("is-syncing");
		const syncStage = rootEl.querySelector("[data-sync-stage]");
		if (syncStage) {
			syncStage.textContent = rvMsg("rollingVineStartingSync", "Starting sync...");
			syncStage.classList.add("is-syncing");
			syncStage.classList.remove("is-error");
		}
		try {
			const response = await sendRuntimeMessage({
				type: "rollingVine.startSync",
				origin: location.origin,
				pageUrl: location.href,
			});
			if (response && response.ok === false) {
				throw new Error(response.error || "Unknown sync start error");
			}
			if (response && response.state && response.state.isRunning && syncStage) {
				syncStage.textContent = getSyncProgressMessage(response.state);
				syncStage.classList.add("is-syncing");
				syncStage.classList.remove("is-error");
			}
		} catch (error) {
			const reason = error && error.message ? error.message : String(error);
			console.error(`${LOG_PREFIX} sync click failed`, error && error.stack ? error.stack : error);
			syncBtn.classList.remove("is-syncing");

			if (syncStage) {
				syncStage.textContent = `${rvMsg("rollingVineSyncStartFailedPrefix", "Sync failed to start")}: ${reason}`;
				syncStage.classList.add("is-error");
				syncStage.classList.remove("is-syncing");
			}
		} finally {
			setTimeout(() => {
				hydrateAccountUI().catch(() => undefined);
			}, 450);
		}
	});

	delegationAttached = true;
}

function findAccountAnchor() {
	// Look for the VHelper extra stats container to insert after it
	const extraStats = document.querySelector("#account-extra-stats");
	if (extraStats) {
		return extraStats.parentElement;
	}

	const dashboardRow = document.querySelector("#vvp-account-dashboard > .a-row");
	if (dashboardRow) {
		return dashboardRow;
	}

	const selectors = ["#vvp-account-overview", "#vvp-account-page", ".vvp-body", "main", "#pageContent"];

	for (const selector of selectors) {
		const node = document.querySelector(selector);
		if (node) {
			return node;
		}
	}

	return document.body;
}

function buildAccountLayout() {
	const fragment = document.createDocumentFragment();

	const headerRow = document.createElement("div");
	headerRow.className = "rolling-vine-header-row";

	const headerMain = document.createElement("div");
	headerMain.className = "rolling-vine-header-main";

	const titleBlock = document.createElement("div");
	titleBlock.className = "rolling-vine-title-block";

	const title = document.createElement("h3");
	title.className = "rolling-vine-title";
	title.textContent = "Rolling Vine";

	const headerSubtext = document.createElement("p");
	headerSubtext.className = "rolling-vine-header-subtext";
	headerSubtext.textContent = rvMsg(
		"rollingVineHeaderSubtext",
		"Rolling Vine extracts your statistics to calculate your ratio as it pertains to Vine Jail."
	);

	const syncBtn = document.createElement("button");
	syncBtn.className = "rolling-vine-sync-btn";
	syncBtn.type = "button";

	const syncControls = document.createElement("div");
	syncControls.className = "rolling-vine-sync-controls";

	const syncIcon = document.createElement("span");
	syncIcon.className = "vh-icon-16 vh-icon-sync rolling-vine-sync-icon";
	syncIcon.setAttribute("aria-hidden", "true");

	syncBtn.appendChild(syncIcon);
	syncBtn.appendChild(document.createTextNode(rvMsg("rollingVineSyncButton", "Sync Vine history")));

	const lastSync = document.createElement("div");
	lastSync.className = "rolling-vine-last-sync";
	lastSync.appendChild(document.createTextNode(`${rvMsg("rollingVineLastSyncLabel", "Last sync:")} `));

	const syncValue = document.createElement("span");
	syncValue.setAttribute("data-sync-value", "");
	syncValue.textContent = rvMsg("rollingVineNever", "Never");
	lastSync.appendChild(syncValue);

	syncControls.appendChild(syncBtn);
	syncControls.appendChild(lastSync);

	titleBlock.appendChild(title);
	titleBlock.appendChild(headerSubtext);

	headerMain.appendChild(titleBlock);
	headerMain.appendChild(syncControls);
	headerRow.appendChild(headerMain);

	const stage = document.createElement("div");
	stage.className = "rolling-vine-stage";
	stage.setAttribute("data-sync-stage", "");

	const grid = document.createElement("div");
	grid.className = "rolling-vine-grid";
	grid.appendChild(buildCard(90));
	grid.appendChild(buildCard(60));
	grid.appendChild(buildCard(30));

	fragment.appendChild(headerRow);
	fragment.appendChild(stage);
	fragment.appendChild(grid);

	return fragment;
}

function buildCard(period) {
	const card = document.createElement("article");
	card.className = "rolling-vine-card";
	card.setAttribute("data-period", String(period));

	const title = document.createElement("h4");
	title.textContent = rvMsg("rollingVinePeriodTitle", `Last ${period} days`, [String(period)]);
	card.appendChild(title);

	card.appendChild(buildCardRow(rvMsg("rollingVineLabelOrders", "Orders"), "orders", "0"));
	card.appendChild(buildCardRow(rvMsg("rollingVineLabelReviews", "Reviews"), "reviews", "0"));
	card.appendChild(
		buildCardRow(rvMsg("rollingVineLabelRate", "Review rate"), "rate", rvMsg("rollingVineRateNA", "N/A"))
	);
	card.appendChild(buildRiskRow(period));
	card.appendChild(buildStatusInfoRow());

	return card;
}

function buildRiskRow(period) {
	const row = document.createElement("div");
	row.className = "rolling-vine-row rolling-vine-risk-row";

	const risk = document.createElement("strong");
	risk.setAttribute("data-field", "riskLevel");
	risk.textContent = getRiskLabel(period, "ok", null);

	row.appendChild(risk);
	return row;
}

function buildCardRow(labelText, fieldName, valueText) {
	const row = document.createElement("div");
	row.className = "rolling-vine-row";

	const label = document.createElement("span");
	label.textContent = labelText;

	const value = document.createElement("strong");
	value.setAttribute("data-field", fieldName);
	value.textContent = valueText;

	row.appendChild(label);
	row.appendChild(value);

	return row;
}

function buildStatusInfoRow() {
	const row = document.createElement("div");
	row.className = "rolling-vine-row rolling-vine-status-info-row";

	const value = document.createElement("strong");
	value.setAttribute("data-field", "statusInfo");
	value.textContent = "";

	row.appendChild(value);
	return row;
}

async function hydrateAccountUI() {
	if (rootEl && !rootEl.isConnected) {
		rootEl = null;
		delegationAttached = false;
	}

	if (!rootEl) {
		const existingRoot = document.querySelector(".rolling-vine-root");
		if (existingRoot) {
			rootEl = existingRoot;
		}
	}

	if (!rootEl) {
		return;
	}

	const [metrics, syncState] = await Promise.all([
		RollingVineStorage.getMetrics(),
		RollingVineStorage.getSyncState(),
	]);

	const syncValue = rootEl.querySelector("[data-sync-value]");
	const syncStage = rootEl.querySelector("[data-sync-stage]");
	const syncBtn = rootEl.querySelector(".rolling-vine-sync-btn");

	if (!syncValue || !syncStage || !syncBtn) {
		rootEl = null;
		delegationAttached = false;
		return;
	}

	syncValue.textContent = syncState.lastSuccessAt
		? new Date(syncState.lastSuccessAt).toLocaleString()
		: rvMsg("rollingVineNever", "Never");

	if (syncState.isRunning) {
		syncStage.textContent = getSyncProgressMessage(syncState);
		syncStage.classList.remove("is-error");
		syncStage.classList.add("is-syncing");
		syncBtn.disabled = true;
		syncBtn.classList.add("is-syncing");
		startSyncPolling();
	} else if (syncState.status === "safe-stopped") {
		syncStage.textContent = getSafeStopMessage(syncState);
		syncStage.classList.remove("is-syncing");
		syncStage.classList.add("is-error");
		syncBtn.disabled = false;
		syncBtn.classList.remove("is-syncing");
		stopSyncPolling();
	} else {
		syncStage.textContent = "";
		syncStage.classList.remove("is-syncing", "is-error");
		syncBtn.disabled = false;
		syncBtn.classList.remove("is-syncing");
		stopSyncPolling();
	}

	if (!metrics || !metrics.periods) {
		return;
	}

	for (const period of PERIODS) {
		const card = rootEl.querySelector(`.rolling-vine-card[data-period="${period}"]`);
		if (!card) {
			continue;
		}
		const periodMetrics = metrics.periods[period];
		if (!periodMetrics) {
			continue;
		}

		card.querySelector('[data-field="orders"]').textContent = String(periodMetrics.orders || 0);
		card.querySelector('[data-field="reviews"]').textContent = String(periodMetrics.reviews || 0);
		card.querySelector('[data-field="rate"]').textContent =
			periodMetrics.rate === null ? rvMsg("rollingVineRateNA", "N/A") : `${periodMetrics.rate.toFixed(1)}%`;

		const riskLevelField = card.querySelector('[data-field="riskLevel"]');
		if (riskLevelField) {
			riskLevelField.textContent = getRiskLabel(period, periodMetrics.status, periodMetrics);
		}

		const statusInfoField = card.querySelector('[data-field="statusInfo"]');
		if (statusInfoField) {
			statusInfoField.textContent = computeStatusInfo(periodMetrics);
		}

		card.classList.toggle("is-risk", periodMetrics.status === "at-risk");
	}
}

function computeStatusInfo(periodMetrics) {
	const { status, reviews, orders } = periodMetrics;

	if (status === "ok") {
		if (orders === 0) {
			return "";
		}
		const maxOrders = Math.floor(reviews / 0.6);
		const ordersAllowed = Math.max(0, maxOrders - orders);
		if (ordersAllowed === 1) {
			return rvMsg("rollingVineMoreOrdersAllowedOne", "1 more order allowed");
		}
		return rvMsg("rollingVineMoreOrdersAllowedMany", `${ordersAllowed} more orders allowed`, [
			String(ordersAllowed),
		]);
	}

	if (status === "at-risk") {
		const reviewsNeeded = Math.max(0, Math.ceil(orders * 0.6) - reviews);
		if (reviewsNeeded === 1) {
			return rvMsg("rollingVineMoreReviewsNeededOne", "1 more review needed");
		}
		return rvMsg("rollingVineMoreReviewsNeededMany", `${reviewsNeeded} more reviews needed`, [
			String(reviewsNeeded),
		]);
	}

	return "";
}

function getRiskLabel(period, status, periodMetrics) {
	if (!periodMetrics || (periodMetrics.orders === 0 && periodMetrics.reviews === 0)) {
		return rvMsg("rollingVineFirstScanRequired", "First scan required");
	}

	if (status === "at-risk") {
		const riskKey = rvRiskMessageKey(period);
		return rvMsg(riskKey, rvMsg("rollingVineRisk90", "High risk of Vine Jail"));
	}

	return rvMsg("rollingVineNeutralRiskLabel", "Percentage in safe zone");
}

function delay(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
