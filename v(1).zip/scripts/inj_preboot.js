/**
 * Main-world guards for notification monitor pages on Amazon.
 *
 * Injected by preboot_inj.js at document_start (external script — Amazon CSP
 * blocks inline injection). Runs in the page's JS context (not the extension
 * content-script world) so we can patch Amazon's jQuery, mix_csa, and script
 * loader before Monitor V4 replaces the host DOM.
 *
 * Problem being solved:
 * Monitor V4 mounts on amazon.<tld>/vine/resources#vh-monitor. The bootloader
 * eventually clears document.body and renders React, but Amazon's nav/flyout
 * JavaScript may already be running. It keeps logging harmless warnings
 * ("MIX C004", "Candidate root not found") via Amazon's CSM telemetry.
 *
 * Strategy:
 * - Strip unneeded Amazon script tags (nav, Rufus, Prime flyout). Keep
 *   vvp-context (CSRF + Vine session JSON) — see VVP_SCRIPT below.
 * - Stub mix_csa (Prime analytics entry point for MIX C004).
 * - Wrap ue.log / ue.logError after Amazon creates window.ue — never trap
 *   window.ue itself (breaks ue.viz and other bootstrap).
 * - Patch jQuery .html() / globalEval so flyout AJAX cannot eval MIX scripts.
 *
 * The async block below adds heavier monitor-only patches (MutationObserver
 * shim, scroll listener blocking, etc.) once extension modules can load.
 */

(function () {
	const isMonitorContext = () => {
		try {
			const url = new URL(window.location.href);
			if (/^[^#]+#monitor$/.test(url.href)) return true;
			if (/^\/(?:[^/]+\/)?vine\/resources\/?$/.test(url.pathname) && url.hash.startsWith("#vh-monitor")) {
				return true;
			}
			if (/^\/(?:[^/]+\/)?vine\/vh-monitor\/?$/.test(url.pathname)) return true;
			return false;
		} catch {
			return false;
		}
	};

	if (!isMonitorContext()) return;

	// Never strip: vvp-context JSON (CSRF token, customer id, queue, etc.).
	const VVP_SCRIPT = 'script[data-a-state=\'{"key":"vvp-context"}\']';
	// Strip on sight: nav desktop, Prime flyout, Rufus widgets, Amazon jQuery loader.
	const BLOCKED_AMAZON_SRC =
		/NavDesktopUberAsset|CardJsRuntimeBuzzCopyBuild|PrimeAcquisition|AmazonUIjQuery|RufusPricingChartsWebAssetsBuild|RufusPanelWebAssetsBuildGating|mix_csa|mix_d/i;
	const SILENT_AMAZON_TELEMETRY = /MIX C004|Candidate root not found|Could not register card/i;

	const shouldStripScript = (script) => {
		if (!(script instanceof HTMLScriptElement)) return false;
		if (script.matches?.(VVP_SCRIPT)) return false;
		const src = script.src || "";
		if (src.startsWith("chrome-extension://")) return false;
		if (BLOCKED_AMAZON_SRC.test(src)) return true;
		return true;
	};

	const stripScripts = () => {
		document.querySelectorAll("head script, body script").forEach((script) => {
			if (shouldStripScript(script)) script.remove();
		});
	};
	stripScripts();

	// --- Telemetry silencing (see file header — do not trap window.ue) ---
	const noop = () => {};
	const wrapLogError = (fn) => {
		if (typeof fn !== "function") return noop;
		return function (msg, ...rest) {
			const text = typeof msg === "string" ? msg : msg?.m || "";
			if (SILENT_AMAZON_TELEMETRY.test(text)) return;
			return fn.call(this, msg, ...rest);
		};
	};

	try {
		Object.defineProperty(window, "mix_csa", {
			configurable: true,
			enumerable: true,
			get: () => noop,
			set: () => {},
		});
	} catch {
		window.mix_csa = noop;
	}

	/** Wrap Amazon's ue.log / ue.logError on the live object (preserve ue.count, ue.viz, etc.). */
	const wrapUeInPlace = (ue) => {
		if (!ue || typeof ue !== "object") return;
		if (typeof ue.logError === "function" && !ue.logError.__vhWrapped) {
			ue.logError = wrapLogError(ue.logError);
			ue.logError.__vhWrapped = true;
		}
		if (typeof ue.log === "function" && !ue.log.__vhWrapped) {
			const origLog = ue.log;
			ue.log = function (...args) {
				const text = typeof args[0] === "string" ? args[0] : args[0]?.m || "";
				if (SILENT_AMAZON_TELEMETRY.test(text)) return;
				return origLog.apply(this, args);
			};
			ue.log.__vhWrapped = true;
		}
	};

	if (window.ue) wrapUeInPlace(window.ue);
	const uePoll = window.setInterval(() => {
		if (window.ue) wrapUeInPlace(window.ue);
		if (typeof window.ueLogError === "function" && !window.ueLogError.__vhWrapped) {
			window.ueLogError = wrapLogError(window.ueLogError);
			window.ueLogError.__vhWrapped = true;
		}
	}, 50);
	window.setTimeout(() => window.clearInterval(uePoll), 60_000);

	/** Remove <script> tags from HTML strings before jQuery injects flyout markup. */
	const stripInlineScripts = (html) => {
		if (typeof html !== "string") return html;
		return html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
	};

	/** Patch jQuery as soon as it appears (Amazon may assign window.jQuery after this file runs). */
	const patchJQuery = ($) => {
		if (!$?.fn || $.__vhDomPatch) return $;
		for (const name of ["html", "append", "prepend"]) {
			const orig = $.fn[name];
			if (typeof orig !== "function") continue;
			$.fn[name] = function (...args) {
				if (args.length && !this.length) return this;
				if (args.length && typeof args[0] === "string") {
					args = [stripInlineScripts(args[0]), ...args.slice(1)];
				}
				return orig.apply(this, args);
			};
		}
		if (typeof $.globalEval === "function" && !$.globalEval.__vhPatched) {
			const origEval = $.globalEval;
			$.globalEval = function (code) {
				if (typeof code === "string" && /mix_csa|mix_d|PrimeAcquisition|MIX[\s_]/i.test(code)) return;
				return origEval.apply(this, arguments);
			};
			$.globalEval.__vhPatched = true;
		}
		$.__vhDomPatch = true;
		return $;
	};

	patchJQuery(window.jQuery || window.$);
	for (const jqKey of ["jQuery", "$"]) {
		let jqVal = window[jqKey];
		try {
			Object.defineProperty(window, jqKey, {
				configurable: true,
				enumerable: true,
				get: () => jqVal,
				set: (v) => {
					jqVal = patchJQuery(v);
				},
			});
		} catch {
			// jQuery may already be non-configurable; polling fallback runs in async block.
		}
	}

	// Watch for late-loaded Amazon <script src="..."> tags and remove them.
	try {
		new MutationObserver((mutations) => {
			for (const mutation of mutations) {
				for (const node of mutation.addedNodes) {
					if (node instanceof HTMLScriptElement && shouldStripScript(node)) {
						node.remove();
					}
				}
			}
		}).observe(document.documentElement, { childList: true, subtree: true });
	} catch {
		// Non-fatal.
	}
})();

// --- Async monitor patches (memory / performance; same pages as sync block above) ---
(async function () {
	const { VVP_CONTEXT, AMAZON_MISC } = await import("/scripts/core/amazon/selectors.js");

	const getResolvedCurrentUrl = async () => {
		const hasOrionSignal = /Orion/i.test(navigator.userAgent || "") || "KAGI" in window || "__ORION__" in window;
		try {
			if (hasOrionSignal && chrome?.runtime?.sendMessage) {
				const response = await chrome.runtime.sendMessage({ action: "getSenderTabUrl" });
				if (typeof response?.url === "string") {
					return new URL(response.url);
				}
			}
		} catch {
			// Ignore and fall back to window location.
		}
		try {
			return new URL(window.location.href);
		} catch {
			return null;
		}
	};

	const currentUrl = await getResolvedCurrentUrl();
	const isMonitorContext =
		Boolean(currentUrl && /^[^#]+#monitor$/.test(currentUrl.href)) ||
		Boolean(
			currentUrl &&
				/^\/(?:[^/]+\/)?vine\/resources\/?$/.test(currentUrl.pathname) &&
				currentUrl.hash.startsWith("#vh-monitor")
		) ||
		Boolean(currentUrl && /^\/(?:[^/]+\/)?vine\/vh-monitor\/?$/.test(currentUrl.pathname));

	//In the notification monitor, block the MutationObservers from holding references to the DOM nodes.
	if (isMonitorContext) {
		const BLOCKED_AMAZON_SRC =
			/NavDesktopUberAsset|CardJsRuntimeBuzzCopyBuild|PrimeAcquisition|AmazonUIjQuery|RufusPricingChartsWebAssetsBuild|RufusPanelWebAssetsBuildGating/i;
		const shouldStripHostScript = (script) => {
			if (!(script instanceof HTMLScriptElement)) return false;
			if (script.matches(VVP_CONTEXT.SCRIPT)) return false;
			const src = script.src || "";
			if (src.startsWith("chrome-extension://")) return false;
			if (BLOCKED_AMAZON_SRC.test(src)) return true;
			return true;
		};
		const stripHostScripts = () => {
			document.querySelectorAll(AMAZON_MISC.HEAD_BODY_SCRIPTS).forEach((script) => {
				if (shouldStripHostScript(script)) {
					script.remove();
				}
			});
		};

		stripHostScripts();

		const stripInlineScripts = (html) => {
			if (typeof html !== "string") return html;
			return html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
		};

		// Monkey patch MutationObserver to prevent memory leaks
		const OriginalMutationObserver = window.MutationObserver;

		try {
			new OriginalMutationObserver((mutations) => {
				for (const mutation of mutations) {
					for (const node of mutation.addedNodes) {
						if (node instanceof HTMLScriptElement && shouldStripHostScript(node)) {
							node.remove();
						}
					}
				}
			}).observe(document.documentElement, { childList: true, subtree: true });
		} catch {
			// Non-fatal: script stripping in bootloader/preboot still runs later.
		}

		const patchJQueryDomInjection = () => {
			const $ = window.jQuery || window.$;
			if (!$?.fn || $.__vhDomPatch) return Boolean($?.__vhDomPatch);
			const guard = (name) => {
				const orig = $.fn[name];
				if (typeof orig !== "function") return;
				$.fn[name] = function (...args) {
					if (args.length && !this.length) return this;
					if (args.length && typeof args[0] === "string") {
						args = [stripInlineScripts(args[0]), ...args.slice(1)];
					}
					return orig.apply(this, args);
				};
			};
			guard("html");
			guard("append");
			guard("prepend");
			if (typeof $.globalEval === "function" && !$.globalEval.__vhPatched) {
				const origEval = $.globalEval;
				$.globalEval = function (code) {
					if (typeof code === "string" && /mix_csa|mix_d|PrimeAcquisition|MIX[\s_]/i.test(code)) return;
					return origEval.apply(this, arguments);
				};
				$.globalEval.__vhPatched = true;
			}
			$.__vhDomPatch = true;
			return true;
		};
		if (!patchJQueryDomInjection()) {
			const jqPatchTimer = window.setInterval(() => {
				if (patchJQueryDomInjection()) window.clearInterval(jqPatchTimer);
			}, 50);
			window.setTimeout(() => window.clearInterval(jqPatchTimer), 10000);
		}
		window.MutationObserver = function (callback) {
			// Create observer with wrapped callback that cleans up references
			const observer = new OriginalMutationObserver((mutations, obs) => {
				try {
					// Call original callback
					//callback(mutations, obs); //Do not call the original callback, or it will hold references to the DOM nodes.
				} finally {
					// Clear mutation records to prevent holding references
					mutations.forEach((mutation) => {
						mutation.target = null;
						mutation.previousSibling = null;
						mutation.nextSibling = null;
						mutation.addedNodes = null;
						mutation.removedNodes = null;
					});
				}
			});

			// Copy prototype methods
			observer.observe = OriginalMutationObserver.prototype.observe.bind(observer);
			observer.disconnect = OriginalMutationObserver.prototype.disconnect.bind(observer);
			observer.takeRecords = OriginalMutationObserver.prototype.takeRecords.bind(observer);

			return observer;
		};

		try {
			// Throttle querySelectorAll abuse
			const origQS = document.querySelectorAll.bind(document);
			document.querySelectorAll = function (sel) {
				if (typeof sel === "string" && /hover|tooltip|popover/i.test(sel)) {
					// Skip overly-chatty selectors
					return [];
				}
				return origQS(sel);
			};

			// Shield expensive style reads (offsetHeight/Width)
			const descH = Object.getOwnPropertyDescriptor(Element.prototype, "offsetHeight");
			if (descH && typeof descH.get === "function") {
				const origGetH = descH.get;
				Object.defineProperty(Element.prototype, "offsetHeight", {
					get() {
						try {
							if (this.classList && this.classList.contains("a-popover")) return 0;
						} catch {
							//Do nothing
						}
						return origGetH.call(this);
					},
				});
			}

			const descW = Object.getOwnPropertyDescriptor(Element.prototype, "offsetWidth");
			if (descW && typeof descW.get === "function") {
				const origGetW = descW.get;
				Object.defineProperty(Element.prototype, "offsetWidth", {
					get() {
						try {
							if (this.classList && this.classList.contains("a-popover")) return 0;
						} catch {
							//Do nothing
						}
						return origGetW.call(this);
					},
				});
			}
		} catch (e) {
			console.warn("Patch failed:", e);
		}

		// Block unwanted scroll, pointerleave, and mousedown listeners
		const origAdd = window.addEventListener;
		const origRemove = window.removeEventListener;

		const blockedTypes = ["scroll", "pointerenter", "pointerleave", "mousedown"];

		const whitelistPrefixes = [
			location.origin, // same-origin scripts (optional)
			"chrome-extension", // your extension world
		];

		const getCallerSource = () => {
			const stack = new Error().stack || "";
			const line = stack.split("\\n")[2] || "";
			return line;
		};

		window.addEventListener = function (type, listener, options) {
			if (blockedTypes.includes(type)) {
				const src = getCallerSource();
				const allowed = whitelistPrefixes.some((p) => src.includes(p));
				if (!allowed) {
					return; // ignore main-world event listeners
				}
			}
			return origAdd.call(this, type, listener, options);
		};

		window.removeEventListener = function (type, listener, options) {
			return origRemove.call(this, type, listener, options);
		};
	}
})();

/**
 * Unused as it's causing internal errors.
 * Unsure if there's actually a performance gain for high number of items.
 */
function disableAmzBootloader() {
	// A universal no-op proxy that safely absorbs any property or call
	const noopProxy = new Proxy(function () {}, {
		get: () => noopProxy,
		apply: () => noopProxy,
		set: () => true,
		has: () => true,
	});

	const stub = {
		load: () => noopProxy, // supports .js(), .css(), .log(), etc.
		when: () => ({ execute: () => {}, ready: () => {} }),
		now: () => {},
		require: () => ({}),
		register: () => {},
		trigger: () => {},
		namespace: undefined,
		attribution: undefined,
	};
	Object.freeze(stub);

	const defineSafe = (name) => {
		const desc = Object.getOwnPropertyDescriptor(window, name);
		if (!desc) {
			Object.defineProperty(window, name, {
				configurable: false,
				enumerable: false,
				writable: false,
				value: stub,
			});
		} else {
			try {
				Object.assign(window[name], stub);
			} catch {
				//Do nothing
			}
		}
	};

	["P", "AmazonUIPageJS", "aui", "CreateMonitor", "Profiler", "Scheduler"].forEach(defineSafe);

	console.log("[VH] stealth stub v2 active");
}
