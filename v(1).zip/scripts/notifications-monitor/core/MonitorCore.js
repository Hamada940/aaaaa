// chrome global is used in subclasses

/*global chrome*/

//This file serve the main purpose of reducing the size of the NotificationMonitor.js file.
//It:
// - contain the variables specific to V2 or V3
// - instanciate the specific classes for V2 or V3
// - instanciate the general purpose classes
// - contains some basic functions that are used by the NotificationMonitor that where good to get out of the way.

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { isSafari } from "/scripts/core/utils/BrowserDetection.js";
import { Template } from "/scripts/core/utils/Template.js";
import { Environment } from "/scripts/core/services/Environment.js";
import { VINE_GRID } from "/scripts/core/amazon/selectors.js";
import { Logger } from "/scripts/core/utils/Logger.js";
import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
import { PinMgr } from "/scripts/notifications-monitor/services/PinMgr.js";
import { HookMgr } from "/scripts/core/utils/HookMgr.js";
import { Internationalization, getMessage } from "/scripts/core/services/Internationalization.js";
import { ScreenNotifier, ScreenNotification } from "/scripts/ui/components/ScreenNotifier.js";
import { StyleUtils } from "/scripts/ui/utils/StyleUtils.js";
import { Tooltip } from "/scripts/ui/components/Tooltip.js";
import { BrendaAnnounceQueue } from "/scripts/core/services/BrendaAnnounce.js";
import { ModalMgr } from "/scripts/ui/controllers/ModalMgr.js";
import { NotificationsSoundPlayer } from "/scripts/ui/components/NotificationsSoundPlayer.js";
import { ServerCom } from "/scripts/notifications-monitor/stream/ServerCom.js";
import { ItemsMgr } from "/scripts/notifications-monitor/services/ItemsMgr.js";
import { Websocket } from "/scripts/notifications-monitor/stream/Websocket.js";
import { WebsocketRelayMonitor } from "/scripts/notifications-monitor/stream/WebsocketRelayMonitor.js";
import { AutoLoad } from "/scripts/notifications-monitor/stream/AutoLoad.js";
import { AutoLoadRFY } from "/scripts/notifications-monitor/stream/AutoLoadRFY.js";
import { AutoLoadFAV } from "/scripts/notifications-monitor/stream/AutoLoadFAV.js";
import { AutoLoadScheduler } from "/scripts/notifications-monitor/stream/AutoLoadScheduler.js";
import { MasterSlave } from "/scripts/notifications-monitor/coordination/MasterSlave.js";
import { TileCounter } from "/scripts/notifications-monitor/services/TileCounter.js";
import { NoShiftGrid } from "/scripts/notifications-monitor/services/NoShiftGrid.js";
import { FullGridLayout } from "/scripts/notifications-monitor/services/GridLayoutStrategy.js";
import { ErrorAlertManager } from "/scripts/notifications-monitor/services/ErrorAlertManager.js";
import {
	updateTabTitle as uiUpdateTabTitle,
	updateTabFavicon,
	updateUserTierInfo,
	syncUIFromSettings,
} from "/scripts/notifications-monitor/core/NotificationMonitorUI.js";

class MonitorCore {
	#channelMessageHandler = null;
	#masterActivationToken = 0;

	//Variables linked to monitor V2 vs V3
	_monitorV3Lite = false; //True if the monitor is in V3 Lite mode
	_monitorV3 = false; //True if the monitor is in V3 mode
	_tileSizer = null; //The tile sizer tool for v3 monitor
	_tierMgr = null; //The tier manager object
	_ws = null; //The websocket object
	_autoLoadScheduler = null;
	_autoLoad = null; //The auto load object
	_autoLoadRFY = null; //The auto load RFY object
	_autoLoadFAV = null;
	_isMasterMonitor = false; //True if the monitor is the master monitor
	_noShiftGrid = null; //The no shift grid object
	_gridLayout = null; // FullGridLayout — see GridLayoutStrategy.js

	_fetchLimit = 100; //The fetch limit for the monitor
	_tabTitleTimer = null; // Timer for batching tab title updates
	_gridContainer = null; //The grid container DOM element
	_channel = null;
	#wakeLock = null; // Wake lock instance to prevent duplicate requests
	#wakeLockVisibilityHandler = null; // Visibility change handler reference

	constructor(monitorV3 = false) {
		// Prevent direct instantiation of the abstract class
		if (this.constructor === MonitorCore) {
			throw new TypeError('Abstract class "MonitorLib" cannot be instantiated directly.');
		}

		this._gridContainer = document.querySelector(VINE_GRID.ITEMS);

		this._channel = new BroadcastChannel("VHelper-notification-monitor");
		this._monitorV3 = monitorV3;

		//General purpose classes
		this._settings = new SettingsMgr();
		this._env = new Environment();
		this._tpl = new Template();
		this._log = new Logger();
		this._cryptoKeys = new CryptoKeys();
		this._i18nMgr = new Internationalization();
		this._notificationsMgr = new ScreenNotifier();
		this._tooltipMgr = new Tooltip();
		this._brendaMgr = new BrendaAnnounceQueue();
		this._dialogMgr = new ModalMgr();
		this._soundPlayerMgr = new NotificationsSoundPlayer();
		this._hookMgr = new HookMgr();

		//Notifications Monitor's specific classes - initialize before MasterSlave
		this._serverComMgr = new ServerCom(this);

		this._masterSlave = new MasterSlave(this);
		this._tileCounter = new TileCounter(this);

		this._itemsMgr = new ItemsMgr(this._settings);

		this._pinMgr = new PinMgr();
		this._pinMgr.setGetItemDOMElementCallback(this._itemsMgr.getItemDOMElement.bind(this._itemsMgr));

		this.#getFetchLimit();

		if (
			this._settings.get("notification.monitor.placeholders") &&
			!this._settings.get("notification.monitor.listView") &&
			this._settings.get("general.tileSize.enabled")
		) {
			this._noShiftGrid = new NoShiftGrid(this);
			this._noShiftGrid.initialize(this._gridContainer);
			this._noShiftGrid.insertPlaceholderTiles();
		}

		this._gridLayout = new FullGridLayout(this);
		// Replaced by syncGridLayoutFromSettings after waitForLoad when virtual mode is on.

		// Initialize error alert manager directly
		this._errorAlertManager = new ErrorAlertManager();

		//Wake Lock to keep the screen awake on mobile devices
		// Note: navigator.wakeLock works from content script context (isolated world)
		// It does not need to be injected into the main world context
		if (this._settings.get("notification.monitor.wakeLock") && "wakeLock" in navigator) {
			this.#requestWakeLock();
		}
	}

	/**
	 * Request a wake lock to keep the screen awake
	 * The wake lock is automatically released when the page becomes hidden
	 * @private
	 */
	async #requestWakeLock() {
		// Don't request if we already have an active wake lock
		if (this.#wakeLock && !this.#wakeLock.released) {
			return;
		}

		this._log.add("MONITOR: Requesting wake lock");
		try {
			this.#wakeLock = await navigator.wakeLock.request("screen");
			this._log.add("MONITOR: Wake lock granted");

			// Set up visibility change handler only once
			if (!this.#wakeLockVisibilityHandler) {
				this.#wakeLockVisibilityHandler = async () => {
					if (document.visibilityState === "visible" && this._settings.get("notification.monitor.wakeLock")) {
						try {
							// Wake lock may have been released (null) or is released, re-request it
							if (!this.#wakeLock || this.#wakeLock.released) {
								// Clear the reference before requesting a new one
								this.#wakeLock = null;
								await this.#requestWakeLock();
							}
						} catch (err) {
							// Silently fail - wake lock may not be available or user may have denied permission
							this._log.add("MONITOR: Wake lock re-request failed: " + err.message);
						}
					}
				};
				document.addEventListener("visibilitychange", this.#wakeLockVisibilityHandler);
			}

			// Handle wake lock release (e.g., user manually released it)
			this.#wakeLock.addEventListener("release", () => {
				this._log.add("MONITOR: Wake lock was released");
				this.#wakeLock = null;
			});
		} catch (err) {
			// Wake lock may not be supported, available, or user may have denied permission
			// This is not a critical error, so we just log it
			this._log.add("MONITOR: Wake lock request failed: " + err.message);
			this.#wakeLock = null;
		}
	}

	/**
	 * Set the monitor as master.
	 */
	async setMasterMonitor() {
		const activationToken = ++this.#masterActivationToken;
		this._isMasterMonitor = true;

		//This can be executed early, ensure the settings are loaded.
		await this._settings.waitForLoad();
		// Role may have changed while waiting for async settings load.
		if (!this._isMasterMonitor || activationToken !== this.#masterActivationToken) {
			return;
		}

		//Safari does not support the websocket in the service worker, so we need to use the websocket in the extension context
		if (isSafari() || this._settings.get("notification.connectionMode") == "0") {
			//Tab Mode

			const messageRelayer = new WebsocketRelayMonitor(this);
			this._ws = new Websocket(messageRelayer);
		} else {
			//SW Mode
			this.closeTabWebSocketIfSWMode();
		}
		this._autoLoadScheduler = new AutoLoadScheduler(this);
		this._autoLoad = new AutoLoad(this);
		this._autoLoadRFY = new AutoLoadRFY(this);
		this._autoLoadFAV = new AutoLoadFAV(this);
		if (this._autoLoadScheduler && this._autoLoad) {
			this._autoLoadScheduler.setDisplayUpdateCallback(() => {
				void this._autoLoad?.updateNextAssistedLoadDate?.();
			});
		}
		this.#createListener();
		// Re-check after async setup to avoid signaling wsConnect from a demoted tab.
		if (!this._isMasterMonitor || activationToken !== this.#masterActivationToken) {
			return;
		}
		this._sendMessageToWebsocket({ type: "wsConnect" }); //Ensure the reconnect timer is running
	}

	/**
	 * Send a message to the websocket, using the appropriate messaging channel
	 * @param {string} message
	 */
	async _sendMessageToWebsocket(message) {
		if (!this.#channelMessageHandler) {
			console.trace("Attempt to call _sendMessageToWebsocket when no channel message handler is set");
			return;
		}
		const event = { data: await this._cryptoKeys.encryptJSON(message) };
		this.#channelMessageHandler(event);
	}

	#createListener() {
		// Avoid duplicate listeners when role flaps or setMasterMonitor is called repeatedly.
		if (this.#channelMessageHandler) {
			this._channel.removeEventListener("message", this.#channelMessageHandler);
			this.#channelMessageHandler = null;
		}

		//The monitor sends messages to the Websocket, such as enquiring about the connection status or fetching the last 100 items
		// Store the handler reference for cleanup
		this.#channelMessageHandler = async (event) => {
			const data = await this._cryptoKeys.decryptToJSON(event.data);

			// getConnectionDetailsResponse is SW → monitor only; ServerCom shows the modal, do not forward.
			if (data && data.type === "getConnectionDetailsResponse") {
				return;
			}
			if (isSafari() || this._settings.get("notification.connectionMode") == "0") {
				//The websocket is handled by the content script (this object), simply send the message to the websocket
				//console.log("Sending message to websocket", event.data);
				if (this._ws !== null) {
					this._ws.processMessage(data);
				}
			} else {
				//The websocket is handled by the service worker, send the message to the service worker, which will relay it to the websocket it manages
				//console.log("Sending message to service worker", event.data);
				chrome.runtime.sendMessage(data);
			}
		};
		this._channel.addEventListener("message", this.#channelMessageHandler);
	}

	/**
	 * Set the monitor as slave.
	 */
	setSlaveMonitor() {
		//console.log("[MonitorCore] Setting as SLAVE monitor"); // eslint-disable-line no-console
		// Invalidate any in-flight setMasterMonitor() async activation.
		this.#masterActivationToken++;
		this._isMasterMonitor = false;
		if (this.#channelMessageHandler) {
			this._channel.removeEventListener("message", this.#channelMessageHandler);
			this.#channelMessageHandler = null;
		}
		if (this._ws !== null) {
			this._ws.destroyInstance();
		}
		this._ws = null;
		this._autoLoadFAV?.destroy?.();
		this._autoLoadRFY?.destroy?.();
		this._autoLoad?.destroy?.();
		this._autoLoadScheduler?.destroy?.();
		this._autoLoad = null;
		this._autoLoadRFY = null;
		this._autoLoadFAV = null;
		this._autoLoadScheduler = null;
	}

	/**
	 * When in SW connection mode, close and destroy any tab WebSocket so no tab
	 * connection is active. Call after settings refresh or when becoming master.
	 */
	closeTabWebSocketIfSWMode() {
		const isSWMode = !isSafari() && this._settings.get("notification.connectionMode") == "1";
		if (isSWMode && this._ws !== null) {
			this._ws.destroyInstance();
			this._ws = null;
		}
	}

	//###############################################
	//## UI update functions
	//###############################################

	_updateUserTierInfo() {
		if (this._tierMgr) updateUserTierInfo(this._tierMgr);
	}

	async #getFetchLimit() {
		await this._settings.waitForLoad();

		//Define the fetch limit based on the user's tier
		if (this._settings.isPremiumUser(3)) {
			this._fetchLimit = 300;
		} else if (this._settings.isPremiumUser(2)) {
			this._fetchLimit = 200;
		} else {
			this._fetchLimit = 100;
		}
	}

	_displayToasterNotification(data) {
		this._notificationsMgr.pushNotification(new ScreenNotification(data));
	}

	async _loadUIUserSettings() {
		await this._settings.waitForLoad();

		this._autoTruncateEnabled = this._settings.get("notification.monitor.autoTruncate");
		this._filterQueue = this._settings.get("notification.monitor.filterQueue");
		this._filterType = this._settings.get("notification.monitor.filterType");
		this._sortType = this._settings.get("notification.monitor.sortType");

		syncUIFromSettings({
			autoTruncateEnabled: this._autoTruncateEnabled,
			filterQueue: this._filterQueue,
			filterType: this._filterType,
			sortType: this._sortType,
			autoTruncateLimit: this._settings.get("notification.monitor.autoTruncateLimit"),
			notificationActive: this._settings.get("notification.active"),
			focusMode: this._settings.get("notification.monitor.focusMode"),
		});
	}

	_updateTabFavicon() {
		updateTabFavicon();
	}

	_hideSelector(selector) {
		try {
			document.querySelectorAll(selector).forEach((elem) => {
				elem.style.display = "none";
			});
		} catch (err) {
			//Do nothing
		}
	}

	async _enableItem(notif) {
		if (!notif) {
			return false;
		}
		notif.classList.remove("vh-item-disabled");
		notif.querySelector(".unavailable-banner")?.remove();
	}

	async _disableItem(notif) {
		if (!notif) {
			return false;
		}

		//Remove the banner if it already existed
		notif.querySelector(".unavailable-banner")?.remove();

		//Add a new banner
		const banner = document.createElement("div");
		banner.classList.add("unavailable-banner");
		banner.innerText = getMessage("bootTabUnavailable", "Unavailable");
		banner.style.isolation = "isolate"; // This prevents the banner from inheriting the filter effects
		const imgThumb = notif.querySelector(".vh-img-thumb");
		(imgThumb ?? notif.querySelector(".vh-img-container"))?.appendChild(banner);

		notif.classList.add("vh-item-disabled");
	}

	/**
	 * Check if an item has unknown ETV
	 * @param {Element} etvObj - The ETV element
	 * @returns {boolean} - True if ETV is unknown
	 */
	isUnknownETV(etvObj) {
		// Check for both empty string and items that haven't had ETV set yet
		// When items have unknown ETV, the dataset attributes remain empty strings
		// but the item data might have null values
		return etvObj && (etvObj.dataset.etvMax == "" || etvObj.dataset.etvMax == null);
	}

	async _processNotificationHighlight(notif) {
		if (!notif) {
			return false;
		}

		// Highlight is active when type is set; color is active when group has monitorColor (deprecated: no longer use notification.monitor.highlight.colorActive)
		const isHighlighted = notif.dataset.typeHighlight == 1;
		const isZeroETV =
			notif.dataset.typeZeroETV == 1 && this._settings.get("notification.monitor.zeroETV.colorActive");
		const isUnknownETV =
			notif.dataset.typeUnknownETV == 1 && this._settings.get("notification.monitor.unknownETV.colorActive");
		const isRFY = notif.dataset.queue == "potluck" && this._settings.get("notification.monitor.rfy.colorActive");

		// Get monitor color from group if available, otherwise use default
		let highlightColor = null;
		const highlightGroupId = notif.dataset.highlightGroupId;
		if (highlightGroupId && isHighlighted) {
			const { getGroupById } = await import("/scripts/core/utils/KeywordGroupsManager.js");
			const group = await getGroupById(this._settings, highlightGroupId);
			if (group) {
				// Use monitorColor if set, otherwise fall back to default
				if (group.monitorColor !== null && group.monitorColor !== undefined) {
					highlightColor = group.monitorColor;
				} else {
					// If monitorColor is explicitly null, don't highlight (use null)
					highlightColor = null;
				}
			}
		}

		const zeroETVColor = this._settings.get("notification.monitor.zeroETV.color");
		const unknownETVColor = this._settings.get("notification.monitor.unknownETV.color");
		const rfyColor = this._settings.get("notification.monitor.rfy.color");
		const debugItemProcessing = this._settings.get("general.debugItemProcessing");
		const ignoreUnknownETVhighlight = this._settings.get(
			"notification.monitor.highlight.ignoreUnknownETVhighlight"
		);
		const ignore0ETVhighlight = this._settings.get("notification.monitor.highlight.ignore0ETVhighlight");
		// Debug logging for styling application
		if (debugItemProcessing) {
			const asin = notif.id?.replace("vh-notification-", "") || "unknown";
			console.log("[DEBUG-ETV-STYLING] Processing highlight/color for item:", {
				asin,
				typeHighlight: notif.dataset.typeHighlight,
				typeZeroETV: notif.dataset.typeZeroETV,
				typeUnknownETV: notif.dataset.typeUnknownETV,
				isHighlighted,
				isZeroETV,
				isUnknownETV,
				highlightGroupId,
				customHighlightColor: highlightGroupId && isHighlighted ? highlightColor : null,
				ignoreUnknownETVhighlight: ignoreUnknownETVhighlight,
				ignore0ETVhighlight: ignore0ETVhighlight,
				willApplyStriped:
					(isUnknownETV && isHighlighted && !ignoreUnknownETVhighlight) ||
					(isZeroETV && isHighlighted && !ignore0ETVhighlight),
				timestamp: new Date().toISOString(),
			});
		}

		// Use StyleUtils to handle background styling
		// Only apply highlight if highlightColor is not null
		if (isHighlighted && highlightColor !== null) {
			if (isZeroETV && !ignore0ETVhighlight) {
				const gradient = StyleUtils.createStripedGradient(zeroETVColor, highlightColor);
				StyleUtils.applyBackground(notif, gradient, true);
				if (debugItemProcessing) {
					console.log("[DEBUG-ETV-STYLING] Applied Zero ETV + Highlight striped styling", {
						asin: notif.id?.replace("vh-notification-", ""),
					});
				}
			} else if (isUnknownETV && !ignoreUnknownETVhighlight) {
				const gradient = StyleUtils.createStripedGradient(unknownETVColor, highlightColor);
				StyleUtils.applyBackground(notif, gradient, true);
				if (debugItemProcessing) {
					console.log("[DEBUG-ETV-STYLING] Applied Unknown ETV + Highlight striped styling", {
						asin: notif.id?.replace("vh-notification-", ""),
					});
				}
			} else {
				StyleUtils.applyBackground(notif, highlightColor, false);
				if (debugItemProcessing) {
					console.log("[DEBUG-ETV-STYLING] Applied Highlight solid color", {
						asin: notif.id?.replace("vh-notification-", ""),
					});
				}
			}
		} else if (isZeroETV) {
			StyleUtils.applyBackground(notif, zeroETVColor, false);
			if (debugItemProcessing) {
				console.log("[DEBUG-ETV-STYLING] Applied Zero ETV solid color", {
					asin: notif.id?.replace("vh-notification-", ""),
				});
			}
		} else if (isUnknownETV) {
			StyleUtils.applyBackground(notif, unknownETVColor, false);
			if (debugItemProcessing) {
				console.log("[DEBUG-ETV-STYLING] Applied Unknown ETV solid color", {
					asin: notif.id?.replace("vh-notification-", ""),
				});
			}
		} else if (isRFY) {
			StyleUtils.applyBackground(notif, rfyColor, false);
			if (debugItemProcessing) {
				console.log("[DEBUG-ETV-STYLING] Applied RFY solid color", {
					asin: notif.id?.replace("vh-notification-", ""),
				});
			}
		} else {
			// Clear any existing background when no styling should be applied
			StyleUtils.clearBackgrounds(notif);
			if (debugItemProcessing) {
				console.log("[DEBUG-ETV-STYLING] No styling applied - cleared backgrounds", {
					asin: notif.id?.replace("vh-notification-", ""),
				});
			}
		}
	}

	_blurItemFound(notif) {
		if (!notif) {
			return false;
		}

		//Blur the thumbnail and title
		const img = notif.querySelector(".vh-img-container>img");
		if (img) {
			if (this._settings.get("general.unblurImageOnHover")) {
				img.classList.add("dynamic-blur");
			} else {
				img.classList.add("blur");
			}
		}
		notif.querySelector(".vvp-item-product-title-container>a")?.classList.add("dynamic-blur");
	}

	_formatETV(etv) {
		let formattedETV = "";
		if (etv != null) {
			formattedETV = new Intl.NumberFormat(this._i18nMgr.getLocale(), {
				style: "currency",
				currency: this._i18nMgr.getCurrency(),
			}).format(etv);
		}
		return formattedETV;
	}

	_formatDate(date = null, timeonly = false) {
		if (date == null) {
			date = new Date();
		}
		if (date === "undefined" || date.toString() == "Invalid Date") {
			return "N/A";
		}
		try {
			if (timeonly) {
				return new Intl.DateTimeFormat(this._i18nMgr.getLocale(), {
					hour: "2-digit",
					minute: "2-digit",
					second: "2-digit",
					hour12: !this._settings.get("i18n.24hrsFormat"),
					hourCycle: "h23",
				}).format(date);
			}
			return new Intl.DateTimeFormat(this._i18nMgr.getLocale(), {
				month: "2-digit",
				day: "2-digit",
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit",
				hour12: !this._settings.get("i18n.24hrsFormat"),
				hourCycle: "h23",
			}).format(date);
		} catch (err) {
			console.log("Date format invalid: " + date); // eslint-disable-line no-console
			return "N/A";
		}
	}

	/**
	 * Initialize event listeners for tab title updates
	 * This should be called after HookMgr is available
	 */
	_initializeTabTitleListener() {
		if (this._hookMgr) {
			// Listen to visibility count changes
			this._hookMgr.hookBind("nm-update-tab-title", (data) => {
				this._updateTabTitle();
			});
		}
		this._updateTabTitle();
	}

	async _updateTabTitle() {
		const visibleTilesCount = this._tileCounter.getCount();
		uiUpdateTabTitle(visibleTilesCount);

		const debugTabTitle = this._settings.get("general.debugTabTitle");
		if (debugTabTitle) {
			console.log(`[TabTitle] Updated to: ${visibleTilesCount}`, {
				providedCount: visibleTilesCount,
				timestamp: new Date().toISOString(),
			});
		}
	}

	// Helper method to preserve scroll position during DOM operations
	_preserveScrollPosition(callback) {
		// Save current scroll position
		const scrollPosition = window.scrollY;

		// Execute the DOM operation
		callback();

		// Restore scroll position
		window.scrollTo({
			top: scrollPosition,
			behavior: "auto", // Use "auto" instead of "smooth" to prevent visible jumping
		});
	}

	_moveNotifToTop(notif) {
		const container = document.getElementById(VINE_GRID.ITEMS_GRID_ID);
		if (!container || !notif) {
			return;
		}

		this._preserveScrollPosition(() => {
			// Keep virtual spacers + placeholder padding intact by inserting before the
			// first real tile in the rendered window.
			const firstRealTile = container.querySelector(".vvp-item-tile:not(.vh-placeholder-tile)");
			if (firstRealTile && firstRealTile.parentNode === container) {
				container.insertBefore(notif, firstRealTile);
				return;
			}

			// Fallback for empty grids / placeholder-only windows.
			container.appendChild(notif);
		});
	}

	/**
	 * Get the TileCounter instance for testing purposes
	 * @returns {TileCounter} The TileCounter instance
	 */
	getTileCounter() {
		return this._tileCounter;
	}
}

export { MonitorCore };
