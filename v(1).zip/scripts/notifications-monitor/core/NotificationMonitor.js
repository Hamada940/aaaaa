/*global chrome*/

//Todo: insertTileAccordingToETV and ETVChangeRepositioning are very similar. Could we merge some logic?

import { YMDHiStoISODate } from "/scripts/core/utils/DateHelper.js";
import { escapeHTML, unescapeHTML } from "/scripts/core/utils/StringHelper.js";
import { MonitorCore } from "/scripts/notifications-monitor/core/MonitorCore.js";
import { Item } from "/scripts/core/models/Item.js";
import { HiddenListMgr } from "/scripts/core/services/HiddenListMgr.js";
import { KeywordMatcherService } from "/scripts/core/services/KeywordMatcherService.js";
import { WebhookQueue } from "../stream/WebhookQueue.js";
import { buildTruncationSortArray, computeKeepRemove } from "../services/TruncationLogic.js";
import { debugTruncation } from "../debug/TruncationDebug.js";
import {
	debugFetchComplete,
	debugVisibilityChange,
	debugFilterCheck,
	debugInitTileCounter,
	debugItemProcessing,
	debugSound,
	debugTrackListener,
	debugUntrackListener,
} from "../debug/MonitorDebug.js";
import {
	updateFilterCount as uiUpdateFilterCount,
	updatePauseButtonUI,
	showPauseOverlay,
	hidePauseOverlay,
	setFetchButtonsDisabled as uiSetFetchButtonsDisabled,
	showUndoBanner as uiShowUndoBanner,
	updateUndoBanner as uiUpdateUndoBanner,
	hideUndoBanner as uiHideUndoBanner,
} from "/scripts/notifications-monitor/core/NotificationMonitorUI.js";
import {
	attachUIHandlers,
	handlePauseClick as uiHandlePauseClick,
	handleHoverPauseEnd as uiHandleHoverPauseEnd,
	handleReportClick as uiHandleReportClick,
	handleConnectionDetailsClick as uiHandleConnectionDetailsClick,
	handleClearMonitorPassive as uiHandleClearMonitorPassive,
	handleClearMonitorDialog as uiHandleClearMonitorDialog,
	handleClearUnavailablePassive as uiHandleClearUnavailablePassive,
	handleClearUnavailableDialog as uiHandleClearUnavailableDialog,
} from "/scripts/notifications-monitor/core/NotificationMonitorUIHandlers.js";
import { getMonitorToolbarKeybindingActions } from "/scripts/core/keybindings/MonitorToolbarKeybindings.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";
import { TileIntegrityService } from "/scripts/notifications-monitor/integrity/TileIntegrityService.js";
import { NotificationLiteDetailsModal } from "/scripts/notifications-monitor/core/NotificationLiteDetailsModal.js";
import { syncGridLayoutFromSettings } from "/scripts/notifications-monitor/services/GridLayoutStrategy.js";
import {
	itemMapExceedsTruncateLimit,
	countVisibleRemovalsAmong,
} from "/scripts/notifications-monitor/services/MonitorTruncationHelpers.js";
import { runPendingClearFinalization } from "/scripts/notifications-monitor/services/MonitorClearActions.js";
import { runAfterItemFoundPlacement } from "/scripts/notifications-monitor/services/NotificationItemDispatcher.js";
import { syncSeeDetailsInputFromItem } from "/scripts/notifications-monitor/services/MonitorSeeDetailsDataset.js";
import { lazyImageLoader } from "/scripts/notifications-monitor/services/LazyImageLoader.js";
import { buildSchemaFromLiveElement } from "/scripts/notifications-monitor/integrity/schemaBuilder.js";
import {
	collectAffectedTilesFromMutations,
	validateAffectedLockedTiles,
} from "/scripts/notifications-monitor/integrity/tileIntegrityQueries.js";
import { isAllowedVHelperInternalIntegrityFailure } from "/scripts/notifications-monitor/integrity/internalIntegrityFailure.js";
import { sendIntegrityIncidentReport } from "/scripts/notifications-monitor/services/IntegrityIncidentReporter.js";
import {
	handleGridMouseover,
	handleGridClick,
} from "/scripts/notifications-monitor/core/NotificationMonitorGridPointerHandlers.js";

/**
 * Store dates in data-* attributes as ISO 8601 so dataset values parse reliably in all browsers
 * (locale strings from Intl or Date#toString are not safely parseable).
 * @param {Date|string|number|null|undefined} value
 * @returns {string} ISO string or "" if missing/invalid
 */
function toIsoDatasetValue(value) {
	if (value == null || value === "") return "";
	const d = value instanceof Date ? value : new Date(value);
	return Number.isNaN(d.getTime()) ? "" : d.toISOString();
}

// Minimum ETV change to trigger repositioning
const ETV_REPOSITION_THRESHOLD = 0.01;

// Memory debugging - will be initialized if debug mode is enabled
let MemoryDebugger = null;
let memoryDebuggerInitialized = false;

// Create a promise that will be resolved when we check for debug mode
window.MEMORY_DEBUGGER_READY = new Promise((resolve) => {
	// This will be resolved when NotificationMonitor is initialized
	window._resolveMemoryDebuggerReady = resolve;
});

// For adding hidden items from NM's hide icon (if setting enabled)
var HiddenList = new HiddenListMgr();

// Also create a simple getter function that works after page load
window.getMemoryDebugger = function () {
	if (window.MEMORY_DEBUGGER) {
		return window.MEMORY_DEBUGGER;
	}
	console.log(
		'Memory debugger not available. Enable with: localStorage.setItem("vh_debug_memory", "true") and reload'
	);
	return null;
};

//const TYPE_SHOW_ALL = -1;
const TYPE_REGULAR = 0;
const TYPE_RFY = 1;
const TYPE_ZEROETV = 2;
const TYPE_HIGHLIGHT = 3;
const TYPE_UNKNOWN_ETV = 4;
const TYPE_HIGHLIGHT_OR_ZEROETV = 9;

// Filter names lookup table
const FILTER_NAMES = {
	[-1]: "All",
	[TYPE_REGULAR]: "Regular only",
	[TYPE_ZEROETV]: "Zero ETV only",
	[TYPE_HIGHLIGHT]: "KW match only",
	[TYPE_UNKNOWN_ETV]: "Unknown ETV only",
	[TYPE_HIGHLIGHT_OR_ZEROETV]: "Zero ETV or KW match only",
};

const TYPE_DATE_ASC = "date_asc";
const TYPE_DATE_DESC = "date_desc";
const TYPE_PRICE_DESC = "price_desc";
const TYPE_PRICE_ASC = "price_asc";
const CLEAR_UNDO_SECONDS = 5;

const EXTERNAL_CHANGES_LOCK_DEBUG = true;

class NotificationMonitor extends MonitorCore {
	_feedPaused = false;
	#pausedByMouseoverSeeDetails = false;
	_feedPausedAmountStored = 0;
	_fetchingRecentItems;
	_gridContainer = null;
	_gridContainerWidth = 0;
	_wsErrorMessage = null;
	_mostRecentItemDate = null;
	_mostRecentItemDateDOM = null;
	_itemTemplateFile = "tile_gridview.html";
	_searchText = ""; // Current search text
	_searchDebounceTimer = null; // Timer for debouncing search
	_autoTruncateDebounceTimer = null; // Timer for debouncing autoTruncate
	// UI User settings (will be loaded from storage)
	_autoTruncateEnabled = true;
	_filterQueue = -1;
	_filterType = -1;
	_sortType = TYPE_DATE_DESC;
	_gridEventManager = null;
	_liteDetailsModal = null;

	#pinDebounceTimer = null;
	#pinDebounceClickable = true;

	/** Current filter/sort from this tab's dropdowns (so each tab can have its own criteria). */
	#getCurrentFilterQueue() {
		const el = document.querySelector("select[name='filter-queue']");
		return el != null ? el.value : this._filterQueue;
	}
	#getCurrentFilterType() {
		const el = document.querySelector("select[name='filter-type']");
		return el != null ? el.value : this._filterType;
	}
	#getCurrentSortType() {
		const el = document.querySelector("select[name='sort-queue']");
		return el != null ? el.value : this._sortType;
	}

	/**
	 * Enables or disables virtual grid from persisted settings. See `syncGridLayoutFromSettings`.
	 */
	syncVirtualGridFromSettings() {
		syncGridLayoutFromSettings(this, () => this.#sortItems());
	}

	// Track items currently being processed for ETV to prevent duplicate processing
	#etvProcessingItems = new Set();

	// Set to track ASINs being processed to prevent concurrent additions
	#processingASINs = new Set();

	// Store event handler references for cleanup
	#eventHandlers = {
		grid: null,
		document: null,
		documentClick: null,
		window: {
			keydown: null,
			keyup: null,
			scroll: null,
		},
		buttons: new Map(),
	};

	// Disconnect button click handler reference
	#disconnectButtonHandler = null;

	// Undo banner and pending clear tracking
	#pendingClearAction = null;
	#clearMonitorButton = null;
	#clearUnavailableButton = null;
	#originalClearMonitorText = "All";
	#originalClearUnavailableText = "Unavail.";

	// Lazy-initialized keyword matcher for highlight/hide/blur matching (keyword groups only)
	#keywordMatcher = null;
	#keywordMatcherPromise = null;

	#webhookQueue = null;

	// Tile DOM integrity: full DOM validation against tile + toolbar templates (see integrity/ module)
	#tileIntegrityLocked = false;
	#tileIntegrityObserver = null;
	/** @type {import("/scripts/notifications-monitor/integrity/TileIntegrityService.js").TileIntegrityService} */
	#tileIntegrityService = null;
	/** Set during #bulkRemoveItems so the integrity observer skips validation (our own DOM changes). */
	#bulkOperationInProgress = false;
	/** Pending mutation records for debounced integrity check (avoids GPU/main-thread thrashing in WebKit). */
	#tileIntegrityPendingMutations = null;
	/** rAF id for debounced tile integrity check. */
	#tileIntegrityRafId = null; // raf = Request Animation Frame

	constructor(monitorV3 = false) {
		super(monitorV3);

		// Prevent direct instantiation of the abstract class
		if (this.constructor === NotificationMonitor) {
			throw new TypeError('Abstract class "NotificationMonitor" cannot be instantiated directly.');
		}

		// Initialize memory debugger if enabled in settings
		this._initializeMemoryDebugger();

		// Initialize debug mode for TileCounter and monitor exposure
		this._initializeDebugMode();

		// Always register monitor instance for access by other components (e.g., VariantButton)
		window.VHelper = window.VHelper || {};
		window.VHelper.monitor = this;

		// Register this instance for testing if the expose script is loaded
		if (window.VHelper && typeof window.VHelper.registerMonitor === "function") {
			window.VHelper.registerMonitor(this);
		}

		// Apply Order Now button colors

		this.#applyOrderNowButtonColors();
		this.#originalClearMonitorText = getMessage("nmClearAllShort", "All");
		this.#originalClearUnavailableText = getMessage("nmClearUnavailableShort", "Unavail.");

		this.#tileIntegrityService = new TileIntegrityService();
		this.#webhookQueue = new WebhookQueue(this._settings);
		this._liteDetailsModal = new NotificationLiteDetailsModal({
			settings: this._settings,
			env: this._env,
			i18n: this._i18nMgr,
			dialogMgr: this._dialogMgr,
			showToaster: (data) => this._displayToasterNotification(data),
		});
	}

	/**
	 * Update the filter count display in the header
	 * @private
	 */
	#updateFilterCount() {
		uiUpdateFilterCount(this._searchText, this.#getCurrentFilterQueue(), this.#getCurrentFilterType());
	}

	/**
	 * Override parent method to update filter count after loading settings
	 */
	async _loadUIUserSettings() {
		// Call parent method to load settings
		await super._loadUIUserSettings();

		// Update filter count after settings are loaded
		this.#updateFilterCount();
	}

	/**
	 * Override: unlock tile before DOM change, then re-lock on next rAF (after observer's rAF) so integrity skips during DOM changes.
	 */
	async _enableItem(notif) {
		const wasLocked = this.#tileIntegrityService?.isTileLocked(notif);
		if (wasLocked) this.#tileIntegrityService?.unlockTile(notif);
		await super._enableItem(notif);
		if (wasLocked) this.#tileIntegrityService?.lockTileOnNextFrame(notif);
	}

	/**
	 * Override: unlock tile before DOM change, then re-lock on next rAF (after observer's rAF) so integrity skips during DOM changes.
	 */
	async _disableItem(notif) {
		const wasLocked = this.#tileIntegrityService?.isTileLocked(notif);
		if (wasLocked) this.#tileIntegrityService?.unlockTile(notif);
		await super._disableItem(notif);
		if (wasLocked) this.#tileIntegrityService?.lockTileOnNextFrame(notif);
	}

	/**
	 * Initialize debug mode for TileCounter and monitor exposure
	 * @private
	 */
	async _initializeDebugMode() {
		await this._settings.waitForLoad();
		await debugInitTileCounter(this);
	}

	/**
	 * Lazy-init KeywordMatcherService for highlight/hide/blur matching (keyword groups only).
	 * @returns {Promise<KeywordMatcherService>}
	 */
	async #ensureKeywordMatcher() {
		if (this.#keywordMatcher) return this.#keywordMatcher;
		if (this.#keywordMatcherPromise) return this.#keywordMatcherPromise;
		this.#keywordMatcherPromise = (async () => {
			const isPremiumTier2 = this._settings.isPremiumUser(2);
			const matcher = new KeywordMatcherService(this._settings, isPremiumTier2);
			await matcher.initialize();
			this.#keywordMatcher = matcher;
			return matcher;
		})();
		return this.#keywordMatcherPromise;
	}

	/**
	 * Initialize the memory debugger if enabled in settings
	 * @private
	 */
	async _initializeMemoryDebugger() {
		// Wait for settings to load
		await this._settings.waitForLoad();

		// Check if memory debugging is enabled
		const debugMemoryEnabled = this._settings.get("general.debugMemory") === true;

		if (debugMemoryEnabled && !memoryDebuggerInitialized) {
			memoryDebuggerInitialized = true;

			try {
				// Dynamically import the memory debugger
				const module = await import("/scripts/notifications-monitor/debug/MemoryDebugger.js");
				MemoryDebugger = module.default || module.MemoryDebugger || module;
				console.log("🔍 Memory Debugger loaded. Use window.MEMORY_DEBUGGER to access."); // eslint-disable-line no-console

				// Create the global instance
				if (!window.MEMORY_DEBUGGER && MemoryDebugger) {
					const debuggerInstance = new MemoryDebugger();

					// Store the debugger instance
					window.MEMORY_DEBUGGER = debuggerInstance;

					console.log("🔍 Memory Debugger initialized. Starting monitoring..."); // eslint-disable-line no-console

					// Create global API that can be accessed from console
					window.VH_MEMORY = {
						takeSnapshot: (name) => {
							if (debuggerInstance) {
								return debuggerInstance.takeSnapshot(name);
							}
							console.error("Memory debugger not available");
							return null;
						},
						generateReport: () => {
							if (debuggerInstance) {
								return debuggerInstance.generateReport();
							}
							console.error("Memory debugger not available");
							return null;
						},
						detectLeaks: () => {
							if (debuggerInstance) {
								return debuggerInstance.detectLeaks();
							}
							console.error("Memory debugger not available");
							return null;
						},
						checkDetachedNodes: () => {
							if (debuggerInstance) {
								return debuggerInstance.checkDetachedNodes();
							}
							console.error("Memory debugger not available");
							return null;
						},
						cleanup: () => {
							if (debuggerInstance) {
								return debuggerInstance.cleanup();
							}
							console.error("Memory debugger not available");
							return null;
						},
						stopMonitoring: () => {
							if (debuggerInstance) {
								return debuggerInstance.stopMonitoring();
							}
							console.error("Memory debugger not available"); // eslint-disable-line no-console
							return null;
						},
					};

					// Make it available globally
					globalThis.VH_MEMORY = window.VH_MEMORY;

					console.log("📊 Memory Debugger API available at window.VH_MEMORY"); // eslint-disable-line no-console
					console.log("Available methods:"); // eslint-disable-line no-console
					console.log("  - VH_MEMORY.takeSnapshot(name)"); // eslint-disable-line no-console
					console.log("  - VH_MEMORY.generateReport()"); // eslint-disable-line no-console
					console.log("  - VH_MEMORY.detectLeaks()"); // eslint-disable-line no-console
					console.log("  - VH_MEMORY.checkDetachedNodes()"); // eslint-disable-line no-console
					console.log("  - VH_MEMORY.cleanup()"); // eslint-disable-line no-console
					console.log("  - VH_MEMORY.stopMonitoring()"); // eslint-disable-line no-console

					// Resolve the promise
					if (window._resolveMemoryDebuggerReady) {
						window._resolveMemoryDebuggerReady(debuggerInstance);
					}
				}
			} catch (error) {
				console.error("Failed to initialize MemoryDebugger:", error); // eslint-disable-line no-console
				if (window._resolveMemoryDebuggerReady) {
					window._resolveMemoryDebuggerReady(null);
				}
			}
		} else {
			// Resolve the promise with null if not enabled
			if (window._resolveMemoryDebuggerReady) {
				window._resolveMemoryDebuggerReady(null);
			}
		}
	}

	//###################################################################
	// DOM element related methods
	//###################################################################

	/**
	 * Determine if the item should be displayed based on the filters settings. Will hide the item if it doesn't match the filters.
	 * @param {object} node - The DOM element of the tile
	 * @param {boolean} unpausing - Whether we're unpausing the feed
	 * @param {boolean} skipLogging - Skip debug logging for bulk operations
	 * @returns {boolean} - If the node should be visible.
	 */
	#processNotificationFiltering(node, unpausing = false, skipLogging = false) {
		if (!node) {
			return false;
		}

		// Skip filtering for placeholder elements
		if (node.classList.contains("vh-placeholder-tile")) {
			return false;
		}

		const notificationTypeZeroETV = parseInt(node.dataset.typeZeroETV) === 1;
		const notificationTypeHighlight = parseInt(node.dataset.typeHighlight) === 1;
		const notificationTypeUnknownETV = parseInt(node.dataset.typeUnknownETV) === 1;
		const queueType = node.dataset.queue;
		const beforeDisplay = node.dataset.display;

		//Feed Paused
		if (node.dataset.feedPaused == "true") {
			this.#setTileDisplay(node, "none");
			return false;
		}

		// Gold item filter for silver users
		if (
			/* this._monitorV3 && */
			!this._tierMgr.isGold() &&
			this._settings.get("notification.monitor.hideGoldNotificationsForSilverUser")
		) {
			const etvObj = node.querySelector("div.etv");
			if (
				etvObj &&
				this._tierMgr.getSilverTierETVLimit() != null &&
				parseFloat(etvObj.dataset.etvMin) > this._tierMgr.getSilverTierETVLimit()
			) {
				this.#setTileDisplay(node, "none");
				return false;
			}
		}

		// Search filter - if search text is not empty, check if item matches
		if (this._searchText.trim()) {
			const title = node.querySelector(".a-truncate-full")?.innerText?.toLowerCase() || "";
			if (!title.includes(this._searchText.toLowerCase().trim())) {
				this.#setTileDisplay(node, "none");
				return false;
			}
		}

		// Simplified filter logic using a lookup table
		const filterVisibility = {
			[-1]: () => true, // Show all
			[TYPE_HIGHLIGHT_OR_ZEROETV]: () => notificationTypeZeroETV || notificationTypeHighlight,
			[TYPE_HIGHLIGHT]: () => notificationTypeHighlight,
			[TYPE_ZEROETV]: () => notificationTypeZeroETV,
			[TYPE_REGULAR]: () => !notificationTypeZeroETV && !notificationTypeHighlight,
			[TYPE_UNKNOWN_ETV]: () => notificationTypeUnknownETV,
		};

		const shouldBeVisible = filterVisibility[this.#getCurrentFilterType()]?.() || false;

		const asin = node.dataset.asin;
		const typeHighlight = parseInt(node.dataset.typeHighlight) || 0;
		const typeZeroETV = parseInt(node.dataset.typeZeroETV) || 0;
		debugFilterCheck(this, {
			asin,
			typeHighlight,
			typeZeroETV,
			currentFilter: this.#getCurrentFilterType(),
			filterName: FILTER_NAMES[this.#getCurrentFilterType()] || "Unknown",
			notificationTypeHighlight,
			notificationTypeZeroETV,
			shouldBeVisible,
			visibilityMismatch:
				this.#getCurrentFilterType() === TYPE_HIGHLIGHT && typeHighlight === 1 && !shouldBeVisible,
		});

		if (!unpausing) {
			this.#setTileDisplay(node, shouldBeVisible ? "flex" : "none");
		}

		if (!skipLogging) {
			const afterDisplay = node.dataset.display;
			if (beforeDisplay !== afterDisplay) {
				debugVisibilityChange(this, {
					asin: node.dataset.asin,
					beforeDisplay,
					afterDisplay,
					typeZeroETV: notificationTypeZeroETV,
					typeHighlight: notificationTypeHighlight,
					currentFilter: this.#getCurrentFilterType(),
					filterName: FILTER_NAMES[this.#getCurrentFilterType()] || "Unknown",
				});
				if (this._tileCounter) {
					this._tileCounter.recountVisibleTiles(100, false, {
						source: "visibility-change",
						asin: node.dataset.asin,
					});
				}
			}
		}

		// Queue filter - combine with type filter using AND logic
		if (this.#getCurrentFilterQueue() == "-1") {
			// No queue filter active, use type filter result
			return shouldBeVisible;
		} else {
			// Queue filter is active
			const queueMatches = queueType == this.#getCurrentFilterQueue();

			// Item is visible only if it passes BOTH filters (when both are active)
			const finalVisibility = shouldBeVisible && queueMatches;

			if (!unpausing) {
				this.#setTileDisplay(node, finalVisibility ? "flex" : "none");
			}
			return finalVisibility;
		}
	}

	/**
	 * Disable gold items for silver users
	 * Will try to detect if the item is gold and if it is, it will hide the See Details button and the Gold tier only button.
	 * @param {object} notif - The DOM element of the tile
	 * @param {boolean} updateTier - If true, update the tier of the item
	 */
	// eslint-disable-next-line no-unused-private-class-members
	#disableGoldItemsForSilverUsers(notif, updateTier = false) {
		if (!notif || this._monitorV3Lite) {
			return;
		}

		//If the user is silver and the item is gold.
		if (!this._tierMgr.isGold() && notif.dataset.tier !== "silver") {
			const etvObj = notif.querySelector("div.etv");

			if (
				this._tierMgr.getSilverTierETVLimit() != null &&
				parseFloat(etvObj.dataset.etvMin) > this._tierMgr.getSilverTierETVLimit()
			) {
				//Remove the See Details button for item outside the tier limit.
				const vvpDetailsBtn = notif.querySelector(".vvp-details-btn, .vh-details-btn");
				if (vvpDetailsBtn) {
					vvpDetailsBtn.style.display = "none";
				}
				const vhGoldTierOnly = notif.querySelector(".vh-gold-tier-only");
				if (vhGoldTierOnly) {
					vhGoldTierOnly.remove();
				}

				//Create a replacement button with no action linked it.
				const btn = document.createElement("span");
				btn.classList.add("a-button", "vh-gold-tier-only");
				btn.innerText = getMessage("nmGoldTierOnly", "Gold tier only");
				//Insert at the end of .vvp-item-tile-content
				notif.querySelector(".vvp-item-tile-content").appendChild(btn);

				// Re-filter this item to apply gold tier filtering, ensuring it's hidden if the setting is enabled
				if (this._settings.get("notification.monitor.hideGoldNotificationsForSilverUser")) {
					this.#processNotificationFiltering(notif);
				}
			}
		} else if (updateTier) {
			const vvpDetailsBtn = notif.querySelector(".vvp-details-btn, .vh-details-btn");
			if (vvpDetailsBtn) {
				vvpDetailsBtn.style.display = "unset";
			}
			const vhGoldTierOnly = notif.querySelector(".vh-gold-tier-only");
			if (vhGoldTierOnly) {
				vhGoldTierOnly.remove();
			}
		}
	}

	/**
	 * Mark an item as unavailable
	 * @param {string} asin - The ASIN of the item
	 */
	async markItemUnavailable(asin) {
		// Update the item data first
		this._itemsMgr.markItemUnavailable(asin);

		// Then update the DOM
		const notif = this._itemsMgr.getItemDOMElement(asin);
		this._disableItem(notif);
	}

	/**
	 * When the fetch recent items is completed, this function is called.
	 * It will unbuffer the feed if it is paused and sort the items.
	 */
	async fetchRecentItemsEnd() {
		debugTruncation("truncation.fetchRecentItemsEnd", this);
		if (this._settings.get("general.debugSound")) {
			console.log("[SOUND DEBUG] Bulk fetch ended, setting _fetchingRecentItems = false");
		}
		this._fetchingRecentItems = false;

		// Always recount to ensure accuracy after fetch, as items may have been
		// added with isVisible=false during the fetch process
		this._tileCounter.recountVisibleTiles(0, true, { source: "fetch-complete" });

		if (this._feedPaused) {
			//Unbuffer the feed
			uiHandlePauseClick(this, false, true); //Skip this._noShiftGrid.insertPlaceholderTiles()
		}

		debugFetchComplete(this);

		//Sort the grid after the fetch is complete
		this.#sortItems();

		if (this._noShiftGrid) {
			if (this.#getCurrentSortType() == TYPE_DATE_DESC) {
				this._noShiftGrid.resetEndPlaceholdersCount();
				this._noShiftGrid.insertPlaceholderTiles();
			} else {
				this._noShiftGrid.deletePlaceholderTiles();
			}
		}

		// Auto-clear unavailable items after the initial fetch completes (if setting enabled)
		try {
			if (typeof this._autoClearedUnavailableOnInitialFetch !== "boolean") {
				this._autoClearedUnavailableOnInitialFetch = false;
			}
			if (this._settings.get("notification.monitor.autoClearUnavailableOnInitialFetch")) {
				if (!this._autoClearedUnavailableOnInitialFetch) {
					this._autoClearedUnavailableOnInitialFetch = true;
					// Defer execution slightly to allow the stream processor to finish adding items to the ItemsMgr
					setTimeout(() => {
						try {
							const unavailableAsins = this._collectUnavailableItemAsins();
							if (unavailableAsins && unavailableAsins.size > 0) {
								if (this._settings.get("notification.monitor.passiveClears")) {
									this._startUndoableClear(unavailableAsins, "unavailable");
								} else {
									this._clearUnavailableItems(unavailableAsins);
								}
							}
						} catch (err) {
							console.error("Auto clear unavailable on initial fetch deferred run failed:", err);
						}
					}, 250);
				}
			}
		} catch (err) {
			console.error("Auto clear unavailable on initial fetch failed:", err);
		}
	}

	/**
	 * Remove "one" item from the monitor.
	 * not used by: the auto-truncate feature
	 * used by: hide click handler, etv filtering.
	 *
	 * This method ensures proper cleanup order to prevent memory leaks
	 * @param {string} asin - The ASIN of the tile
	 * @private
	 */
	#removeTile(asin, skipDOMremoval = false) {
		this.#etvProcessingItems.delete(asin);

		const element = this._itemsMgr.getItemDOMElement(asin);
		if (!element) {
			console.error("Item " + asin + " can't be located to remove it.");
			return false;
		}

		// Destroy Tile instance (this also destroys VariantButton and Splide instances)
		const tile = this._itemsMgr.getItemTile(asin);

		// Remove from ItemsMgr (remove all reference stored in maps)
		this._itemsMgr.removeAsin(asin);

		// Skip integrity check during DOM changes (tile.destroy mutates DOM via Splide, then element.remove)
		if (!skipDOMremoval) {
			this.#bulkOperationInProgress = true;
		}
		try {
			if (tile && typeof tile.destroy === "function") {
				tile.destroy(); //Destroy the DOM elements now that we removed the references to them.
			}

			// Clean up any tooltips
			const linkElement = element.querySelector(".a-link-normal");
			if (linkElement) {
				this._tooltipMgr.removeTooltip(linkElement);
			}

			if (!skipDOMremoval) {
				this._preserveScrollPosition(() => {
					element.remove();
				});

				// Only decrement count if the tile was visible (and not during bulk removal)
				const wasVisible = element.dataset.display && element.dataset.display !== "none";
				if (wasVisible) {
					this._tileCounter.alterCount(-1);
				}

				if (this._noShiftGrid) {
					if (this.#getCurrentSortType() == TYPE_DATE_DESC) {
						this._noShiftGrid.insertPlaceholderTiles();
					} else {
						this._noShiftGrid.deletePlaceholderTiles();
					}
				}
			}
		} finally {
			// Defer clearing flag so the integrity observer's rAF (triggered by tile.destroy) sees it as true
			if (!skipDOMremoval) {
				setTimeout(() => {
					this.#bulkOperationInProgress = false;
				}, 0);
			}
		}
	}

	/**
	 * Bulk remove items from the monitor
	 * @param {Set} asinsToKeep - A Set of ASINs to process
	 * @param {boolean} isKeepSet - If true, keep the items in the array and delete all other items, otherwise remove them
	 */
	#bulkRemoveItems(arrASINs, isKeepSet = false) {
		// Count visible items being removed before the operation
		let visibleRemovedCount = 0;

		debugTruncation("bulk.start", this, arrASINs, isKeepSet);
		debugTruncation("truncation.bulkPath", this, arrASINs);

		this._preserveScrollPosition(() => {
			this.#bulkOperationInProgress = true;
			try {
				// First, collect items to keep and items to remove
				const itemsToKeep = [];
				const itemsToRemove = [];
				let itemsToRemoveCount = 0;

				debugTruncation("bulk.cleanupStart", this, arrASINs, isKeepSet);

				this._itemsMgr.items.forEach((item, asin) => {
					// If isKeepSet is true, keep items IN the set
					// If isKeepSet is false, keep items NOT in the set (remove items IN the set)
					const shouldKeep = isKeepSet ? arrASINs.has(asin) : !arrASINs.has(asin);

					if (shouldKeep) {
						itemsToKeep.push({ asin, item });
					} else {
						itemsToRemoveCount++;
						itemsToRemove.push({ asin, item });

						// Count visible items being removed
						const element = this._itemsMgr.getItemDOMElement(asin);
						// Treat temporarily-hidden items (undo preview) as visible for placeholder accounting
						if (
							element &&
							(this.#isElementVisible(element) || element.classList.contains("vh-nm-temp-hidden"))
						) {
							visibleRemovedCount++;
						}
					}
				});

				// CRITICAL: Clean up items that are being removed BEFORE any DOM manipulation
				itemsToRemove.forEach(({ asin }) => {
					// Remove from ItemsMgr
					this.#removeTile(asin, true);
				});

				// Update items map with kept items only
				debugTruncation(
					"bulk.cleanupDone",
					this,
					itemsToKeep,
					itemsToRemoveCount,
					visibleRemovedCount,
					isKeepSet
				);

				// Rebuild the items map with only kept items
				this._itemsMgr.items.clear();
				const newImageUrls = new Set();
				itemsToKeep.forEach(({ asin, item }) => {
					if (!item) {
						console.log("[bulkRemoveItems] Item is null", asin);
						return;
					}
					this._itemsMgr.items.set(asin, item);
					// Keep track of the image URL for duplicate detection
					if (item.data.img_url && this._settings.get("notification.monitor.hideDuplicateThumbnail")) {
						newImageUrls.add(item.data.img_url);
					}
				});
				this._itemsMgr.imageUrls = newImageUrls;
				debugTruncation(
					"truncation.bulkAfterRebuild",
					this,
					itemsToKeep,
					itemsToRemoveCount,
					visibleRemovedCount
				);

				// Re-sort the remaining items in the existing container
				// This avoids creating a new container and leaving the old one detached
				this.#sortItems();

				// Reattach event listeners to the new container
				this._createListeners(true);
			} finally {
				// Clear flag after next frame so MutationObserver callbacks from our DOM changes
				// still see it true and skip validation (observers run after this tick).
				requestAnimationFrame(() => {
					requestAnimationFrame(() => {
						this.#bulkOperationInProgress = false;
					});
				});
			}
		});

		// Emit event if any visible items were removed
		if (visibleRemovedCount > 0) {
			this._tileCounter.recountVisibleTiles(0, false, { isBulkOperation: true, source: "bulk-remove" });

			// Single placeholder update after bulk remove (we skipped per-tile alterCount/insertPlaceholderTiles)
			if (this._noShiftGrid && this.#getCurrentSortType() === TYPE_DATE_DESC) {
				this._noShiftGrid.insertPlaceholderTiles();
			}

			debugTruncation("bulk.atomicCount", this, visibleRemovedCount);
		}

		// Sort already ran inside the callback (line ~857). Do not call #sortItems() again here:
		// it would clear the grid (including the placeholders we just added) and destroy Tile instances.
	}

	/**
	 * Auto truncate the items in the monitor according to the set limit.
	 * @param {boolean} forceRun - If true, run the truncation immediately, otherwise debounce the truncation
	 */
	#autoTruncate(forceRun = false) {
		debugTruncation("truncation.autoTruncate", this, forceRun);

		// Clear any existing debounce timer
		if (this._autoTruncateDebounceTimer) {
			clearTimeout(this._autoTruncateDebounceTimer);
		}

		// Run immediately if forced, otherwise debounce
		const runTruncate = (fetchingRecentItems = false) => {
			debugTruncation("truncation.runTruncate", this, fetchingRecentItems);

			// Auto truncate
			if (this._autoTruncateEnabled) {
				let visibleItemsRemovedCount = 0;
				const max = this._settings.get("notification.monitor.autoTruncateLimit");
				// Check if we need to truncate based on map size
				if (itemMapExceedsTruncateLimit(this._itemsMgr.items.size, max)) {
					this._log.add(
						`NOTIF: Auto truncating item(s) from the page using the ${this.#getCurrentSortType()} sort method.`
					);

					// Start truncation process
					const debugTabTitle = this._settings.get("general.debugTabTitle");
					if (debugTabTitle) {
						console.log(`[Truncation] Starting truncation`, {
							currentSize: this._itemsMgr.items.size,
							maxLimit: max,
							toRemove: this._itemsMgr.items.size - max,
						});
					}

					// Truncation: always remove oldest (by timestamp), keep newest N. Sort type affects display only.
					const itemsArray = buildTruncationSortArray(this._itemsMgr.items.entries());
					const { asinsToKeep, itemsToRemove } = computeKeepRemove(itemsArray, max);

					debugTruncation("truncation.itemsArray", this, itemsArray);

					visibleItemsRemovedCount = countVisibleRemovalsAmong(
						itemsToRemove,
						(asin) => this._itemsMgr.getItemDOMElement(asin),
						(el) => this.#isElementVisible(el)
					);

					debugTruncation(
						"truncation.keepRemove",
						this,
						max,
						itemsToRemove,
						visibleItemsRemovedCount,
						asinsToKeep,
						fetchingRecentItems
					);

					// Use bulk removal method with the optimized approach for large sets
					this.#bulkRemoveItems(asinsToKeep, true);

					debugTruncation("truncation.afterBulk", this, max);

					if (this._noShiftGrid && this.#getCurrentSortType() == TYPE_DATE_DESC) {
						debugTruncation("truncation.noShiftGrid", this, fetchingRecentItems, visibleItemsRemovedCount);
						if (fetchingRecentItems) {
							this._noShiftGrid.resetEndPlaceholdersCount();
						} else {
							this._noShiftGrid.insertEndPlaceholderTiles(visibleItemsRemovedCount);
						}
						this._noShiftGrid.insertPlaceholderTiles();
					}

					// Truncation completed
					if (debugTabTitle) {
						console.log(`[Truncation] Completed truncation`, {
							visibleItemsRemoved: visibleItemsRemovedCount,
							newSize: this._itemsMgr.items.size,
							fetchingRecentItems,
						});
					}
				} else {
					debugTruncation("truncation.noTruncationNeeded", this, max);
				}
			}
		};

		if (forceRun) {
			runTruncate(false);
		} else {
			// Set a new debounce timer
			const fetchingRecentItems = this._fetchingRecentItems; //Store the feed status during the timer's delay
			debugTruncation("truncation.schedulingDebounce", this, fetchingRecentItems);
			this._autoTruncateDebounceTimer = setTimeout(() => {
				runTruncate(fetchingRecentItems);
			}, 100); // 100ms debounce delay
		}
	}

	/**
	 * Collect ASINs for all visible items in the grid.
	 * @returns {Set<string>}
	 */
	#collectVisibleItemAsins() {
		return this._gridLayout.collectVisibleAsins();
	}

	/**
	 * Clear all visible items from the monitor.
	 * If asins are not provided, collects them from the current visible items.
	 * Delegates to bulkRemoveItems for removal
	 * @param {Set<string>} [asins=null] - Specific ASINs to clear; if null, collects visible items
	 */
	#clearAllVisibleItems(asins = null) {
		uiHandleHoverPauseEnd(this);
		const asinsToClear = asins ?? this.#collectVisibleItemAsins();
		if (!asinsToClear || asinsToClear.size === 0) {
			return;
		}

		// Remove each visible item - bulkRemoveItems handles scroll preservation and event emission
		this.#bulkRemoveItems(asinsToClear, false);
	}

	#isElementVisible(element) {
		const computerStyle = window.getComputedStyle(element);
		return computerStyle.display !== "none";
	}

	/**
	 * Collect ASINs flagged as unavailable.
	 * @returns {Set<string>}
	 */
	#collectUnavailableItemAsins() {
		const unavailableAsins = new Set();
		this._itemsMgr.items.forEach((item, asin) => {
			if (item.data.unavailable == 1) {
				unavailableAsins.add(asin);
			}
		});
		return unavailableAsins;
	}

	/**
	 * Clear all unavailable items from the monitor.
	 * If unavailableAsins are not provided, collects them from items marked as unavailable.
	 * @param {Set<string>} [unavailableAsins=null] - Specific ASINs to clear; if null, collects unavailable items
	 */
	#clearUnavailableItems(unavailableAsins = null) {
		uiHandleHoverPauseEnd(this);
		const asinsToClear = unavailableAsins ?? this.#collectUnavailableItemAsins();
		if (!asinsToClear || asinsToClear.size === 0) {
			return;
		}

		const debugBulkOperations = this._settings.get("general.debugBulkOperations");
		if (debugBulkOperations) {
			console.log("[clearUnavailableItems] Debug info:", {
				totalItems: this._itemsMgr.items.size,
				unavailableCount: asinsToClear.size,
				unavailableAsins: Array.from(asinsToClear).slice(0, 5), // Show first 5 for debugging
			});
		}

		// Use the bulk remove method - it will handle counting and event emission
		this.#bulkRemoveItems(asinsToClear, false);
	}

	/**
	 * Temporarily hide items while offering an undo window (show outcome of the action before finalizing it)
	 * @param {Set<string>} asins - ASINs to hide
	 * @returns {Map<string, {element: HTMLElement}>}
	 */
	#temporarilyHideItems(asins) {
		const hiddenItems = new Map();
		asins.forEach((asin) => {
			const element = this._itemsMgr.getItemDOMElement(asin);
			if (element && !hiddenItems.has(asin)) {
				hiddenItems.set(asin, { element });
				element.classList.add("vh-nm-temp-hidden");
			}
		});
		return hiddenItems;
	}

	/**
	 * Restore temporarily hidden items by removing the hide class from their DOM elements.
	 * Used when an undo action is triggered or a pending clear is cancelled.
	 * @param {Map<string, {element: HTMLElement}>} hiddenItems - Map of hidden items with their DOM elements
	 */
	#restoreTemporarilyHiddenItems(hiddenItems) {
		if (!hiddenItems) {
			return;
		}

		hiddenItems.forEach(({ element }) => {
			if (!element) {
				return;
			}
			element.classList.remove("vh-nm-temp-hidden");
		});
	}

	/**
	 * Replaces the clicked-on "clear ..." button in-place with [Undo (x)], where x is the remaining time until the clear operation is finalized.
	 * @param {number} remainingSeconds - The number of seconds remaining before auto-finalization
	 */
	#showUndoBanner(remainingSeconds) {
		if (this.#pendingClearAction?.undoButton) {
			uiShowUndoBanner(this.#pendingClearAction.undoButton, remainingSeconds);
		}
	}

	/**
	 * Update the undo banner's countdown timer.
	 * @param {number} remainingSeconds - The number of seconds remaining before auto-finalization
	 */
	#updateUndoBanner(remainingSeconds) {
		if (this.#pendingClearAction?.undoButton) {
			uiUpdateUndoBanner(this.#pendingClearAction.undoButton, remainingSeconds);
		}
	}

	/**
	 * Restore the clear button to its original state
	 */
	#hideUndoBanner() {
		if (this.#pendingClearAction?.undoButton && this.#pendingClearAction?.originalText) {
			uiHideUndoBanner(this.#pendingClearAction.undoButton, this.#pendingClearAction.originalText);
		}
	}

	/**
	 * Clear all timers (timeout and interval) assoc'd with a pending clear action.
	 * (Note: this should be called before cancelling or finalizing to prevent timer leaks.)
	 */
	#clearPendingClearTimers() {
		if (this.#pendingClearAction?.timeoutId) {
			clearTimeout(this.#pendingClearAction.timeoutId);
			this.#pendingClearAction.timeoutId = null;
		}
		if (this.#pendingClearAction?.intervalId) {
			clearInterval(this.#pendingClearAction.intervalId);
			this.#pendingClearAction.intervalId = null;
		}
	}

	/** Disable or re-enable fetch buttons (used during clear countdown). When re-enabling, leaves a button disabled if it is in its own fetch cooldown. */
	#setFetchButtonsDisabled(disabled) {
		uiSetFetchButtonsDisabled(disabled, {
			fetchLastCooldownActive: this._fetchLastCooldownActive,
			fetchLast12hrsCooldownActive: this._fetchLast12hrsCooldownActive,
		});
	}

	/**
	 * Run fetch for limit (with 30s countdown UI on the button). Used by UI handlers.
	 * @param {number|string} limitValue - Fetch limit (e.g. 100 or "12hrs")
	 * @param {HTMLInputElement} btnEl - Button to show "Wait Xs" countdown
	 */
	async #runFetchForLimit(limitValue, btnEl) {
		if (btnEl?.disabled) return;
		this._fetchLastCooldownActive = true;
		this.#setFetchButtonsDisabled(true);
		let secondsLeft = 30;
		const originalText = btnEl.value;
		btnEl.value = getMessage("nmWaitSeconds", `Wait ${secondsLeft}s`, [String(secondsLeft)]);
		const countdown = setInterval(() => {
			btnEl.value = getMessage("nmWaitSeconds", `Wait ${secondsLeft}s`, [String(secondsLeft)]);
			secondsLeft--;
			if (secondsLeft < 0) {
				clearInterval(countdown);
				this._fetchLastCooldownActive = false;
				btnEl.value = originalText;
				this.#setFetchButtonsDisabled(false);
			}
		}, 1000);
		debugTruncation("truncation.fetchLastStarting", this, limitValue);
		debugSound(this, "sound.bulkFetchLast100", {
			message: "Starting bulk fetch (last 100), setting _fetchingRecentItems = true",
		});
		this._fetchingRecentItems = true;
		if (!this._feedPaused) {
			uiHandlePauseClick(this);
		}
		const limitToUse = limitValue;
		if (this._isMasterMonitor) {
			this._sendMessageToWebsocket({ type: "fetchLatestItems", limit: limitToUse });
		} else {
			this._channel.postMessage(
				await this._cryptoKeys.encryptJSON({ type: "fetchLatestItems", limit: limitToUse })
			);
		}
	}

	/**
	 * Run fetch last 12hrs (with 60s countdown UI on the button). Used by UI handlers.
	 * @param {HTMLInputElement} btnEl - Button to show "Wait Xs" countdown
	 */
	async #runFetchLast12hrs(btnEl) {
		if (btnEl?.disabled) return;
		this._fetchLast12hrsCooldownActive = true;
		this.#setFetchButtonsDisabled(true);
		let secondsLeft = 60;
		const originalText = btnEl.value;
		btnEl.value = getMessage("nmWaitSeconds", `Wait ${secondsLeft}s`, [String(secondsLeft)]);
		const countdown = setInterval(() => {
			btnEl.value = getMessage("nmWaitSeconds", `Wait ${secondsLeft}s`, [String(secondsLeft)]);
			secondsLeft--;
			if (secondsLeft < 0) {
				clearInterval(countdown);
				this._fetchLast12hrsCooldownActive = false;
				btnEl.value = originalText;
				this.#setFetchButtonsDisabled(false);
			}
		}, 1000);
		debugSound(this, "sound.bulkFetchFilterChange", {
			message: "Starting bulk fetch (filter change), setting _fetchingRecentItems = true",
		});
		this._fetchingRecentItems = true;
		if (!this._feedPaused) {
			uiHandlePauseClick(this);
		}
		if (this._isMasterMonitor) {
			this._sendMessageToWebsocket({ type: "fetchLatestItems", limit: "12hrs" });
		} else {
			this._channel.postMessage(await this._cryptoKeys.encryptJSON({ type: "fetchLatestItems", limit: "12hrs" }));
		}
	}

	/**
	 * Cancel a pending clear operation.
	 * Clears all associated timers, hides the undo button, and restores hidden items to the DOM.
	 * @param {boolean} [restoreHidden=true] - Whether to restore temporarily hidden items
	 */
	#cancelPendingClear(restoreHidden = true) {
		if (!this.#pendingClearAction) {
			return;
		}
		if (this.#pendingClearAction.visibilityHandler) {
			document.removeEventListener("visibilitychange", this.#pendingClearAction.visibilityHandler);
		}
		this.#clearPendingClearTimers();
		this.#hideUndoBanner();
		this.#setFetchButtonsDisabled(false);
		if (restoreHidden) {
			this.#restoreTemporarilyHiddenItems(this.#pendingClearAction.hiddenItems);
			this._tileCounter.recountVisibleTiles(0, true, { source: "clear-revert" });
		}
		this.#pendingClearAction = null;
	}

	/**
	 * Finalize a pending clear operation by permanently removing the temporarily hidden items.
	 * Clears all timers, hides the undo banner, then calls the appropriate clear function
	 * (visible or unavailable) based on the clearKind stored in the pending action.
	 */
	#finalizePendingClear() {
		if (!this.#pendingClearAction) {
			return;
		}
		if (this.#pendingClearAction.visibilityHandler) {
			document.removeEventListener("visibilitychange", this.#pendingClearAction.visibilityHandler);
		}
		const { asins, clearKind, preserveScroll } = this.#pendingClearAction;
		this.#clearPendingClearTimers();
		this.#hideUndoBanner();
		this.#setFetchButtonsDisabled(false);
		this.#pendingClearAction = null;

		runPendingClearFinalization({
			asins,
			clearKind,
			preserveScroll,
			clearVisibleItems: (a) => this.#clearAllVisibleItems(a),
			preserveScrollPosition: (fn) => this._preserveScrollPosition(fn),
			clearUnavailableItems: (a) => this.#clearUnavailableItems(a),
		});
	}

	/**
	 * Start an undoable clear operation with a countdown timer and undo button.
	 * Temporarily hides items from the DOM and shows an undo banner with a countdown.
	 * If not cancelled within CLEAR_UNDO_SECONDS, automatically finalizes the clear operation.
	 * @param {Set<string>} asins - The ASINs to clear
	 * @param {string} clearKind - Either "visible" or "unavailable" to indicate the type of clear
	 * @param {boolean} [preserveScroll=false] - Whether to preserve scroll position during the clear
	 */
	#startUndoableClear(asins, clearKind, preserveScroll = false) {
		uiHandleHoverPauseEnd(this);
		if (!asins || asins.size === 0) {
			return;
		}

		// Reset any existing pending clear (restores items) before starting a new one
		this.#cancelPendingClear(true);

		const undoButton = clearKind === "visible" ? this.#clearMonitorButton : this.#clearUnavailableButton;
		const originalText =
			clearKind === "visible" ? this.#originalClearMonitorText : this.#originalClearUnavailableText;

		if (!undoButton) {
			return;
		}

		const hiddenItems = this.#temporarilyHideItems(asins);
		this._tileCounter.recountVisibleTiles(0, true, { source: "clear-preview" });

		const expiresAt = Date.now() + CLEAR_UNDO_SECONDS * 1000;

		this.#pendingClearAction = {
			asins,
			clearKind,
			preserveScroll,
			hiddenItems,
			expiresAt,
			undoButton,
			originalText,
			timeoutId: null,
			intervalId: null,
		};

		this.#showUndoBanner(CLEAR_UNDO_SECONDS);
		this.#setFetchButtonsDisabled(true);

		this.#pendingClearAction.timeoutId = window.setTimeout(() => {
			this.#finalizePendingClear();
		}, CLEAR_UNDO_SECONDS * 1000);

		this.#pendingClearAction.intervalId = window.setInterval(() => {
			if (!this.#pendingClearAction) {
				return;
			}
			const remaining = Math.max(0, Math.ceil((this.#pendingClearAction.expiresAt - Date.now()) / 1000));
			this.#updateUndoBanner(remaining);
			if (remaining <= 0) {
				this.#finalizePendingClear();
			}
		}, 250);

		this.#pendingClearAction.visibilityHandler = () => {
			if (document.visibilityState !== "visible" || !this.#pendingClearAction) {
				return;
			}
			if (this.#pendingClearAction.expiresAt <= Date.now()) {
				this.#finalizePendingClear();
			}
		};
		document.addEventListener("visibilitychange", this.#pendingClearAction.visibilityHandler);
	}

	/** Protected API for UI handlers. */
	_getPendingClearAction() {
		return this.#pendingClearAction;
	}
	_cancelPendingClear(restoreHidden = true) {
		return this.#cancelPendingClear(restoreHidden);
	}
	_collectVisibleItemAsins() {
		return this.#collectVisibleItemAsins();
	}
	_startUndoableClear(asins, clearKind, preserveScroll = false) {
		return this.#startUndoableClear(asins, clearKind, preserveScroll);
	}
	_clearAllVisibleItems(asins = null) {
		return this.#clearAllVisibleItems(asins);
	}
	_collectUnavailableItemAsins() {
		return this.#collectUnavailableItemAsins();
	}
	_clearUnavailableItems(unavailableAsins = null) {
		return this.#clearUnavailableItems(unavailableAsins);
	}
	_getPausedByMouseoverSeeDetails() {
		return this.#pausedByMouseoverSeeDetails;
	}
	_setPausedByMouseoverSeeDetails(v) {
		this.#pausedByMouseoverSeeDetails = v;
	}
	_showConnectionDetailsModal(data) {
		return this.#showConnectionDetailsModal(data);
	}
	_addToHiddenList(asin) {
		return HiddenList.addItem(asin, true, true);
	}
	_getPinDebounceClickable() {
		return this.#pinDebounceClickable;
	}
	_setPinDebounceClickable(v) {
		this.#pinDebounceClickable = v;
	}
	_setPinDebounceTimer(id) {
		this.#pinDebounceTimer = id;
	}
	_removeTile(asin, skipDOMremoval = false) {
		return this.#removeTile(asin, skipDOMremoval);
	}
	_sendReport(asin) {
		return this.#send_report(asin);
	}

	/**
	 * Insert a tile in the DOM according to the ETV value
	 * @param {DocumentFragment} fragment - The DOM fragment to insert the tile into
	 * @param {string} asin - The ASIN of the item
	 * @param {float} etv_min - The minimum ETV value
	 */
	#insertTileAccordingToETV(fragment, asin, etv_min) {
		if (etv_min !== null) {
			// For price sorting, find the correct position and insert there
			const newPrice = parseFloat(etv_min) || 0;
			let insertPosition = null;

			// Find the first item with a lower price
			const existingItems = Array.from(this._itemsMgr.items.entries());
			for (const [existingAsin, item] of existingItems) {
				// Skip the current item or items without elements
				if (existingAsin === asin || !item.element) continue;

				const existingPrice = parseFloat(item.data.etv_min) || 0;
				if (this.#getCurrentSortType() === TYPE_PRICE_DESC && newPrice > existingPrice) {
					insertPosition = item.element;
					break;
				} else if (this.#getCurrentSortType() === TYPE_PRICE_ASC && newPrice < existingPrice) {
					insertPosition = item.element;
					break;
				}
			}

			if (insertPosition && insertPosition.parentNode === this._gridContainer) {
				// Verify insertPosition is still a child of gridContainer before inserting
				// Insert before the found position
				try {
					this._gridContainer.insertBefore(fragment, insertPosition);
				} catch (error) {
					// If insertBefore fails (e.g., DOM changed), fall back to appendChild
					// This prevents memory leaks from unappended fragments
					console.warn("[NotificationMonitor] insertBefore failed, falling back to appendChild:", error);
					this._gridContainer.appendChild(fragment);
				}
			} else {
				// If no position found, position is invalid, or item has highest price, append to the end
				this._gridContainer.appendChild(fragment);
			}
		} else {
			// If no ETV min, append to the end
			this._gridContainer.appendChild(fragment);
		}
	}

	/**
	 * Add a tile to the monitor
	 * @param {object} item - Item object containing the item data
	 * @returns {false|object} - Return the DOM element of the tile if added, false otherwise
	 */
	async addTileInGrid(item, reason = "") {
		if (!(item instanceof Item)) {
			throw new Error("item is not an instance of Item");
		}
		if (this.#tileIntegrityLocked) return false;

		const asin = item.data.asin;
		const debugTruncation = this._settings.get("general.debugTruncation");
		if (debugTruncation) {
			console.log("[Truncation-DEBUG] addTileInGrid ENTRY", {
				asin,
				reason: reason || "(none)",
				itemsSize: this._itemsMgr.items.size,
				_fetchingRecentItems: this._fetchingRecentItems,
				processingASINsSize: this.#processingASINs.size,
				processingASINsHasThis: this.#processingASINs.has(asin),
				itemsHasThis: this._itemsMgr.items.has(asin),
				timestamp: new Date().toISOString(),
			});
		}

		// Check if this ASIN is currently being processed
		if (this.#processingASINs.has(asin)) {
			if (debugTruncation) {
				console.log("[Truncation-DEBUG] addTileInGrid REJECT: ASIN already being processed", { asin, reason });
			}
			// ASIN already being processed
			return false;
		}

		// Mark this ASIN as being processed
		this.#processingASINs.add(asin);

		try {
			item.setUnavailable(item.data.unavailable == 1);
			item.setTitle(unescapeHTML(unescapeHTML(item.data.title)));
			item.setDate(item.data.date ? YMDHiStoISODate(item.data.date) : null); //Convert server date time to local date time
			item.setDateAdded(item.data.date_added ? YMDHiStoISODate(item.data.date_added) : null); //Convert server date time to local date time
			// Ensure items without a valid timestamp get "now" so they appear at front and are kept by truncation (e.g. Random test)
			const existingTs =
				item.data.timestamp != null && !Number.isNaN(Number(item.data.timestamp))
					? Number(item.data.timestamp)
					: null;
			if (existingTs == null) {
				item.setTimestamp(Date.now());
			}
			const {
				asin,
				queue,
				tier,
				date,
				date_added,
				title,
				img_url,
				is_parent_asin,
				is_pre_release,
				enrollment_guid,
				etv_min,
				etv_max,
				KW,
				KWsMatch,
				BlurKW,
				BlurKWsMatch,
				unavailable,
			} = item.data; //Todo: Actually use the item object
			const recommendationType = item.getRecommendationType();
			const recommendationId = item.getRecommendationString(this._env);

			// If the notification already exists, update the data and return the existing DOM element
			if (this._itemsMgr.items.has(asin)) {
				const element = this._itemsMgr.getItemDOMElement(asin);
				if (element) {
					if (debugTruncation) {
						console.log(
							"[Truncation-DEBUG] addTileInGrid: item already in items map, updating and returning existing element",
							{
								asin,
								reason,
								itemsSize: this._itemsMgr.items.size,
							}
						);
					}
					this._log.add(`NOTIF: Item ${asin} already exists, updating RecommendationId.`);

					// DEBUG: Log duplicate detection
					if (this._settings.get("general.debugDuplicates")) {
						const existingItem = this._itemsMgr.items.get(asin);
						console.log("[DEBUG-DUPLICATE] Item already exists", {
							asin,
							hasElement: !!element,
							imgUrl: item.data.img_url,
							existingImgUrl: existingItem?.data?.img_url,
							new_enrollment_guid: item.data.enrollment_guid,
							existing_enrollment_guid: existingItem?.data?.enrollment_guid,
							enrollment_guid_changed: existingItem?.data?.enrollment_guid !== item.data.enrollment_guid,
							reason: reason,
							timestamp: new Date().toISOString(),
							stack: new Error().stack.split("\n").slice(2, 5).join("\n"),
						});

						// Log enrollment_guid changes specifically
						if (existingItem?.data?.enrollment_guid !== item.data.enrollment_guid) {
							console.warn("[NotificationMonitor] ENROLLMENT_GUID UPDATE:", {
								asin,
								old_enrollment_guid: existingItem?.data?.enrollment_guid,
								new_enrollment_guid: item.data.enrollment_guid,
								reason: reason,
							});
						}
					}
					// Update the data
					this._itemsMgr.addItemData(asin, item.data);

					// Update recommendationId in the DOM
					// it's possible that the input element was removed as part of the de-duplicate image process or the gold tier check
					element.dataset.recommendationId = recommendationId;
					const inputElement = element.querySelector(`input[data-asin='${asin}']`);
					if (inputElement) {
						inputElement.dataset.recommendationId = recommendationId;
					}

					const mergedItem = this._itemsMgr.items.get(asin);
					if (mergedItem) {
						syncSeeDetailsInputFromItem(element, mergedItem, this._env);
					}

					const isUnavailable =
						item.data.unavailable === 1 ||
						item.data.unavailable === "1" ||
						item.data.unavailable === true ||
						item.data.unavailable === "true";
					if (isUnavailable) {
						this._disableItem(element);
					} else {
						this._enableItem(element); //Return the DOM element of the tile.
					}

					return element;
				}
			}

			// Enhanced duplicate detection - check both ASIN and image URL
			// Check if the de-duplicate image setting is on
			if (this._settings.get("notification.monitor.hideDuplicateThumbnail")) {
				// First check if we already have this ASIN with a different image
				if (this._itemsMgr.items.has(asin)) {
					const existingItem = this._itemsMgr.items.get(asin);
					if (existingItem && existingItem.data && existingItem.data.img_url !== img_url) {
						if (this._settings.get("general.debugDuplicates")) {
							console.log("[DEBUG-DUPLICATE] ASIN exists with different image URL", {
								asin,
								newImgUrl: img_url,
								existingImgUrl: existingItem.data.img_url,
								timestamp: new Date().toISOString(),
							});
						}
						// Update the image URL if it's different
						existingItem.data.img_url = img_url;
					}
					if (debugTruncation) {
						console.log(
							"[Truncation-DEBUG] addTileInGrid REJECT: ASIN already exists (hideDuplicateThumbnail)",
							{
								asin,
								reason,
								itemsSize: this._itemsMgr.items.size,
							}
						);
					}
					return false; // ASIN already exists, prevent duplicate
				}

				// Then check if the image URL already exists (original logic)
				if (this._itemsMgr.imageUrls.has(img_url)) {
					// DEBUG: Log image duplicate prevention
					if (this._settings.get("general.debugDuplicates")) {
						console.log("[DEBUG-DUPLICATE] Preventing duplicate by image URL", {
							asin,
							imgUrl: img_url,
							existingImageUrls: Array.from(this._itemsMgr.imageUrls).slice(0, 5),
							timestamp: new Date().toISOString(),
						});
					}
					if (debugTruncation) {
						console.log(
							"[Truncation-DEBUG] addTileInGrid REJECT: image URL already exists (hideDuplicateThumbnail)",
							{
								asin,
								reason,
								imgUrl: img_url,
								itemsSize: this._itemsMgr.items.size,
							}
						);
					}
					return false; // The image already exists, do not add the item
				}
			}

			// Store the item data
			this._itemsMgr.addItemData(asin, item.data);

			// Generate the search URL
			let search_url;
			if (
				this._settings.isPremiumUser(2) &&
				this._settings.get("general.searchOpenModal") &&
				is_parent_asin != null &&
				enrollment_guid != null
			) {
				search_url = item.getVHOpenModalURL();
			} else {
				search_url = item.getVineSearchURL();
			}

			//Load and render the order widget
			if (this._settings.isPremiumUser(3)) {
				const orderWidgetTemplate = await this._tpl.loadFile("scripts/ui/templates/widget_order.html");
				this._tpl.setVar("order_success", item.data.order_success);
				this._tpl.setVar("order_failed", item.data.order_failed);
				const renderedOrderWidget = this._tpl.render(orderWidgetTemplate, false);
				this._tpl.setVar("orderWidget", renderedOrderWidget);
			} else {
				this._tpl.setVar("orderWidget", "");
			}

			// Load and render the appropriate toolbar template
			const toolbarTemplateFile =
				this._itemTemplateFile === "tile_listview.html"
					? "toolbar_monitor_listview.html"
					: "toolbar_monitor_gridview.html"; // Used for tile_gridview.html
			const toolbarTemplate = await this._tpl.loadFile("scripts/ui/templates/" + toolbarTemplateFile);
			const isParentAsinAllowed =
				this._settings.isPremiumUser(2) &&
				this._settings.get("general.displayVariantIcon") === true &&
				(is_parent_asin == "true" || is_parent_asin === true);

			// Set toolbar template variables
			this._tpl.setVar("asin", asin);
			this._tpl.setVar("queue", queue);
			this._tpl.setVar("tier", tier);
			this._tpl.setVar("date_received", new Date().toISOString());
			this._tpl.setVar("date_sent", toIsoDatasetValue(date));
			this._tpl.setVar("date_added", toIsoDatasetValue(date_added));
			this._tpl.setVar("reason", reason);
			// Ensure KW and BlurKW are strings, not false/undefined
			this._tpl.setVar("highlightKW", KW || "");
			this._tpl.setVar("blurKW", BlurKW || "");
			this._tpl.setVar("enrollment_guid", enrollment_guid);
			this._tpl.setVar("description", escapeHTML(title));
			this._tpl.setVar("img_url", img_url);
			this._tpl.setVar("search_url", search_url);
			this._tpl.setVar("is_parent_asin", is_parent_asin); //"true" or "false"
			this._tpl.setIf("is_parent_asin", isParentAsinAllowed);
			this._tpl.setIf(
				"announce",
				this._settings.get("discord.active") && this._settings.get("discord.guid", false) != null
			);
			this._tpl.setIf("pinned", this._settings.get("pinnedTab.active"));

			// Render the toolbar
			const renderedToolbar = this._tpl.render(toolbarTemplate, false);
			const delayedBroadcast = reason.includes("enrollement_guid") || reason.includes("queue");

			// Now load and render the tile template
			let prom2 = await this._tpl.loadFile("scripts/ui/templates/" + this._itemTemplateFile);
			this._tpl.setVar("domain", this._i18nMgr.getDomainTLD());
			this._tpl.setVar("img_url", img_url);
			this._tpl.setIf("use_lazy_image_loading", true);
			this._tpl.setIf("use_eager_image_loading", false);
			this._tpl.setVar("asin", asin);
			this._tpl.setVar("tier", tier);
			this._tpl.setVar("date_displayed", this._formatDate(date)); // Used in tile_gridview.html and tile_listview.html
			// Don't mark items as paused if we're fetching recent items
			// This ensures they can be properly counted as visible
			this._tpl.setVar("feedPaused", this._feedPaused);
			this._tpl.setVar("queue", queue);
			this._tpl.setVar("description", escapeHTML(title));
			// Debug logging for keyword setting
			if (this._settings.get("general.debugKeywords") || KW === undefined) {
				console.log(`[NotificationMonitor] Setting highlightKW for ASIN ${asin}: "${KW}"`);
				console.trace();
			}

			this._tpl.setVar("is_parent_asin", is_parent_asin); //"true" or "false"
			this._tpl.setVar("enrollment_guid", enrollment_guid);
			this._tpl.setVar("recommendationType", recommendationType);
			this._tpl.setVar("recommendationId", recommendationId);
			this._tpl.setVar("mobileSuffix", this._env.isVineConsideredMobileView() ? "-mobile" : "");
			this._tpl.setIf("is_parent_asin", isParentAsinAllowed);
			this._tpl.setVar("is_pre_release", is_pre_release == "true" || is_pre_release === true); // Used in tile_gridview.html
			this._tpl.setIf("pre_release", is_pre_release == "true" || is_pre_release === true); // Pre-Release badge on thumbnail
			this._tpl.setIf("delayed", delayedBroadcast); // Used in tile_gridview.html and tile_listview.html
			this._tpl.setVar("showBuyNow", this._settings.get("general.orderNow.active") ? "1" : "");
			this._tpl.setIf("showBuyNow", this._settings.get("general.orderNow.active"));
			this._tpl.setIf("unavailable", unavailable == 1);
			// Inject the rendered toolbar
			this._tpl.setVar("toolbar", renderedToolbar);

			const tileDOM = await this._tpl.render(prom2, true);
			// Normalize images defensively before inserting into DOM (covers stale cached templates with src attrs).
			lazyImageLoader.prepareWithin(tileDOM);
			syncSeeDetailsInputFromItem(tileDOM, item, this._env);

			// Create fragment and add the tile to it
			const fragment = document.createDocumentFragment();
			fragment.appendChild(tileDOM);
			const insertTrustedTile = (trustedSchema) => {
				this._preserveScrollPosition(() => {
					// Insert the tile based on sort type
					if (
						this.#getCurrentSortType() === TYPE_PRICE_DESC ||
						this.#getCurrentSortType() === TYPE_PRICE_ASC
					) {
						//The tile will need to be inserted in a specific position based on the ETV value
						this.#insertTileAccordingToETV(fragment, asin, etv_min);
					} else if (this.#getCurrentSortType() === TYPE_DATE_ASC) {
						// For date ascending, append to the end
						this._gridContainer.appendChild(fragment);
					} else {
						//Sort DESC
						// For date descending (default), insert at the beginning but after placeholders.
						let insertPosition = this._gridContainer.firstChild;
						while (insertPosition && insertPosition.classList.contains("vh-placeholder-tile")) {
							insertPosition = insertPosition.nextSibling;
						}
						if (insertPosition && insertPosition.parentNode === this._gridContainer) {
							// Verify insertPosition is still a child of gridContainer before inserting
							try {
								this._gridContainer.insertBefore(fragment, insertPosition);
							} catch (error) {
								// If insertBefore fails (e.g., DOM changed), fall back to appendChild
								// This prevents memory leaks from unappended fragments
								console.warn(
									"[NotificationMonitor] insertBefore failed in addTileInGrid, falling back to appendChild:",
									error
								);
								this._gridContainer.appendChild(fragment);
							}
						} else {
							// All children are placeholders or container is empty
							this._gridContainer.appendChild(fragment);
						}
					}
					this.#tileIntegrityService?.lockTileWithSchema(tileDOM, trustedSchema);
				});
			};

			// Store a reference to the DOM element
			const wasMarkedUnavailable = this._itemsMgr.storeItemDOMElement(asin, tileDOM); //Store the DOM element
			// Ensure the stored item has current timestamp so display sort (ItemsMgr.sortItems) and truncation keep it at front
			const storedItem = this._itemsMgr.items.get(asin);
			if (storedItem && (storedItem.data.timestamp == null || Number.isNaN(Number(storedItem.data.timestamp)))) {
				storedItem.setTimestamp(Date.now());
			}
			const tile = this._itemsMgr.getItemTile(asin);

			// Initialize the tile (handles blur keywords and other tile-specific setup)
			if (tile) {
				if (this._settings.get("general.debugKeywords")) {
					console.log("[NotificationMonitor] Calling initiateTile for", asin);
				}
				tile.initiateTile();
			} else {
				console.warn("[NotificationMonitor] No tile object found for", asin);
			}

			// Apply highlight styling (including zero ETV) before the tile is exposed to page scripts.
			await this._processNotificationHighlight(tileDOM);

			// Track tile creation for memory debugging
			if (window.MEMORY_DEBUGGER) {
				window.MEMORY_DEBUGGER.trackTile(tileDOM, asin);
			}

			// Debug logging for count tracking
			if (this._settings.get("general.debugItemProcessing") || this._settings.get("general.debugTabTitle")) {
				const isVisible = tileDOM.dataset.display !== "none" && !tileDOM.classList.contains("hidden");
				console.log("[NotificationMonitor] New item added to DOM", {
					asin,
					isVisible,
					display: tileDOM.dataset.display,
					hasHiddenClass: tileDOM.classList.contains("hidden"),
					currentVisibilityStateCount: this._tileCounter.getCount(),
					itemDataIsVisible: item.isVisible,
					timestamp: new Date().toISOString(),
				});
			}

			// If the item was marked as unavailable before its DOM was ready, apply the unavailable visual state now
			if (wasMarkedUnavailable) {
				this._disableItem(tileDOM);
			}

			if (
				/* this._monitorV3 && */
				this._settings.isPremiumUser(2) &&
				this._settings.get("general.displayVariantButton")
			) {
				if (is_parent_asin && item.data.variants) {
					await this.runWithTileUnlocked(tileDOM, async () => {
						for (const variant of item.data.variants) {
							await tile.addVariant(variant.asin, variant.title, variant.etv);
						}
					});
				}
			}

			// Check if the item is already pinned and update the pin icon
			if (this._settings.get("pinnedTab.active")) {
				const isPinned = await this._pinMgr.checkIfPinned(asin);
				if (isPinned) {
					this._pinMgr.pinItem(item);
				}
			}

			//Set the tile custom dimension according to the settings.
			if (!this._settings.get("notification.monitor.listView")) {
				this._tileSizer.adjustAll(tileDOM);
			}
			//Add tool tip to the truncated item title link
			if (this._settings.get("general.displayFullTitleTooltip")) {
				const titleDOM = tileDOM.querySelector(".a-link-normal");
				this._tooltipMgr.addTooltip(titleDOM, title);
			}

			//If the feed is paused, up the counter, mark tile as buffered, and update the icon
			if (this._feedPaused) {
				tileDOM.dataset.feedPaused = "true";
				this._feedPausedAmountStored++;
				updatePauseButtonUI(true, this._feedPausedAmountStored);

				//Sleep for 1 frame to allow the value to be updated
				if (this._feedPausedAmountStored % 20 == 0) {
					await new Promise((resolve) => requestAnimationFrame(resolve));
					//await new Promise((resolve) => setTimeout(resolve, 1));
				}
			}

			//Process the item according to the notification type (highlight > 0etv > regular)
			//This is what determine & trigger what sound effect to play
			// Handle item-specific logic (sound, moving to top, etc.)
			// Note: type flags are already set above before filtering

			// Debug logging for sound triggering during addTileInGrid
			if (this._settings.get("general.debugSound")) {
				console.log("[SOUND DEBUG] Item sound selection in addTileInGrid:", {
					asin,
					KWsMatch,
					etv_min: parseFloat(etv_min),
					isZeroETV: parseFloat(etv_min) === 0,
					_fetchingRecentItems: this._fetchingRecentItems,
					currentFilter: this.#getCurrentFilterType(),
					filterName:
						this.#getCurrentFilterType() === TYPE_HIGHLIGHT
							? "KW match only"
							: this.#getCurrentFilterType() === TYPE_HIGHLIGHT_OR_ZEROETV
								? "Zero ETV or KW match only"
								: this.#getCurrentFilterType() === TYPE_ZEROETV
									? "Zero ETV only"
									: "No filter",
					soundType: KWsMatch ? "HIGHLIGHT" : parseFloat(etv_min) === 0 ? "ZERO_ETV" : "REGULAR",
				});
			}

			// CRITICAL FIX: Set type flags BEFORE filtering so the filter knows what type of item this is
			// This must happen before processNotificationFiltering to ensure proper visibility calculation
			if (KWsMatch) {
				tileDOM.dataset.typeHighlight = 1;
				// Store groupId for custom color/sound; resolve from KeywordMatcherService when missing (e.g. fetch last 100)
				if (item.data.highlightGroupId) {
					tileDOM.dataset.highlightGroupId = item.data.highlightGroupId;
				} else {
					try {
						const matcher = await this.#ensureKeywordMatcher();
						const match = matcher.findHighlightHideMatchSync(
							title,
							etv_min != null && etv_min !== "" ? parseFloat(etv_min) : null,
							etv_max != null && etv_max !== "" ? parseFloat(etv_max) : null
						);
						if (match && match.type === "highlight" && match.groupId) {
							item.data.highlightGroupId = match.groupId;
							tileDOM.dataset.highlightGroupId = match.groupId;
						}
					} catch (err) {
						console.warn("[NotificationMonitor] Failed to resolve highlightGroupId:", err);
					}
				}

				// Debug logging for typeHighlight being set
				if (this._settings.get("general.debugKeywords")) {
					console.log("[NotificationMonitor] Setting typeHighlight=1 for keyword match:", {
						asin,
						title,
						keyword: KW,
						typeHighlight: 1,
						highlightGroupId: item.data.highlightGroupId,
						currentFilter: this.#getCurrentFilterType(),
						filterName: FILTER_NAMES[this.#getCurrentFilterType()] || "Unknown",
						timestamp: new Date().toISOString(),
					});
				}
			}

			// Check ETV status independently of keyword matching
			if (parseFloat(etv_min) === 0 || parseFloat(etv_max) === 0) {
				tileDOM.dataset.typeZeroETV = 1;
			} else if (etv_min == "" || etv_min == null || etv_max == "" || etv_max == null) {
				// Mark items with unknown ETV
				tileDOM.dataset.typeUnknownETV = 1;
			}

			// Ensure regular items have explicit "0" for type flags (unpause sound, filters, etc. rely on them)
			if (tileDOM.dataset.typeHighlight != "1") {
				tileDOM.dataset.typeHighlight = "0";
			}
			if (tileDOM.dataset.typeZeroETV != "1") {
				tileDOM.dataset.typeZeroETV = "0";
			}

			// Debug logging for ETV type flags and styling
			if (this._settings.get("general.debugItemProcessing")) {
				console.log("[DEBUG-ETV-STYLING] Item type flags set:", {
					asin,
					etv_min,
					etv_max,
					hasEtvData: etv_min != null && etv_min !== "" && etv_max != null && etv_max !== "",
					typeHighlight: tileDOM.dataset.typeHighlight || "0",
					typeZeroETV: tileDOM.dataset.typeZeroETV || "0",
					typeUnknownETV: tileDOM.dataset.typeUnknownETV || "0",
					KWsMatch,
					// Settings that affect styling (highlight color now from group.monitorColor only)
					zeroETVColorActive: this._settings.get("notification.monitor.zeroETV.colorActive"),
					unknownETVColorActive: this._settings.get("notification.monitor.unknownETV.colorActive"),
					ignoreUnknownETVhighlight: this._settings.get(
						"notification.monitor.highlight.ignoreUnknownETVhighlight"
					),
					timestamp: new Date().toISOString(),
				});
			}

			// BUG FIX 2: Move sound playing AFTER filtering to respect filter settings
			// First apply filtering to determine visibility
			const isVisible = this.#processNotificationFiltering(tileDOM);
			this.#setTileDisplay(tileDOM, isVisible ? "flex" : "none");

			// Debug logging for the complete flow sequence
			if (this._settings.get("general.debugKeywords") && KWsMatch) {
				console.log("[NotificationMonitor] Complete keyword match flow:", {
					step: "Final visibility decision",
					asin,
					title,
					keyword: KW,
					typeHighlight: tileDOM.dataset.typeHighlight,
					currentFilter: this.#getCurrentFilterType(),
					filterName: FILTER_NAMES[this.#getCurrentFilterType()] || "Unknown",
					isVisible,
					displayStyle: isVisible ? "flex" : "none",
					note: "This item matched a keyword and its visibility has been determined",
					timestamp: new Date().toISOString(),
				});
			}

			// During bulk fetch we do not play sounds per item; when the feed unpauses,
			// the highest-priority sound is played once (see _unpauseFeed).
			const shouldPlaySound = isVisible && !this._feedPaused;

			// Apply ETV and highlight styling BEFORE move-to-top/sound so the tile is never shown without them.
			// MUST still be after type attributes (typeHighlight, typeZeroETV, etc.) above — they are set above; we only moved this block before #highlightedItemFound.
			if (etv_min != null && etv_max != null) {
				await this.#setETVRange(tileDOM, item.data, etv_min, etv_max);
				this.#checkZeroETVStatus(tileDOM);
			} else {
				const brendaAnnounce = tileDOM.querySelector("#vh-announce-link-" + asin);
				if (brendaAnnounce) {
					brendaAnnounce.style.display = "none";
				}
			}
			this._processNotificationHighlight(tileDOM); // Uses type attributes set above; do not move above type-flag block.

			// Recount after tile is fully styled (ETV + highlight); TileCounter calls insertPlaceholderTiles() when count changes (once per add).
			if (this._noShiftGrid && this.#getCurrentSortType() === TYPE_DATE_DESC) {
				this._tileCounter.recountVisibleTiles(0, { source: "addTile-after-ETV-highlight" });
			}

			// Play appropriate sound for item type
			// Now play sounds only for visible items
			if (KWsMatch) {
				await this.#highlightedItemFound(tileDOM, shouldPlaySound); //Play the highlight sound only if visible
			} else if (parseFloat(etv_min) === 0) {
				await this.#zeroETVItemFound(tileDOM, shouldPlaySound); //Play the zeroETV sound only if visible
			} else if (queue === "potluck") {
				await this.#rfyItemFound(tileDOM);
			} else {
				await this.#regularItemFound(tileDOM, shouldPlaySound); //Play the regular sound only if visible
			}

			//Add the RFY corner to the tile, regardless of the item type (ie.: Add the banner even if it's a highlighted item)
			if (queue === "potluck") {
				this.#markAsRFY(tileDOM);
			} else if (queue === "last_chance") {
				this.#markAsAFA(tileDOM);
			}

			//Process the bluring
			if (BlurKWsMatch) {
				this._blurItemFound(tileDOM);
			}

			if (item.data.price !== undefined && item.data.price !== null) {
				this.#setPrice(tileDOM, item.data.price);
			}
			if (item.data.additional_img && Array.isArray(item.data.additional_img)) {
				this.setAdditionalImagesFromASIN(asin, item.data.additional_img);
			}

			//If unavailable, change opacity
			if (unavailable == 1) {
				this._disableItem(tileDOM);
			}

			//Check gold tier status for this item
			//this.#disableGoldItemsForSilverUsers(tileDOM);

			if (this._mostRecentItemDate == null || date > this._mostRecentItemDate) {
				if (this._mostRecentItemDateDOM) {
					this._mostRecentItemDateDOM.innerText = this._formatDate(date);
				}
				this._mostRecentItemDate = date;
			}

			// Note: Filtering is now done BEFORE sound playing (see above)
			// This ensures sounds only play for visible items

			const trustedSchema = buildSchemaFromLiveElement(tileDOM);
			insertTrustedTile(trustedSchema);
			lazyImageLoader.observeWithin(tileDOM);

			// Emit grid events during normal operation or when fetching recent items
			// Always emit during fetch to ensure counts stay accurate
			if (!this._feedPaused || this._fetchingRecentItems) {
				// Debug: Log when new items are added
				if (this._settings.get("general.debugItemProcessing") || this._settings.get("general.debugTabTitle")) {
					console.log("[NotificationMonitor] New item added - FINAL STATE", {
						asin,
						isVisible,
						currentCount: this._tileCounter.getCount(),
						feedPaused: this._feedPaused,
						fetchingRecentItems: this._fetchingRecentItems,
						tileVisible: this.#isElementVisible(tileDOM),
						computedDisplay: window.getComputedStyle(tileDOM).display,
						inlineDisplay: tileDOM.dataset.display,
						typeHighlight: tileDOM.dataset.typeHighlight,
						typeZeroETV: tileDOM.dataset.typeZeroETV,
						filterType: this.#getCurrentFilterType(),
						timestamp: new Date().toISOString(),
					});
				}

				// During bulk operations (fetchingRecentItems), use debounced recount
				// For individual items, recount immediately
				if (this._fetchingRecentItems) {
					// Use debounced recount during bulk operations
					this._tileCounter.recountVisibleTiles(50, false, { isBulkOperation: true, source: "bulk-add" });
				} else {
					// Immediate recount for individual items
					this._tileCounter.recountVisibleTiles(0, true, { source: "single-add" });
				}
			}

			if (!this._feedPaused) {
				if (this._isMasterMonitor && !delayedBroadcast && !reason.includes("RFY")) {
					this._autoLoad.itemsDroppingDetected(); // Switch to aggressive interval while items are dropping
				}
			}

			//Autotruncate the items if there are too many
			this.#autoTruncate(!this._feedPaused); //If we are paused, autotruncate will debounce itself.

			if (debugTruncation) {
				console.log("[Truncation-DEBUG] addTileInGrid SUCCESS: tile added", {
					asin,
					reason,
					itemsSize: this._itemsMgr.items.size,
					timestamp: new Date().toISOString(),
				});
			}
			return tileDOM; //Return the DOM element for the tile.
		} finally {
			// Always remove from processing map when done
			this.#processingASINs.delete(asin);
		}
	}

	#markAsRFY(tileDOM) {
		const container = tileDOM.querySelector(".vh-img-container");

		const newCorner = document.createElement("div");
		newCorner.classList.add("vh-corner-rfy");
		//Add a span into the div
		const span = document.createElement("span");
		span.innerHTML = "RFY";
		newCorner.appendChild(span);

		//Insert newCorner as the first child of the container
		container.insertBefore(newCorner, container.firstChild);
	}

	#markAsAFA(tileDOM) {
		const container = tileDOM.querySelector(".vh-img-container");

		const newCorner = document.createElement("div");
		newCorner.classList.add("vh-corner-afa");
		//Add a span into the div
		const span = document.createElement("span");
		span.innerHTML = "AFA";
		newCorner.appendChild(span);

		//Insert newCorner as the first child of the container
		container.insertBefore(newCorner, container.firstChild);
	}

	async addVariants(data) {
		if (
			/* this._monitorV3 && */ this._settings.isPremiumUser(2) &&
			this._settings.get("general.displayVariantButton")
		) {
			if (this._itemsMgr.items.has(data.asin)) {
				const tile = this._itemsMgr.getItemTile(data.asin);
				if (tile) {
					await this.runWithTileUnlocked(tile.getDOM(), async () => {
						if (data.variants && data.variants.length > 0) {
							for (const variant of data.variants) {
								await tile.addVariant(variant.asin, variant.title, variant.etv);
							}
						}
					});
				}
			}
		}
	}

	/**
	 * Run callback while tile is unlocked (for DOM changes), then re-lock. Use from bootloader or other code that adds variant buttons etc.
	 * @param {Element} tileElement - .vvp-item-tile DOM element
	 * @param {() => void | Promise<void>} callback
	 * @returns {Promise<void>}
	 */
	async runWithTileUnlocked(tileElement, callback) {
		if (this.#tileIntegrityService) {
			await this.#tileIntegrityService.runWithTileUnlocked(tileElement, callback);
		} else {
			await callback();
		}
	}

	setOrderAttemptsFromASIN(asin, success, failed) {
		const tile = this._itemsMgr.getItemTile(asin);
		if (tile) {
			const tileDOM = tile.getDOM();
			if (tileDOM) {
				// Locate the order widget container within the tile DOM
				const orderWidget = tileDOM.querySelector(".vh-order-widget");
				if (orderWidget) {
					const orderSuccessElem = orderWidget.querySelector(".vh-order-success");
					const orderFailedElem = orderWidget.querySelector(".vh-order-failed");
					if (orderSuccessElem) {
						orderSuccessElem.textContent = success;
					}
					if (orderFailedElem) {
						orderFailedElem.textContent = failed;
					}
				}
			}
		}
	}

	/**
	 * Set ETV range for an item in a single call (more efficient than two separate calls)
	 * Used only for initial loading to avoid downstream impact
	 * @param {object} notif - The DOM element of the tile
	 * @param {object} data - The item data
	 * @param {number} etvMin - The minimum ETV value
	 * @param {number} etvMax - The maximum ETV value
	 * @returns {boolean} - True if the ETV was set, false otherwise
	 */
	async #setETVRange(notif, data, etvMin, etvMax) {
		if (!notif) {
			return false;
		}
		const asin = notif.dataset.asin;
		const etvObj = notif.querySelector("div.etv");
		const etvTxt = etvObj.querySelector("span.etv");
		const brendaAnnounce = notif.querySelector("#vh-announce-link-" + asin);

		// Update both min and max in single operation
		etvObj.dataset.etvMin = etvMin;
		etvObj.dataset.etvMax = etvMax;

		// Ensure etvMin is always less than or equal to etvMax
		if (parseFloat(etvMin) > parseFloat(etvMax)) {
			etvObj.dataset.etvMin = etvMax;
			etvObj.dataset.etvMax = etvMin;
		}

		//Display for formatted ETV in the toolbar
		const etvSpan = etvObj.querySelector("span.etv");

		// Check for price data by looking at actual price content, not just CSS class
		const priceTxt = etvObj.querySelector("span.price");
		const hasPriceData = priceTxt && priceTxt.textContent.trim() !== "" && priceTxt.textContent !== "&nbsp;";
		const hasEtvData = etvObj.dataset.etvMin != "" && etvObj.dataset.etvMax != "";
		const showEtv = hasEtvData && this._settings.get("general.displayETV");

		// Container visibility: single calculation instead of multiple
		const shouldShowContainer = showEtv || (hasPriceData && this._settings.get("general.displayPrice"));

		if (shouldShowContainer) {
			etvObj.style.display = "flex";
		} else {
			etvObj.style.display = "none";
		}

		if (showEtv) {
			// Show ETV span when ETV is enabled and has data
			etvSpan.style.display = "";
			let etvMinToFormat = etvObj.dataset.etvMin;
			let etvMaxToFormat = etvObj.dataset.etvMax;
			if (this._settings.isPremiumUser(2)) {
				etvMinToFormat = etvObj.dataset.etvMin * this._settings.get("general.ETV.modifier");
				etvMaxToFormat = etvObj.dataset.etvMax * this._settings.get("general.ETV.modifier");
			}
			if (etvObj.dataset.etvMin == etvObj.dataset.etvMax) {
				etvTxt.innerText = this._formatETV(etvMinToFormat);
				etvTxt.title = getMessage("nmETVTitleSingle", `ETV: ${etvObj.dataset.etvMin}`, [
					String(etvObj.dataset.etvMin),
				]);
			} else {
				etvTxt.innerText = this._formatETV(etvMinToFormat) + "-" + this._formatETV(etvMaxToFormat);
				etvTxt.title = getMessage("nmETVTitleRange", `ETV: ${etvObj.dataset.etvMin}-${etvObj.dataset.etvMax}`, [
					String(etvObj.dataset.etvMin),
					String(etvObj.dataset.etvMax),
				]);
			}
		} else {
			// Hide span.etv only when ETV is known but "display ETV" is off — keep the span in normal flow when ETV is unknown
			if (etvSpan) {
				if (!this._settings.get("general.displayETV")) {
					etvSpan.style.visibility = "hidden";
				}
			}
			// Clear ETV text content
			if (etvTxt) {
				etvTxt.innerText = "";
				etvTxt.title = "";
			}
		}

		//If Brenda is enabled, toggle the button display according to wether the ETV is known.
		if (brendaAnnounce) {
			if (etvObj.dataset.etvMin === "") {
				brendaAnnounce.style.display = "none";
			} else {
				brendaAnnounce.style.display = "flex";
			}
		}

		const etvMinFinal = isNaN(parseFloat(etvObj.dataset.etvMin)) ? null : parseFloat(etvObj.dataset.etvMin);
		const etvMaxFinal = isNaN(parseFloat(etvObj.dataset.etvMax)) ? null : parseFloat(etvObj.dataset.etvMax);

		// Keyword re-evaluation uses keyword groups only (KeywordMatcherService)
		if (this._settings.get("general.keywordsActive")) {
			const hasEtvConds = etvMinFinal !== null && etvMaxFinal !== null;
			const currentlyHighlighted = notif.dataset.typeHighlight == 1;

			// Only re-evaluate keywords if item is NOT currently highlighted
			if (hasEtvConds && !currentlyHighlighted) {
				if (data.title) {
					// Check keyword match with new ETV values (keyword groups only)
					const matchResult = matcher.findHighlightHideMatchSync(data.title, etvMinFinal, etvMaxFinal);

					// Only treat highlight matches (ignore hide for this re-eval)
					const highlightMatch = matchResult && matchResult.type === "highlight" ? matchResult : null;

					if (highlightMatch) {
						let highlightKeywordString = "";
						if (highlightMatch.contains) {
							highlightKeywordString = highlightMatch.contains;
						}
						if (this._settings.get("general.debugKeywords")) {
							console.log("[NotificationMonitor] #setETV keyword re-evaluation check:", {
								asin,
								hasEtvConditions: hasEtvConds,
								currentlyHighlighted,
								matchResult: highlightMatch,
							});
						}
						this.#highlightedItemFound(notif, data, highlightKeywordString);
					}
				}
			}
		}

		return true;
	}

	/**
	 * Set the ETV for an item. Call it twice with min and max values to set a range.
	 * @param {object} notif - The DOM element of the tile
	 * @param {object} data - The item data
	 * @param {number} etv - The ETV value
	 * @returns {boolean} - True if the ETV was set, false otherwise
	 */
	async #setETV(notif, data, etv) {
		/*
		const {
				asin,
				queue,
				tier,
				date,
				date_added,
				title,
				img_url,
				is_parent_asin,
				is_pre_release,
				enrollment_guid,
				etv_min,
				etv_max,
				KW,
				KWsMatch,
				BlurKW,
				BlurKWsMatch,
				unavailable,
			} = item.data
		*/
		if (!notif) {
			return false;
		}
		const asin = notif.dataset.asin;
		const etvObj = notif.querySelector("div.etv");
		const etvTxt = etvObj.querySelector("span.etv");
		const brendaAnnounce = notif.querySelector("#vh-announce-link-" + asin);

		//Update the ETV value in the hidden fields
		// oldMaxValue kept for potential future use in determining if a new 0ETV was found
		// eslint-disable-next-line no-unused-vars
		let oldMaxValue = etvObj.dataset.etvMax;
		if (etvObj.dataset.etvMin == "" || etv < etvObj.dataset.etvMin) {
			etvObj.dataset.etvMin = etv;
		}

		if (etvObj.dataset.etvMax == "" || etv > etvObj.dataset.etvMax) {
			etvObj.dataset.etvMax = etv;
		}

		// Ensure etvMin is always less than or equal to etvMax
		if (parseFloat(etvObj.dataset.etvMin) > parseFloat(etvObj.dataset.etvMax)) {
			const temp = etvObj.dataset.etvMin;
			etvObj.dataset.etvMin = etvObj.dataset.etvMax;
			etvObj.dataset.etvMax = temp;
		}

		//Display for formatted ETV in the toolbar
		if (etvObj.dataset.etvMin != "" && etvObj.dataset.etvMax != "") {
			etvObj.style.display = "flex";
			let etvMinToFormat = etvObj.dataset.etvMin;
			let etvMaxToFormat = etvObj.dataset.etvMax;
			if (this._settings.isPremiumUser(2)) {
				etvMinToFormat = etvObj.dataset.etvMin * this._settings.get("general.ETV.modifier");
				etvMaxToFormat = etvObj.dataset.etvMax * this._settings.get("general.ETV.modifier");
			}
			if (etvObj.dataset.etvMin == etvObj.dataset.etvMax) {
				etvTxt.innerText = this._formatETV(etvMinToFormat);
				etvTxt.title = getMessage("nmETVTitleSingle", `ETV: ${etvObj.dataset.etvMin}`, [
					String(etvObj.dataset.etvMin),
				]);
			} else {
				etvTxt.innerText = this._formatETV(etvMinToFormat) + "-" + this._formatETV(etvMaxToFormat);
				etvTxt.title = getMessage("nmETVTitleRange", `ETV: ${etvObj.dataset.etvMin}-${etvObj.dataset.etvMax}`, [
					String(etvObj.dataset.etvMin),
					String(etvObj.dataset.etvMax),
				]);
			}
		}

		//If Brenda is enabled, toggle the button display according to wether the ETV is known.
		if (brendaAnnounce) {
			if (etvObj.dataset.etvMin === "") {
				brendaAnnounce.style.display = "none";
			} else {
				brendaAnnounce.style.display = "flex";
			}
		}

		const etvMin = isNaN(parseFloat(etvObj.dataset.etvMin)) ? null : parseFloat(etvObj.dataset.etvMin);
		const etvMax = isNaN(parseFloat(etvObj.dataset.etvMax)) ? null : parseFloat(etvObj.dataset.etvMax);

		// Keyword re-evaluation uses keyword groups only (KeywordMatcherService)
		const matcher = await this.#ensureKeywordMatcher();
		const hasEtvConds = matcher.hasHighlightGroupsWithEtvConditionsSync();
		const currentlyHighlighted = notif.dataset.typeHighlight == 1;

		// Debug: Log why re-evaluation might be triggered
		if (hasEtvConds && currentlyHighlighted && this._settings.get("general.debugKeywords")) {
			console.log(`[KEYWORD-DEBUG] Re-evaluation conditions met:`, {
				asin,
				hasEtvConds,
				currentlyHighlighted,
				hasTitle: !!data.title,
				willTriggerReEvaluation: hasEtvConds && currentlyHighlighted && data.title,
				timestamp: new Date().toISOString(),
			});
		}

		// Debug logging to understand duplicate processing
		if (this._settings.get("general.debugKeywords")) {
			console.log("[NotificationMonitor] #setETV keyword re-evaluation check:", {
				asin,
				hasEtvConditions: hasEtvConds,
				currentlyHighlighted,
				willReEvaluate: hasEtvConds && data.title && !currentlyHighlighted,
				etvMin: etvObj.dataset.etvMin,
				etvMax: etvObj.dataset.etvMax,
				timestamp: Date.now(),
			});
		}

		// Skip re-evaluation if item is already highlighted (matched in stream processing)
		// and continue re-evaluation only for items that might match ETV conditions
		if (hasEtvConds && !currentlyHighlighted) {
			if (data.title) {
				// Check keyword match with new ETV values (keyword groups only)
				const matchResult = matcher.findHighlightHideMatchSync(data.title, etvMin, etvMax);

				// Only treat highlight matches (ignore hide for this re-eval)
				const highlightMatch = matchResult && matchResult.type === "highlight" ? matchResult : null;
				let matchedKeyword = false;
				if (highlightMatch) {
					if (typeof highlightMatch.contains === "string") {
						matchedKeyword = highlightMatch.contains;
					} else if (Array.isArray(highlightMatch.contains) && highlightMatch.contains.length > 0) {
						matchedKeyword = highlightMatch.contains[0];
					} else if (highlightMatch.keyword) {
						matchedKeyword = highlightMatch.keyword;
					}
				}

				const technicalBtn = this._gridContainer.querySelector("#vh-reason-link-" + asin + ">div");

				if (matchedKeyword !== false) {
					// Item matches a highlight keyword
					if (technicalBtn) {
						// Debug logging for updating dataset
						if (this._settings.get("general.debugKeywords")) {
							console.log(
								`[NotificationMonitor] Updating technicalBtn.dataset.highlightkw for ASIN ${asin}: "${matchedKeyword}"`
							);
						}
						technicalBtn.dataset.highlightkw = matchedKeyword;
					}

					// Set the highlight flag and groupId for color/sound
					notif.dataset.typeHighlight = 1;
					if (highlightMatch && highlightMatch.groupId) {
						notif.dataset.highlightGroupId = highlightMatch.groupId;
					}

					// Since we're in the !currentlyHighlighted block, this is always a new highlight
					// Play sound and move to top
					const tileVisible = this.#processNotificationFiltering(notif);

					// Play sound if visible or fetching - use matching group's monitorSound, or fall back to next priority
					if (tileVisible || this._fetchingRecentItems) {
						let soundToPlay = null;
						if (notif.dataset.highlightGroupId) {
							try {
								const { getGroupById } = await import("/scripts/core/utils/KeywordGroupsManager.js");
								const group = await getGroupById(this._settings, notif.dataset.highlightGroupId);
								if (group && group.monitorSound !== null && group.monitorSound !== undefined) {
									soundToPlay = group.monitorSound === "0" ? null : group.monitorSound;
								}
							} catch (error) {
								console.warn("[NotificationMonitor] Error loading group sound:", error);
							}
						}
						// Pass sound (null = use next priority in SoundPlayer)
						this._soundPlayerMgr.play(TYPE_HIGHLIGHT, soundToPlay);
					}

					// Don't handle visibility change here - it will be handled by the caller
					// This prevents double counting when an item is both highlighted and zero ETV
				}
				// Note: No else block needed here because if we're in !currentlyHighlighted
				// and the item doesn't match keywords, it wasn't highlighted before and still isn't
			}
		} else if (hasEtvConds && currentlyHighlighted && data.title) {
			//There are no possible scenario in which an item which previously matched a keyword would no longer match.
			/*
			// Item is already highlighted, but we should check if the matched keyword has ETV conditions
			// that might invalidate the match now that we have actual ETV values
			const technicalBtn = this._gridContainer.querySelector("#vh-reason-link-" + asin + ">div");
			const currentKeyword = technicalBtn?.dataset.highlightkw;

			if (currentKeyword && this.#compiledHighlightKeywords) {
				// Debug: Log re-evaluation details
				const etvMin = parseFloat(etvObj.dataset.etvMin) || null;
				const etvMax = parseFloat(etvObj.dataset.etvMax) || null;
				if (this._settings.get("general.debugKeywords")) {
					console.log(`[KEYWORD-DEBUG] Re-evaluating highlighted item:`, {
						asin,
						currentKeyword,
						title: data.title,
						etvMin,
						etvMax,
						etvObjDataset: { ...etvObj.dataset },
						timestamp: new Date().toISOString(),
					});
				}

				// Check if the current keyword still matches with actual ETV values
				const matchResult = findMatch(data.title, this.#compiledHighlightKeywords, etvMin, etvMax);

				// Extract keyword string from match result
				let matchedKeywordString = null;
				if (matchResult) {
					if (typeof matchResult.contains === "string") {
						matchedKeywordString = matchResult.contains;
					} else if (Array.isArray(matchResult.contains) && matchResult.contains.length > 0) {
						console.log("Is this code ever happening?");
						matchedKeywordString = matchResult.contains[0];
					}
				}

				if (this._settings.get("general.debugKeywords")) {
					console.log(`[KEYWORD-DEBUG] Re-evaluation result:`, {
						asin,
						matchFound: !!matchResult,
						matchedKeyword: matchedKeywordString,
						currentKeyword,
						keywordsMatch: matchedKeywordString === currentKeyword,
						timestamp: new Date().toISOString(),
					});
				}

				// If no match or matched a different keyword, update accordingly
				if (!matchResult || matchedKeywordString !== currentKeyword) {
					if (this._settings.get("general.debugKeywords")) {
						console.log(`[KEYWORD-DEBUG] Removing highlight:`, {
							asin,
							reason: !matchResult ? "no match found" : "different keyword matched",
							previousKeyword: currentKeyword,
							newKeyword: matchedKeywordString,
							compiledKeywords: this.#compiledHighlightKeywords,
							etvMin,
							etvMax,
							title: data.title,
							timestamp: new Date().toISOString(),
						});
					}
					// No longer matches with actual ETV values
					notif.dataset.typeHighlight = 0;
					delete technicalBtn.dataset.highlightkw;
					this.#processNotificationFiltering(notif);
				}
			}
			*/
		}

		// KEYWORD PRIORITY LOGIC (keyword groups only):
		// Hide keywords should ONLY be checked if the item does NOT match a highlight keyword.
		const isHighlighted = notif.dataset.typeHighlight == 1;

		if (!isHighlighted && this._settings.get("notification.hideList") && data.title) {
			const hideMatchResult = matcher.findHighlightHideMatchSync(data.title, etvMin, etvMax);

			if (hideMatchResult && hideMatchResult.type === "hide") {
				let hideKeywordString = "";
				if (typeof hideMatchResult.contains === "string") {
					hideKeywordString = hideMatchResult.contains;
				} else if (Array.isArray(hideMatchResult.contains) && hideMatchResult.contains.length > 0) {
					hideKeywordString = hideMatchResult.contains[0];
				} else if (hideMatchResult.keyword) {
					hideKeywordString = hideMatchResult.keyword;
				}

				if (this._settings.get("general.debugKeywords")) {
					console.log("[setETV] Hide keyword matched for", data, hideKeywordString);
				}
				this._log.add(`NOTIF: Item ${asin} matched hide keyword ${hideKeywordString}. Hiding it.`);

				const element = this._itemsMgr.getItemDOMElement(asin);
				if (element) {
					this.#removeTile(asin);
				} else {
					console.warn(`Hide keyword matched for ${asin} but tile not fully registered. Skipping.`);
				}
				return true; // Exit early since item is processed
			}
		}

		//Set the highlight color as needed
		this._processNotificationHighlight(notif);
		this.#processNotificationFiltering(notif);

		//this.#disableGoldItemsForSilverUsers(notif);

		return true;
	}

	/**
	 * Check if an item has Zero ETV and handle visibility changes
	 * This is separated from #setETV to avoid duplicate checks when setting min/max
	 * @param {HTMLElement} notif - The notification element
	 */
	#checkZeroETVStatus(notif) {
		if (!notif) return;

		const etvObj = notif.querySelector("div.etv");
		if (!etvObj) return;

		// Debug logging for ETV status check
		if (this._settings.get("general.debugItemProcessing")) {
			const asin = notif.id?.replace("vh-notification-", "") || "unknown";
			console.log("[DEBUG-ETV-STYLING] Checking Zero ETV status", {
				asin,
				etvMin: etvObj.dataset.etvMin,
				etvMax: etvObj.dataset.etvMax,
				typeUnknownETV: notif.dataset.typeUnknownETV,
				typeZeroETV: notif.dataset.typeZeroETV,
				typeHighlight: notif.dataset.typeHighlight,
				currentFilterType: this.#getCurrentFilterType(),
				isUnknownETVFilter: this.#getCurrentFilterType() === TYPE_UNKNOWN_ETV,
				timestamp: new Date().toISOString(),
			});
		}

		// Track if we need to update styling
		let needsStylingUpdate = false;

		// Clear unknown ETV flag if we now have ETV values
		if (notif.dataset.typeUnknownETV == 1 && etvObj.dataset.etvMin !== "" && etvObj.dataset.etvMax !== "") {
			const asin = notif.id?.replace("vh-notification-", "") || "unknown";
			debugItemProcessing(this, "etv.clearingUnknownETV", {
				asin,
				wasUnknownETV: true,
				typeHighlight: notif.dataset.typeHighlight,
				typeZeroETV: notif.dataset.typeZeroETV,
				currentFilterType: this.#getCurrentFilterType(),
				isUnknownETVFilter: this.#getCurrentFilterType() === TYPE_UNKNOWN_ETV,
				TYPE_UNKNOWN_ETV_VALUE: TYPE_UNKNOWN_ETV,
				etvMin: etvObj.dataset.etvMin,
				etvMax: etvObj.dataset.etvMax,
			});

			notif.dataset.typeUnknownETV = 0;
			needsStylingUpdate = true;

			// Re-apply filter since the item no longer matches unknown ETV criteria
			if (this.#getCurrentFilterType() === TYPE_UNKNOWN_ETV) {
				debugItemProcessing(this, "etv.hidingItemNoLongerMatches", {
					asin,
					filterType: this.#getCurrentFilterType(),
				});

				// Re-apply the filter to this specific item
				const newVisibility = this.#processNotificationFiltering(notif);

				debugItemProcessing(this, "etv.filterReapplied", {
					asin,
					newVisibility,
					shouldBeHidden: !newVisibility,
				});
			}
		}

		//zero ETV found, highlight the item accordingly
		if (parseFloat(etvObj.dataset.etvMin) == 0) {
			// Only process if we haven't already marked this as zero ETV
			const wasAlreadyZeroETV = notif.dataset.typeZeroETV === "1";

			// Get ASIN from the notification element
			const asin = notif.dataset.asin;

			// Check if we're already processing this item to prevent duplicate processing
			const isAlreadyProcessing = this.#etvProcessingItems.has(asin);

			if (!wasAlreadyZeroETV && !isAlreadyProcessing) {
				// Mark as processing
				this.#etvProcessingItems.add(asin);

				try {
					// Set the flag before calling the handler
					notif.dataset.typeZeroETV = 1;
					needsStylingUpdate = true;

					// Only call the item found handler for sound and sorting
					// The handler will process filtering and update visibility
					this.#zeroETVItemFound(
						notif,
						this._settings.get("notification.monitor.zeroETV.sound") != "0",
						false
					);
				} finally {
					// Always remove from processing set
					this.#etvProcessingItems.delete(asin);
				}
			}
		} else {
			// Clear the zero ETV flag when item is not zero ETV
			if (notif.dataset.typeZeroETV == 1) {
				notif.dataset.typeZeroETV = 0;
				// Re-apply filtering to update visibility
				this.#processNotificationFiltering(notif);
			}
		}

		// Apply styling update once after all flag changes
		if (needsStylingUpdate) {
			this._processNotificationHighlight(notif);
		}
	}

	/**
	 * Set the tier for an item
	 * @param {string} asin - The ASIN of the item
	 * @param {string} tier - The tier value (silver or gold)
	 * @returns {boolean} - True if the tier was set, false otherwise
	 */
	async setTierFromASIN(asin, tier) {
		if (!this._itemsMgr.items.has(asin)) {
			return false;
		}

		if (!this._itemsMgr.updateItemTier(asin, tier)) {
			return false;
		}

		// Get the corresponding DOM element
		const notif = this._itemsMgr.getItemDOMElement(asin);
		if (!notif) {
			return false;
		}

		// Update the DOM element
		notif.dataset.tier = tier;
		const vvpDetailsBtn = notif.querySelector(".vvp-details-btn, .vh-details-btn");
		if (vvpDetailsBtn) {
			vvpDetailsBtn.dataset.tier = tier;
		}

		return true;
	}

	/**
	 * Set the ETV for an item
	 * Called when an ETV update is received from the server.
	 * @param {string} asin - The ASIN of the item
	 * @param {float} etv - The ETV value
	 * @returns {boolean} - True if the ETV was set, false otherwise
	 */
	async setETVFromASIN(asin, etv) {
		// Store old ETV value to detect if reordering is needed
		const oldETV = this._itemsMgr.items.get(asin)?.data?.etv_min || null;

		// Update the data in our Map
		if (!this._itemsMgr.updateItemETV(asin, etv)) {
			return false;
		}

		// Get the corresponding DOM element
		const notif = this._itemsMgr.getItemDOMElement(asin);
		if (!notif) {
			return false;
		}

		const data = this._itemsMgr.items.get(asin)?.data;
		if (!data) {
			return false;
		}

		// Update the DOM element
		this.#setETV(notif, data, etv);

		// Check Zero ETV status after update
		this.#checkZeroETVStatus(notif);

		// Re-position the item if using price sort and the value changed significantly
		if (this.#getCurrentSortType() === TYPE_PRICE_DESC || this.#getCurrentSortType() === TYPE_PRICE_ASC) {
			this.#ETVChangeRepositioning(asin, oldETV);
		}

		return true;
	}

	setPriceFromASIN(asin, price) {
		const notif = this._itemsMgr.getItemDOMElement(asin);
		if (!notif) {
			return false;
		}
		this.#setPrice(notif, price);
		return true;
	}

	#setPrice(notif, price) {
		if (!this._settings.isPremiumUser(3) || !this._settings.get("general.displayPrice")) {
			return;
		}
		const etvObj = notif.querySelector("div.etv");
		etvObj.style.display = "flex";

		const priceTxt = etvObj.querySelector("span.price");

		if (priceTxt && price !== null && price !== undefined) {
			const formattedPrice = new Intl.NumberFormat(this._i18nMgr.getLocale(), {
				style: "currency",
				currency: this._i18nMgr.getCurrency(),
			}).format(price);
			priceTxt.textContent = formattedPrice;
			priceTxt.title = `Amazon Price: ${formattedPrice}`;
			priceTxt.classList.add("defined");
		}
	}

	setAdditionalImagesFromASIN(asin, additionalImages) {
		if (!this._settings.isPremiumUser(3) || !this._settings.get("notification.monitor.carousel.active")) {
			return;
		}
		const tile = this._itemsMgr.getItemTile(asin);
		if (tile) {
			const tileDOM = tile.getDOM();
			this.#tileIntegrityService?.unlockTile(tileDOM);
			tile.setAdditionalImages(additionalImages);
			this.#tileIntegrityService?.lockTile(tileDOM);
		}
	}

	#send0ETVToWebhook(asin) {
		const item = this._itemsMgr.items.get(asin);
		if (
			!item ||
			this._feedPaused ||
			!this._settings.isPremiumUser(3) ||
			!this._settings.get("discord.webhook.zeroETV.active")
		) {
			return false;
		}

		let body = this._settings.get("discord.webhook.zeroETV.content");
		const QUEUE_NAME = this.#queueToAbbr(item.data.queue);
		body = body.replaceAll("$ASIN", asin);
		body = body.replaceAll("$QUEUE_NAME", QUEUE_NAME);
		body = body.replaceAll("$ETV", 0);
		body = body.replaceAll("$TITLE", item.data.title);
		body = body.replaceAll("$IMG_URL", item.data.img_url);
		body = body.replaceAll("$VH_URL", item.getVHOpenModalURL());
		body = body.replaceAll("$VINE_SEARCH_URL", item.getVineSearchURL());
		body = body.replaceAll("$AMZ_URL", item.getAmazonURL());
		this.#webhookQueue.queue(this._settings.get("discord.webhook.zeroETV.url"), {
			method: this._settings.get("discord.webhook.zeroETV.method"),
			headers: {
				"Content-Type": "application/json",
			},
			body: body,
		});
	}

	/**
	 * Reposition the item if using price sort and the value changed significantly
	 * @param {string} asin - The ASIN of the item
	 * @param {float} oldETV - The old ETV value
	 * @returns {boolean} - True if the item was repositioned, false otherwise
	 */
	#ETVChangeRepositioning(asin, oldETV) {
		const newETV = this._itemsMgr.items.get(asin)?.data?.etv_min || 0;
		const notif = this._itemsMgr.items.get(asin)?.element;
		if (!notif) {
			return false;
		}

		// Only reposition if the ETV changed significantly enough to potentially affect order
		if (oldETV === null || Math.abs(newETV - oldETV) > ETV_REPOSITION_THRESHOLD) {
			// First, check if repositioning is actually needed by finding the current position
			const newPrice = parseFloat(newETV);
			let currentIndex = -1;
			let targetIndex = -1;
			let index = 0;

			// Get all items in order
			const orderedItems = Array.from(this._gridContainer.children);

			// Find current position and calculate target position
			for (const element of orderedItems) {
				const itemAsin = element.dataset.asin;
				if (itemAsin === asin) {
					currentIndex = index;
				} else if (itemAsin) {
					const item = this._itemsMgr.items.get(itemAsin);
					if (item && item.data) {
						const existingPrice = parseFloat(item.data.etv_min) || 0;

						// Determine if this item should come after our repositioned item
						if (targetIndex === -1) {
							if (this.#getCurrentSortType() === TYPE_PRICE_DESC && newPrice > existingPrice) {
								targetIndex = index;
							} else if (this.#getCurrentSortType() === TYPE_PRICE_ASC && newPrice < existingPrice) {
								targetIndex = index;
							}
						}
					}
				}
				index++;
			}

			// If no target position found, item should go to the end
			if (targetIndex === -1) {
				targetIndex = orderedItems.length - 1;
			}

			// Adjust target index if current item is before it
			if (currentIndex !== -1 && currentIndex < targetIndex) {
				targetIndex--;
			}

			// Only reposition if the item needs to move
			if (currentIndex !== targetIndex && currentIndex !== -1) {
				// Use atomic DOM update to prevent visual shifts
				// Build the new order in a document fragment
				const fragment = document.createDocumentFragment();
				const allItems = Array.from(this._gridContainer.children);

				// Remove the item from its current position
				allItems.splice(currentIndex, 1);

				// Insert at the target position
				allItems.splice(targetIndex, 0, notif);

				// Move actual nodes (not clones) to the fragment to maintain DOM state
				// This prevents memory leaks from detached cloned nodes
				allItems.forEach((item) => {
					fragment.appendChild(item);
				});

				// Replace all children atomically by appending the fragment
				// This moves all nodes from fragment to container in one operation
				// The fragment will be automatically cleared after this operation
				this._gridContainer.replaceChildren();
				this._gridContainer.appendChild(fragment);

				return true;
			}
		}

		return false;
	}

	/**
	 * Bump zero-ETV tile to the logical front for date-desc by moving its DOM node.
	 * @param {HTMLElement} notif
	 */
	#applyBumpZeroEtvPlacement(notif) {
		const asin = notif?.dataset?.asin;
		if (!asin) {
			return;
		}
		this._moveNotifToTop(notif);
	}

	/**
	 * Common handler for item found events
	 * This is the common code between zeroETVItemFound, highlightedItemFound, and regularItemFound
	 * @param {object} notif - The DOM element of the tile
	 * @param {string} itemType - The type of item (TYPE_ZEROETV, TYPE_HIGHLIGHT, TYPE_REGULAR)
	 * @param {boolean} playSoundEffect - If true, play the sound effect
	 * @param {boolean} skipFiltering - If true, skip re-processing filtering (used when called from ETV processing)
	 * @returns {boolean} - True if the item was found, false otherwise
	 * @private
	 */
	async #handleItemFound(notif, itemType, playSoundEffect = true, skipFiltering = false) {
		if (!notif) {
			return false;
		}

		// Note: Type flags (typeZeroETV, typeHighlight) should already be set
		// before this method is called to ensure proper counting

		let tileVisible;
		if (skipFiltering) {
			// Just check current visibility without re-processing
			tileVisible = this.#isElementVisible(notif);
		} else {
			// Re-process filtering to get current visibility state
			tileVisible = this.#processNotificationFiltering(notif);
		}

		// Play sound effect if conditions are met
		const shouldPlaySound = (tileVisible || this._fetchingRecentItems) && playSoundEffect;

		debugSound(this, "sound.handleItemFound", {
			asin: notif.dataset?.asin,
			itemType,
			tileVisible,
			_fetchingRecentItems: this._fetchingRecentItems,
			playSoundEffect,
			shouldPlaySound,
			currentFilter: this.#getCurrentFilterType(),
			filterName:
				this.#getCurrentFilterType() === TYPE_HIGHLIGHT
					? "KW match only"
					: this.#getCurrentFilterType() === TYPE_HIGHLIGHT_OR_ZEROETV
						? "Zero ETV or KW match only"
						: this.#getCurrentFilterType() === TYPE_ZEROETV
							? "Zero ETV only"
							: "No filter",
			typeHighlight: notif.dataset?.typeHighlight,
			typeZeroETV: notif.dataset?.typeZeroETV,
		});

		if (shouldPlaySound) {
			let highlightSound = undefined;
			let highlightVolume = undefined;
			if (itemType === TYPE_HIGHLIGHT) {
				if (notif.dataset.highlightGroupId) {
					try {
						const { getGroupById } = await import("/scripts/core/utils/KeywordGroupsManager.js");
						const group = await getGroupById(this._settings, notif.dataset.highlightGroupId);
						// Pass group's monitorSound; null = no sound for this group, fall to next priority
						highlightSound =
							group &&
							group.monitorSound !== null &&
							group.monitorSound !== undefined &&
							group.monitorSound !== "0"
								? group.monitorSound
								: null;
						// Pass group's monitorVolume when defined (0–1)
						if (
							group &&
							typeof group.monitorVolume === "number" &&
							group.monitorVolume >= 0 &&
							group.monitorVolume <= 1
						) {
							highlightVolume = group.monitorVolume;
						}
					} catch (error) {
						console.warn("[NotificationMonitor] Error loading group sound:", error);
						highlightSound = null;
					}
				} else {
					highlightSound = null; // No group = use next priority
				}
			}
			this._soundPlayerMgr.play(itemType, highlightSound, highlightVolume);

			const itemTitle = notif.querySelector(".vvp-item-product-title-container").innerText;
			this._soundPlayerMgr.speak(itemType, itemTitle);
		}

		runAfterItemFoundPlacement(
			{
				itemType,
				fetchingRecentItems: this._fetchingRecentItems,
				getCurrentSortType: () => this.#getCurrentSortType(),
				settingsGet: (k) => this._settings.get(k),
				notif,
			},
			{
				sortItems: () => this.#sortItems(),
				moveNotifToTop: (el) => this.#applyBumpZeroEtvPlacement(el),
				noShiftGrid: this._noShiftGrid,
				recountVisibleTiles: (wait, opts) => this._tileCounter.recountVisibleTiles(wait, opts),
			}
		);

		return true;
	}

	async #regularItemFound(notif, playSoundEffect = true, skipFiltering = false) {
		return await this.#handleItemFound(notif, TYPE_REGULAR, playSoundEffect, skipFiltering);
	}

	async #rfyItemFound(notif, playSoundEffect = true, skipFiltering = false) {
		return await this.#handleItemFound(notif, TYPE_RFY, playSoundEffect, skipFiltering);
	}

	/**
	 * Handle the zero ETV item found event
	 * @param {object} notif - The DOM element of the tile
	 * @param {boolean} playSoundEffect - If true, play the zero ETV sound effect
	 * @returns {boolean} - True if the zero ETV item was found, false otherwise
	 */
	async #zeroETVItemFound(notif, playSoundEffect = true, skipFiltering = false) {
		//If the item is already a known 0 etv, check if we need to send a 0 ETV webhook call:
		// Send the ETV change to the webhook
		const etv = this._itemsMgr.items.get(notif.dataset.asin)?.data?.etv_min;
		const asin = notif.dataset.asin;
		if (
			this._settings.isPremiumUser(3) &&
			this._settings.get("discord.webhook.zeroETV.active") &&
			etv !== null &&
			etv !== undefined &&
			!isNaN(parseFloat(etv)) &&
			parseFloat(etv) === 0
		) {
			this.#send0ETVToWebhook(asin);
		}

		return await this.#handleItemFound(notif, TYPE_ZEROETV, playSoundEffect, skipFiltering);
	}

	async #highlightedItemFound(notif, playSoundEffect = true, skipFiltering = false) {
		return await this.#handleItemFound(notif, TYPE_HIGHLIGHT, playSoundEffect, skipFiltering);
	}

	#sortItems() {
		const sortedItems = this._itemsMgr.sortItems();
		this._gridLayout.applySort(sortedItems);
	}

	/**
	 * Properly clear the grid container to prevent memory leaks
	 * This method ensures all DOM elements are properly removed without creating detached nodes
	 * CRITICAL: Destroys Tile instances (including Splide carousels) BEFORE removing DOM elements
	 * to prevent memory leaks from detached Splide instances
	 * @param {HTMLElement} container - Optional container to clear. If not provided, uses this._gridContainer
	 * @protected
	 */
	_clearGridContainer(container = null) {
		const targetContainer = container || this._gridContainer;

		// Get all children before manipulation (children list changes as we remove items)
		const children = Array.from(targetContainer.children);

		// Clean up VHelper tiles properly - only for elements still in the grid
		for (const child of children) {
			// For placeholder tiles, skip cleanup (they don't have Tile instances)
			if (child.classList.contains("vh-placeholder-tile")) {
				continue;
			}

			// For item tiles, destroy the Tile instance first to clean up Splide carousels
			const asin = child.id?.replace("vh-notification-", "");
			if (asin) {
				// Get and destroy the Tile instance (this destroys Splide carousels, VariantButtons, etc.)
				const tile = this._itemsMgr.getItemTile(asin);
				if (tile && typeof tile.destroy === "function") {
					try {
						tile.destroy();
					} catch (e) {
						// Log but don't fail if destroy has issues
						console.warn(`[NotificationMonitor] Error destroying tile for ${asin}:`, e);
					}
				}

				// Clean up any tooltips
				const linkElement = child.querySelector(".a-link-normal");
				if (linkElement) {
					this._tooltipMgr.removeTooltip(linkElement);
				}

				// Clean up dataset properties that might hold references
				if (child.dataset) {
					delete child.dataset.vhOriginalTitle;
					delete child.dataset.vhTileInstance;
				}

				// Clear any direct references on the element
				child.vhTileInstance = null;

				// Notify memory debugger BEFORE removing from DOM
				if (window.MEMORY_DEBUGGER) {
					window.MEMORY_DEBUGGER.markRemoved(child);
				}
			}
		}

		// Now use the most efficient method to clear the container
		if (targetContainer.replaceChildren) {
			// Modern browsers - most efficient method that prevents detached nodes
			targetContainer.replaceChildren();
		} else {
			// Fallback for older browsers
			while (targetContainer.firstChild) {
				targetContainer.removeChild(targetContainer.firstChild);
			}
		}
	}

	//############################################################
	//## CLICK HANDLERS (for tiles' icons)
	//############################################################

	/**
	 * Show the connection details modal (public for SW response via BroadcastChannel).
	 * @param {Object} data - Connection details data
	 */
	showConnectionDetailsModalFromData(data) {
		this.#showConnectionDetailsModal(data || {});
	}

	/**
	 * Show the connection details modal
	 * @param {Object} data - Connection details data
	 */
	#showConnectionDetailsModal(data) {
		let m = this._dialogMgr.newModal("connection-details");
		m.title = "WebSocket Connection Details";
		m.content = `
			<ul style="margin-bottom: 10px;">
				<li>Socket ID: ${data.socketId || "N/A"}</li>
				<li>Tier: ${data.tier || "N/A"}</li>
				<li>Connection(s): ${data.connectionUsed !== undefined && data.connectionUsed !== null ? data.connectionUsed : "N/A"}/${data.connectionAllowed !== undefined && data.connectionAllowed !== null ? data.connectionAllowed : "N/A"}
					<table id="vh-conn-details-table" style="width:100%; border-collapse: collapse; margin-top:10px;">
						<thead>
							<tr>
								<th style="border-bottom: 1px solid #ccc; text-align:left; padding:4px;">Socket Id</th>
								<th style="border-bottom: 1px solid #ccc; text-align:left; padding:4px;">Device Name</th>
								<th style="border-bottom: 1px solid #ccc; text-align:left; padding:4px;">Action</th>
							</tr>
						</thead>
						<tbody>
							${Object.entries(data.devices || {})
								.map(
									([socketId, deviceName]) => `
										<tr>
											<td style="border-bottom: 1px solid #eee; padding:4px 8px;">${socketId}</td>
											<td style="border-bottom: 1px solid #eee; padding:4px 8px;">${deviceName}</td>
											<td style="border-bottom: 1px solid #eee; padding:4px 8px;">
												<button 
													class="vh-disconnect-btn"
													data-socket-id="${socketId}"
													style="color:#fff; background:#d32f2f; border:none; border-radius:3px; padding:2px 12px; cursor:pointer; font-size:0.95em;"
												>
													Disconnect
												</button>
											</td>
										</tr>
									`
								)
								.join("")}
						</tbody>
					</table>
				</li>
			</ul>
		`;
		m.show();

		// Remove existing disconnect button handler if it exists (to ensure only one listener is active)
		if (this.#disconnectButtonHandler) {
			document.removeEventListener("click", this.#disconnectButtonHandler);
		}

		// Set up new disconnect button handler using event delegation
		this.#disconnectButtonHandler = (e) => {
			const disconnectBtn = e.target.closest(".vh-disconnect-btn");
			if (disconnectBtn) {
				const socketId = disconnectBtn.getAttribute("data-socket-id");
				if (socketId) {
					this.#disconnectSocket(socketId);
					// Deactivate the button after it has been clicked
					disconnectBtn.disabled = true;
					disconnectBtn.style.background = "#444";
				}
			}
		};

		// Add the click listener to the document (event delegation)
		document.addEventListener("click", this.#disconnectButtonHandler);
	}

	/**
	 * Disconnect a socket by sending a disconnect request through the websocket
	 * @param {string} socketId - The socket ID to disconnect
	 * @private
	 */
	async #disconnectSocket(socketId) {
		try {
			const cid = await this._env.getCID();
			const uuid = this._settings.get("general.uuid", false);
			const fid = this._settings.get("general.fingerprint.id", false);
			const deviceName = this._settings.get("general.deviceName", false);
			const countryCode = this._i18nMgr.getCountryCode();
			const appVersion = chrome.runtime.getManifest().version;

			await this._sendMessageToWebsocket({
				type: "disconnectRequest",
				socketId: socketId,
				cid: cid,
				uuid: uuid,
				countryCode: countryCode,
				fid: fid,
				app_version: appVersion,
				device_name: deviceName,
			});
		} catch (err) {
			console.error("MONITOR: Failed to send disconnect request: " + err.message);
		}
	}

	/**
	 * Send a report to VH's server
	 * @param {string} asin - The ASIN of the item
	 */
	async #send_report(asin) {
		let manifest = chrome.runtime.getManifest();

		const content = {
			api_version: 5,
			app_version: manifest.version,
			action: "report_asin",
			country: this._i18nMgr.getCountryCode(),
			uuid: this._settings.get("general.uuid", false),
			cid: await this._env.getCID(),
			asin: asin,
		};
		const s = await this._cryptoKeys.signData(content);
		content.s = s;
		content.pk = await this._cryptoKeys.getExportedPublicKey();
		const options = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		};

		//Send the report to VH's server
		fetch(this._env.getAPIUrl(), options).then(function () {
			alert("Report sent. Thank you.");
		});
	}

	#buildIntegrityIncidentComment(reason, failedTile, failedAt) {
		const asin = failedTile?.dataset?.asin ?? failedTile?.id ?? "?";
		const tag = failedAt?.liveElement?.tagName ? ` ${failedAt.liveElement.tagName}` : "";
		const path = failedAt?.path ? ` at ${failedAt.path}` : "";
		return `DOM integrity failed${tag} tile ${asin}${path}: ${reason ?? "structure mismatch"}`;
	}

	#sendIntegrityIncidentReport(reason, failedTile, failedAt) {
		sendIntegrityIncidentReport({
			manifest: chrome.runtime.getManifest(),
			i18n: this._i18nMgr,
			settings: this._settings,
			env: this._env,
			cryptoKeys: this._cryptoKeys,
			comment: this.#buildIntegrityIncidentComment(reason, failedTile, failedAt),
		}).catch((err) => {
			console.warn("[NotificationMonitor] Failed to report DOM integrity incident:", err);
		});
	}

	/**
	 * Apply filtering to all grid items
	 * @private
	 */
	#applyFilteringToAllItems() {
		this._gridLayout.forEachTile((el) => {
			this.#processNotificationFiltering(el, false, true);
		});

		// All filtering is complete

		// Trigger sort after filtering is complete
		this.#sortItems();

		// IMPORTANT: Recount visible tiles AFTER atomic update completes
		// This ensures the DOM is fully updated before counting
		// Use requestAnimationFrame to ensure DOM has been painted
		// NOTE: Skip recount if feed is paused - the feed-unpause event will handle it
		if (!this._feedPaused) {
			requestAnimationFrame(() => {
				if (this._tileCounter) {
					this._tileCounter.recountVisibleTiles(0, true, { isBulkOperation: true, source: "filter-change" }); // 0 wait time, priority = true, source = filter-change
				}
				if (this._noShiftGrid && this.#getCurrentSortType() == TYPE_DATE_DESC) {
					this._noShiftGrid.resetEndPlaceholdersCount();
					this._noShiftGrid.insertPlaceholderTiles();
				}
			});
		}
	}

	#mouseoverHandler(e) {
		handleGridMouseover(this, e);
	}

	/**
	 * Handle all click events in the monitor
	 * @param {Event} e - The click event
	 */
	#clickHandler(e) {
		handleGridClick(this, e);
	}
	/**
	 * Apply Order Now button colors based on settings
	 * @private
	 */
	async #applyOrderNowButtonColors() {
		await this._settings.waitForLoad();
		const colorNonVariants = this._settings.get("general.orderNow.colorNonVariants", "#ffa41c");
		const colorVariants = this._settings.get("general.orderNow.colorVariants", "#ffa41c");

		// Set CSS custom properties for dynamic color application
		document.documentElement.style.setProperty("--vh-order-now-color-non-variants", colorNonVariants);
		document.documentElement.style.setProperty("--vh-order-now-color-variants", colorVariants);
	}

	/**
	 * Get the set of tile elements (.vvp-item-tile) that contain any of the mutated nodes.
	 * @param {MutationRecord[]} mutations
	 * @returns {Set<Element>}
	 * @private
	 */
	#getAffectedTilesFromMutations(mutations) {
		return collectAffectedTilesFromMutations(mutations);
	}

	/**
	 * Check only the given tiles that are locked; skip others. Used when mutations affect specific tiles.
	 * @param {Set<Element>} affectedTiles
	 * @returns {{ ok: boolean, failedTile?: Element, reason?: string, failedAt?: { liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string } }}
	 * @private
	 */
	#checkAffectedTilesIntegrity(affectedTiles) {
		return validateAffectedLockedTiles(affectedTiles, this.#tileIntegrityService, this.#tileIntegrityLocked);
	}

	/**
	 * Check that all tiles in the grid match their locked snapshot. Used only for initial check on startup.
	 * @returns {{ ok: boolean, failedTile?: Element, reason?: string, failedAt?: { liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string } }} ok false and details when a tile fails
	 * @private
	 */
	#checkTileIntegrity() {
		if (!this._gridContainer || this.#tileIntegrityLocked) return { ok: true };
		if (this._gridLayout.shouldSkipTileIntegrity()) {
			return { ok: true };
		}
		const tiles = this._gridContainer.querySelectorAll(".vvp-item-tile:not(.vh-placeholder-tile)");
		for (const tile of tiles) {
			const result = this.#tileIntegrityService?.validateTile(tile);
			if (result && !result.valid) {
				return { ok: false, failedTile: tile, reason: result.reason, failedAt: result.failedAt };
			}
		}
		return { ok: true };
	}

	/**
	 * Check if an integrity failure is likely from VHelper-internal structure (e.g. carousel add/remove, Splide).
	 * In such cases we re-snapshot instead of locking the monitor.
	 * @param {{ liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string }} [failedAt]
	 * @returns {boolean}
	 * @private
	 */
	#isVHelperInternalIntegrityFailure(failedAt) {
		return isAllowedVHelperInternalIntegrityFailure(failedAt, this._settings);
	}

	/**
	 * Handle tile integrity failure: re-snapshot if it looks like VHelper-internal change (carousel, variant indicator),
	 * otherwise lock the monitor. Prevents monitor lock on benign structure changes (e.g. Splide destroying carousel).
	 * @param {{ ok: boolean, failedTile?: Element, reason?: string, failedAt?: object }} check
	 * @private
	 */
	#handleIntegrityFailure(check) {
		if (check.ok || !check.failedTile) return;
		if (this.#isVHelperInternalIntegrityFailure(check.failedAt)) {
			// Re-snapshot the tile and continue; log so it's visible if it recurs
			this.#tileIntegrityService?.lockTile(check.failedTile);
			const asin = check.failedTile?.dataset?.asin ?? check.failedTile?.id ?? "?";
			console.warn(
				"[NotificationMonitor] Tile integrity mismatch (VHelper-internal structure change) — re-snapshot tile ASIN:",
				asin,
				check.reason ?? ""
			);
			return;
		}
		this.#lockDueToExternalChanges(check.reason, check.failedTile, check.failedAt);
	}

	/**
	 * Lock the monitor and show "External changes detected." overlay. Logs full diagnostic to console.
	 * @param {string} [reason] - Why integrity failed
	 * @param {Element} [failedTile] - The tile that failed
	 * @param {{ liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string }} [failedAt] - Node where child count mismatched (for debug)
	 * @private
	 */
	#lockDueToExternalChanges(reason, failedTile, failedAt) {
		if (this.#tileIntegrityLocked) return;
		this.#tileIntegrityLocked = true;
		if (this.#tileIntegrityRafId != null) {
			cancelAnimationFrame(this.#tileIntegrityRafId);
			this.#tileIntegrityRafId = null;
		}
		this.#tileIntegrityPendingMutations = null;
		if (this.#tileIntegrityObserver) {
			this.#tileIntegrityObserver.disconnect();
			this.#tileIntegrityObserver = null;
		}

		// Build debug info for overlay (copyable) and optional console
		const debugLines = [];
		const asin = failedTile?.dataset?.asin ?? failedTile?.id ?? "?";
		debugLines.push("[NotificationMonitor] *** MONITOR LOCKED (tile integrity failed) ***");
		debugLines.push("[NotificationMonitor] Failed tile ASIN: " + asin);
		debugLines.push("[NotificationMonitor] Reason: " + (reason ?? "structure mismatch"));

		if (failedAt) {
			const el = failedAt.liveElement;
			const isElementMismatch = failedAt.expectedChildCount < 0;

			if (isElementMismatch) {
				debugLines.push(
					"[NotificationMonitor] Where it failed — path: " +
						failedAt.path +
						" | node: <" +
						el.tagName +
						"> " +
						(el.classList?.[0] ?? "(no class)")
				);
				const html = el.outerHTML ?? (el.cloneNode && el.cloneNode(true).outerHTML) ?? String(el);
				debugLines.push("[NotificationMonitor] Unexpected HTML (wrong tag or class):");
				debugLines.push(html);
			} else {
				const elementChildren = Array.from(el.childNodes).filter((n) => n.nodeType === Node.ELEMENT_NODE);
				const childSummary = elementChildren
					.map((c, i) => `[${i}] <${c.tagName}>.${c.classList?.[0] ?? ""}`)
					.join(", ");
				debugLines.push(
					"[NotificationMonitor] Where it failed — path: " +
						failedAt.path +
						" | expected " +
						failedAt.expectedChildCount +
						" child(ren), live has " +
						failedAt.actualChildCount +
						" | node: <" +
						el.tagName +
						"> " +
						(el.classList?.[0] ?? "(no class)") +
						" | live children: " +
						(childSummary || "(none)")
				);
				if (failedAt.actualChildCount > failedAt.expectedChildCount) {
					const extraNodes = elementChildren.slice(failedAt.expectedChildCount);
					debugLines.push("[NotificationMonitor] Unexpected HTML (extra node(s)):");
					for (let i = 0; i < extraNodes.length; i++) {
						const node = extraNodes[i];
						const html =
							node.outerHTML ?? (node.cloneNode && node.cloneNode(true).outerHTML) ?? String(node);
						debugLines.push(`--- extra child [${failedAt.expectedChildCount + i}] ---`);
						debugLines.push(html);
					}
				}
			}
		}
		if (failedTile) {
			const failedTileSnapshot =
				failedTile.outerHTML ||
				(failedTile.cloneNode && failedTile.cloneNode(true).outerHTML) ||
				String(failedTile);
			debugLines.push("[NotificationMonitor] Failed tile element HTML snapshot:");
			debugLines.push(failedTileSnapshot);
		}
		let debugText = debugLines.join("\n");
		// Redact any quoted attribute value containing vine.enrollment (for privacy)
		debugText = debugText.replace(/"([^"]*vine\.enrollment[^"]*)"/g, '"[REDACTED]"');

		if (EXTERNAL_CHANGES_LOCK_DEBUG) {
			console.warn(debugText);
		}
		this.#sendIntegrityIncidentReport(reason, failedTile, failedAt);

		const overlay = document.createElement("div");
		overlay.id = "vh-tile-integrity-lock-overlay";
		overlay.setAttribute("role", "alert");
		overlay.style.cssText =
			"position:fixed;inset:0;background:rgba(0,0,0,0.85);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1rem;z-index:99999;color:#fff;font-family:system-ui,sans-serif;font-size:1.5rem;text-align:center;padding:1.5rem;box-sizing:border-box;";

		const message = document.createElement("p");
		message.style.margin = "0";
		message.textContent =
			"Another extension or userscript is interfering with VHelper. Monitor has been disabled. Copy the debug info below to report this issue.";

		const debugBox = document.createElement("textarea");
		debugBox.value = debugText;
		debugBox.readOnly = true;
		debugBox.style.cssText =
			"width:min(90vw,700px);height:min(40vh,300px);padding:0.75rem;font-family:monospace;font-size:0.7rem;line-height:1.4;background:#1a1a1a;color:#e0e0e0;border:1px solid #444;border-radius:4px;resize:none;box-sizing:border-box;";

		overlay.appendChild(message);
		overlay.appendChild(debugBox);
		document.body.appendChild(overlay);

		this.#unloadMonitorDueToExternalChanges();
	}

	/**
	 * Fully unload the monitor when external change is detected: remove grid from DOM, close WebSocket (tab mode, no reconnect), stop ServerCom and AutoLoad.
	 * @private
	 */
	#unloadMonitorDueToExternalChanges() {
		// Destroy NoShiftGrid first so ResizeObserver and timers stop (prevents querySelectorAll on null after we null _gridContainer)
		if (this._noShiftGrid && typeof this._noShiftGrid.destroy === "function") {
			this._noShiftGrid.destroy();
			this._noShiftGrid = null;
		}

		// Remove grid click listener before removing from DOM
		if (this.#eventHandlers.grid && this._gridContainer) {
			this._gridContainer.removeEventListener("click", this.#eventHandlers.grid);
			debugUntrackListener(this._gridContainer, "click", this.#eventHandlers.grid);
			this.#eventHandlers.grid = null;
		}

		// Remove grid from DOM so it cannot be bypassed
		if (this._gridContainer?.parentNode) {
			this._gridContainer.parentNode.removeChild(this._gridContainer);
		}
		this._gridContainer = null;

		// Update WebSocket status icon to disconnected before tearing down (tab mode)
		if (this._serverComMgr && typeof this._serverComMgr.setWebSocketDisconnected === "function") {
			this._serverComMgr.setWebSocketDisconnected("External changes detected.");
		}

		// Tab mode: close WebSocket and prevent reconnect
		if (this._ws && typeof this._ws.destroyInstance === "function") {
			this._ws.destroyInstance();
			this._ws = null;
		}

		// Stop ServerCom and AutoLoad so no more items are fetched or processed
		if (this._serverComMgr && typeof this._serverComMgr.destroy === "function") {
			this._serverComMgr.destroy();
			this._serverComMgr = null;
		}
		if (this._autoLoad && typeof this._autoLoad.destroy === "function") {
			this._autoLoad.destroy();
			this._autoLoad = null;
		}
		if (this._autoLoadRFY && typeof this._autoLoadRFY.destroy === "function") {
			this._autoLoadRFY.destroy();
			this._autoLoadRFY = null;
		}
	}

	/**
	 * Build schema from template then start observing the grid; lock if tiles no longer match template.
	 * Mutation callback is debounced (rAF) to avoid main-thread/GPU thrashing in WebKit (e.g. Orion).
	 * @private
	 */
	async #startTileIntegrityObserver() {
		if (!this._gridContainer || this.#tileIntegrityObserver || this.#tileIntegrityLocked) return;
		// Per-tile snapshots only; no template load. Tiles are assumed valid when locked.
		this.#tileIntegrityObserver = new MutationObserver((mutations) => {
			if (this.#tileIntegrityLocked) return;
			if (this.#bulkOperationInProgress) return;
			// Batch mutations: append and schedule at most one check per frame to avoid GPU/main-thread saturation
			if (!this.#tileIntegrityPendingMutations) this.#tileIntegrityPendingMutations = [];
			this.#tileIntegrityPendingMutations.push(...mutations);
			if (this.#tileIntegrityRafId != null) return;
			this.#tileIntegrityRafId = requestAnimationFrame(() => {
				this.#tileIntegrityRafId = null;
				const pending = this.#tileIntegrityPendingMutations;
				this.#tileIntegrityPendingMutations = null;
				if (!pending?.length || this.#tileIntegrityLocked || this.#bulkOperationInProgress) return;
				const affectedTiles = this.#getAffectedTilesFromMutations(pending);
				if (affectedTiles.size === 0) return;
				const check = this.#checkAffectedTilesIntegrity(affectedTiles);
				if (!check.ok) this.#handleIntegrityFailure(check);
			});
		});
		this.#tileIntegrityObserver.observe(this._gridContainer, {
			childList: true,
			subtree: true,
			attributes: true,
			attributeFilter: ["action", "href", "onclick", "onmouseenter", "onmouseleave", "onmouseover", "type"],
		});
		const initialCheck = this.#checkTileIntegrity();
		if (!initialCheck.ok) this.#handleIntegrityFailure(initialCheck);
	}

	//#######################################################
	// Event listeners and click handlers for static elements
	//#######################################################

	/**
	 * Create listeners for the grid container
	 * @param {boolean} reattachGridContainerOnly - If true, only the grid container will be reattached
	 */
	_createListeners(reattachGridContainerOnly = false) {
		// Remove old grid handler if exists (important for bulk operations)
		if (this.#eventHandlers.grid && this._gridContainer) {
			// Try to remove the old listener if the container still exists
			try {
				this._gridContainer.removeEventListener("click", this.#eventHandlers.grid);

				// Track removal for memory debugging
				debugUntrackListener(this._gridContainer, "click", this.#eventHandlers.grid);
			} catch (e) {
				// Container might be gone, just clear the reference
			}
			this.#eventHandlers.grid = null;
		}

		// Bind the click handler to the instance and then add as event listener
		this.#eventHandlers.grid = (e) => this.#clickHandler(e);
		this._gridContainer.addEventListener("click", this.#eventHandlers.grid);

		// Track event listener for memory debugging
		debugTrackListener(this._gridContainer, "click", this.#eventHandlers.grid);

		// Ensure tile DOM matches template; lock and show error if external changes detected
		this.#startTileIntegrityObserver();

		if (this._settings.get("notification.monitor.mouseoverPause")) {
			// Only add if not already added
			if (!this.#eventHandlers.document) {
				this.#eventHandlers.document = (e) => this.#mouseoverHandler(e);
				document.addEventListener("mouseover", this.#eventHandlers.document);

				// Track event listener for memory debugging
				debugTrackListener(document, "mouseover", this.#eventHandlers.document);
			}
		}

		//If we are only reattaching the grid container, we don't need to create the listeners for the header/page elements.
		if (reattachGridContainerOnly) {
			return;
		}

		this._sessionFetchLimitOverride = null;
		this._lastFetchWasLongPress = false;

		const api = this._buildUIApi();
		attachUIHandlers(api, this.#eventHandlers, debugTrackListener, debugUntrackListener);
		this.#attachMonitorToolbarKeybindings();
	}

	/**
	 * Build the UI handler API object used by both the legacy `attachUIHandlers`
	 * path and the React-based Monitor V4 (which wires React components directly
	 * to this api rather than via DOM listeners).
	 * @returns {object}
	 */
	_buildUIApi() {
		return {
			handlePauseClick: () => uiHandlePauseClick(this),
			handleConnectionDetailsClick: (e) => uiHandleConnectionDetailsClick(this, e),
			clearSearchDebounceTimer: () => {
				if (this._searchDebounceTimer) clearTimeout(this._searchDebounceTimer);
				this._searchDebounceTimer = null;
			},
			setSearchDebounceTimer: (id) => {
				this._searchDebounceTimer = id;
			},
			onSearchInput: (value) => {
				this._searchText = value;
				this.#applyFilteringToAllItems();
				this.#updateFilterCount();
			},
			updateFilterCount: () => this.#updateFilterCount(),
			getPassiveClears: () => this._settings.get("notification.monitor.passiveClears", true),
			handleClearMonitorPassive: (btn) => uiHandleClearMonitorPassive(this, btn),
			handleClearMonitorDialog: () => uiHandleClearMonitorDialog(this),
			setClearMonitorButton: (btn) => {
				this.#clearMonitorButton = btn;
			},
			handleClearUnavailablePassive: (btn) => uiHandleClearUnavailablePassive(this, btn),
			handleClearUnavailableDialog: () => uiHandleClearUnavailableDialog(this),
			setClearUnavailableButton: (btn) => {
				this.#clearUnavailableButton = btn;
			},
			runFetchForLimit: (limit, btn) => this.#runFetchForLimit(limit, btn),
			runFetchLast12hrs: (btn) => this.#runFetchLast12hrs(btn),
			getSessionFetchLimitOverride: () => this._sessionFetchLimitOverride,
			getFetchLimit: () => this._fetchLimit,
			getLastFetchWasLongPress: () => this._lastFetchWasLongPress,
			setLastFetchWasLongPress: (v) => {
				this._lastFetchWasLongPress = v;
			},
			setSessionFetchLimitOverride: (v) => {
				this._sessionFetchLimitOverride = v;
			},
			getLongPressOptions: () => {
				const o = [];
				if (this._settings.isPremiumUser(1)) o.push(50, 100);
				if (this._settings.isPremiumUser(2)) o.push(150, 200);
				if (this._settings.isPremiumUser(3)) o.push(300);
				return o;
			},
			onSortChange: async (value) => {
				this._sortType = value;
				await this._settings.refresh();
				await this._settings.set("notification.monitor.sortType", this.#getCurrentSortType());
				this.#sortItems();
				if (this._noShiftGrid) {
					if (this.#getCurrentSortType() == TYPE_DATE_DESC) {
						this._noShiftGrid.resetEndPlaceholdersCount();
						this._noShiftGrid.insertPlaceholderTiles();
					} else {
						this._noShiftGrid.deletePlaceholderTiles();
					}
				}
			},
			onFilterTypeChange: async (value) => {
				this._filterType = value;
				await this._settings.refresh();
				await this._settings.set("notification.monitor.filterType", this.#getCurrentFilterType());
				this.#applyFilteringToAllItems();
			},
			onFilterQueueChange: async (value) => {
				this._filterQueue = value;
				await this._settings.refresh();
				await this._settings.set("notification.monitor.filterQueue", this.#getCurrentFilterQueue());
				this.#applyFilteringToAllItems();
			},
			onNotificationActiveChange: async (isEnabled) => {
				await this._settings.refresh();
				await this._settings.set("notification.active", isEnabled);
				if (!isEnabled) {
					this._autoLoadScheduler?.cancelAll?.();
					if (this._autoLoad && typeof this._autoLoad.resetReloadTimer === "function") {
						this._autoLoad.resetReloadTimer(1000 * 60 * 60 * 24);
					}
					const nextLoadElement = document.getElementById("date_next_assisted_load");
					if (nextLoadElement) nextLoadElement.innerText = "(tba)";
					if (this._channel && this._cryptoKeys) {
						this._channel.postMessage(
							await this._cryptoKeys.encryptJSON({
								type: "updateAssistedLoadDates",
								nextLoadText: "(tba)",
							})
						);
					}
				} else if (isEnabled && this._autoLoad) {
					if (typeof this._autoLoad.restartTimer === "function") this._autoLoad.restartTimer();
				}
			},
			onAutoTruncateChange: async (checked) => {
				this._autoTruncateEnabled = checked;
				await this._settings.refresh();
				await this._settings.set("notification.monitor.autoTruncate", this._autoTruncateEnabled);
				if (this._autoTruncateEnabled) this.#autoTruncate(true);
			},
			onAutoTruncateLimitChange: async (value) => {
				await this._settings.refresh();
				await this._settings.set("notification.monitor.autoTruncateLimit", parseInt(value, 10));
				this.#autoTruncate(true);
			},
			setAutoTruncateCheckbox: (el) => {
				if (el) el.checked = this._autoTruncateEnabled;
			},
			onFocusModeChange: async (checked) => {
				await this._settings.refresh();
				await this._settings.set("notification.monitor.focusMode", checked);
			},
			initFilterSection: (section, wrapper, pinIcon) => this._initFilterSection(section, wrapper, pinIcon),
			onFilterPinClick: (section, wrapper, pinIcon) => this._onFilterPinClick(section, wrapper, pinIcon),
			onFiltersToggle: (section, wrapper, pinIcon) => this._onFiltersToggle(section, wrapper, pinIcon),
			getSettings: () => this._settings,
		};
	}

	/**
	 * Attach keyup listener for monitor toolbar keybindings (Pause, Clear Unavailable, Clear All).
	 * Works in both MonitorV3 (Vine page) and MonitorV3Lite (standalone) so these 3 keys work without the bootloader.
	 */
	#attachMonitorToolbarKeybindings() {
		const actions = getMonitorToolbarKeybindingActions((key) => this._settings.get(key));
		if (Object.keys(actions).length === 0) return;
		const handler = (e) => {
			if (!this._settings.get("keyBindings.active") || e.ctrlKey || e.shiftKey || e.altKey || e.metaKey) return;
			const nodeName = document.activeElement?.nodeName;
			if (["INPUT", "TEXTAREA", "SELECT", "LI"].includes(nodeName)) return;
			const key = e.key?.toLowerCase();
			const action = actions[key];
			if (action) {
				action();
				e.preventDefault();
			}
		};
		window.addEventListener("keyup", handler, true);
		this.#eventHandlers.window.keyup = handler;
	}

	/**
	 * Initialize filter section DOM from settings (pinned/collapsed). Used by UI handlers.
	 * @param {HTMLElement} filtersSection
	 * @param {HTMLElement|null} filtersWrapper
	 * @param {HTMLElement|null} filterPinIcon
	 */
	_initFilterSection(filtersSection, filtersWrapper, filterPinIcon) {
		const isPinned = this._settings.get("notification.monitor.filtersPinned", false);
		if (isPinned) {
			filtersSection.classList.add("pinned");
			filtersSection.classList.remove("collapsed");
			if (filtersWrapper) filtersWrapper.classList.add("has-pinned-filter");
			if (filterPinIcon) {
				filterPinIcon.classList.remove("vh-icon-pin");
				filterPinIcon.classList.add("vh-icon-unpin");
				filterPinIcon.title = "Unpin filter panel";
			}
		} else {
			filtersSection.classList.add("collapsed");
		}
	}

	/**
	 * Toggle filter panel pin. Used by UI handlers.
	 */
	async _onFilterPinClick(filtersSection, filtersWrapper, filterPinIcon) {
		await this._settings.refresh();
		const isPinned = filtersSection.classList.contains("pinned");
		if (isPinned) {
			filtersSection.classList.remove("pinned");
			if (filtersWrapper) filtersWrapper.classList.remove("has-pinned-filter");
			filterPinIcon?.classList.remove("vh-icon-unpin");
			filterPinIcon?.classList.add("vh-icon-pin");
			filterPinIcon && (filterPinIcon.title = "Pin filter panel open");
			await this._settings.set("notification.monitor.filtersPinned", false);
		} else {
			filtersSection.classList.add("pinned");
			filtersSection.classList.remove("collapsed");
			if (filtersWrapper) filtersWrapper.classList.add("has-pinned-filter");
			filterPinIcon?.classList.remove("vh-icon-pin");
			filterPinIcon?.classList.add("vh-icon-unpin");
			filterPinIcon && (filterPinIcon.title = "Unpin filter panel");
			await this._settings.set("notification.monitor.filtersPinned", true);
		}
	}

	/**
	 * Toggle filter panel collapse / unpin. Used by UI handlers.
	 */
	async _onFiltersToggle(filtersSection, filtersWrapper, filterPinIcon) {
		if (filtersSection.classList.contains("pinned")) {
			await this._settings.refresh();
			filtersSection.classList.remove("pinned");
			filtersSection.classList.add("collapsed");
			if (filtersWrapper) filtersWrapper.classList.remove("has-pinned-filter");
			if (filterPinIcon) {
				filterPinIcon.classList.remove("vh-icon-unpin");
				filterPinIcon.classList.add("vh-icon-pin");
				filterPinIcon.title = "Pin filter panel open";
			}
			await this._settings.set("notification.monitor.filtersPinned", false);
		} else {
			filtersSection.classList.toggle("collapsed");
		}
	}

	/**
	 * Process buffered tiles and play sounds on feed unpause. Called from UI handler handlePauseClick.
	 * @param {boolean} isHoverPause - Whether this unpause was triggered by hover end
	 * @param {boolean} skipPlaceholderTiles - Whether to skip inserting placeholder tiles
	 */
	_unpauseFeed(isHoverPause = false, skipPlaceholderTiles = false) {
		const tiles = this._gridLayout.getTilesForUnpause();
		let visible = false;
		let highestPriorityItem = -1;

		const considerTileForSound = (node) => {
			if (highestPriorityItem < TYPE_HIGHLIGHT && node.dataset.typeHighlight == "1") {
				highestPriorityItem = TYPE_HIGHLIGHT;
			} else if (
				highestPriorityItem < TYPE_ZEROETV &&
				node.dataset.typeZeroETV == "1" &&
				this._settings.get("notification.monitor.zeroETV.sound") != "0"
			) {
				highestPriorityItem = TYPE_ZEROETV;
			} else if (
				highestPriorityItem < TYPE_RFY &&
				node.dataset.queue == "potluck" &&
				this._settings.get("notification.monitor.rfy.sound") != "0"
			) {
				highestPriorityItem = TYPE_RFY;
			} else if (
				highestPriorityItem < TYPE_REGULAR &&
				node.dataset.typeHighlight != "1" &&
				node.dataset.typeZeroETV != "1"
			) {
				highestPriorityItem = TYPE_REGULAR;
			}
		};

		for (const node of tiles) {
			if (node.dataset.feedPaused == "true") {
				node.dataset.feedPaused = "false";
				visible = this.#processNotificationFiltering(node, true);
				const displayValue = visible ? "flex" : "none";
				this.#setTileDisplay(node, displayValue);
				considerTileForSound(node);
			}
		}

		if (highestPriorityItem !== -1) {
			if (highestPriorityItem === TYPE_HIGHLIGHT) {
				(async () => {
					try {
						const { getGroups } = await import("/scripts/core/utils/KeywordGroupsManager.js");
						const { getFirstHighlightSoundFromTiles } = await import(
							"/scripts/notifications-monitor/services/HighlightSoundResolver.js"
						);
						const groups = await getGroups(this._settings);
						const groupMap = new Map(groups.map((g) => [g.id, g]));
						const { sound, volume } = getFirstHighlightSoundFromTiles(tiles, groupMap);
						this._soundPlayerMgr.play(TYPE_HIGHLIGHT, sound, volume);
					} catch (err) {
						console.warn("[NotificationMonitor] Error loading group sound on unpause:", err);
						this._soundPlayerMgr.play(TYPE_HIGHLIGHT);
					}
				})();
			} else {
				this._soundPlayerMgr.play(highestPriorityItem);
			}
		}

		this._tileCounter.recountVisibleTiles(0, true, { isBulkOperation: true, source: "feed-unpause" });

		if (!isHoverPause && this._noShiftGrid && !skipPlaceholderTiles) {
			if (this.#getCurrentSortType() == TYPE_DATE_DESC) {
				this._noShiftGrid.resetEndPlaceholdersCount();
				this._noShiftGrid.insertPlaceholderTiles();
			}
		}
	}

	#setTileDisplay(tile, value) {
		tile.dataset.display = value;
		tile.style.display = value;
	}

	/**
	 * Convert queue name to abbreviation
	 * @param {string} queue - The queue name
	 * @returns {string} The queue abbreviation
	 */
	#queueToAbbr(queue) {
		const arr = {
			potluck: "RFY",
			encore: "AI",
			last_chance: "AFA",
			all_items: "ALL",
		};
		return arr[queue];
	}

	/**
	 * Clean up all event listeners and references
	 * This method should be called when the monitor is being destroyed
	 * to prevent memory leaks
	 */
	destroy() {
		// Only log cleanup messages if debugMemory is enabled
		if (this._settings.get("general.debugMemory")) {
			console.log("🧹 Destroying NotificationMonitor and cleaning up event listeners..."); // eslint-disable-line no-console
		}

		// Remove grid container listener
		if (this.#eventHandlers.grid && this._gridContainer) {
			this._gridContainer.removeEventListener("click", this.#eventHandlers.grid);

			// Track removal for memory debugging
			debugUntrackListener(this._gridContainer, "click", this.#eventHandlers.grid);

			this.#eventHandlers.grid = null;
		}

		// Remove document listeners
		if (this.#eventHandlers.document) {
			document.removeEventListener("mouseover", this.#eventHandlers.document);
			this.#eventHandlers.document = null;
		}
		if (this.#eventHandlers.documentClick) {
			document.removeEventListener("click", this.#eventHandlers.documentClick);
			debugUntrackListener(document, "click", this.#eventHandlers.documentClick);
			this.#eventHandlers.documentClick = null;
		}

		// Remove window listeners
		if (this.#eventHandlers.window.keydown) {
			window.removeEventListener("keydown", this.#eventHandlers.window.keydown, true);
			this.#eventHandlers.window.keydown = null;
		}
		if (this.#eventHandlers.window.keyup) {
			window.removeEventListener("keyup", this.#eventHandlers.window.keyup, true);
			this.#eventHandlers.window.keyup = null;
		}
		if (this.#eventHandlers.window.scroll) {
			window.removeEventListener("scroll", this.#eventHandlers.window.scroll);
			this.#eventHandlers.window.scroll = null;
		}

		// Remove all button/element listeners
		for (const [element, { event, handler }] of this.#eventHandlers.buttons) {
			if (element && handler) {
				element.removeEventListener(event, handler);
			}
		}
		this.#eventHandlers.buttons.clear();

		// Clear any timers
		if (this._searchDebounceTimer) {
			clearTimeout(this._searchDebounceTimer);
			this._searchDebounceTimer = null;
		}
		if (this._autoTruncateDebounceTimer) {
			clearTimeout(this._autoTruncateDebounceTimer);
			this._autoTruncateDebounceTimer = null;
		}
		if (this.#pinDebounceTimer) {
			clearTimeout(this.#pinDebounceTimer);
			this.#pinDebounceTimer = null;
		}

		// Clear processing map to prevent memory leaks
		if (this.#processingASINs) {
			this.#processingASINs.clear();
		}

		// Destroy NoShiftGrid if it exists
		if (this._noShiftGrid && typeof this._noShiftGrid.destroy === "function") {
			this._noShiftGrid.destroy();
			this._noShiftGrid = null;
		}

		if (this._gridLayout && typeof this._gridLayout.destroy === "function") {
			this._gridLayout.destroy();
		}
		this._gridLayout = null;

		// Destroy MasterSlave to clear interval
		if (this._masterSlave && typeof this._masterSlave.destroy === "function") {
			this._masterSlave.destroy();
			this._masterSlave = null;
		}

		// Destroy ServerCom to clear intervals
		if (this._serverComMgr && typeof this._serverComMgr.destroy === "function") {
			this._serverComMgr.destroy();
			this._serverComMgr = null;
		}

		// Destroy AutoLoad to clear timers and event listeners
		if (this._autoLoad && typeof this._autoLoad.destroy === "function") {
			this._autoLoad.destroy();
			this._autoLoad = null;
		}

		// Destroy Websocket to clear timers and connections
		if (this._ws && typeof this._ws.destroyInstance === "function") {
			this._ws.destroyInstance();
			this._ws = null;
		}

		// Clear count verification interval
		if (this._countVerificationInterval) {
			clearInterval(this._countVerificationInterval);
			this._countVerificationInterval = null;
			console.log("🧹 Cleared count verification interval"); // eslint-disable-line no-console
		}

		// Clear references
		this._gridContainer = null;

		if (this._settings.get("general.debugMemory")) {
			console.log("✅ NotificationMonitor cleanup complete"); // eslint-disable-line no-console
		}
	}
}

export { NotificationMonitor };
