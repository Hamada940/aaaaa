import { escapeHTML } from "/scripts/core/utils/StringHelper.js";
import { UnavailableAsinReporter } from "/scripts/core/services/UnavailableAsinReporter.js";
import { RequestCache } from "/scripts/core/services/RequestCache.js";
import { Template } from "/scripts/core/utils/Template.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";
import { refreshCsrfTokenFromVinePage } from "/scripts/core/services/CsrfTokenRefresh.js";
import { Item, WITH_VARIANT } from "/scripts/core/models/Item.js";
import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
import { isOrionBrowser, isSafari, isWebKitNonChromium } from "/scripts/core/utils/BrowserDetection.js";

const QUEUE_TO_RECOMMENDATION_TYPE = Object.freeze({
	potluck: "VENDOR_TARGETED",
	last_chance: "VENDOR_VINE_FOR_ALL",
	encore: "VINE_FOR_ALL",
	all_items: "ALL_ITEMS",
});

class NotificationLiteDetailsModal {
	#settings = null;
	#env = null;
	#i18n = null;
	#dialogMgr = null;
	#showToaster = null;
	#stateByModalId = new Map();
	#unavailableReporter = null;
	#tpl = null;
	#apiRequestCache = null;
	#cryptoKeys = null;
	/** ASINs already reported this session (dedupe variant switches / retries). */
	#reportedUnavailableAsins = new Set();

	static #TPL = Object.freeze({
		shell: "scripts/ui/templates/notification_monitor/nm_lite_details_modal_shell.html",
		preview: "scripts/ui/templates/notification_monitor/nm_lite_details_preview.html",
		error: "scripts/ui/templates/notification_monitor/nm_lite_details_error.html",
		thumbImage: "scripts/ui/templates/notification_monitor/nm_lite_details_thumb_img.html",
		thumbEmpty: "scripts/ui/templates/notification_monitor/nm_lite_details_thumb_empty.html",
		variantsHeader: "scripts/ui/templates/notification_monitor/nm_lite_details_variants_header.html",
		variantsHeaderCell: "scripts/ui/templates/notification_monitor/nm_lite_details_variants_header_cell.html",
		variantsRow: "scripts/ui/templates/notification_monitor/nm_lite_details_variants_row.html",
		variantsCell: "scripts/ui/templates/notification_monitor/nm_lite_details_variants_cell.html",
	});

	constructor({ settings, env, i18n, dialogMgr, showToaster, unavailableReporter = null }) {
		this.#settings = settings;
		this.#env = env;
		this.#i18n = i18n;
		this.#dialogMgr = dialogMgr;
		this.#showToaster = showToaster;
		this.#unavailableReporter = unavailableReporter || new UnavailableAsinReporter({ env, i18n, settings });
		this.#tpl = new Template();
		this.#apiRequestCache = new RequestCache();
		this.#cryptoKeys = new CryptoKeys();
	}

	async openFromButtonData(data) {
		const asin = data?.asin;
		const recommendationId = data?.recommendationId;
		if (!asin || !recommendationId) {
			this.#notifyError("Unable to open details", "Missing ASIN or recommendation ID.");
			return;
		}

		const queue = data?.queue || "encore";
		const isParentAsin = String(data?.isParentAsin).toLowerCase() === "true";
		const isPreRelease = String(data?.isPreRelease).toLowerCase() === "true";
		const modalId = `nm-lite-details-${asin}`;
		this.#closeIfOpen(modalId);

		const state = {
			modalId,
			parentAsin: asin,
			queue,
			recommendationId,
			isParentAsin,
			isPreRelease,
			selectedAsin: asin,
			selectedRecommendationId: recommendationId,
			selectedIndex: 0,
			variants: [],
			unavailableAsins: new Set(),
			columns: [],
			selectedDetails: null,
			requestBlocked: false,
			requestErrorMessage: "",
			requestErrorDetails: "",
			limitedQuantity: false,
		};
		this.#stateByModalId.set(modalId, state);

		const modal = this.#dialogMgr.newModal(modalId);
		modal.title = `Item ${asin}`;
		modal.content = await this.#renderSkeleton();
		modal.style =
			"width: min(1000px, 92vw); max-width: 1000px; max-height: min(720px, calc(100vh - 20px)); max-height: min(720px, calc(100dvh - 20px));";
		await modal.show();
		const modalRoot = this.#getModalRoot(modalId);
		modalRoot?.classList?.add("vh-nm-lite-details-modal");
		this.#mountRequestButtonInFooter(state);
		this.#bindModalEvents(state);

		try {
			await this.#loadInitialData(state, isParentAsin);
		} catch (error) {
			this.#notifyItemNotInEnrollmentIfNeeded(asin, error);
			await this.#renderModalError(
				state,
				error?.message || this.#msg("nmLiteDetailsUnableToLoadProduct", "Unable to load this product."),
				error
			);
			this.#handleError(error, "Unable to load item details", {
				asin,
				queue,
				recommendationId,
				isParentAsin,
			});
		}
	}

	async #loadInitialData(state, isParentAsin) {
		this.#setVariantsVisibility(state, false);

		if (isParentAsin) {
			const childrenData = await this.#fetchChildrenData(state.recommendationId, state.queue, state.parentAsin);
			state.selectedRecommendationId = childrenData.recommendationId || state.recommendationId;
			state.variants = childrenData.variants;
			await this.#hydrateUnavailableVariants(state);
			state.columns = this.#buildColumns(state.variants);
			await this.#renderVariantsTable(state);
			if (state.variants.length > 0) {
				await this.#selectVariant(state, 0);
				return;
			}
		}

		const details = await this.#fetchItemDetails(state.parentAsin, state.selectedRecommendationId, state.queue);
		state.selectedAsin = state.parentAsin;
		state.selectedDetails = details;
		await this.#renderPreview(state, details);
		await this.#sendSelectedEtv(state);
	}

	#closeIfOpen(modalId) {
		const modalEl = document.getElementById(`modal-${modalId}`);
		if (modalEl) {
			this.#dialogMgr.closeModal(modalId);
			this.#stateByModalId.delete(modalId);
		}
	}

	#getBaseUrl() {
		return `https://www.amazon.${this.#i18n.getDomainTLD()}`;
	}

	#isIOSMode() {
		return isWebKitNonChromium() || isOrionBrowser() || isSafari();
	}

	#openUrlInNewTab(url) {
		if (!url) return;
		const isWebKitBrowser = this.#isIOSMode();
		if (!isWebKitBrowser) {
			// Chromium / Firefox: direct user-gesture open is most reliable.
			const openedWindow = window.open(url, "_blank", "noopener,noreferrer");
			if (openedWindow) {
				try {
					openedWindow.opener = null;
				} catch {
					/* noop */
				}
				return;
			}
		}
		try {
			if (chrome?.tabs?.create) {
				chrome.tabs.create({ url });
				return;
			}
			if (chrome?.runtime?.sendMessage) {
				chrome.runtime.sendMessage({ type: "openUrlInNewTab", url });
				return;
			}
		} catch (error) {
			console.warn(
				"[NotificationLiteDetailsModal] Failed to open tab via extension API, falling back to window.open",
				error
			);
		}
		if (isWebKitBrowser) {
			// WebKit fallback if extension API is unavailable or errors.
			window.open(url, "_blank", "noopener,noreferrer");
		}
	}

	#openPostInNewTab(actionUrl, fields) {
		if (!actionUrl) return;
		const formFields = Array.isArray(fields) ? fields : [];
		const redirectUrl = `${this.#getBaseUrl()}/vine/vh-monitor/checkout-redirect/`;
		const params = new URLSearchParams();
		params.set("action", String(actionUrl));
		params.set("fields", JSON.stringify(formFields));
		this.#openUrlInNewTab(`${redirectUrl}?${params.toString()}`);
	}

	#getReferrer(queue) {
		return `${this.#getBaseUrl()}/vine/vine-items${queue ? `?queue=${queue}` : ""}`;
	}

	#getFetchOptions(referrer) {
		return {
			method: "GET",
			mode: "cors",
			credentials: "include",
			headers: {
				accept: "*/*",
				"accept-language": navigator.language || "en-US",
				"sec-fetch-dest": "empty",
				"sec-fetch-mode": "cors",
				"sec-fetch-site": "same-origin",
			},
			referrer,
		};
	}

	async #fetchChildrenData(recommendationId, queue, parentAsin) {
		const cacheKey = `children|${recommendationId}|${queue}|${parentAsin || ""}`;
		return await this.#apiRequestCache.getOrSet(cacheKey, async () => {
			const encoded = encodeURIComponent(recommendationId);
			const referrer = this.#getReferrer(queue);
			const url = `${this.#getBaseUrl()}/vine/api/recommendations/${encoded}`;
			const res = await fetch(url, this.#getFetchOptions(referrer));
			this.#throwIfHttp302(res);
			const data = await this.#readJsonResponse(res, "recommendations");
			const asinFromRecId = recommendationId.split("#")[1] || parentAsin;
			this.#throwIfVineEnrollmentError(data, asinFromRecId);
			if (!res.ok) {
				throw new Error(`Failed to load variants (${res.status} ${res.statusText})`);
			}
			const rawVariants = data?.result?.variations ?? data?.recommendation?.children ?? data?.children ?? [];
			const recommendationIdFromResponse = data?.result?.recommendationId ?? recommendationId;

			const variants = Array.isArray(rawVariants)
				? rawVariants
						.map((variant) => {
							const asin = variant?.asin;
							if (!asin) return null;
							return {
								asin,
								dimensionEntries: this.#toDimensionEntries(variant?.dimensions),
							};
						})
						.filter(Boolean)
				: [];

			if (variants.length === 0 && parentAsin) {
				return {
					recommendationId: recommendationIdFromResponse,
					variants: [],
				};
			}

			return {
				recommendationId: recommendationIdFromResponse,
				variants: this.#sortVariants(variants),
			};
		});
	}

	#toDimensionEntries(dimensions) {
		if (Array.isArray(dimensions)) {
			return dimensions
				.map((entry) => {
					if (entry == null) return null;
					if (typeof entry === "string") {
						return { name: entry, value: entry };
					}
					const name = entry?.name ?? entry?.key ?? entry?.dimensionName ?? "";
					const value = entry?.value ?? entry?.dimensionValue ?? "";
					if (!name) return null;
					return { name: String(name), value: String(value ?? "") };
				})
				.filter(Boolean);
		}

		if (dimensions && typeof dimensions === "object") {
			return Object.entries(dimensions).map(([name, value]) => ({
				name: String(name),
				value: String(value ?? ""),
			}));
		}

		return [];
	}

	#buildColumns(variants) {
		const maxOccurrences = new Map();
		const order = [];

		for (const variant of variants) {
			const counts = new Map();
			for (const entry of variant.dimensionEntries) {
				const name = entry.name || "Dimension";
				if (!order.includes(name)) order.push(name);
				counts.set(name, (counts.get(name) || 0) + 1);
				const currentMax = maxOccurrences.get(name) || 0;
				if (counts.get(name) > currentMax) {
					maxOccurrences.set(name, counts.get(name));
				}
			}
		}

		const columns = [];
		for (const name of order) {
			const maxForName = maxOccurrences.get(name) || 1;
			for (let i = 0; i < maxForName; i++) {
				columns.push({
					id: `${name}__${i}`,
					name,
					occurrenceIndex: i,
				});
			}
		}

		// Fallback: when variants have no dimensions, show ASIN as the variant discriminator.
		if (columns.length === 0) {
			return [
				{
					id: "asin__0",
					name: "ASIN #",
					occurrenceIndex: 0,
					isAsinFallback: true,
				},
			];
		}
		return columns;
	}

	#extractColumnValue(variant, column) {
		if (column?.isAsinFallback) {
			return variant?.asin || "";
		}
		let count = -1;
		for (const entry of variant.dimensionEntries) {
			if (entry.name !== column.name) continue;
			count++;
			if (count === column.occurrenceIndex) {
				return entry.value || "";
			}
		}
		return "";
	}

	#sortVariants(variants) {
		const columns = this.#buildColumns(variants);
		return [...variants].sort((a, b) => {
			for (const column of columns) {
				const av = this.#extractColumnValue(a, column).toLowerCase();
				const bv = this.#extractColumnValue(b, column).toLowerCase();
				const cmp = av.localeCompare(bv, undefined, { numeric: true, sensitivity: "base" });
				if (cmp !== 0) return cmp;
			}
			return a.asin.localeCompare(b.asin);
		});
	}

	async #fetchItemDetails(asin, recommendationId, queue) {
		const cacheKey = `item|${asin}|${recommendationId}|${queue}`;
		return await this.#apiRequestCache.getOrSet(cacheKey, async () => {
			const encoded = encodeURIComponent(recommendationId);
			const referrer = this.#getReferrer(queue);
			const url = `${this.#getBaseUrl()}/vine/api/recommendations/${encoded}/item/${asin}?imageSize=180`;
			const res = await fetch(url, this.#getFetchOptions(referrer));
			this.#throwIfHttp302(res);
			const data = await this.#readJsonResponse(res, "item details");
			this.#throwIfVineEnrollmentError(data, asin);
			if (!res.ok) {
				throw new Error(`Failed to load item details (${res.status} ${res.statusText})`);
			}
			const result = data?.result;
			if (!result) {
				throw new Error("Item details response did not include result.");
			}
			const featureBullets = Array.isArray(result.featureBullets) ? result.featureBullets : [];
			const description = featureBullets
				.map((bullet) => {
					if (typeof bullet === "string") return bullet;
					if (bullet == null) return "";
					return String(bullet?.text ?? bullet?.value ?? bullet?.feature ?? "");
				})
				.filter((bullet) => bullet.trim().length > 0)
				.join("\n");

			const byLineContributors = Array.isArray(result.byLineContributors) ? result.byLineContributors : [];
			const sellerName = byLineContributors
				.map((entry) => {
					if (typeof entry === "string") return entry;
					if (entry == null) return "";
					return String(entry?.name ?? entry?.displayName ?? entry?.title ?? "");
				})
				.filter((name) => name.trim().length > 0)
				.join(", ");

			return {
				asin,
				title: result.productTitle || result.title || asin,
				description: description || this.#msg("nmLiteDetailsNoDescription", "No description available."),
				thumbnail: result.imageUrl || "",
				etvValue: result.taxValue ?? "",
				etvCurrency: result.taxCurrency ?? "",
				productSiteLaunchDate: result.productSiteLaunchDate,
				sellerName,
				promotionId: result.promotionId || "",
				purchasePolicyCode: result.purchasePolicyCode || "",
				limitedQuantity: result.limitedQuantity === true,
			};
		});
	}

	async #fetchVoiceOrder(asin, recommendationId, queue, csrfRetried = false) {
		const csrf = this.#env?.getCsrfToken?.();
		if (!csrf) {
			throw new Error("Missing CSRF token. Reload a Vine page and try again.");
		}

		const url = `${this.#getBaseUrl()}/vine/api/voiceOrders`;
		const recommendationType = QUEUE_TO_RECOMMENDATION_TYPE[queue] || "VINE_FOR_ALL";
		const body = JSON.stringify({
			recommendationId,
			recommendationType,
			itemAsin: asin,
		});

		const res = await fetch(url, {
			method: "POST",
			mode: "cors",
			credentials: "include",
			headers: {
				accept: "*/*",
				"accept-language": navigator.language || "en-US",
				"cache-control": "max-age=0",
				"content-type": "application/json",
				"sec-fetch-dest": "empty",
				"sec-fetch-mode": "cors",
				"sec-fetch-site": "same-origin",
				"anti-csrftoken-a2z": csrf,
			},
			body,
			referrer: `${this.#getBaseUrl()}/vine/no-referrer`,
		});
		this.#throwIfHttp302(res);

		const payloadText = await res.text();
		if (res.status === 403) {
			if (!csrfRetried) {
				await refreshCsrfTokenFromVinePage(this.#env, this.#i18n.getDomainTLD(), queue);
				return this.#fetchVoiceOrder(asin, recommendationId, queue, true);
			}
			throw new Error("voiceOrders returned 403. CSRF token may be stale.");
		}
		let payload = null;
		try {
			payload = JSON.parse(payloadText);
		} catch {
			throw new Error("voiceOrders did not return valid JSON.");
		}

		if (payload?.error) {
			throw new Error(String(payload.error));
		}
		if (!payload?.result?.offerListingId) {
			throw new Error("voiceOrders response missing offerListingId.");
		}
		return payload.result;
	}

	#getVineOpenModalUrlFromState(state) {
		const enrollmentGuid = Item.getEnrollmentGuidFromRecommendationId(state.selectedRecommendationId);
		if (!enrollmentGuid) {
			throw new Error(
				this.#msg(
					"nmLiteDetailsMissingEnrollment",
					"Could not read enrollment information for this item. Open See Details from a normal Vine listing page."
				)
			);
		}
		const hasVariants = Array.isArray(state.variants) && state.variants.length > 0;
		const isParentForModal = hasVariants ? false : !!state.isParentAsin;
		const selectedAsin = state.selectedAsin || state.parentAsin;
		const parentAsin = state.parentAsin || selectedAsin;
		const shouldEncodeVariant = Boolean(hasVariants && selectedAsin && parentAsin && selectedAsin !== parentAsin);
		const item = new Item({
			asin: shouldEncodeVariant ? parentAsin : selectedAsin,
			queue: state.queue || "encore",
			is_parent_asin: isParentForModal,
			is_pre_release: true,
			enrollment_guid: enrollmentGuid,
			variant_asin: shouldEncodeVariant ? selectedAsin : undefined,
		});
		if (typeof this.#i18n.getCountryCode === "function" && item.i18nMgr?.setCountryCode) {
			item.i18nMgr.setCountryCode(this.#i18n.getCountryCode());
		}
		return item.getVHOpenModalURL(shouldEncodeVariant ? WITH_VARIANT : false);
	}

	async #handleRequestProduct(state) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		if (state.requestBlocked) return;
		this.#setRequestError(state, "", "");
		this.#syncRequestButton(state, true);

		if (state.isPreRelease) {
			try {
				const url = this.#getVineOpenModalUrlFromState(state);
				this.#openUrlInNewTab(url);
			} catch (error) {
				this.#handleError(error, "Unable to open Vine", {
					selectedAsin: state.selectedAsin,
					recommendationId: state.selectedRecommendationId,
					queue: state.queue,
				});
			} finally {
				this.#syncRequestButton(state, false);
			}
			return;
		}

		try {
			const details = state.selectedDetails;
			if (!details) {
				throw new Error("No selected item details available.");
			}
			const voiceResult = await this.#fetchVoiceOrder(
				state.selectedAsin,
				state.selectedRecommendationId,
				state.queue
			);
			await this.#settings.set("checkout.currentASIN", state.selectedAsin);
			await this.#settings.set("checkout.currentParentASIN", state.parentAsin);
			//await this.#settings.set("checkout.currentBuyNowASIN", state.selectedAsin);

			this.#submitCheckoutForm(
				state.selectedAsin,
				voiceResult.offerListingId,
				details.promotionId,
				details.purchasePolicyCode
			);
		} catch (error) {
			const errorMessage = String(error?.message || "");
			if (errorMessage.toUpperCase().includes("ITEM_NOT_IN_ENROLLMENT")) {
				await this.#markVariantUnavailable(state, state.selectedAsin, "ITEM_NOT_IN_ENROLLMENT");
			}
			await this.#unavailableReporter.reportOrderFailure(
				state.selectedAsin,
				state.parentAsin,
				"failed",
				errorMessage || "UNKNOWN_ERROR"
			);
			const requestError = this.#getRequestProductError(error);
			state.requestBlocked = true;
			state.requestErrorMessage = requestError.message;
			state.requestErrorDetails = requestError.details;
			this.#setRequestError(state, requestError.message, requestError.details);
			this.#notifyError(this.#msg("nmLiteDetailsRequestFailedTitle", "Request failed"), requestError.message);
		} finally {
			this.#syncRequestButton(state, false);
		}
	}

	#submitCheckoutForm(asin, offerListingId, promotionId, purchasePolicyCode) {
		const checkoutUrl = `${this.#getBaseUrl()}/checkout/entry/buynow?pipelineType=Chewbacca`;
		const fields = [
			["skipCart", "1"],
			["quantity", "1"],
			["asin", String(asin || "")],
			["offerListingID", String(offerListingId || "")],
			["vinePromotionId", String(promotionId || "")],
			["vinePurchasePolicyCode", String(purchasePolicyCode || "")],
		];
		if (this.#isIOSMode()) {
			this.#openPostInNewTab(checkoutUrl, fields);
			return;
		}

		const form = document.createElement("form");
		form.method = "post";
		form.target = "_blank";
		form.action = checkoutUrl;
		for (const [name, value] of fields) {
			const input = document.createElement("input");
			input.type = "hidden";
			input.name = name;
			input.value = value;
			form.appendChild(input);
		}

		document.body.appendChild(form);
		form.submit();
		form.remove();
	}

	async #renderSkeleton() {
		return await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.shell, {});
	}

	async #renderPreview(state, details) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		const preview = root.querySelector(".vh-nm-lite-details-preview");
		if (!preview) return;

		const rawAsin = details.asin || "";
		const title = escapeHTML(details.title || rawAsin || "");
		const description = escapeHTML(details.description || "No description available.");
		const asin = escapeHTML(rawAsin);
		const titleHref = rawAsin ? `${this.#getBaseUrl()}/dp/${encodeURIComponent(rawAsin)}` : "";
		const titleContent = titleHref
			? `<a class="vh-nm-lite-details-title-link" href="${escapeHTML(titleHref)}" target="_blank" rel="noopener noreferrer">${title}</a>`
			: title;
		const sellerName = escapeHTML(details.sellerName || this.#msg("nmLiteDetailsUnknownSeller", "Unknown seller"));
		const etvValue = this.#formatEtv(details.etvValue, details.etvCurrency);
		const thumbnail = details.thumbnail
			? await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.thumbImage, {
					src: escapeHTML(details.thumbnail),
					alt: title,
				})
			: await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.thumbEmpty, {});

		const preReleaseBanner = state.isPreRelease
			? (() => {
					const preReleaseText = escapeHTML(
						this.#msg("tileTitlePreRelease", "This item is a pre-release product.")
					);
					const launchDateText = this.#formatSiteLaunchDate(details.productSiteLaunchDate);
					if (!launchDateText) {
						return `<div class="vh-nm-lite-details-pre-release-notice" role="status">${preReleaseText}</div>`;
					}
					const launchDateLabel = escapeHTML(
						this.#msg("nmLiteDetailsSiteLaunchDateLabel", "Site launch date:")
					);
					return `<div class="vh-nm-lite-details-pre-release-notice" role="status">${preReleaseText}<br>${launchDateLabel} ${escapeHTML(launchDateText)}</div>`;
				})()
			: "";

		preview.innerHTML = await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.preview, {
			preReleaseBanner,
			thumbnail,
			asin,
			etv: escapeHTML(etvValue),
			seller: sellerName,
			titleContent,
			description,
		});
		state.limitedQuantity = details?.limitedQuantity === true;
		this.#syncLimitedQuantityNotice(state);
		this.#setRequestError(state, state.requestErrorMessage || "", state.requestErrorDetails || "");
	}

	async #renderVariantsTable(state) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		const variantsSection = root.querySelector(".vh-nm-lite-details-variants");
		const thead = root.querySelector(".vh-nm-lite-details-table thead");
		const tbody = root.querySelector(".vh-nm-lite-details-table tbody");
		if (!variantsSection || !thead || !tbody) return;

		if (!Array.isArray(state.variants) || state.variants.length === 0) {
			this.#setVariantsVisibility(state, false);
			return;
		}

		this.#setVariantsVisibility(state, true);

		const headerCells = [];
		for (const column of state.columns) {
			headerCells.push(
				await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.variantsHeaderCell, {
					value: escapeHTML(column.name),
				})
			);
		}
		thead.innerHTML = await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.variantsHeader, {
			cells: headerCells.join(""),
		});

		const rows = [];
		for (let index = 0; index < state.variants.length; index++) {
			const variant = state.variants[index];
			const cells = [];
			for (const column of state.columns) {
				cells.push(
					await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.variantsCell, {
						value: escapeHTML(this.#extractColumnValue(variant, column)),
					})
				);
			}
			rows.push(
				await this.#renderTemplate(NotificationLiteDetailsModal.#TPL.variantsRow, {
					rowClass: this.#getVariantRowClass(state, variant, index),
					index: String(index),
					cells: cells.join(""),
				})
			);
		}
		tbody.innerHTML = rows.join("");
	}

	#getVariantRowClass(state, variant, index) {
		const classes = ["vh-nm-lite-details-row"];
		if (index === state.selectedIndex) {
			classes.push("vh-nm-lite-details-row-selected");
		}
		if (state.unavailableAsins instanceof Set && state.unavailableAsins.has(variant?.asin)) {
			classes.push("vh-nm-lite-details-row-unavailable");
		}
		return classes.join(" ");
	}

	#setVariantsVisibility(state, hasVariants) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		const shell = root.querySelector(".vh-nm-lite-details-shell");
		const variantsSection = root.querySelector(".vh-nm-lite-details-variants");
		if (variantsSection) {
			variantsSection.style.display = hasVariants ? "" : "none";
		}
		if (shell) {
			shell.classList.toggle("vh-nm-lite-details-no-variants", !hasVariants);
		}
	}

	async #selectVariant(state, index) {
		if (!Array.isArray(state.variants) || !state.variants[index]) return;
		const didSwitchVariant = state.selectedIndex !== index;
		if (didSwitchVariant) {
			this.#resetRequestState(state);
		}
		state.selectedIndex = index;
		const variant = state.variants[index];
		state.selectedAsin = variant.asin;
		await this.#renderVariantsTable(state);
		const details = await this.#fetchItemDetails(state.selectedAsin, state.selectedRecommendationId, state.queue);
		state.selectedDetails = details;
		await this.#renderPreview(state, details);
		await this.#sendSelectedEtv(state);
	}

	#bindModalEvents(state) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;

		root.addEventListener("click", (event) => {
			const row = event.target.closest(".vh-nm-lite-details-row");
			if (row) {
				event.preventDefault();
				const index = Number(row.dataset.index);
				if (!Number.isNaN(index)) {
					this.#selectVariant(state, index).catch((error) => {
						const variantAsin = state.variants?.[index]?.asin;
						this.#notifyItemNotInEnrollmentIfNeeded(variantAsin, error);
						this.#handleError(error, "Unable to load variant", {
							selectedIndex: index,
							parentAsin: state.parentAsin,
						});
					});
				}
				return;
			}

			const requestBtn = event.target.closest(".vh-nm-lite-details-request-btn");
			if (requestBtn) {
				event.preventDefault();
				this.#handleRequestProduct(state);
			}
		});
	}

	#mountRequestButtonInFooter(state) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		const footer = root.querySelector(".footer");
		if (!footer) return;
		footer.style.display = "grid";
		footer.style.gridTemplateColumns = "auto 1fr auto";
		footer.style.alignItems = "center";
		footer.style.gap = "8px";
		const closeBtn = footer.querySelector(".modal-ok");
		if (closeBtn instanceof HTMLButtonElement) {
			closeBtn.style.gridColumn = "1";
			closeBtn.style.gridRow = "1";
			closeBtn.style.justifySelf = "start";
			closeBtn.textContent = this.#msg("nmLiteDetailsClose", "Close");
		}

		const existing = footer.querySelector(".vh-nm-lite-details-request-btn");
		if (existing) {
			this.#syncRequestButton(state, false);
			return;
		}

		let preReleaseNote = footer.querySelector(".vh-nm-lite-details-request-note");
		if (!(preReleaseNote instanceof HTMLElement)) {
			preReleaseNote = document.createElement("small");
			preReleaseNote.className = "vh-nm-lite-details-request-note";
			preReleaseNote.style.gridColumn = "2";
			preReleaseNote.style.gridRow = "1";
			preReleaseNote.style.justifySelf = "end";
			preReleaseNote.style.textAlign = "right";
			preReleaseNote.style.display = state.isPreRelease ? "block" : "none";
			preReleaseNote.textContent = this.#msg(
				"nmLiteDetailsPreReleaseOrderingNote",
				"Pre-release items will open a new tab and use Vine's ordering process"
			);
			footer.appendChild(preReleaseNote);
		} else {
			preReleaseNote.style.display = state.isPreRelease ? "block" : "none";
		}

		const requestArea = document.createElement("div");
		requestArea.className = "vh-nm-lite-details-request-area";
		requestArea.style.gridColumn = "3";
		requestArea.style.gridRow = "1";
		requestArea.style.justifySelf = "end";
		requestArea.style.display = "inline-flex";
		requestArea.style.alignItems = "center";
		requestArea.style.gap = "8px";

		const limitedQtyNotice = document.createElement("small");
		limitedQtyNotice.className = "vh-nm-lite-details-limited-qty";
		limitedQtyNotice.style.display = "none";
		limitedQtyNotice.style.color = "var(--vh-error-color, #b91c1c)";
		limitedQtyNotice.style.fontWeight = "700";
		limitedQtyNotice.textContent = this.#msg("nmLiteDetailsLimitedQuantityNotice", "Limited Quantity.");

		const requestBtn = document.createElement("button");
		requestBtn.type = "button";
		requestBtn.className = "vh-nm-lite-details-request-btn";
		requestBtn.textContent = this.#msg("nmLiteDetailsRequestProduct", "Request Product");
		requestArea.appendChild(limitedQtyNotice);
		requestArea.appendChild(requestBtn);
		footer.insertBefore(requestArea, footer.firstChild);
		this.#syncRequestButton(state, false);
		this.#syncLimitedQuantityNotice(state);
	}

	#syncRequestButton(state, isLoading) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		const requestBtn = root.querySelector(".vh-nm-lite-details-request-btn");
		if (!(requestBtn instanceof HTMLButtonElement)) return;
		requestBtn.disabled = isLoading || state.requestBlocked;
		if (isLoading) {
			requestBtn.textContent = this.#msg("nmLiteDetailsRequesting", "Requesting...");
			return;
		}
		requestBtn.textContent = state.requestBlocked
			? this.#msg("nmLiteDetailsRequestUnavailable", "Request Unavailable")
			: this.#msg("nmLiteDetailsRequestProduct", "Request Product");
	}

	#syncLimitedQuantityNotice(state) {
		const root = this.#getModalRoot(state.modalId);
		if (!root) return;
		const notice = root.querySelector(".vh-nm-lite-details-limited-qty");
		if (!(notice instanceof HTMLElement)) return;
		notice.style.display = state.limitedQuantity ? "inline" : "none";
	}

	#resetRequestState(state) {
		state.requestBlocked = false;
		state.requestErrorMessage = "";
		state.requestErrorDetails = "";
		this.#setRequestError(state, "", "");
		this.#syncRequestButton(state, false);
	}

	#setRequestError(state, message, details) {
		const root = this.#getModalRoot(state.modalId);
		const preview = root?.querySelector?.(".vh-nm-lite-details-preview");
		if (!preview) return;

		let container = preview.querySelector(".vh-nm-lite-details-action-error");
		if (!container) {
			container = document.createElement("div");
			container.className = "vh-nm-lite-details-action-error";
			container.setAttribute("role", "alert");
			container.style.display = "none";
			preview.insertBefore(container, preview.firstChild);
		}

		if (!message) {
			container.innerHTML = "";
			container.style.display = "none";
			return;
		}

		container.style.display = "";
		container.innerHTML = `<div class="vh-nm-lite-details-action-error-title">${escapeHTML(
			this.#msg("nmLiteDetailsRequestFailedTitle", "Request failed")
		)}</div><div class="vh-nm-lite-details-action-error-message">${escapeHTML(
			message
		)}</div><div class="vh-nm-lite-details-action-error-details"><span class="vh-nm-lite-details-action-error-details-label">${escapeHTML(
			this.#msg("nmLiteDetailsErrorDetailsLabel", "Details:")
		)}</span> <code>${escapeHTML(String(details || "UNKNOWN_ERROR"))}</code></div>`;
	}

	#getRequestProductError(error) {
		const raw = String(error?.message || "UNKNOWN_ERROR").trim();
		const upper = raw.toUpperCase();
		if (upper.includes("ITEM_NOT_IN_ENROLLMENT")) {
			return {
				message: this.#msg(
					"nmLiteDetailsRequestErrorItemNotInEnrollment",
					"This item is no longer available in your Vine enrollment."
				),
				details: raw,
			};
		}
		if (upper.includes("403")) {
			return {
				message: this.#msg(
					"nmLiteDetailsRequestErrorForbidden",
					"Request blocked by Amazon (403). Refresh a normal Vine page and try again later."
				),
				details: raw,
			};
		}
		return {
			message: this.#msg(
				"nmLiteDetailsRequestErrorGeneric",
				"We could not complete your request right now. Please try again from the Vine page."
			),
			details: raw,
		};
	}

	#getModalRoot(modalId) {
		return document.querySelector(`#modal-${modalId}`);
	}

	#throwIfVineEnrollmentError(data, asin) {
		if (!UnavailableAsinReporter.isItemNotInEnrollmentResponse(data)) {
			if (data?.result == null && data?.error?.exceptionType) {
				throw new Error(String(data.error.exceptionType));
			}
			return;
		}
		this.#notifyItemNotInEnrollment(asin);
		throw new Error("ITEM_NOT_IN_ENROLLMENT");
	}

	#notifyItemNotInEnrollmentIfNeeded(asin, error) {
		if (!this.#isItemNotInEnrollmentError(error)) return;
		this.#notifyItemNotInEnrollment(asin);
	}

	#isItemNotInEnrollmentError(error) {
		return String(error?.message || "")
			.toUpperCase()
			.includes("ITEM_NOT_IN_ENROLLMENT");
	}

	/**
	 * POST `record_unavailable` to VH as soon as Vine reports ITEM_NOT_IN_ENROLLMENT.
	 * Fire-and-forget so the modal can show the error without waiting on the API.
	 * @param {string} asin
	 */
	#notifyItemNotInEnrollment(asin) {
		const normalized = String(asin || "").trim();
		if (!normalized || this.#reportedUnavailableAsins.has(normalized)) return;
		this.#reportedUnavailableAsins.add(normalized);
		void this.#unavailableReporter.report(normalized, "ITEM_NOT_IN_ENROLLMENT");
	}

	async #readJsonResponse(res, contextLabel) {
		const contentType = (res.headers.get("content-type") || "").toLowerCase();
		if (this.#isRedirectedHtmlResponse(res, contentType)) {
			throw this.#http302ModalError(false);
		}

		const text = await res.text();
		try {
			return JSON.parse(text);
		} catch {
			const looksLikeHtml = /^\s*</.test(text) || text.toLowerCase().includes("<!doctype html");
			if (looksLikeHtml && (res.redirected || contentType.includes("text/html"))) {
				throw this.#http302ModalError(false);
			}
			const snippet = text.slice(0, 160).replace(/\s+/g, " ").trim();
			throw new Error(
				`${contextLabel} endpoint returned non-JSON content (${res.status} ${res.statusText}). Snippet: ${snippet}`
			);
		}
	}

	async #renderModalError(state, message, error = null) {
		const root = this.#getModalRoot(state.modalId);
		const preview = root?.querySelector?.(".vh-nm-lite-details-preview");
		if (!preview) return;
		this.#setVariantsVisibility(state, false);
		const showRefreshHint = error?.isHttp302 === true;
		preview.innerHTML = await this.#renderTemplate(
			NotificationLiteDetailsModal.#TPL.error,
			{
				errorTitle: this.#msg("nmLiteDetailsErrorTitle", "Unable to load product details"),
				errorMessage: escapeHTML(message),
				errorHint: this.#msg(
					"nmLiteDetailsErrorHint",
					"Try refreshing a normal Vine page, then open See Details again."
				),
			},
			{ showErrorHint: showRefreshHint }
		);
	}

	/** @param {boolean} includeRefreshHint - if true, modal shows nmLiteDetailsErrorHint (literal HTTP 302 only). */
	#http302ModalError(includeRefreshHint) {
		const err = new Error(this.#msg("nmLiteDetailsHttp302Error", this.#http302FallbackMessage()));
		if (includeRefreshHint) err.isHttp302 = true;
		return err;
	}

	#throwIfHttp302(res) {
		if (res?.status === 302) {
			throw this.#http302ModalError(true);
		}
	}

	#isRedirectedHtmlResponse(res, contentType = "") {
		if (!res) return false;
		const redirected = res.redirected === true;
		const isHtml = contentType.includes("text/html");
		const url = String(res.url || "").toLowerCase();
		const looksLikeNonApiTarget =
			url.includes("/ap/signin") || url.includes("/errors/validatecaptcha") || url.includes("/vine/vine-items");
		return redirected && (isHtml || looksLikeNonApiTarget);
	}

	#http302FallbackMessage() {
		return "Unable to load this product, received a product not found error (HTTP 302). Try refreshing a normal Vine page and try again.";
	}

	#msg(key, fallback, placeholders = null) {
		return getMessage(key, fallback, placeholders);
	}

	async #renderTemplate(path, vars = {}, ifs = {}) {
		const html = await this.#tpl.loadFile(path);
		this.#tpl.clearVariables();
		for (const [name, value] of Object.entries(ifs)) {
			this.#tpl.setIf(name, value);
		}
		const mergedVars = {
			labelLoading: this.#msg("nmLiteDetailsLoading", "Loading item details..."),
			labelVariants: this.#msg("nmLiteDetailsVariants", "Variants"),
			labelAsin: this.#msg("nmLiteDetailsAsinLabel", "ASIN:"),
			labelSeller: this.#msg("nmLiteDetailsSellerLabel", "Seller:"),
			noImageText: this.#msg("nmLiteDetailsNoImage", "No image available."),
			preReleaseBanner: "",
			...vars,
		};
		for (const [name, value] of Object.entries(mergedVars)) {
			this.#tpl.setVar(name, value);
		}
		return this.#tpl.render(html, false);
	}

	#formatEtv(rawValue, currency) {
		const valueAsString = String(rawValue ?? "").trim();
		const currencyCode = String(currency ?? "")
			.trim()
			.toUpperCase();
		if (!valueAsString) return this.#msg("nmLiteDetailsEtvNA", "ETV: N/A");
		const normalized = valueAsString.replace(/[^0-9,.-]/g, "").replace(/,/g, "");
		const numeric = Number.parseFloat(normalized);
		if (!Number.isNaN(numeric) && currencyCode) {
			try {
				const formatted = new Intl.NumberFormat(this.#i18n.getLocale(), {
					style: "currency",
					currency: currencyCode,
				}).format(numeric);
				return `ETV: ${formatted}`;
			} catch {
				// Fallback to raw text below.
			}
		}
		return `ETV: ${currencyCode ? `${currencyCode} ` : ""}${valueAsString}`;
	}

	#formatSiteLaunchDate(rawValue) {
		if (rawValue === null || rawValue === undefined || rawValue === "") return "";
		const timestamp = Number(rawValue);
		if (!Number.isFinite(timestamp)) return "";
		const date = new Date(timestamp);
		if (Number.isNaN(date.getTime())) return "";
		try {
			return new Intl.DateTimeFormat(this.#i18n.getLocale(), {
				dateStyle: "medium",
				timeStyle: "short",
			}).format(date);
		} catch {
			return date.toLocaleString();
		}
	}

	#notifyError(title, content) {
		if (typeof this.#showToaster === "function") {
			this.#showToaster({
				title,
				content,
				lifespan: 8,
				type: "error",
			});
		}
	}

	async #hydrateUnavailableVariants(state) {
		if (!state?.parentAsin) return;
		try {
			const response = await this.#fetchVariantsInfo(state.parentAsin);
			const unavailableAsins = Array.isArray(response?.items)
				? response.items.filter((item) => item?.unavailable).map((item) => String(item.asin))
				: [];
			state.unavailableAsins = new Set(unavailableAsins);
		} catch (error) {
			console.debug("[NotificationLiteDetailsModal] Failed to hydrate unavailable variants", error);
		}
	}

	async #markVariantUnavailable(state, asin, reason = "ITEM_NOT_IN_ENROLLMENT") {
		if (!state || !asin) return;
		if (!(state.unavailableAsins instanceof Set)) {
			state.unavailableAsins = new Set();
		}
		state.unavailableAsins.add(String(asin));
		await this.#renderVariantsTable(state);
		this.#notifyItemNotInEnrollment(asin);
	}

	async #fetchVariantsInfo(parentAsin) {
		const cacheKey = `variants-info|${parentAsin}`;
		return await this.#apiRequestCache.getOrSet(cacheKey, async () => {
			const content = {
				api_version: 5,
				app_version: this.#env?.data?.appVersion ?? "",
				action: "get_variants_info",
				country: this.#i18n.getCountryCode(),
				uuid: await this.#settings.get("general.uuid", false),
				fid: await this.#settings.get("general.fingerprint.id", false),
				cid: await this.#env.getCID(),
				parent_asin: parentAsin,
			};
			content.s = await this.#cryptoKeys.signData(content);
			content.pk = await this.#cryptoKeys.getExportedPublicKey();

			const response = await fetch(this.#env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
			if (!response.ok) {
				throw new Error(`Failed to load variant availability (${response.status} ${response.statusText})`);
			}
			return await response.json();
		});
	}

	#handleError(error, title, context = {}) {
		console.error("[NotificationLiteDetailsModal]", title, error, context);
		this.#notifyError(title, error?.message || "Unexpected error.");
	}

	async #sendSelectedEtv(state) {
		try {
			const details = state?.selectedDetails;
			if (!details || !state?.selectedAsin) return;
			const enrollmentGuid = Item.getEnrollmentGuidFromRecommendationId(state.selectedRecommendationId) || "";
			const selectedAsin = String(state.selectedAsin);
			const parentAsin = String(state.parentAsin || "");
			const parentForPayload = selectedAsin !== parentAsin && parentAsin ? parentAsin : null;
			const variants = Array.isArray(state.variants)
				? state.variants.map((variant) => ({
						asin: variant?.asin || "",
						dimensions: encodeURIComponent(JSON.stringify(variant?.dimensionEntries || [])),
					}))
				: null;
			const appVersion = this.#env?.data?.appVersion || chrome.runtime.getManifest().version;

			const content = {
				api_version: 5,
				app_version: appVersion,
				action: "record_etv",
				country: this.#i18n.getCountryCode(),
				uuid: this.#settings.get("general.uuid", false),
				fid: this.#settings.get("general.fingerprint.id", false),
				cid: await this.#env.getCID(),
				asin: selectedAsin,
				parent_asin: parentForPayload,
				queue: state.queue || this.#env?.data?.vineQueue || null,
				title: details.title || "",
				thumbnail: details.thumbnail || "",
				enrollment_guid: enrollmentGuid,
				etv: details.etvValue ?? "",
				variations: variants,
			};
			content.s = await this.#cryptoKeys.signData(content);
			content.pk = await this.#cryptoKeys.getExportedPublicKey();

			await fetch(this.#env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
		} catch (error) {
			console.debug("[NotificationLiteDetailsModal] Failed to send ETV record", error);
		}
	}
}

export { NotificationLiteDetailsModal };
