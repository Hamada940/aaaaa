import { NotificationMonitor } from "/scripts/notifications-monitor/core/NotificationMonitor.js";
import { VINE_GRID } from "/scripts/core/amazon/selectors.js";
import { TileSizer } from "/scripts/ui/controllers/TileSizer.js";
import { TierMgr } from "/scripts/notifications-monitor/services/TierMgr.js";
import { renderMonitorHeader } from "../ui/headerComposer.js";
import { ensureNotInVineJail } from "/scripts/core/services/VineJailCheck.js";
class NotificationMonitorV3Lite extends NotificationMonitor {
	constructor() {
		super();
		this._monitorV3Lite = true;

		// Existing services still use direct instantiation (for now)
		this._tileSizer = new TileSizer("notification.monitor.tileSize");
		this._tierMgr = new TierMgr(this._env);
	}

	async initialize() {
		if (this._settings.get("notification.monitor.listView")) {
			this._itemTemplateFile = "tile_listview.html";
		} else {
			this._itemTemplateFile = "tile_gridview.html";
		}

		// Wait for settings to load before proceeding
		await this._settings.waitForLoad();
		this.syncVirtualGridFromSettings();

		this._i18nMgr.setCountryCode(this._settings.get("general.country"));
		if (!(await ensureNotInVineJail(this._i18nMgr.getDomainTLD(), this._settings))) {
			return false;
		}

		// Insert the header (composed from component templates).
		// Do not call readTierInfo() or _updateUserTierInfo() — monitor lite does not run on a Vine page,
		// so tier/limit cannot be read from the DOM (#vvp-vine-participation-content etc.).
		const parentContainer = document.querySelector("body");
		const header = await renderMonitorHeader(this._tpl, {
			MONITOR_TYPE: "V3 Lite (Memory optimized)",
			fetchLimit: this._fetchLimit,
			isTier3: this._settings.isPremiumUser(3),
			tld: this._i18nMgr.getDomainTLD(),
		});
		parentContainer.insertBefore(header, parentContainer.firstChild);

		this._gridContainer = document.querySelector(VINE_GRID.ITEMS);
		//this._gridContainerWidth = this._gridContainer.offsetWidth;

		//Display tile size widget if the list view is not active and the tile size is active
		if (this._settings.get("general.tileSize.active") && !this._settings.get("notification.monitor.listView")) {
			this.#initTileSizeWidget();
		}

		document.getElementById("date_loaded").innerText = this._formatDate();
		this._mostRecentItemDateDOM = document.getElementById("date_most_recent_item");

		if (this._settings.get("notification.monitor.listView")) {
			this._gridContainer.classList.add("vh-listview");
		}

		//Set the grid items size
		if (this._settings.get("general.tileSize.enabled")) {
			const width = this._settings.get("notification.monitor.tileSize.width");
			const grid = document.querySelector(VINE_GRID.ITEMS);
			grid.classList.add("vh-notification-monitor");
			grid.style.gridTemplateColumns = `repeat(auto-fill,minmax(${width}px,auto))`;
		}

		// Initialize event-driven tab title updates
		this._initializeTabTitleListener();

		// Update UI filters after header is inserted
		this._loadUIUserSettings();

		//Create the event listeners
		this._createListeners();

		//Change the tab's favicon
		this._updateTabFavicon();

		//Initial check of the status of services (master monitor and WebSocket)
		this._serverComMgr.updateWebsocketStatus();
	}

	async #initTileSizeWidget() {
		if (this._settings.get("notification.monitor.listView")) {
			return;
		}
		const container = document.querySelector("#vh-nm-tile-size-container");
		if (container) {
			if (this._settings.get("general.tileSize.enabled")) {
				//Inject the GUI for the tile sizer widget
				this._tileSizer.injectGUI(container);
			}
		}

		if (!this._settings.get("notification.monitor.listView")) {
			this._tileSizer.adjustAll();
		}
	}
}

export { NotificationMonitorV3Lite };
