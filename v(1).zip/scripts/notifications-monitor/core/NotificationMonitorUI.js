/**
 * View-only UI helpers for the notification monitor.
 * Pure DOM/visual updates; no business logic or state. Callers pass data and refs.
 */

import { getMessage } from "/scripts/core/services/Internationalization.js";

/**
 * Update the filter count display in the header.
 * @param {string} searchText - Current search text
 * @param {string|number} filterQueue - Current filter queue value
 * @param {string|number} filterType - Current filter type value
 */
export function updateFilterCount(searchText, filterQueue, filterType) {
	const filterHeaderText = document.querySelector(".vh-nm-filters-header-text");
	if (!filterHeaderText) return;

	let count = 0;
	if (searchText && searchText.trim()) count++;
	if (filterQueue !== "-1" && filterQueue !== -1) count++;
	if (filterType !== "-1" && filterType !== -1) count++;

	filterHeaderText.textContent = getMessage("nmFilterCountLabel", `Filter (${count}):`, [String(count)]);
}

/**
 * Set the browser tab title to the visible tile count.
 * @param {number} visibleTilesCount - Current visible tile count
 */
export function updateTabTitle(visibleTilesCount) {
	document.title = getMessage("nmTabTitleCount", "VHNM (" + visibleTilesCount + ")", [String(visibleTilesCount)]);
}

/**
 * Set the page favicon to VHelper's icon.
 */
export function updateTabFavicon() {
	const favicon = document.querySelector("link[rel~='icon']");
	if (favicon) {
		favicon.href = "https://v-helper.com/favicon.ico";
	} else {
		const link = document.createElement("link");
		link.rel = "icon";
		link.href = "https://v-helper.com/favicon.ico";
		document.head.appendChild(link);
	}
}

/**
 * Update the user tier info element (medal + tier + limit).
 * @param {{ isGold: () => boolean, getTier: () => string, getLimit: () => string }} tierMgr - Tier manager instance
 */
export function updateUserTierInfo(tierMgr) {
	const userTierInfo = document.getElementById("user-tier-info");
	if (!userTierInfo || !tierMgr) return;

	userTierInfo.replaceChildren();

	const tierLabel = getMessage("nmTier", "Tier");
	const limitLabel = getMessage("nmLimit", "Limit");
	const tierName = getMessage(tierMgr.isGold() ? "nmGold" : "nmSilver", tierMgr.getTier());

	userTierInfo.appendChild(document.createTextNode(`[${tierLabel}: `));

	const medalIcon = document.createElement("div");
	medalIcon.classList.add(tierMgr.isGold() ? "vh-icon-medal-gold" : "vh-icon-medal-silver");
	medalIcon.classList.add("vh-icon-16");
	medalIcon.style.display = "inline-block";
	userTierInfo.appendChild(medalIcon);

	userTierInfo.appendChild(document.createTextNode(` ${tierName}] [${limitLabel}: ${tierMgr.getLimit()}]`));
}

/**
 * Sync form controls and toggles from loaded settings state (no storage reads).
 * @param {object} state - { autoTruncateEnabled, filterQueue, filterType, sortType, autoTruncateLimit, notificationActive, focusMode }
 */
export function syncUIFromSettings(state) {
	const autoTruncateCheckbox = document.getElementById("auto-truncate");
	if (autoTruncateCheckbox) autoTruncateCheckbox.checked = state.autoTruncateEnabled;

	const autoTruncateLimit = document.getElementById("auto-truncate-limit");
	if (autoTruncateLimit) autoTruncateLimit.value = String(state.autoTruncateLimit ?? "");

	const filterQueueSelect = document.querySelector("select[name='filter-queue']");
	if (filterQueueSelect) filterQueueSelect.value = state.filterQueue;

	const filterTypeSelect = document.querySelector("select[name='filter-type']");
	if (filterTypeSelect) filterTypeSelect.value = state.filterType;

	const sortQueueSelect = document.querySelector("select[name='sort-queue']");
	if (sortQueueSelect) sortQueueSelect.value = state.sortType;

	const notificationActiveCheckbox = document.getElementById("notification.active");
	if (notificationActiveCheckbox) notificationActiveCheckbox.checked = state.notificationActive;

	const focusModeToggle = document.getElementById("vh-nm-focus-mode-toggle");
	if (focusModeToggle) focusModeToggle.checked = state.focusMode;
}

/**
 * Show the pause overlay (red tint). Call only when pauseOverlay setting is enabled.
 */
export function showPauseOverlay() {
	const overlay = document.createElement("div");
	overlay.id = "pauseFeedOverlay";
	overlay.style.position = "fixed";
	overlay.style.top = "0";
	overlay.style.left = "0";
	overlay.style.width = "100%";
	overlay.style.height = "100%";
	overlay.style.backgroundColor = "rgba(255, 0, 0, 0.10)";
	overlay.style.pointerEvents = "none";
	document.body.appendChild(overlay);
}

/**
 * Remove the pause overlay if present.
 */
export function hidePauseOverlay() {
	const el = document.getElementById("pauseFeedOverlay");
	if (el && el.parentNode) el.parentNode.removeChild(el);
}

/**
 * Update pause button label and fixed icon/title (paused vs resumed).
 * @param {boolean} paused - Whether feed is paused
 * @param {number} bufferedCount - Number of items buffered while paused (used when paused)
 */
export function updatePauseButtonUI(paused, bufferedCount = 0) {
	const mainBtn = document.getElementById("pauseFeed");
	const fixedIcon = document.getElementById("pauseFeed-fixed-icon");
	const fixedBtn = document.getElementById("pauseFeed-fixed");

	// Some call sites can pass null/""/NaN while paused; always render a numeric count.
	const normalizedBufferedCount = Number.isFinite(Number(bufferedCount)) ? Math.max(0, Number(bufferedCount)) : 0;
	const pauseLabel = getMessage("nmPauseAndBuffer", "Pause & Buffer");
	const resumeLabel = getMessage("nmResumeFeed", "Resume Feed ($1$)", [String(normalizedBufferedCount)]);
	if (paused) {
		if (mainBtn) mainBtn.value = resumeLabel;
		if (fixedIcon) fixedIcon.className = "vh-toolbar-icon vh-icon-play";
		if (fixedBtn) fixedBtn.title = resumeLabel;
	} else {
		if (mainBtn) mainBtn.value = pauseLabel;
		if (fixedIcon) fixedIcon.className = "vh-toolbar-icon vh-icon-pause";
		if (fixedBtn) fixedBtn.title = pauseLabel;
	}
}

/**
 * Disable or re-enable fetch buttons. When re-enabling, leaves a button disabled if it is in its own cooldown.
 * @param {boolean} disabled - Whether to disable the buttons
 * @param {{ fetchLastCooldownActive?: boolean, fetchLast12hrsCooldownActive?: boolean }} [cooldownState] - Required when disabled is false
 */
export function setFetchButtonsDisabled(disabled, cooldownState = {}) {
	const btnLast = document.getElementById("fetch-last");
	const btnLast12hrs = document.getElementById("fetch-last-12hrs");
	if (disabled) {
		if (btnLast) btnLast.disabled = true;
		if (btnLast12hrs) btnLast12hrs.disabled = true;
	} else {
		if (btnLast && !cooldownState.fetchLastCooldownActive) btnLast.disabled = false;
		if (btnLast12hrs && !cooldownState.fetchLast12hrsCooldownActive) btnLast12hrs.disabled = false;
	}
}

/**
 * Show undo banner: set button text to "Undo (remainingSeconds)" and add active class.
 * @param {HTMLInputElement} undoButton - The clear button element
 * @param {number} remainingSeconds - Seconds until auto-finalize
 */
export function showUndoBanner(undoButton, remainingSeconds) {
	if (!undoButton) return;
	const safe = Math.max(0, Math.ceil(remainingSeconds));
	undoButton.value = getMessage("nmUndoSeconds", `Undo (${safe})`, [String(safe)]);
	undoButton.classList.add("vh-nm-btn-undo-active");
}

/**
 * Update undo banner countdown text.
 * @param {HTMLInputElement} undoButton - The clear button element
 * @param {number} remainingSeconds - Seconds until auto-finalize
 */
export function updateUndoBanner(undoButton, remainingSeconds) {
	if (!undoButton) return;
	const safe = Math.max(0, Math.ceil(remainingSeconds));
	undoButton.value = getMessage("nmUndoSeconds", `Undo (${safe})`, [String(safe)]);
}

/**
 * Restore the clear button to its original label and remove active class.
 * @param {HTMLInputElement} undoButton - The clear button element
 * @param {string} originalText - Original button value (e.g. "All" or "Unavail.")
 */
export function hideUndoBanner(undoButton, originalText) {
	if (!undoButton) return;
	undoButton.value = originalText;
	undoButton.classList.remove("vh-nm-btn-undo-active");
}
