/**
 * Notification monitor host for the React-based Monitor V4 page.
 *
 * Extends the V3 Lite host (never modified) but swaps out every code path
 * that would imperatively create or mutate DOM tiles. Item state flows
 * through the Zustand store and React Virtuoso renders the visible
 * subset, so the feed behaves like a true virtualised list — only tiles
 * inside the viewport exist in the DOM.
 *
 * What is overridden:
 *  - `_itemsMgr` is replaced with a store-backed facade
 *    ({@link StoreItemsMgrV4}) so inherited code that reads through
 *    `items.has` / `items.get(asin).data.*` still works.
 *  - `addTileInGrid`, `setETVFromASIN`, `setPriceFromASIN`,
 *    `setTierFromASIN`, `setAdditionalImagesFromASIN`,
 *    `setOrderAttemptsFromASIN`, `markItemUnavailable`, `addVariants`,
 *    `fetchRecentItemsEnd` write through the store rather than the DOM.
 *  - `_removeTile`, `_clearAllVisibleItems`, `_clearUnavailableItems`,
 *    `_collectVisibleItemAsins`, `_collectUnavailableItemAsins` use the
 *    store snapshot and skip DOM queries.
 *  - NoShiftGrid, TileSizer, LazyImageLoader, TileIntegrityObserver and
 *    the delegated grid click listener are not initialised in V4 — the
 *    corresponding behaviour is either handled by React (tile clicks,
 *    sizing, lazy loading via `loading="lazy"`) or no longer needed
 *    (integrity observer).
 *
 * V3 and V3 Lite are untouched; their files continue to drive the
 * legacy `vvp-items-grid` DOM exactly as before.
 *
 * @see scripts/notifications-monitor/core/NotificationMonitorV3Lite.js
 * @see src/monitor-v4/host/StoreItemsMgrV4.ts
 * @see src/monitor-v4/main.tsx (V4 bootstrap)
 * @see src/monitor-v4/App.tsx (renders React tiles via Virtuoso)
 */
import { NotificationMonitorV3Lite } from "/scripts/notifications-monitor/core/NotificationMonitorV3Lite.js";
import { VINE_GRID } from "/scripts/core/amazon/selectors.js";
import { Item } from "/scripts/core/models/Item.js";
import { unescapeHTML } from "/scripts/core/utils/StringHelper.js";
import { YMDHiStoISODate } from "/scripts/core/utils/DateHelper.js";
import { KeywordMatcherService } from "/scripts/core/services/KeywordMatcherService.js";
import { importFromExtension } from "@v4/services/importRuntime";
import {
	createStoreItemsMgr,
	storeAddItem,
	storeUpdateETV,
	storeBumpItemRecency,
	storeSetPrice,
	storeSetTier,
	storeSetAdditionalImages,
	storeSetOrderAttempts,
	storeAddVariants,
	storeMarkUnavailable,
	storeRemove,
	storeRemoveMany,
	storeClearAll,
	storeComputeTruncationRemovals,
	storeCollectVisibleAsins,
	storeCollectUnavailableAsins,
	storeHas,
	storeGetData,
	storeSetPaused,
	storeSetPausedBufferCount,
	storeSetFetchingRecentItems,
	storeAddTruncateEndPlaceholders,
	storeResetTruncateEndPlaceholders,
} from "@v4/host/v4HostBindings";
import { updatePauseButtonUI, showPauseOverlay, hidePauseOverlay } from "@v4/ui/pauseUI";
import { useMonitorStore } from "@v4/state/monitorStore";
import { shouldBump0EtvPlacement } from "@v4/state/itemHelpers";

const TYPE_REGULAR = 0;
const TYPE_RFY = 1;
const TYPE_ZEROETV = 2;
const TYPE_HIGHLIGHT = 3;

function getStore() {
	return useMonitorStore;
}

export class NotificationMonitorV4React extends NotificationMonitorV3Lite {
	#pauseSyncTimer = null;
	#tabTitleUnsubscribe = null;
	#pendingUnavailableAsins = new Set();
	#bufferedSoundAsins = new Set();
	/** Live inserts queued while paused (no store row until resume). */
	#feedPausedBuffer = [];
	#keywordMatcher = null;
	#keywordMatcherInitPromise = null;

	constructor() {
		super();
		this._monitorV4React = true;

		// Replace the inherited ItemsMgr (which maintains a DOM-tile map) with
		// a store-backed facade so every legacy read path (`items.has`, etc.)
		// sees the Zustand items map.
		try {
			this._itemsMgr = createStoreItemsMgr(this._settings);
			// pinMgr was configured against the old ItemsMgr in the parent ctor;
			// rebind so it reads DOM elements from our facade (which returns null).
			if (this._pinMgr && typeof this._pinMgr.setGetItemDOMElementCallback === "function") {
				this._pinMgr.setGetItemDOMElementCallback(() => null);
			}
		} catch (err) {
			console.error("[V4React] Failed to install StoreItemsMgrV4:", err);
		}

		// `MonitorCore` may have instantiated a `NoShiftGrid` when the
		// `placeholders` + `tileSize.enabled` settings were on. In V4 that
		// service would prepend raw `<div class="vh-placeholder-tile">` nodes
		// directly into `#vvp-items-grid`, which Virtuoso owns. Worse: the
		// `NoShiftGrid.initialize()` call installs a `ResizeObserver` on the
		// grid container, so every time Virtuoso adjusts its layout (which
		// is constantly during scroll/viewport changes) the observer fires
		// and re-inserts placeholders — creating the ghost-placeholder rows
		// seen mid-viewport. Tear the service down completely (disconnects
		// the observer) and null the reference so every caller becomes a
		// safe no-op.
		if (this._noShiftGrid) {
			// Important: do NOT call `deletePlaceholderTiles()` here.
			// That legacy helper removes every `.vh-placeholder-tile`, and in V4
			// React also renders placeholders with the same class. If host
			// construction races after initial React paint, deleting those nodes
			// from underneath React causes `removeChild` / `insertBefore`
			// reconciliation exceptions.
			try {
				this._noShiftGrid.destroy?.();
			} catch {
				/* ignore */
			}
			this._noShiftGrid = null;
		}
		// Belt & braces: also remove any *legacy* placeholder DOM that made
		// it into the grid before we tore the service down (the resize
		// observer may have fired before this subclass ctor ran). Narrow
		// the selector to `[data-placeholder-label]` so we only touch nodes
		// `NoShiftGrid.insertPlaceholderTiles` created — the React
		// `<Placeholder>` component also carries the `.vh-placeholder-tile`
		// class, and removing those from underneath React raises
		// "The node to be removed is not a child of this node" on the next
		// reconciliation.
		try {
			const grid = this._gridContainer ?? document.querySelector(VINE_GRID.ITEMS);
			grid?.querySelectorAll?.(".vh-placeholder-tile[data-placeholder-label]").forEach((el) => el.remove());
		} catch {
			/* ignore */
		}
	}

	// ----------------------------------------------------------------------
	// Initialisation override — React already rendered the header, the grid
	// is populated by Virtuoso, and every DOM-tile-dependent service is a
	// no-op in V4.
	// ----------------------------------------------------------------------

	async initializeV4() {
		await this._settings.waitForLoad();

		// Keep an existing grid ref around so inherited code that defensively
		// checks `this._gridContainer` doesn't crash; Virtuoso renders into a
		// `<div id="vvp-items-grid">` so this lookup succeeds once React has
		// painted.
		const grid = await this.#waitForGrid();
		if (grid) {
			this._gridContainer = grid;
		}

		this._i18nMgr.setCountryCode(this._settings.get("general.country"));
		const dateLoaded = document.getElementById("date_loaded");
		if (dateLoaded) {
			dateLoaded.textContent = this._formatDate();
		}
		this._mostRecentItemDateDOM = document.getElementById("date_most_recent_item");

		// Tile size: CSS variable on the grid container (replaces the legacy
		// TileSizer which mutated inline styles on every rendered tile).
		if (this._settings.get("general.tileSize.enabled") && this._gridContainer) {
			const width = this._settings.get("notification.monitor.tileSize.width");
			this._gridContainer.classList.add("vh-notification-monitor");
			this._gridContainer.classList.add("tab-grid");
			this._gridContainer.style.setProperty("--vh-tile-width", `${width}px`);
			this._gridContainer.style.gridTemplateColumns = `repeat(auto-fill,minmax(${width}px,auto))`;
		}

		this._loadUIUserSettings();
		this.#initTabTitleSync();

		// Build the _uiApi surface the React header/toolbar consume.
		this._sessionFetchLimitOverride = null;
		this._lastFetchWasLongPress = false;
		this._uiApi = this._buildUIApi();

		this.#mirrorPausedToStore();

		this._updateTabFavicon();
		this._serverComMgr.updateWebsocketStatus();
	}

	// ----------------------------------------------------------------------
	// Stream mutation overrides — every entry point ServerCom calls routes
	// through the store instead of creating/mutating DOM tiles.
	// ----------------------------------------------------------------------

	#feedPausedBufferHasImageUrl(imgUrl) {
		if (!imgUrl) return false;
		for (const e of this.#feedPausedBuffer) {
			if (e.data.img_url === imgUrl) return true;
		}
		return false;
	}

	#bufferIncomingTileWhilePaused(data, reason) {
		const asin = data.asin;
		const idx = this.#feedPausedBuffer.findIndex((e) => e.data.asin === asin);
		if (idx >= 0) {
			this.#feedPausedBuffer[idx] = { data, reason };
			if (this.#pendingUnavailableAsins.has(asin)) {
				const merged = { ...this.#feedPausedBuffer[idx].data, unavailable: 1 };
				this.#feedPausedBuffer[idx].data = merged;
				this.#pendingUnavailableAsins.delete(asin);
			}
			return true;
		}

		this.#feedPausedBuffer.push({ data, reason });
		this.#bufferedSoundAsins.add(asin);
		this._feedPausedAmountStored++;
		storeSetPausedBufferCount(this._feedPausedAmountStored);
		updatePauseButtonUI(true, this._feedPausedAmountStored);

		if (this.#pendingUnavailableAsins.has(asin)) {
			const last = this.#feedPausedBuffer[this.#feedPausedBuffer.length - 1];
			last.data = { ...last.data, unavailable: 1 };
			this.#pendingUnavailableAsins.delete(asin);
		}
		return true;
	}

	async #flushFeedPausedBuffer() {
		if (this.#feedPausedBuffer.length === 0) return;
		const entries = this.#feedPausedBuffer;
		this.#feedPausedBuffer = [];
		for (const { data, reason } of entries) {
			const hideDupe = this._settings.get("notification.monitor.hideDuplicateThumbnail");
			const img = data.img_url;
			if (hideDupe && img) {
				if (this._itemsMgr.imageUrls.has(img)) {
					continue;
				}
				this._itemsMgr.imageUrls.add(img);
			}
			storeAddItem(data, reason || "stream");
			this.#updateMostRecentItemDate(data);
			const asin = data.asin;
			if (this.#pendingUnavailableAsins.has(asin)) {
				storeMarkUnavailable(asin);
				this.#pendingUnavailableAsins.delete(asin);
			}
			try {
				const toRemove = storeComputeTruncationRemovals();
				if (toRemove.length > 0) {
					storeRemoveMany(toRemove);
					if (
						this._fetchingRecentItems ||
						this._settings.get("notification.monitor.sortType") !== "date_desc"
					) {
						storeResetTruncateEndPlaceholders();
					} else {
						storeAddTruncateEndPlaceholders(toRemove.length);
					}
				}
			} catch (err) {
				console.error("[V4React] truncation failed", err);
			}
		}
	}

	/**
	 * Accept a newly-streamed item. Deduplicates by ASIN (and, when the
	 * relevant setting is on, by image URL) then pushes into the store so
	 * React re-renders. Keyword matching / notification dispatch / sounds
	 * have already been performed by `NewItemStreamProcessing` upstream —
	 * their results live on `item.data.KWsMatch`, `KW`, `BlurKW`, etc.
	 */
	async addTileInGrid(item, reason = "") {
		if (!(item instanceof Item)) {
			// Upstream validation already constructs Item — defensively guard.
			try {
				item = new Item(item);
			} catch (err) {
				console.error("[V4React] addTileInGrid: bad item payload", err);
				return false;
			}
		}

		try {
			item.setUnavailable(item.data.unavailable == 1);
			if (item.data.title) {
				item.setTitle(unescapeHTML(unescapeHTML(item.data.title)));
			}
			if (item.data.date) {
				item.setDate(YMDHiStoISODate(item.data.date));
			}
			if (item.data.date_added) {
				item.setDateAdded(YMDHiStoISODate(item.data.date_added));
			}
			if (item.data.timestamp == null || Number.isNaN(Number(item.data.timestamp))) {
				item.setTimestamp(Date.now());
			}
			await this.#normalizeKeywordFlags(item);
		} catch (err) {
			console.error("[V4React] addTileInGrid normalise error", err);
		}

		const asin = item.data.asin;
		if (!asin) return false;

		const isNew = !storeHas(asin);

		// Image-based dedup (preserve the legacy behaviour).
		const hideDupe = this._settings.get("notification.monitor.hideDuplicateThumbnail");
		if (hideDupe && isNew && item.data.img_url) {
			if (this._itemsMgr.imageUrls.has(item.data.img_url)) {
				return false;
			}
			if (this.#feedPausedBufferHasImageUrl(item.data.img_url)) {
				return false;
			}
		}

		const data = { ...item.data, date_added: item.data.date_added ?? new Date().toISOString() };

		// While paused, hold **new** ASINs off the store and bump Resume (n).
		if (this._feedPaused && !this._fetchingRecentItems && isNew) {
			return this.#bufferIncomingTileWhilePaused(data, reason || "stream");
		}

		if (hideDupe && isNew && item.data.img_url) {
			this._itemsMgr.imageUrls.add(item.data.img_url);
		}

		storeAddItem(data, reason || "stream");
		this.#updateMostRecentItemDate(data);
		if (this.#pendingUnavailableAsins.has(asin)) {
			storeMarkUnavailable(asin);
			this.#pendingUnavailableAsins.delete(asin);
		}

		// Auto-truncate: keep the feed below the legacy limit. Pinned items
		// are preserved by `computeTruncationRemovals`.
		try {
			const toRemove = storeComputeTruncationRemovals();
			if (toRemove.length > 0) {
				storeRemoveMany(toRemove);
				if (this._fetchingRecentItems || this._settings.get("notification.monitor.sortType") !== "date_desc") {
					storeResetTruncateEndPlaceholders();
				} else {
					storeAddTruncateEndPlaceholders(toRemove.length);
				}
			}
		} catch (err) {
			console.error("[V4React] truncation failed", err);
		}

		if (isNew) {
			if (this._feedPaused) {
				this.#bufferedSoundAsins.add(asin);
			} else {
				await this.#playSoundForNewItem(data);
			}
			this.#maybeBump0EtvForItem(asin, data);
		}

		return isNew;
	}

	#maybeBump0EtvForItem(asin, itemData) {
		if (
			shouldBump0EtvPlacement({
				isZeroEtv: isZeroEtv(itemData),
				isHighlight: isHighlightItem(itemData),
				sort: this._settings.get("notification.monitor.sortType") ?? "date_desc",
				bump0ETV: Boolean(this._settings.get("notification.monitor.bump0ETV")),
				fetchingRecentItems: this._fetchingRecentItems,
			})
		) {
			storeBumpItemRecency(asin);
		}
	}

	async setETVFromASIN(asin, etv) {
		const n = Number(etv);
		if (!Number.isFinite(n)) return false;
		const existing = storeGetData(asin);
		if (!existing) return false;
		const wasZeroEtv = isZeroEtv(existing);
		const wasHighlight = isHighlightItem(existing);
		const prevMin = existing.etv_min;
		const prevMax = existing.etv_max;
		const nMin = prevMin == null || prevMin === "" ? n : Math.min(Number(prevMin), n);
		const nMax = prevMax == null || prevMax === "" ? n : Math.max(Number(prevMax), n);
		storeUpdateETV(asin, nMin, nMax);

		const updated = storeGetData(asin);
		if (!updated) return true;
		const becameZeroEtv = isZeroEtv(updated);
		if (
			!wasZeroEtv &&
			becameZeroEtv &&
			this._settings.get("notification.monitor.bump0ETV") &&
			this._settings.get("notification.monitor.sortType") === "date_desc"
		) {
			// Match V3 intent: promote once when item transitions into 0-ETV.
			// Do not keep re-bumping on every subsequent sort operation.
			storeBumpItemRecency(asin);
		}

		// V3 parity: ETV updates can promote an item to highlight when groups
		// include ETV conditions (and can trigger highlight sound).
		if (this._settings.get("general.keywordsActive")) {
			const becameHighlight = await this.#applyEtvHighlightPromotion(asin, updated, wasHighlight);
			const promoted = storeGetData(asin) ?? updated;
			const nowZeroEtv = isZeroEtv(promoted);
			const transitionTypes = getV3EtvTransitionTypes({
				becameHighlight,
				wasZeroEtv,
				nowZeroEtv,
				zeroEtvSoundEnabled: this._settings.get("notification.monitor.zeroETV.sound") != "0",
			});
			for (const type of transitionTypes) {
				await this.#playSoundForTransition(promoted, type);
			}
			return true;
		}

		const transitionTypes = getV3EtvTransitionTypes({
			becameHighlight: false,
			wasZeroEtv,
			nowZeroEtv: isZeroEtv(updated),
			zeroEtvSoundEnabled: this._settings.get("notification.monitor.zeroETV.sound") != "0",
		});
		for (const type of transitionTypes) {
			await this.#playSoundForTransition(updated, type);
		}
		return true;
	}

	setPriceFromASIN(asin, price) {
		if (!storeHas(asin)) return false;
		storeSetPrice(asin, price);
		return true;
	}

	async setTierFromASIN(asin, tier) {
		if (!storeHas(asin)) return false;
		storeSetTier(asin, String(tier));
		return true;
	}

	setAdditionalImagesFromASIN(asin, additionalImages) {
		if (!storeHas(asin) || !Array.isArray(additionalImages)) return false;
		storeSetAdditionalImages(asin, additionalImages);
		return true;
	}

	setOrderAttemptsFromASIN(asin, success, failed) {
		if (!storeHas(asin)) return false;
		storeSetOrderAttempts(asin, Number(success) || 0, Number(failed) || 0);
		return true;
	}

	async markItemUnavailable(asin) {
		if (!storeHas(asin)) {
			// Unavailable websocket events can race ahead of initial item insert
			// during recent-item fetches; keep a pending flag and apply on add.
			this.#pendingUnavailableAsins.add(asin);
			return false;
		}
		storeMarkUnavailable(asin);
		return true;
	}

	async addVariants(payload) {
		if (!payload || !payload.asin || !Array.isArray(payload.variants)) return false;
		if (!storeHas(payload.asin)) return false;
		storeAddVariants(payload.asin, payload.variants);
		return true;
	}

	async fetchRecentItemsEnd() {
		if (this._settings.get("general.debugSound")) {
			console.log("[SOUND DEBUG] Bulk fetch ended, setting _fetchingRecentItems = false");
		}
		this._fetchingRecentItems = false;
		storeSetFetchingRecentItems(false);

		if (this._feedPaused) {
			this.handlePauseClick(false, true);
		}

		if (this._settings.get("notification.monitor.autoClearUnavailableOnInitialFetch")) {
			if (!this._autoClearedUnavailableOnInitialFetch) {
				this._autoClearedUnavailableOnInitialFetch = true;
				setTimeout(() => {
					try {
						const asins = this._collectUnavailableItemAsins();
						if (asins && asins.size > 0) {
							if (this._settings.get("notification.monitor.passiveClears")) {
								this._startUndoableClear(asins, "unavailable");
							} else {
								this._clearUnavailableItems(asins);
							}
						}
					} catch (err) {
						console.error("[V4React] auto-clear-unavailable failed", err);
					}
				}, 250);
			}
		}
	}

	// ----------------------------------------------------------------------
	// Clear / remove overrides — bypass DOM queries.
	// ----------------------------------------------------------------------

	_removeTile(asin) {
		storeRemove(asin);
		// keep the legacy image-dedup set in sync
		const data = storeGetData(asin);
		if (data?.img_url) {
			this._itemsMgr.imageUrls.delete(String(data.img_url));
		}
		return true;
	}

	_collectVisibleItemAsins() {
		return storeCollectVisibleAsins();
	}

	_collectUnavailableItemAsins() {
		return storeCollectUnavailableAsins();
	}

	_clearAllVisibleItems(asins) {
		const targets = asins ?? this._collectVisibleItemAsins();
		storeRemoveMany(targets);
		return true;
	}

	_clearUnavailableItems(asins) {
		const targets = asins ?? this._collectUnavailableItemAsins();
		storeRemoveMany(targets);
		return true;
	}

	/**
	 * Override the legacy DOM-based undo flow. In V4 the 5-second undo
	 * window is owned by the React `ClearButtons` component (see
	 * `src/monitor-v4/components/Header/ClearButtons.tsx`), but we still
	 * need a working `_startUndoableClear` so the auto-clear-unavailable
	 * branch in `fetchRecentItemsEnd` doesn't crash on the inherited
	 * implementation (which walks DOM nodes that don't exist in V4).
	 *
	 * We route through the store's `beginPendingClear` so the React
	 * countdown UI picks up the pending action just as if the user had
	 * clicked the button.
	 */
	_startUndoableClear(asins, kind /* , preserveScroll */) {
		const store = useMonitorStore.getState();
		const list = Array.isArray(asins) ? asins : Array.from(asins ?? []);
		if (list.length === 0) return false;
		const mapped = kind === "unavailable" ? "unavailable" : "all";
		store.beginPendingClear(mapped, list, Date.now() + 5000);
		return true;
	}

	_cancelPendingClear() {
		useMonitorStore.getState().cancelPendingClear();
	}

	_finalizePendingClear() {
		useMonitorStore.getState().commitPendingClear();
	}

	_getPendingClearAction() {
		return useMonitorStore.getState().pendingClear;
	}

	/**
	 * `_uiApi.handlePauseClick` calls `insertPlaceholderTiles` on
	 * `_noShiftGrid` to prevent layout shift. In V4 Virtuoso handles the
	 * scroll placeholder, so this override is a no-op. (We also null out
	 * `_noShiftGrid` in the constructor — the combination prevents any
	 * raw `<div class="vh-placeholder-tile">` from ever being injected
	 * into `#vvp-items-grid`.)
	 */
	_insertPlaceholderTiles() {
		/* handled by Virtuoso */
	}

	// ----------------------------------------------------------------------
	// DOM-styling overrides — React tiles derive their highlight / disabled
	// / blur state from the Zustand store, and Virtuoso recycles DOM nodes
	// across items. If the legacy styling methods ran on a recycled tile the
	// previous item's inline background / classes would bleed through. Make
	// every styling side-effect a no-op on V4.
	// ----------------------------------------------------------------------
	_processNotificationHighlight() {
		/* Tile.tsx derives highlight / zero-ETV / RFY backgrounds from store. */
	}
	_blurItemFound() {
		/* Tile.tsx derives blur from store. */
	}
	_unblurItemFound() {
		/* Tile.tsx derives blur from store. */
	}
	async _enableItem() {
		/* Tile.tsx reads `unavailable` from the store. */
	}
	async _disableItem() {
		/* Tile.tsx reads `unavailable` from the store. */
	}

	// ----------------------------------------------------------------------
	// Pause state — React's PauseButton reads from the store; legacy code
	// still toggles `_feedPaused`. Keep the store in sync either way.
	// ----------------------------------------------------------------------

	#mirrorPausedToStore() {
		const store = getStore();
		let last = Boolean(this._feedPaused);
		storeSetPaused(last);
		this.#pauseSyncTimer = setInterval(() => {
			const current = Boolean(this._feedPaused);
			if (current !== last) {
				last = current;
				storeSetPaused(current);
			}
			const fetching = Boolean(this._fetchingRecentItems);
			if (fetching !== store.getState().fetchingRecentItems) {
				storeSetFetchingRecentItems(fetching);
			}
		}, 200);
	}

	/**
	 * Public helper so React PauseButton / FixedToolbar can toggle feed pause
	 * using V4-owned UI helpers while preserving legacy buffer semantics.
	 */
	handlePauseClick(isHoverPause = false, skipPlaceholderTiles = false) {
		this._feedPaused = !this._feedPaused;
		if (this._feedPaused) {
			this._feedPausedAmountStored = 0;
			updatePauseButtonUI(true, 0);
			if (this._settings.get("notification.monitor.pauseOverlay")) {
				showPauseOverlay();
			}
		} else {
			if (this._settings.get("notification.monitor.pauseOverlay")) {
				hidePauseOverlay();
			}
			updatePauseButtonUI(false);
			this._unpauseFeed(isHoverPause, skipPlaceholderTiles);
		}
		try {
			storeSetPaused(Boolean(this._feedPaused));
			storeSetPausedBufferCount(this._feedPaused ? (this._feedPausedAmountStored ?? 0) : 0);
		} catch {
			/* ignore */
		}
	}

	/**
	 * Wrap pause toggling so `pausedBufferCount` stays aligned with
	 * `_feedPausedAmountStored` for the Resume (n) label.
	 */
	_buildUIApi() {
		const api = super._buildUIApi();
		api.handlePauseClick = () => this.handlePauseClick();
		return api;
	}

	async _unpauseFeed() {
		await this.#flushFeedPausedBuffer();
		const bufferedAsins = Array.from(this.#bufferedSoundAsins);
		this.#bufferedSoundAsins.clear();

		let groupMap = new Map();
		try {
			const { getGroups } = await importFromExtension("scripts/core/utils/KeywordGroupsManager.js");
			const groups = await getGroups(this._settings);
			groupMap = new Map((groups || []).map((g) => [String(g.id), g]));
		} catch (err) {
			console.warn("[V4React] Error loading keyword groups for unpause sound:", err);
		}

		const visibleBufferedItems = [];
		for (const asin of bufferedAsins) {
			const data = storeGetData(asin);
			if (!data) continue;
			if (!this.#isVisibleUnderCurrentFilters(data)) continue;
			await this.#ensureHighlightGroupId(data);
			visibleBufferedItems.push(data);
		}
		let highestPriorityItem = -1;
		for (const data of visibleBufferedItems) {
			const type = getV3UnpauseCandidateType(data, (key) => this._settings.get(key), groupMap);
			if (type > highestPriorityItem) highestPriorityItem = type;
		}

		if (this._settings.get("general.debugSound")) {
			console.log("[SOUND DEBUG] V4 unpause buffered summary:", {
				bufferedCount: bufferedAsins.length,
				visibleBufferedCount: visibleBufferedItems.length,
				highestPriorityItem,
				_fetchingRecentItems: this._fetchingRecentItems,
			});
		}

		if (highestPriorityItem === -1 || !this._soundPlayerMgr) return;

		if (highestPriorityItem === TYPE_HIGHLIGHT) {
			const { sound, volume } = await resolveHighlightSoundFromItems(this._settings, visibleBufferedItems);
			if (sound != null) {
				if (this._settings.get("general.debugSound")) {
					console.log("[SOUND DEBUG] V4 unpause play highlight:", {
						highestPriorityItem,
						sound,
						volume,
						regularSound: this._settings.get("notification.monitor.regular.sound"),
					});
				}
				this._soundPlayerMgr.play(TYPE_HIGHLIGHT, sound, volume);
				return;
			}
			highestPriorityItem = -1;
			for (const data of visibleBufferedItems) {
				const type = getV3UnpauseCandidateType(data, (key) => this._settings.get(key), groupMap);
				if (type > highestPriorityItem) highestPriorityItem = type;
			}
			if (highestPriorityItem === -1 || highestPriorityItem === TYPE_HIGHLIGHT) return;
		}

		if (this._settings.get("general.debugSound")) {
			console.log("[SOUND DEBUG] V4 unpause play non-highlight:", {
				highestPriorityItem,
			});
		}
		this._soundPlayerMgr.play(highestPriorityItem);
	}

	async #waitForGrid() {
		for (let i = 0; i < 200; i++) {
			const el = document.querySelector(VINE_GRID.ITEMS);
			if (el) return el;
			await new Promise((r) => requestAnimationFrame(r));
		}
		return document.querySelector(VINE_GRID.ITEMS);
	}

	#updateMostRecentItemDate(itemData) {
		const candidateRaw = itemData?.date_added ?? itemData?.date ?? itemData?.timestamp ?? Date.now();
		const candidate = new Date(candidateRaw);
		if (Number.isNaN(candidate.getTime())) return;

		if (this._mostRecentItemDate == null || candidate > this._mostRecentItemDate) {
			if (this._mostRecentItemDateDOM) {
				this._mostRecentItemDateDOM.innerText = this._formatDate(candidate);
			}
			this._mostRecentItemDate = candidate;
		}
	}

	destroy() {
		if (this.#pauseSyncTimer) {
			clearInterval(this.#pauseSyncTimer);
			this.#pauseSyncTimer = null;
		}
		if (typeof this.#tabTitleUnsubscribe === "function") {
			this.#tabTitleUnsubscribe();
			this.#tabTitleUnsubscribe = null;
		}
		this.#pendingUnavailableAsins.clear();
		this.#bufferedSoundAsins.clear();
		this.#feedPausedBuffer = [];
		this.#keywordMatcher = null;
		this.#keywordMatcherInitPromise = null;
		try {
			storeClearAll();
		} catch {
			/* ignore */
		}
		super.destroy?.();
	}

	/**
	 * In V4, DOM tile count can differ from the real feed size because Virtuoso
	 * only mounts what is visible in the viewport. Keep the tab title in sync
	 * with the filtered/renderable item count (after queue/type/search filters).
	 */
	async _updateTabTitle() {
		const visibleCount = useMonitorStore.getState().visibleCount;
		document.title = `VHNM (${visibleCount})`;
	}

	#initTabTitleSync() {
		this._updateTabTitle();
		const store = useMonitorStore;
		let lastCount = store.getState().visibleCount;
		this.#tabTitleUnsubscribe = store.subscribe((state) => {
			const nextCount = state.visibleCount;
			if (nextCount === lastCount) return;
			lastCount = nextCount;
			document.title = `VHNM (${nextCount})`;
		});
	}

	async #ensureKeywordMatcher() {
		if (this.#keywordMatcher) return this.#keywordMatcher;
		if (!this.#keywordMatcherInitPromise) {
			this.#keywordMatcherInitPromise = (async () => {
				await this._settings.waitForLoad();
				const matcher = new KeywordMatcherService(this._settings, this._settings.isPremiumUser(2));
				await matcher.initialize();
				this.#keywordMatcher = matcher;
				return matcher;
			})();
		}
		return this.#keywordMatcherInitPromise;
	}

	async #normalizeKeywordFlags(item) {
		const data = item?.data;
		if (!data || typeof data.title !== "string" || !data.title.trim()) {
			return;
		}

		// Keep explicit payload flags when they exist, but normalize common
		// string/number forms so React selectors don't get tripped by "0"/"1".
		let highlightMatch = toOptionalBoolean(data.KWsMatch);
		let blurMatch = toOptionalBoolean(data.BlurKWsMatch);
		const kw = typeof data.KW === "string" ? data.KW : "";
		const blurKw = typeof data.BlurKW === "string" ? data.BlurKW : "";

		if (highlightMatch == null && kw) highlightMatch = true;
		if (blurMatch == null && blurKw) blurMatch = true;

		// Match V3 Lite fallback behavior: when stream payloads don't include
		// precomputed keyword flags (e.g. some fetch/replay paths), compute them
		// from the configured keyword groups.
		if (highlightMatch == null || blurMatch == null) {
			try {
				const matcher = await this.#ensureKeywordMatcher();
				const etvMin = normalizeEtv(data.etv_min);
				const etvMax = normalizeEtv(data.etv_max);

				if (highlightMatch == null) {
					const match = matcher.findHighlightHideMatchSync(data.title, etvMin, etvMax);
					if (match && match.type === "highlight") {
						highlightMatch = true;
						if (!kw) {
							data.KW = match.contains ?? match.word ?? "";
						}
						if (!data.highlightGroupId && match.groupId) {
							data.highlightGroupId = match.groupId;
						}
					} else {
						highlightMatch = false;
					}
				}

				if (blurMatch == null) {
					const blur = matcher.findBlurMatchSync(data.title, etvMin, etvMax);
					if (blur) {
						blurMatch = true;
						if (!blurKw) {
							data.BlurKW = blur.contains ?? blur.word ?? "";
						}
					} else {
						blurMatch = false;
					}
				}
			} catch (err) {
				console.warn("[V4React] keyword fallback matching failed", err);
			}
		}

		data.KWsMatch = Boolean(highlightMatch);
		data.BlurKWsMatch = Boolean(blurMatch);
		if (typeof data.KW !== "string") data.KW = "";
		if (typeof data.BlurKW !== "string") data.BlurKW = "";
		await this.#ensureHighlightGroupId(data);
	}

	#isVisibleUnderCurrentFilters(itemData) {
		const state = useMonitorStore.getState();
		const asin = itemData?.asin;
		if (!asin) return false;

		if (state.tempHidden?.has(asin)) return false;

		const queueFilter = String(state.filterQueue ?? "-1");
		if (queueFilter !== "-1") {
			const queue = typeof itemData.queue === "string" ? itemData.queue : "";
			if (queue.toUpperCase() !== queueFilter.toUpperCase()) return false;
		}

		const filterType = String(state.filterType ?? "-1");
		if (!passesTypeFilter(itemData, filterType)) return false;

		const needle = String(state.searchText ?? "")
			.trim()
			.toLowerCase();
		if (needle) {
			const title = String(itemData.title ?? "").toLowerCase();
			if (!title.includes(needle)) return false;
		}

		return true;
	}

	async #playSoundForNewItem(itemData) {
		if (!this._soundPlayerMgr || this._feedPaused || this._fetchingRecentItems) return;
		if (!this.#isVisibleUnderCurrentFilters(itemData)) return;
		await this.#ensureHighlightGroupId(itemData);

		const itemType = getV3SoundItemType(itemData);
		let highlightSound;
		let highlightVolume;
		if (itemType === TYPE_HIGHLIGHT) {
			const groupId = itemData.highlightGroupId;
			if (groupId) {
				try {
					const { getGroupById } = await importFromExtension("scripts/core/utils/KeywordGroupsManager.js");
					const group = await getGroupById(this._settings, groupId);
					highlightSound =
						group &&
						group.monitorSound !== null &&
						group.monitorSound !== undefined &&
						group.monitorSound !== "0"
							? group.monitorSound
							: null;
					if (
						group &&
						typeof group.monitorVolume === "number" &&
						group.monitorVolume >= 0 &&
						group.monitorVolume <= 1
					) {
						highlightVolume = group.monitorVolume;
					}
				} catch (error) {
					console.warn("[V4React] Error loading group sound:", error);
					highlightSound = null;
				}
			} else {
				highlightSound = null;
			}
		}

		if (this._settings.get("general.debugSound")) {
			console.log("[SOUND DEBUG] V4 addTile sound decision:", {
				asin: itemData?.asin,
				itemType,
				highlightGroupId: itemData?.highlightGroupId ?? null,
				highlightSound: highlightSound ?? null,
				highlightVolume,
				regularSound: this._settings.get("notification.monitor.regular.sound"),
				_fetchingRecentItems: this._fetchingRecentItems,
				_feedPaused: this._feedPaused,
			});
		}
		this._soundPlayerMgr.play(itemType, highlightSound, highlightVolume);
		const itemTitle = String(itemData.title ?? "").trim();
		if (itemTitle) {
			this._soundPlayerMgr.speak(itemType, itemTitle);
		}
	}

	async #playSoundForTransition(itemData, itemType) {
		if (!this._soundPlayerMgr) return;
		const shouldPlay = this.#isVisibleUnderCurrentFilters(itemData) || this._fetchingRecentItems;
		if (!shouldPlay) return;
		await this.#ensureHighlightGroupId(itemData);

		let highlightSound;
		let highlightVolume;
		if (itemType === TYPE_HIGHLIGHT) {
			const groupId = itemData.highlightGroupId;
			if (groupId) {
				try {
					const { getGroupById } = await importFromExtension("scripts/core/utils/KeywordGroupsManager.js");
					const group = await getGroupById(this._settings, groupId);
					highlightSound =
						group &&
						group.monitorSound !== null &&
						group.monitorSound !== undefined &&
						group.monitorSound !== "0"
							? group.monitorSound
							: null;
					if (
						group &&
						typeof group.monitorVolume === "number" &&
						group.monitorVolume >= 0 &&
						group.monitorVolume <= 1
					) {
						highlightVolume = group.monitorVolume;
					}
				} catch (error) {
					console.warn("[V4React] Error loading group sound:", error);
					highlightSound = null;
				}
			} else {
				highlightSound = null;
			}
		}

		if (this._settings.get("general.debugSound")) {
			console.log("[SOUND DEBUG] V4 transition sound decision:", {
				asin: itemData?.asin,
				itemType,
				highlightGroupId: itemData?.highlightGroupId ?? null,
				highlightSound: highlightSound ?? null,
				highlightVolume,
				regularSound: this._settings.get("notification.monitor.regular.sound"),
				_fetchingRecentItems: this._fetchingRecentItems,
				visibleNow: this.#isVisibleUnderCurrentFilters(itemData),
			});
		}
		this._soundPlayerMgr.play(itemType, highlightSound, highlightVolume);
		const itemTitle = String(itemData.title ?? "").trim();
		if (itemTitle) {
			this._soundPlayerMgr.speak(itemType, itemTitle);
		}
	}

	async #ensureHighlightGroupId(itemData) {
		if (!itemData || !isHighlightItem(itemData) || itemData.highlightGroupId) return;
		if (typeof itemData.title !== "string" || !itemData.title.trim()) return;
		try {
			const matcher = await this.#ensureKeywordMatcher();
			const etvMin = normalizeEtv(itemData.etv_min);
			const etvMax = normalizeEtv(itemData.etv_max);
			const match = matcher.findHighlightHideMatchSync(itemData.title, etvMin, etvMax);
			if (match && match.type === "highlight" && match.groupId) {
				itemData.highlightGroupId = match.groupId;
				if (!itemData.KW && typeof match.contains === "string") {
					itemData.KW = match.contains;
				}
			}
		} catch (err) {
			console.warn("[V4React] highlight group backfill failed", err);
		}
	}

	async #applyEtvHighlightPromotion(asin, itemData, wasHighlight) {
		if (wasHighlight) return false;
		if (!itemData || typeof itemData.title !== "string" || !itemData.title.trim()) return false;
		try {
			const matcher = await this.#ensureKeywordMatcher();
			if (!matcher.hasHighlightGroupsWithEtvConditionsSync()) return false;
			const etvMin = normalizeEtv(itemData.etv_min);
			const etvMax = normalizeEtv(itemData.etv_max);
			const match = matcher.findHighlightHideMatchSync(itemData.title, etvMin, etvMax);
			if (!match || match.type !== "highlight") return false;

			const kw =
				typeof match.contains === "string"
					? match.contains
					: Array.isArray(match.contains) && match.contains.length > 0
						? String(match.contains[0])
						: typeof match.word === "string"
							? match.word
							: "";
			storeAddItem(
				{
					...itemData,
					asin,
					KWsMatch: true,
					KW: kw,
					highlightGroupId: match.groupId ?? itemData.highlightGroupId,
				},
				"etv-highlight-recheck"
			);
			return true;
		} catch (err) {
			console.warn("[V4React] ETV highlight promotion failed", err);
			return false;
		}
	}
}

function toOptionalBoolean(value) {
	if (value === true || value === 1 || value === "1" || value === "true") return true;
	if (value === false || value === 0 || value === "0" || value === "false") return false;
	return null;
}

function normalizeEtv(value) {
	if (value == null || value === "") return null;
	const n = Number(value);
	return Number.isFinite(n) ? n : null;
}

export function getV3SoundItemType(itemData) {
	if (isHighlightItem(itemData)) return TYPE_HIGHLIGHT;
	if (isZeroEtv(itemData)) return TYPE_ZEROETV;
	if (itemData?.queue === "potluck") return TYPE_RFY;
	return TYPE_REGULAR;
}

export function getV3UnpauseCandidateType(itemData, settingsGet, groupMap) {
	if (isHighlightItem(itemData)) {
		if (groupMap === undefined) {
			return TYPE_HIGHLIGHT;
		}
		if (itemHasAudibleHighlightSound(itemData, groupMap)) {
			return TYPE_HIGHLIGHT;
		}
	}
	if (isZeroEtv(itemData) && settingsGet("notification.monitor.zeroETV.sound") != "0") return TYPE_ZEROETV;
	if (itemData?.queue === "potluck" && settingsGet("notification.monitor.rfy.sound") != "0") return TYPE_RFY;
	if (!isZeroEtv(itemData) && !isHighlightItem(itemData)) return TYPE_REGULAR;
	return -1;
}

export function itemHasAudibleHighlightSound(itemData, groupMap) {
	if (!isHighlightItem(itemData) || !groupMap) return false;
	const groupId = itemData?.highlightGroupId;
	if (!groupId) return false;
	const group = groupMap.get(String(groupId));
	if (!group) return false;
	return group.monitorSound != null && group.monitorSound !== undefined && group.monitorSound !== "0";
}

export function getV3EtvTransitionTypes({ becameHighlight, wasZeroEtv, nowZeroEtv, zeroEtvSoundEnabled }) {
	const out = [];
	if (becameHighlight) out.push(TYPE_HIGHLIGHT);
	if (!wasZeroEtv && nowZeroEtv && zeroEtvSoundEnabled) out.push(TYPE_ZEROETV);
	return out;
}

function passesTypeFilter(itemData, filter) {
	if (filter === "-1" || filter === "all") return true;
	const minRaw = itemData?.etv_min;
	const maxRaw = itemData?.etv_max;
	const hasMin = minRaw != null && minRaw !== "";
	const hasMax = maxRaw != null && maxRaw !== "";
	const hasEtv = hasMin && hasMax;
	const minNum = hasMin ? Number(minRaw) : NaN;
	const isZero = hasEtv && minNum === 0;
	const isUnknownEtv = !hasEtv;
	const isHighlight = Boolean(itemData?.KWsMatch || itemData?.KW || itemData?.highlight);
	switch (filter) {
		case "0":
		case "regular":
			return !isZero && !isHighlight;
		case "2":
		case "zeroETV":
			return isZero;
		case "3":
		case "highlight":
			return isHighlight;
		case "4":
		case "unknownETV":
			return isUnknownEtv;
		case "9":
		case "zeroETV_or_highlight":
			return isZero || isHighlight;
		default:
			return true;
	}
}

function isZeroEtv(itemData) {
	if (!itemData) return false;
	const min = parseFloat(itemData?.etv_min);
	const max = parseFloat(itemData?.etv_max);
	return (!Number.isNaN(min) && min === 0) || (!Number.isNaN(max) && max === 0);
}

function isHighlightItem(itemData) {
	return Boolean(itemData?.KWsMatch || itemData?.KW || itemData?.highlight);
}

async function resolveHighlightSoundFromItems(settings, items) {
	if (!Array.isArray(items) || items.length === 0) {
		return { sound: null, volume: undefined };
	}
	try {
		const { getGroups } = await importFromExtension("scripts/core/utils/KeywordGroupsManager.js");
		const groups = await getGroups(settings);
		const groupMap = new Map((groups || []).map((g) => [String(g.id), g]));
		let best = null;
		for (const data of items) {
			const groupId = data?.highlightGroupId;
			if (!groupId) continue;
			const group = groupMap.get(String(groupId));
			if (!group) continue;
			if (group.monitorSound == null || group.monitorSound === "0") continue;
			const order = Number.isFinite(Number(group.order)) ? Number(group.order) : Number.MAX_SAFE_INTEGER;
			if (!best || order < best.order) {
				best = {
					order,
					sound: group.monitorSound,
					volume:
						typeof group.monitorVolume === "number" && group.monitorVolume >= 0 && group.monitorVolume <= 1
							? group.monitorVolume
							: undefined,
				};
			}
		}
		return best ? { sound: best.sound, volume: best.volume } : { sound: null, volume: undefined };
	} catch (err) {
		console.warn("[V4React] Error resolving highlight sound for unpause:", err);
		return { sound: null, volume: undefined };
	}
}
