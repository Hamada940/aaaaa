/*global chrome*/

import { getMessage } from "/scripts/core/services/Internationalization.js";

/**
 * Event handlers for notification monitor UI elements (toolbar, filters, fetch buttons, etc.).
 * Attaches listeners and stores them in eventHandlers for cleanup.
 * All behavior is delegated to the provided `api` (the monitor's callback surface).
 *
 * @param {object} api - Monitor API: handlePauseClick, handleConnectionDetailsClick, onSearchInput,
 *   handleClearMonitor(btn), handleClearUnavailable(btn), runFetchForLimit(limit, btnEl), runFetchLast12hrs(btnEl),
 *   getSessionFetchLimitOverride, getFetchLimit, getLastFetchWasLongPress, setLastFetchWasLongPress,
 *   setSessionFetchLimitOverride, getLongPressOptions, onSortChange, onFilterTypeChange, onFilterQueueChange,
 *   onNotificationActiveChange, onAutoTruncateChange, onAutoTruncateLimitChange, onFocusModeChange,
 *   onFilterPinClick, onFiltersToggle, onFilterClickOutside, getSettings, getPassiveClears, updateFilterCount,
 *   setAutoTruncateCheckbox
 * @param {object} eventHandlers - { window: { scroll }, buttons: Map, documentClick?: fn }
 * @param {function} debugTrackListener - Optional (element, event, handler) for debug
 */
import {
	debugTrackListener as defaultDebugTrackListener,
	debugUntrackListener as defaultDebugUntrackListener,
} from "../debug/MonitorDebug.js";
import { updatePauseButtonUI, showPauseOverlay, hidePauseOverlay } from "./NotificationMonitorUI.js";
import { Item } from "/scripts/core/models/Item.js";
import { mountAll } from "../ui/index.js";

async function fetchConnectionDetailsFromApi(monitor) {
	const env = monitor?._env;
	const cryptoKeys = monitor?._cryptoKeys;
	const settings = monitor?._settings;
	const i18nMgr = monitor?._i18nMgr;
	if (!env || !cryptoKeys || !settings || !i18nMgr) {
		return null;
	}

	const content = {
		api_version: 5,
		app_version: chrome.runtime.getManifest().version,
		action: "get_connection_details",
		country: i18nMgr.getCountryCode(),
		uuid: settings.get("general.uuid", false),
		fid: settings.get("general.fingerprint.id", false),
		cid: await env.getCID(),
	};
	content.s = await cryptoKeys.signData(content);
	content.pk = await cryptoKeys.getExportedPublicKey();

	const response = await fetch(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(content),
	});
	if (!response.ok) {
		return null;
	}
	const payload = await response.json();
	if (payload?.ok !== "ok" || typeof payload.connectionDetails !== "object" || payload.connectionDetails == null) {
		return null;
	}
	return payload.connectionDetails;
}

export function attachUIHandlers(
	api,
	eventHandlers,
	debugTrackListener = defaultDebugTrackListener,
	debugUntrackListener = defaultDebugUntrackListener
) {
	// Ensure eventHandlers.buttons exists for component cleanup
	eventHandlers.buttons = eventHandlers.buttons || new Map();
	mountAll(api, eventHandlers, debugTrackListener, debugUntrackListener);
}

// ---- Handle* implementations (UI handlers call into monitor via _xxx) ----

export function handleClearMonitorPassive(monitor, btn) {
	if (monitor._getPendingClearAction?.()?.undoButton === btn) {
		monitor._cancelPendingClear(true);
		return;
	}
	const visibleAsins = monitor._collectVisibleItemAsins();
	monitor._startUndoableClear(visibleAsins, "visible", true);
}

export function handleClearMonitorDialog(monitor) {
	const visibleAsins = monitor._collectVisibleItemAsins();
	if (confirm("Are you sure you want to clear all visible items?")) {
		monitor._clearAllVisibleItems(visibleAsins);
	}
}

export function handleClearUnavailablePassive(monitor, btn) {
	if (monitor._getPendingClearAction?.()?.undoButton === btn) {
		monitor._cancelPendingClear(true);
		return;
	}
	const unavailableAsins = monitor._collectUnavailableItemAsins();
	monitor._startUndoableClear(unavailableAsins, "unavailable");
}

export function handleClearUnavailableDialog(monitor) {
	const unavailableAsins = monitor._collectUnavailableItemAsins();
	if (confirm("Are you sure you want to clear all unavailable items?")) {
		monitor._clearUnavailableItems(unavailableAsins);
	}
}

export async function handleHideClick(monitor, e, target) {
	e.preventDefault();
	const asin = target.dataset.asin;
	monitor._log.add(`NOTIF: Hiding icon clicked for item ${asin}`);
	try {
		if (monitor._settings.get("notification.monitor.hideAddsToHiddenList")) {
			await monitor._addToHiddenList(asin);
		}
	} catch (err) {
		console.error("Failed to add item to HiddenList from NotificationMonitor:", err);
	}
	const tile = monitor._itemsMgr.getItemDOMElement(asin);
	if (tile) {
		monitor._removeTile(asin);
	}
}

export function handleBrendaClick(monitor, e, target) {
	e.preventDefault();
	if (target.classList.contains("vh-disabled")) return;
	const asin = target.dataset.asin;
	const queue = target.dataset.queue;
	const etvEl = document.querySelector("#vh-notification-" + asin + " .etv");
	const etv = etvEl?.dataset?.etvMax;
	monitor._brendaMgr.announce(asin, etv, queue, monitor._i18nMgr.getDomainTLD());
	target.classList.add("vh-disabled");
}

export async function handlePinClick(monitor, e, target) {
	e.preventDefault();
	if (!monitor._getPinDebounceClickable?.()) return false;
	monitor._setPinDebounceClickable?.(false);
	target.classList.add("vh-disabled");
	monitor._setPinDebounceTimer?.(
		setTimeout(() => {
			monitor._setPinDebounceClickable?.(true);
			target.classList.remove("vh-disabled");
		}, 1000)
	);

	const asin = target.dataset.asin;
	const isPinned = await monitor._pinMgr.checkIfPinned(asin);
	const title = target.dataset.title;

	if (isPinned) {
		monitor._pinMgr.unpinItem(asin);
		monitor._displayToasterNotification({
			title: `Item ${asin} unpinned.`,
			lifespan: 3,
			content: title,
		});
	} else {
		try {
			const item = new Item({
				asin,
				queue: target.dataset.queue,
				title,
				img_url: target.dataset.thumbnail,
				is_parent_asin: target.dataset.isParentAsin,
				enrollment_guid: target.dataset.enrollmentGuid,
			});
			monitor._pinMgr.pinItem(item);
			monitor._displayToasterNotification({
				title: `Item ${asin} pinned.`,
				lifespan: 3,
				content: title,
			});
		} catch (error) {
			console.error("[NotificationMonitor] Cannot create item for pinning -", error.message, {
				source: "pin button click",
				asin,
				queue: target.dataset.queue,
				enrollment_guid: target.dataset.enrollmentGuid,
				is_parent_asin: target.dataset.isParentAsin,
				raw_dataset: target.dataset,
			});
			monitor._displayToasterNotification({
				title: `Failed to pin item ${asin}`,
				lifespan: 3,
				content: "Missing required data",
				type: "error",
			});
		}
	}
}

export async function handleDetailsClick(monitor, e, target) {
	e.preventDefault();
	const asin = target.dataset.asin;
	const dateSent = target.dataset.dateSent;
	const dateAdded = target.dataset.dateAdded;
	const dateReceived = target.dataset.dateReceived;
	const tier = target.dataset.tier;
	const reason = target.dataset.reason;
	const highlightKW = target.dataset.highlightkw || "";
	const blurKW = target.dataset.blurkw || "";
	const queue = target.dataset.queue;

	const m = monitor._dialogMgr.newModal("item-details-" + asin);
	m.title = "Item " + asin;
	const firstSeen = getMessage("itemDetailsFirstSeen", "First seen: ");
	const broadcastSent = getMessage("itemDetailsBroadcastSent", "Broadcast sent: ");
	const broadcastReason = getMessage("itemDetailsBroadcastReason", "Broadcast reason: ");
	const dataReceived = getMessage("itemDetailsDataReceived", "Data received: ");
	const queueLbl = getMessage("itemDetailsQueue", "Queue: ");
	const foundInTier = getMessage("itemDetailsFoundInTier", "Found in tier: ");
	const highlightKWLbl = getMessage("itemDetailsHighlightKW", "Highlight Keyword: ");
	const blurKWLbl = getMessage("itemDetailsBlurKW", "Blur Keyword: ");
	const reportLbl = getMessage("itemDetailsReport", "Report: ");
	const reportLinkText = getMessage("itemDetailsReportLink", "Report the user who contributed this item");
	m.content = `
		<ul style="margin-bottom: 10px;">
			<li>${firstSeen}${monitor._formatDate(new Date(dateAdded))}</li>
			<li>${broadcastSent}${monitor._formatDate(new Date(dateSent))}</li>
			<li>${broadcastReason}${reason}</li>
			<li>${dataReceived}${monitor._formatDate(new Date(dateReceived))}</li>
			<li>${queueLbl}${queue}</li>
			<li>${foundInTier}${tier}</li>
			<li>${highlightKWLbl}${highlightKW}</li>
			<li>${blurKWLbl}${blurKW}</li>
			<li>${reportLbl}<a href="#" class="report-link" style="color:red;" data-asin="${asin}">${reportLinkText}</a></li>
		</ul>
	`;
	await m.show();

	const reportLink = document.querySelector("a.report-link");
	if (reportLink) {
		reportLink.addEventListener("click", (event) => {
			event.preventDefault();
			handleReportClick(monitor, event, event.target);
		});
	}
}

export async function handleConnectionDetailsClick(monitor, e) {
	e.preventDefault();
	try {
		const apiData = await fetchConnectionDetailsFromApi(monitor);
		if (apiData) {
			monitor._showConnectionDetailsModal(apiData);
			return;
		}
	} catch (error) {
		console.warn("[ConnectionDetails] API fallback failed, trying websocket path:", error);
	}

	//Fall back to old websocket path to obtain the connection details
	const isServiceWorkerMode = monitor._settings.get("notification.connectionMode") == "1";
	if (isServiceWorkerMode) {
		chrome.runtime.sendMessage({ type: "getConnectionDetails" }, () => {
			if (chrome.runtime.lastError) {
				console.error("Error getting connection details:", chrome.runtime.lastError);
				monitor._showConnectionDetailsModal({});
			}
		});
	} else {
		const data = monitor._ws ? monitor._ws.getConnectionDetails() : {};
		monitor._showConnectionDetailsModal(data);
	}
}

export function handleReportClick(monitor, e, target) {
	e.preventDefault();
	const asin = target.dataset.asin;
	const fallback =
		"Are you sure you want to REPORT the user who posted ASIN#" +
		asin +
		"?\n" +
		"Only report notifications which are not Amazon products\n" +
		"Note: False reporting may get you banned.\n\n" +
		"type REPORT in the field below to send a report:";
	const promptMsg = getMessage("itemDetailsReportConfirm", fallback, [asin]);
	const val = prompt(promptMsg);
	if (val !== null && val.toLowerCase() === "report") {
		monitor._sendReport(asin);
	} else {
		alert(getMessage("itemDetailsReportNotSent", "Not reported."));
	}
}

export function handleHoverPauseEnd(monitor) {
	if (monitor._getPausedByMouseoverSeeDetails?.()) {
		monitor._setPausedByMouseoverSeeDetails?.(false);
		if (monitor._feedPaused) {
			handlePauseClick(monitor, true);
		}
	}
}

export function handlePauseClick(monitor, isHoverPause = false, skipPlaceholderTiles = false) {
	monitor._feedPaused = !monitor._feedPaused;
	if (monitor._feedPaused) {
		monitor._feedPausedAmountStored = 0;
		updatePauseButtonUI(true, 0);
		if (monitor._settings.get("notification.monitor.pauseOverlay")) {
			showPauseOverlay();
		}
	} else {
		if (monitor._settings.get("notification.monitor.pauseOverlay")) {
			hidePauseOverlay();
		}
		updatePauseButtonUI(false);
		monitor._unpauseFeed(isHoverPause, skipPlaceholderTiles);
	}
}
