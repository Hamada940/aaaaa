/**
 * Grid pointer handlers extracted from NotificationMonitor for testing and smaller core file.
 */
import { Item } from "/scripts/core/models/Item.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";
import { BuyNow } from "/scripts/core/services/BuyNow.js";
import { createOrderNowButtonProgress } from "/scripts/core/services/OrderNowButtonProgress.js";
import {
	handleHoverPauseEnd as uiHandleHoverPauseEnd,
	handlePauseClick as uiHandlePauseClick,
	handleBrendaClick as uiHandleBrendaClick,
	handlePinClick as uiHandlePinClick,
	handleHideClick as uiHandleHideClick,
	handleDetailsClick as uiHandleDetailsClick,
} from "/scripts/notifications-monitor/core/NotificationMonitorUIHandlers.js";
import { eventClosestIconOrLinkChild } from "/scripts/notifications-monitor/services/MonitorEventTargeting.js";
import { isWebKitNonChromium } from "/scripts/core/utils/BrowserDetection.js";

function openUrlInNewTab(url) {
	if (!url) return;
	try {
		if (chrome?.tabs?.create) {
			chrome.tabs.create({ url });
			return;
		}
		if (chrome?.runtime?.sendMessage) {
			chrome.runtime.sendMessage({ type: "openUrlInNewTab", url });
			return;
		}
	} catch (error) {
		console.warn("[NotificationMonitor] Failed to open tab via extension API, falling back to window.open", error);
	}
	window.open(url, "_blank", "noopener,noreferrer");
}

function shouldUseExtensionTabOpen(monitor) {
	return isWebKitNonChromium();
}

/**
 * Whether See Details should open Amazon in a new tab instead of the in-place modal.
 * V3 Lite and V4 each use their own setting; Amazon V3 uses openLinksInNewTab.
 *
 * @param {object} monitor - NotificationMonitor instance
 * @param {MouseEvent} e
 * @returns {boolean}
 */
function resolveSeeDetailsOpenInNewTab(monitor, e) {
	const modifier = Boolean(e.ctrlKey || e.metaKey);
	if (monitor._monitorV4React) {
		const v3LiteOpenLinksInNewTab =
			monitor._monitorV3Lite && monitor._settings.get("notification.monitor.v3LiteOpenLinksInNewTab") == "1";
		return (
			monitor._settings.get("notification.monitor.openLinksInNewTab") == "1" ||
			modifier ||
			v3LiteOpenLinksInNewTab
		);
	}
	if (monitor._monitorV3Lite) {
		return modifier || monitor._settings.get("notification.monitor.v3LiteOpenLinksInNewTab") == "1";
	}
	return modifier || monitor._settings.get("notification.monitor.openLinksInNewTab") == "1";
}

/**
 * @param {object} monitor - NotificationMonitor instance
 * @param {MouseEvent} e
 */
function handleGridMouseover(monitor, e) {
	if (
		eventClosestIconOrLinkChild(e, ".vh-btn-container", () => {
			e.preventDefault();
			if (!monitor._feedPaused) {
				monitor._setPausedByMouseoverSeeDetails(true);
				uiHandlePauseClick(monitor, true);
			}
		})
	) {
		return;
	}

	uiHandleHoverPauseEnd(monitor);
}

/**
 * @param {object} monitor - NotificationMonitor instance
 * @param {MouseEvent} e
 */
function handleGridClick(monitor, e) {
	uiHandleHoverPauseEnd(monitor);

	if (
		monitor._settings.get("general.orderNow.active") &&
		eventClosestIconOrLinkChild(e, ".vh-buy-now-btn", (event, btn) => {
			event.preventDefault();
			event.stopPropagation();
			if (!e.isTrusted) return;
			const asin = btn.dataset.asin;
			const queue = btn.dataset.queue ?? "";
			const isParentAsin = btn.dataset.isParentAsin ?? "false";
			const recommendationId = btn.dataset.recommendationId;
			if (!asin || !recommendationId) return;
			const LABEL_BUY_NOW = getMessage("btnOrderNow", "Order Now");
			const LABEL_SURE = getMessage("btnOrderNowConfirm", "Confirm?");
			const CONFIRM_MS = 2000;
			const textEl = btn.querySelector(".vh-buy-now-btn-text") || btn;
			const currentText = (textEl.textContent || "").trim();
			if (currentText === LABEL_SURE) {
				clearTimeout(btn._vhBuyNowTimeout);
				btn._vhBuyNowTimeout = null;
				const progress = createOrderNowButtonProgress(btn);
				void BuyNow.startBuyNow(
					asin,
					queue,
					isParentAsin,
					recommendationId,
					monitor._env,
					monitor._i18nMgr,
					progress.onProgress
				).then((ok) => {
					if (!ok) progress.setError();
				});
				return;
			} else {
				textEl.textContent = LABEL_SURE;
				clearTimeout(btn._vhBuyNowTimeout);
				btn._vhBuyNowTimeout = setTimeout(() => {
					btn._vhBuyNowTimeout = null;
					const sureLabel = getMessage("btnOrderNowConfirm", "Confirm?");
					if (textEl.textContent === sureLabel) textEl.textContent = getMessage("btnOrderNow", "Order Now");
				}, CONFIRM_MS);
			}
		})
	) {
		return;
	}

	if (
		eventClosestIconOrLinkChild(e, ".vh-icon-search", (event, icon) => {
			event.preventDefault();
			const href = icon.closest("a")?.href;
			if (!href) return;
			if (shouldUseExtensionTabOpen(monitor)) {
				openUrlInNewTab(href);
				return;
			}
			window.open(href, "_blank", "noopener,noreferrer");
		})
	) {
		return;
	}

	const titleLink = e.target.closest(".vvp-item-product-title-container a.a-link-normal");
	if (titleLink) {
		if (shouldUseExtensionTabOpen(monitor)) {
			e.preventDefault();
			openUrlInNewTab(titleLink.href);
			return;
		}
	}

	if (
		eventClosestIconOrLinkChild(e, ".vh-icon-announcement", (event, icon) => {
			if (monitor._settings.get("discord.active") && monitor._settings.get("discord.guid", false) != null) {
				uiHandleBrendaClick(monitor, event, icon);
			}
		})
	) {
		return;
	}

	if (
		eventClosestIconOrLinkChild(e, ".vh-icon-pin, .vh-icon-unpin", (event, icon) => {
			if (monitor._settings.get("pinnedTab.active")) {
				uiHandlePinClick(monitor, event, icon);
			}
		})
	) {
		return;
	}

	if (
		eventClosestIconOrLinkChild(e, ".vh-icon-hide", (event, icon) => {
			uiHandleHideClick(monitor, event, icon);
		})
	) {
		return;
	}

	if (
		eventClosestIconOrLinkChild(e, ".vh-icon-question", (event, icon) => {
			uiHandleDetailsClick(monitor, event, icon);
		})
	) {
		return;
	}

	const seeDetailsBtn = e.target.closest(".a-button-primary input");
	if (seeDetailsBtn) {
		if (e.isTrusted === false) {
			// report untrusted — optional
		}
	}

	const shouldOpenInNewTab = resolveSeeDetailsOpenInNewTab(monitor, e);

	if (shouldOpenInNewTab) {
		if (seeDetailsBtn) {
			e.preventDefault();
			const btnContainer = e.target.closest(".vvp-details-btn");
			if (btnContainer) {
				btnContainer.classList.remove("vvp-details-btn");
				btnContainer.classList.remove("vvp-details-btn-mobile");
			}

			try {
				const item = new Item({
					asin: seeDetailsBtn.dataset.asin,
					queue: seeDetailsBtn.dataset.queue,
					is_parent_asin: seeDetailsBtn.dataset.isParentAsin === "true",
					is_pre_release: seeDetailsBtn.dataset.isPreRelease === "true",
					enrollment_guid: seeDetailsBtn.dataset.enrollmentGuid,
				});

				const link = document.createElement("a");
				link.href = item.getVHOpenModalURL();
				link.target = "_blank";
				link.rel = "noopener noreferrer";
				link.style.display = "none";

				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			} catch (error) {
				console.error("[NotificationMonitor] Cannot create item for modal -", error.message, {
					source: "see details button click",
					asin: seeDetailsBtn.dataset.asin,
					queue: seeDetailsBtn.dataset.queue,
					enrollment_guid: seeDetailsBtn.dataset.enrollmentGuid,
					is_parent_asin: seeDetailsBtn.dataset.isParentAsin,
					is_pre_release: seeDetailsBtn.dataset.isPreRelease,
					raw_dataset: seeDetailsBtn.dataset,
				});
			}
		}
	} else {
		if (monitor._monitorV3Lite && seeDetailsBtn) {
			e.preventDefault();
			monitor._liteDetailsModal
				?.openFromButtonData({
					asin: seeDetailsBtn.dataset.asin,
					queue: seeDetailsBtn.dataset.queue,
					isParentAsin: seeDetailsBtn.dataset.isParentAsin,
					isPreRelease: seeDetailsBtn.dataset.isPreRelease,
					recommendationId: seeDetailsBtn.dataset.recommendationId,
					enrollmentGuid: seeDetailsBtn.dataset.enrollmentGuid,
				})
				.catch((error) => {
					console.error("[NotificationMonitor] Failed to open V3 Lite details modal", error, {
						source: "see details button click",
						asin: seeDetailsBtn.dataset.asin,
						queue: seeDetailsBtn.dataset.queue,
						enrollment_guid: seeDetailsBtn.dataset.enrollmentGuid,
						is_parent_asin: seeDetailsBtn.dataset.isParentAsin,
						raw_dataset: seeDetailsBtn.dataset,
					});
					monitor._displayToasterNotification({
						title: "Unable to open details",
						content: error?.message || "Unexpected error.",
						type: "error",
						lifespan: 8,
					});
				});
			return;
		}
		// Open in place (Vine default)
	}
}

export { handleGridMouseover, handleGridClick, resolveSeeDetailsOpenInNewTab };
