/* eslint-disable no-console -- V3 fallback when Monitor V4 debug bridge is unavailable */
/**
 * @fileoverview Debug helpers for NotificationMonitor and webhook flow. All logic and
 * settings checks live here; callers pass the monitor (or settings manager) and payload
 * and get a single-line call.
 */

const SETTING_DEBUG_PLACEHOLDERS = "general.debugPlaceholders";
const SETTING_DEBUG_TAB_TITLE = "general.debugTabTitle";
const SETTING_DEBUG_KEYWORDS = "general.debugKeywords";
const SETTING_DEBUG_TILE_COUNTER = "general.debugTileCounter";
const SETTING_DEBUG_ITEM_PROCESSING = "general.debugItemProcessing";
const SETTING_DEBUG_SOUND = "general.debugSound";
const SETTING_DEBUG_WEBHOOKS = "general.debugWebhooks";

function getSettings(monitor) {
	return monitor?._settings;
}

function emitViaMonitorDebugBridge(settingsManager, settingKey, category, message, payload = {}) {
	if (typeof window !== "undefined" && window.__VH_MONITOR_DEBUG_EMIT__) {
		window.__VH_MONITOR_DEBUG_EMIT__(settingKey, category, message, payload, settingsManager);
		return true;
	}
	return false;
}

function isWebhookDebugEnabled(settingsManager) {
	return !!(settingsManager && settingsManager.get(SETTING_DEBUG_WEBHOOKS));
}

function safeUrlHost(url) {
	if (!url) return "(no URL)";
	try {
		return new URL(url).host;
	} catch {
		return "(invalid URL)";
	}
}

/**
 * Log fetch-complete placeholder debug if general.debugPlaceholders is enabled.
 * @param {Object} monitor - NotificationMonitor instance
 */
export function debugFetchComplete(monitor) {
	const settings = getSettings(monitor);
	if (!settings?.get(SETTING_DEBUG_PLACEHOLDERS)) return;

	const gridContainer = monitor._gridContainer;
	const itemTiles = gridContainer?.querySelectorAll(".vvp-item-tile:not(.vh-placeholder-tile)") ?? [];
	const placeholderTiles = gridContainer?.querySelectorAll(".vh-placeholder-tile") ?? [];
	const visibleCount = monitor._tileCounter?.getCount?.() ?? 0;

	const payload = {
		visibleCount,
		totalItems: monitor._itemsMgr?.items?.size,
		gridChildren: gridContainer?.children?.length ?? 0,
		itemTiles: itemTiles.length,
		placeholders: placeholderTiles.length,
		visibilityStateCount: visibleCount,
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settings,
			SETTING_DEBUG_PLACEHOLDERS,
			"Placeholders",
			"Fetch complete (after DOM settle)",
			payload
		)
	) {
		return;
	}
	console.log("[fetchRecentItemsEnd] Fetch complete (after DOM settle)", payload);
}

/**
 * Log visibility change if general.debugTabTitle or general.debugPlaceholders is enabled.
 * Call only when beforeDisplay !== afterDisplay; recount remains the caller's responsibility.
 *
 * @param {Object} monitor - NotificationMonitor instance (used for settings only)
 * @param {Object} payload - { asin, beforeDisplay, afterDisplay, typeZeroETV, typeHighlight, currentFilter, filterName }
 */
export function debugVisibilityChange(monitor, payload) {
	const settings = getSettings(monitor);
	if (!settings?.get(SETTING_DEBUG_TAB_TITLE) && !settings?.get(SETTING_DEBUG_PLACEHOLDERS)) return;
	if (payload.beforeDisplay === payload.afterDisplay) return;

	const logPayload = {
		asin: payload.asin,
		beforeDisplay: payload.beforeDisplay,
		afterDisplay: payload.afterDisplay,
		typeZeroETV: payload.typeZeroETV,
		typeHighlight: payload.typeHighlight,
		currentFilter: payload.currentFilter,
		filterName: payload.filterName,
		styleDisplay: "flex",
		timestamp: new Date().toISOString(),
	};
	const settingKey = settings?.get(SETTING_DEBUG_TAB_TITLE) ? SETTING_DEBUG_TAB_TITLE : SETTING_DEBUG_PLACEHOLDERS;
	if (emitViaMonitorDebugBridge(settings, settingKey, "Visibility", "Item visibility changed", logPayload)) {
		return;
	}
	console.log("[NotificationMonitor] Item visibility changed", logPayload);
}

/**
 * Log filter check and optional visibility mismatch if general.debugKeywords is enabled.
 *
 * @param {Object} monitor - NotificationMonitor instance (used for settings only)
 * @param {Object} payload - {
 *   asin, typeHighlight, typeZeroETV, currentFilter, filterName,
 *   notificationTypeHighlight, notificationTypeZeroETV, shouldBeVisible,
 *   visibilityMismatch (boolean: KW Match Only + typeHighlight=1 but !shouldBeVisible)
 * }
 */
export function debugFilterCheck(monitor, payload) {
	const settings = getSettings(monitor);
	if (!settings?.get(SETTING_DEBUG_KEYWORDS)) return;

	const logPayload = {
		asin: payload.asin,
		typeHighlight: payload.typeHighlight,
		typeZeroETV: payload.typeZeroETV,
		currentFilter: payload.currentFilter,
		filterName: payload.filterName,
		notificationTypeHighlight: payload.notificationTypeHighlight,
		notificationTypeZeroETV: payload.notificationTypeZeroETV,
		willBeVisible: payload.shouldBeVisible,
		timestamp: new Date().toISOString(),
	};
	if (emitViaMonitorDebugBridge(settings, SETTING_DEBUG_KEYWORDS, "Keywords", "Filter check", logPayload)) {
		if (payload.visibilityMismatch) {
			emitViaMonitorDebugBridge(settings, SETTING_DEBUG_KEYWORDS, "Keywords", "Visibility mismatch detected", {
				asin: payload.asin,
				issue: "Item has typeHighlight=1 but willBeVisible=false with KW Match Only filter",
				typeHighlight: payload.typeHighlight,
				notificationTypeHighlight: payload.notificationTypeHighlight,
				filterType: payload.currentFilter,
				timestamp: new Date().toISOString(),
			});
		}
		return;
	}
	console.log("[NotificationMonitor] Filter check:", logPayload);

	if (payload.visibilityMismatch) {
		console.warn("[NotificationMonitor] Visibility mismatch detected:", {
			asin: payload.asin,
			issue: "Item has typeHighlight=1 but willBeVisible=false with KW Match Only filter",
			typeHighlight: payload.typeHighlight,
			notificationTypeHighlight: payload.notificationTypeHighlight,
			filterType: payload.currentFilter,
			timestamp: new Date().toISOString(),
		});
	}
}

/**
 * Initialize TileCounter debugger and expose monitor/tileCounter/debugger if general.debugTileCounter is enabled.
 * @param {Object} monitor - NotificationMonitor instance
 * @returns {Promise<void>}
 */
export async function debugInitTileCounter(monitor) {
	const settings = getSettings(monitor);
	if (!settings?.get(SETTING_DEBUG_TILE_COUNTER)) return;

	window.VHelper = window.VHelper || {};
	window.VHelper.monitor = monitor;

	const tileCounter = monitor.getTileCounter?.();
	if (!tileCounter) {
		console.error("[NotificationMonitor] TileCounter not available for debugging");
		return;
	}

	try {
		const module = await import("/scripts/notifications-monitor/debug/TileCounterDebugger.js");
		const TileCounterDebugger = module.TileCounterDebugger || module.default || module;

		if (!TileCounterDebugger) {
			console.error("[NotificationMonitor] TileCounterDebugger module not found");
			return;
		}

		const debuggerInstance = new TileCounterDebugger(tileCounter);

		window.tileCounter = tileCounter;
		window.tileCounterDebugger = debuggerInstance;

		console.log("🔍 TileCounter Debugger loaded. Use window.tileCounter and window.tileCounterDebugger to access.");

		tileCounter.setPerformanceMetrics(true);
	} catch (error) {
		console.error("Failed to initialize TileCounterDebugger:", error);
	}
}

/**
 * Log item-processing (ETV styling) debug if general.debugItemProcessing is enabled.
 * @param {Object} monitor - NotificationMonitor instance
 * @param {string} topic - e.g. "etv.clearingUnknownETV", "etv.hidingItemNoLongerMatches", "etv.filterReapplied"
 * @param {Object} payload - Data to log (timestamp added if missing)
 */
export function debugItemProcessing(monitor, topic, payload = {}) {
	const settings = getSettings(monitor);
	if (!settings?.get(SETTING_DEBUG_ITEM_PROCESSING)) return;
	const p = { ...payload, timestamp: payload.timestamp ?? new Date().toISOString() };
	if (emitViaMonitorDebugBridge(settings, SETTING_DEBUG_ITEM_PROCESSING, "ItemProcessing", topic, p)) return;
	console.log("[DEBUG-ETV-STYLING]", topic, p);
}

/**
 * Log sound debug if general.debugSound is enabled.
 * @param {Object} monitor - NotificationMonitor instance
 * @param {string} topic - e.g. "sound.handleItemFound", "sound.bulkFetchLast100", "sound.bulkFetchFilterChange"
 * @param {Object} payload - Data to log (optional; for simple messages use { message: "..." })
 */
export function debugSound(monitor, topic, payload = {}) {
	const settings = getSettings(monitor);
	if (!settings?.get(SETTING_DEBUG_SOUND)) return;
	const p = { ...payload, timestamp: payload.timestamp ?? new Date().toISOString() };
	if (emitViaMonitorDebugBridge(settings, SETTING_DEBUG_SOUND, "Sound", topic, p)) return;
	console.log("[SOUND DEBUG]", topic, p);
}

/**
 * Track a listener with MEMORY_DEBUGGER if present. No-op when MEMORY_DEBUGGER is disabled.
 * @param {EventTarget} element
 * @param {string} event
 * @param {EventListener} handler
 */
export function debugTrackListener(element, event, handler) {
	if (window.MEMORY_DEBUGGER && typeof window.MEMORY_DEBUGGER.trackListener === "function") {
		window.MEMORY_DEBUGGER.trackListener(element, event, handler);
	}
}

/**
 * Untrack a listener with MEMORY_DEBUGGER if present. No-op when MEMORY_DEBUGGER is disabled.
 * @param {EventTarget} element
 * @param {string} event
 * @param {EventListener} handler
 */
export function debugUntrackListener(element, event, handler) {
	if (window.MEMORY_DEBUGGER && typeof window.MEMORY_DEBUGGER.untrackListener === "function") {
		window.MEMORY_DEBUGGER.untrackListener(element, event, handler);
	}
}

// --- Webhook debug (callers pass settingsManager; used by NewItemStreamProcessing and WebhookQueue) ---

/**
 * Log when transformWebhook skips (no item, fetchLatest, no monitor, not master).
 * @param {Object} settingsManager
 * @param {{ reason?: string, asin?: string, fetchLatest?: boolean, isMaster?: boolean }} payload
 */
export function debugWebhookTransformSkipped(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		reason: payload.reason,
		asin: payload.asin,
		fetchLatest: !!payload.fetchLatest,
		isMaster: !!payload.isMaster,
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"Webhook",
			"Webhook transform skipped",
			logPayload
		)
	)
		return;
	console.log("[NewItemStreamProcessing] Webhook skipped (transformWebhook):", logPayload);
}

/**
 * Log webhook decision (KWsMatch / AFA / RFY flags and enabled state).
 * @param {Object} settingsManager
 * @param {{ asin, queue, webhookKW, webhookAFA, webhookRFY, KWsMatchWebhook, webhookAFAEnabled, webhookRFYEnabled }} payload
 */
export function debugWebhookDecision(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		asin: payload.asin,
		queue: payload.queue,
		webhookKW: payload.webhookKW,
		webhookAFA: payload.webhookAFA,
		webhookRFY: payload.webhookRFY,
		KWsMatchWebhook: payload.KWsMatchWebhook,
		webhookAFAEnabled: payload.webhookAFAEnabled,
		webhookRFYEnabled: payload.webhookRFYEnabled,
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"Webhook",
			"Webhook dispatch decision",
			logPayload
		)
	)
		return;
	console.log("[NewItemStreamProcessing] Webhook decision:", logPayload);
}

/**
 * Log highlight group webhook flag (group found, webhook value, KWsMatchWebhook).
 * @param {Object} settingsManager
 * @param {{ asin, groupId, groupFound, groupName, webhook, KWsMatchWebhook }} payload
 */
export function debugWebhookHighlightGroupWebhook(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		asin: payload.asin,
		groupId: payload.groupId,
		groupFound: payload.groupFound,
		groupName: payload.groupName,
		webhook: payload.webhook,
		KWsMatchWebhook: payload.KWsMatchWebhook,
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"Webhook",
			"Highlight group webhook flag",
			logPayload
		)
	)
		return;
	console.log("[NewItemStreamProcessing] Highlight group webhook flag:", logPayload);
}

/**
 * Log when queuing KWsMatch webhook (url present, host).
 * @param {Object} settingsManager
 * @param {{ asin, url }} payload - url can be string or undefined
 */
export function debugWebhookQueuingKWsMatch(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		asin: payload.asin,
		urlPresent: !!payload.url,
		urlHost: safeUrlHost(payload.url),
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"Webhook",
			"Queuing KWsMatch webhook",
			logPayload
		)
	)
		return;
	console.log("[NewItemStreamProcessing] Webhook queuing KWsMatch:", logPayload);
}

/**
 * Log when queuing AFA webhook.
 * @param {Object} settingsManager
 * @param {{ asin, url }} payload
 */
export function debugWebhookQueuingAFA(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		asin: payload.asin,
		urlHost: safeUrlHost(payload.url),
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(settingsManager, SETTING_DEBUG_WEBHOOKS, "Webhook", "Queuing AFA webhook", logPayload)
	)
		return;
	console.log("[NewItemStreamProcessing] Webhook queuing AFA:", logPayload);
}

/**
 * Log when queuing RFY webhook.
 * @param {Object} settingsManager
 * @param {{ asin, url }} payload
 */
export function debugWebhookQueuingRFY(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		asin: payload.asin,
		urlHost: safeUrlHost(payload.url),
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(settingsManager, SETTING_DEBUG_WEBHOOKS, "Webhook", "Queuing RFY webhook", logPayload)
	)
		return;
	console.log("[NewItemStreamProcessing] Webhook queuing RFY:", logPayload);
}

/**
 * Log when a webhook is added to the queue.
 * @param {Object} settingsManager
 * @param {{ url, queueLength, method }} payload
 */
export function debugWebhookQueueQueued(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		urlHost: safeUrlHost(payload.url),
		queueLength: payload.queueLength,
		method: payload.method || "POST",
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(settingsManager, SETTING_DEBUG_WEBHOOKS, "WebhookQueue", "Webhook queued", logPayload)
	)
		return;
	console.log("[WebhookQueue] Queued:", logPayload);
}

/**
 * Log before sending fetch.
 * @param {Object} settingsManager
 * @param {{ url, method }} payload
 */
export function debugWebhookQueueSending(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		urlHost: safeUrlHost(payload.url),
		method: payload.method || "POST",
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"WebhookQueue",
			"Sending webhook fetch",
			logPayload
		)
	)
		return;
	console.log("[WebhookQueue] Sending fetch:", logPayload);
}

/**
 * Log after fetch response.
 * @param {Object} settingsManager
 * @param {{ url, status, ok, statusText }} payload
 */
export function debugWebhookQueueResponse(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const logPayload = {
		urlHost: safeUrlHost(payload.url),
		status: payload.status,
		ok: payload.ok,
		statusText: payload.statusText,
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"WebhookQueue",
			"Webhook response received",
			logPayload
		)
	)
		return;
	console.log("[WebhookQueue] Response:", logPayload);
}

/**
 * Log fetch error details (in addition to console.error in caller).
 * @param {Object} settingsManager
 * @param {{ url, error }} payload - error object with name, message, cause
 */
export function debugWebhookQueueError(settingsManager, payload) {
	if (!isWebhookDebugEnabled(settingsManager)) return;
	const err = payload.error;
	const logPayload = {
		urlHost: safeUrlHost(payload.url),
		errorName: err?.name,
		errorMessage: err?.message,
		errorCause: err?.cause,
		timestamp: new Date().toISOString(),
	};
	if (
		emitViaMonitorDebugBridge(
			settingsManager,
			SETTING_DEBUG_WEBHOOKS,
			"WebhookQueue",
			"Webhook fetch error",
			logPayload
		)
	)
		return;
	console.log("[WebhookQueue] Fetch error details:", logPayload);
}
