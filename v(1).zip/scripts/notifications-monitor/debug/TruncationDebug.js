/* eslint-disable no-console -- V3 fallback when Monitor V4 debug bridge is unavailable */
/**
 * @fileoverview Single-line debug observer for truncation, bulk-remove, and placeholders.
 * Callers pass (topic, context, ...args). The observer obtains settings from context,
 * gates by topic, extracts payload via topic-specific extractors, and logs one line.
 * Context is the monitor or NoShiftGrid instance; extractors own all data extraction.
 */

const TRUNCATION_SETTING = "general.debugTruncation";
const BULK_SETTING = "general.debugBulkOperations";
const PLACEHOLDERS_SETTING = "general.debugPlaceholders";

const BULK_TOPICS = new Set(["bulk.start", "bulk.cleanupStart", "bulk.cleanupDone", "bulk.atomicCount"]);

function getSettings(context) {
	return context?._settings ?? context?._monitor?._settings;
}

function isEnabled(settings, topic) {
	if (!settings) return false;
	const useBulk = BULK_TOPICS.has(topic);
	const usePlaceholders = topic.startsWith("placeholders.");
	return useBulk
		? settings.get(BULK_SETTING)
		: usePlaceholders
			? settings.get(PLACEHOLDERS_SETTING)
			: settings.get(TRUNCATION_SETTING);
}

function settingKeyForTopic(topic) {
	if (BULK_TOPICS.has(topic)) return BULK_SETTING;
	if (topic.startsWith("placeholders.")) return PLACEHOLDERS_SETTING;
	return TRUNCATION_SETTING;
}

function getTag(topic) {
	return BULK_TOPICS.has(topic)
		? "[DEBUG-BULK]"
		: topic.startsWith("placeholders.")
			? "[Placeholders-DEBUG]"
			: "[Truncation-DEBUG]";
}

// ----- Monitor extractors (context = monitor) -----

function extractFetchRecentItemsEnd(m) {
	return {
		_fetchingRecentItems: m._fetchingRecentItems,
		itemsSize: m._itemsMgr?.items?.size,
		gridChildrenCount: m._gridContainer?.children?.length ?? 0,
	};
}

function extractBulkStart(m, arrASINs, isKeepSet) {
	return {
		arrASINsSize: arrASINs?.size,
		isKeepSet,
		totalItems: m._itemsMgr?.items?.size,
		firstFewAsins: arrASINs ? Array.from(arrASINs).slice(0, 5) : undefined,
	};
}

function extractBulkPath(m, arrASINs) {
	return {
		asinsToKeepSize: arrASINs?.size,
		totalItemsBefore: m._itemsMgr?.items?.size,
		asinsToKeepSample: arrASINs ? Array.from(arrASINs).slice(0, 10) : undefined,
		asinsToKeepLast: arrASINs ? Array.from(arrASINs).slice(-5) : undefined,
	};
}

function extractBulkCleanupStart(m, arrASINs, isKeepSet) {
	return {
		totalItems: m._itemsMgr?.items?.size,
		itemsToRemove: isKeepSet ? (m._itemsMgr?.items?.size ?? 0) - (arrASINs?.size ?? 0) : (arrASINs?.size ?? 0),
		isKeepSet,
	};
}

function extractBulkCleanupDone(m, itemsToKeep, itemsToRemoveCount, visibleRemovedCount, isKeepSet) {
	return {
		itemsToKeepCount: itemsToKeep?.length ?? 0,
		itemsToRemoveCount,
		visibleRemovedCount,
		isKeepSet,
		expectedItemsAfter: itemsToKeep?.length ?? 0,
	};
}

function extractBulkAfterRebuild(m, itemsToKeep, itemsToRemoveCount, visibleRemovedCount) {
	return {
		itemsSizeNow: m._itemsMgr?.items?.size,
		itemsToKeepCount: itemsToKeep?.length ?? 0,
		itemsToRemoveCount,
		visibleRemovedCount,
	};
}

function extractBulkAtomicCount(m, visibleRemovedCount) {
	return { visibleRemovedCount };
}

function extractAutoTruncate(m, forceRun) {
	const settings = getSettings(m);
	return {
		forceRun,
		debounceScheduled: !forceRun,
		_fetchingRecentItems: m._fetchingRecentItems,
		itemsSize: m._itemsMgr?.items?.size,
		autoTruncateEnabled: m._autoTruncateEnabled,
		autoTruncateLimit: m._autoTruncateEnabled ? settings?.get("notification.monitor.autoTruncateLimit") : null,
		hadTimer: !!m._autoTruncateDebounceTimer,
	};
}

function extractRunTruncate(m, fetchingRecentItems) {
	return {
		fetchingRecentItems,
		_fetchingRecentItemsNow: m._fetchingRecentItems,
		itemsSize: m._itemsMgr?.items?.size,
	};
}

function extractItemsArray(m, itemsArray) {
	return {
		totalItems: itemsArray?.length ?? 0,
		firstFive: itemsArray?.slice(0, 5).map((o) => ({ asin: o.asin, sortTime: o.sortTime })),
		lastFive: itemsArray?.slice(-5).map((o) => ({ asin: o.asin, sortTime: o.sortTime })),
		zeroSortTime: itemsArray?.filter((o) => o.sortTime === 0).map((o) => o.asin),
	};
}

function extractKeepRemove(m, max, itemsToRemove, visibleItemsRemovedCount, asinsToKeep, fetchingRecentItems) {
	return {
		max,
		itemsToRemoveCount: itemsToRemove?.length ?? 0,
		visibleItemsRemovedCount,
		asinsToKeepSize: asinsToKeep?.size,
		asinsToRemoveSample: itemsToRemove?.slice(0, 10).map((o) => o.asin),
		asinsToKeepSample: asinsToKeep ? Array.from(asinsToKeep).slice(0, 5) : undefined,
		fetchingRecentItems,
	};
}

function extractAfterBulk(m, max) {
	return {
		itemsSizeNow: m._itemsMgr?.items?.size,
		expectedSize: max,
	};
}

function extractNoShiftGrid(m, fetchingRecentItems, visibleItemsRemovedCount) {
	return {
		fetchingRecentItems,
		calling: fetchingRecentItems
			? "resetEndPlaceholdersCount"
			: "insertEndPlaceholderTiles(" + visibleItemsRemovedCount + ")",
	};
}

function extractNoTruncationNeeded(m, max) {
	return { itemsSize: m._itemsMgr?.items?.size, max };
}

function extractFetchLastStarting(m, limitValue) {
	return {
		limitValue,
		_fetchingRecentItemsBefore: m._fetchingRecentItems,
		itemsSize: m._itemsMgr?.items?.size,
	};
}

function extractSchedulingDebounce(m, fetchingRecentItems) {
	return { fetchingRecentItemsCaptured: fetchingRecentItems };
}

// ----- NoShiftGrid extractors (context = grid) -----

function extractPlaceholdersResize(g, oldWidth) {
	return { oldWidth, newWidth: g._gridWidth };
}

function extractPlaceholdersSkipCacheClear(g) {
	return {
		fetchingRecentItems: g._monitor?._fetchingRecentItems,
		cachedWidth: g._cachedTileWidth,
	};
}

function extractPlaceholdersCacheClear(g) {
	return { previousWidth: g._cachedTileWidth };
}

function extractPlaceholdersGridWidth(g, oldWidth) {
	return {
		oldWidth,
		newWidth: g._gridWidth,
		difference: Math.abs(oldWidth - g._gridWidth),
	};
}

function extractPlaceholdersResetEndPlaceholdersCount(g) {
	return { oldCount: g._endPlaceholdersCount, newCount: 0 };
}

function extractTruncationResetEndPlaceholdersCount(g) {
	return {
		oldEndPlaceholdersCount: g._endPlaceholdersCount,
		_fetchingRecentItems: g._monitor?._fetchingRecentItems,
	};
}

function extractPlaceholdersInsertPlaceholderTiles(
	g,
	numPlaceholderTiles,
	theoricalItemsCount,
	tilesPerRow,
	tileWidth
) {
	return {
		numPlaceholderTiles,
		theoricalItemsCount,
		visibleItemsCount: g._visibleItemsCount,
		endPlaceholdersCount: g._endPlaceholdersCount,
		tilesPerRow,
		gridWidth: g._gridWidth,
		tileWidth,
	};
}

function extractTruncationInsertPlaceholderTiles(g, numPlaceholderTiles, theoricalItemsCount, tilesPerRow) {
	return {
		numPlaceholderTiles,
		theoricalItemsCount,
		visibleItemsCount: g._visibleItemsCount,
		endPlaceholdersCount: g._endPlaceholdersCount,
		tilesPerRow,
		_feedPaused: g._monitor?._feedPaused,
		_fetchingRecentItems: g._monitor?._fetchingRecentItems,
	};
}

function extractPlaceholdersInsertEndPlaceholderTiles(
	g,
	oldEndPlaceholdersCount,
	newEndPlaceholdersCount,
	tilesPerRow
) {
	return { oldEndPlaceholdersCount, newEndPlaceholdersCount, tilesPerRow };
}

function extractTruncationInsertEndPlaceholderTiles(g, count, bufferBefore, tilesPerRow) {
	return {
		count,
		oldEndPlaceholdersCount: g._endPlaceholdersCount,
		_endPlaceholdersCountBufferBefore: bufferBefore,
		_endPlaceholdersCountBufferAfter: g._endPlaceholdersCountBuffer,
		tilesPerRow,
		_feedPaused: g._monitor?._feedPaused,
	};
}

function extractTruncationInsertEndPlaceholderTilesAfterApply(g) {
	return { _endPlaceholdersCount: g._endPlaceholdersCount };
}

function extractPlaceholdersSkipTileWidth(g) {
	return {
		fetchingRecentItems: g._monitor?._fetchingRecentItems,
		cachedWidth: g._cachedTileWidth,
	};
}

function extractPlaceholdersCachedTileWidth(g, now) {
	return { cachedWidth: g._cachedTileWidth, timestamp: now };
}

function extractPlaceholdersCssGridWidth(g, cssGridWidth, now) {
	return { width: cssGridWidth, cached: true, timestamp: now };
}

function extractPlaceholdersMeasuredWidth(g, measuredWidth, now) {
	return { width: measuredWidth, cached: true, timestamp: now };
}

function extractPlaceholdersRetryTileWidth() {
	return {};
}

function extractPlaceholdersInitialTileWidth(g, initialWidth, now) {
	return { width: initialWidth, timestamp: now };
}

const EXTRACTORS = {
	"truncation.fetchRecentItemsEnd": extractFetchRecentItemsEnd,
	"bulk.start": extractBulkStart,
	"truncation.bulkPath": extractBulkPath,
	"bulk.cleanupStart": extractBulkCleanupStart,
	"bulk.cleanupDone": extractBulkCleanupDone,
	"truncation.bulkAfterRebuild": extractBulkAfterRebuild,
	"bulk.atomicCount": extractBulkAtomicCount,
	"truncation.autoTruncate": extractAutoTruncate,
	"truncation.runTruncate": extractRunTruncate,
	"truncation.itemsArray": extractItemsArray,
	"truncation.keepRemove": extractKeepRemove,
	"truncation.afterBulk": extractAfterBulk,
	"truncation.noShiftGrid": extractNoShiftGrid,
	"truncation.noTruncationNeeded": extractNoTruncationNeeded,
	"truncation.schedulingDebounce": extractSchedulingDebounce,
	"truncation.fetchLastStarting": extractFetchLastStarting,
	"placeholders.resize": extractPlaceholdersResize,
	"placeholders.skipCacheClear": extractPlaceholdersSkipCacheClear,
	"placeholders.cacheClear": extractPlaceholdersCacheClear,
	"placeholders.gridWidth": extractPlaceholdersGridWidth,
	"placeholders.resetEndPlaceholdersCount": extractPlaceholdersResetEndPlaceholdersCount,
	"truncation.resetEndPlaceholdersCount": extractTruncationResetEndPlaceholdersCount,
	"placeholders.insertPlaceholderTiles": extractPlaceholdersInsertPlaceholderTiles,
	"truncation.insertPlaceholderTiles": extractTruncationInsertPlaceholderTiles,
	"placeholders.insertEndPlaceholderTiles": extractPlaceholdersInsertEndPlaceholderTiles,
	"truncation.insertEndPlaceholderTiles": extractTruncationInsertEndPlaceholderTiles,
	"truncation.insertEndPlaceholderTilesAfterApply": extractTruncationInsertEndPlaceholderTilesAfterApply,
	"placeholders.skipTileWidth": extractPlaceholdersSkipTileWidth,
	"placeholders.cachedTileWidth": extractPlaceholdersCachedTileWidth,
	"placeholders.cssGridWidth": extractPlaceholdersCssGridWidth,
	"placeholders.measuredWidth": extractPlaceholdersMeasuredWidth,
	"placeholders.retryTileWidth": extractPlaceholdersRetryTileWidth,
	"placeholders.initialTileWidth": extractPlaceholdersInitialTileWidth,
};

/**
 * Log truncation/bulk/placeholders debug for the given topic if the relevant setting is enabled.
 * Settings are obtained from context (monitor._settings or grid._monitor._settings).
 * Payload is built by the topic's extractor; timestamp is added if missing.
 *
 * @param {string} topic - e.g. "truncation.autoTruncate", "bulk.start", "placeholders.resize"
 * @param {Object} context - Monitor or NoShiftGrid instance
 * @param {...*} args - Topic-specific args passed to the extractor
 */
export function debugTruncation(topic, context, ...args) {
	const settings = getSettings(context);
	if (!isEnabled(settings, topic)) return;

	const fn = EXTRACTORS[topic];
	const raw = fn ? fn(context, ...args) : { args };
	const payload =
		raw != null && typeof raw === "object"
			? { ...raw, ...(raw.timestamp == null && { timestamp: new Date().toISOString() }) }
			: { value: raw, timestamp: new Date().toISOString() };
	const tag = getTag(topic);
	const category = tag.replace(/[[\]]/g, "").trim();
	if (typeof window !== "undefined" && window.__VH_MONITOR_DEBUG_EMIT__) {
		window.__VH_MONITOR_DEBUG_EMIT__(settingKeyForTopic(topic), category, topic, payload, settings);
		return;
	}
	console.log(tag, topic, payload);
}
