/**
 * Pure helpers for walking notification tiles and collecting visible ASINs.
 * Used by FullGridLayout and unit-tested without NotificationMonitor.
 */
import { VINE_GRID } from "/scripts/core/amazon/selectors.js";

/**
 * Whether a tile element counts toward "visible ASIN" collection.
 * @param {Element | null | undefined} el
 * @returns {boolean}
 */
function isTileEligibleForVisibleAsin(el) {
	if (!el || !el.classList) {
		return false;
	}
	if (el.classList.contains("vh-placeholder-tile")) {
		return false;
	}
	if (el.classList.contains("vh-nm-temp-hidden")) {
		return false;
	}
	if (el.dataset && el.dataset.display === "none") {
		return false;
	}
	return true;
}

/**
 * Full-grid path: tiles currently in the DOM grid.
 * @param {HTMLElement} gridContainer
 * @returns {Set<string>}
 */
function collectVisibleAsinsFromGrid(gridContainer) {
	const asins = new Set();
	const visibleItems = gridContainer.querySelectorAll(`${VINE_GRID.TILE}:not([style*='display: none'])`);
	visibleItems.forEach((item) => {
		const asin = item.dataset?.asin;
		if (asin) {
			asins.add(asin);
		}
	});
	return asins;
}

/**
 * Virtual path: walk ItemsMgr (tiles may be pooled off-grid).
 * @param {{ items: Map<string, { element?: Element }>, getItemDOMElement: (asin: string) => Element | null }} itemsMgr
 * @returns {Set<string>}
 */
function collectVisibleAsinsFromItemsMgr(itemsMgr) {
	const asins = new Set();
	itemsMgr.items.forEach((item, asin) => {
		const el = item.element || itemsMgr.getItemDOMElement(asin);
		if (!isTileEligibleForVisibleAsin(el)) {
			return;
		}
		asins.add(asin);
	});
	return asins;
}

/**
 * @param {HTMLElement} gridContainer
 * @param {(el: HTMLElement) => void} cb
 */
function forEachTileFromGrid(gridContainer, cb) {
	const tiles = gridContainer.querySelectorAll(".vvp-item-tile");
	for (let i = 0; i < tiles.length; i++) {
		cb(tiles[i]);
	}
}

/**
 * @param {{ items: Map<string, { element?: Element }>, getItemDOMElement: (asin: string) => Element | null }} itemsMgr
 * @param {(el: HTMLElement) => void} cb
 */
function forEachTileFromItemsMgr(itemsMgr, cb) {
	itemsMgr.items.forEach((item, asin) => {
		const el = item.element || itemsMgr.getItemDOMElement(asin);
		if (el && el.classList.contains("vvp-item-tile")) {
			cb(el);
		}
	});
}

/**
 * @param {{ items: Map<string, { element?: Element }>, getItemDOMElement: (asin: string) => Element | null }} itemsMgr
 * @returns {Element[]}
 */
function listTilesForUnpauseFromItemsMgr(itemsMgr) {
	return Array.from(itemsMgr.items.entries())
		.map(([asin, item]) => item.element || itemsMgr.getItemDOMElement(asin))
		.filter((el) => el && el.classList.contains("vvp-item-tile"));
}

/**
 * @param {HTMLElement} gridContainer
 * @returns {NodeListOf<Element>}
 */
function getTilesForUnpauseFromGrid(gridContainer) {
	return gridContainer.querySelectorAll(".vvp-item-tile");
}

export {
	isTileEligibleForVisibleAsin,
	collectVisibleAsinsFromGrid,
	collectVisibleAsinsFromItemsMgr,
	forEachTileFromGrid,
	forEachTileFromItemsMgr,
	listTilesForUnpauseFromItemsMgr,
	getTilesForUnpauseFromGrid,
};
