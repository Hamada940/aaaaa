/**
 * @fileoverview Pure truncation logic: always remove oldest items (by timestamp), keep newest N.
 * Sort type affects display only; truncation is always by age. No DOM or monitor dependencies.
 */

/**
 * Returns sort key (ms) for an item. All items are expected to have timestamp set (e.g. in addTileInGrid).
 * Invalid/missing timestamp is treated as 0 (oldest).
 * @param {{ data: { timestamp?: number|null } }} item - Item-like object with data.timestamp
 * @returns {number}
 */
export function getSortTime(item) {
	const t = item?.data?.timestamp;
	return t != null && typeof t === "number" && !Number.isNaN(t) ? t : 0;
}

/**
 * Builds an array of { asin, sortTime } from map entries, sorted oldest first (smallest timestamp).
 * Truncation always removes oldest; display sort type is irrelevant.
 * @param {Iterable<[string, { data: Object }]>} entries - Map.entries() from items map (asin, item)
 * @returns {{ asin: string, sortTime: number }[]}
 */
export function buildTruncationSortArray(entries) {
	const arr = [];
	for (const [asin, item] of entries) {
		if (!item) continue;
		arr.push({
			asin,
			sortTime: getSortTime(item),
		});
	}
	// Oldest first → remove from start, keep last N (newest)
	arr.sort((a, b) => a.sortTime - b.sortTime);
	return arr;
}

/**
 * Given a sorted array (worst at start, best at end) and max count to keep,
 * returns sets of ASINs to keep and items (for removal list).
 * @param {{ asin: string }[]} sortedArray - From buildTruncationSortArray (already sorted)
 * @param {number} max - Maximum number of items to keep
 * @returns {{ asinsToKeep: Set<string>, itemsToRemove: { asin: string }[] }}
 */
export function computeKeepRemove(sortedArray, max) {
	if (max <= 0 || sortedArray.length <= max) {
		return {
			asinsToKeep: new Set(sortedArray.map((o) => o.asin)),
			itemsToRemove: [],
		};
	}
	const itemsToRemoveCount = sortedArray.length - max;
	const itemsToRemove = sortedArray.slice(0, itemsToRemoveCount);
	const itemsToKeep = sortedArray.slice(itemsToRemoveCount);
	const asinsToKeep = new Set(itemsToKeep.map((o) => o.asin));
	return { asinsToKeep, itemsToRemove };
}
