const MAX_INTEGRITY_COMMENT_LENGTH = 256;

function truncateIntegrityComment(comment) {
	const value = String(comment ?? "").trim() || "DOM integrity failure";
	return value.length > MAX_INTEGRITY_COMMENT_LENGTH ? value.slice(0, MAX_INTEGRITY_COMMENT_LENGTH) : value;
}

async function buildIntegrityIncidentReportPayload({ manifest, i18n, settings, env, cryptoKeys, comment }) {
	const content = {
		api_version: 5,
		app_version: manifest.version,
		action: "report_user",
		country: i18n.getCountryCode(),
		uuid: settings.get("general.uuid", false),
		cid: await env.getCID(),
		asin: truncateIntegrityComment(comment),
	};
	content.s = await cryptoKeys.signData(content);
	content.pk = await cryptoKeys.getExportedPublicKey();
	return content;
}

async function sendIntegrityIncidentReport({ manifest, i18n, settings, env, cryptoKeys, comment, fetchImpl = fetch }) {
	const content = await buildIntegrityIncidentReportPayload({
		manifest,
		i18n,
		settings,
		env,
		cryptoKeys,
		comment,
	});
	return fetchImpl(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(content),
	});
}

export {
	MAX_INTEGRITY_COMMENT_LENGTH,
	truncateIntegrityComment,
	buildIntegrityIncidentReportPayload,
	sendIntegrityIncidentReport,
};
