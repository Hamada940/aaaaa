/**
 * Visibility-based image lazy loader.
 * Keeps image loading policy isolated from tile rendering code.
 */
class LazyImageLoader {
	#observer = null;
	#IntersectionObserverImpl = null;

	constructor({ IntersectionObserverImpl = globalThis?.IntersectionObserver ?? null } = {}) {
		this.#IntersectionObserverImpl = IntersectionObserverImpl;
	}

	#ensureObserver() {
		if (this.#observer || !this.#IntersectionObserverImpl) {
			return this.#observer;
		}
		this.#observer = new this.#IntersectionObserverImpl(
			(entries) => {
				for (const entry of entries) {
					if (!entry?.isIntersecting) {
						continue;
					}
					const img = entry.target;
					this.loadImage(img);
					this.#observer?.unobserve(img);
				}
			},
			{
				root: null,
				// Small prefetch margin to avoid visible pop-in while still being conservative.
				rootMargin: "120px 0px",
				threshold: 0.01,
			}
		);
		return this.#observer;
	}

	prepareImage(imgElement, src) {
		if (!imgElement || !src) {
			return;
		}
		if (!imgElement.dataset.vhSrc) {
			imgElement.dataset.vhSrc = src;
		}
		imgElement.loading = "lazy";
		this.observeImage(imgElement);
	}

	observeImage(imgElement) {
		if (!imgElement || !imgElement.dataset?.vhSrc) {
			return;
		}
		const observer = this.#ensureObserver();
		if (!observer) {
			// Fallback for environments without IntersectionObserver support.
			this.loadImage(imgElement);
			return;
		}
		observer.observe(imgElement);
	}

	observeWithin(container) {
		if (!container) {
			return;
		}
		const lazyImages = container.querySelectorAll("img[data-vh-src]");
		for (const img of lazyImages) {
			this.observeImage(img);
		}
	}

	/**
	 * Normalize images for lazy loading even when templates were cached with src attributes.
	 * @param {ParentNode} container
	 */
	prepareWithin(container) {
		if (!container) {
			return;
		}
		const images = container.querySelectorAll("img");
		for (const img of images) {
			if (!img.dataset?.vhSrc) {
				const currentSrc = img.getAttribute("src");
				if (currentSrc) {
					img.dataset.vhSrc = currentSrc;
					img.removeAttribute("src");
				}
			}
			if (img.dataset?.vhSrc) {
				img.loading = "lazy";
			}
		}
	}

	loadImage(imgElement) {
		if (!imgElement) {
			return;
		}
		const src = imgElement.dataset?.vhSrc;
		if (!src) {
			return;
		}
		if (imgElement.getAttribute("src") !== src) {
			imgElement.setAttribute("src", src);
		}
		delete imgElement.dataset.vhSrc;
	}

	destroy() {
		if (this.#observer) {
			this.#observer.disconnect();
			this.#observer = null;
		}
	}
}

const lazyImageLoader = new LazyImageLoader();

export { LazyImageLoader, lazyImageLoader };
