import { PinnedListMgr } from "/scripts/core/services/PinnedListMgr.js";
import { Item } from "/scripts/core/models/Item.js";

class PinMgr {
	#getItemDOMElementCallback = null;

	constructor() {
		this._pinnedListMgr = new PinnedListMgr();

		// Register this PinMgr as an observer for broadcast events
		this._pinnedListMgr.addBroadcastObserver({
			onPinnedBroadcast: (item) => {
				// Handle pin events from other tabs - only update UI, don't save/broadcast
				this._pinnedListMgr.addItem(item, false, false);
				this.#updatePinIcon(item.data.asin, true);
			},
			onUnpinnedBroadcast: (asin) => {
				// Handle unpin events from other tabs - only update UI, don't save/broadcast
				this._pinnedListMgr.removeItem(asin, false, false);
				this.#updatePinIcon(asin, false);
			},
		});
	}

	setGetItemDOMElementCallback(callback) {
		this.#getItemDOMElementCallback = callback;
	}

	// Check if an item is already pinned
	async checkIfPinned(asin) {
		await this._pinnedListMgr.getList(); // This will wait for the list to be loaded
		return this._pinnedListMgr.isPinned(asin);
	}

	async unpinItem(asin) {
		// Unpin the item
		await this._pinnedListMgr.removeItem(asin);

		// Update the icon to reflect unpinned state
		this.#updatePinIcon(asin, false);
	}

	async pinItem(item) {
		const pinItem = this.#normalizePinItem(item);
		// Pin the item
		await this._pinnedListMgr.addItem(pinItem);

		// Update the icon to reflect pinned state
		this.#updatePinIcon(pinItem.data.asin, true);
	}

	#normalizePinItem(item) {
		if (item instanceof Item) return item;
		if (!item || typeof item !== "object" || !item.data || typeof item.data !== "object") {
			throw new Error("Invalid item payload");
		}
		return new Item(item.data);
	}

	// Update the pin icon for an item
	#updatePinIcon(asin, isPinned) {
		const notif = this.#getItemDOMElementCallback(asin);
		if (notif) {
			const pinIcon = notif.querySelector("#vh-pin-link-" + asin + ">div");
			if (pinIcon) {
				if (isPinned) {
					// Item is pinned - show unpin icon (red)
					pinIcon.classList.remove("vh-icon-pin");
					pinIcon.classList.add("vh-icon-unpin");
					pinIcon.title = "Unpin this item";
				} else {
					// Item is unpinned - show pin icon (gray)
					pinIcon.classList.remove("vh-icon-unpin");
					pinIcon.classList.add("vh-icon-pin");
					pinIcon.title = "Pin this item";
				}
			}
		}
	}
}

export { PinMgr };
