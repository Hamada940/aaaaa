/**
 * Grid layout strategy for the notification monitor.
 *
 * Historically this module exposed two strategies — `FullGridLayout` and
 * `VirtualGridLayout` — and flipped between them based on the
 * `notification.monitor.virtualGrid` setting. The virtualized path has been
 * removed (see [VirtualizedGridViewport removal phase](../../../docs/)), so
 * only `FullGridLayout` remains. `syncGridLayoutFromSettings` is kept as a
 * thin entry point to preserve call sites in `MonitorCore` and friends, even
 * though the choice it expresses is now trivial.
 */
import {
	collectVisibleAsinsFromGrid,
	forEachTileFromGrid,
	getTilesForUnpauseFromGrid,
} from "/scripts/notifications-monitor/services/MonitorTileQueries.js";

class FullGridLayout {
	/** @param {object} monitor */
	constructor(monitor) {
		this._monitor = monitor;
	}

	isVirtual() {
		return false;
	}

	/**
	 * @param {Array<{ asin: string }>} sortedItems
	 */
	applySort(sortedItems) {
		const m = this._monitor;
		if (sortedItems.length === 0) {
			m._clearGridContainer();
			return;
		}
		const fragment = document.createDocumentFragment();
		sortedItems.forEach((sortedItem) => {
			const element = m._itemsMgr.getItemDOMElement(sortedItem.asin);
			if (element && element.parentNode === m._gridContainer) {
				fragment.appendChild(element);
			}
		});
		m._clearGridContainer();
		m._gridContainer.appendChild(fragment);
	}

	/**
	 * @param {(el: HTMLElement) => void} cb
	 */
	forEachTile(cb) {
		forEachTileFromGrid(this._monitor._gridContainer, cb);
	}

	/**
	 * @returns {Set<string>}
	 */
	collectVisibleAsins() {
		return collectVisibleAsinsFromGrid(this._monitor._gridContainer);
	}

	/**
	 * @returns {NodeListOf<Element>|Array<Element|null>}
	 */
	getTilesForUnpause() {
		return getTilesForUnpauseFromGrid(this._monitor._gridContainer);
	}

	/** @returns {boolean} */
	shouldSkipTileIntegrity() {
		return false;
	}

	destroy() {}
}

/**
 * Ensures `monitor._gridLayout` is wired to a `FullGridLayout` and triggers
 * a relayout if the monitor already holds items. Retained as a named export
 * purely so existing call sites (`MonitorCore`, settings-change handlers)
 * keep compiling after the virtual-grid removal.
 *
 * @param {object} monitor
 * @param {() => void} refreshLayout
 */
function syncGridLayoutFromSettings(monitor, refreshLayout) {
	monitor._gridLayout = new FullGridLayout(monitor);
	if (monitor._itemsMgr && monitor._itemsMgr.items && monitor._itemsMgr.items.size > 0) {
		refreshLayout();
	}
}

export { FullGridLayout, syncGridLayoutFromSettings };
