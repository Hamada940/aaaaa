/**
 * Item-type placement after an item is found (sort / bump / tile counter hooks).
 * Extracted for unit tests; NotificationMonitor supplies callbacks for side effects.
 */

/** @see NotificationMonitor TYPE_ZEROETV */
const TYPE_ZEROETV = 2;
/** @see NotificationMonitor TYPE_HIGHLIGHT */
const TYPE_HIGHLIGHT = 3;
const TYPE_DATE_ASC = "date_asc";
const TYPE_DATE_DESC = "date_desc";
const TYPE_PRICE_DESC = "price_desc";
const TYPE_PRICE_ASC = "price_asc";

/**
 * @param {object} ctx
 * @param {number} ctx.itemType
 * @param {boolean} ctx.fetchingRecentItems
 * @param {() => string} ctx.getCurrentSortType
 * @param {(key: string) => *} ctx.settingsGet
 * @param {Element} ctx.notif
 * @param {object} api
 * @param {() => void} api.sortItems
 * @param {(el: Element) => void} api.moveNotifToTop
 * @param {boolean | null | undefined} api.noShiftGrid
 * @param {(opts?: object) => void} api.recountVisibleTiles
 */
function runAfterItemFoundPlacement(ctx, api) {
	const { itemType, fetchingRecentItems, getCurrentSortType, settingsGet, notif } = ctx;
	if (fetchingRecentItems) {
		return;
	}
	const sort = getCurrentSortType();

	if (itemType === TYPE_ZEROETV) {
		if (sort === TYPE_PRICE_DESC || sort === TYPE_PRICE_ASC) {
			api.sortItems();
		} else if (sort === TYPE_DATE_DESC && settingsGet("notification.monitor.bump0ETV")) {
			api.moveNotifToTop(notif);
			if (api.noShiftGrid && sort === TYPE_DATE_DESC) {
				api.recountVisibleTiles(0, { source: "zeroETV-add" });
			}
		}
		return;
	}

	if (itemType === TYPE_HIGHLIGHT && sort !== TYPE_DATE_ASC) {
		if (api.noShiftGrid && sort === TYPE_DATE_DESC) {
			api.recountVisibleTiles(0, { source: "highlight-add" });
		}
		return;
	}

	if (api.noShiftGrid && sort === TYPE_DATE_DESC) {
		api.recountVisibleTiles(0, { source: "regular-add" });
	}
}

export {
	runAfterItemFoundPlacement,
	TYPE_ZEROETV,
	TYPE_HIGHLIGHT,
	TYPE_DATE_ASC,
	TYPE_DATE_DESC,
	TYPE_PRICE_DESC,
	TYPE_PRICE_ASC,
};
