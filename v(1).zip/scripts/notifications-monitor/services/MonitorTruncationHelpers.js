/**
 * Pure helpers for auto-truncate decisions (unit-tested without NotificationMonitor).
 */

/**
 * @param {number} itemMapSize
 * @param {number} maxLimit
 * @returns {boolean}
 */
function itemMapExceedsTruncateLimit(itemMapSize, maxLimit) {
	return itemMapSize > maxLimit;
}

/**
 * Count how many removals correspond to currently visible tile DOM (for placeholder accounting).
 * @param {Array<{ asin: string }>} itemsToRemove
 * @param {(asin: string) => Element | null | undefined} getItemDOMElement
 * @param {(element: Element | null | undefined) => boolean} isElementVisible
 * @returns {number}
 */
function countVisibleRemovalsAmong(itemsToRemove, getItemDOMElement, isElementVisible) {
	let n = 0;
	for (const o of itemsToRemove) {
		const element = getItemDOMElement(o.asin);
		if (isElementVisible(element)) {
			n++;
		}
	}
	return n;
}

export { itemMapExceedsTruncateLimit, countVisibleRemovalsAmong };
