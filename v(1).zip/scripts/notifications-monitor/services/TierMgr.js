import { Internationalization } from "/scripts/core/services/Internationalization.js";

class TierMgr {
	#env = null;
	#i18nMgr = null;
	#goldTier = true;
	#etvLimit = null;

	constructor(env) {
		this.#env = env;
		this.#i18nMgr = new Internationalization();
	}

	readTierInfo() {
		this.#goldTier = this.#env.getTierLevel("gold") === "gold";
		this.#etvLimit = this.#env.getSilverTierLimit();
	}

	isGold() {
		return this.#goldTier;
	}

	getTier() {
		return this.#goldTier ? "Gold" : "Silver";
	}

	getSilverTierETVLimit() {
		return this.#etvLimit;
	}

	getLimit() {
		if (this.#goldTier) {
			return "∞";
		}
		// Format the ETV limit as local currency
		return new Intl.NumberFormat(this.#i18nMgr.getLocale(), {
			style: "currency",
			currency: this.#i18nMgr.getCurrency(),
		}).format(this.#etvLimit);
	}
}

export { TierMgr };
