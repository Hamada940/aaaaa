/**
 * @fileoverview Resolves highlight sound/volume from visible tiles for unpause.
 * Pure helper: given tile elements and a group map, returns the first visible
 * highlight tile whose group has a sound set (so "None" does not override).
 */

/**
 * Returns the highlight sound and volume from the highest-priority visible highlight
 * group that has a sound. Group priority is by order (lower order = higher priority).
 * Skips placeholders, hidden tiles, and non-highlight tiles. Among all visible
 * highlight tiles whose group has a sound, picks the group with the smallest order.
 * @param {Iterable<Element>} tiles - Tile elements (e.g. NodeList or array)
 * @param {Map<string, Object>} groupMap - Map of group id -> group (must have order, monitorSound, monitorVolume)
 * @returns {{ sound: string|null, volume: number|undefined }}
 */
export function getFirstHighlightSoundFromTiles(tiles, groupMap) {
	let best = null; // { order, sound, volume }

	for (const node of tiles) {
		if (node.classList && node.classList.contains("vh-placeholder-tile")) continue;
		if (node.dataset && node.dataset.display === "none") continue;
		if (node.dataset && node.dataset.typeHighlight != "1") continue;

		const gid = node.dataset && node.dataset.highlightGroupId;
		if (!gid) continue;

		const group = groupMap.get(gid);
		if (!group || group.monitorSound == null || group.monitorSound === undefined || group.monitorSound === "0") {
			continue;
		}

		const order = typeof group.order === "number" ? group.order : Infinity;
		if (best !== null && order >= best.order) continue;

		const volume =
			typeof group.monitorVolume === "number" && group.monitorVolume >= 0 && group.monitorVolume <= 1
				? group.monitorVolume
				: undefined;
		best = { order, sound: group.monitorSound, volume };
	}

	return best === null ? { sound: null, volume: undefined } : { sound: best.sound, volume: best.volume };
}
