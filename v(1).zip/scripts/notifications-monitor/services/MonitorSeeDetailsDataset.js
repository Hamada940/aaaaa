/**
 * Keeps See Details `<input>` data-* in sync with Item data and any extra attributes
 * captured from Amazon's tile (forwarded as `item.data.see_details_button_dataset`).
 */
import {
	collectExtraSeeDetailsDatasetFromInput,
	SEE_DETAILS_DATASET_CANONICAL_KEYS,
} from "/scripts/core/utils/SeeDetailsDataset.js";

/**
 * @param {HTMLElement} tileRoot
 * @param {import("/scripts/core/models/Item.js").Item} item
 * @param {import("/scripts/core/services/Environment.js").Environment | null} [env] - Required when `item` has no `_originalRecommendationId` (builds recommendationId via `getRecommendationString`).
 */
function syncSeeDetailsInputFromItem(tileRoot, item, env = null) {
	if (!tileRoot || !item?.data?.asin) {
		return;
	}
	const asin = item.data.asin;
	const input =
		tileRoot.querySelector(`input[data-asin='${asin}'].a-button-input`) ||
		tileRoot.querySelector(".vvp-details-btn input[data-asin], .vh-details-btn input[data-asin]") ||
		tileRoot.querySelector(`input[data-asin='${asin}']`);
	if (!input) {
		return;
	}

	const extras = item.data.see_details_button_dataset;
	if (extras && typeof extras === "object") {
		for (const [k, v] of Object.entries(extras)) {
			if (SEE_DETAILS_DATASET_CANONICAL_KEYS.has(k)) {
				continue;
			}
			if (v === undefined || v === null || v === "") {
				continue;
			}
			input.dataset[k] = String(v);
		}
	}

	const recommendationId = item._originalRecommendationId || (env ? item.getRecommendationString(env) : "") || "";
	const recommendationType = item._originalRecommendationType || item.getRecommendationType() || "";
	const isParentStr = item.data.is_parent_asin ? "true" : "false";
	const isPreStr = item.data.is_pre_release ? "true" : "false";
	const queueStr = item.data.queue || "";

	input.dataset.asin = asin;
	input.dataset.queue = queueStr;
	input.dataset.isParentAsin = isParentStr;
	input.dataset.isPreRelease = isPreStr;
	if (recommendationId) {
		input.dataset.recommendationId = recommendationId;
	}
	if (recommendationType) {
		input.dataset.recommendationType = recommendationType;
	}
	if (item.data.enrollment_guid) {
		input.dataset.enrollmentGuid = item.data.enrollment_guid;
	}

	const buyNow = tileRoot.querySelector(".vh-buy-now-btn");
	if (buyNow) {
		buyNow.dataset.asin = asin;
		buyNow.dataset.queue = queueStr;
		buyNow.dataset.isParentAsin = isParentStr;
		if (recommendationId) {
			buyNow.dataset.recommendationId = recommendationId;
		}
	}
}

export { syncSeeDetailsInputFromItem, collectExtraSeeDetailsDatasetFromInput, SEE_DETAILS_DATASET_CANONICAL_KEYS };
