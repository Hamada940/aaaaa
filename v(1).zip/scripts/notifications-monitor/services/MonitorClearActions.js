/**
 * Routes finalize step for undoable clear (visible vs unavailable, optional scroll preservation).
 * Callbacks keep NotificationMonitor side effects explicit and testable.
 */

/**
 * @param {object} opts
 * @param {Set<string>} opts.asins
 * @param {"visible"|"unavailable"} opts.clearKind
 * @param {boolean} opts.preserveScroll
 * @param {(asins: Set<string>) => void} opts.clearVisibleItems
 * @param {(fn: () => void) => void} opts.preserveScrollPosition
 * @param {(asins: Set<string>) => void} opts.clearUnavailableItems
 */
function runPendingClearFinalization({
	asins,
	clearKind,
	preserveScroll,
	clearVisibleItems,
	preserveScrollPosition,
	clearUnavailableItems,
}) {
	if (!asins || asins.size === 0) {
		return;
	}
	if (clearKind === "visible") {
		if (preserveScroll) {
			preserveScrollPosition(() => clearVisibleItems(asins));
		} else {
			clearVisibleItems(asins);
		}
	} else if (clearKind === "unavailable") {
		clearUnavailableItems(asins);
	}
}

export { runPendingClearFinalization };
