/**
 * Event targeting for grid icon clicks (closest match or link-wrapped icon).
 */

/**
 * @param {Event} e
 * @param {string} iconSelector
 * @param {(event: Event, icon: Element) => void} handler
 * @returns {boolean} Whether a match was handled
 */
function eventClosestIconOrLinkChild(e, iconSelector, handler) {
	const icon = e.target.closest(iconSelector);
	if (icon) {
		e.preventDefault();
		handler(e, icon);
		return true;
	}

	const parentLink = e.target.closest("a");
	if (parentLink && parentLink.querySelector(iconSelector) && !e.target.closest(iconSelector)) {
		e.preventDefault();
		const containedIcon = parentLink.querySelector(iconSelector);
		if (containedIcon) {
			handler(e, containedIcon);
			return true;
		}
	}

	return false;
}

export { eventClosestIconOrLinkChild };
