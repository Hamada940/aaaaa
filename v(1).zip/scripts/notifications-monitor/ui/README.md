# Notification Monitor UI Components

UI elements of the notification monitor are implemented as **components** to prepare for an eventual migration to React. **Each component owns its HTML**: it loads its own template and injects it into its container.

## Component ownership

- **headerComposer** only renders the **shell** (main header with mount-point divs) and calls each component’s `mount(container, tpl)`. It does not load or inject component HTML.
- **Each component** loads its own template, renders it (with any vars it needs), and appends the result into the `container` it receives. Parents that use placeholders (StatusCard, FilterSection) call their children’s `renderToMarkup(tpl)` and set vars before rendering their own template.

## Component templates

Each component has a dedicated **template file** in `scripts/ui/templates/notification_monitor/` and is responsible for loading and rendering it:

| Template                               | Component                  | Vars / composition                                                                |
| -------------------------------------- | -------------------------- | --------------------------------------------------------------------------------- |
| `nm_fixed_toolbar.html`                | FixedToolbar               | —                                                                                 |
| `nm_connection_details_button.html`    | ConnectionDetailsButton    | —                                                                                 |
| `nm_search_input.html`                 | SearchInput                | —                                                                                 |
| `nm_clear_buttons.html`                | ClearButtons               | —                                                                                 |
| `nm_fetch_buttons.html`                | FetchButtons               | `fetchLimit`, `{{if TIER3}}` (set by composer on `tpl` before mount)              |
| `nm_pause_button.html`                 | PauseButton                | —                                                                                 |
| `nm_sort_select.html`                  | SortSelect                 | —                                                                                 |
| `nm_filter_selects.html`               | FilterSelects              | —                                                                                 |
| `nm_notification_active_checkbox.html` | NotificationActiveCheckbox | —                                                                                 |
| `nm_auto_truncate_controls.html`       | AutoTruncateControls       | —                                                                                 |
| `nm_focus_mode_toggle.html`            | FocusModeToggle            | —                                                                                 |
| `nm_filter_section.html`               | FilterSection              | Composes SearchInput, FilterSelects, SortSelect via `renderToMarkup`              |
| `nm_dates_card.html`                   | DatesCard                  | —                                                                                 |
| `nm_status_card.html`                  | StatusCard                 | Composes ConnectionDetailsButton, NotificationActiveCheckbox via `renderToMarkup` |

The main header `notification_monitor_header.html` is a **shell only**: layout + `{{$MONITOR_TYPE}}` + mount-point divs (`#nm-mount-dates-card`, `#nm-mount-status-card`, etc.). No component HTML is in the shell.

## Component contract

Each component exports:

1. **renderToMarkup(tpl)** (async) – Returns the component’s HTML string. Used by parent components that embed this one (e.g. StatusCard embeds ConnectionDetailsButton and NotificationActiveCheckbox). Composer does not call this; only parent components do.
2. **mount(container, tpl)** (async) – If `container` is given, loads the component’s template, renders it (with any vars on `tpl`), parses to DOM, and appends to `container`. Called by **headerComposer** after the shell is rendered.
3. **attach(api, eventHandlers, debugTrackListener, debugUntrackListener)** – Binds to DOM (by id/selector), attaches event listeners, registers them in `eventHandlers`. Called by **attachUIHandlers** (via `attachAll` / `mountAll`) after the header is in the document.

Components do **not** create the DOM for the monitor header; the HTML is still from `notification_monitor_header.html`. Each component owns a **logical UI element** (e.g. fixed toolbar, pause button, search input) and attaches behavior to the existing nodes.

## List of components

| Component                  | DOM / IDs                                                      | Responsibility                                       |
| -------------------------- | -------------------------------------------------------------- | ---------------------------------------------------- |
| FixedToolbar               | `#fixed-toolbar`, `#scrollToTop-fixed`, `#pauseFeed-fixed`     | Scroll visibility, scroll-to-top, fixed pause button |
| ConnectionDetailsButton    | `#connectionDetails`                                           | Open connection details modal                        |
| SearchInput                | `#search-input`                                                | Search input + debounce, filter count update         |
| ClearButtons               | `#clear-monitor`, `#clear-unavailable`                         | Clear all / clear unavailable + undo                 |
| FetchButtons               | `#fetch-last`, `#fetch-last-12hrs`                             | Fetch last N, long-press menu, fetch 12hrs           |
| PauseButton                | `#pauseFeed`                                                   | Pause/resume feed                                    |
| SortSelect                 | `select[name='sort-queue']`                                    | Sort order change                                    |
| FilterSelects              | `select[name='filter-type']`, `select[name='filter-queue']`    | Filter type and queue + filter count                 |
| NotificationActiveCheckbox | `#notification.active`                                         | Enable monitor and assisted load                     |
| AutoTruncateControls       | `#auto-truncate`, `#auto-truncate-limit`                       | Auto truncate toggle + limit                         |
| FocusModeToggle            | `#vh-nm-focus-mode-toggle`                                     | Focus mode                                           |
| FilterSection              | `#vh-nm-filters`, `.vh-nm-filters-header`, `#vh-nm-filter-pin` | Pin, expand/collapse, click-outside                  |

## Usage

1. **Header** – The monitor calls `renderMonitorHeader(tpl, { MONITOR_TYPE, fetchLimit, isTier3 })`, which renders the shell and then calls each component’s `mount(container, tpl)` so components inject their own HTML into their mount points.
2. **Behavior** – The monitor calls `attachUIHandlers(api, eventHandlers, ...)`, which calls `attachAll` (exported as `mountAll`) so each component’s `attach(api, eventHandlers, ...)` runs and registers listeners. Cleanup is done by the monitor’s destroy() using `eventHandlers.buttons`, `eventHandlers.window`, and `eventHandlers.documentClick`.

## React migration

When migrating to React:

1. Replace the static header HTML with a React root.
2. Implement each component as a React component that receives **props** (data) and **callbacks** (onPauseClick, onSortChange, etc.).
3. The same `api` surface becomes React props/callbacks; component boundaries and responsibilities stay the same.
