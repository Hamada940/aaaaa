/**
 * Renders the notification monitor header shell and asks each component to inject its own HTML.
 * Components own their HTML; the composer only provides the shell and mount points.
 *
 * @param {import("/scripts/core/utils/Template.js").Template} tpl - Template instance (e.g. monitor._tpl)
 * @param {{ MONITOR_TYPE: string, fetchLimit: number, isTier3: boolean }} vars - Header variables
 * @returns {Promise<Element>} The header root DOM element
 */
import { mount as mountDatesCard } from "./components/DatesCard.js";
import { mount as mountStatusCard } from "./components/StatusCard.js";
import { mount as mountFocusModeToggle } from "./components/FocusModeToggle.js";
import { mount as mountFilterSection } from "./components/FilterSection.js";
import { mount as mountClearButtons } from "./components/ClearButtons.js";
import { mount as mountFetchButtons } from "./components/FetchButtons.js";
import { mount as mountPauseButton } from "./components/PauseButton.js";
import { mount as mountAutoTruncateControls } from "./components/AutoTruncateControls.js";
import { mount as mountFixedToolbar } from "./components/FixedToolbar.js";

export async function renderMonitorHeader(tpl, vars) {
	const { MONITOR_TYPE, fetchLimit, isTier3, tld } = vars;

	tpl.setVar("MONITOR_TYPE", MONITOR_TYPE);
	tpl.setVar("fetchLimit", fetchLimit);
	tpl.setIf("TIER3", isTier3);
	// Hide ALL (new AI) queue for .com TLD only
	if (tld === "com") {
		tpl.setIf("HIDE_ALL_QUEUE", true);
	}

	// Shell only – mount points, no component HTML
	const mainHtml = await tpl.loadFile("scripts/ui/templates/notification_monitor_header.html");
	const header = tpl.render(mainHtml, true);

	// Each component injects its own HTML into its mount point
	const mountPoints = {
		"nm-mount-dates-card": mountDatesCard,
		"nm-mount-status-card": mountStatusCard,
		"nm-mount-focus-mode-toggle": mountFocusModeToggle,
		"nm-mount-filter-section": mountFilterSection,
		"nm-mount-clear-buttons": mountClearButtons,
		"nm-mount-fetch-buttons": mountFetchButtons,
		"nm-mount-pause-button": mountPauseButton,
		"nm-mount-auto-truncate-controls": mountAutoTruncateControls,
		"nm-mount-fixed-toolbar": mountFixedToolbar,
	};

	for (const [id, mountFn] of Object.entries(mountPoints)) {
		const container = header.querySelector(`#${id}`);
		if (container) await mountFn(container, tpl);
	}

	return header;
}
