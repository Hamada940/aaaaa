/**
 * Notification monitor UI – attach behavior to components (HTML is owned by components, injected by headerComposer).
 */
import { attach as attachFixedToolbar } from "./components/FixedToolbar.js";
import { attach as attachConnectionDetailsButton } from "./components/ConnectionDetailsButton.js";
import { attach as attachSearchInput } from "./components/SearchInput.js";
import { attach as attachClearButtons } from "./components/ClearButtons.js";
import { attach as attachFetchButtons } from "./components/FetchButtons.js";
import { attach as attachPauseButton } from "./components/PauseButton.js";
import { attach as attachSortSelect } from "./components/SortSelect.js";
import { attach as attachFilterSelects } from "./components/FilterSelects.js";
import { attach as attachNotificationActiveCheckbox } from "./components/NotificationActiveCheckbox.js";
import { attach as attachAutoTruncateControls } from "./components/AutoTruncateControls.js";
import { attach as attachFocusModeToggle } from "./components/FocusModeToggle.js";
import { attach as attachFilterSection } from "./components/FilterSection.js";
import { attach as attachDatesCard } from "./components/DatesCard.js";
import { attach as attachStatusCard } from "./components/StatusCard.js";

const ATTACH_FNS = [
	attachFixedToolbar,
	attachConnectionDetailsButton,
	attachSearchInput,
	attachClearButtons,
	attachFetchButtons,
	attachPauseButton,
	attachSortSelect,
	attachFilterSelects,
	attachNotificationActiveCheckbox,
	attachAutoTruncateControls,
	attachFocusModeToggle,
	attachFilterSection,
	attachDatesCard,
	attachStatusCard,
];

/**
 * Attach event listeners for all monitor UI components. Call from attachUIHandlers.
 * Components have already injected their HTML via headerComposer.
 */
export function attachAll(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	for (const attachFn of ATTACH_FNS) {
		attachFn(api, eventHandlers, debugTrackListener, debugUntrackListener);
	}
}

// Legacy export name for callers that still use mountAll
export { attachAll as mountAll };

export { attach as attachFixedToolbar } from "./components/FixedToolbar.js";
export { attach as attachConnectionDetailsButton } from "./components/ConnectionDetailsButton.js";
export { attach as attachSearchInput } from "./components/SearchInput.js";
export { attach as attachClearButtons } from "./components/ClearButtons.js";
export { attach as attachFetchButtons } from "./components/FetchButtons.js";
export { attach as attachPauseButton } from "./components/PauseButton.js";
export { attach as attachSortSelect } from "./components/SortSelect.js";
export { attach as attachFilterSelects } from "./components/FilterSelects.js";
export { attach as attachNotificationActiveCheckbox } from "./components/NotificationActiveCheckbox.js";
export { attach as attachAutoTruncateControls } from "./components/AutoTruncateControls.js";
export { attach as attachFocusModeToggle } from "./components/FocusModeToggle.js";
export { attach as attachFilterSection } from "./components/FilterSection.js";
export { attach as attachDatesCard } from "./components/DatesCard.js";
export { attach as attachStatusCard } from "./components/StatusCard.js";
