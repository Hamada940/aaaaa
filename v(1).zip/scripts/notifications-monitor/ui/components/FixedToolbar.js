/**
 * Fixed toolbar (scroll-to-top + fixed pause button). Shows when user scrolls past original pause button.
 * Owns its HTML: loads template and injects into container.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_fixed_toolbar.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const scrollToTopBtn = document.getElementById("scrollToTop-fixed");
	const originalPauseBtn = document.getElementById("pauseFeed");
	const fixedPauseBtn = document.getElementById("pauseFeed-fixed");
	const fixedToolbar = document.getElementById("fixed-toolbar");
	const originalBtnPosition = originalPauseBtn ? originalPauseBtn.getBoundingClientRect().top + window.scrollY : 0;

	const windowScrollHandler = () => {
		if (fixedToolbar) {
			fixedToolbar.style.display = window.scrollY > originalBtnPosition ? "block" : "none";
		}
	};
	if (eventHandlers.window?.scroll?.handler) {
		window.removeEventListener(eventHandlers.window.scroll.event, eventHandlers.window.scroll.handler);
		debugUntrackListener(window, "scroll", eventHandlers.window.scroll.handler);
	}
	window.addEventListener("scroll", windowScrollHandler);
	eventHandlers.window = eventHandlers.window || {};
	eventHandlers.window.scroll = { event: "scroll", handler: windowScrollHandler };
	debugTrackListener(window, "scroll", windowScrollHandler);

	const scrollToTopHandler = () => window.scrollTo({ top: 0, behavior: "smooth" });
	removeExisting(buttons, scrollToTopBtn, "click", scrollToTopHandler);
	register(buttons, scrollToTopBtn, "click", scrollToTopHandler);
	debugTrackListener(scrollToTopBtn, "click", scrollToTopHandler);

	const fixedPauseHandler = () => api.handlePauseClick();
	removeExisting(buttons, fixedPauseBtn, "click", fixedPauseHandler);
	register(buttons, fixedPauseBtn, "click", fixedPauseHandler);
	debugTrackListener(fixedPauseBtn, "click", fixedPauseHandler);
}
