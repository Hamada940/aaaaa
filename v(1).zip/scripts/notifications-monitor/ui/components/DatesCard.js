/**
 * Dates card (loaded on, most recent, assisted load). Owns its HTML.
 * No attach – dates are updated by the monitor elsewhere.
 */
import { getTemplatePath, parseMarkupToDOM } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_dates_card.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach() {
	// No listeners; monitor updates date_loaded, date_most_recent_item, etc. directly
}
