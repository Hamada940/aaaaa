/**
 * Clear monitor / clear unavailable buttons. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_clear_buttons.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const passiveClears = api.getPassiveClears?.() ?? true;

	const btnClearMonitor = document.getElementById("clear-monitor");
	if (btnClearMonitor) {
		api.setClearMonitorButton?.(btnClearMonitor);
		const handler = () =>
			passiveClears ? api.handleClearMonitorPassive(btnClearMonitor) : api.handleClearMonitorDialog();
		removeExisting(buttons, btnClearMonitor, "click", handler);
		register(buttons, btnClearMonitor, "click", handler);
		debugTrackListener(btnClearMonitor, "click", handler);
	}

	const btnClearUnavailable = document.getElementById("clear-unavailable");
	if (btnClearUnavailable) {
		api.setClearUnavailableButton?.(btnClearUnavailable);
		const handler = () =>
			passiveClears ? api.handleClearUnavailablePassive(btnClearUnavailable) : api.handleClearUnavailableDialog();
		removeExisting(buttons, btnClearUnavailable, "click", handler);
		register(buttons, btnClearUnavailable, "click", handler);
		debugTrackListener(btnClearUnavailable, "click", handler);
	}
}
