/**
 * Filter section – pin, expand/collapse, click-outside. Owns its HTML.
 * Composes SearchInput, FilterSelects, SortSelect.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";
import { renderToMarkup as renderSearchInput } from "./SearchInput.js";
import { renderToMarkup as renderFilterSelects } from "./FilterSelects.js";
import { renderToMarkup as renderSortSelect } from "./SortSelect.js";

export async function renderToMarkup(tpl) {
	tpl.setVar("NM_SEARCH_INPUT", await renderSearchInput(tpl));
	tpl.setVar("NM_FILTER_SELECTS", await renderFilterSelects(tpl));
	tpl.setVar("NM_SORT_SELECT", await renderSortSelect(tpl));
	const html = await tpl.loadFile(getTemplatePath("nm_filter_section.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const filtersHeader = document.querySelector(".vh-nm-filters-header");
	const filtersSection = document.getElementById("vh-nm-filters");
	const filtersWrapper = document.getElementById("vh-nm-filters-wrapper");
	const filterPinIcon = document.getElementById("vh-nm-filter-pin");

	if (!filtersHeader || !filtersSection) return;

	api.initFilterSection?.(filtersSection, filtersWrapper, filterPinIcon);
	api.updateFilterCount();

	if (filterPinIcon) {
		const filterPinHandler = (e) => {
			e.preventDefault();
			e.stopPropagation();
			api.onFilterPinClick(filtersSection, filtersWrapper, filterPinIcon);
		};
		filterPinIcon.addEventListener("click", filterPinHandler);
		buttons.set(filterPinIcon, { event: "click", handler: filterPinHandler });
		debugTrackListener(filterPinIcon, "click", filterPinHandler);
	}

	const filtersToggleHandler = (e) => {
		const target = e.target;
		const isInteractive =
			target?.closest(
				"input, button, select, .vh-button-icon-compact, .vh-icon-only-button, .vh-nm-filter-pin"
			) !== null;
		if (!isInteractive) api.onFiltersToggle(filtersSection, filtersWrapper, filterPinIcon);
	};
	removeExisting(buttons, filtersHeader, "click", filtersToggleHandler);
	register(buttons, filtersHeader, "click", filtersToggleHandler);
	debugTrackListener(filtersHeader, "click", filtersToggleHandler);

	const filterClickOutsideHandler = (e) => {
		if (
			!filtersSection.classList.contains("collapsed") &&
			!filtersSection.classList.contains("pinned") &&
			!filtersSection.contains(e.target)
		) {
			filtersSection.classList.add("collapsed");
		}
	};
	if (eventHandlers.documentClick) {
		document.removeEventListener("click", eventHandlers.documentClick);
		debugUntrackListener(document, "click", eventHandlers.documentClick);
	}
	eventHandlers.documentClick = filterClickOutsideHandler;
	document.addEventListener("click", filterClickOutsideHandler);
	debugTrackListener(document, "click", filterClickOutsideHandler);
}
