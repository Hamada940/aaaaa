/**
 * Connection details button – opens connection details modal.
 * Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_connection_details_button.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const connectionDetailsBtn = document.getElementById("connectionDetails");
	if (!connectionDetailsBtn) return;

	const handler = api.handleConnectionDetailsClick;
	removeExisting(buttons, connectionDetailsBtn, "click", handler);
	connectionDetailsBtn.addEventListener("click", handler);
	buttons.set(connectionDetailsBtn, { event: "click", handler: handler });
	debugTrackListener(connectionDetailsBtn, "click", handler);
}
