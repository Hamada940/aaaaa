/**
 * Status card (mode, connection, notification toggle). Owns its HTML.
 * Composes ConnectionDetailsButton and NotificationActiveCheckbox.
 * No attach – listeners are on the child components.
 */
import { getTemplatePath, parseMarkupToDOM } from "./buttonHelpers.js";
import { renderToMarkup as renderConnectionDetailsButton } from "./ConnectionDetailsButton.js";
import { renderToMarkup as renderNotificationActiveCheckbox } from "./NotificationActiveCheckbox.js";

export async function renderToMarkup(tpl) {
	tpl.setVar("NM_CONNECTION_DETAILS_BUTTON", await renderConnectionDetailsButton(tpl));
	tpl.setVar("NM_NOTIFICATION_ACTIVE_CHECKBOX", await renderNotificationActiveCheckbox(tpl));
	const html = await tpl.loadFile(getTemplatePath("nm_status_card.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach() {
	// Listeners are on ConnectionDetailsButton and NotificationActiveCheckbox
}
