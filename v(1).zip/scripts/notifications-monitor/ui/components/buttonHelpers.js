/**
 * Shared helpers for monitor UI components (register/remove listeners, parse HTML).
 */

const NM_TEMPLATE_BASE = "scripts/ui/templates/notification_monitor";

/**
 * @param {string} name - Template file name (e.g. "nm_fixed_toolbar.html")
 * @returns {string} Full path for Template.loadFile
 */
export function getTemplatePath(name) {
	return `${NM_TEMPLATE_BASE}/${name}`;
}

/**
 * Parse an HTML string into a DocumentFragment (or single element) for appending into a container.
 * @param {string} markup - HTML string
 * @returns {DocumentFragment|Element} Fragment or single element
 */
export function parseMarkupToDOM(markup) {
	const doc = new DOMParser().parseFromString(markup, "text/html");
	const body = doc.body;
	if (body.childNodes.length === 1 && body.firstChild.nodeType === Node.ELEMENT_NODE) {
		return /** @type {Element} */ (body.firstChild);
	}
	const fragment = document.createDocumentFragment();
	while (body.firstChild) {
		fragment.appendChild(body.firstChild);
	}
	return fragment;
}

/**
 * Remove existing listener for an element from the buttons Map and from the DOM.
 * @param {Map} buttonsMap - eventHandlers.buttons
 * @param {Element} element - DOM element
 * @param {string} event - Event name (e.g. 'click', 'change')
 * @param {function} handler - Handler function
 */
export function removeExisting(buttonsMap, element, event, handler) {
	if (!buttonsMap || !element) return;
	const existing = buttonsMap.get(element);
	if (existing?.handler) {
		element.removeEventListener(existing.event, existing.handler);
	}
}

/**
 * Register a listener on an element and store it in the buttons Map for cleanup.
 * @param {Map} buttonsMap - eventHandlers.buttons
 * @param {Element} element - DOM element
 * @param {string} event - Event name
 * @param {function} handler - Handler function
 */
export function register(buttonsMap, element, event, handler) {
	if (!element) return;
	element.addEventListener(event, handler);
	if (buttonsMap) buttonsMap.set(element, { event, handler });
}
