/**
 * Focus mode toggle. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_focus_mode_toggle.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const focusModeToggle = document.getElementById("vh-nm-focus-mode-toggle");
	if (!focusModeToggle) return;

	const handler = () => api.onFocusModeChange(focusModeToggle.checked);
	removeExisting(buttons, focusModeToggle, "change", handler);
	register(buttons, focusModeToggle, "change", handler);
}
