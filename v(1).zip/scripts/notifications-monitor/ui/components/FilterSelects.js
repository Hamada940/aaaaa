/**
 * Filter type and filter queue selects. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_filter_selects.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;

	const filterType = document.querySelector("select[name='filter-type']");
	if (filterType) {
		const handler = () => {
			api.onFilterTypeChange(filterType.value);
			api.updateFilterCount();
		};
		removeExisting(buttons, filterType, "change", handler);
		register(buttons, filterType, "change", handler);
		debugTrackListener(filterType, "change", handler);
	}

	const filterQueue = document.querySelector("select[name='filter-queue']");
	if (filterQueue) {
		const handler = () => {
			api.onFilterQueueChange(filterQueue.value);
			api.updateFilterCount();
		};
		removeExisting(buttons, filterQueue, "change", handler);
		register(buttons, filterQueue, "change", handler);
		debugTrackListener(filterQueue, "change", handler);
	}
}
