/**
 * Notification active checkbox. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_notification_active_checkbox.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const notificationActiveCheckbox = document.getElementById("notification.active");
	if (!notificationActiveCheckbox) return;

	const handler = () => api.onNotificationActiveChange(notificationActiveCheckbox.checked);
	removeExisting(buttons, notificationActiveCheckbox, "change", handler);
	register(buttons, notificationActiveCheckbox, "change", handler);
}
