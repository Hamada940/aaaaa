/**
 * Search input – debounced search. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_search_input.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const searchInput = document.getElementById("search-input");
	if (!searchInput) return;

	const searchHandler = (event) => {
		if (api.clearSearchDebounceTimer) api.clearSearchDebounceTimer();
		api.setSearchDebounceTimer(
			setTimeout(() => {
				api.onSearchInput(event.target.value);
				api.updateFilterCount();
			}, 300)
		);
	};
	searchInput.addEventListener("input", searchHandler);
	buttons.set(searchInput, { event: "input", handler: searchHandler });
	debugTrackListener(searchInput, "input", searchHandler);
}
