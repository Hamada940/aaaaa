/**
 * Fetch last / fetch last 12hrs buttons and long-press dropdown. Owns its HTML.
 * Composer must set tpl vars fetchLimit and TIER3 before mount.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_fetch_buttons.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;

	const btnLast = document.getElementById("fetch-last");
	if (btnLast) {
		const fetchLastHandler = async () => {
			if (api.getLastFetchWasLongPress?.()) {
				api.setLastFetchWasLongPress?.(false);
				return;
			}
			const limitToUse = api.getSessionFetchLimitOverride?.() ?? api.getFetchLimit?.();
			await api.runFetchForLimit(limitToUse, btnLast);
		};
		removeExisting(buttons, btnLast, "click", fetchLastHandler);
		register(buttons, btnLast, "click", fetchLastHandler);
		debugTrackListener(btnLast, "click", fetchLastHandler);

		// Long-press dropdown for fetch last
		const longPressOptions = api.getLongPressOptions?.() ?? [];
		if (longPressOptions.length > 0) {
			const uniqueOptions = Array.from(new Set(longPressOptions));
			const dropdown = document.createElement("div");
			dropdown.className = "vh-fetch-last-dropdown";
			Object.assign(dropdown.style, {
				position: "absolute",
				display: "none",
				background: "white",
				border: "1px solid #ccc",
				boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
				zIndex: "2000",
				padding: "4px",
				borderRadius: "4px",
				minWidth: "80px",
			});
			dropdown.setAttribute("role", "menu");

			let dropdownVisible = false;
			const hideDropdown = () => {
				dropdown.style.display = "none";
				dropdownVisible = false;
				setTimeout(() => api.setLastFetchWasLongPress?.(false), 50);
			};
			const showDropdown = () => {
				dropdown.style.top = `${btnLast.getBoundingClientRect().bottom + window.scrollY + 6}px`;
				dropdown.style.left = `${btnLast.getBoundingClientRect().left + window.scrollX}px`;
				dropdown.style.display = "block";
				dropdownVisible = true;
				api.setLastFetchWasLongPress?.(true);
			};

			uniqueOptions.forEach((opt) => {
				const optionBtn = document.createElement("button");
				optionBtn.type = "button";
				optionBtn.className = "vh-fetch-last-option";
				Object.assign(optionBtn.style, {
					display: "block",
					width: "100%",
					textAlign: "left",
					padding: "6px 8px",
					border: "none",
					background: "transparent",
					cursor: "pointer",
				});
				optionBtn.innerText = String(opt);
				optionBtn.dataset.value = opt;
				optionBtn.addEventListener("mouseup", async (e) => {
					e.stopPropagation();
					const limit = parseInt(optionBtn.dataset.value, 10);
					api.setSessionFetchLimitOverride?.(limit);
					btnLast.value = String(limit);
					await api.runFetchForLimit(limit, btnLast);
					hideDropdown();
				});
				dropdown.appendChild(optionBtn);
			});
			document.body.appendChild(dropdown);

			let longPressTimer = null;
			const longPressDelay = 1000;
			const pointerDownHandler = (e) => {
				if (e.pointerType === "mouse" && e.button !== 0) return;
				longPressTimer = setTimeout(() => {
					if (!btnLast.disabled) showDropdown();
				}, longPressDelay);
			};
			const cancelPress = () => {
				if (longPressTimer) {
					clearTimeout(longPressTimer);
					longPressTimer = null;
				}
			};

			btnLast.addEventListener("pointerdown", pointerDownHandler);
			btnLast.addEventListener("pointerup", cancelPress);
			btnLast.addEventListener("pointerleave", cancelPress);
			btnLast.addEventListener("pointercancel", cancelPress);
			dropdown.addEventListener("mouseleave", hideDropdown);
			btnLast.addEventListener("touchstart", pointerDownHandler, { passive: true });
			btnLast.addEventListener("touchend", cancelPress);
			document.addEventListener("click", (ev) => {
				if (dropdownVisible && !dropdown.contains(ev.target) && ev.target !== btnLast) hideDropdown();
			});
			buttons.set(dropdown, { event: "click", handler: null });
			debugTrackListener(btnLast, "pointerdown", pointerDownHandler);
			debugTrackListener(btnLast, "pointerup", cancelPress);
		}
	}

	const btnLast12hrs = document.getElementById("fetch-last-12hrs");
	if (btnLast12hrs) {
		const handler = () => api.runFetchLast12hrs(btnLast12hrs);
		removeExisting(buttons, btnLast12hrs, "click", handler);
		register(buttons, btnLast12hrs, "click", handler);
		debugTrackListener(btnLast12hrs, "click", handler);
	}
}
