/**
 * Sort queue select. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_sort_select.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const sortQueue = document.querySelector("select[name='sort-queue']");
	if (!sortQueue) return;

	const handler = () => api.onSortChange(sortQueue.value);
	removeExisting(buttons, sortQueue, "change", handler);
	register(buttons, sortQueue, "change", handler);
	debugTrackListener(sortQueue, "change", handler);
}
