/**
 * Auto truncate checkbox and limit select. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_auto_truncate_controls.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;

	const autoTruncateCheckbox = document.getElementById("auto-truncate");
	if (autoTruncateCheckbox) {
		if (api.setAutoTruncateCheckbox) api.setAutoTruncateCheckbox(autoTruncateCheckbox);
		const handler = () => api.onAutoTruncateChange(autoTruncateCheckbox.checked);
		removeExisting(buttons, autoTruncateCheckbox, "change", handler);
		register(buttons, autoTruncateCheckbox, "change", handler);
		debugTrackListener(autoTruncateCheckbox, "change", handler);
	}

	const autoTruncateLimitSelect = document.getElementById("auto-truncate-limit");
	if (autoTruncateLimitSelect) {
		const handler = () => api.onAutoTruncateLimitChange(parseInt(autoTruncateLimitSelect.value, 10));
		removeExisting(buttons, autoTruncateLimitSelect, "change", handler);
		register(buttons, autoTruncateLimitSelect, "change", handler);
		debugTrackListener(autoTruncateLimitSelect, "change", handler);
	}
}
