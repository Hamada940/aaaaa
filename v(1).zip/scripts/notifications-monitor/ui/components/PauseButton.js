/**
 * Pause feed button. Owns its HTML.
 */
import { getTemplatePath, parseMarkupToDOM, removeExisting, register } from "./buttonHelpers.js";

export async function renderToMarkup(tpl) {
	const html = await tpl.loadFile(getTemplatePath("nm_pause_button.html"));
	return tpl.render(html, false);
}

export async function mount(container, tpl) {
	if (!container) return;
	const markup = await renderToMarkup(tpl);
	const node = parseMarkupToDOM(markup);
	container.appendChild(node);
}

export function attach(api, eventHandlers, debugTrackListener = () => {}, debugUntrackListener = () => {}) {
	const buttons = eventHandlers.buttons;
	const btnPauseFeed = document.getElementById("pauseFeed");
	if (!btnPauseFeed) return;

	const handler = () => api.handlePauseClick();
	removeExisting(buttons, btnPauseFeed, "click", handler);
	register(buttons, btnPauseFeed, "click", handler);
	debugTrackListener(btnPauseFeed, "click", handler);
}
