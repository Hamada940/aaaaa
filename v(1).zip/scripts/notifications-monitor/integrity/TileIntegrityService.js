/**
 * Tile integrity service: per-tile lock/unlock with snapshot validation.
 * - Lock: store current DOM structure as the allowed state for that tile.
 * - Unlock: allow the monitor to modify the tile; re-lock after changes to store the new allowed state.
 * - Validation: locked tiles must match their stored snapshot; any change triggers "external changes" lock.
 * Template-based schema is only used to bootstrap the observer (ensureSchema); actual checks use per-tile snapshots.
 */

import { buildSchemaFromLiveElement, cloneSchemaNode } from "./schemaBuilder.js";
import { validate as validateNode, validateWithReason } from "./validator.js";

/**
 * Service for per-tile integrity: lock (snapshot), unlock (allow changes), validate (compare to snapshot).
 */
export class TileIntegrityService {
	/** @type {WeakMap<Element, { schema: import('./schemaBuilder.js').ElementSchemaNode, locked: boolean }>} */
	#snapshots = new WeakMap();
	/** @type {WeakSet<Element>} Tiles currently inside runWithTileUnlocked — skip validation to avoid false positives from observer racing. */
	#tilesBeingModified = new WeakSet();

	constructor() {}

	/**
	 * Lock a tile: snapshot its current DOM structure. While locked, validation requires the tile to match this snapshot.
	 * Call after creating a tile or after the monitor has finished modifying it.
	 * @param {Element} tileElement - .vvp-item-tile element
	 */
	lockTile(tileElement) {
		if (!tileElement?.classList?.contains("vvp-item-tile")) return;
		const schema = buildSchemaFromLiveElement(tileElement);
		this.#snapshots.set(tileElement, { schema, locked: true });
	}

	/**
	 * Lock a tile against a schema captured before the tile was exposed to page scripts.
	 * @param {Element} tileElement - .vvp-item-tile element
	 * @param {import('./schemaBuilder.js').ElementSchemaNode} trustedSchema
	 */
	lockTileWithSchema(tileElement, trustedSchema) {
		if (!tileElement?.classList?.contains("vvp-item-tile") || !trustedSchema) return;
		this.#snapshots.set(tileElement, { schema: cloneSchemaNode(trustedSchema), locked: true });
	}

	/**
	 * Unlock a tile: allow DOM changes without triggering integrity failure. Call before the monitor modifies the tile, then call lockTile when done.
	 * @param {Element} tileElement - .vvp-item-tile element
	 */
	unlockTile(tileElement) {
		if (!tileElement) return;
		const entry = this.#snapshots.get(tileElement);
		if (entry) entry.locked = false;
	}

	/**
	 * Schedule a lock for the next animation frame. Use after DOM changes so the integrity observer's rAF
	 * (triggered by the mutation) runs first and skips the tile while it's still unlocked.
	 * @param {Element} tileElement - .vvp-item-tile element
	 */
	lockTileOnNextFrame(tileElement) {
		if (!tileElement?.classList?.contains("vvp-item-tile")) return;
		requestAnimationFrame(() => this.lockTile(tileElement));
	}

	/**
	 * Run a callback while the tile is unlocked, then re-lock (snapshot new state). Use when adding variant buttons or other DOM changes from code that cannot call unlock/lock directly.
	 * @param {Element} tileElement - .vvp-item-tile element
	 * @param {() => void | Promise<void>} callback - Code that modifies the tile DOM (e.g. tile.addVariant)
	 * @returns {Promise<void>}
	 */
	async runWithTileUnlocked(tileElement, callback) {
		if (!tileElement) {
			await callback();
			return;
		}
		const tileId = tileElement.id ?? tileElement.dataset?.asin ?? "?";
		this.#tilesBeingModified.add(tileElement);
		this.unlockTile(tileElement);
		try {
			await callback();
		} finally {
			this.#tilesBeingModified.delete(tileElement);
			this.lockTile(tileElement);
		}
	}

	/**
	 * Whether this tile has a locked snapshot (only such tiles need integrity validation on mutation).
	 * @param {Element} tileElement - .vvp-item-tile element
	 * @returns {boolean}
	 */
	isTileLocked(tileElement) {
		if (!tileElement?.classList?.contains("vvp-item-tile")) return false;
		const entry = this.#snapshots.get(tileElement);
		return !!(entry && entry.locked);
	}

	/**
	 * Validate a single tile: if it has a locked snapshot, current DOM must match that snapshot.
	 * @param {Element} tileElement - .vvp-item-tile element
	 * @returns {{ valid: boolean, reason?: string }} valid false and reason set when integrity check fails
	 */
	validateTile(tileElement) {
		if (!tileElement?.classList?.contains("vvp-item-tile")) return { valid: true };
		if (this.#tilesBeingModified.has(tileElement)) return { valid: true };
		const entry = this.#snapshots.get(tileElement);
		if (!entry || !entry.locked) return { valid: true };
		const { ok, reason, failedAt } = validateWithReason(tileElement, entry.schema);
		if (ok) return { valid: true };
		return { valid: false, reason: reason ?? "structure mismatch", failedAt };
	}

	/**
	 * No-op for API compatibility (observer still calls ensureSchema; we don't need template cache for per-tile mode).
	 * @param {string} [_tileTemplateFile]
	 */
	async ensureSchema(_tileTemplateFile) {
		// Per-tile snapshots only; no template cache needed for validation
	}

	invalidate() {
		// WeakMap entries are per-element; no global cache to clear
	}
}
