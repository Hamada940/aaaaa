/**
 * Validates a live DOM element (or tile) against a schema tree.
 * Recursively checks every node: tag and required class only (no attributes or textContent).
 * Optional schema nodes can be skipped so that {{if}}-driven structure is accepted either way.
 * <font> elements are ignored in the expected schema; when present in the live DOM they are treated
 * as transparent wrappers: their element children (recursively, unwrapping nested <font>) are matched
 * against the expected schema. No new elements are allowed—only structure that was in the expected
 * tree, optionally wrapped in <font>. E.g. expected <span><a></a></span> allows
 * <span><font><a></a></font></span> but not <span><font><a><a></a></a></font></span>.
 */

/**
 * Expand <font> wrappers: return a flat list of element nodes with FONT nodes replaced by the
 * recursive expansion of their element children. Result is the "effective" child list for matching.
 * @param {Element[]} liveElementNodes
 * @returns {Element[]}
 */
function expandFonts(liveElementNodes) {
	const out = [];
	for (const node of liveElementNodes) {
		if (node.tagName === "FONT") {
			const fontChildren = Array.from(node.childNodes).filter((n) => n.nodeType === Node.ELEMENT_NODE);
			out.push(...expandFonts(fontChildren));
		} else {
			out.push(node);
		}
	}
	return out;
}

/**
 * @typedef {{ reason: string | null, failedAt?: { liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string, expectedTag?: string } }} FailureReason
 */

/**
 * Set failure reason once (first failure wins).
 * @param {FailureReason} out
 * @param {string} msg
 * @param {{ liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string }} [failedAt]
 */
function setReason(out, msg, failedAt) {
	if (out && out.reason === null) {
		out.reason = msg;
		if (failedAt) out.failedAt = failedAt;
	}
}

/**
 * Check that a live element matches an element schema node (tag, requiredClass), then match children.
 * @param {Element} live - Live DOM element
 * @param {import('./schemaBuilder.js').ElementSchemaNode} expected - Element schema node
 * @param {FailureReason} [out] - If provided, set reason on first failure
 * @param {string} [path] - Path for error messages
 * @returns {boolean}
 */
function matchElement(live, expected, out, path = "tile") {
	if (!live || live.nodeType !== Node.ELEMENT_NODE) {
		setReason(out, `${path}: expected element, got ${live ? "non-element" : "null"}`);
		return false;
	}
	if (live.tagName !== expected.tag) {
		setReason(
			out,
			`${path}: expected tag <${expected.tag}>, got <${live.tagName}>${live.id ? " (id=" + live.id + ")" : ""}`,
			{ liveElement: live, expectedChildCount: -1, actualChildCount: -1, path, expectedTag: expected.tag }
		);
		return false;
	}
	const firstClass = live.classList?.[0] ?? "";
	if (expected.requiredClass && !live.classList.contains(expected.requiredClass)) {
		setReason(
			out,
			`${path}: expected class "${expected.requiredClass}" (on <${expected.tag}>), first class on live is "${firstClass}"`,
			{ liveElement: live, expectedChildCount: -1, actualChildCount: -1, path }
		);
		return false;
	}
	if (expected.attributes) {
		for (const [attr, expectedValue] of Object.entries(expected.attributes)) {
			const liveValue = live.getAttribute(attr);
			if (liveValue !== expectedValue) {
				setReason(
					out,
					`${path}: expected attribute "${attr}" to remain "${expectedValue ?? ""}", got "${liveValue ?? ""}"`,
					{ liveElement: live, expectedChildCount: -1, actualChildCount: -1, path }
				);
				return false;
			}
		}
	}

	const liveChildren = Array.from(live.childNodes).filter((n) => n.nodeType === Node.ELEMENT_NODE);
	const effectiveChildren = expandFonts(liveChildren);
	return matchChildren(effectiveChildren, expected.children, out, path, live);
}

/**
 * Match a list of expected schema children to a list of live element children.
 * Optional expected nodes can be skipped. Slots (unresolved) accept any single element.
 * @param {Element[]} liveChildren
 * @param {import('./schemaBuilder.js').SchemaNode[]} expectedChildren
 * @param {FailureReason} [out]
 * @param {string} [path]
 * @param {Element} [parentLive] - Parent of liveChildren; used for failedAt when child count mismatches
 * @returns {boolean}
 */
function matchChildren(liveChildren, expectedChildren, out, path = "tile", parentLive) {
	let eIndex = 0;
	let lIndex = 0;

	while (eIndex < expectedChildren.length) {
		const exp = expectedChildren[eIndex];

		if (exp.type === "element") {
			if (exp.optional) {
				if (matchChildrenFrom(liveChildren, expectedChildren, eIndex + 1, lIndex, out, path, parentLive))
					return true;
			}
			if (lIndex >= liveChildren.length) {
				setReason(
					out,
					`${path}: expected child ${eIndex} (<${exp.tag}.${exp.requiredClass}>), but only ${liveChildren.length} child(ren)`
				);
				return false;
			}
			const childPath = `${path} > child[${lIndex}]`;
			if (!matchElement(liveChildren[lIndex], exp, out, childPath)) {
				if (exp.optional) {
					eIndex++;
					continue;
				}
				return false;
			}
			eIndex++;
			lIndex++;
			continue;
		}

		if (exp.type === "slot") {
			if (exp.optional && lIndex >= liveChildren.length) {
				eIndex++;
				continue;
			}
			if (exp.optional && eIndex + 1 < expectedChildren.length) {
				if (matchChildrenFrom(liveChildren, expectedChildren, eIndex + 1, lIndex, out, path, parentLive))
					return true;
			}
			if (lIndex >= liveChildren.length) {
				setReason(
					out,
					`${path}: expected slot "${exp.name}" (one element), but only ${liveChildren.length} child(ren)`
				);
				return false;
			}
			eIndex++;
			lIndex++;
			continue;
		}

		eIndex++;
	}

	if (lIndex !== liveChildren.length) {
		setReason(
			out,
			`${path}: expected ${lIndex} child(ren) to match schema, but element has ${liveChildren.length} child(ren) (extra node(s) or wrong structure)`,
			parentLive != null
				? { liveElement: parentLive, expectedChildCount: lIndex, actualChildCount: liveChildren.length, path }
				: undefined
		);
		return false;
	}
	return true;
}

/**
 * @param {Element[]} liveChildren
 * @param {import('./schemaBuilder.js').SchemaNode[]} expectedChildren
 * @param {number} eIndex
 * @param {number} lIndex
 * @param {FailureReason} [out]
 * @param {string} [path]
 * @param {Element} [parentLive]
 * @returns {boolean}
 */
function matchChildrenFrom(liveChildren, expectedChildren, eIndex, lIndex, out, path = "tile", parentLive) {
	let ei = eIndex;
	let li = lIndex;

	while (ei < expectedChildren.length) {
		const exp = expectedChildren[ei];

		if (exp.type === "element") {
			if (exp.optional) {
				if (matchChildrenFrom(liveChildren, expectedChildren, ei + 1, li, out, path, parentLive)) return true;
			}
			if (li >= liveChildren.length) {
				setReason(
					out,
					`${path}: expected more children (expected <${exp.tag}>), only ${liveChildren.length} present`
				);
				return false;
			}
			const childPath = `${path} > child[${li}]`;
			if (!matchElement(liveChildren[li], exp, out, childPath)) {
				if (exp.optional) {
					ei++;
					continue;
				}
				return false;
			}
			ei++;
			li++;
			continue;
		}

		if (exp.type === "slot") {
			if (exp.optional && li >= liveChildren.length) {
				ei++;
				continue;
			}
			if (exp.optional && ei + 1 < expectedChildren.length) {
				if (matchChildrenFrom(liveChildren, expectedChildren, ei + 1, li, out, path, parentLive)) return true;
			}
			if (li >= liveChildren.length) {
				setReason(
					out,
					`${path}: slot "${exp.name}": expected one element, only ${liveChildren.length} child(ren)`
				);
				return false;
			}
			ei++;
			li++;
			continue;
		}

		ei++;
	}

	if (li !== liveChildren.length) {
		setReason(
			out,
			`${path}: schema has ${ei} slot(s), live has ${liveChildren.length} child(ren) (extra or missing)`,
			parentLive
				? { liveElement: parentLive, expectedChildCount: li, actualChildCount: liveChildren.length, path }
				: undefined
		);
		return false;
	}
	return true;
}

/**
 * Validate a live tile (or any root element) against the full schema tree.
 * @param {Element} liveRoot - Root DOM element (e.g. .vvp-item-tile)
 * @param {import('./schemaBuilder.js').ElementSchemaNode} schemaRoot - Root schema node
 * @returns {boolean} true if the entire subtree matches the schema (structure only)
 */
export function validate(liveRoot, schemaRoot) {
	if (!liveRoot || !schemaRoot) return false;
	if (schemaRoot.type !== "element") return false;
	return matchElement(liveRoot, schemaRoot);
}

/**
 * Validate and return a human-readable reason and debug info on failure.
 * @param {Element} liveRoot - Root DOM element (e.g. .vvp-item-tile)
 * @param {import('./schemaBuilder.js').ElementSchemaNode} schemaRoot - Root schema node
 * @returns {{ ok: boolean, reason: string | null, failedAt?: { liveElement: Element, expectedChildCount: number, actualChildCount: number, path: string } }}
 */
export function validateWithReason(liveRoot, schemaRoot) {
	const out = { reason: null };
	if (!liveRoot || !schemaRoot) {
		out.reason = "no live root or schema";
		return { ok: false, reason: out.reason };
	}
	if (schemaRoot.type !== "element") {
		out.reason = "schema root is not an element node";
		return { ok: false, reason: out.reason };
	}
	const ok = matchElement(liveRoot, schemaRoot, out, "tile");
	return { ok, reason: out.reason, failedAt: out.failedAt };
}
