/**
 * Pure helpers for tile integrity checks (testable without NotificationMonitor).
 */

/**
 * @param {MutationRecord[]} mutations
 * @returns {Set<Element>}
 */
function collectAffectedTilesFromMutations(mutations) {
	const tiles = new Set();
	for (const record of mutations) {
		addAffectedTileFromNode(record.target, tiles);
		for (const node of record.addedNodes ?? []) {
			addAffectedTileFromNode(node, tiles);
		}
		for (const node of record.removedNodes ?? []) {
			addAffectedTileFromNode(node, tiles);
		}
	}
	return tiles;
}

/**
 * @param {Node} node
 * @param {Set<Element>} tiles
 */
function addAffectedTileFromNode(node, tiles) {
	const element = node?.nodeType === Node.ELEMENT_NODE ? /** @type {Element} */ (node) : node?.parentElement;
	if (!element) return;

	if (element.matches?.(".vvp-item-tile:not(.vh-placeholder-tile)")) {
		tiles.add(element);
	}
	const closestTile = element.closest?.(".vvp-item-tile:not(.vh-placeholder-tile)");
	if (closestTile) {
		tiles.add(closestTile);
	}
	element.querySelectorAll?.(".vvp-item-tile:not(.vh-placeholder-tile)").forEach((tile) => tiles.add(tile));
}

/**
 * @param {Set<Element>} affectedTiles
 * @param {{ isTileLocked?: (el: Element) => boolean, validateTile?: (el: Element) => { valid?: boolean, reason?: string, failedAt?: object } } | null | undefined} tileIntegrityService
 * @param {boolean} integrityLocked
 * @returns {{ ok: boolean, failedTile?: Element, reason?: string, failedAt?: object }}
 */
function validateAffectedLockedTiles(affectedTiles, tileIntegrityService, integrityLocked) {
	if (!tileIntegrityService || integrityLocked || affectedTiles.size === 0) {
		return { ok: true };
	}
	for (const tile of affectedTiles) {
		if (!tileIntegrityService.isTileLocked?.(tile)) {
			continue;
		}
		const result = tileIntegrityService.validateTile?.(tile);
		if (result && !result.valid) {
			return { ok: false, failedTile: tile, reason: result.reason, failedAt: result.failedAt };
		}
	}
	return { ok: true };
}

export { collectAffectedTilesFromMutations, validateAffectedLockedTiles };
