/**
 * Builds a structure schema tree from template HTML.
 * Schema describes expected DOM shape (tag + one identifying class per node); optional nodes from {{if}} are marked.
 * Used for full tile integrity validation. Component-friendly: slots (e.g. {{$toolbar}}) can be filled with sub-schemas later.
 */

/**
 * @typedef {Object} ElementSchemaNode
 * @property {'element'} type
 * @property {string} tag - Uppercase tag name
 * @property {string} requiredClass - First class from template (for matching)
 * @property {Record<string, string|null>} [attributes] - Security-relevant attributes that must not change
 * @property {boolean} optional - Inside {{if}}...{{endif}}
 * @property {SchemaNode[]} children
 */

/**
 * @typedef {Object} SlotSchemaNode
 * @property {'slot'} type
 * @property {string} name - e.g. 'toolbar', 'orderWidget'
 * @property {boolean} [optional] - true if slot can render nothing (e.g. {{$orderWidget}} empty)
 */

/**
 * @typedef {ElementSchemaNode | SlotSchemaNode} SchemaNode
 */

/**
 * @typedef {Object} BuildOptions
 * @property {string} [rootSelector] - CSS selector for root (e.g. '.vvp-item-tile'). If omitted, uses doc.body.firstElementChild.
 */

/**
 * Deep-clone a schema node (for slot resolution without mutating cached schema).
 * @param {SchemaNode} node
 * @returns {SchemaNode}
 */
export function cloneSchemaNode(node) {
	if (node.type === "slot") {
		return { ...node };
	}
	return {
		...node,
		attributes: node.attributes ? { ...node.attributes } : undefined,
		children: node.children.map((c) => cloneSchemaNode(c)),
	};
}

const INTEGRITY_ATTRIBUTES = ["action", "href", "onclick", "onmouseenter", "onmouseleave", "onmouseover", "type"];

/**
 * Build a schema tree from a live DOM element (snapshot for per-tile lock).
 * Same shape as ElementSchemaNode: tag, requiredClass (first class), children. No optional/slots.
 * Iterative (stack-based) to avoid deep recursion and keep lock fast; no template check — tile is assumed valid.
 * @param {Element} liveElement - Live DOM element
 * @returns {ElementSchemaNode} Schema node for this element and its subtree
 */
export function buildSchemaFromLiveElement(liveElement) {
	if (!liveElement || liveElement.nodeType !== Node.ELEMENT_NODE) {
		return { type: "element", tag: "DIV", requiredClass: "", optional: false, children: [] };
	}
	/** @type {{ el: Element, parent: ElementSchemaNode }[]} */
	const stack = [{ el: liveElement, parent: null }];
	/** @type {ElementSchemaNode} */
	let root = null;
	while (stack.length) {
		const { el, parent } = stack.pop();
		const node = {
			type: "element",
			tag: el.tagName,
			requiredClass: el.classList?.[0] ?? "",
			attributes: captureIntegrityAttributes(el),
			optional: false,
			children: [],
		};
		if (parent === null) root = node;
		else parent.children.push(node);
		for (let i = el.childNodes.length - 1; i >= 0; i--) {
			const child = el.childNodes[i];
			if (child.nodeType !== Node.ELEMENT_NODE) continue;
			// Ignore <font> in expected schema so they are treated as allowed extras when validating
			if (/** @type {Element} */ (child).tagName === "FONT") continue;
			stack.push({ el: /** @type {Element} */ (child), parent: node });
		}
	}
	return root ?? { type: "element", tag: "DIV", requiredClass: "", optional: false, children: [] };
}

function captureIntegrityAttributes(element) {
	const attributes = {};
	for (const attr of INTEGRITY_ATTRIBUTES) {
		const value = element.getAttribute?.(attr);
		if (value != null || attr.startsWith("on")) {
			attributes[attr] = value;
		}
	}
	return attributes;
}

/**
 * Resolve slot placeholders in a schema tree by replacing slots with the given schema.
 * Mutates the schema tree in place.
 * @param {SchemaNode} node - Schema node (element or slot)
 * @param {Record<string, ElementSchemaNode | null>} slotSchemas - Map slot name -> schema to inject (null = allow any single element)
 */
export function resolveSlots(node, slotSchemas) {
	if (!node) return;
	if (node.type === "slot") return;
	for (let i = 0; i < node.children.length; i++) {
		const child = node.children[i];
		if (child.type === "slot") {
			const replacement = slotSchemas[child.name];
			if (replacement != null) {
				node.children[i] = cloneSchemaNode(replacement);
			}
			continue;
		}
		resolveSlots(child, slotSchemas);
	}
}
