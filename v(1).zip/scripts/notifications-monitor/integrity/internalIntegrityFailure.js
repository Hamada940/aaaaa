function isAllowedVHelperInternalIntegrityFailure(failedAt, settings) {
	if (!failedAt?.liveElement || !failedAt.expectedTag) return false;
	if (!settings?.isPremiumUser?.(3) || !settings?.get?.("notification.monitor.carousel.active")) {
		return false;
	}
	const el = failedAt.liveElement;
	const expected = (failedAt.expectedTag || "").toUpperCase();
	const got = (el.tagName || "").toUpperCase();
	const isDirectChildOfImgContainer = el.parentElement?.classList?.contains("vh-img-container");
	if (!isDirectChildOfImgContainer) return false;
	return (expected === "SECTION" && got === "DIV") || (expected === "DIV" && got === "SECTION");
}

export { isAllowedVHelperInternalIntegrityFailure };
