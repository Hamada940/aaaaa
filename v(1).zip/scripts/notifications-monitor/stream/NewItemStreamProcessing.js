/*global chrome*/

import { Streamy } from "../../core/utils/Streamy.js";
import { SettingsMgr } from "../../core/services/SettingsMgr.js";
import { Item } from "../../core/models/Item.js";
import { YMDHiStoISODate, DateToUnixTimeStamp } from "../../core/utils/DateHelper.js";
import { WebhookQueue } from "./WebhookQueue.js";
import { Internationalization } from "../../core/services/Internationalization.js";
import { unescapeHTML } from "../../core/utils/StringHelper.js";
import { KeywordMatcherService } from "../../core/services/KeywordMatcherService.js";
import * as MonitorDebug from "../debug/MonitorDebug.js";

/**
 * NewItemStreamProcessing handles real-time item processing with keyword matching.
 *
 * This class uses the simplified KeywordCompiler/KeywordMatcher pattern where:
 * - Keywords are compiled once on initialization
 * - Keywords are recompiled when settings change
 * - No complex caching logic is needed
 */
class NewItemStreamProcessing {
	constructor(settingsManager = null, monitor = null) {
		this.settingsManager = settingsManager || new SettingsMgr();
		this.monitor = monitor;
		this.webhookQueue = new WebhookQueue(this.settingsManager);
		this.dataStream = new Streamy();

		this.outputFunctions = {
			broadcast: () => {},
			push: () => {},
		};

		// Keyword matching service (handles all keyword logic with lazy compilation)
		this.keywordMatcher = null;

		// Settings that affect behavior
		this.hideListEnabled = false;
		this.pushNotifications = false;
		this.pushNotificationsAFA = false;

		// Diagnostic: Track processing counts per ASIN
		this.processingCounts = new Map();
		// Diagnostic: Track webhook dispatch counts per webhook fingerprint
		this.webhookDispatchCounts = new Map();

		this.#pipelineReady = false;
		this.#pendingInput = [];

		this.setupPipeline();
		void this.initialize().then(() => {
			this.#pipelineReady = true;
			const queued = this.#pendingInput;
			this.#pendingInput = [];
			for (const data of queued) {
				this.dataStream.input(data);
			}
		});
	}

	#pipelineReady = false;
	#pendingInput = [];

	#titleForKeywordMatch(title) {
		if (title == null || title === undefined) {
			return "";
		}
		return unescapeHTML(unescapeHTML(String(title)));
	}

	#isHideListEnabled() {
		return Boolean(this.settingsManager?.get("notification.hideList"));
	}

	async initialize() {
		// Wait for settings to load before checking premium status
		if (this.settingsManager && typeof this.settingsManager.waitForLoad === "function") {
			await this.settingsManager.waitForLoad();
		}

		this.i18nMgr = new Internationalization();
		const countryCode = this.settingsManager.get("general.country");
		if (countryCode != null) {
			this.i18nMgr.setCountryCode(countryCode);
		}

		// Initialize keyword matcher service and pre-load groups for sync methods
		// Check premium tier 2 status - try multiple ways to ensure we get the correct status
		let isPremiumTier2 = false;
		if (this.settingsManager && typeof this.settingsManager.isPremiumUser === "function") {
			isPremiumTier2 = this.settingsManager.isPremiumUser(2);
		} else if (
			this.settingsManager &&
			this.settingsManager._settings &&
			typeof this.settingsManager._settings.isPremiumUser === "function"
		) {
			isPremiumTier2 = this.settingsManager._settings.isPremiumUser(2);
		}

		this.keywordMatcher = new KeywordMatcherService(this.settingsManager, isPremiumTier2);
		await this.keywordMatcher.initialize();

		// Update behavior settings
		this.hideListEnabled = this.settingsManager.get("notification.hideList");
		this.pushNotifications = this.settingsManager.get("notification.pushNotifications");
		this.pushNotificationsAFA = this.settingsManager.get("notification.pushNotificationsAFA");

		this.webhookKWsMatchUrl = this.settingsManager.get("discord.webhook.KWsMatch.url");
		this.webhookAFAEnabled = this.settingsManager.get("discord.webhook.AFA.active");
		this.webhookAFAUrl = this.settingsManager.get("discord.webhook.AFA.url");
		this.webhookRFYEnabled = this.settingsManager.get("discord.webhook.RFY.active");
		this.webhookRFYUrl = this.settingsManager.get("discord.webhook.RFY.url");
	}

	//#####################################################
	//## PIPELINE
	//#####################################################

	filterHideItem(rawData) {
		if (!rawData.item) {
			return true; //Skip this filter
		}
		const data = rawData.item.data;
		if (data.title === undefined) {
			if (this.settingsManager.get("general.debugKeywords")) {
				console.log("[NewItemStreamProcessing] Item has no title, skipping hide filter.", data);
			}
			return true; //Skip this filter
		}

		if (!this.#isHideListEnabled()) {
			if (this.settingsManager.get("general.debugKeywords")) {
				console.log("[NewItemStreamProcessing] Hide list is not enabled, skipping hide filter.");
			}
			return true;
		}
		if (!this.keywordMatcher) {
			if (this.settingsManager.get("general.debugKeywords")) {
				console.log(
					"[NewItemStreamProcessing] KeywordMatcherService is not initialized, skipping hide filter."
				);
			}
			return true;
		}

		const title = this.#titleForKeywordMatch(data.title);
		if (!title) {
			if (this.settingsManager.get("general.debugKeywords")) {
				console.log("[NewItemStreamProcessing] Item title is empty, skipping hide filter.", data);
			}
			return true;
		}

		// Only check hide keywords if the item is NOT highlighted
		if (!data.KWsMatch) {
			const match = this.keywordMatcher.findHighlightHideMatchSync(title, data.etv_min, data.etv_max);
			if (match && match.type === "hide") {
				if (this.settingsManager.get("general.debugKeywords")) {
					console.log("[NewItemStreamProcessing] Item hidden by keyword:", {
						asin: data.asin,
						title: data.title,
						keyword: match?.contains ?? "",
						timestamp: Date.now(),
					});
				}
				return false; //Do not display the notification as it matches the hide list.
			}
		}
		return true;
	}

	transformIsHighlight(rawData) {
		if (!rawData.item) {
			return rawData; //Skip this transformer
		}
		const data = rawData.item.data;

		if (data.title === undefined) {
			return rawData; //Skip this transformer if no title
		}

		// Diagnostic logging for duplicate processing
		if (this.settingsManager.get("general.debugDuplicates")) {
			const timestamp = Date.now();
			const asin = data.asin;

			// Track processing count
			const currentCount = this.processingCounts.get(asin) || 0;
			this.processingCounts.set(asin, currentCount + 1);

			if (this.settingsManager.get("general.debugKeywords")) {
				console.log("[NewItemStreamProcessing] transformIsHighlight called:", {
					asin: asin,
					title: data.title?.substring(0, 50) + "...",
					enrollment_guid: data.enrollment_guid,
					processingCount: currentCount + 1,
					isDuplicate: currentCount > 0,
					timestamp,
					timestampMs: timestamp,
					reason: rawData.reason || "no reason",
					callStack: new Error().stack.split("\n").slice(2, 5).join(" <- "),
				});
			}

			// Warn if this is a duplicate processing
			if (currentCount > 0) {
				console.warn(
					`[NewItemStreamProcessing] DUPLICATE PROCESSING DETECTED for ASIN ${asin} - processed ${currentCount + 1} times`,
					{
						enrollment_guid: data.enrollment_guid,
						reason: rawData.reason,
						timestamp: new Date().toISOString(),
					}
				);
			}
		}

		const title = this.#titleForKeywordMatch(data.title);

		// Use keyword matcher service (sync version)
		if (this.keywordMatcher) {
			const match = this.keywordMatcher.findHighlightHideMatchSync(title, data.etv_min, data.etv_max);
			if (match && match.type === "highlight") {
				rawData.item.data.KWsMatch = true;
				rawData.item.data.KW = match.contains ?? "";
				// Store groupId for custom color lookup (only for highlight type)
				if (match.groupId) {
					rawData.item.data.highlightGroupId = match.groupId;
					// Webhook is sent only when the matching group has webhook === true
					const groups = this.settingsManager.get("general.keywordGroups") || [];
					const group = groups.find((g) => g.id === match.groupId);
					rawData.item.data.KWsMatchWebhook = group && group.webhook === true;
					MonitorDebug.debugWebhookHighlightGroupWebhook(this.settingsManager, {
						asin: data.asin,
						groupId: match.groupId,
						groupFound: !!group,
						groupName: group?.name,
						webhook: group?.webhook,
						KWsMatchWebhook: rawData.item.data.KWsMatchWebhook,
					});
				} else {
					rawData.item.data.KWsMatchWebhook = false;
				}

				if (this.settingsManager.get("general.debugKeywords")) {
					console.log("[NewItemStreamProcessing] Item highlighted by keyword:", {
						asin: data.asin,
						title: data.title,
						keyword: match,
						groupId: match.groupId,
						timestamp: Date.now(),
					});
				}
			} else {
				rawData.item.data.KWsMatch = false;
				rawData.item.data.KW = "";
				rawData.item.data.KWsMatchWebhook = false;
			}
		} else {
			rawData.item.data.KWsMatch = false;
			rawData.item.data.KW = "";
			rawData.item.data.KWsMatchWebhook = false;
		}

		return rawData;
	}

	transformIsBlur(rawData) {
		if (!rawData.item) {
			return rawData; //Skip this transformer
		}
		const data = rawData.item.data;
		if (data.title == undefined) {
			return rawData; //Skip this transformer
		}

		// Use keyword matcher service (sync version)
		// Blur keywords are checked independently of highlight/hide status
		if (this.keywordMatcher) {
			const blurTitle = this.#titleForKeywordMatch(data.title);
			const blurKeyword = this.keywordMatcher.findBlurMatchSync(blurTitle, data.etv_min, data.etv_max);
			rawData.item.data.BlurKWsMatch = blurKeyword !== null;
			rawData.item.data.BlurKW = blurKeyword?.contains ?? "";
		} else {
			rawData.item.data.BlurKWsMatch = false;
			rawData.item.data.BlurKW = "";
		}

		return rawData;
	}

	transformSearchPhrase(rawData) {
		if (!rawData.item) {
			return rawData; //Skip this transformer
		}
		const data = rawData.item.data;
		if (data.title == undefined) {
			return rawData; //Skip this transformer
		}

		// Extract search phrase by taking only words that contain only letters and numbers
		// Split by spaces and filter out words with special characters
		/*
		const words = data.title.split(/\s+/);
		const cleanWords = words.filter((word) => /^[a-zA-Z0-9]+$/.test(word));
		const truncatedTitle = cleanWords.slice(0, 6).join(" ").substring(0, 40).trim();
		*/
		let truncatedTitle =
			data.title.length > 40 ? data.title.substr(0, 40).split(" ").slice(0, -1).join(" ") : data.title;
		// Decode HTML entities so "&amp;" is treated as "&" (a symbol), not the word "amp".
		truncatedTitle = unescapeHTML(String(truncatedTitle));
		// Keep word characters from all languages, drop punctuation/symbols (e.g., "°")
		// to avoid Vine search misses on unsupported characters.
		truncatedTitle = String(truncatedTitle)
			.normalize("NFC")
			.replace(/[^\p{L}\p{N}\s]/gu, " ")
			.replace(/\s+/g, " ")
			.trim();
		//Remove single letter words
		truncatedTitle = truncatedTitle
			.split(" ")
			.filter((word) => word.length > 1)
			.join(" ");

		rawData.item.data.search = truncatedTitle;
		return rawData;
	}

	transformUnixTimestamp(rawData) {
		if (!rawData.item) {
			return rawData; //Skip this transformer
		}
		const data = rawData.item.data;
		rawData.item.data.timestamp = this.dateToUnixTimestamp(data.date);
		return rawData;
	}

	transformPostNotification(rawData) {
		if (!rawData.item || !this.monitor || !this.monitor._isMasterMonitor) {
			return rawData; //Skip this transformer
		}
		const data = rawData.item.data;
		if (data.asin == undefined) {
			return rawData; //Skip this transformer
		}

		//If the new item match a highlight keyword, push a real notification.
		const KWNotification = this.pushNotifications && data.KWsMatch;
		const AFANotification = this.pushNotificationsAFA && data.queue == "last_chance";

		if (KWNotification || AFANotification) {
			//Create a new clean item with just the info needed to display the notification
			const item = new Item({
				asin: data.asin,
				queue: data.queue,
				is_parent_asin: data.is_parent_asin,
				is_pre_release: data.is_pre_release,
				enrollment_guid: data.enrollment_guid,
			});
			item.setTitle(data.title);
			item.setImgUrl(data.img_url);
			item.setSearch(data.search);

			if (KWNotification) {
				// Debug logging for OS notification triggered by keyword match
				if (this.settingsManager.get("general.debugKeywords")) {
					console.log("[NewItemStreamProcessing] OS notification triggered for keyword match:", {
						asin: data.asin,
						title: data.title,
						keyword: data.KW,
						KWsMatch: data.KWsMatch,
						timestamp: new Date().toISOString(),
					});
				}
				this.outputFunctions.push("VHelper - New item match KW!", item);
			} else if (AFANotification) {
				this.outputFunctions.push("VHelper - New AFA item", item);
			}
		}
		return rawData;
	}

	transformWebhook(rawData) {
		const debugWebhooks = !!this.settingsManager.get("general.debugWebhooks");
		if (!rawData.item || rawData.fetchLatest || !this.monitor || !this.monitor._isMasterMonitor) {
			if (debugWebhooks) {
				console.log("[WebhookFlow][SKIP]", {
					asin: rawData?.item?.data?.asin,
					reason: !rawData.item
						? "no item"
						: rawData.fetchLatest
							? "fetchLatest=true"
							: !this.monitor
								? "no monitor"
								: "not master monitor",
					fetchLatest: !!rawData.fetchLatest,
					isMaster: !!this.monitor?._isMasterMonitor,
					streamReason: rawData?.reason || "(none)",
					timestamp: new Date().toISOString(),
				});
			}
			if (rawData.item)
				MonitorDebug.debugWebhookTransformSkipped(this.settingsManager, {
					reason: !rawData.item
						? "no item"
						: rawData.fetchLatest
							? "fetchLatest"
							: !this.monitor
								? "no monitor"
								: "not master monitor",
					asin: rawData.item?.data?.asin,
					fetchLatest: !!rawData.fetchLatest,
					isMaster: !!this.monitor?._isMasterMonitor,
				});
			return rawData; //Skip this transformer
		}
		const data = rawData.item.data;
		// Read webhook settings at dispatch time so toggling in settings takes effect without reload
		const webhookAFAEnabled = this.settingsManager.get("discord.webhook.AFA.active");
		const webhookAFAUrl = this.settingsManager.get("discord.webhook.AFA.url");
		const webhookRFYEnabled = this.settingsManager.get("discord.webhook.RFY.active");
		const webhookRFYUrl = this.settingsManager.get("discord.webhook.RFY.url");
		const webhookKWsMatchUrl = this.settingsManager.get("discord.webhook.KWsMatch.url");

		const webhookKW = data.KWsMatchWebhook === true;
		const webhookAFA = webhookAFAEnabled && webhookAFAUrl && data.queue == "last_chance";
		const webhookRFY = webhookRFYEnabled && webhookRFYUrl && data.queue == "potluck";
		if (debugWebhooks) {
			console.log("[WebhookFlow][DECISION]", {
				asin: data.asin,
				title: data.title,
				queue: data.queue,
				webhookKW,
				webhookAFA,
				webhookRFY,
				KWsMatch: data.KWsMatch,
				KWsMatchWebhook: data.KWsMatchWebhook,
				streamReason: rawData?.reason || "(none)",
				fetchLatest: !!rawData.fetchLatest,
				activeUrls: {
					KW: webhookKWsMatchUrl,
					AFA: webhookAFAUrl,
					RFY: webhookRFYUrl,
				},
				timestamp: new Date().toISOString(),
			});
		}

		MonitorDebug.debugWebhookDecision(this.settingsManager, {
			asin: data.asin,
			queue: data.queue,
			webhookKW,
			webhookAFA,
			webhookRFY,
			KWsMatchWebhook: data.KWsMatchWebhook,
			webhookAFAEnabled: this.webhookAFAEnabled,
			webhookRFYEnabled: this.webhookRFYEnabled,
		});

		if (!webhookKW && !webhookAFA && !webhookRFY) {
			return rawData; //Skip this transformer
		}

		//Generate VHelper's URL to open the item
		const item = new Item(data);
		const VH_URL = item.getVHOpenModalURL();
		const VINE_SEARCH_URL = item.getVineSearchURL();
		const AMZ_URL = item.getAmazonURL();

		//Convert the queue (ie.: potluck, encore, last_chance, all_items) to the common abbreviation (ie.: RFY, AI, AFA, ALL)
		const QUEUE_NAME = queueToAbbr(data.queue);
		const TITLE = data.title;
		const IMG_URL = data.img_url;
		const ASIN = data.asin;

		//JSON data
		let body;
		const baseBody = `{
			"content": "New item in $QUEUE_NAME!",
			"embeds": [
				{
					"title": "$TITLE",
					"url": "$VH_URL",
					"thumbnail":  {
						"url": "$IMG_URL"
					}
				}
			]
		}`;

		if (webhookKW) {
			MonitorDebug.debugWebhookQueuingKWsMatch(this.settingsManager, {
				asin: ASIN,
				url: this.webhookKWsMatchUrl,
			});

			if (this.settingsManager.isPremiumUser(3)) {
				body = this.settingsManager.get("discord.webhook.KWsMatch.content");
			} else {
				body = baseBody;
			}
			body = body.replaceAll("$QUEUE_NAME", QUEUE_NAME);
			body = body.replaceAll("$TITLE", TITLE);
			body = body.replaceAll("$IMG_URL", IMG_URL);
			body = body.replaceAll("$ASIN", ASIN);
			body = body.replaceAll("$VH_URL", VH_URL);
			body = body.replaceAll("$VINE_SEARCH_URL", VINE_SEARCH_URL);
			body = body.replaceAll("$AMZ_URL", AMZ_URL);

			const fingerprint = `${ASIN}|KW|${webhookKWsMatchUrl || "(no-url)"}`;
			const nextCount = (this.webhookDispatchCounts.get(fingerprint) || 0) + 1;
			this.webhookDispatchCounts.set(fingerprint, nextCount);
			if (debugWebhooks) {
				console.log("[WebhookFlow][QUEUE_KW]", {
					fingerprint,
					dispatchCountForFingerprint: nextCount,
					asin: ASIN,
					queue: data.queue,
					streamReason: rawData?.reason || "(none)",
					url: webhookKWsMatchUrl,
					bodyPreview: typeof body === "string" ? body.substring(0, 220) : "(non-string body)",
					timestamp: new Date().toISOString(),
				});
			}
			//Send the data to the webhook
			this.webhookQueue.queue(webhookKWsMatchUrl, {
				method: this.settingsManager.isPremiumUser(3)
					? this.settingsManager.get("discord.webhook.KWsMatch.method")
					: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: body,
			});
		}
		if (webhookAFA) {
			if (this.settingsManager.isPremiumUser(3)) {
				body = this.settingsManager.get("discord.webhook.AFA.content");
			} else {
				body = baseBody;
			}
			body = body.replaceAll("$QUEUE_NAME", QUEUE_NAME);
			body = body.replaceAll("$TITLE", TITLE);
			body = body.replaceAll("$IMG_URL", IMG_URL);
			body = body.replaceAll("$ASIN", ASIN);
			body = body.replaceAll("$VH_URL", VH_URL);
			body = body.replaceAll("$VINE_SEARCH_URL", VINE_SEARCH_URL);
			body = body.replaceAll("$AMZ_URL", AMZ_URL);

			const fingerprint = `${ASIN}|AFA|${this.webhookAFAUrl || "(no-url)"}`;
			const nextCount = (this.webhookDispatchCounts.get(fingerprint) || 0) + 1;
			this.webhookDispatchCounts.set(fingerprint, nextCount);
			if (debugWebhooks) {
				console.log("[WebhookFlow][QUEUE_AFA]", {
					fingerprint,
					dispatchCountForFingerprint: nextCount,
					asin: ASIN,
					queue: data.queue,
					streamReason: rawData?.reason || "(none)",
					url: this.webhookAFAUrl,
					bodyPreview: typeof body === "string" ? body.substring(0, 220) : "(non-string body)",
					timestamp: new Date().toISOString(),
				});
			}
			MonitorDebug.debugWebhookQueuingAFA(this.settingsManager, { asin: ASIN, url: this.webhookAFAUrl });
			this.webhookQueue.queue(this.webhookAFAUrl, {
				method: this.settingsManager.isPremiumUser(3)
					? this.settingsManager.get("discord.webhook.AFA.method")
					: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: body,
			});
		}
		if (webhookRFY) {
			if (this.settingsManager.isPremiumUser(3)) {
				body = this.settingsManager.get("discord.webhook.RFY.content");
			} else {
				body = baseBody;
			}
			body = body.replaceAll("$QUEUE_NAME", QUEUE_NAME);
			body = body.replaceAll("$TITLE", TITLE);
			body = body.replaceAll("$IMG_URL", IMG_URL);
			body = body.replaceAll("$ASIN", ASIN);
			body = body.replaceAll("$VH_URL", VH_URL);
			body = body.replaceAll("$VINE_SEARCH_URL", VINE_SEARCH_URL);
			body = body.replaceAll("$AMZ_URL", AMZ_URL);

			const fingerprint = `${ASIN}|RFY|${this.webhookRFYUrl || "(no-url)"}`;
			const nextCount = (this.webhookDispatchCounts.get(fingerprint) || 0) + 1;
			this.webhookDispatchCounts.set(fingerprint, nextCount);
			if (debugWebhooks) {
				console.log("[WebhookFlow][QUEUE_RFY]", {
					fingerprint,
					dispatchCountForFingerprint: nextCount,
					asin: ASIN,
					queue: data.queue,
					streamReason: rawData?.reason || "(none)",
					url: this.webhookRFYUrl,
					bodyPreview: typeof body === "string" ? body.substring(0, 220) : "(non-string body)",
					timestamp: new Date().toISOString(),
				});
			}
			MonitorDebug.debugWebhookQueuingRFY(this.settingsManager, { asin: ASIN, url: this.webhookRFYUrl });
			this.webhookQueue.queue(this.webhookRFYUrl, {
				method: this.settingsManager.isPremiumUser(3)
					? this.settingsManager.get("discord.webhook.RFY.method")
					: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: body,
			});
		}
		return rawData;
	}

	setupPipeline() {
		const filterHideitem = this.dataStream.filter((rawData) => this.filterHideItem(rawData));
		const transformIsHighlight = this.dataStream.transformer((rawData) => this.transformIsHighlight(rawData));
		const transformIsBlur = this.dataStream.transformer((rawData) => this.transformIsBlur(rawData));
		const transformSearchPhrase = this.dataStream.transformer((rawData) => this.transformSearchPhrase(rawData));
		const transformUnixTimestamp = this.dataStream.transformer((rawData) => this.transformUnixTimestamp(rawData));
		const transformPostNotification = this.dataStream.transformer((rawData) =>
			this.transformPostNotification(rawData)
		);
		const transformWebhook = this.dataStream.transformer((rawData) => this.transformWebhook(rawData));

		this.dataStream
			.pipe(transformIsHighlight) //Highlight keywords first...
			.pipe(filterHideitem) // ... then figure out if we can hide the item
			.pipe(transformIsBlur)
			.pipe(transformSearchPhrase)
			.pipe(transformUnixTimestamp)
			.pipe(transformPostNotification)
			.pipe(transformWebhook)
			.output((data) => {
				//Broadcast the notification
				this.outputFunctions.broadcast(data, "notification");
			});
	}

	dateToUnixTimestamp(dateString) {
		// Use the proper date parsing utilities instead of Safari-incompatible string concatenation
		const date = YMDHiStoISODate(dateString);
		return DateToUnixTimeStamp(date);
	}

	setBroadcastFunction(fct) {
		this.outputFunctions.broadcast = fct;
	}

	setNotificationPushFunction(fct) {
		this.outputFunctions.push = fct;
	}

	input(data) {
		// Diagnostic logging for stream input
		if (this.settingsManager.get("general.debugKeywords") && data.item) {
			const timestamp = Date.now();
			console.log("[NewItemStreamProcessing] Stream input received:", {
				asin: data.item.data?.asin,
				title: data.item.data?.title?.substring(0, 50) + "...",
				type: data.type,
				reason: data.reason,
				timestamp,
				timestampMs: timestamp,
			});
		}
		if (!this.#pipelineReady) {
			this.#pendingInput.push(data);
			return;
		}
		this.dataStream.input(data);
	}

	// Expose compiled keywords for testing
	getCompiledKeywords() {
		return {
			hideKeywords: this.compiledHideKeywords,
			highlightKeywords: this.compiledHighlightKeywords,
			blurKeywords: this.compiledBlurKeywords,
		};
	}
}

function queueToAbbr(queue) {
	const arr = {
		potluck: "RFY",
		encore: "AI",
		last_chance: "AFA",
		all_items: "ALL",
	};

	return arr[queue];
}

export { NewItemStreamProcessing };
