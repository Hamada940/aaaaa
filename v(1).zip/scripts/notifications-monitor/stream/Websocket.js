/*global chrome*/

const DEBUG_MODE = false;
const VHELPER_API_V5_WS_URL = "wss://api.v-helper.com";
//const VHELPER_API_V5_WS_URL = "ws://127.0.0.1:3000";
const VHELPER_API_V5_WS_FALLBACK_URL = "wss://api.vinehelper.ovh";
const WSReconnectInterval = 10 * 1000; //10 seconds
const WS_ENGINE_SILENCE_MS = 2 * 60 * 1000;
const WS_MAX_CONNECTION_AGE_MS = 3 * 60 * 60 * 1000;
const WS_PROBE_INTERVAL_MS = 15 * 60 * 1000;
const WS_PROBE_TIMEOUT_MS = 30 * 1000;
const WS_BROADCAST_SYNC_INTERVAL_MS = 60 * 1000;

import { io } from "/scripts/vendor/socket.io/client-dist/socket.io.esm.min.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { Internationalization } from "/scripts/core/services/Internationalization.js";
import { Environment } from "/scripts/core/services/Environment.js";
import { shouldReconnectForBroadcastMismatch } from "/scripts/notifications-monitor/stream/broadcastSync.js";

var Settings = new SettingsMgr();
var env = new Environment();
var i18n = new Internationalization();

function getWebsocketUrl() {
	const until = Settings.get("general.apiFallbackUntil", 0);
	if (typeof until === "number" && until > Date.now()) {
		return VHELPER_API_V5_WS_FALLBACK_URL;
	}
	return VHELPER_API_V5_WS_URL;
}

class Websocket {
	static #instance = null;

	#socket = null;
	#socket_connecting = false;
	#reconnectTimer = null;
	#socketHandlers = null;
	#messageRelayer = null;
	#isDestroyed = false;
	#lifecycleToken = 0;

	#connectionDetails = {};
	#connectedAt = 0;
	#lastEngineActivityAt = 0;
	#lastApplicationMessageAt = 0;
	#lastProbeAt = 0;
	#lastBroadcastSyncAt = 0;
	#lastReceivedBroadcastAsin = null;
	#lastReceivedBroadcastAt = null;
	#probeInFlight = false;
	#probeTimer = null;
	// #hadSuccessfulConnection = false;
	#engineActivityHandler = null;
	#engine = null;

	/**
	 * Constructor
	 * @param {WebsocketRelayInterface} messageRelayer Instance of one of the WebsocketRelay classes. Used to relay messages to the monitor.
	 */
	constructor(messageRelayer) {
		if (Websocket.#instance) {
			return Websocket.#instance;
		}
		Websocket.#instance = this;
		this.#isDestroyed = false;
		this.#messageRelayer = messageRelayer;
		this.#init();
		this.#createReconnectTimer();
	}

	getConnectionDetails() {
		return this.#connectionDetails;
	}

	async #init() {
		const lifecycleToken = this.#lifecycleToken;
		if (this.#isLifecycleObsolete(lifecycleToken)) {
			return;
		}

		try {
			await Settings.refresh();
			if (this.#isLifecycleObsolete(lifecycleToken)) {
				return;
			}
			i18n.setCountryCode(DEBUG_MODE ? "com" : await Settings.get("general.country"));
		} catch (e) {
			if (this.#isLifecycleObsolete(lifecycleToken)) {
				return;
			}
			//Will catch an error from ChromeStorageAdapter.get() if the storage is not accessible
			this.#messageRelayer.relayMessage({ type: "outOfContext" });
		}
		if (this.#isLifecycleObsolete(lifecycleToken)) {
			return;
		}

		if (!Settings.get("notification.active")) {
			this.#socket?.disconnect();
			return;
		}

		// If the socket is already connected, do not connect again
		if (this.#socket?.connected) {
			return;
		}

		if (i18n.getCountryCode() === null) {
			console.error("Country not known, refresh/load a vine page.");
			return; //If the country is not known, do not connect
		}

		if (this.#socket_connecting) {
			if (Settings.get("general.debugWebsocket")) {
				console.log(`${new Date().toLocaleString()} - WS already connecting, skipping.`);
			}
			return;
		}

		// Clean up any existing socket instance before creating a new one
		if (this.#socket) {
			this.#cleanupSocketListeners();
			this.#socket.removeAllListeners();
			this.#socket.disconnect();
			this.#socket = null;
		}

		this.#socket_connecting = true;
		const uuid = await Settings.get("general.uuid", false);
		const fid = await Settings.get("general.fingerprint.id", false);
		const cid = await Settings.get("general.cid", false);
		const deviceName = await Settings.get("general.deviceName", false);
		if (this.#isLifecycleObsolete(lifecycleToken)) {
			this.#socket_connecting = false;
			return;
		}
		this.#socket = io.connect(getWebsocketUrl(), {
			query: {
				app_version: chrome.runtime.getManifest().version,
				countryCode: DEBUG_MODE ? "com" : i18n.getCountryCode(),
				uuid: uuid,
				fid: fid,
				cid: cid,
				device_name: deviceName,
			}, // Pass the country code as a query parameter
			transports: ["websocket"],
			reconnection: false, //Handled manually every 30 seconds.
		});

		//## PASS ALL RECEIVED DATA TO THE MESSAGING CHANNEL #########################

		// Clean up any existing listeners before adding new ones
		this.#cleanupSocketListeners();

		// Define named handlers to reduce memory overhead and improve debugging
		this.#socketHandlers = {
			connect: () => {
				this.#socket_connecting = false;
				this.#connectedAt = Date.now();
				this.#touchEngineActivity();
				this.#attachEngineActivityMonitor();
				if (Settings.get("general.debugWebsocket")) {
					console.log(`${new Date().toLocaleString()} - WS Connected`);
				}
				this.#messageRelayer.relayMessage({ type: "wsStatus", status: "wsOpen" });
				// if (this.#hadSuccessfulConnection) {
				// 	void this.processMessage({ type: "fetchLatestItems", limit: 100 });
				// }
				// this.#hadSuccessfulConnection = true;
			},

			newItem: (data) => {
				this.#markApplicationActivity();
				if (data?.item?.asin) {
					this.#lastReceivedBroadcastAsin = data.item.asin;
					this.#lastReceivedBroadcastAt = new Date().toISOString(); //UTC timezone to compare with the server's
				}
				if (Settings.get("general.debugWebsocket")) {
					console.log("[WebSocket] Received newItem", {
						asin: data.item?.asin,
						hasImgUrl: !!data.item?.img_url,
						imgUrl: data.item?.img_url,
						itemKeys: data.item ? Object.keys(data.item) : [],
					});
				}

				this.#messageRelayer.relayMessage({ type: "newPreprocessedItem", item: data.item });
			},

			connection_info: (data) => {
				this.#markApplicationActivity();
				this.#connectionDetails = {
					...data,
					socketId: data?.socketId || this.#socket?.id,
				};
			},

			last100: (data) => {
				this.#markApplicationActivity();
				this.#completeHealthProbe();
				this.#messageRelayer.relayMessage({ type: "last100", products: data.products });
			},

			newETV: (data) => {
				this.#markApplicationActivity();
				this.#messageRelayer.relayMessage({ type: "newETV", item: data.item });
			},

			newPrice: (data) => {
				this.#markApplicationActivity();
				this.#messageRelayer.relayMessage({ type: "newPrice", item: data.item });
			},

			newVariants: (data) => {
				this.#markApplicationActivity();
				this.#messageRelayer.relayMessage({ type: "newVariants", item: data });
			},

			unavailableItem: (data) => {
				this.#markApplicationActivity();
				this.#messageRelayer.relayMessage({ type: "unavailableItem", item: data.item });
			},

			reloadPage: async (data) => {
				this.#markApplicationActivity();
				this.#messageRelayer.relayMessage({ type: "fetchAutoLoadUrl", queue: data.queue, page: data.page });
			},

			orderAttempts: (data) => {
				this.#markApplicationActivity();
				this.#messageRelayer.relayMessage({ type: "orderAttempts", data: data.item });
			},

			//This is called when the server force-disconnects the client
			serverDisconnect: (data) => {
				// Server-initiated disconnect - stop reconnection and show specific message
				this.#socket_connecting = false;

				// Deactivate the reconnection timer when server disconnects us
				if (this.#reconnectTimer) {
					clearInterval(this.#reconnectTimer);
					this.#reconnectTimer = null;
				}

				if (Settings.get("general.debugWebsocket")) {
					console.log(`${new Date().toLocaleString()} - Server disconnected the client`);
				}
				this.#messageRelayer.relayMessage({
					type: "wsStatus",
					status: "wsError",
					error:
						data.message ||
						"Remotely disconnected, reload the page. Upgrade your membership to get more connections",
				});

				// Ensure no orphaned connection remains after server denial.
				if (this.#socket) {
					this.#cleanupSocketListeners();
					this.#socket.removeAllListeners();
					this.#socket.disconnect();
					this.#socket = null;
				}

				this.#connectionDetails = {};
			},

			connection_error: async (error) => {
				const msg = error?.message || "Connection error";
				const invalid = error?.invalid_uuid === true || msg === "UUID does not exist" || msg === "Old UUID";
				if (invalid) {
					await env.recoverFromInvalidUuid();
				}
				//Errors from the API
				// Only pass minimal error info to prevent retaining large error objects
				this.#messageRelayer.relayMessage({
					type: "wsStatus",
					status: "wsError",
					error: msg,
				});
			},

			disconnect: () => {
				this.#socket_connecting = false;
				this.#detachEngineActivityMonitor();
				this.#connectedAt = 0;
				if (Settings.get("general.debugWebsocket")) {
					console.log(`${new Date().toLocaleString()} - Socket.IO Disconnected`);
				}
				this.#messageRelayer.relayMessage({ type: "wsStatus", status: "wsClosed" });
				this.#connectionDetails = {};
			},

			connect_error: (error) => {
				//Errors from the protocol
				this.#socket_connecting = false;
				// Extract only the message to avoid retaining the full error object
				//If the error message is an object, serialize it to a string
				let errorMessage;
				if (typeof error.message === "object") {
					errorMessage = JSON.stringify(error.message) + " when connecting to " + getWebsocketUrl();
				} else {
					errorMessage = error.message + " when connecting to " + getWebsocketUrl() || "Unknown error";
				}
				this.#messageRelayer.relayMessage({ type: "wsStatus", status: "wsError", error: errorMessage });
				console.error(`${new Date().toLocaleString()} - Socket.IO error: ${errorMessage}`);
			},

			broadcastSyncPong: (data) => {
				this.#markApplicationActivity();
				this.#handleBroadcastSyncPong(data);
			},
		};

		// Attach all handlers
		Object.entries(this.#socketHandlers).forEach(([event, handler]) => {
			this.#socket.on(event, handler);
		});
	}

	#createReconnectTimer() {
		// Clear any existing intervals
		if (this.#reconnectTimer) {
			clearInterval(this.#reconnectTimer);
		}
		// Create interval to check connection every WSReconnectInterval minutes
		this.#reconnectTimer = setInterval(() => {
			if (this.#isDestroyed) {
				return;
			}
			this.#checkConnectionHealth();
			this.#init();
		}, WSReconnectInterval); // Convert minutes to milliseconds
	}

	async processMessage(message) {
		if (this.#isDestroyed) {
			return;
		}
		//The service worker is passing along a request to fetch the latest items
		if (message.type === "fetchLatestItems") {
			//Get the last 100 most recent items
			if (this.#socket?.connected) {
				this.#socket.emit("getLast100", {
					app_version: chrome.runtime.getManifest().version,
					uuid: await Settings.get("general.uuid", false),
					cid: await Settings.get("general.cid", false),
					fid: await Settings.get("general.fingerprint.id", false),
					countryCode: DEBUG_MODE ? "com" : i18n.getCountryCode(),
					limit: message.limit || 100,
					request_variants: Settings.isPremiumUser(2) && Settings.get("general.displayVariantButton"),
				});
			} else {
				console.warn("Socket not connected - cannot fetch last 100 items");
			}
		}

		if (message.type === "disconnectRequest") {
			this.#socket.emit("disconnectRequest", message);
		}

		//The service worker is passing along a request to report the websocket status
		if (message.type === "wsStatus" && message.status === undefined) {
			const healthy = this.#isTransportHealthy();
			this.#messageRelayer.relayMessage({
				type: "wsStatus",
				status: healthy ? "wsOpen" : "wsClosed",
			});
			if (this.#socket?.connected && !healthy) {
				void this.#forceReconnect("Connection health check failed");
			}
		}

		if (message.type === "reloadRequest") {
			this.#socket.emit("reloadRequest", {
				uuid: message.uuid,
				cid: message.cid || null,
				fid: message.fid,
				countryCode: message.countryCode,
			});
		}

		//The notification monitor is being loaded, ensure the reconnect timer is running
		if (message.type === "wsConnect") {
			this.#messageRelayer.relayMessage({
				type: "wsStatus",
				status: "wsError",
				error: "Reconnecting in a few seconds...",
			});
			this.#createReconnectTimer();
		}
	}

	isConnected() {
		return this.#socket?.connected || false;
	}

	emit(type, data) {
		this.#socket.emit(type, data);
	}

	disconnect() {
		this.#socket.disconnect();
	}

	destroyInstance() {
		this.#isDestroyed = true;
		this.#lifecycleToken++;
		this.#clearProbeTimer();
		this.#detachEngineActivityMonitor();

		// Notify UI that the socket is closed before tearing down (so status icon updates; disconnect event won't fire after removeAllListeners)
		this.#messageRelayer?.relayMessage({ type: "wsStatus", status: "wsClosed" });

		// Clear the reconnect timer
		if (this.#reconnectTimer) {
			clearInterval(this.#reconnectTimer);
			this.#reconnectTimer = null;
		}

		// Remove all event listeners
		if (this.#socket) {
			this.#socket.removeAllListeners();
			this.#socket.disconnect();
			this.#socket = null;
		}

		this.#socket_connecting = false;
		Websocket.#instance = null;
	}

	#isLifecycleObsolete(lifecycleToken) {
		return this.#isDestroyed || lifecycleToken !== this.#lifecycleToken;
	}

	/**
	 * Clean up socket event listeners before re-adding them
	 */
	#cleanupSocketListeners() {
		this.#detachEngineActivityMonitor();
		if (this.#socket && this.#socketHandlers) {
			// Remove all handlers using the same references
			Object.entries(this.#socketHandlers).forEach(([event, handler]) => {
				this.#socket.off(event, handler);
			});
		}
		// Clear the handlers object to free memory
		this.#socketHandlers = null;
	}

	#touchEngineActivity() {
		this.#lastEngineActivityAt = Date.now();
	}

	#markApplicationActivity() {
		this.#touchEngineActivity();
		this.#lastApplicationMessageAt = Date.now();
	}

	#attachEngineActivityMonitor() {
		this.#detachEngineActivityMonitor();
		const engine = this.#socket?.io?.engine;
		if (!engine || typeof engine.on !== "function") {
			return;
		}
		this.#engine = engine;
		this.#engineActivityHandler = () => this.#touchEngineActivity();
		engine.on("packet", this.#engineActivityHandler);
		engine.on("ping", this.#engineActivityHandler);
		engine.on("pong", this.#engineActivityHandler);
	}

	#detachEngineActivityMonitor() {
		if (this.#engine && this.#engineActivityHandler) {
			this.#engine.off("packet", this.#engineActivityHandler);
			this.#engine.off("ping", this.#engineActivityHandler);
			this.#engine.off("pong", this.#engineActivityHandler);
		}
		this.#engine = null;
		this.#engineActivityHandler = null;
	}

	#isTransportHealthy() {
		if (!this.#socket?.connected) {
			return false;
		}
		const engine = this.#socket?.io?.engine;
		if (!engine) {
			return true;
		}
		if (engine.readyState && engine.readyState !== "open") {
			return false;
		}
		if (this.#lastEngineActivityAt > 0 && Date.now() - this.#lastEngineActivityAt > WS_ENGINE_SILENCE_MS) {
			return false;
		}
		return true;
	}

	#checkConnectionHealth() {
		if (!this.#socket?.connected || this.#socket_connecting) {
			return;
		}
		if (!this.#isTransportHealthy()) {
			void this.#forceReconnect("Transport inactive");
			return;
		}
		if (this.#connectedAt > 0 && Date.now() - this.#connectedAt > WS_MAX_CONNECTION_AGE_MS) {
			void this.#forceReconnect("Periodic connection refresh");
			return;
		}
		this.#maybeRunBroadcastSync();
		this.#maybeRunHealthProbe();
	}

	#maybeRunBroadcastSync() {
		if (!this.#socket?.connected) {
			return;
		}
		if (Date.now() - this.#lastBroadcastSyncAt < WS_BROADCAST_SYNC_INTERVAL_MS) {
			return;
		}
		this.#lastBroadcastSyncAt = Date.now();
		this.#socket.emit("broadcastSyncPing");
	}

	#handleBroadcastSyncPong(data) {
		if (
			!shouldReconnectForBroadcastMismatch(data, {
				asin: this.#lastReceivedBroadcastAsin,
				timestamp: this.#lastReceivedBroadcastAt,
			})
		) {
			return;
		}
		if (Settings.get("general.debugWebsocket")) {
			console.warn(`${new Date().toLocaleString()} - WS broadcast sync mismatch`, {
				server: data,
				local: {
					asin: this.#lastReceivedBroadcastAsin,
					timestamp: this.#lastReceivedBroadcastAt,
				},
			});
		}
		void this.#forceReconnect("Broadcast sync mismatch");
	}

	async #maybeRunHealthProbe() {
		if (!this.#socket?.connected || this.#probeInFlight) {
			return;
		}
		if (Date.now() - this.#lastApplicationMessageAt < WS_PROBE_INTERVAL_MS) {
			return;
		}
		if (Date.now() - this.#lastProbeAt < WS_PROBE_INTERVAL_MS) {
			return;
		}
		this.#lastProbeAt = Date.now();
		this.#probeInFlight = true;
		this.#clearProbeTimer();
		this.#probeTimer = setTimeout(() => {
			this.#probeInFlight = false;
			if (this.#socket?.connected) {
				void this.#forceReconnect("Server health probe timed out");
			}
		}, WS_PROBE_TIMEOUT_MS);
		try {
			this.#socket.emit("getLast100", {
				app_version: chrome.runtime.getManifest().version,
				uuid: await Settings.get("general.uuid", false),
				cid: await Settings.get("general.cid", false),
				fid: await Settings.get("general.fingerprint.id", false),
				countryCode: DEBUG_MODE ? "com" : i18n.getCountryCode(),
				limit: 1,
				request_variants: Settings.isPremiumUser(2) && Settings.get("general.displayVariantButton"),
			});
		} catch {
			this.#completeHealthProbe();
		}
	}

	#completeHealthProbe() {
		if (!this.#probeInFlight) {
			return;
		}
		this.#probeInFlight = false;
		this.#clearProbeTimer();
	}

	#clearProbeTimer() {
		if (this.#probeTimer) {
			clearTimeout(this.#probeTimer);
			this.#probeTimer = null;
		}
	}

	async #forceReconnect(reason) {
		if (this.#isDestroyed) {
			return;
		}
		if (Settings.get("general.debugWebsocket")) {
			console.warn(`${new Date().toLocaleString()} - WS force reconnect: ${reason}`);
		}
		this.#completeHealthProbe();
		this.#socket_connecting = false;
		this.#connectedAt = 0;
		this.#messageRelayer.relayMessage({
			type: "wsStatus",
			status: "wsError",
			error: "Reconnecting live feed...",
		});
		if (this.#socket) {
			this.#cleanupSocketListeners();
			this.#socket.removeAllListeners();
			this.#socket.disconnect();
			this.#socket = null;
		}
		this.#connectionDetails = {};
		await this.#init();
	}
}

export { Websocket };
