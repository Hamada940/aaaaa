/*global chrome*/

import { AutoLoadCore } from "./AutoLoadCore.js";
import { getPageCount } from "/scripts/core/utils/VinePageCountParser.js";
import { getFavouriteCategories, formatFavouriteLabel } from "/scripts/core/utils/FavouriteCategoriesManager.js";
import {
	loadFavouriteProgress,
	saveFavouriteProgress,
	getNextPageForFavourite,
	advanceFavouriteProgress,
	reconcileFavouriteProgress,
	resetFavouriteProgress,
	didCompleteFavouriteRun,
} from "/scripts/core/utils/FavouriteCategoryProgress.js";

/**
 * Assisted-load handler for starred favourite subcategories (FAV queue).
 *
 * @module AutoLoadFAV
 */
class AutoLoadFAV extends AutoLoadCore {
	static #instance = null;
	static #DELAY_1_HOUR_MS = 60 * 60 * 1000;
	static #DELAY_24_HOURS_MS = 24 * 60 * 60 * 1000;

	#channelMessageHandler = null;
	#progress = null;
	#runInProgress = false;
	#drainUntilComplete = false;
	#wasBoostMode = false;

	constructor(monitor) {
		super(monitor);
		if (AutoLoadFAV.#instance) {
			return AutoLoadFAV.#instance;
		}
		AutoLoadFAV.#instance = this;
		this.#createListener();
		void this.#ensureProgress();
		this.#armFAVTimer(true);
	}

	async onItemsDroppingChanged() {
		const boostNow = this.#isBoostMode();
		const boostStateChanged = boostNow !== this.#wasBoostMode;
		if (!boostStateChanged) {
			return;
		}

		if (boostNow) {
			if (!this.#runInProgress && !this.#drainUntilComplete) {
				await this.#resetRunForBoost();
			} else {
				this.#runInProgress = true;
				this.#drainUntilComplete = false;
			}
			this.#armFAVTimer(true);
		} else if (this.#runInProgress) {
			this.#drainUntilComplete = true;
			this.#armFAVTimer(true);
		} else {
			this.#armFAVTimer(false);
		}

		this.#wasBoostMode = boostNow;
	}

	#isBoostMode() {
		return this._monitor._autoLoad?.getItemsDropping?.() === true;
	}

	async #resetRunForBoost() {
		this.#progress = resetFavouriteProgress();
		await saveFavouriteProgress(this.#progress);
		this.#runInProgress = true;
		this.#drainUntilComplete = false;
	}

	#createListener() {
		this.#channelMessageHandler = async (event) => {
			const data = await this._monitor._cryptoKeys.decryptToJSON(event.data);
			this.processMessage(data);
		};
		this._monitor._channel.addEventListener("message", this.#channelMessageHandler);
	}

	async #ensureProgress() {
		const favourites = getFavouriteCategories(this._monitor._settings);
		this.#progress = reconcileFavouriteProgress(await loadFavouriteProgress(), favourites);
	}

	#shouldRunFAVLoad() {
		const favourites = getFavouriteCategories(this._monitor._settings);
		return (
			this._monitor._isMasterMonitor &&
			this._monitor._settings.get("notification.active") &&
			favourites.length > 0 &&
			(this.#isBoostMode() || this.#drainUntilComplete) &&
			!this._monitor._autoLoadScheduler?.isAssistedLoadSuspended?.()
		);
	}

	#getNextIntervalMs() {
		let minSec = this._monitor._settings.get("notification.autoload.favMin");
		let maxSec = this._monitor._settings.get("notification.autoload.favMax");
		if (minSec == null || minSec < 10) minSec = 30;
		if (maxSec == null || maxSec > 180) maxSec = 60;
		minSec = Math.max(10, Math.min(180, minSec));
		maxSec = Math.max(10, Math.min(180, maxSec));
		if (minSec > maxSec) maxSec = minSec;
		return Math.floor(Math.random() * (maxSec - minSec + 1) + minSec) * 1000;
	}

	#armFAVTimer(firstTime = false, overrideDelayMs) {
		const scheduler = this._monitor._autoLoadScheduler;
		if (!scheduler) return;

		if (!overrideDelayMs && !this.#shouldRunFAVLoad()) {
			scheduler.cancelType("FAV");
			return;
		}

		let label = "FAV";
		let fav;
		let page = 1;
		const favourites = getFavouriteCategories(this._monitor._settings);
		if (!overrideDelayMs) {
			const idx = Math.min(this.#progress?.currentIndex ?? 0, Math.max(favourites.length - 1, 0));
			fav = favourites[idx];
			if (!fav) {
				scheduler.cancelType("FAV");
				return;
			}
			page = getNextPageForFavourite(this.#progress ?? { currentIndex: 0, pages: {} }, fav.pn, fav.cn);
			label = `${formatFavouriteLabel(fav)}, P.${page}`;
		}

		const delayMs = overrideDelayMs ?? this.#getNextIntervalMs();
		const favSnapshot = fav;
		const pageSnapshot = page;

		scheduler.schedule({
			type: "FAV",
			label,
			desiredAt: new Date(Date.now() + delayMs),
			execute: async () => {
				if (overrideDelayMs) {
					this.#armFAVTimer(false);
					return;
				}
				if (!firstTime && favSnapshot) {
					const shouldRearm = await this.#loadFavourite(favSnapshot, pageSnapshot);
					if (!shouldRearm) return;
				}
				this.#armFAVTimer(false);
			},
		});
		void this.updateNextAssistedLoadDate();
	}

	async #loadFavourite(fav, page) {
		const tld = this._monitor._i18nMgr.getDomainTLD();
		const url = `https://www.amazon.${tld}/vine/vine-items?queue=encore&pn=${fav.pn}&cn=${fav.cn}&page=${page}`;
		const displayLabel = formatFavouriteLabel(fav);
		let pageCount = 1;
		try {
			await this.fetchAutoLoadUrl(url, "AI", page, null, null, displayLabel, (doc) => {
				pageCount = getPageCount(doc);
			});
			if (!this.#progress) {
				await this.#ensureProgress();
			}
			if (this.#progress) {
				const favourites = getFavouriteCategories(this._monitor._settings);
				this.#progress = advanceFavouriteProgress(this.#progress, favourites, fav.pn, fav.cn, page, pageCount);
				await saveFavouriteProgress(this.#progress);
				if (didCompleteFavouriteRun(favourites, fav.pn, fav.cn, page, pageCount)) {
					this.#runInProgress = false;
					this.#drainUntilComplete = false;
				}
			}
			return true;
		} catch (error) {
			if (error.message == "dog_page") this.#dogPageDetected();
			else if (error.message == "captcha_page") this.#captchaPageDetected();
			else if (error.message == "login_page") this.#loginPageDetected();
			else throw error;
			return false;
		}
	}

	#suspendAssistedLoad(reason, delayMs) {
		this._monitor._autoLoadScheduler?.setAssistedLoadSuspension(reason, delayMs);
		this.#armFAVTimer(false, delayMs);
	}

	#dogPageDetected() {
		console.log(`${new Date().toLocaleString()} - Dog page detected (FAV).`);
		this.#suspendAssistedLoad("dog", AutoLoadFAV.#DELAY_24_HOURS_MS);
	}

	#captchaPageDetected() {
		console.log(`${new Date().toLocaleString()} - Captcha page detected (FAV).`);
		this.#suspendAssistedLoad("captcha", AutoLoadFAV.#DELAY_1_HOUR_MS);
	}

	#loginPageDetected() {
		console.log(`${new Date().toLocaleString()} - Login page detected (FAV).`);
		this.#suspendAssistedLoad("login", AutoLoadFAV.#DELAY_1_HOUR_MS);
	}

	processMessage(message) {
		if (message.type === "dogpage") this.#suspendAssistedLoad("dog", AutoLoadFAV.#DELAY_24_HOURS_MS);
		if (message.type === "captchapage") this.#suspendAssistedLoad("captcha", AutoLoadFAV.#DELAY_1_HOUR_MS);
		if (message.type === "loginpage") this.#suspendAssistedLoad("login", AutoLoadFAV.#DELAY_1_HOUR_MS);
	}

	destroy() {
		this._monitor._autoLoadScheduler?.cancelType("FAV");
		if (this.#channelMessageHandler && this._monitor._channel) {
			this._monitor._channel.removeEventListener("message", this.#channelMessageHandler);
			this.#channelMessageHandler = null;
		}
		AutoLoadFAV.#instance = null;
	}
}

export { AutoLoadFAV };
