import { isPageLogin, isPageCaptcha, isPageDog } from "/scripts/core/utils/DOMHelper.js";
import { parseTilesFromDocument } from "/scripts/core/amazon/parsers/tiles.js";
import { parseVvpContextFromDocument } from "/scripts/core/amazon/parsers/vvpContext.js";
import { getInfoPageParam } from "/scripts/core/utils/VineBrowseContext.js";
import { Logger } from "/scripts/core/utils/Logger.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";

const logger = new Logger();
/**
 * Format the monitor "Next assisted load" value (time only; queue type lives in the tooltip).
 *
 * @param {Date|null} nextExecuteTime
 * @param {(date: Date, timeOnly?: boolean) => string} formatDate
 * @returns {string}
 */
export function formatNextAssistedLoadDisplayTime(nextExecuteTime, formatDate) {
	if (!nextExecuteTime) {
		return "(tba)";
	}
	return `~${formatDate(nextExecuteTime, true)}`;
}

/**
 * Update the "Last assisted load" monitor field with truncation-friendly tooltip support.
 *
 * @param {HTMLElement} element
 * @param {string} text
 */
export function setLastAssistedLoadElement(element, text) {
	element.textContent = text;
	if (text && text !== "(tba)") {
		element.setAttribute("title", text);
	} else {
		element.removeAttribute("title");
	}
}

class AutoLoadCore {
	_monitor = null;

	constructor(monitor) {
		if (this.constructor === AutoLoadCore) {
			throw new Error("Cannot instantiate abstract class AutoLoadCore directly");
		}
		this._monitor = monitor;
	}

	/**
	 * Get the next execution time from the autoload timer
	 * @returns {Date|null} The next execution time, or null if not set
	 */
	#getScheduler() {
		return this._monitor?._autoLoadScheduler ?? null;
	}

	#getNextExecuteTime() {
		const scheduler = this.#getScheduler();
		if (scheduler) {
			return scheduler.getNextExecuteTime();
		}
		if (typeof this.getNextExecuteTime === "function") {
			return this.getNextExecuteTime();
		}
		if (this._monitor?._autoLoad && typeof this._monitor._autoLoad.getNextExecuteTime === "function") {
			return this._monitor._autoLoad.getNextExecuteTime();
		}
		return null;
	}

	/**
	 * Whether items are currently dropping (aggressive interval in use).
	 * @returns {boolean}
	 */
	#getItemsDropping() {
		if (typeof this.getItemsDropping === "function") {
			return this.getItemsDropping();
		}
		if (this._monitor?._autoLoad && typeof this._monitor._autoLoad.getItemsDropping === "function") {
			return this._monitor._autoLoad.getItemsDropping();
		}
		return false;
	}

	/**
	 * Format the next execution time as a time string
	 * @param {Date|null} nextExecuteTime - The next execution time
	 * @returns {string} Formatted time string or "(tba)" if no time is set
	 */
	#formatNextLoadText(nextExecuteTime) {
		return formatNextAssistedLoadDisplayTime(nextExecuteTime, (date, timeOnly) =>
			this._monitor._formatDate(date, timeOnly)
		);
	}

	#getWaitingListTooltip() {
		const scheduler = this.#getScheduler();
		if (!scheduler) return "";
		const text = scheduler.formatWaitingListTooltip();
		if (!text) {
			return getMessage("nmAssistedLoadWaitingListEmpty", "No assisted loads are currently scheduled.");
		}
		return text;
	}

	#updateWaitingListTooltipIcon() {
		const icon = document.getElementById("nm_next_assisted_load_help");
		if (!icon) return;
		const tooltip = this.#getWaitingListTooltip();
		icon.setAttribute("title", tooltip);
		icon.setAttribute("aria-label", tooltip);
	}

	/**
	 * Set the content of the next assisted load element (icon + text when dropping, else plain text).
	 * @param {HTMLElement} nextLoadElement - The DOM element
	 * @param {string} nextLoadText - The text to set
	 * @param {boolean} [itemsDropping] - If true, show speedometer icon before the value with tooltip
	 */
	#setNextLoadElementContent(nextLoadElement, nextLoadText, itemsDropping = false) {
		if (itemsDropping) {
			const tooltip = getMessage(
				"nmItemsDroppingTooltip",
				"Items are dropping, accelerated assisted-load intervals used"
			);
			nextLoadElement.innerHTML = "";
			const icon = document.createElement("span");
			icon.className = "vh-icon-16 vh-icon-speedometer vh-nm-dropping-icon";
			icon.setAttribute("title", tooltip);
			icon.setAttribute("aria-label", tooltip);
			const text = document.createElement("span");
			text.className = "vh-nm-next-load-time";
			text.textContent = nextLoadText;
			nextLoadElement.appendChild(icon);
			nextLoadElement.appendChild(text);
		} else {
			nextLoadElement.textContent = nextLoadText;
		}
		this.#updateWaitingListTooltipIcon();
	}

	/**
	 * Update the next assisted load date element in the DOM
	 * @param {string} nextLoadText - The text to set
	 * @param {boolean} [itemsDropping] - If true, show speedometer icon before the value with tooltip
	 */
	async #updateNextLoadElement(nextLoadText, itemsDropping = false) {
		// Wait for element to appear if it doesn't exist yet
		while (!document.getElementById("date_next_assisted_load")) {
			await new Promise((resolve) => setTimeout(resolve, 100));
		}
		const nextLoadElement = document.getElementById("date_next_assisted_load");
		if (nextLoadElement) {
			this.#setNextLoadElementContent(nextLoadElement, nextLoadText, itemsDropping);
		}
	}

	/**
	 * Broadcast assisted load dates to all monitors (master and slaves)
	 * @param {string} lastLoadText - The last load text (or "(tba)" if not updating)
	 * @param {string} nextLoadText - The next load text
	 * @param {boolean} [itemsDropping] - If true, show speedometer icon next to next load time
	 */
	async #broadcastAssistedLoadDates(lastLoadText, nextLoadText, itemsDropping = false, waitingListText = "") {
		if (this._monitor && this._monitor._channel) {
			this._monitor._channel.postMessage(
				await this._monitor._cryptoKeys.encryptJSON({
					type: "updateAssistedLoadDates",
					lastLoadText: lastLoadText,
					nextLoadText: nextLoadText,
					itemsDropping: itemsDropping,
					waitingListText: waitingListText || this.#getWaitingListTooltip(),
				})
			);
		}
	}

	/**
	 * Update the "Next assisted load" date in the notification monitor header
	 * Broadcasts the update to all monitors (master and slaves)
	 * This is called when the timer is set/reset, not necessarily when a page is loaded
	 */
	async #updateNextAssistedLoadDate() {
		const nextExecuteTime = this.#getNextExecuteTime();
		const nextLoadText = this.#formatNextLoadText(nextExecuteTime);
		const itemsDropping = this.#getItemsDropping();
		const waitingListText = this.#getWaitingListTooltip();

		await this.#updateNextLoadElement(nextLoadText, itemsDropping);
		await this.#broadcastAssistedLoadDates("(tba)", nextLoadText, itemsDropping, waitingListText);
	}

	/**
	 * Update the "Last assisted load" and "Next assisted load" dates in the notification monitor header
	 * Broadcasts the update to all monitors (master and slaves)
	 * @param {string} queue - The queue name (AI, RFY, AFA, ALL)
	 * @param {number} page - The page number
	 */
	async #updateLastAssistedLoadDate(queue, page, displayLabel = null) {
		const now = new Date();
		const timeStr = this._monitor._formatDate(now, true);
		const queueLabel = displayLabel ? `${displayLabel}` : queue;
		const lastLoadText = `${timeStr}; ${queueLabel} (p. ${page})`;

		const nextExecuteTime = this.#getNextExecuteTime();
		const nextLoadText = this.#formatNextLoadText(nextExecuteTime);
		const itemsDropping = this.#getItemsDropping();
		const waitingListText = this.#getWaitingListTooltip();

		await this.#broadcastAssistedLoadDates(lastLoadText, nextLoadText, itemsDropping, waitingListText);

		// Also update locally
		const lastLoadElement = document.getElementById("date_last_assisted_load");
		if (lastLoadElement) {
			setLastAssistedLoadElement(lastLoadElement, lastLoadText);
		}

		// Update next load element (don't wait for it, element should exist by now)
		const nextLoadElement = document.getElementById("date_next_assisted_load");
		if (nextLoadElement) {
			this.#setNextLoadElementContent(nextLoadElement, nextLoadText, itemsDropping);
		}
	}

	/**
	 * Public method to update the next assisted load date
	 * Called when the timer is set/reset, not necessarily when a page is loaded
	 */
	async updateNextAssistedLoadDate() {
		await this.#updateNextAssistedLoadDate();
	}

	async fetchAutoLoadUrl(
		url,
		queue,
		page,
		DOMCallback = null,
		VHCallback = null,
		displayLabel = null,
		docCallback = null
	) {
		// Check if notification.active is enabled
		if (!this._monitor._settings.get("notification.active")) {
			return;
		}

		if (this._monitor._settings.get("general.debugServercom")) {
			logger.add(`${new Date().toLocaleString()} - Reloading page: ${queue} page ${page}`);
		}

		//Fetch the url
		const userAgent = navigator.userAgent;
		const acceptLanguage = navigator.language || navigator.languages?.join(",") || "en-US,en;q=0.9";
		const headers = {
			"User-Agent": userAgent,
			Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
			"Accept-Language": acceptLanguage,
			"Accept-Encoding": "gzip, deflate, br",
			"Cache-Control": "no-cache",
			Pragma: "no-cache",
			"Sec-Fetch-Dest": "document",
			"Sec-Fetch-Mode": "navigate",
			"Sec-Fetch-Site": "none",
			"Sec-Fetch-User": "?1",
			"Upgrade-Insecure-Requests": "1",
		};
		const response = await fetch(url, { headers: headers });
		const html = await response.text();

		//Parse the HTML
		const parser = new DOMParser();
		const doc = parser.parseFromString(html, "text/html");

		//check if the page is a dogpage
		if (isPageDog(doc)) {
			throw new Error("dog_page");
		}

		//Check if the page is a captchapage
		if (isPageCaptcha(doc)) {
			throw new Error("captcha_page");
		}

		//Check if the page is a loginpage
		if (isPageLogin(doc)) {
			throw new Error("login_page");
		}

		if (docCallback) docCallback(doc);
		await this.#updateLastAssistedLoadDate(queue, page, displayLabel);

		const vvpContext = parseVvpContextFromDocument(doc);
		if (vvpContext) {
			this._monitor._env.updateVVPContext(vvpContext);
		}

		const parsedTiles = parseTilesFromDocument(doc);
		const items = parsedTiles.map((t) => ({
			asin: t.asin,
			title: t.title,
			thumbnail: t.thumbnail,
			is_parent_asin: t.is_parent_asin,
			is_pre_release: t.is_pre_release,
			enrollment_guid: t.enrollment_guid,
			queue: t.queue,
		}));
		if (DOMCallback) {
			DOMCallback.call(this, items);
		}

		//Forward the items to the server
		const arrQueue = { AI: "encore", RFY: "potluck", AFA: "last_chance", ALL: "all_items" };

		const content = {
			api_version: 5,
			app_version: this._monitor._env.data.appVersion,
			action: "get_info",
			country: this._monitor._i18nMgr.getCountryCode(),
			uuid: await this._monitor._settings.get("general.uuid", false),
			fid: await this._monitor._settings.get("general.fingerprint.id", false),
			cid: await this._monitor._env.getCID(),
			tier: this._monitor._tierMgr.getTier(),
			queue: arrQueue[queue] || null,
			items: items,
			request_variants: false,
			p: getInfoPageParam(url, page),
		};
		content.s = await this._monitor._cryptoKeys.signData(content);
		content.pk = await this._monitor._cryptoKeys.getExportedPublicKey();
		const self = this; // Store this context for use in callbacks
		fetch(this._monitor._env.getAPIUrl(), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		})
			.then(async (response) => {
				if (response.ok && VHCallback) {
					const responseData = await response.json();
					VHCallback.call(self, responseData["products"]);
				}
				//Log the number of items sent to the server
				if (self._monitor._settings.get("general.debugServercom")) {
					logger.add(
						`${new Date().toLocaleString()} - ${items.length} items from ${queue}:${page} sent to the server.`
					);
				}
			})
			.catch((error) => {
				logger.add("[AutoLoadCore] Fetch failed: " + error);
			});
	}
}

export { AutoLoadCore };
