export const EMPTY_BROADCAST_SYNC_RESPONSE = Object.freeze({
	available: false,
	asin: false,
	timestamp: false,
});

/**
 * Server has not broadcast a newItem since startup (or state is otherwise unknown).
 *
 * @param {{ available?: boolean, asin?: string | boolean | null, timestamp?: string | boolean | null }} server
 * @returns {boolean}
 */
export function isBroadcastSyncUnavailable(server) {
	if (server?.available === false) {
		return true;
	}
	return typeof server?.asin !== "string" || typeof server?.timestamp !== "string";
}

/**
 * Decide whether a broadcast-sync ping indicates the client missed live newItem pushes.
 *
 * @param {{ available?: boolean, asin?: string | boolean | null, timestamp?: string | boolean | null }} server
 * @param {{ asin?: string | null, timestamp?: string | null }} local
 * @returns {boolean}
 */
export function shouldReconnectForBroadcastMismatch(server, local) {
	if (isBroadcastSyncUnavailable(server)) {
		return false;
	}

	const serverAsin = server.asin;
	const serverTimestamp = server.timestamp;
	const localAsin = local?.asin;
	const localTimestamp = local?.timestamp;

	if (typeof localAsin !== "string" || typeof localTimestamp !== "string") {
		return false;
	}
	if (serverAsin === localAsin) {
		return false;
	}

	const serverTime = Date.parse(serverTimestamp);
	const localTime = Date.parse(localTimestamp);
	if (!Number.isFinite(serverTime) || !Number.isFinite(localTime)) {
		return false;
	}

	return serverTime > localTime;
}
