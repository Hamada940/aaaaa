import { getMessage } from "/scripts/core/services/Internationalization.js";

/**
 * Coordinates assisted-load timers for AI, RFY, and FAV queues.
 * Enforces a minimum 5-second gap between any two executed loads.
 *
 * @module AutoLoadScheduler
 */

class AutoLoadScheduler {
	static MIN_GAP_MS = 5000;
	static #instance = null;

	#monitor;
	#entries = [];
	#lastExecuteTime = 0;
	#masterTimer = null;
	#displayCallback = null;
	#suspension = null;

	constructor(monitor) {
		if (AutoLoadScheduler.#instance) {
			return AutoLoadScheduler.#instance;
		}
		AutoLoadScheduler.#instance = this;
		this.#monitor = monitor;
	}

	/**
	 * Register a callback invoked whenever the waiting list or next-load time changes.
	 *
	 * @param {() => void} callback
	 *
	 * @example
	 * scheduler.setDisplayUpdateCallback(() => autoLoadCore.updateNextAssistedLoadDate());
	 */
	setDisplayUpdateCallback(callback) {
		this.#displayCallback = callback;
	}

	/**
	 * Schedule (or replace) the next load for a queue type.
	 *
	 * @param {Object} opts
	 * @param {"AI"|"RFY"|"FAV"} opts.type
	 * @param {string} opts.label
	 * @param {Date} opts.desiredAt
	 * @param {() => void|Promise<void>} opts.execute
	 *
	 * @example
	 * scheduler.schedule({
	 *   type: "RFY",
	 *   label: "RFY",
	 *   desiredAt: new Date(Date.now() + 120000),
	 *   execute: async () => { await rfyLoader.fetch(); },
	 * });
	 */
	schedule(opts) {
		this.cancelType(opts.type);
		let executeAt = opts.desiredAt.getTime();
		executeAt = this.#resolveConflicts(executeAt, opts.type);
		this.#entries.push({
			type: opts.type,
			label: opts.label,
			executeAt,
			execute: opts.execute,
		});
		this.#entries.sort((a, b) => a.executeAt - b.executeAt);
		this.#armMasterTimer();
		this.#notifyDisplay();
	}

	/**
	 * Remove the pending slot for a queue type.
	 *
	 * @param {"AI"|"RFY"|"FAV"} type
	 *
	 * @example
	 * scheduler.cancelType("FAV");
	 */
	cancelType(type) {
		const before = this.#entries.length;
		this.#entries = this.#entries.filter((e) => e.type !== type);
		if (this.#entries.length !== before) {
			this.#armMasterTimer();
			this.#notifyDisplay();
		}
	}

	/**
	 * Cancel every pending slot.
	 *
	 * @example
	 * scheduler.cancelAll();
	 */
	cancelAll() {
		this.#entries = [];
		if (this.#masterTimer) {
			clearTimeout(this.#masterTimer);
			this.#masterTimer = null;
		}
		this.#notifyDisplay();
	}

	/**
	 * Earliest scheduled load time across all queues.
	 *
	 * @returns {Date|null}
	 *
	 * @example
	 * const next = scheduler.getNextExecuteTime();
	 */
	getNextExecuteTime() {
		if (!this.#entries.length) return null;
		return new Date(this.#entries[0].executeAt);
	}

	/**
	 * Label of the earliest scheduled load.
	 *
	 * @returns {string|null}
	 */
	getNextLoadLabel() {
		return this.#entries[0]?.label ?? null;
	}

	/**
	 * Sorted waiting list for the monitor tooltip.
	 *
	 * @returns {Array<{type: string, label: string, executeAt: Date}>}
	 *
	 * @example
	 * scheduler.getWaitingList();
	 */
	getWaitingList() {
		return this.#entries.map((e) => ({
			type: e.type,
			label: e.label,
			executeAt: new Date(e.executeAt),
		}));
	}

	/**
	 * Build multiline tooltip text for the waiting list.
	 *
	 * @returns {string}
	 */
	formatWaitingListTooltip() {
		const lines = [];
		const suspension = this.getAssistedLoadSuspensionTooltip();
		if (suspension) lines.push(suspension);
		if (this.#entries.length) {
			lines.push(
				...this.getWaitingList().map((e) => {
					const time = this.#monitor._formatDate(e.executeAt, true);
					return `${time} — ${e.label}`;
				})
			);
		}
		return lines.join("\n");
	}

	setAssistedLoadSuspension(reason, durationMs) {
		const until = Date.now() + durationMs;
		if (!this.#suspension || until > this.#suspension.until) {
			this.#suspension = { reason, until };
		}
		this.#notifyDisplay();
	}

	isAssistedLoadSuspended() {
		this.#clearAssistedLoadSuspensionIfExpired();
		return this.#suspension !== null;
	}

	getAssistedLoadSuspensionRemainingMs() {
		this.#clearAssistedLoadSuspensionIfExpired();
		if (!this.#suspension) return null;
		return Math.max(0, this.#suspension.until - Date.now());
	}

	getAssistedLoadSuspensionTooltip() {
		this.#clearAssistedLoadSuspensionIfExpired();
		if (!this.#suspension) return "";
		const minutes = Math.max(1, Math.ceil((this.#suspension.until - Date.now()) / 60_000));
		const messageKey = {
			dog: "nmAssistedLoadSuspendedDog",
			captcha: "nmAssistedLoadSuspendedCaptcha",
			login: "nmAssistedLoadSuspendedLogin",
		}[this.#suspension.reason];
		const fallback = {
			dog: `Dog page detected. Assisted load suspended for ${minutes} minutes.`,
			captcha: `Captcha page detected. Assisted load suspended for ${minutes} minutes.`,
			login: `Login page detected. Assisted load suspended for ${minutes} minutes.`,
		}[this.#suspension.reason];
		return getMessage(messageKey, fallback, [String(minutes)]);
	}

	#clearAssistedLoadSuspensionIfExpired() {
		if (this.#suspension && Date.now() >= this.#suspension.until) {
			this.#suspension = null;
		}
	}

	#resolveConflicts(desiredAt, excludeType) {
		let t = desiredAt;
		let changed = true;
		while (changed) {
			changed = false;
			for (const entry of this.#entries) {
				if (entry.type === excludeType) continue;
				if (Math.abs(t - entry.executeAt) < AutoLoadScheduler.MIN_GAP_MS) {
					t = entry.executeAt + AutoLoadScheduler.MIN_GAP_MS;
					changed = true;
				}
			}
			if (this.#lastExecuteTime > 0 && t - this.#lastExecuteTime < AutoLoadScheduler.MIN_GAP_MS) {
				t = this.#lastExecuteTime + AutoLoadScheduler.MIN_GAP_MS;
				changed = true;
			}
		}
		return t;
	}

	#armMasterTimer() {
		if (this.#masterTimer) {
			clearTimeout(this.#masterTimer);
			this.#masterTimer = null;
		}
		if (!this.#entries.length) return;
		const next = this.#entries[0];
		const delay = Math.max(0, next.executeAt - Date.now());
		this.#masterTimer = setTimeout(() => {
			this.#masterTimer = null;
			void this.#runEntry(next);
		}, delay);
	}

	async #runEntry(entry) {
		const now = Date.now();
		if (this.#lastExecuteTime > 0 && now - this.#lastExecuteTime < AutoLoadScheduler.MIN_GAP_MS) {
			this.schedule({
				type: entry.type,
				label: entry.label,
				desiredAt: new Date(this.#lastExecuteTime + AutoLoadScheduler.MIN_GAP_MS),
				execute: entry.execute,
			});
			return;
		}

		this.#entries = this.#entries.filter((e) => e !== entry);
		this.#lastExecuteTime = Date.now();
		try {
			await entry.execute();
		} finally {
			this.#armMasterTimer();
			this.#notifyDisplay();
		}
	}

	#notifyDisplay() {
		if (this.#displayCallback) {
			void this.#displayCallback();
		}
	}

	destroy() {
		this.cancelAll();
		this.#displayCallback = null;
		this.#suspension = null;
		AutoLoadScheduler.#instance = null;
	}
}

export { AutoLoadScheduler };
