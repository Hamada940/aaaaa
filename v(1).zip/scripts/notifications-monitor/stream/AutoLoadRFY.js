/*global chrome*/

import { AutoLoadCore } from "./AutoLoadCore.js";
import { isAutoloadTimeWithinRange } from "/scripts/core/utils/autoloadActiveHours.js";

/**
 * Client-side assisted load for the RFY (potluck) queue.
 *
 * @module AutoLoadRFY
 */
class AutoLoadRFY extends AutoLoadCore {
	static #instance = null;
	static #DELAY_1_HOUR_MS = 60 * 60 * 1000;
	static #DELAY_24_HOURS_MS = 24 * 60 * 60 * 1000;
	static #CHECK_INTERVAL_MS = 15 * 60 * 1000;

	#arrItems = {};
	#lastLoad = 0;
	#channelMessageHandler = null;

	constructor(monitor) {
		super(monitor);
		if (AutoLoadRFY.#instance) {
			return AutoLoadRFY.#instance;
		}
		AutoLoadRFY.#instance = this;
		this.#createListener();
		this.#armRFYTimer();
	}

	#getScheduler() {
		return this._monitor._autoLoadScheduler;
	}

	#createListener() {
		this.#channelMessageHandler = async (event) => {
			const data = await this._monitor._cryptoKeys.decryptToJSON(event.data);
			this.processMessage(data);
		};
		this._monitor._channel.addEventListener("message", this.#channelMessageHandler);
	}

	#armRFYTimer(overrideDelayMs) {
		const scheduler = this.#getScheduler();
		if (!scheduler) return;

		const delayMs =
			overrideDelayMs ?? (this.#shouldRunRFYLoad() ? this.#getNextIntervalMs() : AutoLoadRFY.#CHECK_INTERVAL_MS);

		scheduler.schedule({
			type: "RFY",
			label: "RFY",
			desiredAt: new Date(Date.now() + delayMs),
			execute: async () => {
				if (overrideDelayMs) {
					this.#armRFYTimer();
					return;
				}
				const scheduler = this.#getScheduler();
				if (scheduler?.isAssistedLoadSuspended()) {
					const remaining =
						scheduler.getAssistedLoadSuspensionRemainingMs() ?? AutoLoadRFY.#CHECK_INTERVAL_MS;
					this.#armRFYTimer(Math.max(remaining, AutoLoadRFY.#CHECK_INTERVAL_MS));
					return;
				}
				if (this.#shouldRunRFYLoad()) {
					const shouldRearm = await this.#getRFY();
					if (!shouldRearm) return;
				}
				this.#armRFYTimer();
			},
		});
	}

	#shouldRunRFYLoad() {
		return (
			this._monitor._isMasterMonitor &&
			this._monitor._settings.get("notification.active") &&
			this._monitor._settings.get("notification.autoload.rfyActive") &&
			this.#isTimeWithinRange() &&
			!this.#getScheduler()?.isAssistedLoadSuspended?.()
		);
	}

	#getNextIntervalMs() {
		let min = this._monitor._settings.get("notification.autoload.rfyMin");
		let max = this._monitor._settings.get("notification.autoload.rfyMax");
		if (min == null || min < 1) min = 2;
		if (max == null || max > 10) max = 5;
		min = Math.max(1, Math.min(10, min));
		max = Math.max(1, Math.min(10, max));
		if (min > max) max = min;
		const rangeMs = (max - min) * 60 * 1000;
		return Math.floor(Math.random() * (rangeMs + 1)) + min * 60 * 1000;
	}

	#isTimeWithinRange() {
		return isAutoloadTimeWithinRange(
			this._monitor._settings.get("notification.autoload.hourStart"),
			this._monitor._settings.get("notification.autoload.hourEnd")
		);
	}

	async #getRFY() {
		if (
			!this._monitor._settings.get("notification.active") ||
			!this._monitor._settings.get("notification.autoload.rfyActive")
		) {
			return true;
		}
		if (Date.now() - this.#lastLoad < 1000 * 60 * 2) {
			return true;
		}
		this.#lastLoad = Date.now();
		try {
			const url = `https://www.amazon.${this._monitor._i18nMgr.getDomainTLD()}/vine/vine-items?queue=potluck&page=1`;
			await this.fetchAutoLoadUrl(
				url,
				"RFY",
				1,
				this.#syncRFYPageData.bind(this),
				this.#syncRFYServerData.bind(this)
			);
			return true;
		} catch (error) {
			if (error.message == "dog_page") this.#dogPageDetected();
			else if (error.message == "captcha_page") this.#captchaPageDetected();
			else if (error.message == "login_page") this.#loginPageDetected();
			else throw error;
			return false;
		}
	}

	#suspendAssistedLoad(reason, delayMs) {
		this.#getScheduler()?.setAssistedLoadSuspension(reason, delayMs);
		this.#armRFYTimer(delayMs);
	}

	#dogPageDetected() {
		console.log(`${new Date().toLocaleString()} - Dog page detected.`);
		this.#suspendAssistedLoad("dog", AutoLoadRFY.#DELAY_24_HOURS_MS);
	}

	#captchaPageDetected() {
		console.log(`${new Date().toLocaleString()} - Captcha page detected.`);
		this.#suspendAssistedLoad("captcha", AutoLoadRFY.#DELAY_1_HOUR_MS);
	}

	#loginPageDetected() {
		console.log(`${new Date().toLocaleString()} - Login page detected.`);
		this.#suspendAssistedLoad("login", AutoLoadRFY.#DELAY_1_HOUR_MS);
	}

	processMessage(message) {
		if (message.type === "dogpage") this.#suspendAssistedLoad("dog", AutoLoadRFY.#DELAY_24_HOURS_MS);
		if (message.type === "captchapage") this.#suspendAssistedLoad("captcha", AutoLoadRFY.#DELAY_1_HOUR_MS);
		if (message.type === "loginpage") this.#suspendAssistedLoad("login", AutoLoadRFY.#DELAY_1_HOUR_MS);
	}

	destroy() {
		this.#getScheduler()?.cancelType("RFY");
		if (this.#channelMessageHandler && this._monitor._channel) {
			this._monitor._channel.removeEventListener("message", this.#channelMessageHandler);
			this.#channelMessageHandler = null;
		}
		AutoLoadRFY.#instance = null;
	}

	async #syncRFYPageData(items) {
		this.#arrItems = {};
		for (const item of items) {
			this.#arrItems[item.asin] = {
				asin: item.asin,
				title: item.title,
				thumbnail: item.thumbnail,
				is_parent_asin: item.is_parent_asin,
				is_pre_release: item.is_pre_release,
				enrollment_guid: item.enrollment_guid,
				queue: item.queue,
				price: item.price,
				additional_img: item.additional_img,
			};
		}
	}

	async #syncRFYServerData(items) {
		for (const [key, values] of Object.entries(items)) {
			if (!this.#arrItems[key]) {
				console.warn(`Key ${key} not found in #arrItems, skipping`);
				continue;
			}
			const target = this.#arrItems[key];
			target.etv_min = values.etv_min;
			target.etv_max = values.etv_max;
			target.date_added = values.date_added;
			target.discovered = values.discovered;
			target.hidden = values.hidden;
			target.variants = values.variants;
			target.order_success = values.order_success;
			target.order_failed = values.order_failed;
			target.order_unavailable = values.order_unavailable;
			target.price = values.price;
			target.additional_img = values.additional_img;
		}

		let potluckItems = await chrome.storage.local.get("potluckItems");
		if (!potluckItems || !potluckItems.potluckItems || Object.keys(potluckItems.potluckItems).length === 0) {
			potluckItems = {};
		} else {
			potluckItems = potluckItems.potluckItems;
		}
		for (const asin of Object.keys(potluckItems)) {
			if (!this.#arrItems[asin]) {
				delete potluckItems[asin];
			}
		}
		for (const [asin, item] of Object.entries(this.#arrItems)) {
			if (!potluckItems[asin]) {
				potluckItems[asin] = item;
				const data = {
					type: "newPreprocessedItem",
					item: {
						asin: asin,
						reason: "new item in RFY (autoload)",
						etv_min: item.etv_min,
						etv_max: item.etv_max,
						tier: this._monitor._tierMgr.getTier(),
						queue: "potluck",
						title: item.title,
						timestamp: Date.now(),
						date: new Date().toISOString().slice(0, 19).replace("T", " "),
						date_added: item.date_added,
						img_url: item.thumbnail,
						is_parent_asin: item.is_parent_asin,
						is_pre_release: item.is_pre_release,
						enrollment_guid: item.enrollment_guid,
						variants: item.variants,
						price: item.price,
						addtitional_img: item.additional_img,
					},
				};
				this._monitor._serverComMgr.processBroadcastMessage(data);
			}
		}
		chrome.storage.local.set({ ["potluckItems"]: potluckItems });
	}
}

export { AutoLoadRFY };
