/*global chrome*/

import { AutoLoadCore } from "./AutoLoadCore.js";
import { isAutoloadTimeWithinRange } from "/scripts/core/utils/autoloadActiveHours.js";

/**
 * Server-coordinated assisted load for the AI queue.
 *
 * @module AutoLoad
 */
class AutoLoad extends AutoLoadCore {
	static #instance = null;
	#channelMessageHandler = null;
	#itemsDropping = false;
	#droppingCooldownTimer = null;
	static #DROPPING_COOLDOWN_MS = 5 * 60 * 1000;

	constructor(monitor) {
		super(monitor);
		if (AutoLoad.#instance) {
			return AutoLoad.#instance;
		}
		AutoLoad.#instance = this;
		this.#createListener();
		this.#armAITimer(true);
	}

	#getScheduler() {
		return this._monitor._autoLoadScheduler;
	}

	/**
	 * Pause AI loads for a fixed backoff interval.
	 *
	 * @param {number} interval - Delay in milliseconds.
	 *
	 * @example
	 * autoLoad.resetReloadTimer(1000 * 60 * 60);
	 */
	async resetReloadTimer(interval) {
		const scheduler = this.#getScheduler();
		if (!scheduler) return;
		scheduler.schedule({
			type: "AI",
			label: "AI (server)",
			desiredAt: new Date(Date.now() + interval),
			execute: () => this.#armAITimer(false),
		});
		await this.updateNextAssistedLoadDate();
	}

	getNextExecuteTime() {
		return this.#getScheduler()?.getNextExecuteTime() ?? null;
	}

	getItemsDropping() {
		return this.#itemsDropping;
	}

	async restartTimer() {
		this.#getScheduler()?.cancelType("AI");
		this.#armAITimer(true);
		await this.updateNextAssistedLoadDate();
	}

	#createListener() {
		this.#channelMessageHandler = async (event) => {
			const data = await this._monitor._cryptoKeys.decryptToJSON(event.data);
			this.processMessage(data);
		};
		this._monitor._channel.addEventListener("message", this.#channelMessageHandler);
	}

	processMessage(message) {
		if (message.type === "dogpage") this.#suspendAssistedLoad("dog", 1000 * 60 * 60 * 24);
		if (message.type === "captchapage") this.#suspendAssistedLoad("captcha", 1000 * 60 * 60);
		if (message.type === "loginpage") this.#suspendAssistedLoad("login", 1000 * 60 * 60);
	}

	#suspendAssistedLoad(reason, delayMs) {
		this.#getScheduler()?.setAssistedLoadSuspension(reason, delayMs);
		void this.resetReloadTimer(delayMs);
	}

	dogPageDetected() {
		console.log(`${new Date().toLocaleString()} - Dog page detected.`);
		this.#suspendAssistedLoad("dog", 1000 * 60 * 60 * 24);
	}

	captchaPageDetected() {
		console.log(`${new Date().toLocaleString()} - Captcha page detected.`);
		this.#suspendAssistedLoad("captcha", 1000 * 60 * 60);
	}

	loginPageDetected() {
		console.log(`${new Date().toLocaleString()} - Login page detected.`);
		this.#suspendAssistedLoad("login", 1000 * 60 * 60);
	}

	#armAITimer(firstTime = false) {
		const scheduler = this.#getScheduler();
		if (!scheduler) return;

		if (!this._monitor._settings.get("notification.active")) {
			void this.resetReloadTimer(1000 * 60 * 15);
			return;
		}
		if (!this.#itemsDropping && !this.#isTimeWithinRange()) {
			void this.resetReloadTimer(1000 * 60 * 15);
			return;
		}

		let timerMs;
		if (this.#itemsDropping) {
			let minSec = this._monitor._settings.get("notification.autoload.whenDroppingMin");
			let maxSec = this._monitor._settings.get("notification.autoload.whenDroppingMax");
			if (minSec == null || minSec < 10) minSec = 30;
			if (maxSec == null || maxSec > 180) maxSec = 60;
			minSec = Math.max(10, Math.min(180, minSec));
			maxSec = Math.max(10, Math.min(180, maxSec));
			if (minSec > maxSec) maxSec = minSec;
			timerMs = Math.floor(Math.random() * (maxSec - minSec + 1) + minSec) * 1000;
		} else {
			let min = this._monitor._settings.get("notification.autoload.min");
			let max = this._monitor._settings.get("notification.autoload.max");
			if (!min || min > 5) min = 5;
			if (!max || max > 10) max = 10;
			timerMs = Math.floor(Math.random() * (max * 60 * 1000 - min * 60 * 1000 + 1) + min * 60 * 1000);
		}

		scheduler.schedule({
			type: "AI",
			label: "AI (server)",
			desiredAt: new Date(Date.now() + timerMs),
			execute: async () => {
				if (scheduler.isAssistedLoadSuspended()) {
					const remaining = scheduler.getAssistedLoadSuspensionRemainingMs() ?? timerMs;
					void this.resetReloadTimer(Math.max(remaining, 1000));
					return;
				}
				if (!firstTime && this._monitor._i18nMgr.getCountryCode()) {
					this._monitor._sendMessageToWebsocket({
						type: "reloadRequest",
						uuid: await this._monitor._settings.get("general.uuid", false),
						cid: await this._monitor._settings.get("general.cid", false),
						fid: await this._monitor._settings.get("general.fingerprint.id", false),
						countryCode: this._monitor._i18nMgr.getCountryCode(),
					});
				}
				this.#armAITimer(false);
			},
		});
		void this.updateNextAssistedLoadDate();
	}

	itemsDroppingDetected() {
		const wasDropping = this.#itemsDropping;
		this.#itemsDropping = true;
		if (this.#droppingCooldownTimer) {
			clearTimeout(this.#droppingCooldownTimer);
			this.#droppingCooldownTimer = null;
		}
		this.#droppingCooldownTimer = setTimeout(() => {
			this.#itemsDropping = false;
			this.#droppingCooldownTimer = null;
			void this._monitor._autoLoadFAV?.onItemsDroppingChanged?.();
			this.#armAITimer(false);
		}, AutoLoad.#DROPPING_COOLDOWN_MS);

		if (!wasDropping) {
			void this._monitor._autoLoadFAV?.onItemsDroppingChanged?.();
		}

		let maxSec = this._monitor._settings.get("notification.autoload.whenDroppingMax");
		if (maxSec == null || maxSec > 180) maxSec = 60;
		maxSec = Math.max(10, Math.min(180, maxSec));
		const aggressiveMaxMs = maxSec * 1000;
		const next = this.#getScheduler()?.getNextExecuteTime();
		const shouldReschedule = next && next.getTime() - Date.now() > aggressiveMaxMs;
		if (shouldReschedule) {
			this.#getScheduler()?.cancelType("AI");
			this.#armAITimer(false);
		}
	}

	#isTimeWithinRange() {
		return isAutoloadTimeWithinRange(
			this._monitor._settings.get("notification.autoload.hourStart"),
			this._monitor._settings.get("notification.autoload.hourEnd")
		);
	}

	destroy() {
		this.#getScheduler()?.cancelType("AI");
		if (this.#droppingCooldownTimer) {
			clearTimeout(this.#droppingCooldownTimer);
			this.#droppingCooldownTimer = null;
		}
		if (this.#channelMessageHandler && this._monitor._channel) {
			this._monitor._channel.removeEventListener("message", this.#channelMessageHandler);
			this.#channelMessageHandler = null;
		}
		AutoLoad.#instance = null;
	}
}

export { AutoLoad };
