import * as MonitorDebug from "../debug/MonitorDebug.js";

class WebhookQueue {
	static #instance;
	#arrWebhookQueue = [];
	#queueTimer = null;
	#settingsMgr = null;
	#requestSeq = 0;
	#activeProcessRunId = 0;
	constructor(settingsMgr) {
		if (WebhookQueue.#instance) {
			return WebhookQueue.#instance;
		}
		WebhookQueue.#instance = this;
		this.#settingsMgr = settingsMgr;
	}

	/** This method queue the webhook and will retry if it fails */

	queue(url, options) {
		const debugEnabled = !!this.#settingsMgr?.get?.("general.debugWebhooks");
		const entry = {
			url,
			options,
			_meta: {
				id: ++this.#requestSeq,
				retryCount: 0,
				queuedAt: Date.now(),
				firstQueuedAt: Date.now(),
				lastAttemptAt: null,
				lastStatus: null,
			},
		};
		if (debugEnabled) {
			console.log("[WebhookQueue][QUEUE]", {
				id: entry._meta.id,
				queueLengthBefore: this.#arrWebhookQueue.length,
				queueLengthAfter: this.#arrWebhookQueue.length + 1,
				method: options?.method,
				urlHost: (() => {
					try {
						return new URL(url).host;
					} catch {
						return "(invalid URL)";
					}
				})(),
				bodyPreview:
					typeof options?.body === "string" ? options.body.substring(0, 220) : "(non-string/no body)",
				timestamp: new Date().toISOString(),
			});
		}
		MonitorDebug.debugWebhookQueueQueued(this.#settingsMgr, {
			url,
			queueLength: this.#arrWebhookQueue.length + 1,
			method: options?.method,
		});
		this.#arrWebhookQueue.push(entry);
		if (!this.#queueTimer) {
			this.#queueTimer = setInterval(() => {
				this.#processWebhookQueue();
			}, 3000);
		}
		this.#processWebhookQueue();
	}

	async #processWebhookQueue() {
		const debugEnabled = !!this.#settingsMgr?.get?.("general.debugWebhooks");
		const processRunId = ++this.#activeProcessRunId;
		if (debugEnabled) {
			console.log("[WebhookQueue][PROCESS_START]", {
				processRunId,
				queueLengthAtStart: this.#arrWebhookQueue.length,
				timestamp: new Date().toISOString(),
			});
		}
		while (this.#arrWebhookQueue.length > 0) {
			const entry = this.#arrWebhookQueue.shift();
			const { url, options, _meta } = entry;
			if (_meta) {
				_meta.lastAttemptAt = Date.now();
			}
			if (debugEnabled) {
				console.log("[WebhookQueue][SEND_ATTEMPT]", {
					processRunId,
					id: _meta?.id ?? "(no-meta)",
					retryCount: _meta?.retryCount ?? 0,
					queueLengthAfterShift: this.#arrWebhookQueue.length,
					method: options?.method,
					url,
					bodyPreview:
						typeof options?.body === "string" ? options.body.substring(0, 220) : "(non-string/no body)",
					timestamp: new Date().toISOString(),
				});
			}

			try {
				MonitorDebug.debugWebhookQueueSending(this.#settingsMgr, { url, method: options?.method });
				const response = await fetch(url, options);
				if (_meta) {
					_meta.lastStatus = response.status;
				}
				if (debugEnabled) {
					console.log("[WebhookQueue][SEND_RESPONSE]", {
						processRunId,
						id: _meta?.id ?? "(no-meta)",
						retryCount: _meta?.retryCount ?? 0,
						status: response.status,
						ok: response.ok,
						statusText: response.statusText,
						queueLengthCurrent: this.#arrWebhookQueue.length,
						timestamp: new Date().toISOString(),
					});
				}

				MonitorDebug.debugWebhookQueueResponse(this.#settingsMgr, {
					url,
					status: response.status,
					ok: response.ok,
					statusText: response.statusText,
				});

				if (response.status === 429 && this.#settingsMgr.isPremiumUser(3)) {
					// Rate limit exceeded - keep in queue and wait
					console.warn("Rate limit exceeded, keeping webhook in queue");
					if (_meta) {
						_meta.retryCount += 1;
					}
					this.#arrWebhookQueue.unshift(entry);
					if (debugEnabled) {
						console.warn("[WebhookQueue][REQUEUE_429]", {
							processRunId,
							id: _meta?.id ?? "(no-meta)",
							retryCount: _meta?.retryCount ?? "(unknown)",
							queueLengthAfterRequeue: this.#arrWebhookQueue.length,
							timestamp: new Date().toISOString(),
						});
					}
					break; // Exit loop to wait for next interval
				}
			} catch (error) {
				console.error("Error sending webhook:", error);
				if (debugEnabled) {
					console.error("[WebhookQueue][SEND_ERROR]", {
						processRunId,
						id: _meta?.id ?? "(no-meta)",
						retryCount: _meta?.retryCount ?? 0,
						error: error?.message || String(error),
						queueLengthCurrent: this.#arrWebhookQueue.length,
						timestamp: new Date().toISOString(),
					});
				}
				MonitorDebug.debugWebhookQueueError(this.#settingsMgr, { url, error });
			}
		}
		if (debugEnabled) {
			console.log("[WebhookQueue][PROCESS_END]", {
				processRunId,
				queueLengthAtEnd: this.#arrWebhookQueue.length,
				timestamp: new Date().toISOString(),
			});
		}
	}
}

export { WebhookQueue };
