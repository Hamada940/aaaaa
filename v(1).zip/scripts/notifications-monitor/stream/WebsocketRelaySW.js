/**
 * Relay messages from the Service Worker handled websocket to the monitor (For non-Safari browsers)
 * This class is injected to the websocket
 */

import { WebsocketRelayInterface } from "/scripts/notifications-monitor/stream/WebsocketRelayInterface.js";
import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";

/**
 * @implements {WebsocketRelayInterface}
 */
class WebsocketRelaySW extends WebsocketRelayInterface {
	#fctPostMessage = null;
	#cryptoKeys = null;
	/**
	 * Constructor
	 * @param {function} fctPostMessage Function to post the message to the monitor.
	 */
	constructor(fctPostMessage) {
		super();
		this.#fctPostMessage = fctPostMessage;
		this.#cryptoKeys = new CryptoKeys();
	}

	/**
	 * Relay a message to the monitor
	 * @param {object} message The message to relay
	 */
	async relayMessage(message) {
		this.#fctPostMessage(await this.#cryptoKeys.encryptJSON(message));
	}
}

export { WebsocketRelaySW };
