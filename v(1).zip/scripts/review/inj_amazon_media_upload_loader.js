const scriptTag = document.createElement("script");
scriptTag.src = chrome.runtime.getURL("/scripts/review/inj_amazon_media_upload.js");
scriptTag.onload = function () {
	this.remove();
};
(document.head || document.documentElement).appendChild(scriptTag);
