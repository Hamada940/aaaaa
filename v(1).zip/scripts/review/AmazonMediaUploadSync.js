/**
 * Wait for Amazon create-review media uploads to finish before injecting the next file.
 * Prevents images from appearing ahead of videos when uploads run in parallel.
 *
 * Uses several signals because Amazon's DOM varies by locale/build:
 * - completed upload network requests (Performance API)
 * - new review-media preview nodes (including shadow DOM)
 * - document-wide blob / Amazon CDN preview images
 */

import { AMAZON_REVIEW_MEDIA } from "/scripts/core/amazon/selectors.js";

const MEDIA_TILE_SELECTORS = AMAZON_REVIEW_MEDIA.TILE;
const PREVIEW_MEDIA_SELECTORS = AMAZON_REVIEW_MEDIA.PREVIEW;
const TILE_BUSY_SELECTORS = AMAZON_REVIEW_MEDIA.BUSY;
const UPLOAD_URL_RE = AMAZON_REVIEW_MEDIA.UPLOAD_URL_REGEX;

let uploadHookInstalled = false;
let uploadHookPromise = null;

/**
 * Inject MAIN-world fetch/XHR hooks so upload completion is visible even when DOM selectors fail.
 * @returns {Promise<void>}
 */
export function ensureAmazonMediaUploadHook() {
	if (uploadHookInstalled) {
		return Promise.resolve();
	}
	if (typeof chrome?.runtime?.getURL !== "function") {
		uploadHookInstalled = true;
		return Promise.resolve();
	}
	if (uploadHookPromise) {
		return uploadHookPromise;
	}
	uploadHookPromise = new Promise((resolve) => {
		const finish = () => {
			uploadHookInstalled = true;
			resolve();
		};
		const script = document.createElement("script");
		script.src = chrome.runtime.getURL("/scripts/review/inj_amazon_media_upload.js");
		script.onload = () => {
			script.remove();
			finish();
		};
		script.onerror = () => {
			script.remove();
			uploadHookPromise = null;
			finish();
		};
		(document.head || document.documentElement).appendChild(script);
	});
	return uploadHookPromise;
}

/**
 * @param {ParentNode} node
 * @returns {Generator<Element>}
 */
function* walkElements(node) {
	if (!(node instanceof Element || node instanceof Document || node instanceof DocumentFragment)) {
		return;
	}
	const root = node instanceof Document ? node.documentElement : node;
	if (!root) {
		return;
	}
	const stack = [root];
	while (stack.length) {
		const current = stack.pop();
		if (!(current instanceof Element)) {
			continue;
		}
		yield current;
		if (current.shadowRoot) {
			stack.push(current.shadowRoot);
		}
		for (let i = current.children.length - 1; i >= 0; i--) {
			stack.push(current.children[i]);
		}
	}
}

/**
 * @param {ParentNode | null | undefined} root
 * @param {string} selector
 * @returns {Element[]}
 */
function queryAllDeep(root, selector) {
	if (!root) {
		return [];
	}
	const matches = [];
	for (const el of walkElements(root)) {
		if (el.matches(selector)) {
			matches.push(el);
		}
	}
	return matches;
}

/**
 * @param {HTMLInputElement | null} fileInput
 * @returns {HTMLElement | null}
 */
export function getAmazonMediaUploadRoot(fileInput) {
	if (!fileInput) {
		return null;
	}
	return (
		fileInput.closest("form.ryp__review-form__form") ||
		fileInput.closest("form") ||
		fileInput.closest(".in-context-ryp__form-field") ||
		fileInput.closest("[class*='media']") ||
		document.body
	);
}

/**
 * @returns {PerformanceResourceTiming[]}
 */
function getResourceEntries() {
	if (typeof performance?.getEntriesByType === "function") {
		return performance.getEntriesByType("resource");
	}
	return [];
}

/**
 * @param {HTMLElement[]} matches
 * @returns {HTMLElement[]}
 */
function dedupeMediaElements(matches) {
	return matches.filter((el) => !matches.some((other) => other !== el && other.contains(el)));
}

/**
 * @param {ParentNode | null | undefined} root
 * @returns {HTMLElement[]}
 */
export function getAmazonMediaElements(root) {
	const scope = root || document.body;
	const matches = [];

	for (const selector of MEDIA_TILE_SELECTORS) {
		for (const el of queryAllDeep(scope, selector)) {
			if (el instanceof HTMLElement && !el.closest("input[type='file']")) {
				matches.push(el);
			}
		}
	}

	for (const selector of PREVIEW_MEDIA_SELECTORS) {
		for (const el of queryAllDeep(scope, selector)) {
			if (!(el instanceof HTMLElement) || el.closest("input[type='file']")) {
				continue;
			}
			if (matches.some((tile) => tile.contains(el))) {
				continue;
			}
			matches.push(el);
		}
	}

	return dedupeMediaElements(matches);
}

/** @deprecated Use getAmazonMediaElements */
export function getAmazonMediaTiles(root) {
	return getAmazonMediaElements(root);
}

/** @deprecated Use getAmazonMediaElements */
export function getAmazonMediaPreviewElements(root) {
	return getAmazonMediaElements(root);
}

/**
 * @param {ParentNode | null | undefined} root
 * @returns {number}
 */
export function countAmazonMediaTiles(root) {
	return getAmazonMediaElements(root).length;
}

/**
 * @param {PerformanceResourceTiming} entry
 * @returns {boolean}
 */
export function isLikelyAmazonMediaUploadRequest(entry) {
	if (!entry?.name) {
		return false;
	}
	if (UPLOAD_URL_RE.test(entry.name)) {
		return true;
	}
	const size = Math.max(entry.transferSize || 0, entry.encodedBodySize || 0, entry.decodedBodySize || 0);
	if (size < 800) {
		return false;
	}
	return (
		entry.initiatorType === "xmlhttprequest" || entry.initiatorType === "fetch" || entry.initiatorType === "beacon"
	);
}

/**
 * @param {PerformanceResourceTiming} entry
 * @returns {boolean}
 */
export function isCompletedResource(entry) {
	return Boolean(entry.responseEnd && entry.responseEnd > 0);
}

/**
 * @returns {Set<string>}
 */
export function snapshotResourceKeys() {
	return new Set(getResourceEntries().map((entry) => resourceKey(entry)));
}

/**
 * @param {PerformanceResourceTiming} entry
 * @returns {string}
 */
export function resourceKey(entry) {
	return `${entry.name}|${Math.round(entry.startTime)}|${Math.round(entry.responseEnd || 0)}`;
}

/**
 * @param {Set<string>} beforeKeys
 * @param {number} startTime
 * @param {File | null | undefined} file
 * @returns {boolean}
 */
export function hasNewCompletedUpload(beforeKeys, startTime, file) {
	const minSize = Math.min(Math.max(Math.floor((file?.size || 0) * 0.08), 800), 500000);
	for (const entry of getResourceEntries()) {
		if (beforeKeys.has(resourceKey(entry))) {
			continue;
		}
		if (entry.startTime + 50 < startTime) {
			continue;
		}
		if (!isCompletedResource(entry)) {
			continue;
		}
		const size = Math.max(entry.transferSize || 0, entry.encodedBodySize || 0, entry.decodedBodySize || 0);
		if (isLikelyAmazonMediaUploadRequest(entry) || size >= minSize) {
			return true;
		}
	}
	return false;
}

/**
 * @param {HTMLElement | null | undefined} tile
 * @returns {boolean}
 */
export function isAmazonMediaTileBusy(tile) {
	if (!tile) {
		return false;
	}
	for (const selector of TILE_BUSY_SELECTORS) {
		const el = tile.querySelector(selector);
		if (!el) {
			continue;
		}
		const text = el.textContent?.trim().toLowerCase() ?? "";
		if (text.includes("uploading") || text.includes("processing")) {
			return true;
		}
		if (el.matches(".a-spinner, [class*='a-spinner'], [class*='uploading']")) {
			return true;
		}
	}
	const tileText = tile.textContent?.trim().toLowerCase() ?? "";
	if (/\buploading\b/.test(tileText) || /\bprocessing\b/.test(tileText)) {
		return !/\buploaded\b/.test(tileText);
	}
	return false;
}

/**
 * @param {HTMLElement | null | undefined} tile
 * @returns {boolean}
 */
export function isAmazonMediaTileReady(tile) {
	if (!tile || isAmazonMediaTileBusy(tile)) {
		return false;
	}
	const img = tile.matches("img[src]") ? tile : tile.querySelector("img[src]");
	if (img?.getAttribute("src")) {
		return true;
	}
	const video = tile.matches("video[src]") ? tile : tile.querySelector("video[src], video source[src]");
	return Boolean(video?.getAttribute("src"));
}

/**
 * @param {ParentNode | null | undefined} root
 * @returns {boolean}
 */
export function isAmazonMediaUploadBusy(root) {
	const tiles = getAmazonMediaElements(root);
	if (!tiles.length) {
		return false;
	}
	return isAmazonMediaTileBusy(tiles[tiles.length - 1]);
}

/**
 * @param {ParentNode | null | undefined} root
 * @param {number} baselineCount
 * @returns {boolean}
 */
export function isAmazonMediaUploadSettled(root, baselineCount) {
	const previews = getAmazonMediaElements(root);
	if (previews.length <= baselineCount) {
		return false;
	}
	const newPreview = previews[baselineCount];
	return isAmazonMediaTileReady(newPreview);
}

/**
 * @param {File} file
 * @returns {{ startTime: number, resourceKeys: Set<string>, previewBaseline: number, file: File }}
 */
export function beginAmazonMediaUpload(file) {
	return {
		startTime: performance.now(),
		resourceKeys: snapshotResourceKeys(),
		previewBaseline: countAmazonMediaTiles(document.body),
		file,
	};
}

/**
 * @param {{ startTime: number, resourceKeys: Set<string>, previewBaseline: number, file: File }} session
 * @param {ParentNode | null | undefined} root
 * @returns {boolean}
 */
export function isAmazonMediaUploadComplete(session, root) {
	if (hasNewCompletedUpload(session.resourceKeys, session.startTime, session.file)) {
		return true;
	}
	return isAmazonMediaUploadSettled(root, session.previewBaseline);
}

/**
 * @param {ParentNode | null | undefined} root
 * @param {File} file
 * @param {{ baselineTileCount?: number, minMs?: number, maxMs?: number, pollMs?: number, session?: ReturnType<typeof beginAmazonMediaUpload> }} [options]
 * @returns {Promise<{ ok: boolean, timedOut: boolean }>}
 */
export async function waitForAmazonMediaUploadSettle(root, file, options = {}) {
	const isVideo = file?.type?.startsWith("video/");
	const minMs = options.minMs ?? 800;
	const maxMs = options.maxMs ?? (isVideo ? 300000 : 45000);
	const pollMs = options.pollMs ?? 150;
	const session = options.session ?? beginAmazonMediaUpload(file);
	const baselineCount = options.baselineTileCount ?? session.previewBaseline;

	await ensureAmazonMediaUploadHook();

	const start = Date.now();
	let stableSince = 0;
	let lastPreviewCount = countAmazonMediaTiles(document.body);
	let resolveWait;
	const done = new Promise((resolve) => {
		resolveWait = resolve;
	});

	let finished = false;
	const finish = (ok) => {
		if (finished) {
			return;
		}
		finished = true;
		observer.disconnect();
		document.removeEventListener("vh-amazon-media-upload", onHookUpload);
		clearInterval(intervalId);
		clearTimeout(timeoutId);
		resolveWait({ ok, timedOut: !ok });
	};

	/** @param {Event} event */
	const onHookUpload = (event) => {
		if (Date.now() - start < minMs) {
			return;
		}
		const detail = /** @type {CustomEvent<{ type?: string }>} */ (event).detail;
		if (detail?.type === "complete") {
			finish(true);
		}
	};
	document.addEventListener("vh-amazon-media-upload", onHookUpload);

	const check = () => {
		if (Date.now() - start < minMs) {
			return;
		}

		if (hasNewCompletedUpload(session.resourceKeys, session.startTime, session.file)) {
			finish(true);
			return;
		}

		const previewCount = countAmazonMediaTiles(document.body);
		const domSettled =
			isAmazonMediaUploadSettled(root, baselineCount) || isAmazonMediaUploadSettled(document.body, baselineCount);
		const busy = isAmazonMediaUploadBusy(root) || isAmazonMediaUploadBusy(document.body);

		if (domSettled) {
			finish(true);
			return;
		}

		if (previewCount > baselineCount && !busy) {
			if (previewCount === lastPreviewCount) {
				if (!stableSince) {
					stableSince = Date.now();
				} else if (Date.now() - stableSince >= 700) {
					finish(true);
					return;
				}
			} else {
				stableSince = 0;
				lastPreviewCount = previewCount;
			}
		} else {
			stableSince = 0;
			lastPreviewCount = previewCount;
		}
	};

	const observer = new MutationObserver(check);
	observer.observe(document.body, {
		childList: true,
		subtree: true,
		attributes: true,
		attributeFilter: ["src", "class", "aria-busy", "style"],
	});

	const intervalId = setInterval(check, pollMs);
	const timeoutId = setTimeout(() => {
		if (countAmazonMediaTiles(document.body) > baselineCount) {
			finish(true);
			return;
		}
		finish(false);
	}, maxMs);

	check();

	return done;
}
