/**
 * MAIN-world hook: surface Amazon media upload network activity to the content script.
 */
(function installVhAmazonMediaUploadHook() {
	if (window.__vhAmazonMediaUploadHook) {
		return;
	}
	window.__vhAmazonMediaUploadHook = true;

	const UPLOAD_URL_RE =
		/media-amazon|images-amazon|ssl-images-amazon|customer.?media|mediaupload|imageupload|videoupload|unagi|amazonaws\.com.*upload|\/upload\/|create-review.*media/i;

	/** @param {string} type @param {Record<string, unknown>} detail */
	function dispatch(type, detail) {
		document.dispatchEvent(new CustomEvent("vh-amazon-media-upload", { detail: { type, ...detail } }));
	}

	/** @param {string | undefined | null} url @param {number} [size] */
	function isUploadRequest(url, size) {
		if (!url) {
			return false;
		}
		if (UPLOAD_URL_RE.test(url)) {
			return true;
		}
		return (size || 0) >= 500;
	}

	const originalFetch = window.fetch;
	window.fetch = function vhPatchedFetch(input, init) {
		const url = typeof input === "string" ? input : input?.url;
		const bodySize =
			init?.body instanceof Blob ? init.body.size : typeof init?.body === "string" ? init.body.length : 0;
		const tracked = isUploadRequest(url, bodySize);
		if (tracked) {
			dispatch("start", { url, via: "fetch" });
		}
		return originalFetch.call(this, input, init).then(
			(response) => {
				if (tracked) {
					dispatch("complete", { url, via: "fetch", ok: response.ok });
				}
				return response;
			},
			(error) => {
				if (tracked) {
					dispatch("error", { url, via: "fetch" });
				}
				throw error;
			}
		);
	};

	const originalOpen = XMLHttpRequest.prototype.open;
	const originalSend = XMLHttpRequest.prototype.send;

	XMLHttpRequest.prototype.open = function vhPatchOpen(method, url, ...rest) {
		this.__vhUploadUrl = typeof url === "string" ? url : String(url || "");
		this.__vhUploadMethod = method;
		return originalOpen.call(this, method, url, ...rest);
	};

	XMLHttpRequest.prototype.send = function vhPatchSend(body) {
		const bodySize =
			body instanceof Blob
				? body.size
				: body instanceof ArrayBuffer
					? body.byteLength
					: typeof body === "string"
						? body.length
						: 0;
		const tracked = isUploadRequest(this.__vhUploadUrl, bodySize);
		if (tracked) {
			this.addEventListener("loadend", () => {
				dispatch("complete", {
					url: this.__vhUploadUrl,
					via: "xhr",
					ok: this.status >= 200 && this.status < 400,
				});
			});
			dispatch("start", { url: this.__vhUploadUrl, via: "xhr" });
		}
		return originalSend.call(this, body);
	};
})();
