/**
 * Injects monitor guards into the page's JavaScript context ("main world").
 *
 * Content scripts run in an isolated world; Amazon's page scripts run in the
 * main world. To patch Amazon's jQuery / ue / mix_csa we must inject code
 * the page can execute.
 *
 * Amazon's Content-Security-Policy blocks inline scripts (script.textContent).
 * We load inj_preboot.js via script.src (chrome-extension://… is allowed).
 *
 * Only active on notification monitor pages (V3 hash monitor, V4 hash vh-monitor, etc.).
 * See inj_preboot.js for what the guards do.
 */
const scriptTag = document.createElement("script");
scriptTag.src = chrome.runtime.getURL("scripts/inj_preboot.js");
scriptTag.onload = function () {
	this.remove();
};
(document.head || document.documentElement).appendChild(scriptTag);
