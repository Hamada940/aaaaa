/**
 * Shared keybinding actions for the notification monitor toolbar (Pause, Clear Unavailable, Clear All).
 * Used by Monitor V3, Monitor V3 Lite, and Monitor V4 so these 3 keybindings work without the bootloader.
 *
 * @param {function(string): string} getSetting - Function to read a setting, e.g. (key) => Settings.get(key)
 * @returns {Object.<string, function(): void>} Map of key (lowercase) to action (click the corresponding button)
 */
export function getMonitorToolbarKeybindingActions(getSetting) {
	const pauseFeedKey = getSetting("keyBindings.pauseFeed");
	const clearUnavailableKey = getSetting("keyBindings.clearUnavailable");
	const clearAllKey = getSetting("keyBindings.clearAll");

	const map = {};
	if (pauseFeedKey != null && String(pauseFeedKey).trim() !== "") {
		map[String(pauseFeedKey).toLowerCase()] = () => document.getElementById("pauseFeed")?.click();
	}
	if (clearUnavailableKey != null && String(clearUnavailableKey).trim() !== "") {
		map[String(clearUnavailableKey).toLowerCase()] = () => document.getElementById("clear-unavailable")?.click();
	}
	if (clearAllKey != null && String(clearAllKey).trim() !== "") {
		map[String(clearAllKey).toLowerCase()] = () => document.getElementById("clear-monitor")?.click();
	}
	return map;
}
