/**
 * Redact PII from parse-health debug payloads before queueing or sending to the API.
 */

const CUSTOMER_ID_RE = /"customerId"\s*:\s*"[^"]*"/gi;
const CUSTOMER_ID_SNAKE_RE = /"customer_id"\s*:\s*"[^"]*"/gi;
const CHECKOUT_PRODUCT_ID_RE = /p-\d+-\d+-\d+/g;
const ADDRESS_ID_RE = /addressID=[^&\s"']+/gi;
const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;

/**
 * @param {unknown} value
 * @returns {unknown}
 */
export function redactValue(value) {
	if (value === null || value === undefined) {
		return value;
	}
	if (typeof value === "string") {
		return redactString(value);
	}
	if (Array.isArray(value)) {
		return value.map(redactValue);
	}
	if (typeof value === "object") {
		return redactObject(value);
	}
	return value;
}

/**
 * @param {string} str
 * @returns {string}
 */
export function redactString(str) {
	return str
		.replace(CUSTOMER_ID_RE, '"customerId":"[REDACTED]"')
		.replace(CUSTOMER_ID_SNAKE_RE, '"customer_id":"[REDACTED]"')
		.replace(CHECKOUT_PRODUCT_ID_RE, "[REDACTED]")
		.replace(ADDRESS_ID_RE, "addressID=[REDACTED]")
		.replace(UUID_RE, "[REDACTED]");
}

/**
 * @param {Record<string, unknown>} obj
 * @returns {Record<string, unknown>}
 */
export function redactObject(obj) {
	const out = {};
	for (const [key, val] of Object.entries(obj)) {
		const lower = key.toLowerCase();
		if (
			lower === "customerid" ||
			lower === "customer_id" ||
			lower === "addressid" ||
			lower === "address_id" ||
			lower === "legacyaddressid" ||
			lower === "uuid" ||
			lower === "cid"
		) {
			out[key] = "[REDACTED]";
			continue;
		}
		if (lower === "productid" || lower === "checkoutid") {
			out[key] = "[REDACTED]";
			continue;
		}
		out[key] = redactValue(val);
	}
	return out;
}

/**
 * @param {string} url
 * @returns {string}
 */
export function redactPageContext(url) {
	try {
		const parsed = new URL(url, "https://www.amazon.com");
		return `${parsed.pathname}${parsed.search ? redactString(parsed.search) : ""}`;
	} catch {
		return redactString(String(url || ""));
	}
}
