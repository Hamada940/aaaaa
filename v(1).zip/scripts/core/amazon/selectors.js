/**
 * Central registry for all Amazon / Vine host-page CSS selectors, regex patterns, and URL guards.
 *
 * When Vine or Amazon changes their layout, update selectors here — consumer files import
 * named constants via resolveSelector() and must not hardcode host-page selector strings.
 */

export const SELECTOR_BUNDLE_VERSION = "1.0.0";

/** @type {Record<string, string | string[]>} */
let selectorOverrides = {};

/**
 * Load server-pushed selector overrides (stub — returns empty until server bundle is implemented).
 * @returns {Promise<Record<string, string | string[]>>}
 */
export async function loadSelectorOverrides() {
	return {};
}

/**
 * Apply overrides (called after loadSelectorOverrides in future).
 * @param {Record<string, string | string[]>} overrides
 */
export function setSelectorOverrides(overrides) {
	selectorOverrides = overrides ?? {};
}

/**
 * Resolve a selector key to its string or array value, applying any override.
 * @param {string} key - Dot path, e.g. "VINE_GRID.ITEMS"
 * @param {string | string[]} fallback
 * @returns {string | string[]}
 */
export function resolveSelector(key, fallback) {
	if (Object.prototype.hasOwnProperty.call(selectorOverrides, key)) {
		return selectorOverrides[key];
	}
	return fallback;
}

// ---------------------------------------------------------------------------
// Vine item grid — /vine/vine-items and live listing pages
// ---------------------------------------------------------------------------

/** Vine items grid and tile markup on queue/listing pages. */
export const VINE_GRID = {
	/** Outer grid wrapper. */
	CONTAINER: "#vvp-items-grid-container",
	/** Main items grid element. */
	ITEMS: "#vvp-items-grid",
	/** Same grid id for document.getElementById. */
	ITEMS_GRID_ID: "vvp-items-grid",
	/** Items list wrapper. */
	ITEMS_CONTAINER: ".vvp-items-container",
	/** Individual product tile (excludes VH-pinned clones). */
	TILE: ".vvp-item-tile",
	TILE_NOT_PINNED: ".vvp-item-tile:not(.pinned)",
	/** Tiles inside fetched HTML document. */
	TILE_IN_GRID: "#vvp-items-grid .vvp-item-tile",
	/** Search input on Vine items page. */
	SEARCH_INPUT: "#vvp-search-text-input",
	/** Button/search bar row. */
	BUTTON_SEARCH_CONTAINER: ".vvp-items-button-and-search-container",
	/** Tile title link. */
	TILE_TITLE_LINK: ".a-link-normal",
	/** Tile title truncate element. */
	TILE_TITLE: ".a-truncate-full",
	/** Tile image inside content area. */
	TILE_IMAGE: ".vvp-item-tile-content img",
	/** Fallback tile image. */
	TILE_IMAGE_FALLBACK: "img",
	/** Hidden ASIN input on each tile. */
	TILE_ASIN_INPUT: "input[data-asin]",
	/** See-details button input inside tile. */
	TILE_DETAILS_BTN_INPUT: ".vvp-details-btn input",
	/** Grid nav pagination last/first links. */
	NAV_LAST_PAGE: "#vvp-items-grid-container nav ul li:last-child a",
	NAV_FIRST_PAGE: "#vvp-items-grid-container nav ul li:first-child a",
	/** Host chrome hidden by notification monitor. */
	HIDE_CONTAINER_PARAGRAPH: "#vvp-items-grid-container>p",
	HIDE_CONTAINER_NAV_DIV: "#vvp-items-grid-container > div[role=navigation]",
	HIDE_CONTAINER_NAV: "#vvp-items-grid-container > nav",
};

// ---------------------------------------------------------------------------
// VVP context — embedded JSON in script[data-a-state]
// ---------------------------------------------------------------------------

/** vvp-context script tag and fallback scan attribute. */
export const VVP_CONTEXT = {
	/** Exact script selector for vvp-context JSON payload. */
	SCRIPT: 'script[data-a-state=\'{"key":"vvp-context"}\']',
	/** All data-a-state scripts (fallback loop). */
	SCRIPT_ALL: "script[data-a-state]",
	CONTEXT_KEY: "vvp-context",
};

// ---------------------------------------------------------------------------
// Vine pending reviews — /vine/vine-reviews?review-type=pending_review
// ---------------------------------------------------------------------------

/** Pending reviews table on Vine reviews page. */
export const VINE_REVIEWS = {
	TABLE: "table.vvp-reviews-table",
	TABLE_ROW: "table.vvp-reviews-table tr",
	HEADING_ROW_CLASS: "vvp-reviews-table--heading-row",
	REVIEW_ITEM_BTN:
		'a[name="vvp-reviews-table--review-item-btn"], a.vvp-reviews-table--action-btn[name="vvp-reviews-table--review-item-btn"], a.vvp-reviews-table--action-btn',
	ROW_STRIP_ACTIONS:
		'[name="vvp-reviews-table--review-item-btn"], .vvp-reviews-table--action-btn, .vvp-reviews-table--actions-col, button, input, script, style',
	ORDER_TIMESTAMP: "[data-order-timestamp]",
	TIMESTAMP: "[data-timestamp]",
	IMAGE: ".vvp-reviews-table--image-col img, img",
	TITLE_CANDIDATES: ".a-truncate-full, .a-text-normal, [class*='product']",
	REVIEW_CONTENT_HEADING: "#vvp-reviews-table--review-content-heading",
	REVIEW_STATUS_COL: ".vvp-reviews-table--text-col:nth-of-type(4)",
	ROW_LINKS: "a[href]",
};

/** URL path guard for vine-reviews pages. */
export const VINE_REVIEWS_PATH = /^\/vine\/vine-reviews\/?/i;

/** Regex to detect enabled/disabled Amazon pagination "last" li from raw HTML. */
export const PAGINATION_LAST_LI_REGEX = /<li[^>]*class="[^"]*a-last[^"]*"[^>]*>/i;

// ---------------------------------------------------------------------------
// Amazon pagination — shared across Vine listing and item explorer
// ---------------------------------------------------------------------------

/** Amazon standard pagination ul/li markup. */
export const AMAZON_PAGINATION = {
	LIST: "ul.a-pagination",
	LIST_ITEM: "ul.a-pagination li",
	LIST_ITEM_NOT_LAST: "ul.a-pagination li:not(.a-last)",
	LIST_ITEM_SELECTED: "ul.a-pagination li.a-selected",
	LIST_ITEM_FIRST_LINK: "ul.a-pagination li:first-child a",
	LIST_LINKS: "ul.a-pagination li a",
	PAGINATION_ELEMENT: ".a-pagination",
};

// ---------------------------------------------------------------------------
// Vine evaluation metrics — account / activity boxes on Vine pages
// ---------------------------------------------------------------------------

/** Vine voice evaluation period and activity metrics DOM. */
export const VINE_EVAL_METRICS = {
	STATUS_BOX: "#vvp-evaluation-period-tooltip-trigger",
	PERIOD_END_STAMP: "#vvp-eval-end-stamp",
	PERIOD_START_STAMP: "#vvp-eval-start-stamp",
	PERIOD_DATE_STRING_STRONG: "#vvp-evaluation-date-string > strong",
	METRICS_BOX: "#vvp-vine-activity-metrics-box, #vvp-vine-account-details-box",
	REVIEWED_METRIC: "#vvp-num-reviewed-metric-display p:nth-child(-n+2) *:is(strong, .a-size-extra-large)",
};

// ---------------------------------------------------------------------------
// Vine header / browse / checkout on Vine pages
// ---------------------------------------------------------------------------

/** Vine header, browse nodes, and in-Vine checkout form. */
export const VINE_CHROME = {
	HEADER: "#vvp-header",
	HEADER_LINKS: "ul.vvp-header-links-container",
	BROWSE_NODES_CONTAINER: "#vvp-browse-nodes-container",
	CHECKOUT_BUY_NOW_FORM: "#vvp-checkout-buy-now",
	CHECKOUT_REQUEST_BTN:
		"input[data-asin][data-recommendation-id], input[data-asin][data-recommendationId], button[data-asin]",
	TABS_ITEMS_GRID: '#tabs ul a[href="#vvp-items-grid"]',
	TABS_UNAVAILABLE: '#tabs ul a[href="#tab-unavailable"]',
	TABS_HIDDEN: '#tabs ul a[href="#tab-hidden"]',
	TABS_PINNED: '#tabs ul a[href="#tab-pinned"]',
};

// ---------------------------------------------------------------------------
// Amazon product page — /dp/{asin}
// ---------------------------------------------------------------------------

/** Product detail page title, price, and description selectors. */
export const AMAZON_PRODUCT = {
	TITLE: "#productTitle",
	META_TITLE: 'meta[name="title"]',
	PRICE_SELECTORS: [
		"#corePrice_feature_div .a-price .a-offscreen",
		"#corePriceDisplay_desktop_feature_div .a-price .a-offscreen",
		"#apex_desktop .apexPriceToPay .a-offscreen",
		"#price_inside_buybox",
		".priceToPay .a-offscreen",
		"#tp_price_block_total_price_ww .a-offscreen",
		"#sns-base-price .a-offscreen",
	],
	BUYBOX: "#buybox",
	BUYBOX_DESKTOP: "#desktop_buybox",
	BUYBOX_QUALIFIED: "#qualifiedBuybox",
	BUYBOX_PRICE: ".a-price .a-offscreen",
	FEATURE_BULLETS: "#feature-bullets ul, #featurebullets_feature_div ul",
	FEATURE_BULLET_ITEM: "li",
	DESCRIPTION: "#productDescription",
	DESCRIPTION_APLUS: "#aplus_feature_div",
	DESCRIPTION_FEATURE_DIV: "#productDescription_feature_div",
};

// ---------------------------------------------------------------------------
// Amazon create-review form
// ---------------------------------------------------------------------------

/** Create-review page form fields and star rating. */
export const AMAZON_REVIEW_FORM = {
	TITLE: "#reviewTitle",
	TEXT: "#reviewText",
	TEXT_TEXTAREA: "#reviewText textarea",
	STAR_CLEAR: ".in-context-ryp__form-field--starRating--clear",
	STAR_FIELD: ".in-context-ryp__form-field--starRating, [class*='starRating']",
	MOBILE_FIELDS: ".in-context-ryp__form_fields_container-mweb",
	SUBMIT_CONTAINER: ".in-context-ryp__form-field--submit-button, .in-context-ryp__submit-button-container",
	REVIEW_FORM: "form.ryp__review-form__form .ryp__card-frame",
	STAR_SPANS: "span[class*='star'], .a-icon-star, [class*='Star']",
	STAR_RADIOS: 'input[type="radio"]',
	STAR_BUTTONS: "button, [role='button']",
	MEDIA_SECTION: "#media",
	MEDIA_FILE_INPUT: 'input[type="file"][accept*="image"], input[type="file"][accept*="video"]',
	SUBMIT_BUTTON:
		'input[data-hook="ryp-submit-review"], #cm_cr_submit_form input[type="submit"], [data-action="a-popover-close"]',
};

/** Review media upload tile / busy detection (locale-variant class names). */
export const AMAZON_REVIEW_MEDIA = {
	TILE: [
		"[class*='media-preview']",
		"[class*='MediaPreview']",
		"[class*='media-tile']",
		"[class*='mediaTile']",
		"[class*='uploaded-media']",
		"[class*='MediaTile']",
		"[data-testid*='media-preview']",
		"[data-testid*='media-tile']",
		"[data-testid*='MediaPreview']",
	],
	PREVIEW: [
		"img[src^='blob:']",
		"img[src^='data:']",
		"img[src*='media-amazon']",
		"img[src*='images-amazon']",
		"img[src*='ssl-images-amazon']",
		"video[src]",
		"video source[src]",
	],
	BUSY: [".a-spinner", "[class*='a-spinner']", "[class*='uploading']", "[class*='loading-indicator']"],
	UPLOAD_URL_REGEX:
		/media-amazon|images-amazon|ssl-images-amazon|customer.?media|mediaupload|imageupload|videoupload|unagi|amazonaws\.com.*upload|\/upload\/|create-review.*media/i,
};

// ---------------------------------------------------------------------------
// Amazon checkout flow — /checkout/p/ and thank-you pages
// ---------------------------------------------------------------------------

/** Amazon checkout and order confirmation page elements. */
export const AMAZON_CHECKOUT = {
	PRIME_DECLINE: "a#prime-decline-button, a.prime-decline-button, #prime-decline-button a",
	LUNA_SPINNER: "#a-popover-luna-background",
	PLACE_ORDER:
		'#placeOrder, input[name="placeYourOrder1"], input[data-testid="SPC_selectPlaceOrder"], input[data-csa-c-slot-id="checkout-place-your-order-button"], .place-your-order-button',
	DELIVERY_PANEL: "#checkout-deliveryAddressPanel",
	DELIVERY_ERROR: 'div[data-messageid="selectDeliveryOptionMessage"]',
	DELIVERY_FIRST_RADIO: '#col-delivery-group input[type="radio"]',
	CHANGE_ADDRESS_BTN:
		'a[data-action="checkout-view-modal"], a.checkout-change-address, span.checkout-change-address-label',
	CONTINUE_SECONDARY: "#checkout-secondary-continue-button-id input",
	CONTINUE_SECONDARY_TEST: 'input[data-testid="secondary-continue-button"]',
	CONTINUE_PRIMARY: "#checkout-primary-continue-button-id input",
	CONTINUE_BOTTOM: 'input[data-testid="bottom-continue-button"]',
	CONTINUE_SASP: '[data-action="select-destination-on-sasp-desktop-panel"] input',
	CONTINUE_SUBMIT: 'input[type="submit"]',
	SASP_SUBMIT: '.sasp-desktop-submit-button-container input[type="submit"]',
	PANEL_SUBMIT: '#checkout-deliveryAddressPanel input[type="submit"]',
	ORDER_TOTAL:
		"#subtotals-marketplace-table .order-summary-line-definition, .order-summary-line-definition, #subtotals .a-color-price",
	OUT_OF_STOCK: 'div[data-messageid="ItemOutOfStockMessage"], div[data-messageid="itemOutOfStockMessage"]',
	VINE_CV_ERROR: 'div[data-messageid="VineCVMessage"]',
	QUANTITY: ".quantity-display",
	CHECKOUT_PATH_P: "/checkout/p/",
	THANKYOU_PATH: "/gp/buy/thankyou/",
	PRODUCT_ID_REGEX: /\/checkout\/p\/(p-\d+-\d+-\d+)/,
};

// ---------------------------------------------------------------------------
// Amazon address book — fetched address list HTML
// ---------------------------------------------------------------------------

/** Address book page markup for preferred-address selection. */
export const AMAZON_ADDRESS_BOOK = {
	EDIT_LINK: "a[href*='addressID=']",
	LABEL_PARTS:
		".displayAddressFullName, .displayAddressAddressLine1, .displayAddressAddressLine2, .displayAddressCityStateOrRegionPostalCode, .displayAddressCountryName",
};

// ---------------------------------------------------------------------------
// Page guards — login, captcha, dog error pages
// ---------------------------------------------------------------------------

/** Detect Amazon error / auth pages before parsing Vine content. */
export const PAGE_GUARDS = {
	LOGIN_PORTAL: "body #authportal-main-section",
	LOGIN_FORM: "body form.auth-validate-form",
	CAPTCHA_FORM: "body .a-section form",
	DOG_IMAGE: "body img#d",
	DOG_ALT: "Dogs of Amazon / Chiens d'Amazon",
};

// ---------------------------------------------------------------------------
// Amazon popover / modal (host page, not VH)
// ---------------------------------------------------------------------------

export const AMAZON_POPOVER = {
	MODAL_VISIBLE: '.a-popover-modal[aria-hidden="false"]',
	CLOSE_BTN: 'button[data-action="a-popover-close"]',
};

// ---------------------------------------------------------------------------
// Misc Amazon chrome
// ---------------------------------------------------------------------------

export const AMAZON_MISC = {
	SIDE_CART_ARROW: ".nav-ewc-arrow",
	HEAD_BODY_SCRIPTS: "head script, body script",
};

// ---------------------------------------------------------------------------
// Generic review title labels (not selectors — used by review title parser)
// ---------------------------------------------------------------------------

export const GENERIC_REVIEW_LABELS =
	/^(review item|write a review|review|not yet reviewed|unavailable|voir l'article|écrire un avis|rédiger un avis)$/i;
