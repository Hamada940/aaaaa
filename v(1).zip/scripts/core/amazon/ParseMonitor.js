import { SELECTOR_BUNDLE_VERSION } from "./selectors.js";
import { redactObject, redactPageContext } from "./redact.js";

/** @type {Map<string, number>} */
const rateLimitMap = new Map();
const RATE_LIMIT_MS = 60 * 60 * 1000;

/** @type {Array<import("./ParseHealthReporter.js").ParseFailureRecord>} */
let pendingFailures = [];

/** @type {(() => Promise<void>) | null} */
let flushCallback = null;

/** @type {(() => void) | null} */
let notifyCallback = null;

/**
 * Register the function that flushes failures to the API.
 * @param {() => Promise<void>} fn
 */
export function setParseHealthFlushCallback(fn) {
	flushCallback = fn;
}

/**
 * Register the function that shows a user-facing toaster on parse failure.
 * @param {() => void} fn
 */
export function setParseFailureNotifyCallback(fn) {
	notifyCallback = fn;
}

/**
 * @param {string} parserId
 * @param {string} pageContext
 * @returns {string}
 */
function rateLimitKey(parserId, pageContext) {
	return `${parserId}::${pageContext}`;
}

/**
 * @param {string} parserId
 * @param {string} pageContext
 * @returns {boolean}
 */
function isRateLimited(parserId, pageContext) {
	const key = rateLimitKey(parserId, pageContext);
	const last = rateLimitMap.get(key);
	return Boolean(last && Date.now() - last < RATE_LIMIT_MS);
}

/**
 * @param {string} parserId
 * @param {string} errorType
 * @param {string} pageContext
 * @param {Record<string, unknown>} debug
 * @param {boolean} reportSuppressed
 */
function logParseFailure(parserId, errorType, pageContext, debug, reportSuppressed) {
	const suffix = reportSuppressed ? " [bug report suppressed by rate limit]" : "";
	console.group(`[VHelper Parse] ${parserId} (${errorType})${suffix}`);
	console.error("page_context:", pageContext);
	console.error("selector_bundle_version:", SELECTOR_BUNDLE_VERSION);
	if (debug.message) {
		console.error("message:", debug.message);
	}
	if (debug.stack) {
		console.error("stack:", debug.stack);
	}
	console.error("debug:", debug);
	console.groupEnd();
}

/**
 * @param {import("./ParseHealthReporter.js").ParseFailureRecord} record
 */
export function queueParseFailure(record) {
	pendingFailures.push(record);
	if (flushCallback) {
		flushCallback().catch(() => {});
	}
}

/**
 * @returns {import("./ParseHealthReporter.js").ParseFailureRecord[]}
 */
export function drainPendingFailures() {
	const batch = pendingFailures.slice(0, 10);
	pendingFailures = pendingFailures.slice(batch.length);
	return batch;
}

/**
 * Reset rate-limit state (tests only).
 */
export function _resetParseMonitorForTests() {
	rateLimitMap.clear();
	pendingFailures = [];
}

/**
 * Run a parse operation with monitoring. Reports failures when validation fails or an error is thrown.
 *
 * @template T
 * @param {string} parserId - Stable parser identifier for admin reports.
 * @param {{ doc?: Document, pageUrl?: string, responseStatus?: number, selectorHits?: Record<string, boolean> }} context
 * @param {() => T} fn - Parse function body.
 * @param {{ validate?: (result: T) => boolean, required?: boolean }} [options]
 * @returns {T}
 */
export function monitoredParse(parserId, context, fn, options = {}) {
	const pageContext = redactPageContext(context.pageUrl || context.doc?.baseURI || "");
	const selectorHits = context.selectorHits ?? {};

	try {
		const result = fn();
		if (options.validate && !options.validate(result)) {
			reportFailure(parserId, "validation", pageContext, {
				selectorHits,
				responseStatus: context.responseStatus ?? null,
				resultType: Array.isArray(result) ? `array:${result.length}` : typeof result,
			});
		}
		return result;
	} catch (err) {
		reportFailure(parserId, "exception", pageContext, {
			selectorHits,
			responseStatus: context.responseStatus ?? null,
			message: err instanceof Error ? err.message : String(err),
			stack: err instanceof Error ? err.stack : undefined,
		});
		if (options.required) {
			throw err;
		}
		throw err;
	}
}

/**
 * @param {string} parserId
 * @param {"exception"|"validation"|"empty_result"|"selector_miss"} errorType
 * @param {string} pageContext
 * @param {Record<string, unknown>} debug
 */
export function reportParseFailure(parserId, errorType, pageContext, debug = {}) {
	reportFailure(parserId, errorType, pageContext, debug);
}

/**
 * @param {string} parserId
 * @param {string} errorType
 * @param {string} pageContext
 * @param {Record<string, unknown>} debug
 */
function reportFailure(parserId, errorType, pageContext, debug) {
	const rateLimited = isRateLimited(parserId, pageContext);
	logParseFailure(parserId, errorType, pageContext, debug, rateLimited);
	if (rateLimited) {
		return;
	}
	rateLimitMap.set(rateLimitKey(parserId, pageContext), Date.now());
	queueParseFailure({
		parser_id: parserId,
		error_type: errorType,
		selector_bundle_version: SELECTOR_BUNDLE_VERSION,
		page_context: pageContext,
		debug_json: redactObject(debug),
	});
	if (notifyCallback) {
		try {
			notifyCallback();
		} catch (err) {
			console.warn("[VHelper Parse] notify callback failed:", err);
		}
	}
}

/**
 * Query a selector and record hit/miss in a hits map.
 * @param {Document | Element} root
 * @param {string} selectorKey
 * @param {string} selector
 * @param {Record<string, boolean>} hits
 * @returns {Element | null}
 */
export function queryWithHit(root, selectorKey, selector, hits) {
	const el = root.querySelector(selector);
	hits[selectorKey] = Boolean(el);
	return el;
}
