import { GENERIC_REVIEW_LABELS, VINE_REVIEWS, VINE_REVIEWS_PATH } from "../selectors.js";
import { monitoredParse, queryWithHit } from "../ParseMonitor.js";
import { parseProductTitleFromDocument } from "./product.js";

const PENDING_REVIEW_TYPE = "pending_review";

/**
 * @param {string} href
 */
export function isVineReviewsPage(href = window.location.href) {
	try {
		const url = new URL(href);
		if (!VINE_REVIEWS_PATH.test(url.pathname)) {
			return false;
		}
		const type = url.searchParams.get("review-type");
		return type !== "completed";
	} catch {
		return false;
	}
}

/**
 * @param {string} href
 */
export function getAmazonOrigin(href = window.location.href) {
	return new URL(href).origin;
}

/**
 * @param {string} title
 * @param {string} [asin]
 */
export function isGenericProductTitle(title, asin = "") {
	if (!title || typeof title !== "string") {
		return true;
	}
	const t = title.replace(/\s+/g, " ").trim();
	if (t.length < 4) {
		return true;
	}
	if (asin && t.toUpperCase() === asin.toUpperCase()) {
		return true;
	}
	return GENERIC_REVIEW_LABELS.test(t);
}

/**
 * @param {string} text
 */
function cleanTitleText(text) {
	return (text || "").replace(/\s+/g, " ").trim();
}

/**
 * @param {Element | null | undefined} el
 */
export function isDisabledReviewItemBtn(el) {
	if (!el || !(el instanceof Element)) {
		return true;
	}
	if (el.matches?.('[aria-disabled="true"], .a-disabled, .a-button-disabled')) {
		return true;
	}
	if (el.closest?.(".a-button-disabled, .a-disabled")) {
		return true;
	}
	const href = el.getAttribute("href") || "";
	if (!href || href === "#" || href.startsWith("javascript:")) {
		return true;
	}
	return false;
}

/**
 * @param {Element} row
 */
export function rowIndicatesUnavailable(row) {
	for (const el of row.querySelectorAll(VINE_REVIEWS.TITLE_CANDIDATES + ", " + VINE_REVIEWS.REVIEW_STATUS_COL)) {
		const t = cleanTitleText(el.textContent);
		if (/^unavailable$/i.test(t)) {
			return true;
		}
	}
	return false;
}

/**
 * Skip Vine rows that cannot be reviewed (unavailable product, disabled action, missing data).
 * @param {Element} row
 * @param {HTMLAnchorElement | null} reviewBtn
 * @param {{ asin: string, productTitle: string, orderDateMs: number | null, imageUrl: string | null }} details
 */
export function shouldSkipPendingReviewRow(row, reviewBtn, { asin, productTitle }) {
	if (!reviewBtn || isDisabledReviewItemBtn(reviewBtn)) {
		return true;
	}
	if (!asin) {
		return true;
	}
	if (rowIndicatesUnavailable(row) || /^unavailable$/i.test(cleanTitleText(productTitle))) {
		return true;
	}
	return false;
}

/**
 * @param {Element} row
 * @param {HTMLAnchorElement} reviewBtn
 * @param {HTMLImageElement|null} img
 * @param {string} asin
 */
function resolveProductTitleFromRow(row, reviewBtn, img, asin) {
	for (const anchor of row.querySelectorAll(VINE_REVIEWS.ROW_LINKS)) {
		if (anchor === reviewBtn) {
			continue;
		}
		if (anchor.getAttribute("name") === "vvp-reviews-table--review-item-btn") {
			continue;
		}
		const href = anchor.getAttribute("href") || "";
		if (!href.includes(asin) && !href.includes("/dp/")) {
			continue;
		}
		const t = cleanTitleText(anchor.textContent);
		if (!isGenericProductTitle(t, asin)) {
			return t.slice(0, 200);
		}
	}

	if (img) {
		const alt = cleanTitleText(img.getAttribute("alt") || "");
		if (!isGenericProductTitle(alt, asin)) {
			return alt.slice(0, 200);
		}
		const imgTitle = cleanTitleText(img.getAttribute("title") || "");
		if (!isGenericProductTitle(imgTitle, asin)) {
			return imgTitle.slice(0, 200);
		}
	}

	const clone = row.cloneNode(true);
	clone.querySelectorAll(VINE_REVIEWS.ROW_STRIP_ACTIONS).forEach((el) => el.remove());

	const candidates = [];
	const pushCandidate = (raw) => {
		const t = cleanTitleText(raw);
		if (!isGenericProductTitle(t, asin) && !/^\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}/.test(t)) {
			candidates.push(t);
		}
	};

	clone.querySelectorAll(VINE_REVIEWS.TITLE_CANDIDATES).forEach((el) => {
		pushCandidate(el.textContent);
	});

	for (const cell of clone.querySelectorAll("td, span, div, p")) {
		pushCandidate(cell.textContent);
	}

	if (candidates.length) {
		candidates.sort((a, b) => b.length - a.length);
		return candidates[0].slice(0, 200);
	}

	const scripts = row.closest("table")?.ownerDocument?.querySelectorAll("script") || [];
	for (const script of scripts) {
		const text = script.textContent || "";
		if (!text.includes(asin)) {
			continue;
		}
		const titleMatch =
			text.match(new RegExp(`"asin"\\s*:\\s*"${asin}"[\\s\\S]{0,400}?"title"\\s*:\\s*"([^"]+)"`, "i")) ||
			text.match(new RegExp(`"title"\\s*:\\s*"([^"]+)"[\\s\\S]{0,400}?"asin"\\s*:\\s*"${asin}"`, "i"));
		if (titleMatch?.[1]) {
			const t = cleanTitleText(
				titleMatch[1].replace(/\\u([\dA-Fa-f]{4})/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
			);
			if (!isGenericProductTitle(t, asin)) {
				return t.slice(0, 200);
			}
		}
	}

	return asin;
}

/**
 * @param {string} origin
 * @param {number} [page]
 */
export function buildVineReviewsPageUrl(origin, page = 1) {
	const url = new URL(`${origin}/vine/vine-reviews`);
	url.searchParams.set("review-type", PENDING_REVIEW_TYPE);
	if (page > 1) {
		url.searchParams.set("page", String(page));
	}
	return url.toString();
}

/**
 * @param {Document} doc
 */
export function parseReviewsFromDocument(doc) {
	return monitoredParse("vine.reviews.pending_rows", { doc, pageUrl: doc?.baseURI }, () => {
		const items = [];
		const rows = doc.querySelectorAll(VINE_REVIEWS.TABLE_ROW);
		rows.forEach((row, idx) => {
			if (idx === 0 || row.classList.contains(VINE_REVIEWS.HEADING_ROW_CLASS)) {
				return;
			}
			try {
				const hits = {};
				const reviewBtn = queryWithHit(row, "VINE_REVIEWS.REVIEW_ITEM_BTN", VINE_REVIEWS.REVIEW_ITEM_BTN, hits);
				if (!reviewBtn || isDisabledReviewItemBtn(reviewBtn)) {
					return;
				}
				let asin = null;
				try {
					asin = new URL(reviewBtn.href, doc.baseURI || window.location.href).searchParams.get("asin");
				} catch {
					asin = null;
				}
				if (!asin) {
					return;
				}

				const orderEl =
					row.querySelector(VINE_REVIEWS.ORDER_TIMESTAMP) || row.querySelector(VINE_REVIEWS.TIMESTAMP) || row;
				let orderDateMs = null;
				const tsAttr = orderEl.getAttribute("data-order-timestamp") || orderEl.getAttribute("data-timestamp");
				if (tsAttr) {
					const n = Number(tsAttr);
					if (n > 0) {
						orderDateMs = n < 1e12 ? n * 1000 : n;
					}
				}

				const img = row.querySelector(VINE_REVIEWS.IMAGE);
				const imageUrl = img ? img.src : null;
				let productTitle = resolveProductTitleFromRow(row, reviewBtn, img, asin);
				if (isGenericProductTitle(productTitle, asin)) {
					productTitle = asin;
				}

				if (
					shouldSkipPendingReviewRow(row, reviewBtn, {
						asin,
						productTitle,
					})
				) {
					return;
				}

				const origin = doc.defaultView?.location?.origin || getAmazonOrigin();
				const productUrl = `${origin}/dp/${asin}`;

				items.push({
					asin,
					productTitle,
					productUrl,
					imageUrl,
					orderDateMs,
					isOverdue: orderDateMs ? Date.now() - orderDateMs > 30 * 24 * 60 * 60 * 1000 : false,
				});
			} catch (err) {
				console.warn("[VHelper Review Manager] Skipping unparsable review row", err);
			}
		});
		return items;
	});
}

/** @type {Map<string, string>} */
const productTitleCache = new Map();

/**
 * @param {string} origin
 * @param {string} asin
 */
export async function fetchProductTitleFromDp(origin, asin) {
	const cacheKey = `${origin}:${asin}`;
	if (productTitleCache.has(cacheKey)) {
		return productTitleCache.get(cacheKey);
	}

	try {
		const response = await fetch(`${origin}/dp/${asin}`, { credentials: "include" });
		if (!response.ok) {
			productTitleCache.set(cacheKey, null);
			return null;
		}
		const html = await response.text();
		const doc = new DOMParser().parseFromString(html, "text/html");
		const title = parseProductTitleFromDocument(doc, asin);

		if (title) {
			productTitleCache.set(cacheKey, title);
			return title;
		}
	} catch {
		// fall through
	}

	productTitleCache.set(cacheKey, null);
	return null;
}

/**
 * @param {Array<{ asin: string, productTitle: string }>} items
 * @param {string} origin
 * @param {(done: number, total: number) => void} [onProgress]
 */
export async function enrichProductTitles(items, origin, onProgress) {
	const need = items.filter((item) => isGenericProductTitle(item.productTitle, item.asin));
	let done = 0;
	for (const item of need) {
		const title = await fetchProductTitleFromDp(origin, item.asin);
		if (title) {
			item.productTitle = title;
		} else if (isGenericProductTitle(item.productTitle, item.asin)) {
			item.productTitle = item.asin;
		}
		done += 1;
		if (onProgress) {
			onProgress(done, need.length);
		}
		await new Promise((r) => setTimeout(r, 250));
	}
	return items;
}
