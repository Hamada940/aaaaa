import { VINE_GRID } from "../selectors.js";
import { monitoredParse, queryWithHit } from "../ParseMonitor.js";
import { Item } from "../../models/Item.js";
import { collectExtraSeeDetailsDatasetFromInput } from "../../utils/SeeDetailsDataset.js";

/**
 * Extract raw tile fields from a Vine item tile element (without creating an Item).
 * @param {HTMLElement} tileDOM
 * @returns {object | null}
 */
export function parseTileElement(tileDOM) {
	return monitoredParse("vine.tile.from_element", { pageUrl: tileDOM?.baseURI }, () => {
		const hits = {};
		const asinInput = queryWithHit(tileDOM, "VINE_GRID.TILE_ASIN_INPUT", VINE_GRID.TILE_ASIN_INPUT, hits);
		if (!asinInput) {
			return null;
		}
		const asin = asinInput.dataset.asin;
		if (!asin) {
			return null;
		}

		const titleLink = queryWithHit(tileDOM, "VINE_GRID.TILE_TITLE", VINE_GRID.TILE_TITLE, hits);
		const title = titleLink ? titleLink.innerText || titleLink.textContent : null;

		const img =
			queryWithHit(tileDOM, "VINE_GRID.TILE_IMAGE", VINE_GRID.TILE_IMAGE, hits) ||
			queryWithHit(tileDOM, "VINE_GRID.TILE_IMAGE_FALLBACK", VINE_GRID.TILE_IMAGE_FALLBACK, hits);
		const img_url = img ? img.src : null;

		const recommendationId = asinInput.dataset.recommendationId;
		const recommendationType = asinInput.dataset.recommendationType;

		return {
			asin,
			title,
			img_url,
			thumbnail: img_url,
			is_parent_asin: asinInput.dataset.isParentAsin === "true",
			is_pre_release: asinInput.dataset.isPreRelease === "true",
			enrollment_guid: recommendationId ? Item.getEnrollmentGuidFromRecommendationId(recommendationId) : null,
			queue: Item.getQueueFromData(recommendationType, recommendationId),
			recommendationId,
			recommendationType,
			see_details_button_dataset: collectExtraSeeDetailsDatasetFromInput(asinInput),
			_selectorHits: hits,
		};
	});
}

/**
 * Parse all tiles from a fetched Vine items page document.
 * @param {Document} doc
 * @returns {object[]}
 */
export function parseTilesFromDocument(doc) {
	return monitoredParse(
		"vine.items.fetch_page",
		{ doc, pageUrl: doc?.baseURI },
		() => {
			const tiles = doc.querySelectorAll(VINE_GRID.TILE_IN_GRID);
			const items = [];
			for (const tile of tiles) {
				const parsed = parseTileElement(tile);
				if (parsed) {
					const { _selectorHits, ...item } = parsed;
					items.push(item);
				}
			}
			return items;
		},
		{
			validate: (result) => Array.isArray(result),
		}
	);
}

/**
 * Query tile elements on the live page.
 * @param {string} [selector]
 * @returns {NodeListOf<Element>}
 */
export function queryPageTiles(selector = VINE_GRID.TILE_NOT_PINNED) {
	return document.querySelectorAll(selector);
}
