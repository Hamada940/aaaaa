import { AMAZON_ADDRESS_BOOK } from "../selectors.js";
import { monitoredParse } from "../ParseMonitor.js";

/**
 * Parse address book entries from a fetched Amazon address list HTML document.
 * @param {Document} doc
 * @returns {Map<string, string>}
 */
export function parseAddressBookFromDocument(doc) {
	return monitoredParse("amazon.address.book_entries", { doc, pageUrl: doc?.baseURI }, () => {
		const uniqueAddresses = new Map();
		const editLinks = doc.querySelectorAll(AMAZON_ADDRESS_BOOK.EDIT_LINK);

		for (const link of editLinks) {
			const linkUrl = new URL(link.href, doc.baseURI || "https://www.amazon.com");
			const addressID = linkUrl.searchParams.get("addressID");
			if (addressID && !uniqueAddresses.has(addressID)) {
				let label = `Address ${addressID}`;
				const addressBox = link.closest(".address-column, .address-box, div");
				if (addressBox) {
					const parts = [];
					addressBox.querySelectorAll(AMAZON_ADDRESS_BOOK.LABEL_PARTS).forEach((el) => {
						const t = el.textContent.trim();
						if (t) {
							parts.push(t);
						}
					});
					if (parts.length) {
						label = parts.join(", ");
					}
				}
				uniqueAddresses.set(addressID, label);
			}
		}
		return uniqueAddresses;
	});
}
