import { PAGE_GUARDS } from "../selectors.js";
import { monitoredParse } from "../ParseMonitor.js";

/**
 * Detect Amazon login redirect page.
 * @param {Document} doc
 * @returns {boolean}
 */
export function isPageLogin(doc) {
	return monitoredParse("amazon.page.guard.login", { doc, pageUrl: doc?.baseURI }, () => {
		if (doc.querySelector(PAGE_GUARDS.LOGIN_PORTAL)) {
			return true;
		}
		const loginForm2 = doc.querySelector(PAGE_GUARDS.LOGIN_FORM);
		return Boolean(loginForm2 && loginForm2.name === "signIn");
	});
}

/**
 * Detect Amazon captcha challenge page.
 * @param {Document} doc
 * @returns {boolean}
 */
export function isPageCaptcha(doc) {
	return monitoredParse("amazon.page.guard.captcha", { doc, pageUrl: doc?.baseURI }, () => {
		const captchaForm = doc.querySelector(PAGE_GUARDS.CAPTCHA_FORM);
		if (!captchaForm) {
			return false;
		}
		const captcha = captchaForm.action.split("/")[4];
		return captcha === "validateCaptcha";
	});
}

/**
 * Detect Amazon "dog" error page.
 * @param {Document} doc
 * @returns {boolean}
 */
export function isPageDog(doc) {
	return monitoredParse("amazon.page.guard.dog", { doc, pageUrl: doc?.baseURI }, () => {
		const dogImg = doc.querySelector(PAGE_GUARDS.DOG_IMAGE);
		return Boolean(dogImg && dogImg.alt === PAGE_GUARDS.DOG_ALT);
	});
}
