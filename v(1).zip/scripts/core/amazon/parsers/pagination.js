import { AMAZON_PAGINATION, PAGINATION_LAST_LI_REGEX } from "../selectors.js";
import { monitoredParse } from "../ParseMonitor.js";

/**
 * Extract total page count from Amazon Vine pagination markup.
 * @param {Document} doc
 * @returns {number}
 */
export function getPageCount(doc) {
	return monitoredParse("vine.pagination.page_count", { doc, pageUrl: doc?.baseURI }, () => {
		if (!doc) return 1;
		const lis = doc.querySelectorAll(AMAZON_PAGINATION.LIST_ITEM_NOT_LAST);
		if (!lis.length) return 1;
		const lastLi = lis[lis.length - 1];
		const text = lastLi?.textContent?.trim() ?? "";
		const n = parseInt(text, 10);
		return Number.isFinite(n) && n > 0 ? n : 1;
	});
}

/**
 * Detect whether raw HTML has an enabled "next page" pagination control.
 * @param {string} html
 * @returns {boolean}
 */
export function hasNextPageFromHtml(html) {
	return monitoredParse("vine.reviews.pagination_next", { pageUrl: "/vine/vine-reviews" }, () => {
		const lastLiMatch = html.match(PAGINATION_LAST_LI_REGEX);
		if (!lastLiMatch) {
			return false;
		}
		return !lastLiMatch[0].includes("a-disabled");
	});
}
