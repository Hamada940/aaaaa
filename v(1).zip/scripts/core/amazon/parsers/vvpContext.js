import { VVP_CONTEXT } from "../selectors.js";
import { monitoredParse, queryWithHit } from "../ParseMonitor.js";

/**
 * Find the vvp-context script element in a document.
 * @param {Document} doc
 * @returns {HTMLScriptElement | null}
 */
export function findVvpContextScriptElement(doc) {
	if (!doc) {
		return null;
	}
	const hits = {};
	const exact = queryWithHit(doc, "VVP_CONTEXT.SCRIPT", VVP_CONTEXT.SCRIPT, hits);
	if (exact) {
		return exact;
	}
	for (const script of doc.querySelectorAll(VVP_CONTEXT.SCRIPT_ALL)) {
		try {
			const state = JSON.parse(script.getAttribute("data-a-state") || "null");
			if (state?.key === VVP_CONTEXT.CONTEXT_KEY) {
				hits["VVP_CONTEXT.fallback"] = true;
				return script;
			}
		} catch {
			// ignore malformed data-a-state
		}
	}
	hits["VVP_CONTEXT.fallback"] = false;
	return null;
}

/**
 * Parse vvp-context JSON from a document.
 * @param {Document} doc
 * @returns {object | null}
 */
export function parseVvpContextFromDocument(doc) {
	return monitoredParse(
		"vine.vvp_context",
		{ doc, pageUrl: doc?.baseURI },
		() => {
			const script = findVvpContextScriptElement(doc);
			if (!script) {
				return null;
			}
			return JSON.parse(script.innerHTML);
		},
		{
			validate: (result) => result === null || (typeof result === "object" && result !== null),
		}
	);
}

/**
 * Extract CSRF token from vvp-context in a fetched document.
 * @param {Document} doc
 * @returns {string | null}
 */
export function parseCsrfTokenFromDocument(doc) {
	const ctx = parseVvpContextFromDocument(doc);
	return ctx?.csrfToken ?? null;
}
