import { AMAZON_PRODUCT } from "../selectors.js";
import { monitoredParse, queryWithHit } from "../ParseMonitor.js";
import { isGenericProductTitle } from "./reviews.js";

/**
 * @param {string} text
 */
function cleanTitleText(text) {
	return (text || "").replace(/\s+/g, " ").trim();
}

/**
 * @param {Document} doc
 * @param {string} [asin]
 * @returns {string | null}
 */
export function parseProductTitleFromDocument(doc, asin = "") {
	return monitoredParse("amazon.product.title", { doc, pageUrl: doc?.baseURI }, () => {
		const hits = {};
		let title = cleanTitleText(
			queryWithHit(doc, "AMAZON_PRODUCT.TITLE", AMAZON_PRODUCT.TITLE, hits)?.textContent || ""
		);
		if (isGenericProductTitle(title, asin)) {
			const meta =
				queryWithHit(doc, "AMAZON_PRODUCT.META_TITLE", AMAZON_PRODUCT.META_TITLE, hits)?.getAttribute(
					"content"
				) || "";
			title = cleanTitleText(meta.replace(/^Amazon\.[^:]+:\s*/i, "").replace(/\s*:\s*Amazon\..+$/i, ""));
		}
		if (!isGenericProductTitle(title, asin)) {
			return title;
		}
		return null;
	});
}

/**
 * @param {Document} doc
 * @returns {string | null}
 */
export function parseCurrentPriceFromDocument(doc) {
	return monitoredParse("amazon.product.price", { doc, pageUrl: doc?.baseURI }, () => {
		const hits = {};
		for (let i = 0; i < AMAZON_PRODUCT.PRICE_SELECTORS.length; i++) {
			const selector = AMAZON_PRODUCT.PRICE_SELECTORS[i];
			const text = queryWithHit(doc, `AMAZON_PRODUCT.PRICE_${i}`, selector, hits)?.textContent?.trim();
			if (text) {
				return text;
			}
		}
		const buybox =
			queryWithHit(doc, "AMAZON_PRODUCT.BUYBOX", AMAZON_PRODUCT.BUYBOX, hits) ||
			queryWithHit(doc, "AMAZON_PRODUCT.BUYBOX_DESKTOP", AMAZON_PRODUCT.BUYBOX_DESKTOP, hits) ||
			queryWithHit(doc, "AMAZON_PRODUCT.BUYBOX_QUALIFIED", AMAZON_PRODUCT.BUYBOX_QUALIFIED, hits);
		const fallback = buybox?.querySelector(AMAZON_PRODUCT.BUYBOX_PRICE)?.textContent?.trim();
		return fallback || null;
	});
}

/**
 * @param {Document} doc
 * @returns {string}
 */
export function extractProductDescription(doc) {
	return monitoredParse("amazon.product.description", { doc, pageUrl: doc?.baseURI }, () => {
		const parts = [];

		const bullets = doc.querySelector(AMAZON_PRODUCT.FEATURE_BULLETS);
		if (bullets) {
			bullets.querySelectorAll(AMAZON_PRODUCT.FEATURE_BULLET_ITEM).forEach((li) => {
				const t = li.textContent.trim();
				if (t) {
					parts.push(t);
				}
			});
		}

		const desc =
			doc.querySelector(AMAZON_PRODUCT.DESCRIPTION) ||
			doc.querySelector(AMAZON_PRODUCT.DESCRIPTION_APLUS) ||
			doc.querySelector(AMAZON_PRODUCT.DESCRIPTION_FEATURE_DIV);
		if (desc) {
			const t = desc.textContent.trim();
			if (t) {
				parts.push(t);
			}
		}

		const title = doc.querySelector(AMAZON_PRODUCT.TITLE);
		if (title) {
			parts.unshift(title.textContent.trim());
		}

		return parts.join("\n\n").slice(0, 12000);
	});
}

/**
 * @param {string} productUrl
 */
export async function fetchProductPageData(productUrl) {
	const response = await fetch(productUrl, { credentials: "include" });
	if (!response.ok) {
		throw new Error(`Failed to load product page (${response.status})`);
	}
	const html = await response.text();
	const doc = new DOMParser().parseFromString(html, "text/html");
	return {
		description: extractProductDescription(doc),
		currentPrice: parseCurrentPriceFromDocument(doc),
	};
}

/**
 * @param {string} productUrl
 */
export async function fetchProductDescription(productUrl) {
	const { description } = await fetchProductPageData(productUrl);
	return description;
}
