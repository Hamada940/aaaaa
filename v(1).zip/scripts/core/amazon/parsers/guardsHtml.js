import { PAGE_GUARDS } from "../selectors.js";

/**
 * HTML-string page guards for environments without DOMParser (e.g. extension service workers).
 */

function normalizeHtml(html) {
	return (html || "").toLowerCase();
}

/**
 * @param {string} html
 * @returns {boolean}
 */
export function isHtmlPageDog(html) {
	const lower = normalizeHtml(html);
	const hasDogImg =
		lower.includes('id="d"') ||
		lower.includes("id='d'") ||
		lower.includes("img#d") ||
		lower.includes('<img id="d"');
	if (!hasDogImg) {
		return false;
	}

	const dogAlt = PAGE_GUARDS.DOG_ALT.toLowerCase();
	return (
		lower.includes(dogAlt) ||
		lower.includes("dogs of amazon") ||
		lower.includes("chiens d'amazon") ||
		lower.includes("chiens d&#39;amazon")
	);
}

/**
 * @param {string} html
 * @returns {boolean}
 */
export function isHtmlPageCaptcha(html) {
	const lower = normalizeHtml(html);

	if (lower.includes('name="captchacharacters"') || lower.includes("name='captchacharacters'")) {
		return true;
	}
	if (lower.includes("validatecaptcha")) {
		return true;
	}
	if (lower.includes("enter the characters you see")) {
		return true;
	}

	return false;
}

/**
 * @param {string} html
 * @returns {boolean}
 */
export function isHtmlPageLogin(html) {
	const lower = normalizeHtml(html);

	if (lower.includes("authportal-main-section")) {
		return true;
	}
	if (lower.includes("auth-validate-form") && lower.includes("signin")) {
		return true;
	}
	if (lower.includes('type="password"') && lower.includes("signin")) {
		return true;
	}

	return false;
}

/**
 * @param {string} html
 * @returns {"dog" | "captcha" | "login" | null}
 */
export function detectHtmlPageGuard(html) {
	if (isHtmlPageDog(html)) {
		return "dog";
	}
	if (isHtmlPageCaptcha(html)) {
		return "captcha";
	}
	if (isHtmlPageLogin(html)) {
		return "login";
	}
	return null;
}
