import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { Internationalization } from "/scripts/core/services/Internationalization.js";
import { ChromeStorageAdapter } from "/scripts/infrastructure/StorageAdapter.js";
import { DeviceMgr } from "/scripts/core/services/DeviceMgr.js";
import { CHOICE_SETTING_PATHS, expandChoiceSettings } from "/scripts/core/services/SettingsAnalyticsChoices.js";

const SUBMIT_INTERVAL_MS = 7 * 24 * 60 * 60 * 1000;
const LAST_SUBMIT_STORAGE_KEY = "settingsAnalyticsLastSubmit";
const FLOAT_EPSILON = 0.001;

const BLOCKED_EXACT = new Set([
	"general.uuid",
	"general.cid",
	"general.deviceName",
	"general.customCSS",
	"discord.guid",
	"discord.webhooks",
	"vvpContext",
	"thorvarium",
]);

const BLOCKED_PREFIXES = [
	"crypto.",
	"general.fingerprint.",
	"checkout.",
	"metrics.",
	"vvpContext.",
	"thorvarium.",
	"notification.monitor.vineJailCheck.",
];

const SPECIAL_ONLY_PATHS = new Set([
	"general.ETV.modifier",
	"general.keywordGroups",
	"general.orderNow.preferredAddressId",
	"notification.autoload.favouriteCategories",
	"discord.guid",
	"discord.webhooks",
]);

const storage = new ChromeStorageAdapter("local");
const cryptoKeys = new CryptoKeys();
const i18n = new Internationalization();

function isBlockedPath(path) {
	if (BLOCKED_EXACT.has(path)) {
		return true;
	}
	if (BLOCKED_PREFIXES.some((prefix) => path === prefix.slice(0, -1) || path.startsWith(prefix))) {
		return true;
	}
	if (path.startsWith("general.keywordGroups.")) {
		return true;
	}
	if (path.startsWith("notification.autoload.favouriteCategories.")) {
		return true;
	}
	if (/^discord\.webhook\.[^.]+\.(url|content)$/.test(path)) {
		return true;
	}
	return false;
}

function isPlainObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}

function defaultBooleanize(value) {
	if (typeof value === "boolean") {
		return value;
	}
	if (typeof value === "number") {
		return true;
	}
	if (typeof value === "string") {
		return value.trim() !== "";
	}
	if (Array.isArray(value)) {
		return value.length > 0;
	}
	return false;
}

function walkLeaves(obj, prefix, output) {
	if (!isPlainObject(obj)) {
		return;
	}

	for (const [key, value] of Object.entries(obj)) {
		const path = prefix ? `${prefix}.${key}` : key;

		if (isBlockedPath(path) || SPECIAL_ONLY_PATHS.has(path) || CHOICE_SETTING_PATHS.has(path)) {
			continue;
		}

		if (isPlainObject(value)) {
			walkLeaves(value, path, output);
			continue;
		}

		output[path] = defaultBooleanize(value);
	}
}

function pathExistsInTree(tree, path) {
	const parts = path.split(".");
	let current = tree;
	for (const part of parts) {
		if (!isPlainObject(current) || !Object.prototype.hasOwnProperty.call(current, part)) {
			return false;
		}
		current = current[part];
	}
	return true;
}

function hasPathPrefixInTree(tree, prefix) {
	const parts = prefix.split(".");
	let current = tree;
	for (const part of parts) {
		if (!isPlainObject(current) || !Object.prototype.hasOwnProperty.call(current, part)) {
			return false;
		}
		current = current[part];
	}
	return true;
}

function applySpecialProcessors(settings) {
	const getFromSettings = (path) => {
		if (!pathExistsInTree(settings, path)) {
			return undefined;
		}
		const parts = path.split(".");
		let current = settings;
		for (const part of parts) {
			current = current[part];
		}
		return current;
	};

	const special = {};

	if (pathExistsInTree(settings, "general.ETV.modifier")) {
		const etvModifier = getFromSettings("general.ETV.modifier");
		special["general.ETV.modifier"] = typeof etvModifier === "number" && Math.abs(etvModifier - 1) > FLOAT_EPSILON;
	}

	if (pathExistsInTree(settings, "general.keywordGroups")) {
		const keywordGroups = getFromSettings("general.keywordGroups");
		special["general.keywordGroups"] = Array.isArray(keywordGroups) && keywordGroups.length >= 1;
	}

	if (pathExistsInTree(settings, "notification.autoload.favouriteCategories")) {
		const favouriteCategories = getFromSettings("notification.autoload.favouriteCategories");
		special["notification.autoload.favouriteCategories"] =
			Array.isArray(favouriteCategories) && favouriteCategories.length >= 1;
	}

	if (pathExistsInTree(settings, "general.orderNow.preferredAddressId")) {
		const preferredAddress = getFromSettings("general.orderNow.preferredAddressId");
		special["general.orderNow.preferredAddressId"] =
			typeof preferredAddress === "string" && preferredAddress.trim() !== "";
	}

	if (hasPathPrefixInTree(settings, "discord.webhook")) {
		const webhookTypes = ["KWsMatch", "AFA", "RFY", "zeroETV"];
		special["discord.webhooks"] = webhookTypes.some((type) => {
			const url = getFromSettings(`discord.webhook.${type}.url`);
			return typeof url === "string" && url.trim() !== "";
		});
	}

	if (pathExistsInTree(settings, "discord.guid")) {
		const discordGuid = getFromSettings("discord.guid");
		special["discord.guid"] = typeof discordGuid === "string" && discordGuid.trim() !== "";
	}

	return special;
}

export function buildSettingsMap(settingsTree) {
	const output = {};

	walkLeaves(settingsTree, "", output);
	Object.assign(output, applySpecialProcessors(settingsTree));
	Object.assign(output, expandChoiceSettings(settingsTree));

	const sorted = {};
	for (const key of Object.keys(output).sort()) {
		sorted[key] = !!output[key];
	}
	return sorted;
}

export async function computeClientHash(cid, deviceName) {
	const encoder = new TextEncoder();
	const data = encoder.encode(String(cid) + String(deviceName));
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	const hashArray = Array.from(new Uint8Array(hashBuffer));
	return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function getLastSubmitMs() {
	const stored = await storage.get(LAST_SUBMIT_STORAGE_KEY);
	return typeof stored === "number" ? stored : 0;
}

async function setLastSubmitMs(value) {
	await storage.set(LAST_SUBMIT_STORAGE_KEY, value);
}

let Settings = null;

async function ensureSettings(existingSettings = null) {
	if (existingSettings) {
		await existingSettings.waitForLoad();
		return existingSettings;
	}
	if (!Settings) {
		Settings = new SettingsMgr();
	}
	await Settings.waitForLoad();
	return Settings;
}

function resolveApiUrl(settingsMgr) {
	const until = settingsMgr.get("general.apiFallbackUntil", 0);
	if (typeof until === "number" && until > Date.now()) {
		return "https://api.vinehelper.ovh";
	}
	return "https://api.v-helper.com";
}

function logSkip(reason) {
	console.warn("[SettingsAnalytics] Skipped:", reason);
}

/**
 * @param {{ settingsMgr?: import("./SettingsMgr.js").SettingsMgr, env?: import("./Environment.js").Environment, cryptoKeys?: import("../utils/CryptoKeys.js").CryptoKeys, i18n?: import("./Internationalization.js").Internationalization }} [deps]
 * @returns {Promise<{ ok: true, content: Record<string, unknown>, settingsMap: Record<string, boolean> } | { ok: false, reason: string }>}
 */
async function buildSignedSubmissionPayload(deps = {}) {
	const settingsMgr = await ensureSettings(deps.settingsMgr);
	const keys = deps.cryptoKeys ?? cryptoKeys;
	const env = deps.env ?? null;
	const locale = deps.i18n ?? i18n;

	await keys.waitForLoad();

	const uuid = settingsMgr.get("general.uuid", false);
	if (!uuid) {
		return { ok: false, reason: "missing uuid" };
	}

	let cid = settingsMgr.get("general.cid", false);
	if (env && typeof env.getCID === "function") {
		try {
			cid = await env.getCID();
		} catch {
			// fall back to cached cid
		}
	}
	if (!cid) {
		return { ok: false, reason: "missing cid" };
	}

	const deviceName = settingsMgr.get("general.deviceName", false);
	if (!deviceName) {
		return { ok: false, reason: "missing deviceName" };
	}

	const countryCode = settingsMgr.get("general.country", false) || locale.getCountryCode();
	if (!countryCode) {
		return { ok: false, reason: "missing country" };
	}
	locale.setCountryCode(countryCode);

	const fid = settingsMgr.get("general.fingerprint.id", false);
	const settingsMap = buildSettingsMap(settingsMgr.getSettingsTree());
	const clientHash = await computeClientHash(cid, deviceName);
	const appVersion = chrome.runtime.getManifest().version;

	const content = {
		api_version: 5,
		app_version: appVersion,
		action: "submit_settings_analytics",
		country: countryCode,
		uuid,
		cid,
		fid: fid || null,
		client_hash: clientHash,
		settings: settingsMap,
	};

	content.s = await keys.signData(content);
	content.pk = await keys.getExportedPublicKey();

	return { ok: true, content, settingsMap };
}

/**
 * Anonymised settings map shown before a manual telemetry submit.
 * @param {{ settingsMgr?: import("./SettingsMgr.js").SettingsMgr }} [deps]
 */
export async function buildAnonymizedPreview(deps = {}) {
	const settingsMgr = await ensureSettings(deps.settingsMgr);
	return buildSettingsMap(settingsMgr.getSettingsTree());
}

/**
 * @param {boolean} force
 * @param {{ settingsMgr?: import("./SettingsMgr.js").SettingsMgr, env?: import("./Environment.js").Environment, cryptoKeys?: import("../utils/CryptoKeys.js").CryptoKeys, i18n?: import("./Internationalization.js").Internationalization }} [deps]
 */
export async function submitIfDue(force = false, deps = {}) {
	console.log("[SettingsAnalytics] submitIfDue called", { force });

	const settingsMgr = await ensureSettings(deps.settingsMgr);

	try {
		const lastSubmit = await getLastSubmitMs();
		if (!force && Date.now() - lastSubmit < SUBMIT_INTERVAL_MS) {
			logSkip("not due yet");
			return false;
		}

		const built = await buildSignedSubmissionPayload(deps);
		if (!built.ok) {
			logSkip(built.reason);
			return false;
		}

		const response = await fetch(resolveApiUrl(settingsMgr), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(built.content),
		});

		if (!response.ok) {
			logSkip(`HTTP ${response.status}`);
			return false;
		}

		const data = await response.json();
		if (data.error) {
			logSkip(String(data.error));
			return false;
		}

		await setLastSubmitMs(Date.now());
		console.log("[SettingsAnalytics] Submitted", Object.keys(built.settingsMap).length, "settings");
		return true;
	} catch (err) {
		console.warn("[SettingsAnalytics] Submit failed:", err);
		return false;
	}
}

export const SETTINGS_ANALYTICS_ALARM = "settingsAnalytics";
