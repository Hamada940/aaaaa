import { getMessage } from "/scripts/core/services/Internationalization.js";

/** @typedef {"variants" | "see-details" | "voiceOrders" | "checkout"} OrderNowProgressStep */

/**
 * @typedef {Object} OrderNowProgressEvent
 * @property {OrderNowProgressStep} step
 * @property {number} index - 1-based step index
 * @property {number} total - total steps in this flow
 */

/**
 * @param {OrderNowProgressStep} step
 * @returns {string}
 */
export function getOrderNowStepLabel(step) {
	switch (step) {
		case "variants":
			return getMessage("btnOrderNowStepVariants", "Variants…");
		case "see-details":
			return getMessage("btnOrderNowStepSeeDetails", "Details…");
		case "voiceOrders":
			return getMessage("btnOrderNowStepVoice", "Voice…");
		case "checkout":
			return getMessage("btnOrderNowStepCheckout", "Checkout…");
		default:
			return getMessage("btnOrderNowStepProcessing", "Processing…");
	}
}

/**
 * @param {OrderNowProgressEvent} event
 * @returns {string}
 */
export function formatOrderNowProgressLabel(event) {
	const stepLabel = getOrderNowStepLabel(event.step);
	if (event.total > 1) {
		return getMessage("btnOrderNowStepProgress", "$1$/$2$ $3$", [
			String(event.index),
			String(event.total),
			stepLabel,
		]);
	}
	return stepLabel;
}

/**
 * @param {HTMLElement|null|undefined} buttonEl
 * @param {OrderNowProgressEvent} event
 */
export function applyOrderNowButtonProgress(buttonEl, event) {
	if (!buttonEl) return;
	const textEl = buttonEl.querySelector(".vh-buy-now-btn-text") || buttonEl;
	textEl.textContent = formatOrderNowProgressLabel(event);
	buttonEl.disabled = true;
	buttonEl.style.opacity = "0.85";
	buttonEl.classList.add("vh-buy-now-btn--in-progress");
	buttonEl.dataset.vhOrderNowStep = event.step;
	const percent = Math.round((event.index / event.total) * 100);
	buttonEl.style.setProperty("--vh-order-now-progress", `${percent}%`);
}

/**
 * @param {HTMLElement|null|undefined} buttonEl
 * @param {{ error?: boolean }} [options]
 */
export function resetOrderNowButtonProgress(buttonEl, options = {}) {
	if (!buttonEl) return;
	buttonEl.classList.remove("vh-buy-now-btn--in-progress");
	buttonEl.style.removeProperty("--vh-order-now-progress");
	delete buttonEl.dataset.vhOrderNowStep;
	const textEl = buttonEl.querySelector(".vh-buy-now-btn-text") || buttonEl;
	if (options.error) {
		buttonEl.disabled = false;
		buttonEl.style.opacity = "1";
		textEl.textContent = getMessage("btnOrderNowError", "Error");
		return;
	}
	buttonEl.disabled = false;
	buttonEl.style.opacity = "1";
	textEl.textContent = getMessage("btnOrderNow", "Order Now");
}

/**
 * @param {HTMLElement|null|undefined} buttonEl
 * @returns {{ onProgress: (event: OrderNowProgressEvent) => void, setError: () => void, reset: () => void }}
 */
export function createOrderNowButtonProgress(buttonEl) {
	return {
		onProgress: (event) => applyOrderNowButtonProgress(buttonEl, event),
		setError: () => resetOrderNowButtonProgress(buttonEl, { error: true }),
		reset: () => resetOrderNowButtonProgress(buttonEl),
	};
}
