/**
 * Known select / radio / theme settings and their fixed option values.
 * Each becomes virtual keys: `{path}.{choice} = true|false` for analytics.
 */

const MONITOR_SOUND_CHOICES = ["0", "cash-register", "notification", "upgrade", "tada", "vintage-horn"];

const WEBHOOK_METHOD_CHOICES = ["POST", "GET", "PUT"];

/** @type {Record<string, { choices: string[], defaultValue?: string }>} */
export const CHOICE_SETTINGS = {
	"general.theme": {
		defaultValue: "forest",
		choices: ["aurora", "forest", "garish", "win31", "dark", "midnight", "scifi"],
	},
	"general.orderNow.shippingPriority": {
		defaultValue: "",
		choices: ["", "Amazon Day", "No-Rush", "Standard Shipping"],
	},
	"i18n.localeOverride": {
		defaultValue: "",
		choices: ["", "en", "de", "es", "fr", "it", "ja"],
	},
	"general.hiddenItemsCacheSize": {
		defaultValue: "4",
		choices: ["2", "3", "4", "5", "6", "7", "8", "9"],
	},
	"general.verbosePaginationStartPadding": {
		choices: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
	},
	"general.reviewToolbarMaxReviews": {
		choices: ["100", "250", "1000"],
	},
	"notification.soundCooldownDelay": {
		choices: ["0", "2000", "10000", "30000", "60000"],
	},
	"notification.connectionMode": {
		choices: ["0", "1"],
	},
	"notification.monitor.openLinksInNewTab": {
		choices: ["0", "1"],
	},
	"notification.monitor.v3LiteOpenLinksInNewTab": {
		choices: ["0", "1"],
	},
	"notification.monitor.v4OpenLinksInNewTab": {
		choices: ["0", "1"],
	},
	"notification.monitor.topRightLinkTarget": {
		choices: ["v3", "v3lite", "v4"],
	},
	"notification.monitor.zeroETV.sound": {
		choices: MONITOR_SOUND_CHOICES,
	},
	"notification.monitor.rfy.sound": {
		choices: MONITOR_SOUND_CHOICES,
	},
	"notification.monitor.regular.sound": {
		choices: MONITOR_SOUND_CHOICES,
	},
	"notification.screen.regular.sound": {
		choices: ["0", "notification", "upgrade", "vintage-horn"],
	},
	"discord.webhook.KWsMatch.method": {
		choices: WEBHOOK_METHOD_CHOICES,
	},
	"discord.webhook.AFA.method": {
		choices: WEBHOOK_METHOD_CHOICES,
	},
	"discord.webhook.RFY.method": {
		choices: WEBHOOK_METHOD_CHOICES,
	},
	"discord.webhook.zeroETV.method": {
		choices: WEBHOOK_METHOD_CHOICES,
	},
};

export const CHOICE_SETTING_PATHS = new Set(Object.keys(CHOICE_SETTINGS));

/**
 * @param {string} value
 * @returns {string}
 */
export function choiceKeySegment(value) {
	if (value === "" || value == null) {
		return "_default";
	}
	const segment = String(value)
		.trim()
		.replace(/[^a-zA-Z0-9_-]+/g, "_")
		.replace(/^_+|_+$/g, "");
	return segment || "_default";
}

function valuesMatch(stored, choice) {
	return String(stored ?? "") === String(choice);
}

function isPlainObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}

function pathExistsInTree(tree, path) {
	const parts = path.split(".");
	let current = tree;
	for (const part of parts) {
		if (!isPlainObject(current) || !Object.prototype.hasOwnProperty.call(current, part)) {
			return false;
		}
		current = current[part];
	}
	return true;
}

function getFromSettings(tree, path) {
	if (!pathExistsInTree(tree, path)) {
		return undefined;
	}
	const parts = path.split(".");
	let current = tree;
	for (const part of parts) {
		current = current[part];
	}
	return current;
}

/**
 * @param {object} settingsTree
 * @returns {Record<string, boolean>}
 */
export function expandChoiceSettings(settingsTree) {
	const output = {};

	for (const [path, config] of Object.entries(CHOICE_SETTINGS)) {
		const inTree = pathExistsInTree(settingsTree, path);
		if (!inTree && config.defaultValue === undefined) {
			continue;
		}

		const currentValue = inTree ? getFromSettings(settingsTree, path) : config.defaultValue;

		for (const choice of config.choices) {
			const key = `${path}.${choiceKeySegment(choice)}`;
			output[key] = valuesMatch(currentValue, choice);
		}
	}

	return output;
}
