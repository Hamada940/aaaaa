import { validate, ValidationError } from "/scripts/core/utils/ExpectationValidator.js";
import { OrderNowFailureError } from "/scripts/ui/components/OrderNowFailureReport.js";
import { showOrderNowFailureModal } from "/scripts/ui/components/OrderNowFailureModal.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
import { Internationalization, getMessage } from "/scripts/core/services/Internationalization.js";
import { ScreenNotification, ScreenNotifier } from "/scripts/ui/components/ScreenNotifier.js";
import { UnavailableAsinReporter } from "/scripts/core/services/UnavailableAsinReporter.js";
import { refreshCsrfTokenFromVinePage } from "/scripts/core/services/CsrfTokenRefresh.js";
import { isOrionBrowser, isSafari, isWebKitNonChromium } from "/scripts/core/utils/BrowserDetection.js";
import { createOrderNowButtonProgress } from "/scripts/core/services/OrderNowButtonProgress.js";

/** @typedef {import("/scripts/core/services/OrderNowButtonProgress.js").OrderNowProgressEvent} OrderNowProgressEvent */

const Settings = new SettingsMgr();
const Notifications = new ScreenNotifier();
const cryptoKeys = new CryptoKeys();
const i18n = new Internationalization();

export { ValidationError };

class ToasterError extends Error {
	constructor(message, details) {
		super(message);
		this.details = details;
	}
}

/**
 * Expectation template for the see-details API response.
 * Values: "/pattern/" = regex (actual coerced to string), "literal" = exact match, [] = must be array, null = must be null.
 */
export const SEE_DETAILS_EXPECTATION = Object.freeze({
	result: Object.freeze({
		asin: "/[A-Z0-9]{10,13}/",
		imageUrl: "/https:\\/\\/m\\.media-amazon.*/",
		productTitle: "/.*/",
		featureBullets: [],
		byLineContributors: [],
		catalogSize: "/.*/",
		taxCurrency: "/[A-Z]{3}/",
		taxValue: "/[0-9 ,.]+/",
		promotionId: "/[A-Z0-9]{12,14}/",
		purchasePolicyCode: "AmazonVine",
		asinTangoEligible: "/true|false/",
		productSiteLaunchDate: "/1|[0-9]{12,14}/",
		limitedQuantity: "/true|false/",
	}),
	error: null,
});

/**
 * Expectation template for the voiceOrders API response (used to build checkout form).
 */
export const VOICE_ORDER_EXPECTATION = Object.freeze({
	result: Object.freeze({
		orderId: null,
		legacyOrderId: null,
		recommendationType: null,
		recommendationId: null,
		itemAsin: null,
		customerId: null,
		addressId: null,
		legacyAddressId: null,
		slateToken: null,
		proceedToCheckout: "/true/",
		offerListingId: "/.+/",
		taxAccountId: null,
		internalIpClass: null,
	}),
	error: null,
});

/**
 * Build Accept-Language header value from the browser's language preferences.
 * @returns {string}
 */
function getBrowserAcceptLanguage() {
	if (typeof navigator !== "undefined" && Array.isArray(navigator.languages) && navigator.languages.length > 0) {
		return navigator.languages
			.map((lang, i) => (i === 0 ? lang : `${lang};q=${(1 - i * 0.1).toFixed(1)}`))
			.join(", ");
	}
	if (typeof navigator !== "undefined" && navigator.language) {
		return navigator.language;
	}
	return "en-US,en;q=0.9";
}

/**
 * BuyNow: starts the Vine "Buy Now" flow by fetching recommendation/item data
 * and preparing the checkout context. Used when general.orderNow is enabled.
 */
export class BuyNow {
	#env = null;
	#baseUrl = null;
	#parentAsin = null;
	#unavailableReporter = null;

	#isIOSMode() {
		return isWebKitNonChromium() || isOrionBrowser() || isSafari();
	}

	#openUrlInNewTab(url) {
		if (!url) return;
		try {
			if (chrome?.tabs?.create) {
				chrome.tabs.create({ url });
				return;
			}
			if (chrome?.runtime?.sendMessage) {
				chrome.runtime.sendMessage({ type: "openUrlInNewTab", url });
				return;
			}
		} catch (error) {
			console.warn("[BuyNow] Failed to open tab via extension API, falling back to window.open", error);
		}
		window.open(url, "_blank", "noopener,noreferrer");
	}

	#openPostInNewTab(actionUrl, fields) {
		if (!actionUrl) return;
		const formFields = Array.isArray(fields) ? fields : [];
		const redirectUrl = `${this.#baseUrl}/vine/vh-monitor/checkout-redirect/`;
		const params = new URLSearchParams();
		params.set("action", String(actionUrl));
		params.set("fields", JSON.stringify(formFields));
		this.#openUrlInNewTab(`${redirectUrl}?${params.toString()}`);
	}
	/**
	 * Build request options for Vine API fetches (same-origin, with credentials).
	 * Uses minimal headers so the request is accepted; cookies are sent via credentials.
	 * @param {string} referrer - Referrer URL (e.g. vine-items page)
	 * @returns {RequestInit}
	 */
	#getFetchOptions(referrer) {
		return {
			method: "GET",
			mode: "cors",
			credentials: "include",
			headers: {
				accept: "*/*",
				"accept-language": getBrowserAcceptLanguage(),
				"sec-fetch-dest": "empty",
				"sec-fetch-mode": "cors",
				"sec-fetch-site": "same-origin",
			},
			referrer: referrer || this.#baseUrl + "/vine/vine-items",
		};
	}

	/** Queue name → Vine API recommendationType (for voiceOrders body). */
	static #QUEUE_TO_RECOMMENDATION_TYPE = Object.freeze({
		potluck: "VENDOR_TARGETED",
		last_chance: "VENDOR_VINE_FOR_ALL",
		encore: "VINE_FOR_ALL",
		all_items: "ALL_ITEMS",
	});

	/**
	 * Get anti-csrftoken-a2z from vvp-context (Environment reads it from the page's script[data-a-state]).
	 * @returns {string|null}
	 */
	#getCsrfToken() {
		const token = this.#env?.getCsrfToken?.();
		if (token) {
			return token;
		}
		throw new Error("VHelper could not find the CSRF token. Refresh a Vine page and try again.");
	}

	/**
	 * Inform VHelper API that an item is no longer available (record_unavailable).
	 * Used when the first fetch returns ITEM_NOT_IN_ENROLLMENT.
	 * @param {string} asin - Item ASIN
	 * @param {string} reason - e.g. "ITEM_NOT_IN_ENROLLMENT"
	 */
	async #reportUnavailableToApi(asin, reason) {
		await this.#unavailableReporter?.report(asin, reason);
	}

	/**
	 * Report order status/error to VHelper API (record_order), e.g. for ITEM_NOT_IN_ENROLLMENT.
	 * @param {string} asin - Item ASIN
	 * @param {string|null} parentAsin - Parent ASIN (or null)
	 * @param {string} orderStatus - e.g. "failed"
	 * @param {string} orderError - e.g. "ITEM_NOT_IN_ENROLLMENT"
	 */
	async #reportOrderErrorToApi(asin, parentAsin, orderStatus, orderError) {
		if (!this.#env?.getAPIUrl) return;
		try {
			const content = {
				api_version: 5,
				app_version: this.#env.data?.appVersion ?? "",
				action: "record_order",
				country: i18n.getCountryCode(),
				uuid: await Settings.get("general.uuid", false),
				cid: await this.#env.getCID(),
				fid: await Settings.get("general.fingerprint.id", false),
				asin: asin,
				parent_asin: parentAsin,
				order_status: orderStatus,
				order_error: orderError,
			};
			content.s = await cryptoKeys.signData(content);
			content.pk = await cryptoKeys.getExportedPublicKey();
			await fetch(this.#env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
		} catch (e) {
			console.warn("[BuyNow] Failed to report order error to API:", e);
		}
	}

	/**
	 * Bind "Buy Now" button behavior to a container (delegated click).
	 * First click: label "Sure?" for 2s then revert. Double-click within 2s: call startBuyNow.
	 * @param {HTMLElement} container - Grid or list container that holds .vh-buy-now-btn
	 * @param {import("/scripts/core/services/Environment.js").Environment} env
	 * @param {import("/scripts/core/services/Internationalization.js").Internationalization} i18n
	 */
	static bindBuyNowButtons(container, env, i18n) {
		if (!container || container.dataset.vhBuynowBound === "1") return;
		container.dataset.vhBuynowBound = "1";

		const CONFIRM_MS = 2000;

		container.addEventListener("click", async (e) => {
			const btn = e.target?.closest?.(".vh-buy-now-btn");
			if (!btn) return;

			e.preventDefault();
			e.stopPropagation();

			const asin = btn.dataset.asin;
			const queue = btn.dataset.queue ?? "";
			const isParentAsin = btn.dataset.isParentAsin ?? "false";
			const recommendationId = btn.dataset.recommendationId;
			if (!asin || !recommendationId) return;

			const labelBuyNow = getMessage("btnOrderNow", "Order Now");
			const labelSure = getMessage("btnOrderNowConfirm", "Confirm?");
			const textEl = btn.querySelector(".vh-buy-now-btn-text") || btn;
			const currentText = (textEl.textContent || "").trim();

			if (currentText === labelSure) {
				clearTimeout(btn._vhBuyNowTimeout);
				btn._vhBuyNowTimeout = null;
				const progress = createOrderNowButtonProgress(btn);
				const ok = await BuyNow.startBuyNow(
					asin,
					queue,
					isParentAsin,
					recommendationId,
					env,
					i18n,
					progress.onProgress
				);
				if (!ok) {
					progress.setError();
				}
				return;
			} else {
				textEl.textContent = labelSure;
				clearTimeout(btn._vhBuyNowTimeout);
				btn._vhBuyNowTimeout = setTimeout(() => {
					btn._vhBuyNowTimeout = null;
					if (textEl.textContent === labelSure) textEl.textContent = labelBuyNow;
				}, CONFIRM_MS);
			}
		});
	}

	/**
	 * Start the Buy Now flow for an item.
	 * @param {string} asin - Item ASIN
	 * @param {string} queue - data-queue value
	 * @param {boolean|string} isParentAsin - data-is-parent-asin
	 * @param {string} recommendationId - data-recommendation-id (full string)
	 * @param {import("/scripts/core/services/Environment.js").Environment} env
	 * @param {import("/scripts/core/services/Internationalization.js").Internationalization} i18n
	 * @param {(event: OrderNowProgressEvent) => void} [onProgress]
	 */
	static async startBuyNow(asin, queue, isParentAsin, recommendationId, env, i18n, onProgress) {
		const instance = new BuyNow();
		instance.#env = env;
		instance.#baseUrl = `https://www.amazon.${i18n.getDomainTLD()}`;
		instance.#parentAsin = asin;
		instance.#unavailableReporter = new UnavailableAsinReporter({ env, i18n, settings: Settings, cryptoKeys });
		const referrer = `${instance.#baseUrl}/vine/vine-items${queue ? `?queue=${queue}` : ""}`;

		const isParent =
			isParentAsin === true || isParentAsin === "true" || String(isParentAsin).toLowerCase() === "true";
		const totalSteps = (isParent ? 1 : 0) + 3;
		let stepIndex = 0;
		const report = (step) => {
			stepIndex += 1;
			try {
				onProgress?.({ step, index: stepIndex, total: totalSteps });
			} catch (_) {
				// ignore UI callback failures
			}
		};

		let _asin = asin;
		let _recommendationId = recommendationId;
		if (isParent) {
			report("variants");
			const firstVariant = await instance.#fetchChildrenData(recommendationId, referrer);
			if (firstVariant?.asin) {
				_asin = firstVariant.asin;
				_recommendationId = firstVariant.recommendationId;
			} else {
				throw new Error("No variant found.");
			}
		}
		let seeDetailsResult = null;
		let voiceResult = null;
		try {
			if (Settings.isPremiumUser(3) && Settings.get("general.orderNow.parallelCheckout")) {
				report("see-details");
				report("voiceOrders");
				[seeDetailsResult, voiceResult] = await Promise.all([
					instance.#fetchSeeDetailsData(_asin, _recommendationId, referrer),
					instance.#fetchVoiceOrder(_asin, _recommendationId, queue),
				]);
			} else {
				report("see-details");
				seeDetailsResult = await instance.#fetchSeeDetailsData(_asin, _recommendationId, referrer);
				report("voiceOrders");
				voiceResult = await instance.#fetchVoiceOrder(_asin, _recommendationId, queue);
			}
		} catch (err) {
			if (err instanceof OrderNowFailureError) {
				console.warn("[BuyNow] Order Now aborted:", err.debugReport);
				await showOrderNowFailureModal(err.debugReport);
				return false;
			}
			if (err instanceof ToasterError) {
				const notification = new ScreenNotification();
				notification.title = `Unable to Order Now`;
				notification.lifespan = 30;
				notification.content = err.details;
				Notifications.pushNotification(notification);
				return false;
			}
			const notification = new ScreenNotification();
			notification.title = `Unexpected error occured`;
			notification.lifespan = 30;
			notification.content = err.message;
			Notifications.pushNotification(notification);
			return false;
		}

		report("checkout");
		instance.#submitCheckoutForm(
			_asin,
			voiceResult.offerListingId,
			seeDetailsResult.promotionId,
			seeDetailsResult.purchasePolicyCode
		);
		return true;
	}

	/**
	 * Fetch children (variants) for a parent ASIN. Returns first variant's asin and recommendationId.
	 * @param {string} recommendationId - Parent recommendation ID (encoded in URL)
	 * @param {string} referrer
	 * @returns {Promise<{ asin: string, recommendationId: string }|null>}
	 */
	async #fetchChildrenData(recommendationId, referrer) {
		const encoded = encodeURIComponent(recommendationId);
		const url = `${this.#baseUrl}/vine/api/recommendations/${encoded}`;
		const opts = this.#getFetchOptions(referrer);

		const res = await fetch(url, opts);
		if (!res.ok) {
			console.warn("[BuyNow] fetchChildrenData failed:", res.status, res.statusText);
			return null;
		}
		const data = await res.json();
		if (data?.result == null && data?.error?.exceptionType === "ITEM_NOT_IN_ENROLLMENT") {
			const asinFromRecId = recommendationId.split("#")[1] || this.#parentAsin;
			if (asinFromRecId) {
				await this.#reportUnavailableToApi(asinFromRecId, "ITEM_NOT_IN_ENROLLMENT");
			}
			const notification = new ScreenNotification();
			notification.title = `Unable to Order Now`;
			notification.lifespan = 30;
			notification.content = `Vine returned error: ${data?.error?.exceptionType}`;
			Notifications.pushNotification(notification);
			throw new Error("ITEM_NOT_IN_ENROLLMENT");
		}
		// API can return result.variations (array of { asin, dimensions }) or recommendation.children / children
		const variations = data?.result?.variations ?? data?.recommendation?.children ?? data?.children ?? [];
		const first = Array.isArray(variations) ? variations[0] : null;
		if (!first?.asin) return null;
		// Use the recommendationId returned by the API (result.recommendationId); pass variant asin for item fetch
		const recId = data?.result?.recommendationId ?? recommendationId;
		return { asin: first.asin, recommendationId: recId };
	}

	/**
	 * Fetch see-details (item) data for an ASIN.
	 * @param {string} asin - Item ASIN
	 * @param {string} recommendationId - Full recommendation ID for this item
	 * @param {string} referrer
	 * @param {string} [queue] - Queue name (for voice order: potluck, encore, last_chance, all_items)
	 */
	async #fetchSeeDetailsData(asin, recommendationId, referrer) {
		const encoded = encodeURIComponent(recommendationId);
		const url = `${this.#baseUrl}/vine/api/recommendations/${encoded}/item/${asin}?imageSize=180`;
		const opts = this.#getFetchOptions(referrer);

		const res = await fetch(url, opts);
		if (!res.ok) {
			console.warn("[BuyNow] fetchSeeDetailsData failed:", res.status, res.statusText);
			throw new ToasterError("Unable to Order Now", `Vine returned error: ${res.statusText}`);
		}
		const data = await res.json();
		if (data?.result == null && data?.error?.exceptionType === "ITEM_NOT_IN_ENROLLMENT") {
			await this.#reportUnavailableToApi(asin, "ITEM_NOT_IN_ENROLLMENT");
			throw new ToasterError(
				getMessage("buyNowUnableToOrderTitle", "Unable to Order Now"),
				getMessage("buyNowVineReturnedError", "Vine returned error: $1$", [String(data?.error?.exceptionType)])
			);
		}
		try {
			BuyNow.validateSeeDetailsResponse(data);
		} catch (err) {
			if (err instanceof ValidationError) {
				console.warn("[BuyNow] fetchSeeDetailsData validation failed:", err.toDisplayMessage());
				throw OrderNowFailureError.fromValidation({
					step: "see-details",
					request: { method: "GET", url, referrer },
					validationError: err,
					expectation: SEE_DETAILS_EXPECTATION,
					received: data,
				});
			}
			throw err;
		}

		return data.result;
	}

	/**
	 * Validate see-details response against SEE_DETAILS_EXPECTATION.
	 * @param {unknown} data - Parsed JSON response
	 * @param {Record<string, unknown>} expectation - Expectation template (default SEE_DETAILS_EXPECTATION)
	 * @returns {{ result: Record<string, unknown> } }
	 * @throws {ValidationError} With path, message, expected, actual for UI display
	 */
	static validateSeeDetailsResponse(data, expectation = SEE_DETAILS_EXPECTATION) {
		validate(data, expectation, "");
		const obj = /** @type {{ result: Record<string, unknown> } } */ (data);
		return { result: obj.result };
	}

	/**
	 * POST to /vine/api/voiceOrders with recommendationId, recommendationType, itemAsin.
	 * Uses validated see-details result (asin) and the same recommendationId + queue-derived recommendationType.
	 * @param {Record<string, unknown>} result - Validated result from fetchSeeDetailsData (must have asin)
	 * @param {string} recommendationId - Full recommendation ID
	 * @param {string} queue - Queue name (potluck, encore, last_chance, all_items)
	 */
	async #fetchVoiceOrder(asin, recommendationId, queue = "", csrfRetried = false) {
		const recommendationType = BuyNow.#QUEUE_TO_RECOMMENDATION_TYPE[queue] || "VINE_FOR_ALL";
		const url = `${this.#baseUrl}/vine/api/voiceOrders`;
		const body = JSON.stringify({
			recommendationId,
			recommendationType,
			itemAsin: asin,
		});

		const csrf = this.#getCsrfToken();

		const headers = {
			accept: "*/*",
			"accept-language": getBrowserAcceptLanguage(),
			"cache-control": "max-age=0",
			"content-type": "application/json",
			"sec-fetch-dest": "empty",
			"sec-fetch-mode": "cors",
			"sec-fetch-site": "same-origin",
			"anti-csrftoken-a2z": csrf,
		};

		const res = await fetch(url, {
			method: "POST",
			mode: "cors",
			credentials: "include",
			headers,
			body,
			referrer: `${this.#baseUrl}/vine/no-referrer`,
		});
		if (res.status === 403) {
			if (!csrfRetried) {
				const domainTLD = this.#baseUrl.replace(/^https:\/\/www\.amazon\./, "");
				await refreshCsrfTokenFromVinePage(this.#env, domainTLD, queue || "encore");
				return this.#fetchVoiceOrder(asin, recommendationId, queue, true);
			}
			throw new ToasterError(
				"Unable to Order Now",
				"VHelper received a 403 error from the server, the CSRF token likely changed, please reload a vine page and the monitor."
			);
		}
		const text = await res.text();
		const voiceOrderUrl = url;
		const voiceOrderBody = {
			recommendationId,
			recommendationType,
			itemAsin: asin,
		};
		let data;
		try {
			data = JSON.parse(text);
		} catch (_) {
			console.warn("[BuyNow] fetchVoiceOrder: response is not JSON", text);
			throw OrderNowFailureError.fromInvalidJson({
				step: "voiceOrders",
				request: {
					method: "POST",
					url: voiceOrderUrl,
					referrer: `${this.#baseUrl}/vine/no-referrer`,
					body: voiceOrderBody,
				},
				rawResponseText: text,
			});
		}

		try {
			BuyNow.validateVoiceOrderResponse(data);
			await Settings.set("checkout.currentASIN", asin);
			await Settings.set("checkout.currentParentASIN", this.#parentAsin);
			await Settings.set("checkout.currentBuyNowASIN", asin);
		} catch (err) {
			if (data && data.error) {
				if (data.error === "ITEM_NOT_IN_ENROLLMENT") {
					await this.#reportOrderErrorToApi(asin, this.#parentAsin, "failed", data.error);
				}

				throw new ToasterError(
					getMessage("buyNowUnableToOrderTitle", "Unable to Order Now"),
					getMessage("buyNowVineReturnedError", "Vine returned error: $1$", [String(data.error)])
				);
			}
			if (err instanceof ValidationError) {
				console.warn("[BuyNow] fetchVoiceOrder validation failed:", err.toDisplayMessage());
				throw OrderNowFailureError.fromValidation({
					step: "voiceOrders",
					request: {
						method: "POST",
						url: voiceOrderUrl,
						referrer: `${this.#baseUrl}/vine/no-referrer`,
						body: voiceOrderBody,
					},
					validationError: err,
					expectation: VOICE_ORDER_EXPECTATION,
					received: data,
				});
			}
			throw err;
		}

		return data.result;
	}

	/**
	 * Validate voice order response against VOICE_ORDER_EXPECTATION.
	 * @param {unknown} data - Parsed voiceOrders API response
	 * @returns {{ result: Record<string, unknown> }}
	 * @throws {ValidationError}
	 */
	static validateVoiceOrderResponse(data, expectation = VOICE_ORDER_EXPECTATION) {
		validate(data, expectation, "");
		const obj = /** @type {{ result: Record<string, unknown> } } */ (data);
		return { result: obj.result };
	}

	/**
	 * Build checkout form from validated voice order result and see-details result, submit in new tab, then remove form.
	 * @param {Record<string, unknown>} voiceResult - Validated voice order result (offerListingId, itemAsin, etc.)
	 * @param {Record<string, unknown>} seeDetailsResult - See-details result (asin, promotionId, purchasePolicyCode)
	 */
	#submitCheckoutForm(asin, offerListingId, promotionId, purchasePolicyCode) {
		const checkoutUrl = `${this.#baseUrl}/checkout/entry/buynow?pipelineType=Chewbacca`;
		const fields = [
			["skipCart", "1"],
			["quantity", "1"],
			["asin", String(asin || "")],
			["offerListingID", String(offerListingId || "")],
			["vinePromotionId", String(promotionId || "")],
			["vinePurchasePolicyCode", String(purchasePolicyCode || "")],
		];
		if (this.#isIOSMode()) {
			this.#openPostInNewTab(checkoutUrl, fields);
			return;
		}

		const form = document.createElement("form");
		form.id = "vvp-checkout-buy-now";
		form.method = "post";
		form.target = "_blank";
		form.action = checkoutUrl;
		for (const [name, value] of fields) {
			const input = document.createElement("input");
			input.type = "hidden";
			input.name = name;
			input.value = String(value ?? "");
			form.appendChild(input);
		}

		document.body.appendChild(form);
		form.submit();
		form.remove();
	}
}
