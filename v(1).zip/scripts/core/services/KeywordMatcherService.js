/**
 * @fileoverview KeywordMatcherService - Centralized keyword matching service with lazy compilation
 *
 * This service provides a simple, unified interface for keyword matching that:
 * - Uses keyword groups for all keyword matching
 * - Lazy loads compilation (only compiles when needed)
 * - Provides simple methods for highlight, hide, and blur matching
 * - Respects group order for highlight/hide groups
 */

import { compileKeywordObjects } from "../utils/KeywordCompiler.js";
import { findMatch, hasEtvConditions } from "../utils/KeywordMatcher.js";
import { getGroups } from "../utils/KeywordGroupsManager.js";

/**
 * Centralized keyword matching service with lazy compilation
 */
class KeywordMatcherService {
	#settingsManager = null;
	#isPremiumTier2 = false;

	// Lazy-loaded compiled keywords (only compiled when first accessed)
	#compiledBlurKeywords = null;
	#orderedHighlightHideGroups = null;
	#orderedBlurGroups = null; // Store blur groups separately for independent processing

	// Cache flags to track if we've loaded groups
	#groupsLoaded = false;
	#useKeywordGroups = false;

	constructor(settingsManager, isPremiumTier2 = false) {
		this.#settingsManager = settingsManager;
		this.#isPremiumTier2 = isPremiumTier2;
		if (typeof settingsManager?.addSettingsChangeObserver === "function") {
			settingsManager.addSettingsChangeObserver(() => {
				this.invalidateCache(); //Clear the keywords
				this.initialize(); //Reload them
			});
		}
	}

	/**
	 * Lazy loads groups (only called when needed)
	 * @private
	 */
	async #ensureGroupsLoaded() {
		if (this.#groupsLoaded) {
			return;
		}

		await this.#settingsManager.waitForLoad();

		// Check if keyword groups are being used
		const keywordGroups = this.#settingsManager.get("general.keywordGroups") || [];
		this.#useKeywordGroups = Array.isArray(keywordGroups) && keywordGroups.length > 0;

		if (this.#useKeywordGroups) {
			// Load groups (but don't compile yet - lazy compile)
			const allGroups = await getGroups(this.#settingsManager);
			this.#orderedHighlightHideGroups = allGroups
				.filter((group) => (group.type === "highlight" || group.type === "hide") && group.enabled !== false)
				.sort((a, b) => a.order - b.order);

			// For blur keywords, store groups separately and compile them now since they're separate
			this.#orderedBlurGroups = allGroups
				.filter((group) => group.type === "blur" && this.#isPremiumTier2 && group.enabled !== false)
				.sort((a, b) => a.order - b.order);

			const allBlurKeywords = [];
			this.#orderedBlurGroups.forEach((group) => {
				if (group.keywords && Array.isArray(group.keywords)) {
					const formattedKeywords = group.keywords.map((kw) => {
						if (typeof kw === "string") {
							return { contains: kw };
						}
						return kw;
					});
					allBlurKeywords.push(...formattedKeywords);
				}
			});
			this.#compiledBlurKeywords = allBlurKeywords.length > 0 ? compileKeywordObjects(allBlurKeywords) : null;
		}

		this.#groupsLoaded = true;
	}

	/**
	 * Synchronous version - requires groups to be pre-loaded
	 * @private
	 */
	#findHighlightHideMatchSync(text, itemEtvMin = null, itemEtvMax = null) {
		if (!text) {
			return null;
		}

		if (this.#useKeywordGroups && this.#orderedHighlightHideGroups && this.#orderedHighlightHideGroups.length > 0) {
			// Process groups in order, stopping at first match
			for (const group of this.#orderedHighlightHideGroups) {
				// Skip disabled groups (should already be filtered, but double-check for safety)
				if (group.enabled === false) {
					continue;
				}

				if (!group.keywords || !Array.isArray(group.keywords) || group.keywords.length === 0) {
					continue;
				}

				// Lazy compile keywords for this group
				const compiledKeywords = compileKeywordObjects(group.keywords);

				// Find match in this group
				const match = findMatch(text, compiledKeywords, itemEtvMin, itemEtvMax);
				if (match) {
					return {
						...match,
						type: group.type, // 'highlight' or 'hide'
						groupId: group.id,
						groupName: group.name,
					};
				}
			}
		}

		return null;
	}

	/**
	 * Returns true if any enabled highlight group has keywords with ETV conditions (etv_min/etv_max).
	 * Used to decide whether to re-evaluate highlight when ETV values change.
	 * Synchronous - requires groups to be pre-loaded via initialize().
	 * @returns {boolean}
	 */
	hasHighlightGroupsWithEtvConditionsSync() {
		if (!this.#useKeywordGroups || !this.#orderedHighlightHideGroups) {
			return false;
		}
		const highlightGroups = this.#orderedHighlightHideGroups.filter((g) => g.type === "highlight");
		for (const group of highlightGroups) {
			if (
				group.enabled === false ||
				!group.keywords ||
				!Array.isArray(group.keywords) ||
				group.keywords.length === 0
			) {
				continue;
			}
			const compiled = compileKeywordObjects(group.keywords);
			if (hasEtvConditions(compiled)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Pre-loads groups (call this before using sync methods)
	 * @returns {Promise<void>}
	 */
	async initialize() {
		await this.#ensureGroupsLoaded();
	}

	/**
	 * Finds a match in highlight/hide groups, processing them together in order
	 * Stops at first match (whether highlight or hide)
	 * Async version - loads groups if needed
	 * @param {string} text - The text to match against
	 * @param {number|null} itemEtvMin - Item's minimum ETV
	 * @param {number|null} itemEtvMax - Item's maximum ETV
	 * @returns {Promise<Object|null>} The first matching keyword object with type ('highlight' or 'hide') or null
	 */
	async findHighlightHideMatch(text, itemEtvMin = null, itemEtvMax = null) {
		await this.#ensureGroupsLoaded();
		return this.#findHighlightHideMatchSync(text, itemEtvMin, itemEtvMax);
	}

	/**
	 * Synchronous version - requires groups to be pre-loaded via initialize()
	 * @param {string} text - The text to match against
	 * @param {number|null} itemEtvMin - Item's minimum ETV
	 * @param {number|null} itemEtvMax - Item's maximum ETV
	 * @returns {Object|null} The first matching keyword object with type ('highlight' or 'hide') or null
	 */
	findHighlightHideMatchSync(text, itemEtvMin = null, itemEtvMax = null) {
		return this.#findHighlightHideMatchSync(text, itemEtvMin, itemEtvMax);
	}

	/**
	 * Finds a blur keyword match
	 * Async version - loads groups if needed
	 * @param {string} text - The text to match against
	 * @returns {Promise<Object|null>} The matching keyword object or null
	 */
	async findBlurMatch(text) {
		if (!text) {
			return null;
		}

		await this.#ensureGroupsLoaded();

		if (this.#compiledBlurKeywords) {
			return findMatch(text, this.#compiledBlurKeywords);
		}

		return null;
	}

	/**
	 * Synchronous version - requires groups to be pre-loaded via initialize()
	 * Blur keywords are checked independently of highlight/hide status
	 * @param {string} text - The text to match against
	 * @param {number|null} itemEtvMin - Item's minimum ETV
	 * @param {number|null} itemEtvMax - Item's maximum ETV
	 * @returns {Object|null} The matching keyword object or null
	 */
	findBlurMatchSync(text, itemEtvMin = null, itemEtvMax = null) {
		// Re-check premium tier 2 status dynamically in case it changed or wasn't set correctly
		let isPremiumTier2 = this.#isPremiumTier2;
		if (this.#settingsManager && typeof this.#settingsManager.isPremiumUser === "function") {
			const currentPremiumStatus = this.#settingsManager.isPremiumUser(2);
			if (currentPremiumStatus !== isPremiumTier2) {
				isPremiumTier2 = currentPremiumStatus;
				// Update cached value
				this.#isPremiumTier2 = currentPremiumStatus;
			}
		}

		if (!text || !isPremiumTier2) {
			return null;
		}

		// Check if keyword groups are being used
		const keywordGroups = this.#settingsManager.get("general.keywordGroups") || [];
		const useKeywordGroups = Array.isArray(keywordGroups) && keywordGroups.length > 0;

		if (useKeywordGroups && this.#orderedBlurGroups && this.#orderedBlurGroups.length > 0) {
			// Process blur groups in order (though order doesn't matter for blur matching)
			for (const group of this.#orderedBlurGroups) {
				// Skip disabled groups (should already be filtered, but double-check for safety)
				if (group.enabled === false) {
					continue;
				}

				if (!group.keywords || !Array.isArray(group.keywords) || group.keywords.length === 0) {
					continue;
				}

				// Lazy compile keywords for this group
				const compiledKeywords = compileKeywordObjects(group.keywords);

				// Find match in this group
				const match = findMatch(text, compiledKeywords, itemEtvMin, itemEtvMax);
				if (match) {
					return {
						...match,
						type: group.type,
						groupId: group.id,
						groupName: group.name,
					};
				}
			}
			return null;
		} else if (this.#compiledBlurKeywords) {
			return findMatch(text, this.#compiledBlurKeywords, itemEtvMin, itemEtvMax);
		}

		return null;
	}

	/**
	 * Clears the cached keywords (useful when settings change)
	 */
	invalidateCache() {
		// Keep the last-loaded groups active until reload finishes so sync matching
		// does not briefly return null during settings updates.
		this.#groupsLoaded = false;
		void this.#ensureGroupsLoaded();
	}
}

export { KeywordMatcherService };
