/**
 * Settings Manager - Direct implementation without DI
 *
 * This is a singleton wrapper around SettingsMgrDI that creates
 * its own storage adapter directly.
 */

import { SettingsMgrDI } from "./SettingsMgrDI.js";
import { ChromeStorageAdapter, ServiceWorkerStorageAdapter } from "../../infrastructure/StorageAdapter.js";
import { isSafari } from "../utils/BrowserDetection.js";
import { Logger } from "../utils/Logger.js";

// Create a singleton-like class that creates its own storage adapter
class SettingsMgr {
	static #instance = null;
	#diInstance = null;

	constructor() {
		if (SettingsMgr.#instance) {
			return SettingsMgr.#instance;
		}

		SettingsMgr.#instance = this;

		// Create storage adapter directly
		const logger = new Logger();
		let storageAdapter;

		// Safari doesn't support service workers, so use localStorage instead
		if (isSafari()) {
			logger.add("Using ServiceWorkerStorageAdapter");
			storageAdapter = new ServiceWorkerStorageAdapter();
		} else {
			logger.add("Using ChromeStorageAdapter(local)");
			storageAdapter = new ChromeStorageAdapter("local");
		}

		// Create SettingsMgrDI instance directly
		this.#diInstance = new SettingsMgrDI(storageAdapter, logger);
	}

	// Delegate all methods to the DI instance
	isPremiumUser(tier = 2) {
		return this.#diInstance.isPremiumUser(tier);
	}

	async waitForLoad() {
		return this.#diInstance.waitForLoad();
	}

	isLoaded() {
		return this.#diInstance.isLoaded();
	}

	async refresh() {
		return await this.#diInstance.refresh();
	}

	addSettingsChangeObserver(observer) {
		return this.#diInstance.addSettingsChangeObserver(observer);
	}

	removeSettingsChangeObserver(observer) {
		this.#diInstance.removeSettingsChangeObserver(observer);
	}

	dispose() {
		this.#diInstance.dispose();
	}

	get(settingPath, undefinedReturnDefault = true) {
		return this.#diInstance.get(settingPath, undefinedReturnDefault);
	}

	getDefault(settingPath) {
		return this.#diInstance.getDefault(settingPath);
	}

	getSettingsTree() {
		return this.#diInstance.getSettingsTree();
	}

	async set(settingPath, value, reloadSettings = true) {
		return await this.#diInstance.set(settingPath, value, reloadSettings);
	}
}

export { SettingsMgr };
