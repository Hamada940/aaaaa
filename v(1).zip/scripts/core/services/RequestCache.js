class RequestCache {
	#values = new Map();
	#inFlight = new Map();

	/**
	 * Resolve cached value, dedupe in-flight calls, and cache successful results.
	 * Rejected requests are not cached.
	 * @template T
	 * @param {string} key
	 * @param {() => Promise<T>} loader
	 * @returns {Promise<T>}
	 */
	async getOrSet(key, loader) {
		if (this.#values.has(key)) {
			return this.#values.get(key);
		}
		if (this.#inFlight.has(key)) {
			return this.#inFlight.get(key);
		}

		const promise = (async () => {
			try {
				const value = await loader();
				this.#values.set(key, value);
				return value;
			} finally {
				this.#inFlight.delete(key);
			}
		})();

		this.#inFlight.set(key, promise);
		return promise;
	}

	clear(key = null) {
		if (key == null) {
			this.#values.clear();
			this.#inFlight.clear();
			return;
		}
		this.#values.delete(key);
		this.#inFlight.delete(key);
	}
}

export { RequestCache };
