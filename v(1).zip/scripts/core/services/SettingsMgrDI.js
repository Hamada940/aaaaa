/**
 * Settings Manager with Dependency Injection
 *
 * This is a refactored version of SettingsMgr that:
 * - Uses dependency injection instead of singleton pattern
 * - Accepts a storage adapter for testability
 * - Maintains backward compatibility with existing API
 * - Can be gradually adopted throughout the codebase
 */

// Use relative import for better testability
/* global chrome */
import { Logger } from "../utils/Logger.js";

export class SettingsMgrDI {
	#storageAdapter;
	#logger;
	#defaultSettings;
	#settings;
	#isLoaded = false;
	#loadPromise;
	/** Non-zero while this tab is writing `settings` to chrome.storage.local (onChanged also fires here; skip redundant refresh). */
	#pendingOwnSettingsWrite = 0;
	#chromeStorageOnChangedListener = null;
	#settingsChangeObservers = new Set();
	#autoDisposeHandler = null;

	constructor(storageAdapter, logger = new Logger()) {
		this.#storageAdapter = storageAdapter;
		this.#logger = logger;
		this.#settings = {};
		this.#getDefaultSettings();

		// Initialize settings on construction
		this.#loadPromise = this.#initializeSettings();
		this.#registerExternalSettingsSyncListeners();
		this.#registerAutoDispose();
	}

	/**
	 * Register a callback invoked when `chrome.storage.local` `settings` changes in another extension context.
	 * Runs after in-memory settings are reloaded from storage (not when `refresh()` is called from code).
	 * @param {(payload?: { changedPaths?: string[] }) => void | Promise<void>} observer
	 * @returns {() => void} Unsubscribe function
	 */
	addSettingsChangeObserver(observer) {
		if (typeof observer !== "function") {
			return () => {};
		}
		this.#settingsChangeObservers.add(observer);
		return () => {
			this.#settingsChangeObservers.delete(observer);
		};
	}

	removeSettingsChangeObserver(observer) {
		this.#settingsChangeObservers.delete(observer);
	}

	/**
	 * Releases listeners/observers held by this instance.
	 * Useful for long-lived pages that can be torn down/reloaded.
	 */
	dispose() {
		if (typeof chrome !== "undefined" && chrome.storage?.onChanged && this.#chromeStorageOnChangedListener) {
			chrome.storage.onChanged.removeListener(this.#chromeStorageOnChangedListener);
		}
		if (typeof window !== "undefined" && this.#autoDisposeHandler) {
			window.removeEventListener("pagehide", this.#autoDisposeHandler);
		}
		this.#autoDisposeHandler = null;
		this.#chromeStorageOnChangedListener = null;
		this.#settingsChangeObservers.clear();
	}

	/**
	 * Notify all settings change observers that the settings have changed.
	 */
	#notifySettingsChangeObservers(payload = undefined) {
		for (const observer of this.#settingsChangeObservers) {
			try {
				const result = observer(payload);
				if (result && typeof result.then === "function") {
					void result.catch((err) => {
						this.#logger.add(`SettingsMgr: settings observer rejected: ${err?.message ?? err}`);
					});
				}
			} catch (err) {
				this.#logger.add(`SettingsMgr: settings observer error: ${err?.message ?? err}`);
			}
		}
	}

	async #handleExternalSettingsUpdated(payload = undefined) {
		if (this.#pendingOwnSettingsWrite > 0) {
			return;
		}
		try {
			await this.refresh();
			this.#notifySettingsChangeObservers(payload);
		} catch (err) {
			this.#logger.add(`SettingsMgr: refresh after external settings change failed: ${err.message}`);
		}
	}

	/** Listens for `settings` changes in `chrome.storage.local` from other extension contexts (tabs, workers, etc.). */
	#registerExternalSettingsSyncListeners() {
		if (this.#chromeStorageOnChangedListener) {
			return;
		}
		if (typeof chrome !== "undefined" && chrome.storage?.onChanged) {
			this.#chromeStorageOnChangedListener = (changes, areaName) => {
				if (areaName !== "local" || !changes.settings) {
					return;
				}
				const changedPaths = this.#getChangedPaths(changes.settings.oldValue, changes.settings.newValue);
				// `chrome.storage.onChanged` can fire in the writing tab too. Skip
				// immediately while a local write is in flight to avoid self-refresh churn.
				if (this.#pendingOwnSettingsWrite > 0) {
					return;
				}
				void this.#loadPromise.then(() => {
					void this.#handleExternalSettingsUpdated({ changedPaths });
				});
			};
			chrome.storage.onChanged.addListener(this.#chromeStorageOnChangedListener);
		}
	}

	#registerAutoDispose() {
		if (this.#autoDisposeHandler) {
			return;
		}
		if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
			this.#autoDisposeHandler = () => {
				this.dispose();
			};
			window.addEventListener("pagehide", this.#autoDisposeHandler, { once: true });
		}
	}

	#getChangedPaths(oldSettings, newSettings) {
		// chrome.storage.onChanged often omits oldValue for large blobs — do not treat every key as changed.
		if (oldSettings == null) {
			return [];
		}
		const changedPaths = [];
		this.#collectChangedPaths(oldSettings, newSettings, "", changedPaths);
		return changedPaths;
	}

	#collectChangedPaths(oldValue, newValue, basePath, output) {
		if (oldValue === newValue) {
			return;
		}

		const oldIsObject = oldValue && typeof oldValue === "object" && !Array.isArray(oldValue);
		const newIsObject = newValue && typeof newValue === "object" && !Array.isArray(newValue);

		// Removed value or primitive/array replacement.
		if (!newIsObject) {
			if (basePath) {
				output.push(basePath);
			}
			return;
		}

		// New nested object; skip root — handled by #getChangedPaths when oldSettings is null.
		if (!oldIsObject) {
			if (!basePath) {
				return;
			}
			for (const key of Object.keys(newValue)) {
				const nextPath = `${basePath}.${key}`;
				this.#collectChangedPaths(undefined, newValue[key], nextPath, output);
			}
			return;
		}

		const keys = new Set([...Object.keys(oldValue), ...Object.keys(newValue)]);
		for (const key of keys) {
			const nextPath = basePath ? `${basePath}.${key}` : key;
			this.#collectChangedPaths(oldValue[key], newValue[key], nextPath, output);
		}
	}

	async #initializeSettings() {
		try {
			await this.#loadSettingsFromStorage();
			this.#isLoaded = true;
			this.#logger.add("SettingsMgr: Settings loaded.");
			return true;
		} catch (error) {
			this.#logger.add(`SettingsMgr: Failed to load settings: ${error.message}`);
			throw error;
		}
	}

	// Return true if the user has a valid premium membership on Patreon
	isPremiumUser(tier = 2) {
		return parseInt(this.get("general.patreon.tier")) >= tier;
	}

	async waitForLoad() {
		// Resolve immediately if settings are already in memory (avoids deadlock when migrate calls waitForLoad)
		if (this.#isLoaded) {
			return Promise.resolve();
		}
		return this.#loadPromise;
	}

	isLoaded() {
		return this.#isLoaded;
	}

	async refresh() {
		await this.#loadSettingsFromStorage(true);
	}

	get(settingPath, undefinedReturnDefault = true) {
		let answer = this.#getFromObject(this.#settings, settingPath);

		// If the value is not found in the settings, check if we should return the default value
		if (answer == undefined && undefinedReturnDefault) {
			answer = this.#getFromObject(this.#defaultSettings, settingPath);
		}

		return answer;
	}

	getDefault(settingPath) {
		return this.#getFromObject(this.#defaultSettings, settingPath);
	}

	getSettingsTree() {
		return structuredClone(this.#settings);
	}

	#getFromObject(obj, settingPath) {
		const pathArray = settingPath.split(".");
		return pathArray.reduce((prev, curr) => prev && prev[curr], obj);
	}

	/** Returns true if version a is inferior or equal to version b (e.g. "3.9.10" <= "3.9.11"). */
	#isVersionLte(a, b) {
		const pa = a.split(".").map((n) => parseInt(n, 10) || 0);
		const pb = b.split(".").map((n) => parseInt(n, 10) || 0);
		for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
			const na = pa[i] || 0;
			const nb = pb[i] || 0;
			if (na < nb) return true;
			if (na > nb) return false;
		}
		return true;
	}

	async set(settingPath, value) {
		await this.waitForLoad();
		// Merge with latest storage so a stale in-memory copy cannot overwrite changes from another tab.
		await this.refresh();

		// Don't go through the hassle of updating the value if it did not change
		if (this.get(settingPath, false) === value) {
			return false;
		}

		const pathArray = settingPath.split(".");
		const lastKey = pathArray.pop();

		// Traverse the object and create missing intermediate objects if needed
		let current = this.#settings;
		for (let key of pathArray) {
			if (!current[key]) {
				current[key] = {};
			}
			current = current[key];
		}

		// Set the final value
		current[lastKey] = value;

		//console.log(`[${performance.now().toFixed(3)}] SettingsMgr: Setting ${settingPath} to ${value}`);
		await this.#save();

		return true;
	}

	async #save() {
		try {
			this.#pendingOwnSettingsWrite++;
			try {
				await this.#storageAdapter.set("settings", this.#settings);
			} finally {
				this.#pendingOwnSettingsWrite--;
			}
			//console.log(`[${performance.now().toFixed(3)}] SettingsMgr: Settings saved to storage`);
		} catch (e) {
			// Enhanced error handling for Safari and other browsers
			const isQuotaError =
				e.name === "QuotaExceededError" ||
				(e.message &&
					(e.message.includes("Exceeded storage quota") ||
						e.message.includes("QUOTA_BYTES quota exceeded") ||
						e.message.includes("quota exceeded")));

			if (isQuotaError) {
				this.#logger.add("SettingsMgr: Storage quota exceeded, attempting cleanup...");

				try {
					await this.#storageAdapter.set("hiddenItems", []);
					await this.#save();
				} catch (retryError) {
					this.#logger.add(`SettingsMgr: Storage quota cleanup failed: ${retryError.message}`);
					return false;
				}
			} else {
				// Some other error occurred - log it instead of showing alert
				this.#logger.add(`SettingsMgr: Storage error: ${e.name} - ${e.message}`);
				console.error("SettingsMgr storage error:", e);
				return false;
			}
		}

		return true;
	}

	async #loadSettingsFromStorage(skipMigration = false) {
		const settings = await this.#storageAdapter.get("settings");

		// If no settings exist already, create the default ones
		if (!settings?.general || Object.keys(settings).length === 0) {
			// Will generate default settings
			try {
				await this.#storageAdapter.clear();
			} catch (error) {
				console.log("SettingsMgr: Failed to clear storage:", error);
			}
			this.#settings = { ...this.#defaultSettings };
			await this.#save();
		} else {
			this.#settings = { ...settings };
		}

		// Mark loaded before migration so migrateHighlightSettingsToGroups' waitForLoad() resolves (avoids deadlock)
		this.#isLoaded = true;

		if (!skipMigration) {
			await this.#migrate();
		}
	}

	async #migrate() {
		// V3.5.0 - Remove compiled keywords (no longer needed)
		const generalSettings = this.#settings.general || {};
		let hasCompiledKeywords = false;

		// Check for any compiled keyword keys
		const compiledKeys = ["hideKeywords_compiled", "highlightKeywords_compiled", "blurKeywords_compiled"];
		for (const key of compiledKeys) {
			if (generalSettings[key] !== undefined) {
				delete generalSettings[key];
				hasCompiledKeywords = true;
			}
		}

		if (hasCompiledKeywords) {
			this.#logger.add("SettingsMgr: Removed legacy compiled keywords from storage");
			console.log("SettingsMgr: Removed legacy compiled keywords from storage");
			await this.#save();
		}

		const isServiceWorker =
			typeof ServiceWorkerGlobalScope !== "undefined" && self instanceof ServiceWorkerGlobalScope;

		//3.9.0
		// Migrate old keywords to keyword groups system
		// Check if old keywords still exist - if they do, migration is needed even if flag is set
		// Skip in service worker context (dynamic import() not supported - reuse isServiceWorker from above)
		if (!isServiceWorker && !this.#settings.general?.keywordGroups) {
			const hasOldKeywords =
				(this.#settings.general?.highlightKeywords &&
					Array.isArray(this.#settings.general.highlightKeywords) &&
					this.#settings.general.highlightKeywords.length > 0) ||
				(this.#settings.general?.hideKeywords &&
					Array.isArray(this.#settings.general.hideKeywords) &&
					this.#settings.general.hideKeywords.length > 0) ||
				(this.#settings.general?.blurKeywords &&
					Array.isArray(this.#settings.general.blurKeywords) &&
					this.#settings.general.blurKeywords.length > 0);

			// Run migration if:
			// 1. Migration hasn't been attempted yet, OR
			// 2. Old keywords still exist (migration may have failed or been incomplete)
			if (hasOldKeywords) {
				// Run migration asynchronously to not block settings loading
				this.#migrateKeywordGroups().catch((error) => {
					// If error is about ServiceWorkerGlobalScope, skip silently (shouldn't happen here but safety check)
					if (
						error.message &&
						(error.message.includes("ServiceWorkerGlobalScope") ||
							error.message.includes("import() is disallowed"))
					) {
						return;
					}
					// Log error but don't block
					this.#logger.add(`SettingsMgr: Error during keyword groups migration: ${error.message}`);
					console.error("SettingsMgr: Error during keyword groups migration:", error);
				});
			}
		}

		//v 3.9.11 - Migrate highlight settings to keyword groups
		// Ensure highlight keyword groups have listingColor, monitorColor, monitorSound from defaults when missing
		// Only run when previous version is <= 3.9.10 (skip in service worker context)
		if (!isServiceWorker) {
			const previousVersion = this.get("general.versionInfoPopup", false);
			const runMigration =
				previousVersion != null &&
				previousVersion !== false &&
				this.#isVersionLte(String(previousVersion), "3.9.10");
			if (runMigration) {
				try {
					const { migrateHighlightSettingsToGroups } = await import("../utils/KeywordGroupsManager.js");
					await migrateHighlightSettingsToGroups(this);
				} catch (error) {
					// If error is about ServiceWorkerGlobalScope, skip silently (expected in SW context)
					if (
						error.message &&
						(error.message.includes("ServiceWorkerGlobalScope") ||
							error.message.includes("import() is disallowed"))
					) {
						// Skip migration in service worker - it's not needed there
						return;
					}
					this.#logger.add(`SettingsMgr: Error during highlight defaults migration: ${error.message}`);
					console.error("SettingsMgr: Error during highlight defaults migration:", error);
				}
			}
		}

		//v3.9.11
		// Migrate onboardingComplete to onboardingIncomplete
		if (this.#settings.general?.onboardingComplete !== undefined) {
			this.#settings.general.onboardingIncomplete = !this.#settings.general.onboardingComplete;
			delete this.#settings.general.onboardingComplete;
			await this.#save();
		}
	}

	async #migrateKeywordGroups() {
		try {
			const module = await import("../utils/KeywordGroupsManager.js");
			const { migrateOldKeywordsToGroups } = module;

			if (!migrateOldKeywordsToGroups) {
				throw new Error("migrateOldKeywordsToGroups function not found in module");
			}

			// Pass raw settings to migration function to ensure we're using raw values, not compiled
			// The migration function will read from settingsManager, but we ensure raw values are available
			const migrationResult = await migrateOldKeywordsToGroups(this, this.#settings);
			if (migrationResult && migrationResult.migrationPerformed) {
				this.#logger.add("SettingsMgr: Migrated old keywords to keyword groups system");
				console.log("SettingsMgr: Migrated old keywords to keyword groups system");

				// Delete old keyword keys from settings AFTER migration is complete
				// Only delete specific keys from general, never touch the general object itself
				/*
				if (this.#settings.general) {
					for (const keyPath of migrationResult.keysToDelete) {
						// Extract just the key name (e.g., "highlightKeywords" from "general.highlightKeywords")
						const keyName = keyPath.split(".").pop();
						if (this.#settings.general[keyName] !== undefined) {
							console.log(`SettingsMgr: Deleting old keyword key: ${keyName}`);
							delete this.#settings.general[keyName];
						}
					}
				}
				*/
				// Save the changes
				await this.#save();
			} else {
				console.log("SettingsMgr: No migration needed or migration returned no result");
			}
		} catch (error) {
			// Log error but don't block settings loading
			this.#logger.add(`SettingsMgr: Error during keyword groups migration: ${error.message}`);
			console.error("SettingsMgr: Error during keyword groups migration:", error);
		}
	}

	#getDefaultSettings() {
		this.#defaultSettings = {
			i18n: {
				localeOverride: "",
				"24hrsFormat": false,
			},
			unavailableTab: {
				active: true,
			},

			general: {
				bookmark: false,
				bookmarkColor: "#90ee90",
				bookmarkDate: 0,
				unblurImageOnHover: false,
				carousel: {
					active: true,
				},
				country: null,
				customCSS: "",
				detailsIcon: true,
				deviceName: null,
				discoveryFirst: true,
				displayETV: true,
				displayPrice: true,
				displayFirstSeen: true,
				displayFullTitleTooltip: false,
				displayModalETV: false,
				etvModalOnTop: false,
				displayVariantIcon: true,
				displayVariantButton: true,
				displayNonZeroPriceWarning: false,
				ETV: {
					modifier: 1,
				},
				fingerprint: null,
				forceCheckoutNewTab: false,
				onboardingComplete: false,
				showOnboarding: 0,
				hiddenItemsCacheSize: 4,
				hideCategoriesRFYAFA: false,
				hideReviewHighlights: false,
				hideNoNews: true,
				scrollToRFY: false,
				hideOptOutButton: false,
				hideRecommendations: false,
				hideHeader: false,
				hideFooter: false,
				hideAssociateStripe: false,
				hideSideCart: false,
				displayAccountExtraStats: true,
				highlightColor: {
					active: true, //Deprecated as of 3.9.11
					color: "#FFE815", //Still used as the default color
					ignore0ETVhighlight: false,
					ignoreUnknownETVhighlight: false,
				},
				highlightKWFirst: true,
				listView: false,
				modalNavigation: false,
				searchOpenModal: false,
				orderNow: {
					active: false,
					colorNonVariants: "#ffa41c",
					colorVariants: "#ffa41c",
					parallelCheckout: false,
					skipConfirmOrder: false,
					preferredAddressId: "",
					shippingPriority: "",
				},
				patreon: {
					tier: 0,
				},
				projectedAccountStatistics: true,
				rollingVine: true,
				reviewToolbar: true,
				reviewToolbarMaxReviews: 100,
				reviewSubmissionMarker: false,
				reviewManager: true,
				reviewManagerGrammarCollapsed: false,
				reviewManagerAiCollapsed: false,
				reviewManagerCurrentPeriodOnly: false,
				tileSize: {
					active: true,
					enabled: true,
					fontSize: 14,
					iconSize: 14,
					rowSpacing: 0,
					titleSpacing: 50,
					toolbarFontSize: 10,
					verticalSpacing: 20,
					width: 236,
				},
				topPagination: true,
				toolbarBackgroundColor: "#FFFFFF",
				skipPrimeAd: false,
				syncSettings: false,
				unknownETVHighlight: {
					active: false,
					color: "#FF3366",
				},
				uuid: null,
				apiFallbackUntil: 0,
				verbosePagination: false,
				verbosePaginationStartPadding: 5,
				versionInfoPopup: 0,
				zeroETVHighlight: {
					active: true,
					color: "#64af4b",
				},
				debugTabTitle: false,
				debugPlaceholders: false,
				debugStackTraces: false,
				debugTitleDisplay: false,
				debugMemory: false,
				debugBulkOperations: false,
				debugTruncation: false,
				debugMemoryAutoSnapshot: false,
				debugKeywords: false,
				debugSettings: false,
				debugStorage: false,
				debugVisibility: false,
				debugTileCounter: false,
				debugSound: false,
				debugDuplicates: false,
				debugItemProcessing: false,
				debugWebsocket: false,
				debugServercom: false,
				debugServiceWorker: false,
				debugCoordination: false,
				debugWebhooks: false,
				debugMonitorLog: false,
				debugReactDevTools: false,
				debugVersionLabel: false,
			},
			metrics: {
				minutesUsed: 0,
			},
			notification: {
				active: false,
				connectionMode: "0",
				hideList: true,
				autoload: {
					min: 2,
					max: 5,
					hourStart: "03:00",
					hourEnd: "17:00",
					whenDroppingMin: 30,
					whenDroppingMax: 60,
					rfyActive: true,
					rfyMin: 2,
					rfyMax: 5,
					favouriteCategories: [],
					favMin: 30,
					favMax: 60,
				},
				monitor: {
					reactUi: false,
					autoTruncate: true,
					autoTruncateLimit: 1000,
					mouseoverPause: false,
					pauseOverlay: false,
					bump0ETV: true,
					carousel: {
						active: false,
					},
					ETV: {
						modifier: 1,
					},
					filterQueue: -1,
					filterType: -1,
					placeholders: true,
					highlight: {
						color: "#FFE815", //Still used as the default color
						colorActive: true, //Deprecated as of 3.9.11
						sound: "0", //Deprecated as of 3.9.11
						volume: 1, //Deprecated as of 3.9.11
						ignore0ETVhighlight: false,
						ignoreUnknownETVhighlight: false,
					},
					hideAddsToHiddenList: false,
					hideDuplicateThumbnail: false,
					hideGoldNotificationsForSilverUser: false,
					passiveClears: true,
					listView: false,
					openLinksInNewTab: "1",
					v3LiteOpenLinksInNewTab: "0",
					v4OpenLinksInNewTab: "0",
					v4: {
						titleFontSmartColor: true,
					},
					topRightLinkTarget: "v4",
					preventUnload: true,
					regular: {
						sound: "0",
						volume: 1,
					},
					sortType: "date_desc",
					tileSize: {
						fontSize: 14,
						iconSize: 14,
						rowSpacing: 0,
						titleSpacing: 50,
						toolbarFontSize: 10,
						verticalSpacing: 20,
						width: 236,
					},
					unknownETV: {
						color: "#FF3366",
						colorActive: false,
					},
					zeroETV: {
						color: "#64af4b",
						colorActive: true,
						sound: "0",
						volume: 1,
					},
					rfy: {
						color: "#7199FF",
						colorActive: false,
						sound: "0",
						volume: 1,
					},
					wakeLock: false,
					focusMode: false,
					autoClearUnavailableOnInitialFetch: false,
					vineJailCheck: {
						lastCheckedAt: 0,
						inJail: false,
					},
				},
				pushNotifications: false,
				pushNotificationsAFA: false,
				reduce: false,
				screen: {
					active: false,
					regular: {
						sound: "0",
						volume: 1,
					},
					thumbnail: true,
				},
				soundCooldownDelay: 2000,
			},

			keyBindings: {
				active: true,
				AFAPage: "a",
				AIPage: "i",
				ALLPage: "l",
				debug: "d",
				hideAll: "h",
				nextPage: "n",
				pauseFeed: "f",
				previousPage: "p",
				RFYPage: "r",
				showAll: "s",
				clearVisibleItems: "",
			},

			hiddenTab: {
				active: true,
				remote: false,
			},

			pinnedTab: {
				active: true,
				remote: false,
			},

			checkout: {
				riskAcceptedAt: null,
				currentASIN: null,
				currentParentASIN: null,
				arrCurrentCheckouts: [],
			},

			discord: {
				active: false,
				guid: null,

				webhook: {
					KWsMatch: {
						active: false,
						url: "",
						method: "POST",
						content: `{
"content": "New item in $QUEUE_NAME!",
"embeds": [{
	"title": "$TITLE",
	"url": "$VH_URL",
	"thumbnail":  {
		"url": "$IMG_URL"
	}
}]
}`,
					},
					AFA: {
						active: false,
						url: "",
						method: "POST",
						content: `{
"content": "New item in $QUEUE_NAME!",
"embeds": [{
	"title": "$TITLE",
	"url": "$VH_URL",
	"thumbnail":  {
		"url": "$IMG_URL"
	}
}]
}`,
					},
					RFY: {
						active: false,
						url: "",
						method: "POST",
						content: `{
"content": "New item in $QUEUE_NAME!",
"embeds": [{
	"title": "$TITLE",
	"url": "$VH_URL",
	"thumbnail":  {
		"url": "$IMG_URL"
	}
}]
}`,
					},
					zeroETV: {
						active: false,
						url: "",
						method: "POST",
						content: `{
"content": "0 ETV item in $QUEUE_NAME!",
"embeds": [{
	"title": "$TITLE",
	"url": "$VH_URL",
	"thumbnail":  {
		"url": "$IMG_URL"
	}
}]
}`,
					},
				},
			},
		};
	}
}
