import { getMessage, Internationalization } from "/scripts/core/services/Internationalization.js";

const OVERLAY_ID = "vh-vine-jail-overlay";
const CHECK_DELAY_MS = 1000;
const CACHE_TTL_MS = 12 * 60 * 60 * 1000;
const UNDER_REVIEW_SELECTOR = "#vvp-under-review-alert";
const LAST_CHECKED_PATH = "notification.monitor.vineJailCheck.lastCheckedAt";
const IN_JAIL_PATH = "notification.monitor.vineJailCheck.inJail";

/**
 * @param {string} domainTLD
 * @returns {string}
 */
export function buildVineAccountPageUrl(domainTLD) {
	return `https://www.amazon.${domainTLD}/vine/account`;
}

/**
 * @param {string} [countryCode]
 * @returns {string}
 */
export function resolveDomainTLD(countryCode) {
	const i18n = new Internationalization();
	if (countryCode) {
		i18n.setCountryCode(countryCode);
	}
	return i18n.getDomainTLD() || "com";
}

/**
 * @param {string} domainTLD
 * @returns {Promise<string>}
 */
async function fetchAccountPageHtml(domainTLD) {
	const url = buildVineAccountPageUrl(domainTLD);
	const headers = {
		"User-Agent": navigator.userAgent,
		Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Language": navigator.language || navigator.languages?.join(",") || "en-US,en;q=0.9",
		"Cache-Control": "no-cache",
		Pragma: "no-cache",
	};
	const response = await fetch(url, { headers, credentials: "include" });
	return response.text();
}

/**
 * @param {string} html
 * @returns {boolean}
 */
function isUnderReviewInHtml(html) {
	const doc = new DOMParser().parseFromString(html, "text/html");
	return !!doc.querySelector(UNDER_REVIEW_SELECTOR);
}

function ensureStylesheet() {
	if (document.getElementById("vh-vine-jail-check-css")) {
		return;
	}
	const link = document.createElement("link");
	link.id = "vh-vine-jail-check-css";
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = chrome.runtime.getURL("resource/css/vine-jail-check.css");
	document.head.appendChild(link);
}

function removeOverlay() {
	document.getElementById(OVERLAY_ID)?.remove();
}

function showCheckingOverlay() {
	ensureStylesheet();
	removeOverlay();

	const overlay = document.createElement("div");
	overlay.id = OVERLAY_ID;
	overlay.className = "vh-vine-jail-overlay vh-vine-jail-checking";
	overlay.setAttribute("role", "status");
	overlay.setAttribute("aria-live", "polite");
	overlay.innerHTML = `
		<div class="vh-vine-jail-panel">
			<div class="vh-vine-jail-icon-wrap" aria-hidden="true">
				<div class="vh-vine-jail-scan-ring"></div>
				<div class="vh-vine-jail-scan-ring vh-vine-jail-scan-ring--delayed"></div>
				<div class="vh-vine-jail-check-icon">
					<svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
						<path d="M12 2 4 5v6c0 5.25 3.4 10.15 8 11.35 4.6-1.2 8-6.1 8-11.35V5l-8-3zm-1 13-3.5-3.5 1.4-1.4L11 12.2l4.6-4.6 1.4 1.4L11 15z"></path>
					</svg>
				</div>
			</div>
			<h2 class="vh-vine-jail-title">${getMessage("nmVineJailChecking", "Checking account status...")}</h2>
			<p class="vh-vine-jail-detail">${getMessage("nmVineJailCheckingDetail", "Verifying your Vine account standing")}</p>
			<div class="vh-vine-jail-progress" aria-hidden="true">
				<div class="vh-vine-jail-progress-bar"></div>
			</div>
		</div>
	`;
	document.body.appendChild(overlay);
}

/**
 * @param {string} accountPageUrl
 */
function showErrorOverlay(accountPageUrl) {
	ensureStylesheet();
	removeOverlay();

	const overlay = document.createElement("div");
	overlay.id = OVERLAY_ID;
	overlay.className = "vh-vine-jail-overlay vh-vine-jail-error";
	overlay.setAttribute("role", "alert");
	overlay.innerHTML = `
		<div class="vh-vine-jail-panel">
			<div class="vh-vine-jail-error-icon" aria-hidden="true">
				<svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
					<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
				</svg>
			</div>
			<h2 class="vh-vine-jail-title">${getMessage("nmVineJailTitle", "Your account is in Vine Jail")}</h2>
			<p class="vh-vine-jail-detail">${getMessage(
				"nmVineJailMessage",
				"Your account is in Vine Jail. The notification monitor cannot be used until your account is in good standing."
			)}</p>
			<a class="vh-vine-jail-link" href="${accountPageUrl}" target="_blank" rel="noopener noreferrer">${getMessage(
				"nmVineJailAccountLink",
				"Go to Vine account page"
			)}</a>
		</div>
	`;
	document.body.appendChild(overlay);
}

/**
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @returns {Promise<boolean>} `true` when a fresh-enough "not in jail" result can be reused
 */
async function canSkipLiveCheck(settings) {
	await settings.waitForLoad();
	const lastCheckedAt = Number(settings.get(LAST_CHECKED_PATH, false)) || 0;
	if (!lastCheckedAt || Date.now() - lastCheckedAt >= CACHE_TTL_MS) {
		return false;
	}
	if (settings.get(IN_JAIL_PATH, false)) {
		return false;
	}
	return true;
}

/**
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @param {boolean} inJail
 * @returns {Promise<void>}
 */
async function persistCheckResult(settings, inJail) {
	await settings.set(LAST_CHECKED_PATH, Date.now());
	await settings.set(IN_JAIL_PATH, inJail);
}

/**
 * Fetches the Vine account page and blocks monitor startup when the account is under review.
 * A clear result is cached in settings for 12 hours; in-jail results are always re-checked.
 *
 * @param {string} domainTLD
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} [settings]
 * @returns {Promise<boolean>} `true` when the monitor may load, `false` when in vine jail
 */
export async function ensureNotInVineJail(domainTLD, settings = null) {
	if (!settings) {
		const { SettingsMgr } = await import("/scripts/core/services/SettingsMgr.js");
		settings = new SettingsMgr();
	}

	if (await canSkipLiveCheck(settings)) {
		return true;
	}

	showCheckingOverlay();

	try {
		await new Promise((resolve) => setTimeout(resolve, CHECK_DELAY_MS));
		const html = await fetchAccountPageHtml(domainTLD);
		const inJail = isUnderReviewInHtml(html);
		await persistCheckResult(settings, inJail);
		if (inJail) {
			showErrorOverlay(buildVineAccountPageUrl(domainTLD));
			return false;
		}
		removeOverlay();
		return true;
	} catch (error) {
		console.warn("[VineJailCheck] Failed to check account status, allowing monitor to load:", error);
		removeOverlay();
		return true;
	}
}
