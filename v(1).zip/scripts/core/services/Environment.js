/* global chrome */

import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { Internationalization } from "/scripts/core/services/Internationalization.js";
var i18n = new Internationalization();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
var Settings = new SettingsMgr();

import { DeviceFingerprintMgr } from "/scripts/core/services/DeviceFingerprintMgr.js";
import { DeviceMgr } from "/scripts/core/services/DeviceMgr.js";

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
var cryptoKeys = new CryptoKeys();

import { isFirefox, isSafari } from "/scripts/core/utils/BrowserDetection.js";
import { showMobileBootError } from "/scripts/core/utils/MobileBootError.js";
import { getInfoPageParam } from "/scripts/core/utils/VineBrowseContext.js";
import { findVvpContextScriptElement } from "/scripts/core/amazon/parsers/vvpContext.js";

const VVP_CONTEXT_WAIT_MS = 30_000;
const ENV_LOAD_STALL_MS = 45_000;
/** Human-readable labels for boot-phase stall reporting on mobile. */
const BOOT_PHASE_LABELS = {
	starting: "startup",
	settings: "settings",
	vvpContext: "VVP context",
	uuid: "device UUID",
	ready: "startup",
};
/** Separate from `settings` so monitor autoload does not trigger settings-page sync. */
const VVP_CONTEXT_STORAGE_KEY = "vvpContext";
/** Shared across content-script module loads and the Vite-bundled Monitor V4 entry. */
const ENV_GLOBAL_SINGLETON_KEY = "__VH_ENVIRONMENT__";

const VHELPER_API_V5_URL = "https://api.v-helper.com";
//const VHELPER_API_V5_URL = "http://127.0.0.1:3000";
const VHELPER_API_V5_FALLBACK_URL = "https://api.vinehelper.ovh";

/**
 * Environment file, used to load and store global variables
 */

class Environment {
	static #instance = null;

	data = {};
	loaded = false;

	#UUIDRequestFailed = false;
	#vvpContext = null;
	#mobileLoadStallReported = false;
	/** Updated during `#init()` so stall errors name the step that is still running. */
	#bootPhase = "starting";

	constructor() {
		const globalExisting = globalThis[ENV_GLOBAL_SINGLETON_KEY];
		if (globalExisting) {
			Environment.#instance = globalExisting;
			return globalExisting;
		}
		if (Environment.#instance) {
			globalThis[ENV_GLOBAL_SINGLETON_KEY] = Environment.#instance;
			return Environment.#instance;
		}
		// Initialize the instance if it doesn't exist
		Environment.#instance = this;
		globalThis[ENV_GLOBAL_SINGLETON_KEY] = this;

		logger.add("ENV: Initializing environment...");

		this._deviceMgr = new DeviceMgr(Settings);
		this._deviceFingerprintMgr = new DeviceFingerprintMgr(this, Settings);
		this.#init();
	}

	#isServiceWorkerContext() {
		return (
			typeof ServiceWorkerGlobalScope !== "undefined" &&
			typeof self !== "undefined" &&
			self instanceof ServiceWorkerGlobalScope
		);
	}

	#isBrowserContext() {
		if (this.#isServiceWorkerContext()) {
			return false;
		}
		return typeof document !== "undefined" && typeof document.querySelector === "function";
	}

	async #init() {
		try {
			if (this.#isBrowserContext()) {
				this.#isUltraVinerRunning();
			} else {
				this.data.ultraviner = false;
			}
			this.#loadAppVersion();

			this.#bootPhase = "settings";
			logger.add("ENV: Waiting for settings to load...");
			await Settings.waitForLoad();
			logger.add("ENV: Settings loaded.");

			this.#loadDiscordActive();
			await this.#loadCountryCode();
			await cryptoKeys.waitForLoad();

			this.#bootPhase = "vvpContext";
			if (this.#isBrowserContext()) {
				await this.ensureVVPContextFromPage({ timeoutMs: VVP_CONTEXT_WAIT_MS });
				logger.add("ENV: VVP context data available.");
				this.#bootPhase = "uuid";
				await this.#loadUUID();
				this.#loadBrowsingContext();
			} else {
				await this.#loadVVPContextFromStorage();
				this.#readVVPContext();
				this.#bootPhase = "uuid";
				await this.#loadUUID();
			}
			this.#bootPhase = "ready";
			logger.add("ENV: Environment init completed.");
		} catch (error) {
			logger.add("ENV: Init failed: " + (error?.message || error));
			this.data.initError = error?.message || String(error);
			showMobileBootError(error, { source: "Environment.js", phase: "init" });
		} finally {
			this.loaded = true;
		}
	}

	#hasUsableVVPContext() {
		return !!(this.#vvpContext && typeof this.#vvpContext === "object" && this.#vvpContext.csrfToken);
	}

	#reportBootStall(phase, detail) {
		const label = BOOT_PHASE_LABELS[phase] || phase;
		showMobileBootError(
			new Error(
				detail ||
					`Environment: ${label} did not finish loading within ${Math.round(ENV_LOAD_STALL_MS / 1000)} seconds.`
			),
			{ source: "Environment.js", phase: phase || "waitForLoad" }
		);
	}

	#isBootPhaseReady(phase) {
		switch (phase) {
			case "settings":
				return true;
			case "vvpContext":
				return this.#hasUsableVVPContext();
			case "uuid":
				return !!(Settings.get("general.uuid", false) || this.#UUIDRequestFailed);
			default:
				return this.loaded;
		}
	}

	/**
	 * Wait until selected boot-critical data is ready (settings, VVP context, UUID).
	 * Use instead of `waitForLoad()` when only a subset is required (e.g. Monitor V4 takeover).
	 *
	 * @param {object} [options]
	 * @param {boolean} [options.requirePageVvp=false] - require a live page vvp-context script (before DOM teardown)
	 * @param {number} [options.vvpWaitMs=15000]
	 * @param {string[]} [options.phases=['settings','vvpContext','uuid']]
	 * @param {boolean} [options.reportStall=true]
	 * @returns {Promise<{ ok: boolean, failedPhase?: string }>}
	 */
	async waitForBootCritical(options = {}) {
		const {
			requirePageVvp = false,
			vvpWaitMs = 15_000,
			phases = ["settings", "vvpContext", "uuid"],
			reportStall = true,
		} = options;

		const started = Date.now();
		let stallReported = false;

		if (requirePageVvp) {
			const vvp = await this.ensureVVPContextFromPage({ timeoutMs: vvpWaitMs, requireDom: true });
			if (!vvp.ok) {
				if (reportStall) {
					this.#reportBootStall(
						"vvpContext",
						"VVP context could not be read from the Amazon page. CSRF and customer data are required before Monitor V4 can start."
					);
				}
				return { ok: false, failedPhase: "vvpContext" };
			}
		}

		if (phases.includes("settings")) {
			this.#bootPhase = "settings";
			await Settings.waitForLoad();
		}

		while (true) {
			const pending = phases.filter((phase) => !this.#isBootPhaseReady(phase));
			if (pending.length === 0) {
				return { ok: true };
			}

			if (pending.includes("uuid") && !Settings.get("general.uuid", false) && !this.#UUIDRequestFailed) {
				const uuidReady = await this.waitForUUID();
				if (uuidReady) {
					continue;
				}
				if (this.#UUIDRequestFailed) {
					return { ok: false, failedPhase: "uuid" };
				}
			}

			if (this.loaded) {
				const stillPending = phases.filter((phase) => !this.#isBootPhaseReady(phase));
				if (stillPending.length > 0) {
					return { ok: false, failedPhase: stillPending[0] };
				}
				return { ok: true };
			}

			if (reportStall && !stallReported && Date.now() - started > ENV_LOAD_STALL_MS) {
				stallReported = true;
				this.#reportBootStall(pending[0] || this.#bootPhase);
			}

			await new Promise((resolve) => setTimeout(resolve, 50));
		}
	}

	#findVVPContextScriptElement() {
		if (!this.#isBrowserContext()) {
			return null;
		}
		return findVvpContextScriptElement(document);
	}

	async waitForLoad() {
		const started = Date.now();
		while (!this.loaded) {
			if (!this.#mobileLoadStallReported && Date.now() - started > ENV_LOAD_STALL_MS) {
				this.#mobileLoadStallReported = true;
				this.#reportBootStall(this.#bootPhase);
			}
			await new Promise((resolve) => setTimeout(resolve, 50));
		}
		return true;
	}

	#isUltraVinerRunning() {
		const regex = /^.+?amazon\..+\/vine\/.*ultraviner.*?$/;
		this.data.ultraviner = typeof window !== "undefined" && regex.test(window.location.href);
	}
	#loadAppVersion() {
		let manifest = chrome.runtime.getManifest();
		this.data.appVersion = manifest.version;
	}

	async #loadCountryCode() {
		if (Settings.get("general.country", false) === null) {
			const code = i18n.getCountryCode();
			if (code) {
				await Settings.set("general.country", code);
			}
		}
	}

	#loadDiscordActive() {
		//If the domain if not from outside the countries supported by the discord API, disable discord
		if (i18n.getDomainTLD() != null) {
			if (["ca", "com", "co.uk"].indexOf(i18n.getDomainTLD()) == -1) {
				Settings.set("discord.active", false);
			}
		}
	}

	#loadBrowsingContext() {
		//Try to obtain the queue from the vvpContext
		this.data.vineQueue = this.#readQueue(null);

		//If the queue was not obtained from the vvpContext, try to obtain it from the URL
		if (!this.data.vineQueue) {
			this.#readQueueFromURL("all_items");
		}

		//Determine if we are currently searching for an item
		let regex, arrMatches;
		const currentUrl = window.location.href;
		regex = /^.+?amazon\..+\/vine\/vine-items(?:.*?)(?:[?&]search=(.+?))(?:[#&].*?)?$/;
		arrMatches = currentUrl.match(regex);
		this.data.vineSearch = false;
		if (arrMatches != null) {
			if (arrMatches[1] == undefined) {
				this.data.vineSearch = false;
			} else {
				this.data.vineSearch = true;
				this.data.vineQueue = null;
			}
		}

		let arrQueues = { potluck: "RFY", last_chance: "AFA", encore: "AI", all_items: "ALL" };
		if (this.data.vineQueue != null) {
			this.data.vineQueueAbbr = arrQueues[this.data.vineQueue];
		}

		//Determine what page number we are on:
		regex = /&page=(\d+)?/;
		const match = currentUrl.match(regex);
		let vinePageNumber;
		if (match) {
			vinePageNumber = match[1] ? parseInt(match[1]) : 1;
		} else {
			vinePageNumber = 1;
		}
		this.data.vinePageNumber = getInfoPageParam(currentUrl, vinePageNumber);
	}

	async #loadUUID() {
		//Generate a UUID for the user
		let uuid = Settings.get("general.uuid", false);
		if (!uuid || uuid == "") {
			try {
				uuid = await this.#requestNewUUID();
				await Settings.set("general.uuid", uuid);
				await Settings.set("general.uuidError", null);
				logger.add("ENV: Obtained new UUID");
			} catch (error) {
				this.#UUIDRequestFailed = true;
				await Settings.set("general.uuidError", error.message);
				return false;
			}
		}

		//Generate a device name
		let deviceName = await this._deviceMgr.getDeviceName();
		if (!deviceName) {
			deviceName = await this._deviceMgr.generateDeviceName(true);
		}

		// Fingerprint collection requires DOM/canvas; skip in service worker (e.g. Websocket.js).
		if (this.#isBrowserContext()) {
			if (
				!(await this._deviceFingerprintMgr.getFingerprintHash()) || //If the fingerprint was not generated.
				!(await this._deviceFingerprintMgr.getFingerprintId()) //If the fingerprint was not sucessfully saved.
			) {
				try {
					await this._deviceFingerprintMgr.generateFingerprint(uuid, deviceName);
				} catch (error) {
					//There was an error generating or submitting the fingerprint.
					//Clear the fingerprint and try again later.
					logger.add("ENV: Fingerprint error: " + error);
					await this._deviceFingerprintMgr.clearFingerprint();
				}
			}
		}
	}

	//Wait for the UUID to be set,
	async waitForUUID() {
		return new Promise((resolve) => {
			const checkUUID = () => {
				const uuid = Settings.get("general.uuid", false);
				if (uuid) {
					resolve(true);
				} else if (this.#UUIDRequestFailed) {
					resolve(false);
				} else {
					// If still requesting, check again after a short delay
					setTimeout(checkUUID, 50);
				}
			};
			checkUUID();
		});
	}

	/**
	 * Server rejected the stored UUID (unknown or stale). Clear it and run the same
	 * provisioning path as boot so get_uuid records the current CID.
	 */
	async recoverFromInvalidUuid() {
		this.#UUIDRequestFailed = false;
		await Settings.set("general.uuidError", null);
		await Settings.set("general.uuid", null);
		await this.#loadUUID();
	}

	/** Request a new UUID from the server.
	 * @return string UUID
	 */
	async #requestNewUUID() {
		logger.add("ENV: Generating new UUID.");

		//Request a new UUID from the server
		const content = {
			api_version: 5,
			app_version: this.data.appVersion,
			action: "get_uuid",
			country: i18n.getCountryCode(),
			cid: await this.getCID(),
		};
		const s = await cryptoKeys.signData(content);
		content.s = s;
		content.pk = await cryptoKeys.getExportedPublicKey();
		const options = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		};

		let response = await fetch(this.getAPIUrl(), options);

		// Parse the JSON response
		let serverResponse = await response.json();

		if (serverResponse["ok"] !== "ok") {
			logger.add("ENV: get_uuid response: " + JSON.stringify(serverResponse));
			throw new Error(serverResponse["error"]);
		}

		// Return the obtained UUID
		return serverResponse["uuid"];
	}

	getAPIUrl() {
		const until = Settings.get("general.apiFallbackUntil", 0);
		if (typeof until === "number" && until > Date.now()) {
			return VHELPER_API_V5_FALLBACK_URL;
		} else if (until !== 0) {
			Settings.set("general.apiFallbackUntil", 0); //Reset the fallback until
		}
		return VHELPER_API_V5_URL;
	}

	isUsingFallback() {
		const until = Settings.get("general.apiFallbackUntil", 0);
		return typeof until === "number" && until > Date.now();
	}

	getFallbackUntil() {
		const until = Settings.get("general.apiFallbackUntil", 0);
		return typeof until === "number" ? until : 0;
	}

	async offerFallbackForNext48Hours() {
		if (this.isUsingFallback()) {
			return false;
		}
		const promptMessage =
			chrome.i18n.getMessage("settingsApiFallbackPrompt") ||
			"Connection to the main server failed. Use the fallback server (api.vinehelper.ovh) for the next 7 days?";

		const confirmed = window.confirm(promptMessage);
		if (!confirmed) {
			return false;
		}
		const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
		await Settings.set("general.apiFallbackUntil", expiresAt);
		return true;
	}

	getTierLevel(defaultStatus = "silver") {
		if (!this.data.tierLevel) {
			this.data.tierLevel = this.#readTierLevel();
		}
		return this.data.tierLevel ? this.data.tierLevel : defaultStatus;
	}

	#readTierLevel() {
		let status;
		try {
			if (!this.#vvpContext) {
				this.#readVVPContext();
			}
			status = this.#vvpContext?.voiceDetails.tierStatus == "TIER2" ? "gold" : "silver";
		} catch {
			status = null;
		}
		return status;
	}

	async #loadVVPContextFromStorage() {
		try {
			const data = await chrome.storage.local.get(VVP_CONTEXT_STORAGE_KEY);
			const stored = data?.[VVP_CONTEXT_STORAGE_KEY];
			if (stored && typeof stored === "object") {
				this.#vvpContext = stored;
				return;
			}
			const legacy = Settings.get("vvpContext", false);
			if (legacy && typeof legacy === "object") {
				this.#vvpContext = legacy;
				await chrome.storage.local.set({ [VVP_CONTEXT_STORAGE_KEY]: legacy });
			}
		} catch (err) {
			logger.add("ENV: Failed to load VVP context from storage: " + err.message);
		}
	}

	#persistVVPContextToStorage(vvpContext) {
		try {
			if (typeof chrome === "undefined" || !chrome.runtime?.id || !chrome.storage?.local) {
				return Promise.resolve();
			}
			return chrome.storage.local.set({ [VVP_CONTEXT_STORAGE_KEY]: vvpContext }).catch((err) => {
				logger.add("ENV: Failed to cache VVP context in storage: " + err.message);
			});
		} catch (err) {
			logger.add("ENV: Failed to cache VVP context in storage: " + err.message);
			return Promise.resolve();
		}
	}

	#readVVPContext() {
		// Prefer the live page script whenever it is still in the DOM.
		if (this.#isBrowserContext()) {
			try {
				const scriptElement = this.#findVVPContextScriptElement();
				if (scriptElement) {
					const vvpContext = JSON.parse(scriptElement.innerHTML);
					this.#setVVPContext(vvpContext);
					return this.#vvpContext;
				}
			} catch (err) {
				logger.add("ENV: Failed to read VVP context from DOM: " + err.message);
			}
		}

		if (this.#vvpContext !== null) {
			return this.#vvpContext;
		}

		// Legacy: still readable from settings blob until user clears storage
		try {
			const cachedContext = Settings.get("vvpContext", false);
			if (cachedContext && typeof cachedContext === "object") {
				this.#vvpContext = cachedContext;
				void this.#persistVVPContextToStorage(cachedContext);
				return this.#vvpContext;
			}
		} catch (err) {
			logger.add("ENV: Failed to read VVP context from settings cache: " + err.message);
		}

		// If both failed, return empty object
		this.#vvpContext = {};
		return this.#vvpContext;
	}

	#setVVPContext(vvpContext) {
		const cachedStr = this.#vvpContext ? JSON.stringify(this.#vvpContext) : null;
		const newStr = vvpContext ? JSON.stringify(vvpContext) : null;
		this.#vvpContext = vvpContext;
		if (cachedStr !== newStr) {
			void this.#persistVVPContextToStorage(vvpContext);
		}
	}

	updateVVPContext(vvpContext) {
		this.#setVVPContext(vvpContext);
	}

	/**
	 * Load vvp-context from chrome.storage, then optionally wait for the live page script.
	 * Single entry point for DOM + storage reads (bootloader, init, CSRF refresh).
	 *
	 * @param {object} [options]
	 * @param {number} [options.timeoutMs=0] - max ms to poll the page for the vvp-context script
	 * @param {boolean} [options.requireDom=false] - when true, cached storage alone is not enough
	 * @returns {Promise<{ ok: boolean, source: 'dom' | 'storage' | 'none' }>}
	 */
	async ensureVVPContextFromPage({ timeoutMs = 0, requireDom = false } = {}) {
		await this.#loadVVPContextFromStorage();

		if (!this.#isBrowserContext()) {
			const ok = !requireDom && this.#hasUsableVVPContext();
			return { ok, source: ok ? "storage" : "none" };
		}

		const deadline = Date.now() + Math.max(0, timeoutMs);
		do {
			const scriptElement = this.#findVVPContextScriptElement();
			if (scriptElement) {
				try {
					const vvpContext = JSON.parse(scriptElement.innerHTML);
					this.#setVVPContext(vvpContext);
					if (this.#hasUsableVVPContext()) {
						return { ok: true, source: "dom" };
					}
				} catch (err) {
					logger.add("ENV: Failed to read VVP context from DOM: " + err.message);
				}
			}

			if (!requireDom && this.#hasUsableVVPContext()) {
				return { ok: true, source: "storage" };
			}

			if (Date.now() >= deadline) {
				break;
			}
			await new Promise((resolve) => setTimeout(resolve, 50));
		} while (Date.now() < deadline);

		if (!requireDom) {
			this.#readVVPContext();
			const ok = this.#hasUsableVVPContext();
			return { ok, source: ok ? "storage" : "none" };
		}

		return { ok: false, source: "none" };
	}

	/**
	 * Re-read vvp-context from the current page DOM and update the cached context.
	 * @returns {Promise<boolean>} true if a context was read from the page
	 */
	async refreshVVPContextFromPage() {
		const result = await this.ensureVVPContextFromPage({ timeoutMs: 0 });
		return result.ok && result.source === "dom";
	}

	getMarketplaceId() {
		if (!this.#vvpContext) {
			this.#readVVPContext();
		}
		return this.#vvpContext?.marketplaceId;
	}

	getCustomerId() {
		if (!this.#vvpContext) {
			this.#readVVPContext();
		}
		return this.#vvpContext?.customerId;
	}

	getVoiceDetails(key) {
		if (!this.#vvpContext) {
			this.#readVVPContext();
		}
		return this.#vvpContext?.voiceDetails[key];
	}

	getCsrfToken() {
		if (this.#isBrowserContext()) {
			try {
				const scriptElement = this.#findVVPContextScriptElement();
				if (scriptElement) {
					const vvpContext = JSON.parse(scriptElement.innerHTML);
					if (vvpContext?.csrfToken) {
						this.#setVVPContext(vvpContext);
						return vvpContext.csrfToken;
					}
				}
			} catch (err) {
				logger.add("ENV: Failed to read CSRF token from DOM: " + err.message);
			}
		}
		if (this.#vvpContext === null) {
			this.#readVVPContext();
		}
		return this.#vvpContext?.csrfToken ?? null;
	}

	async getCID(forceRecalculate = false) {
		const countryCode = i18n.getCountryCode();
		const customerId = this.getCustomerId();
		if (!forceRecalculate && !customerId) {
			return await Settings.get("general.cid", false);
		}

		// Create a one-way secure hash of the customer id
		const encoder = new TextEncoder();
		const data = encoder.encode(countryCode + customerId);
		const hashBuffer = await crypto.subtle.digest("SHA-256", data);

		// Convert to hex string
		const hashArray = Array.from(new Uint8Array(hashBuffer));
		const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");

		//Check if the value was saved
		const oldCID = await Settings.get("general.cid", false);
		if (oldCID !== hashHex) {
			await Settings.set("general.cid", hashHex);
		}

		return hashHex;
	}

	#readQueue(defaultQueue = null) {
		try {
			if (!this.#vvpContext) {
				this.#readVVPContext();
			}
			if (this.#vvpContext?.queueKey) {
				this.data.vineBrowsingListing = true;
			}
			return this.#vvpContext?.queueKey || defaultQueue;
		} catch {
			return defaultQueue;
		}
	}

	#readQueueFromURL(defaultQueue = null) {
		//Determine if we are browsing a queue
		const currentUrl = window.location.href;
		let regex = /^.+?amazon\..+\/vine\/vine-items(?:\?(queue|search)=(.+?))?(?:[#&].*)?$/;
		let arrMatches = currentUrl.match(regex);
		if (arrMatches != null) {
			this.data.vineBrowsingListing = true;
			if (arrMatches[1] == "queue" && arrMatches[2] != undefined) {
				this.data.vineQueue = arrMatches[2];
			} else if (arrMatches[1] == undefined) {
				this.data.vineQueue = defaultQueue; //Default queue
			} else {
				this.data.vineQueue = defaultQueue; //Could be a ?search, (but not a &search).
			}
		}
	}

	getSilverTierLimit() {
		if (!this.data.silverTierLimit) {
			this.data.silverTierLimit = this.#readSilverTierLimit();
		}
		return this.data.silverTierLimit;
	}

	#readSilverTierLimit() {
		const rawText = document.querySelector("#vvp-vine-participation-content ul>li").innerText;
		const regex = new RegExp("^.+?[0-9]{1}.+?([0-9,.]+).+", "m");
		const match = rawText.match(regex);
		if (match) {
			return parseFloat(match[1]);
		}
	}

	isAmazonCheckoutEnabled() {
		try {
			if (!this.#vvpContext) {
				this.#readVVPContext();
			}
			return this.#vvpContext?.isCheckoutEnabled;
		} catch {
			return false;
		}
	}

	isFirefox() {
		return isFirefox();
	}

	isSafari() {
		return isSafari();
	}

	isMobileView() {
		const isAmazonMobileHeader = document.querySelector("header#nav-main.nav-mobile") !== null;
		const visualViewportWidth = window.visualViewport?.width || 0;
		const windowInnerWidth = window.innerWidth || 0;
		const docClientWidth = document.documentElement?.clientWidth || 0;
		const bodyClientWidth = document.body?.clientWidth || 0;
		const screenWidth = window.screen?.width || 0;
		const innerHeight = window.innerHeight || 0;
		const viewportCandidates = [visualViewportWidth, docClientWidth, windowInnerWidth, bodyClientWidth, screenWidth]
			.map((value) => Math.round(Number(value) || 0))
			.filter((value) => value > 0);
		const viewportWidth = viewportCandidates.length > 0 ? Math.min(...viewportCandidates) : 0;
		const isMobileByViewport = viewportWidth > 0 && viewportWidth <= 1024;
		const isMobile = isAmazonMobileHeader || isMobileByViewport;
		return isMobile;
	}

	isVineConsideredMobileView() {
		return document.querySelector("header#nav-main.nav-mobile") !== null;
	}

	//getWSSUrl() {
	//	return "wss://api.v-helper.com";
	//}
}

export { Environment };
