import { isPageLogin, isPageCaptcha, isPageDog } from "/scripts/core/utils/DOMHelper.js";
import { parseVvpContextFromDocument } from "/scripts/core/amazon/parsers/vvpContext.js";

/**
 * Fetch a Vine listing page (same mechanism as monitor autoload) and refresh the CSRF token in env.
 * @param {import("./Environment.js").Environment} env
 * @param {string} domainTLD - e.g. "com"
 * @param {string} [queue="encore"] - Vine queue for the autoload URL
 * @returns {Promise<string|null>} The new CSRF token, or null if not found
 */
export async function refreshCsrfTokenFromVinePage(env, domainTLD, queue = "encore") {
	const url = `https://www.amazon.${domainTLD}/vine/vine-items?queue=${encodeURIComponent(queue)}&page=1`;
	const userAgent = navigator.userAgent;
	const acceptLanguage = navigator.language || navigator.languages?.join(",") || "en-US,en;q=0.9";
	const headers = {
		"User-Agent": userAgent,
		Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		"Accept-Language": acceptLanguage,
		"Accept-Encoding": "gzip, deflate, br",
		"Cache-Control": "no-cache",
		Pragma: "no-cache",
		"Sec-Fetch-Dest": "document",
		"Sec-Fetch-Mode": "navigate",
		"Sec-Fetch-Site": "none",
		"Sec-Fetch-User": "?1",
		"Upgrade-Insecure-Requests": "1",
	};
	const response = await fetch(url, { headers, credentials: "include" });
	const html = await response.text();

	const parser = new DOMParser();
	const doc = parser.parseFromString(html, "text/html");

	if (isPageDog(doc)) {
		throw new Error("dog_page");
	}
	if (isPageCaptcha(doc)) {
		throw new Error("captcha_page");
	}
	if (isPageLogin(doc)) {
		throw new Error("login_page");
	}

	const vvpContext = parseVvpContextFromDocument(doc);
	if (vvpContext) {
		env.updateVVPContext(vvpContext);
		return vvpContext?.csrfToken ?? null;
	}

	return env.getCsrfToken?.() ?? null;
}
