import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";

class UnavailableAsinReporter {
	#env = null;
	#i18n = null;
	#settings = null;
	#cryptoKeys = null;

	/**
	 * @param {unknown} data - Parsed Vine recommendations/item API JSON
	 * @returns {boolean}
	 */
	static isItemNotInEnrollmentResponse(data) {
		return data?.result == null && data?.error?.exceptionType === "ITEM_NOT_IN_ENROLLMENT";
	}

	constructor({ env, i18n, settings = null, cryptoKeys = null }) {
		this.#env = env;
		this.#i18n = i18n;
		this.#settings = settings || new SettingsMgr();
		this.#cryptoKeys = cryptoKeys || new CryptoKeys();
	}

	/**
	 * Report that an item is no longer requestable (`record_unavailable`).
	 * Use this only when a pre-order/details API call fails with `ITEM_NOT_IN_ENROLLMENT`
	 * before the user submits a request.
	 *
	 * For failures after a request attempt (voice order / checkout flow), use
	 * `reportOrderFailure()` so VH receives a `record_order` event instead.
	 *
	 * @param {string} asin
	 * @param {string} reason
	 * @param {{ parentAsin?: string|null }} [meta]
	 */
	async report(asin, reason = "ITEM_NOT_IN_ENROLLMENT", meta = null) {
		if (!asin || !this.#env?.getAPIUrl) return;
		try {
			const parentAsin = meta && typeof meta === "object" ? meta.parentAsin : null;
			const content = {
				api_version: 5,
				app_version: this.#env.data?.appVersion ?? "",
				action: "record_unavailable",
				country: this.#i18n?.getCountryCode?.() || "",
				uuid: await this.#settings.get("general.uuid", false),
				fid: await this.#settings.get("general.fingerprint.id", false),
				cid: await this.#env.getCID(),
				asin,
				parent_asin: parentAsin ?? null,
				reason,
			};
			content.s = await this.#cryptoKeys.signData(content);
			content.pk = await this.#cryptoKeys.getExportedPublicKey();

			await fetch(this.#env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
		} catch (error) {
			console.warn("[UnavailableAsinReporter] Failed to report unavailable item:", error);
		}
	}

	/**
	 * Report a request/order failure (`record_order`).
	 * Use this when the user has clicked Request Product and the order flow fails.
	 *
	 * @param {string} asin
	 * @param {string|null} parentAsin
	 * @param {string} orderStatus
	 * @param {string} orderError
	 */
	async reportOrderFailure(asin, parentAsin, orderStatus = "failed", orderError = "UNKNOWN_ERROR") {
		if (!asin || !this.#env?.getAPIUrl) return;
		try {
			const content = {
				api_version: 5,
				app_version: this.#env.data?.appVersion ?? "",
				action: "record_order",
				country: this.#i18n?.getCountryCode?.() || "",
				uuid: await this.#settings.get("general.uuid", false),
				cid: await this.#env.getCID(),
				fid: await this.#settings.get("general.fingerprint.id", false),
				asin,
				parent_asin: parentAsin ?? null,
				order_status: orderStatus,
				order_error: orderError,
			};
			content.s = await this.#cryptoKeys.signData(content);
			content.pk = await this.#cryptoKeys.getExportedPublicKey();

			await fetch(this.#env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
		} catch (error) {
			console.warn("[UnavailableAsinReporter] Failed to report order failure:", error);
		}
	}
}

export { UnavailableAsinReporter };
