/*global chrome*/

import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { Internationalization } from "/scripts/core/services/Internationalization.js";
const i18n = new Internationalization();

import { Environment } from "/scripts/core/services/Environment.js";
const env = new Environment();

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
const cryptoKeys = new CryptoKeys();

import { Item } from "/scripts/core/models/Item.js";

import { isSafari } from "/scripts/core/utils/BrowserDetection.js";

class PinnedListMgr {
	static #instance = null;

	listLoaded;

	constructor() {
		if (PinnedListMgr.#instance) {
			// Return the existing instance if it already exists
			return PinnedListMgr.#instance;
		}
		// Initialize the instance if it doesn't exist
		PinnedListMgr.#instance = this;

		this.mapPin = new Map();
		this.listLoaded = false;
		this.arrChanges = [];
		this.broadcast = new BroadcastChannel("VHelper");
		this.broadcastObservers = [];

		logger.add("PINNEDMGR: Loading list");
		this.loadFromLocalStorage(); //Can't be awaited

		//Handle the reception of broadcasts:
		this.broadcast.addEventListener("message", async (ev) => {
			const data = await cryptoKeys.decryptToJSON(ev.data);
			if (data.type == undefined) return;

			if (data.type == "pinnedItem") {
				logger.add("Broadcast received: pinned item " + ev.data.asin);
				try {
					const item = new Item({
						asin: data.asin,
						queue: data.queue,
						title: data.title,
						img_url: data.thumbnail,
						is_parent_asin: data.is_parent_asin,
						enrollment_guid: data.enrollment_guid,
						is_pre_release: data.is_pre_release,
					});
					this.addItem(item, false, false);

					// Notify observers about the broadcast event
					this.broadcastObservers.forEach((observer) => {
						if (observer.onPinnedBroadcast) {
							observer.onPinnedBroadcast(item);
						}
					});
				} catch (error) {
					logger.add("PINNEDMGR: Failed to create Item from broadcast - " + error.message);
					console.error("[PinnedListMgr] Cannot create item from broadcast -", error.message, {
						source: "broadcast pinnedItem",
						broadcast_data: ev.data,
					});
				}
			}
			if (data.type == "unpinnedItem") {
				logger.add("Broadcast received: unpinned item " + data.asin);
				this.removeItem(data.asin, false, false);
				// Notify observers about the broadcast event
				this.broadcastObservers.forEach((observer) => {
					if (observer.onUnpinnedBroadcast) {
						observer.onUnpinnedBroadcast(data.asin);
					}
				});
			}
		});
	}

	async loadFromLocalStorage() {
		const data = await chrome.storage.local.get("pinnedItems");
		if (data.pinnedItems) {
			try {
				//Detect if the content is a string of JSON or an object
				if (typeof data.pinnedItems === "string") {
					this.mapPin = new Map(JSON.parse(data.pinnedItems));
				} else {
					this.mapPin = new Map(Object.entries(data.pinnedItems));
				}
			} catch (error) {
				// If JSON parsing fails assume legacy format and convert to new format
				// Once the migration period is over delete this section of code
				logger.add("Failed to parse pinnedItems as JSON, treating as array:");
				if (Array.isArray(data.pinnedItems)) {
					this.mapPin = data.pinnedItems.reduce((map, product) => {
						map.set(product.asin, {
							title: product.title,
							thumbnail: product.thumbnail,
							is_parent_asin: product.is_parent_asin,
							enrollment_guid: product.enrollment_guid,
							is_pre_release: product.is_pre_release ? true : false,
						});
						return map;
					}, new Map());
				} else {
					logger.add("Invalid data format for pinned items.  Creating new map.");
					this.mapPin = new Map(); // Initialize with an empty map if data is malformed
				}
			}
		} else {
			// No data found or empty pinnedItems, initialize an empty Map
			this.mapPin = new Map();
		}

		this.listLoaded = true;
		logger.add("PINNEDMGR: List loaded.");
	}

	async removeItem(asin, save = true, broadcast = true) {
		if (save) await this.loadFromLocalStorage(); //Load the list in case it was altered in a different tab

		this.mapPin.delete(asin);

		//The server may not be in sync with the local list, and will deal with duplicate.
		this.updateArrChange({ asin: asin, pinned: false });

		if (save) this.saveList();

		//Broadcast the change to other tabs
		if (broadcast) {
			this.broadcast.postMessage(await cryptoKeys.encryptJSON({ type: "unpinnedItem", asin: asin }));
		}
	}

	async addItem(item, save = true, broadcast = true) {
		if (!(item instanceof Item)) {
			throw new Error("item is not an instance of Item");
		}

		let { asin, queue, title, img_url, is_parent_asin, enrollment_guid, is_pre_release } = item.data;
		if (!queue) {
			queue = "encore"; //Not really a good fix but if there is no known queue, assume it's AI.
		}
		if (!asin || !title || !img_url || is_parent_asin == undefined || !enrollment_guid) {
			throw new Error("Invalid data");
		}

		if (save) await this.loadFromLocalStorage(); //Load the list in case it was altered in a different tab

		this.mapPin.set(asin, {
			date_added: Date.now(),
			title: title,
			queue: queue,
			thumbnail: img_url,
			is_parent_asin: is_parent_asin,
			enrollment_guid: enrollment_guid,
			is_pre_release: is_pre_release,
		});

		//The server may not be in sync with the local list, and will deal with duplicate.
		this.updateArrChange({
			asin: asin,
			pinned: true,
			queue: queue,
			title: title,
			thumbnail: img_url,
			is_parent_asin: is_parent_asin,
			enrollment_guid: enrollment_guid,
			is_pre_release: is_pre_release,
		});

		if (save) this.saveList();

		//Broadcast the change to other tabs
		if (broadcast) {
			this.broadcast.postMessage(
				await cryptoKeys.encryptJSON({
					type: "pinnedItem",
					asin: asin,
					queue: queue,
					title: title,
					thumbnail: img_url,
					is_parent_asin: is_parent_asin,
					enrollment_guid: enrollment_guid,
					is_pre_release: is_pre_release,
				})
			);
		}
	}

	async saveList(remoteSave = true) {
		let storableVal = Object.fromEntries(this.mapPin);

		if (isSafari()) {
			//Send instructions to the service worker to save the list to local storage
			chrome.runtime.sendMessage({ type: "saveToLocalStorage", key: "pinnedItems", value: storableVal });
		} else {
			//Save the list to local storage
			await chrome.storage.local.set({ pinnedItems: storableVal }, () => {
				if (chrome.runtime.lastError) {
					const error = chrome.runtime.lastError;
					if (error.message === "QUOTA_BYTES quota exceeded") {
						const message =
							typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage
								? chrome.i18n.getMessage("alertLocalStorageQuotaExceeded") ||
									"VHelper local storage quota exceeded! Hidden items will be trimmed to make space."
								: "VHelper local storage quota exceeded! Hidden items will be trimmed to make space.";
						alert(message);
						HiddenList.garbageCollection();
					} else {
						alert(
							(() => {
								if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
									const msg = chrome.i18n.getMessage("alertPinnedItemsSaveError", [
										e.name,
										e.message,
									]);
									if (msg) {
										return msg;
									}
								}
								return `VHelper encountered an error while trying to save your pinned items. Please report the following details: ${e.name}, ${e.message}`;
							})()
						);
						return;
					}
				}
			});
		}

		if (remoteSave && Settings.isPremiumUser(1) && Settings.get("pinnedTab.remote") && this.arrChanges.length > 0) {
			await this.notifyServerOfChangedItem();
			this.arrChanges = [];
		}
	}

	/**
	 * Send new items on the server to be added or removed from the changed list.
	 */
	async notifyServerOfChangedItem() {
		const content = {
			api_version: 5,
			app_version: env.data.appVersion,
			action: "save_pinned_list",
			country: i18n.getCountryCode(),
			uuid: Settings.get("general.uuid", false),
			cid: await env.getCID(),
			items: this.arrChanges,
		};
		const s = await cryptoKeys.signData(content);
		content.s = s;
		content.pk = await cryptoKeys.getExportedPublicKey();

		//Post an AJAX request to the 3rd party server, passing along the JSON array of all the products on the page
		fetch(env.getAPIUrl(), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		});
	}

	isPinned(asin) {
		if (asin == undefined) throw new Exception("Asin not defined");

		return this.mapPin.has(asin);
	}

	isChange(asin) {
		for (const id in this.arrChanges) {
			if (this.arrChanges[id].asin == asin) {
				return id;
			}
		}
		return false;
	}

	updateArrChange(obj) {
		let itemId = this.isChange(obj.asin);
		if (itemId == false) this.arrChanges.push(obj);
		else this.arrChanges[itemId] = obj;
	}

	async getList() {
		while (!this.listLoaded) {
			await new Promise((r) => setTimeout(r, 50));
		}
		return this.mapPin;
	}

	// Register an observer to be notified of broadcast events
	addBroadcastObserver(observer) {
		this.broadcastObservers.push(observer);
	}
}

export { PinnedListMgr };
