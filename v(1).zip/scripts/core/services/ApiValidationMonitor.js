import { redactObject, redactPageContext } from "/scripts/core/amazon/redact.js";

/**
 * @typedef {object} ApiValidationFailureRecord
 * @property {string} endpoint_id
 * @property {string} failure_kind
 * @property {string} page_context
 * @property {Record<string, unknown>} debug_json
 */

/** @type {Map<string, number>} */
const rateLimitMap = new Map();
const RATE_LIMIT_MS = 60 * 60 * 1000;

/** @type {ApiValidationFailureRecord[]} */
let pendingFailures = [];

/** @type {(() => Promise<void>) | null} */
let flushCallback = null;

/**
 * Register the function that flushes failures to the API.
 * @param {() => Promise<void>} fn
 */
export function setApiValidationFlushCallback(fn) {
	flushCallback = fn;
}

/**
 * @returns {ApiValidationFailureRecord[]}
 */
export function drainPendingApiValidationFailures() {
	const batch = pendingFailures.slice(0, 10);
	pendingFailures = pendingFailures.slice(batch.length);
	return batch;
}

/**
 * Reset rate-limit state (tests only).
 */
export function _resetApiValidationMonitorForTests() {
	rateLimitMap.clear();
	pendingFailures = [];
	flushCallback = null;
}

/**
 * @returns {string}
 */
function resolvePageContext() {
	try {
		if (typeof window !== "undefined" && window.location?.href) {
			return redactPageContext(window.location.href);
		}
	} catch {
		// ignore
	}
	return "unknown";
}

/**
 * @param {string} url
 * @returns {string}
 */
function redactApiUrl(url) {
	try {
		const absolute = url.startsWith("http")
			? url
			: `https://www.amazon.com${url.startsWith("/") ? url : `/${url}`}`;
		return redactPageContext(absolute);
	} catch {
		return redactPageContext(String(url || ""));
	}
}

/**
 * @param {import("/scripts/ui/components/OrderNowFailureReport.js").OrderNowFailureDebugReport} report
 * @returns {Record<string, unknown>}
 */
function buildDebugJson(report) {
	/** @type {Record<string, unknown>} */
	const debug = {
		step: report.step,
		failure_kind: report.failureKind,
		request: {
			method: report.request.method,
			url: redactApiUrl(report.request.url),
		},
	};

	if (report.request.referrer) {
		debug.request = {
			...debug.request,
			referrer: redactApiUrl(report.request.referrer),
		};
	}
	if (report.request.body !== undefined) {
		debug.request = {
			...debug.request,
			body: report.request.body,
		};
	}
	if (report.httpStatus) {
		debug.httpStatus = report.httpStatus;
	}
	if (report.vineError) {
		debug.vineError = report.vineError;
	}
	if (report.contextNote) {
		debug.contextNote = report.contextNote;
	}

	if (report.validation) {
		const v = report.validation;
		debug.validation = {
			path: v.path,
			message: v.message,
			expected: v.expected ?? null,
			actual: v.actual,
			expectationTemplate: v.expectationTemplate,
			receivedPayload: v.receivedPayload,
		};
	}

	if (report.rawResponseText != null) {
		debug.rawResponseText = String(report.rawResponseText).slice(0, 4000);
	}

	return redactObject(debug);
}

/**
 * @param {string} endpointId
 * @param {string} failureKind
 * @param {string} pageContext
 * @returns {boolean}
 */
function isRateLimited(endpointId, failureKind, pageContext) {
	const key = `${endpointId}::${failureKind}::${pageContext}`;
	const last = rateLimitMap.get(key);
	if (last && Date.now() - last < RATE_LIMIT_MS) {
		return true;
	}
	rateLimitMap.set(key, Date.now());
	return false;
}

/**
 * Queue an API response validation failure for server reporting.
 * @param {import("/scripts/ui/components/OrderNowFailureReport.js").OrderNowFailureDebugReport} report
 */
export function queueApiValidationFailure(report) {
	if (!report || report.failureKind !== "validation") {
		return;
	}

	const endpointId = String(report.step || "unknown").slice(0, 64);
	const failureKind = String(report.failureKind || "validation").slice(0, 32);
	const pageContext = resolvePageContext();

	if (isRateLimited(endpointId, failureKind, pageContext)) {
		return;
	}

	pendingFailures.push({
		endpoint_id: endpointId,
		failure_kind: failureKind,
		page_context: pageContext,
		debug_json: buildDebugJson(report),
	});

	if (flushCallback) {
		flushCallback().catch(() => {});
	}
}
