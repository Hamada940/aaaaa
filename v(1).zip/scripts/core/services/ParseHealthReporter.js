import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { Internationalization } from "/scripts/core/services/Internationalization.js";
import { ChromeStorageAdapter } from "/scripts/infrastructure/StorageAdapter.js";
import { DeviceMgr } from "/scripts/core/services/DeviceMgr.js";
import {
	drainPendingFailures,
	setParseFailureNotifyCallback,
	setParseHealthFlushCallback,
} from "/scripts/core/amazon/ParseMonitor.js";
import { redactObject } from "/scripts/core/amazon/redact.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";
import { ScreenNotification, ScreenNotifier } from "/scripts/ui/components/ScreenNotifier.js";

/**
 * @typedef {object} ParseFailureRecord
 * @property {string} parser_id
 * @property {string} error_type
 * @property {string} selector_bundle_version
 * @property {string} page_context
 * @property {Record<string, unknown>} debug_json
 */

const storage = new ChromeStorageAdapter("local");
const cryptoKeys = new CryptoKeys();
const i18n = new Internationalization();

let initialized = false;

const PARSE_FAILURE_TOAST_LIFESPAN_SEC = 60;

/** @type {InstanceType<typeof ScreenNotifier> | null} */
let notificationsMgr = null;

const PARSE_FAILURE_CONTENT_FALLBACK =
	"VHelper has encountered unexpected content structure and was not able to properly extract data from the page. This can happen if Vine update their page. A bug report was submitted. If this issue makes Vine unusable, you may want to disable VH temporarily while we're working on a fix. You can check the browser's debugger console for details.";

function getNotificationsMgr() {
	if (typeof document === "undefined") {
		return null;
	}
	if (!notificationsMgr) {
		notificationsMgr = new ScreenNotifier();
	}
	return notificationsMgr;
}

/**
 * Show a long-lived toaster when page content could not be parsed.
 */
export function showParseFailureToaster() {
	const mgr = getNotificationsMgr();
	if (!mgr) {
		return;
	}

	const note = new ScreenNotification({
		title: getMessage("vhParseFailureTitle", "Unable to extract page data"),
		content: getMessage("vhParseFailureContent", PARSE_FAILURE_CONTENT_FALLBACK),
		lifespan: PARSE_FAILURE_TOAST_LIFESPAN_SEC,
	});

	mgr.pushNotification(note).catch((err) => {
		console.warn("[ParseHealth] Toaster failed:", err);
	});
}

function resolveApiUrl(settingsMgr) {
	const override = settingsMgr.get("general.apiUrl", false);
	if (override) {
		return override;
	}
	return i18n.getAPIUrl();
}

/**
 * @param {string} cid
 * @param {string} deviceName
 */
async function computeClientHash(cid, deviceName) {
	const data = new TextEncoder().encode(`${cid}:${deviceName}`);
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	return Array.from(new Uint8Array(hashBuffer))
		.map((b) => b.toString(16).padStart(2, "0"))
		.join("");
}

/**
 * @param {{ settingsMgr?: SettingsMgr, env?: import("./Environment.js").Environment }} [deps]
 */
async function buildSignedPayload(deps = {}) {
	const settingsMgr = deps.settingsMgr ?? new SettingsMgr();
	await settingsMgr.waitForLoad();
	await cryptoKeys.waitForLoad();

	const uuid = settingsMgr.get("general.uuid", false);
	if (!uuid) {
		return { ok: false, reason: "missing uuid" };
	}

	let cid = settingsMgr.get("general.cid", false);
	if (deps.env && typeof deps.env.getCID === "function") {
		try {
			cid = await deps.env.getCID();
		} catch {
			// fall back
		}
	}
	if (!cid) {
		return { ok: false, reason: "missing cid" };
	}

	const deviceName = settingsMgr.get("general.deviceName", false);
	if (!deviceName) {
		return { ok: false, reason: "missing deviceName" };
	}

	const countryCode = settingsMgr.get("general.country", false) || i18n.getCountryCode();
	if (!countryCode) {
		return { ok: false, reason: "missing country" };
	}
	i18n.setCountryCode(countryCode);

	const failures = drainPendingFailures();
	if (!failures.length) {
		return { ok: false, reason: "empty" };
	}

	const clientHash = await computeClientHash(cid, deviceName);
	const appVersion = chrome.runtime.getManifest().version;
	const fid = settingsMgr.get("general.fingerprint.id", false);

	const content = {
		api_version: 5,
		app_version: appVersion,
		action: "report_parse_failures",
		country: countryCode,
		uuid,
		cid,
		fid: fid || null,
		client_hash: clientHash,
		failures: failures.map((f) => redactObject(f)),
	};

	content.s = await cryptoKeys.signData(content);
	content.pk = await cryptoKeys.getExportedPublicKey();

	return { ok: true, content };
}

/**
 * Flush queued parse failures to the API.
 * @param {{ settingsMgr?: SettingsMgr, env?: import("./Environment.js").Environment }} [deps]
 */
export async function flushParseFailures(deps = {}) {
	try {
		const built = await buildSignedPayload(deps);
		if (!built.ok) {
			return false;
		}

		const settingsMgr = deps.settingsMgr ?? new SettingsMgr();
		await settingsMgr.waitForLoad();

		const response = await fetch(resolveApiUrl(settingsMgr), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(built.content),
		});

		if (!response.ok) {
			console.warn("[ParseHealth] HTTP", response.status);
			return false;
		}

		const data = await response.json();
		if (data.error) {
			console.warn("[ParseHealth]", data.error);
			return false;
		}

		return true;
	} catch (err) {
		console.warn("[ParseHealth] Flush failed:", err);
		return false;
	}
}

/**
 * Wire ParseMonitor to auto-flush on new failures.
 */
export function initParseHealthReporter() {
	if (initialized) {
		return;
	}
	initialized = true;
	setParseHealthFlushCallback(() => flushParseFailures());
	setParseFailureNotifyCallback(() => showParseFailureToaster());
}
