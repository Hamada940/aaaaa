import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { Internationalization } from "/scripts/core/services/Internationalization.js";
import { DeviceMgr } from "/scripts/core/services/DeviceMgr.js";
import {
	drainPendingApiValidationFailures,
	setApiValidationFlushCallback,
} from "/scripts/core/services/ApiValidationMonitor.js";
import { redactObject } from "/scripts/core/amazon/redact.js";

const cryptoKeys = new CryptoKeys();
const i18n = new Internationalization();

let initialized = false;

function resolveApiUrl(settingsMgr) {
	const override = settingsMgr.get("general.apiUrl", false);
	if (override) {
		return override;
	}
	return i18n.getAPIUrl();
}

/**
 * @param {string} cid
 * @param {string} deviceName
 */
async function computeClientHash(cid, deviceName) {
	const data = new TextEncoder().encode(`${cid}:${deviceName}`);
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	return Array.from(new Uint8Array(hashBuffer))
		.map((b) => b.toString(16).padStart(2, "0"))
		.join("");
}

/**
 * @param {{ settingsMgr?: SettingsMgr, env?: import("./Environment.js").Environment }} [deps]
 */
async function buildSignedPayload(deps = {}) {
	const settingsMgr = deps.settingsMgr ?? new SettingsMgr();
	await settingsMgr.waitForLoad();
	await cryptoKeys.waitForLoad();

	const uuid = settingsMgr.get("general.uuid", false);
	if (!uuid) {
		return { ok: false, reason: "missing uuid" };
	}

	let cid = settingsMgr.get("general.cid", false);
	if (deps.env && typeof deps.env.getCID === "function") {
		try {
			cid = await deps.env.getCID();
		} catch {
			// fall back
		}
	}
	if (!cid) {
		return { ok: false, reason: "missing cid" };
	}

	const deviceName = settingsMgr.get("general.deviceName", false);
	if (!deviceName) {
		return { ok: false, reason: "missing deviceName" };
	}

	const countryCode = settingsMgr.get("general.country", false) || i18n.getCountryCode();
	if (!countryCode) {
		return { ok: false, reason: "missing country" };
	}
	i18n.setCountryCode(countryCode);

	const failures = drainPendingApiValidationFailures();
	if (!failures.length) {
		return { ok: false, reason: "empty" };
	}

	const clientHash = await computeClientHash(cid, deviceName);
	const appVersion = chrome.runtime.getManifest().version;
	const fid = settingsMgr.get("general.fingerprint.id", false);

	const content = {
		api_version: 5,
		app_version: appVersion,
		action: "report_api_validation_failures",
		country: countryCode,
		uuid,
		cid,
		fid: fid || null,
		client_hash: clientHash,
		failures: failures.map((f) => redactObject(f)),
	};

	content.s = await cryptoKeys.signData(content);
	content.pk = await cryptoKeys.getExportedPublicKey();

	return { ok: true, content };
}

/**
 * Flush queued API validation failures to the VH server.
 * @param {{ settingsMgr?: SettingsMgr, env?: import("./Environment.js").Environment }} [deps]
 */
export async function flushApiValidationFailures(deps = {}) {
	try {
		const built = await buildSignedPayload(deps);
		if (!built.ok) {
			return false;
		}

		const settingsMgr = deps.settingsMgr ?? new SettingsMgr();
		await settingsMgr.waitForLoad();

		const response = await fetch(resolveApiUrl(settingsMgr), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(built.content),
		});

		if (!response.ok) {
			console.warn("[ApiValidation] HTTP", response.status);
			return false;
		}

		const data = await response.json();
		if (data.error) {
			console.warn("[ApiValidation]", data.error);
			return false;
		}

		return true;
	} catch (err) {
		console.warn("[ApiValidation] Flush failed:", err);
		return false;
	}
}

/**
 * Wire ApiValidationMonitor to auto-flush on new failures.
 */
export function initApiValidationReporter() {
	if (initialized) {
		return;
	}
	initialized = true;
	setApiValidationFlushCallback(() => flushApiValidationFailures());
}
