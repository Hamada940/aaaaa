/*global chrome*/

/** Prefix for settings values that reference a stored custom sound. */
export const CUSTOM_SOUND_PREFIX = "custom:";

/** Select option value that opens the file picker. */
export const UPLOAD_OPTION_VALUE = "__custom_upload__";

/** chrome.storage.local key for the sound library. */
export const STORAGE_KEY = "customSounds";

/** chrome.storage.local quota (bytes). */
export const LOCAL_STORAGE_QUOTA_BYTES = 10 * 1024 * 1024;

const ACCEPTED_MIME_PREFIX = "audio/";

/** @type {Record<string, CustomSoundEntry>|null} */
let cachedLibrary = null;

/**
 * @typedef {Object} CustomSoundEntry
 * @property {string} id
 * @property {string} hash
 * @property {string} name
 * @property {string} mimeType
 * @property {string} data
 * @property {number} sizeBytes
 */

export function isCustomSoundValue(value) {
	return typeof value === "string" && value.startsWith(CUSTOM_SOUND_PREFIX);
}

export function getCustomSoundId(value) {
	if (!isCustomSoundValue(value)) {
		return null;
	}
	return value.slice(CUSTOM_SOUND_PREFIX.length);
}

export function bytesToSize(bytes, decimals = 2) {
	if (!Number(bytes)) {
		return "0 Bytes";
	}
	const kbToBytes = 1024;
	const dm = decimals < 0 ? 0 : decimals;
	const sizes = ["Bytes", "KB", "MB", "GB"];
	const index = Math.floor(Math.log(bytes) / Math.log(kbToBytes));
	return `${parseFloat((bytes / Math.pow(kbToBytes, index)).toFixed(dm))} ${sizes[index]}`;
}

export async function getStorageBytesUsed() {
	return new Promise((resolve, reject) => {
		try {
			chrome.storage.local.getBytesInUse(null, (bytes) => {
				if (chrome.runtime.lastError) {
					reject(new Error(chrome.runtime.lastError.message));
				} else {
					resolve(bytes);
				}
			});
		} catch {
			chrome.storage.local.get(null, (data) => {
				if (chrome.runtime.lastError) {
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				try {
					resolve(JSON.stringify(data).length * 2);
				} catch {
					resolve(0);
				}
			});
		}
	});
}

export function invalidateLibraryCache() {
	cachedLibrary = null;
}

export async function loadLibrary() {
	if (cachedLibrary) {
		return cachedLibrary;
	}
	const data = await new Promise((resolve, reject) => {
		chrome.storage.local.get(STORAGE_KEY, (result) => {
			if (chrome.runtime.lastError) {
				reject(new Error(chrome.runtime.lastError.message));
			} else {
				resolve(result[STORAGE_KEY] || {});
			}
		});
	});
	cachedLibrary = data;
	return cachedLibrary;
}

async function saveLibrary(library) {
	await new Promise((resolve, reject) => {
		chrome.storage.local.set({ [STORAGE_KEY]: library }, () => {
			if (chrome.runtime.lastError) {
				reject(new Error(chrome.runtime.lastError.message));
			} else {
				resolve();
			}
		});
	});
	cachedLibrary = library;
}

function findEntryByHash(library, hash) {
	return Object.values(library).find((entry) => entry.hash === hash) || null;
}

async function hashFile(file) {
	const rawBuffer = await file.arrayBuffer();
	const bytes = new Uint8Array(rawBuffer);
	const digest = await crypto.subtle.digest("SHA-256", bytes);
	const hash = Array.from(new Uint8Array(digest))
		.map((b) => b.toString(16).padStart(2, "0"))
		.join("");
	const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
	return { hash, buffer };
}

function idFromHash(hash) {
	return hash.slice(0, 16);
}

function arrayBufferToBase64(buffer) {
	const bytes = new Uint8Array(buffer);
	let binary = "";
	for (let i = 0; i < bytes.length; i++) {
		binary += String.fromCharCode(bytes[i]);
	}
	return btoa(binary);
}

/**
 * Read a user-selected audio file and check whether it already exists in the library.
 * @param {File} file
 * @returns {Promise<{existingId: string|null, hash: string, name: string, mimeType: string, sizeBytes: number, dataBase64: string, currentUsageBytes: number}>}
 */
export async function analyzeSoundFile(file) {
	if (!file || !file.type.startsWith(ACCEPTED_MIME_PREFIX)) {
		throw new Error("INVALID_TYPE");
	}

	const { hash, buffer } = await hashFile(file);
	const library = await loadLibrary();
	const existing = findEntryByHash(library, hash);
	const currentUsageBytes = await getStorageBytesUsed();

	return {
		existingId: existing ? existing.id : null,
		hash,
		name: file.name,
		mimeType: file.type || "audio/mpeg",
		sizeBytes: file.size,
		dataBase64: arrayBufferToBase64(buffer),
		currentUsageBytes,
	};
}

/**
 * Store a new custom sound or return an existing id when the same file was uploaded before.
 * @param {Awaited<ReturnType<typeof analyzeSoundFile>>} analyzed
 * @returns {Promise<{id: string, reused: boolean, sizeBytesAdded: number}>}
 */
export async function importAnalyzedSound(analyzed) {
	if (analyzed.existingId) {
		return { id: analyzed.existingId, reused: true, sizeBytesAdded: 0 };
	}

	const availableBytes = LOCAL_STORAGE_QUOTA_BYTES - analyzed.currentUsageBytes;
	if (analyzed.sizeBytes > availableBytes) {
		throw new Error("QUOTA_EXCEEDED");
	}

	const library = await loadLibrary();
	const id = idFromHash(analyzed.hash);
	library[id] = {
		id,
		hash: analyzed.hash,
		name: analyzed.name,
		mimeType: analyzed.mimeType,
		data: analyzed.dataBase64,
		sizeBytes: analyzed.sizeBytes,
	};

	try {
		await saveLibrary(library);
	} catch (error) {
		if (
			error?.name === "QuotaExceededError" ||
			error?.message?.includes("quota exceeded") ||
			error?.message?.includes("QUOTA_BYTES")
		) {
			throw new Error("QUOTA_EXCEEDED");
		}
		throw error;
	}

	return { id, reused: false, sizeBytesAdded: analyzed.sizeBytes };
}

function base64ToBlob(base64, mimeType) {
	const binary = atob(base64);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) {
		bytes[i] = binary.charCodeAt(i);
	}
	return new Blob([bytes], { type: mimeType });
}

/**
 * @param {Record<string, CustomSoundEntry>} library
 * @param {string} soundValue
 * @returns {string|null}
 */
export function createPlaybackObjectUrl(library, soundValue) {
	if (!soundValue || soundValue === "0") {
		return null;
	}
	if (!isCustomSoundValue(soundValue)) {
		return null;
	}
	const id = getCustomSoundId(soundValue);
	const entry = library[id];
	if (!entry) {
		return null;
	}
	return URL.createObjectURL(base64ToBlob(entry.data, entry.mimeType));
}

/**
 * @param {Record<string, CustomSoundEntry>} library
 * @param {string} soundValue
 * @returns {string|null}
 * @deprecated Use createPlaybackObjectUrl — data URLs are blocked by extension CSP.
 */
export function getPlaybackUrl(library, soundValue) {
	return createPlaybackObjectUrl(library, soundValue);
}

export const NOTIFICATION_SOUND_SETTING_KEYS = [
	"notification.screen.regular.sound",
	"notification.monitor.regular.sound",
	"notification.monitor.zeroETV.sound",
	"notification.monitor.rfy.sound",
];

export function customSoundValue(id) {
	return CUSTOM_SOUND_PREFIX + id;
}

/**
 * @param {string} soundValue
 * @param {Object} settings
 * @returns {Array<{type: string, key?: string, id?: string, name?: string}>}
 */
export function findCustomSoundReferences(soundValue, settings) {
	const references = [];

	for (const key of NOTIFICATION_SOUND_SETTING_KEYS) {
		const value = key.split(".").reduce((obj, part) => obj?.[part], settings);
		if (value === soundValue) {
			references.push({ type: "setting", key });
		}
	}

	for (const group of settings?.general?.keywordGroups || []) {
		if (group.monitorSound === soundValue) {
			references.push({
				type: "keywordGroup",
				id: group.id,
				name: group.name || group.id,
			});
		}
	}

	return references;
}

/**
 * @param {string} id
 * @returns {Promise<boolean>}
 */
export async function deleteCustomSoundById(id) {
	const library = await loadLibrary();
	if (!library[id]) {
		return false;
	}
	delete library[id];
	await saveLibrary(library);
	return true;
}

export function listCustomSounds(library) {
	return Object.values(library).sort((a, b) => a.name.localeCompare(b.name));
}
