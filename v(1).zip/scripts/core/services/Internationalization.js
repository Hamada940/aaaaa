/**
 * Chrome extension i18n helpers (message keys from _locales/.../messages.json).
 * Supports locale override for the options page via initLocaleOverride().
 */
const I18N_OVERRIDE_KEY = "__VH_I18N_OVERRIDE__";

function applySubstitutions(msg, substitutions) {
	if (!msg || substitutions == null) return msg || "";
	const subs = Array.isArray(substitutions) ? substitutions : [substitutions];
	for (let i = 0; i < subs.length; i++) {
		const n = i + 1;
		const value = String(subs[i]);

		// Support both Chrome placeholder styles:
		// - "$1$" (used in many of our locale strings + override path)
		// - "$1"  (Chrome i18n also supports this form, e.g. "Wait $1s")
		if (msg.includes(`$${n}$`)) {
			msg = msg.replace(new RegExp("\\$" + n + "\\$", "g"), value);
		} else {
			msg = msg.replace(new RegExp("\\$" + n + "(?!\\d)", "g"), value);
		}
	}
	return msg;
}

function escapeChromeSubstitutions(substitutions) {
	if (substitutions == null) return undefined;
	const subs = Array.isArray(substitutions) ? substitutions : [substitutions];
	return subs.map((s) => String(s).replace(/\$/g, "$$$$"));
}

function getChromeMessage(key, substitutions) {
	const override = typeof window !== "undefined" && window[I18N_OVERRIDE_KEY];
	let msg = "";

	// 1) Prefer explicit locale override (used on options / template pages)
	if (override && override.messages && override.messages[key]) {
		const entry = override.messages[key];
		msg = typeof entry === "string" ? entry : (entry?.message ?? "");
		return applySubstitutions(msg, substitutions);
	}

	if (typeof chrome !== "undefined" && chrome.i18n && typeof chrome.i18n.getMessage === "function") {
		try {
			// 2) Prefer native substitution when supported (Chrome/Firefox).
			//    Escape `$` in values so amounts like "$3.10" are not parsed as placeholders.
			const template = chrome.i18n.getMessage(key) || "";
			msg = chrome.i18n.getMessage(key, escapeChromeSubstitutions(substitutions)) || template;
			// Orion and similar browsers may ignore substitutions; fill placeholders ourselves.
			if (/\$\d+\$/.test(msg) || (substitutions != null && msg === template)) {
				msg = applySubstitutions(msg, substitutions);
			}
		} catch {
			// Extension context invalidated
		}
	}

	return msg || "";
}

/**
 * Initialize locale override for the options page. Call after Settings.waitForLoad() and before rendering.
 * @param {string} [locale] - "en", "fr", or empty to use browser language
 * @returns {Promise<void>}
 */
export async function initLocaleOverride(locale) {
	if (typeof window === "undefined") return;
	const normalized = locale != null && String(locale).trim() !== "" ? String(locale).trim() : "";
	if (normalized === "") {
		window[I18N_OVERRIDE_KEY] = null;
		return;
	}
	const url = chrome.runtime.getURL("_locales/" + normalized + "/messages.json");
	try {
		const res = await fetch(url);
		if (!res.ok) {
			console.warn("[VH i18n] initLocaleOverride: fetch failed for", url, "status", res.status);
			window[I18N_OVERRIDE_KEY] = null;
			return;
		}
		const json = await res.json();
		const messages = {};
		for (const [k, v] of Object.entries(json)) {
			if (v && typeof v.message === "string") {
				messages[k] = v;
			}
		}
		window[I18N_OVERRIDE_KEY] = { locale: normalized, messages };
	} catch (e) {
		console.warn("[VH i18n] initLocaleOverride: failed to load locale", normalized, e);
		window[I18N_OVERRIDE_KEY] = null;
	}
}

/**
 * @param {string} key - Message key from _locales/.../messages.json
 * @param {string} defaultMessage - Fallback when key is missing or i18n unavailable
 * @param {string|string[]} [substitutions] - Optional substitution(s) for placeholders ($1$, $2$, ...)
 * @returns {string}
 */
export function getMessageOrDefault(key, defaultMessage, substitutions) {
	const msg = getChromeMessage(key, substitutions);
	return msg !== "" ? msg : applySubstitutions(defaultMessage, substitutions);
}

/**
 * Get message for use by Template.js (uses override when set).
 * @param {string} messageName - Message key
 * @returns {string}
 */
export function getMessageForTemplate(messageName) {
	return getChromeMessage(messageName);
}

/**
 * Chrome i18n with fallback for script contexts (content scripts, notification monitor).
 * Uses override when set (e.g. from options page); otherwise chrome.i18n.getMessage.
 * @param {string} key - Message key
 * @param {string} [fallback=""] - Fallback when translation missing or i18n unavailable
 * @param {string[]} [substitutions] - Optional substitution list for placeholders
 * @returns {string}
 */
export function getMessage(key, fallback = "", substitutions) {
	const msg = getChromeMessage(key, substitutions);
	return msg !== "" ? msg : applySubstitutions(fallback, substitutions);
}

// --- Vine/Amazon locale (domain, country, currency) ---

class Internationalization {
	static #instance = null;

	#domainTLD;
	#countryCode;
	#locale;
	#currency;

	constructor() {
		if (Internationalization.#instance) {
			// Return the existing instance if it already exists
			return Internationalization.#instance;
		}
		// Initialize the instance if it doesn't exist
		Internationalization.#instance = this;

		this.#domainTLD = null;
		this.#countryCode = null;
		this.#locale = null;
		this.#currency = null;

		//Try to set the locale if the context allows for it.
		//ie.: extensions pages won't work.
		if (typeof window !== "undefined") {
			const currentUrl = window.location.href;
			const regex = /^.+?amazon\.([a-z.]+).*\/vine\/.*$/;
			const arrMatches = currentUrl.match(regex);
			if (arrMatches != null) {
				const domainTLD = arrMatches[1];
				this.setDomainTLD(domainTLD);
			}
		}
	}

	setDomainTLD(domainTLD) {
		if (!this.#doesDomainTLDExist(domainTLD)) {
			throw Error(domainTLD + " is not a valid/supported domainTLD.");
		}

		const vineLocales = this.#getLocales();
		this.#domainTLD = domainTLD;
		this.#countryCode = this.#getCountryCodeFromDomain(domainTLD);
		this.#locale = vineLocales[this.#countryCode].locale;
		this.#currency = vineLocales[this.#countryCode].currency;
	}

	setCountryCode(countryCode) {
		if (!this.#doesCountryCodeExist(countryCode)) {
			throw Error(countryCode + " is not a valid/supported country code.");
		}

		const vineLocales = this.#getLocales();
		this.#domainTLD = vineLocales[countryCode].domain;
		this.#countryCode = countryCode;
		this.#locale = vineLocales[this.#countryCode].locale;
		this.#currency = vineLocales[this.#countryCode].currency;
	}

	#doesCountryCodeExist(countryCode) {
		const locales = this.#getLocales();
		return Object.prototype.hasOwnProperty.call(locales, countryCode);
	}

	#doesDomainTLDExist(domainTLD) {
		const locales = this.#getLocales();
		// Iterate through the locales and check if any of the domain properties match domainTLD
		return Object.values(locales).some((locale) => locale.domain === domainTLD);
	}

	#getCountryCodeFromDomain(domainTLD) {
		const locales = this.#getLocales(); // Get the locales object

		// Iterate through the locales and find the country code that matches the domainTLD
		for (let countryCode in locales) {
			if (locales[countryCode].domain === domainTLD) {
				return countryCode; // Return the country code if domainTLD matches
			}
		}

		return null; // Return null if no match is found
	}
	#getLocales() {
		return {
			ca: { locale: "en-CA", currency: "CAD", domain: "ca" },
			com: { locale: "en-US", currency: "USD", domain: "com" },
			uk: { locale: "en-GB", currency: "GBP", domain: "co.uk" },
			jp: { locale: "ja-JP", currency: "JPY", domain: "co.jp" },
			de: { locale: "de-DE", currency: "EUR", domain: "de" },
			fr: { locale: "fr-FR", currency: "EUR", domain: "fr" },
			es: { locale: "es-ES", currency: "EUR", domain: "es" },
			it: { locale: "it-IT", currency: "EUR", domain: "it" },
			au: { locale: "en-AU", currency: "AUD", domain: "com.au" },
			br: { locale: "pt-BR", currency: "BRL", domain: "com.br" },
			mx: { locale: "es-MX", currency: "MXN", domain: "com.mx" },
			sg: { locale: "en-SG", currency: "SGD", domain: "sg" },
		};
	}

	getDomainTLD() {
		return this.#domainTLD;
	}

	getCountryCode() {
		return this.#countryCode;
	}

	getLocale() {
		return this.#locale;
	}

	getCurrency() {
		return this.#currency;
	}
}

export { Internationalization };
