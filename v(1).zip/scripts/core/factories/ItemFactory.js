import { Item } from "../models/Item.js";
import { parseTileElement, queryPageTiles, VINE_GRID } from "/scripts/core/amazon/index.js";

/**
 * Factory class for creating Item instances from DOM elements
 */
class ItemFactory {
	/**
	 * Create an Item instance from a DOM element (tile)
	 * @param {HTMLElement} tileDOM - The DOM element representing a Vine tile
	 * @returns {Item|null} - The created Item instance, or null if extraction fails
	 */
	static createFromDOM(tileDOM) {
		try {
			const parsed = parseTileElement(tileDOM);
			if (!parsed) {
				console.warn("[ItemFactory] No ASIN input found in tile DOM");
				return null;
			}

			const itemData = {
				asin: parsed.asin,
				title: parsed.title,
				img_url: parsed.img_url,
				is_parent_asin: parsed.is_parent_asin,
				is_pre_release: parsed.is_pre_release,
				enrollment_guid: parsed.enrollment_guid,
				queue: parsed.queue,
				see_details_button_dataset: parsed.see_details_button_dataset,
			};

			const item = new Item(itemData);

			if (parsed.recommendationId) {
				item._originalRecommendationId = parsed.recommendationId;
			}
			if (parsed.recommendationType) {
				item._originalRecommendationType = parsed.recommendationType;
			}

			return item;
		} catch (error) {
			console.error("[ItemFactory] Error creating Item from DOM:", error);
			return null;
		}
	}

	/**
	 * Extract all Items from the page
	 * @param {string} selector - CSS selector for tiles (default: ".vvp-item-tile:not(.pinned)")
	 * @returns {Array<Item>} - Array of Item instances
	 */
	static extractAllFromPage(selector = VINE_GRID.TILE_NOT_PINNED) {
		const tileElements = queryPageTiles(selector);
		const items = [];

		for (const tileDOM of tileElements) {
			const item = ItemFactory.createFromDOM(tileDOM);
			if (item) {
				items.push(item);
			}
		}

		return items;
	}
}

export { ItemFactory };
