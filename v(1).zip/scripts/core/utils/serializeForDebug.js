/**
 * Serialize a value for debug display (full depth, no truncation).
 * @param {unknown} value
 * @param {number} [indent=2]
 * @returns {string}
 */
export function serializeForDebug(value, indent = 2) {
	const seen = new WeakSet();
	try {
		return JSON.stringify(
			value,
			(_key, val) => {
				if (val !== null && typeof val === "object") {
					if (seen.has(val)) {
						return "[Circular]";
					}
					seen.add(val);
				}
				if (val === undefined) {
					return "[undefined]";
				}
				if (typeof val === "bigint") {
					return String(val);
				}
				return val;
			},
			indent
		);
	} catch (e) {
		return `[Unserializable: ${(e && /** @type {Error} */ (e).message) || String(e)}]`;
	}
}
