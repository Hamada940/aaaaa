/**
 * @fileoverview KeywordGroupsManager - Utility functions for managing keyword groups
 *
 * This module provides functions for managing keyword groups, including:
 * - Creating, updating, and deleting groups
 * - Managing group order
 * - Validating group data
 * - Converting between old and new keyword formats
 */

/**
 * Validates a keyword group object
 * @param {Object} group - The group object to validate
 * @returns {boolean} True if the group is valid
 */
export function isValidGroup(group) {
	if (!group || typeof group !== "object") {
		return false;
	}

	// Required fields
	if (!group.id || typeof group.id !== "string") {
		return false;
	}

	if (!group.name || typeof group.name !== "string" || group.name.trim() === "") {
		return false;
	}

	if (!group.type || !["highlight", "hide", "blur"].includes(group.type)) {
		return false;
	}

	if (typeof group.order !== "number" || group.order < 0) {
		return false;
	}

	// Keywords array is optional but must be an array if present
	if (group.keywords !== undefined && !Array.isArray(group.keywords)) {
		return false;
	}

	// Enabled is optional but must be boolean if present
	if (group.enabled !== undefined && typeof group.enabled !== "boolean") {
		return false;
	}

	// collapsed is optional but must be boolean if present
	if (group.collapsed !== undefined && typeof group.collapsed !== "boolean") {
		return false;
	}

	// listingColor is optional but must be a string (hex color) or null if present
	if (group.listingColor !== undefined && group.listingColor !== null && typeof group.listingColor !== "string") {
		return false;
	}

	// monitorColor is optional but must be a string (hex color) or null if present
	if (group.monitorColor !== undefined && group.monitorColor !== null && typeof group.monitorColor !== "string") {
		return false;
	}

	// monitorSound is optional but must be a string or null if present
	if (group.monitorSound !== undefined && group.monitorSound !== null && typeof group.monitorSound !== "string") {
		return false;
	}

	// monitorVolume is optional but must be a number in [0, 1] if present
	if (
		group.monitorVolume !== undefined &&
		(typeof group.monitorVolume !== "number" || group.monitorVolume < 0 || group.monitorVolume > 1)
	) {
		return false;
	}

	if (group.communityLink !== undefined) {
		if (!isValidCommunityLink(group.communityLink)) {
			return false;
		}
	}

	return true;
}

/**
 * Normalizes a community link object (coerces numeric fields from storage).
 * @param {Object} link
 * @returns {{ listId: number, name: string, revision: number } | null}
 */
export function normalizeCommunityLink(link) {
	if (!link || typeof link !== "object") {
		return null;
	}
	const listId = Number(link.listId);
	const revision = link.revision === undefined || link.revision === null ? 0 : Number(link.revision);
	const name = typeof link.name === "string" ? link.name.trim() : "";
	if (!Number.isFinite(listId) || listId <= 0 || !name) {
		return null;
	}
	if (!Number.isFinite(revision) || revision < 0) {
		return null;
	}
	return { listId, name, revision };
}

/**
 * Validates a community link object (no user identifiers stored client-side).
 * @param {Object} link
 * @returns {boolean}
 */
export function isValidCommunityLink(link) {
	return normalizeCommunityLink(link) !== null;
}

/**
 * Whether a keyword group should render collapsed in settings.
 * Uses the group's collapsed property when set; otherwise community-linked groups
 * default to collapsed and all other groups default to expanded.
 * @param {Object} group
 * @returns {boolean}
 */
export function isGroupCollapsed(group) {
	if (group?.collapsed === true) {
		return true;
	}
	if (group?.collapsed === false) {
		return false;
	}
	return normalizeCommunityLink(group?.communityLink) !== null;
}

/**
 * Validates a keyword object
 * @param {Object} keyword - The keyword object to validate
 * @returns {boolean} True if the keyword is valid
 */
export function isValidKeyword(keyword) {
	if (!keyword || typeof keyword !== "object") {
		return false;
	}

	// At least one field must be present
	if (!keyword.contains && !keyword.without && !keyword.etv_min && !keyword.etv_max) {
		return false;
	}

	return true;
}

/**
 * Creates a new keyword group
 * @param {string} name - The group name
 * @param {string} type - The group type (highlight, hide, or blur)
 * @param {number} order - The group order
 * @returns {Object} A new keyword group object
 */
export function createGroup(name, type, order = 0) {
	const id = `group_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
	return {
		id,
		name: name.trim(),
		type,
		order,
		keywords: [],
		enabled: true, // Default to enabled
	};
}

/**
 * Gets all groups from settings, sorted by order
 * @param {Object} settingsManager - The settings manager instance
 * @returns {Array<Object>} Array of groups sorted by order
 */
export async function getGroups(settingsManager) {
	await settingsManager.waitForLoad();
	const groups = settingsManager.get("general.keywordGroups") || [];
	// Groups are stored with explicit fields set by creation / migration / import.
	// Call sites treat `enabled === false` as disabled and assume "enabled" when undefined.
	// Optional properties (colors, sound) are handled explicitly where needed.
	return [...groups].sort((a, b) => a.order - b.order);
}

/**
 * Gets a single group by id
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} groupId - The group ID
 * @returns {Promise<Object|null>} The group or null if not found
 */
export async function getGroupById(settingsManager, groupId) {
	const groups = await getGroups(settingsManager);
	return groups.find((g) => g.id === groupId) ?? null;
}

/**
 * Gets groups of a specific type, sorted by order
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} type - The group type (highlight, hide, or blur)
 * @returns {Array<Object>} Array of groups of the specified type, sorted by order
 */
export async function getGroupsByType(settingsManager, type) {
	const allGroups = await getGroups(settingsManager);
	return allGroups.filter((group) => group.type === type);
}

/**
 * Saves groups to settings
 * @param {Object} settingsManager - The settings manager instance
 * @param {Array<Object>} groups - Array of groups to save
 * @returns {Promise<void>}
 */
export async function saveGroups(settingsManager, groups) {
	// Validate all groups before saving
	const validGroups = groups.filter((group) => isValidGroup(group));

	// Remove undefined properties before saving to preserve the distinction between
	// "never set" (undefined/missing) and "explicitly disabled" (null)
	// This ensures migration can detect undefined properties on next load
	const cleanedGroups = validGroups.map((group) => {
		const cleaned = { ...group };
		// Remove undefined properties (they will be missing from saved JSON)
		// This preserves undefined vs null distinction for migration
		if (cleaned.listingColor === undefined) delete cleaned.listingColor;
		if (cleaned.monitorColor === undefined) delete cleaned.monitorColor;
		if (cleaned.monitorSound === undefined) delete cleaned.monitorSound;
		if (cleaned.monitorVolume === undefined) delete cleaned.monitorVolume;
		if (cleaned.webhook === undefined) delete cleaned.webhook;
		return cleaned;
	});

	await settingsManager.set("general.keywordGroups", cleanedGroups);
}

/**
 * Adds a new group
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} name - The group name
 * @param {string} type - The group type
 * @returns {Promise<Object>} The newly created group
 */
export async function addGroup(settingsManager, name, type) {
	const groups = await getGroups(settingsManager);
	const maxOrder = groups.length > 0 ? Math.max(...groups.map((g) => g.order)) : -1;
	const newGroup = createGroup(name, type, maxOrder + 1);

	// For new highlight groups, default listing/monitor colors from settings (checkboxes on)
	if (type === "highlight") {
		newGroup.listingColor = settingsManager.get("general.highlightColor.color", false) ?? "#FFE815";
		newGroup.monitorColor = settingsManager.get("notification.monitor.highlight.color", false) ?? "#FFE815";
	}

	groups.push(newGroup);
	await saveGroups(settingsManager, groups);
	return newGroup;
}

/**
 * Updates a group
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} groupId - The group ID
 * @param {Object} updates - Object with fields to update
 * @returns {Promise<Object|null>} The updated group or null if not found
 */
export async function updateGroup(settingsManager, groupId, updates) {
	const groups = await getGroups(settingsManager);
	const index = groups.findIndex((g) => g.id === groupId);
	if (index === -1) {
		return null;
	}

	const updatedGroup = { ...groups[index], ...updates };

	if (!isValidGroup(updatedGroup)) {
		throw new Error("Invalid group data");
	}

	groups[index] = updatedGroup;
	await saveGroups(settingsManager, groups);
	return updatedGroup;
}

/**
 * Deletes a group
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} groupId - The group ID
 * @returns {Promise<boolean>} True if the group was deleted
 */
export async function deleteGroup(settingsManager, groupId) {
	const groups = await getGroups(settingsManager);
	const filtered = groups.filter((g) => g.id !== groupId);
	if (filtered.length === groups.length) {
		return false; // Group not found
	}
	await saveGroups(settingsManager, filtered);
	return true;
}

/**
 * Reorders groups
 * @param {Object} settingsManager - The settings manager instance
 * @param {Array<string>} groupIds - Array of group IDs in the desired order
 * @returns {Promise<void>}
 */
export async function reorderGroups(settingsManager, groupIds) {
	const groups = await getGroups(settingsManager);
	const groupMap = new Map(groups.map((g) => [g.id, g]));

	// Update order based on the provided order
	groupIds.forEach((id, index) => {
		if (groupMap.has(id)) {
			groupMap.get(id).order = index;
		}
	});

	await saveGroups(settingsManager, Array.from(groupMap.values()));
}

/**
 * Adds a keyword to a group
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} groupId - The group ID
 * @param {Object} keyword - The keyword object to add
 * @returns {Promise<boolean>} True if the keyword was added
 */
export async function addKeywordToGroup(settingsManager, groupId, keyword) {
	if (!isValidKeyword(keyword)) {
		throw new Error("Invalid keyword data");
	}

	const groups = await getGroups(settingsManager);
	const group = groups.find((g) => g.id === groupId);
	if (!group) {
		return false;
	}

	if (!group.keywords) {
		group.keywords = [];
	}

	group.keywords.push(keyword);
	await saveGroups(settingsManager, groups);
	return true;
}

/**
 * Updates a keyword in a group
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} groupId - The group ID
 * @param {number} keywordIndex - The index of the keyword in the group
 * @param {Object} updates - Object with fields to update
 * @returns {Promise<boolean>} True if the keyword was updated
 */
export async function updateKeywordInGroup(settingsManager, groupId, keywordIndex, updates) {
	const groups = await getGroups(settingsManager);
	const group = groups.find((g) => g.id === groupId);
	if (!group || !group.keywords || keywordIndex < 0 || keywordIndex >= group.keywords.length) {
		return false;
	}

	const updatedKeyword = { ...group.keywords[keywordIndex], ...updates };
	if (!isValidKeyword(updatedKeyword)) {
		throw new Error("Invalid keyword data");
	}

	group.keywords[keywordIndex] = updatedKeyword;
	await saveGroups(settingsManager, groups);
	return true;
}

/**
 * Deletes a keyword from a group
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} groupId - The group ID
 * @param {number} keywordIndex - The index of the keyword in the group
 * @returns {Promise<boolean>} True if the keyword was deleted
 */
export async function deleteKeywordFromGroup(settingsManager, groupId, keywordIndex) {
	const groups = await getGroups(settingsManager);
	const group = groups.find((g) => g.id === groupId);
	if (!group || !group.keywords || keywordIndex < 0 || keywordIndex >= group.keywords.length) {
		return false;
	}

	group.keywords.splice(keywordIndex, 1);
	await saveGroups(settingsManager, groups);
	return true;
}

/**
 * Migrates old keyword format to new group-based format
 * @param {Object} settingsManager - The settings manager instance
 * @param {string} type - The keyword type (highlight, hide, or blur)
 * @param {Array} oldKeywords - The old keyword array
 * @returns {Promise<Object>} The created group
 */
export async function migrateKeywordsToGroup(settingsManager, type, oldKeywords) {
	if (!oldKeywords || oldKeywords.length === 0) {
		return null;
	}

	// Check if migration already happened
	const existingGroups = await getGroupsByType(settingsManager, type);
	if (existingGroups.length > 0) {
		// Migration already done, don't duplicate
		return null;
	}

	// Create a default group for the old keywords
	const groupName = `Default ${type.charAt(0).toUpperCase() + type.slice(1)} Keywords`;
	const group = await addGroup(settingsManager, groupName, type);

	// Convert old format to new format
	const keywords = oldKeywords.map((kw) => {
		if (typeof kw === "string") {
			return { contains: kw };
		}
		return kw;
	});

	group.keywords = keywords;
	await updateGroup(settingsManager, group.id, { keywords });

	return group;
}

/**
 * Migrates old keyword system to new keyword groups system
 * @param {Object} settingsManager - The settings manager instance
 * @param {Object} rawSettings - Optional raw settings object to read from directly
 * @returns {Promise<Object>} Object with migrationPerformed flag and keysToDelete array
 */
export async function migrateOldKeywordsToGroups(settingsManager, rawSettings = null) {
	await settingsManager.waitForLoad();

	// Access raw keyword values directly from settings object FIRST
	// Use rawSettings if provided, otherwise fall back to settingsManager.get()
	// This ensures we get the raw array values, not compiled regex patterns
	let highlightKeywords, hideKeywords, blurKeywords;

	if (rawSettings && rawSettings.general) {
		// Read directly from raw settings object
		highlightKeywords = rawSettings.general.highlightKeywords;
		hideKeywords = rawSettings.general.hideKeywords;
		blurKeywords = rawSettings.general.blurKeywords;
	} else {
		// Fall back to settingsManager.get() with false to not return defaults
		highlightKeywords = await settingsManager.get("general.highlightKeywords", false);
		hideKeywords = await settingsManager.get("general.hideKeywords", false);
		blurKeywords = await settingsManager.get("general.blurKeywords", false);
	}

	// Debug: Log what we found
	console.log("Migration: Checking for old keywords...");
	console.log(
		"Migration: highlightKeywords:",
		highlightKeywords ? (Array.isArray(highlightKeywords) ? highlightKeywords.length : "not array") : "undefined"
	);
	console.log(
		"Migration: hideKeywords:",
		hideKeywords ? (Array.isArray(hideKeywords) ? hideKeywords.length : "not array") : "undefined"
	);
	console.log(
		"Migration: blurKeywords:",
		blurKeywords ? (Array.isArray(blurKeywords) ? blurKeywords.length : "not array") : "undefined"
	);

	// Check if there are any old keywords to migrate
	const hasOldKeywords =
		(highlightKeywords && Array.isArray(highlightKeywords) && highlightKeywords.length > 0) ||
		(hideKeywords && Array.isArray(hideKeywords) && hideKeywords.length > 0) ||
		(blurKeywords && Array.isArray(blurKeywords) && blurKeywords.length > 0);

	if (!hasOldKeywords) {
		// No old keywords to migrate
		console.log("Migration: No old keywords found, skipping migration");
		return {
			migrationPerformed: false,
			keysToDelete: [],
		};
	}

	// Old keywords exist - proceed with migration even if groups already exist
	console.log("Migration: Old keywords found, proceeding with migration...");

	let migrationPerformed = false;

	// Get existing groups ONCE and work with them in memory
	// This prevents race conditions where groups might be overwritten
	const groups = await getGroups(settingsManager);
	const maxOrder = groups.length > 0 ? Math.max(...groups.map((g) => g.order)) : -1;
	let nextOrder = maxOrder + 1;

	// Helper function to merge and de-duplicate keywords
	const mergeKeywords = (existingKeywords, newKeywords) => {
		const existing = existingKeywords || [];
		const merged = [...existing];
		const existingKeys = new Set(
			existing.map((kw) => JSON.stringify({ contains: kw.contains || "", without: kw.without || "" }))
		);

		for (const newKw of newKeywords) {
			const key = JSON.stringify({ contains: newKw.contains || "", without: newKw.without || "" });
			if (!existingKeys.has(key)) {
				merged.push(newKw);
				existingKeys.add(key);
			}
		}

		return merged;
	};

	// Migrate highlight keywords
	if (highlightKeywords && Array.isArray(highlightKeywords) && highlightKeywords.length > 0) {
		// Check if a "Highlight Keywords" group already exists
		let highlightGroup = groups.find((g) => g.name === "Highlight Keywords" && g.type === "highlight");

		if (!highlightGroup) {
			// Create new group in memory (don't save yet)
			highlightGroup = createGroup("Highlight Keywords", "highlight", nextOrder++);
			groups.push(highlightGroup);
		}

		// Convert old format to new format
		const migratedKeywords = highlightKeywords.map((kw) => {
			if (typeof kw === "string") {
				return { contains: kw };
			}
			return kw;
		});

		// Merge with existing keywords and de-duplicate
		const existingKeywords = highlightGroup.keywords || [];
		const mergedKeywords = mergeKeywords(existingKeywords, migratedKeywords);

		// Update group in memory
		const groupIndex = groups.findIndex((g) => g.id === highlightGroup.id);
		if (groupIndex !== -1) {
			groups[groupIndex] = { ...groups[groupIndex], keywords: mergedKeywords };
		}
		migrationPerformed = true;
	}

	// Migrate hide keywords
	if (hideKeywords && Array.isArray(hideKeywords) && hideKeywords.length > 0) {
		// Check if a "Hide Keywords" group already exists
		let hideGroup = groups.find((g) => g.name === "Hide Keywords" && g.type === "hide");

		if (!hideGroup) {
			// Create new group in memory (don't save yet)
			hideGroup = createGroup("Hide Keywords", "hide", nextOrder++);
			groups.push(hideGroup);
		}

		// Convert old format to new format
		const migratedKeywords = hideKeywords.map((kw) => {
			if (typeof kw === "string") {
				return { contains: kw };
			}
			return kw;
		});

		// Merge with existing keywords and de-duplicate
		const existingKeywords = hideGroup.keywords || [];
		const mergedKeywords = mergeKeywords(existingKeywords, migratedKeywords);

		// Update group in memory
		const groupIndex = groups.findIndex((g) => g.id === hideGroup.id);
		if (groupIndex !== -1) {
			groups[groupIndex] = { ...groups[groupIndex], keywords: mergedKeywords };
		}
		migrationPerformed = true;
	}

	// Migrate blur keywords
	if (blurKeywords && Array.isArray(blurKeywords) && blurKeywords.length > 0) {
		// Check if a "Blur Keywords" group already exists
		let blurGroup = groups.find((g) => g.name === "Blur Keywords" && g.type === "blur");

		if (!blurGroup) {
			// Create new group in memory (don't save yet)
			blurGroup = createGroup("Blur Keywords", "blur", nextOrder++);
			groups.push(blurGroup);
		}

		// Convert old format to new format (blur keywords are usually strings)
		const migratedKeywords = blurKeywords.map((kw) => {
			if (typeof kw === "string") {
				return { contains: kw };
			}
			return kw;
		});

		// Merge with existing keywords and de-duplicate
		const existingKeywords = blurGroup.keywords || [];
		const mergedKeywords = mergeKeywords(existingKeywords, migratedKeywords);

		// Update group in memory
		const groupIndex = groups.findIndex((g) => g.id === blurGroup.id);
		if (groupIndex !== -1) {
			groups[groupIndex] = { ...groups[groupIndex], keywords: mergedKeywords };
		}
		migrationPerformed = true;
	}

	// Save all groups ONCE after all migrations are complete
	// This ensures all groups are written atomically and prevents overwrites
	if (migrationPerformed) {
		await saveGroups(settingsManager, groups);
		console.log("Migration: All keyword groups saved successfully");
	}

	// If migration was performed, delete old keyword keys from storage
	// Note: We access settings through the manager's internal structure
	// The actual deletion happens in SettingsMgrDI migration after this function returns
	// Migrate highlight color and sound settings to existing highlight groups
	await migrateHighlightSettingsToGroups(settingsManager);

	return {
		migrationPerformed,
		keysToDelete: migrationPerformed
			? [
					...(highlightKeywords && highlightKeywords.length > 0 ? ["general.highlightKeywords"] : []),
					...(hideKeywords && hideKeywords.length > 0 ? ["general.hideKeywords"] : []),
					...(blurKeywords && blurKeywords.length > 0 ? ["general.blurKeywords"] : []),
				]
			: [],
	};
}

/**
 * Pure function: computes which highlight groups need default values and what updates to apply.
 * Used for migration and unit testing. Does not touch storage.
 * @param {Array<Object>} groups - All keyword groups (any type)
 * @param {Object} defaults - Default values: { listingColor?, monitorColor?, monitorSound?, monitorVolume?, webhook? }
 * @returns {Array<{ groupId: string, updates: Object }>} List of group id and updates to apply
 */
export function computeHighlightDefaultsUpdates(groups, defaults) {
	const highlightGroups = (groups || []).filter((g) => g.type === "highlight");
	if (highlightGroups.length === 0) {
		return [];
	}

	const listingColorDefault = defaults.listingColor;
	const monitorColorDefault = defaults.monitorColor;
	const monitorSoundDefault = defaults.monitorSound;
	const monitorVolumeDefault = defaults.monitorVolume;
	const webhookDefault = defaults.webhook;
	const result = [];

	for (const group of highlightGroups) {
		const updates = {};

		// Prefer old highlightColor over global default when listingColor is missing. Only apply when undefined.
		if (group.listingColor === undefined) {
			if (group.highlightColor !== undefined) {
				updates.listingColor = group.highlightColor;
			} else if (listingColorDefault !== undefined) {
				updates.listingColor = listingColorDefault;
			}
		}

		if (group.monitorColor === undefined && monitorColorDefault !== undefined) {
			updates.monitorColor = monitorColorDefault;
		}

		if (group.monitorSound === undefined && monitorSoundDefault !== undefined) {
			updates.monitorSound = monitorSoundDefault === "0" ? null : monitorSoundDefault;
		}

		if (group.monitorVolume === undefined && monitorVolumeDefault !== undefined) {
			const v = Number(monitorVolumeDefault);
			updates.monitorVolume = Number.isFinite(v) && v >= 0 && v <= 1 ? v : 0.5;
		}

		// Migrate legacy discord.webhook.KWsMatch.active: when it was true, set webhook on highlight groups that don't have it true
		if (webhookDefault !== undefined && group.webhook !== true) {
			updates.webhook = webhookDefault;
		}

		if (Object.keys(updates).length > 0) {
			result.push({ groupId: group.id, updates });
		}
	}

	return result;
}

/**
 * Migrates old highlight color, sound, and volume settings to existing highlight keyword groups.
 * Ensures each highlight group has listingColor, monitorColor, monitorSound, monitorVolume from defaults when missing.
 * @param {Object} settingsManager - The settings manager instance
 * @returns {Promise<void>}
 */
export async function migrateHighlightSettingsToGroups(settingsManager) {
	await settingsManager.waitForLoad();

	// Use raw groups from storage so we only migrate when properties are undefined (never set)
	const rawGroups = settingsManager.get("general.keywordGroups") || [];
	const sortedRaw = [...rawGroups].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

	// Only migrate colors when the corresponding active flag is true
	// If active is false, leave as undefined (don't migrate - null means user explicitly disabled it)
	const listingColorActive = settingsManager.get("general.highlightColor.active");
	const monitorHighlightActive = settingsManager.get("notification.monitor.highlight.colorActive");
	const kwsMatchActive = settingsManager.get("discord.webhook.KWsMatch.active");

	const defaults = {
		// Only provide default if active is true - undefined means "don't migrate"
		listingColor: listingColorActive === true ? settingsManager.get("general.highlightColor.color") : undefined,
		monitorColor:
			monitorHighlightActive === true ? settingsManager.get("notification.monitor.highlight.color") : undefined,
		monitorSound: settingsManager.get("notification.monitor.highlight.sound"),
		monitorVolume: settingsManager.get("notification.monitor.highlight.volume"),
		// Migrate legacy KWsMatch.active: if it was true, enable webhook on highlight groups
		webhook: kwsMatchActive === true ? true : undefined,
	};

	const toApply = computeHighlightDefaultsUpdates(sortedRaw, defaults);

	for (const { groupId, updates } of toApply) {
		await updateGroup(settingsManager, groupId, updates);
	}
}

/**
 * @param {Object} settingsManager
 * @returns {Promise<Array<Object>>}
 */
export async function getLinkedCommunityGroups(settingsManager) {
	const groups = await getGroups(settingsManager);
	return groups.filter((g) => normalizeCommunityLink(g.communityLink));
}

/**
 * @param {Object} settingsManager
 * @param {string} groupId
 * @param {{ listId: number, name: string, revision: number }} communityLink
 */
export async function linkGroupToCommunityList(settingsManager, groupId, communityLink) {
	if (!isValidCommunityLink(communityLink)) {
		throw new Error("Invalid community link");
	}
	return updateGroup(settingsManager, groupId, { communityLink });
}

/**
 * @param {Object} settingsManager
 * @param {string} groupId
 */
export async function unlinkGroupFromCommunityList(settingsManager, groupId) {
	const groups = await getGroups(settingsManager);
	const index = groups.findIndex((g) => g.id === groupId);
	if (index === -1) return null;
	const group = groups[index];
	const updated = { ...group };
	delete updated.communityLink;
	groups[index] = updated;
	await saveGroups(settingsManager, groups);
	return group;
}

/**
 * @param {Object} settingsManager
 * @param {string} name
 * @returns {Promise<Object|null>}
 */
export async function findGroupByName(settingsManager, name) {
	const groups = await getGroups(settingsManager);
	const normalized = name.trim().toLowerCase();
	return groups.find((g) => g.name.trim().toLowerCase() === normalized) ?? null;
}
