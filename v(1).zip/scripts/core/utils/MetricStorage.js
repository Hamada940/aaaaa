/*global chrome*/

/**
 * Usage metrics stored under chrome.storage.local key "metric" (not in Settings)
 * so the service worker can increment minutes without triggering settings reload on every page.
 *
 * Legacy: minutes lived at settings metrics.minutesUsed — see migrateMinutesUsedFromSettingsIfNeeded.
 */

export const METRIC_STORAGE_KEY = "metric";

/**
 * @param {*} v
 * @returns {number}
 */
function toFiniteMinutes(v) {
	const n = Number(v);
	return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 0;
}

/**
 * If chrome.storage.local "metric" is missing or has no valid minutesUsed, copy from
 * legacy Settings metrics.minutesUsed and persist.
 *
 * @param {{ get: (path: string) => unknown }} settingsMgr - loaded SettingsMgr (or compatible)
 * @returns {Promise<number>}
 */
export async function migrateMinutesUsedFromSettingsIfNeeded(settingsMgr) {
	const data = await chrome.storage.local.get(METRIC_STORAGE_KEY);
	const existing = data[METRIC_STORAGE_KEY];
	if (existing && typeof existing.minutesUsed === "number" && Number.isFinite(existing.minutesUsed)) {
		return Math.max(0, Math.floor(existing.minutesUsed));
	}
	const legacy = settingsMgr ? toFiniteMinutes(settingsMgr.get("metrics.minutesUsed")) : 0;
	await chrome.storage.local.set({ [METRIC_STORAGE_KEY]: { minutesUsed: legacy } });
	return legacy;
}

/**
 * Read minutes used, running migration once if needed.
 *
 * @param {{ get: (path: string) => unknown }} settingsMgr
 * @returns {Promise<number>}
 */
export async function getMinutesUsed(settingsMgr) {
	return migrateMinutesUsedFromSettingsIfNeeded(settingsMgr);
}

/**
 * Increment by 1. Does not touch Settings. Call migrateMinutesUsedFromSettingsIfNeeded (or getMinutesUsed)
 * once at startup before the first tick so the counter continues from legacy value.
 *
 * @returns {Promise<number>} new total minutes
 */
export async function incrementMinutesUsed() {
	const data = await chrome.storage.local.get(METRIC_STORAGE_KEY);
	const rec = data[METRIC_STORAGE_KEY];
	const current =
		rec && typeof rec.minutesUsed === "number" && Number.isFinite(rec.minutesUsed)
			? Math.max(0, Math.floor(rec.minutesUsed))
			: 0;
	const next = current + 1;
	await chrome.storage.local.set({ [METRIC_STORAGE_KEY]: { minutesUsed: next } });
	return next;
}
