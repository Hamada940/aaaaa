/**
 * Validation error with path and detailed message for UI display.
 */
export class ValidationError extends Error {
	/**
	 * @param {string} path - Dot-separated path (e.g. "result.asin")
	 * @param {string} message - Human-readable reason
	 * @param {string} [expected] - What was expected (e.g. "match pattern /[A-Z0-9]{10,13}/")
	 * @param {unknown} [actual] - Actual value received
	 */
	constructor(path, message, expected, actual) {
		const fullMessage = ValidationError.buildMessage(path, message, expected, actual);
		super(fullMessage);
		this.name = "ValidationError";
		/** @type {string} */
		this.reason = message;
		/** @type {string} */
		this.path = path;
		/** @type {string|undefined} */
		this.expected = expected;
		/** @type {unknown} */
		this.actual = actual;
	}

	/**
	 * Build a single-line message: path, reason, expected, actual (for which field failed and why).
	 * @param {string} path
	 * @param {string} message
	 * @param {string|undefined} expected
	 * @param {unknown} actual
	 * @returns {string}
	 */
	static buildMessage(path, message, expected, actual) {
		let out = path ? `${path}: ${message}` : message;
		if (expected != null && expected !== "") {
			out += ` (expected: ${expected})`;
		}
		if (actual !== undefined) {
			const actualStr = typeof actual === "object" && actual !== null ? JSON.stringify(actual) : String(actual);
			out += actualStr.length > 80 ? ` (actual: ${actualStr.slice(0, 77)}…)` : ` (actual: ${actualStr})`;
		}
		return out;
	}

	/**
	 * Full message suitable for display (path + message + expected/actual if set).
	 * @returns {string}
	 */
	toDisplayMessage() {
		return this.message;
	}
}

/**
 * Check if a string is a regex pattern: starts with "/" and ends with "/" (optional flags after).
 * @param {string} s
 * @returns {{ pattern: string, flags: string } | null}
 */
function parseRegexLiteral(s) {
	if (typeof s !== "string" || s.length < 2 || s[0] !== "/") return null;
	const lastSlash = s.lastIndexOf("/");
	if (lastSlash <= 0) return null;
	const pattern = s.slice(1, lastSlash);
	const flags = s.slice(lastSlash + 1);
	return { pattern, flags };
}

/**
 * Check if a string looks like a bare regex pattern (e.g. "[A-Z0-9]{14}").
 * @param {string} s
 * @returns {boolean}
 */
function looksLikeBareRegex(s) {
	if (typeof s !== "string" || s.length === 0) return false;
	// Contains regex metacharacters and no spaces (likely a pattern)
	return /[[\\^$*+?.|()]/.test(s) && !/\s/.test(s);
}

/**
 * Validate a single value against an expectation template value.
 * Template conventions:
 * - String "/pattern/" or "/pattern/flags" → actual is coerced to string and must match regex
 * - String that looks like bare regex (e.g. "[A-Z0-9]{14}") → same as above
 * - String otherwise → literal equality
 * - Empty array [] → actual must be an array (any length)
 * - null → actual must be null
 * - number/boolean → literal equality
 *
 * @param {unknown} data - Value to validate
 * @param {unknown} template - Expectation for this value
 * @param {string} path - Current path for error reporting
 * @throws {ValidationError}
 */
function validateValue(data, template, path) {
	// Literal null
	if (template === null) {
		if (data !== null) {
			throw new ValidationError(path, "Value must be null", "null", data);
		}
		return;
	}

	// Expectation: must be array
	if (Array.isArray(template)) {
		if (!Array.isArray(data)) {
			throw new ValidationError(
				path,
				"Value must be an array",
				"array",
				data === undefined ? "missing" : typeof data
			);
		}
		return;
	}

	// Regex: string "/pattern/" or "/pattern/flags"
	if (typeof template === "string") {
		const regexSpec = parseRegexLiteral(template);
		if (regexSpec) {
			// Allow null/undefined for "match any" pattern (e.g. optional fields like catalogSize)
			if ((data === null || data === undefined) && regexSpec.pattern === ".*" && !regexSpec.flags) {
				return;
			}
			let re;
			try {
				re = new RegExp(regexSpec.pattern, regexSpec.flags);
			} catch (e) {
				throw new ValidationError(
					path,
					`Invalid regex in expectation: ${(e && /** @type {Error} */ (e).message) || String(e)}`,
					template,
					undefined
				);
			}
			const str = data === undefined || data === null ? "" : String(data);
			if (!re.test(str)) {
				throw new ValidationError(path, "Value does not match the required pattern", `match ${template}`, data);
			}
			return;
		}
		// Bare regex pattern (e.g. "[A-Z0-9]{14}")
		if (looksLikeBareRegex(template)) {
			let re;
			try {
				re = new RegExp(template);
			} catch (e) {
				// Not a valid regex, treat as literal
				if (data !== template) {
					throw new ValidationError(path, "Value does not match expected literal", template, data);
				}
				return;
			}
			const str = data === undefined || data === null ? "" : String(data);
			if (!re.test(str)) {
				throw new ValidationError(
					path,
					"Value does not match the required pattern",
					`match /${template}/`,
					data
				);
			}
			return;
		}
		// Literal string
		if (data !== template) {
			throw new ValidationError(path, "Value does not match expected literal", template, data);
		}
		return;
	}

	// Literal number or boolean
	if (typeof template === "number" || typeof template === "boolean") {
		if (data !== template) {
			throw new ValidationError(path, "Value does not match expected literal", String(template), data);
		}
		return;
	}

	// Nested object: recurse with strict key set
	if (template !== null && typeof template === "object" && !Array.isArray(template)) {
		validateObject(data, /** @type {Record<string, unknown>} */ (template), path);
		return;
	}

	throw new ValidationError(path, "Unsupported expectation type", typeof template, data);
}

/**
 * Validate that data is an object with exactly the keys of template (no extra, no missing).
 * @param {unknown} data
 * @param {Record<string, unknown>} template
 * @param {string} path
 * @throws {ValidationError}
 */
function validateObject(data, template, path) {
	if (data == null || typeof data !== "object" || Array.isArray(data)) {
		throw new ValidationError(
			path,
			"Expected an object",
			"object",
			data === undefined ? "missing" : Array.isArray(data) ? "array" : typeof data
		);
	}
	const obj = /** @type {Record<string, unknown>} */ (data);
	const templateKeys = Object.keys(template);
	const dataKeys = Object.keys(obj);

	const extra = dataKeys.filter((k) => !templateKeys.includes(k));
	if (extra.length > 0) {
		throw new ValidationError(
			path,
			"Object must not contain extra properties",
			`only: ${templateKeys.join(", ")}`,
			`extra: ${extra.join(", ")}`
		);
	}

	const missing = templateKeys.filter((k) => !dataKeys.includes(k));
	if (missing.length > 0) {
		throw new ValidationError(
			path,
			"Object is missing required properties",
			`required: ${templateKeys.join(", ")}`,
			`missing: ${missing.join(", ")}`
		);
	}

	for (const key of templateKeys) {
		const childPath = path ? `${path}.${key}` : key;
		validateValue(obj[key], template[key], childPath);
	}
}

/**
 * Validate data against an expectation template.
 * - Top-level keys must match exactly (no extra, no missing).
 * - Each value is validated per template conventions (regex, literal, array, nested object).
 *
 * @param {unknown} data - Data to validate
 * @param {Record<string, unknown>} expectationTemplate - Template (e.g. { result: { asin: "/[A-Z0-9]{10,13}/", ... }, error: null })
 * @param {string} [basePath=""] - Prefix for error paths
 * @throws {ValidationError} With path, message, expected, actual for UI display
 */
export function validate(data, expectationTemplate, basePath = "") {
	validateObject(data, expectationTemplate, basePath);
}
