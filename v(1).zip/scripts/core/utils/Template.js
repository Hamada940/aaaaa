import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { TitleDebugLogger } from "/scripts/ui/components/TitleDebugLogger.js";
const titleDebugger = TitleDebugLogger.getInstance();

class Template {
	static #instance = null;
	#tplMgr;

	constructor() {
		if (Template.#instance) {
			// Return the existing instance if it already exists
			return Template.#instance;
		}
		// Initialize the instance if it doesn't exist
		Template.#instance = this;

		this.arrCache = [];
		this.arrVar = [];
		this.arrIf = [];
		this.currentURL = null;
		this.#tplMgr = new TemplateMgr(); //Singleton
	}

	async loadFile(url, forceFromFile = false) {
		this.currentURL = url;

		return this.#tplMgr.getTemplate(url, forceFromFile);
	}

	setVar(name, value) {
		let variable = this.arrVar.find((e) => e.name === name);
		if (variable == null) this.arrVar.push({ name: name, value: value });
		//Variable already exist, update the value.
		else variable.value = value;
	}

	setIf(name, value) {
		let variable = this.arrIf.find((e) => e.name === name);
		if (variable == null) this.arrIf.push({ name: name, value: value });
		//Variable already exist, update the value.
		else variable.value = value;
	}

	clearVariables() {
		this.arrCache = [];
		this.arrVar = [];
		this.arrIf = [];
	}

	render(html, convertToDOMObject = false) {
		if (html == null) {
			logger.add("No content for " + this.currentURL + ", did you await loadFile()) ?");
			return convertToDOMObject ? document.createElement("div") : "";
		}
		var output = html;

		// Debug logging for description variable
		const descriptionVar = this.arrVar.find((v) => v.name === "description");
		const asinVar = this.arrVar.find((v) => v.name === "asin");

		if (descriptionVar && titleDebugger.isEnabled()) {
			console.log("[Template.js] Processing description variable:", {
				currentURL: this.currentURL,
				description:
					descriptionVar.value?.substring(0, 100) + (descriptionVar.value?.length > 100 ? "..." : ""),
				descriptionLength: descriptionVar.value?.length,
				asin: asinVar?.value,
			});
		}

		// Check if we're processing a template with description placeholder
		const hasDescriptionPlaceholder = output.includes("{{$description}}");

		for (let i = 0; i < this.arrVar.length; i++) {
			output = output.replaceAll("{{$" + this.arrVar[i]["name"] + "}}", this.arrVar[i]["value"]);
		}

		// Log template processing for title debugging
		if (asinVar && titleDebugger.isEnabled()) {
			titleDebugger.logTemplateProcessing(
				asinVar.value,
				this.currentURL,
				hasDescriptionPlaceholder,
				descriptionVar?.value
			);
		}

		// Process if conditions with a stack-based approach for proper nesting

		// Parse and evaluate the template
		const parseTemplate = (template) => {
			let pos = 0;
			let result = "";
			let stack = [];

			while (pos < template.length) {
				// Find the next tag
				const ifStart = template.indexOf("{{if ", pos);
				const elseTag = template.indexOf("{{else}}", pos);
				const endIf = template.indexOf("{{endif}}", pos);

				// Find the minimum positive position
				const positions = [
					ifStart >= 0 ? ifStart : Infinity,
					elseTag >= 0 ? elseTag : Infinity,
					endIf >= 0 ? endIf : Infinity,
				];
				const nextTagPos = Math.min(...positions);

				// No more tags found, add the remaining text if we should include content
				if (nextTagPos === Infinity) {
					if (!stack.some((item) => !item.includeContent)) {
						result += template.substring(pos);
					}
					break;
				}

				// Add the text before the tag if we should include content
				if (!stack.some((item) => !item.includeContent)) {
					result += template.substring(pos, nextTagPos);
				}

				// Process tag based on type
				if (nextTagPos === ifStart) {
					// Extract the condition name
					const endOfIf = template.indexOf("}}", nextTagPos);
					const condName = template.substring(nextTagPos + 5, endOfIf);

					// Find the condition value
					const condValue = this.arrIf.find((c) => c.name === condName)?.value || false;

					// Push current position and condition value to the stack
					stack.push({
						type: "if",
						value: condValue,
						includeContent: condValue,
					});

					pos = endOfIf + 2;
				} else if (nextTagPos === elseTag) {
					// Toggle the include flag for the current block
					if (stack.length > 0) {
						const current = stack[stack.length - 1];
						current.includeContent = !current.value;
					}

					pos = elseTag + 8; // "{{else}}".length = 8
				} else if (nextTagPos === endIf) {
					// Pop the stack
					stack.pop();
					pos = endIf + 9; // "{{endif}}".length = 9
				}
			}

			return result;
		};

		output = parseTemplate(output);

		// Replace Chrome i18n placeholders (__MSG_messageName__) with translated strings.
		// Template files are loaded as raw text, so they don't get Chrome's automatic substitution.
		// Use window.__VH_GET_MESSAGE__ when set (options page locale override), else chrome.i18n.
		if (
			(typeof chrome !== "undefined" && chrome.i18n && typeof chrome.i18n.getMessage === "function") ||
			(typeof window !== "undefined" && window.__VH_GET_MESSAGE__)
		) {
			output = output.replace(/__MSG_([a-zA-Z0-9_]+)__/g, (_, messageName) => {
				let translated =
					typeof window !== "undefined" && window.__VH_GET_MESSAGE__
						? window.__VH_GET_MESSAGE__(messageName)
						: "";
				if (translated === "" && typeof chrome !== "undefined" && chrome.i18n?.getMessage) {
					translated = chrome.i18n.getMessage(messageName);
				}
				return translated !== "" ? translated : `__MSG_${messageName}__`;
			});
		}

		if (!convertToDOMObject) {
			return output;
		}

		//Otherwise, convert the HTML string to a DOM element.
		let parser = new DOMParser();
		let doc = parser.parseFromString(output, "text/html");
		let element = doc.body.firstChild; // Use firstChild to get the top-level element
		return element instanceof Node ? element : document.createElement("div");
	}

	async flushLocalStorage() {
		console.log("[Template.flushLocalStorage] Starting flush...");
		// Clear in-memory cache immediately and synchronously (most reliable)
		this.#tplMgr.arrTemplate = [];
		this.clearVariables();
		console.log("[Template.flushLocalStorage] In-memory cache cleared");

		// Remove the key from storage (not just set to empty array)
		// Use direct removal which works reliably in all contexts including popup pages
		return new Promise((resolve) => {
			console.log("[Template.flushLocalStorage] Attempting to remove arrTemplate from storage...");
			try {
				if (typeof chrome === "undefined" || !chrome.storage?.local) {
					resolve();
					return;
				}
				chrome.storage.local.remove("arrTemplate", () => {
					if (chrome.runtime.lastError) {
						console.warn("[Template.flushLocalStorage] Remove failed:", chrome.runtime.lastError.message);
						// If direct removal fails, try setting to empty array as fallback
						console.log("[Template.flushLocalStorage] Trying fallback: set to empty array...");
						try {
							chrome.storage.local.set({ arrTemplate: [] }, () => {
								if (chrome.runtime.lastError) {
									console.error(
										"[Template.flushLocalStorage] Fallback also failed:",
										chrome.runtime.lastError.message
									);
								} else {
									console.log(
										"[Template.flushLocalStorage] Successfully set to empty array (fallback)"
									);
									logger.add("TEMPLATE: Flushed template cache (set to empty array fallback).");
								}
								resolve();
							});
						} catch {
							resolve();
						}
					} else {
						//console.log("[Template.flushLocalStorage] Successfully removed arrTemplate from storage");
						logger.add("TEMPLATE: Flushed template cache (removed from storage).");
						resolve();
					}
				});
			} catch {
				resolve();
			}
		});
	}
}

class TemplateMgr {
	static #instance = null;
	#templatesLoaded = false;
	arrTemplate = [];

	constructor() {
		//Singleton
		if (TemplateMgr.#instance) {
			// Return the existing instance if it already exists
			return TemplateMgr.#instance;
		}
		// Initialize the instance if it doesn't exist
		TemplateMgr.#instance = this;

		this.arrTemplate = [];
		this.loadTempateFromLocalStorage();
	}

	async loadTempateFromLocalStorage() {
		try {
			if (typeof chrome !== "undefined" && chrome.storage?.local) {
				const data = await chrome.storage.local.get("arrTemplate");
				if (Object.keys(data).length === 0) {
					logger.add("TEMPLATE: No template in localstorage, will load them from files as needed...");
					this.#templatesLoaded = true;
					return;
				}
				this.arrTemplate = data.arrTemplate;
			}
		} catch (error) {
			logger.add("TEMPLATE: Failed to load template from storage: " + error.message);
		} finally {
			this.#templatesLoaded = true;
		}
	}

	async getTemplate(url, forceFromFile = false) {
		//Wait until the template are loaded from local storage
		while (!this.#templatesLoaded) {
			await new Promise((r) => setTimeout(r, 50));
		}
		//Search for the template in the memory
		if (!forceFromFile) {
			let content = this.arrTemplate.find((e) => {
				return e.url === url;
			});
			if (content != null) {
				logger.add("TEMPLATE: Loaded template " + url + " from memory.");
				return content.prom;
			}
		}

		//Not found in memory, which was loaded from local storage. Fetch the file.
		logger.add("TEMPLATE: Loading template " + url + " from file.");
		const prom = await this.loadTemplateFromFile(url);

		// Remove any object with the same url if it already exists in this.arrTemplate
		this.arrTemplate = this.arrTemplate.filter((e) => e.url !== url);
		this.arrTemplate.push({ url, prom });

		// Only save to storage if not forcing from file (forceFromFile means don't cache)
		if (!forceFromFile) {
			//Save new file to local storage
			try {
				if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
					chrome.runtime.sendMessage({
						type: "saveToLocalStorage",
						key: "arrTemplate",
						value: this.arrTemplate,
					});
				}
			} catch (error) {
				logger.add("TEMPLATE: Failed to save template to storage: " + error.message);
			}
		}

		return prom;
	}

	async loadTemplateFromFile(url) {
		let extensionUrl = "";
		try {
			if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
				extensionUrl = chrome.runtime.getURL(url);
			}
		} catch {
			return "";
		}

		if (!extensionUrl) {
			return "";
		}

		const promise = fetch(extensionUrl)
			.then((response) => {
				if (!response.ok) {
					throw new Error(response.statusText + " " + url);
				}
				return response.text();
			})
			.catch((error) => {
				// Handle the error here
				let safeUrl = url;
				try {
					if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
						safeUrl = chrome.runtime.getURL(url);
					}
				} catch {
					safeUrl = url;
				}
				return error + " " + safeUrl;
			});

		return promise;
	}
}

export { Template };
