/**
 * @fileoverview KeywordGroupsProcessor - Processes keyword groups for matching
 *
 * This module handles the processing of keyword groups in the correct order,
 * separating blur groups from highlight/hide groups as required.
 */

import { compileKeywordObjects } from "./KeywordCompiler.js";
import { findMatch } from "./KeywordMatcher.js";
import { getGroups } from "./KeywordGroupsManager.js";

/**
 * Processes keyword groups and returns compiled keywords organized by type
 * @param {Object} settingsManager - The settings manager instance
 * @param {boolean} isPremiumTier2 - Whether the user has premium tier 2 access
 * @returns {Promise<Object>} Object with compiledHighlightKeywords, compiledHideKeywords, compiledBlurKeywords
 */
export async function processKeywordGroups(settingsManager, isPremiumTier2 = false) {
	const groups = await getGroups(settingsManager);

	// Separate groups by type and process in order
	const highlightGroups = [];
	const hideGroups = [];
	const blurGroups = [];

	groups.forEach((group) => {
		// Skip disabled groups
		if (group.enabled === false) {
			return;
		}

		if (group.type === "highlight") {
			highlightGroups.push(group);
		} else if (group.type === "hide") {
			hideGroups.push(group);
		} else if (group.type === "blur") {
			// Only include blur groups if user has premium tier 2
			if (isPremiumTier2) {
				blurGroups.push(group);
			}
		}
	});

	// Process groups in order and flatten keywords
	const allHighlightKeywords = [];
	const allHideKeywords = [];
	const allBlurKeywords = [];

	// Process highlight groups in order
	highlightGroups.forEach((group) => {
		if (group.keywords && Array.isArray(group.keywords)) {
			allHighlightKeywords.push(...group.keywords);
		}
	});

	// Process hide groups in order
	hideGroups.forEach((group) => {
		if (group.keywords && Array.isArray(group.keywords)) {
			allHideKeywords.push(...group.keywords);
		}
	});

	// Process blur groups in order (separate from highlight/hide)
	blurGroups.forEach((group) => {
		if (group.keywords && Array.isArray(group.keywords)) {
			// Convert blur keywords to proper format if needed
			const formattedKeywords = group.keywords.map((kw) => {
				if (typeof kw === "string") {
					return { contains: kw };
				}
				return kw;
			});
			allBlurKeywords.push(...formattedKeywords);
		}
	});

	// Compile all keywords
	const compiledHighlightKeywords =
		allHighlightKeywords.length > 0 ? compileKeywordObjects(allHighlightKeywords) : null;
	const compiledHideKeywords = allHideKeywords.length > 0 ? compileKeywordObjects(allHideKeywords) : null;
	const compiledBlurKeywords = allBlurKeywords.length > 0 ? compileKeywordObjects(allBlurKeywords) : null;

	return {
		compiledHighlightKeywords,
		compiledHideKeywords,
		compiledBlurKeywords,
	};
}

/**
 * Finds a match in keyword groups, processing groups in order
 * @param {string} text - The text to match against
 * @param {Array<Object>} groups - Array of groups to search (already filtered by type)
 * @param {number|null} itemEtvMin - Item's minimum ETV
 * @param {number|null} itemEtvMax - Item's maximum ETV
 * @returns {Object|null} The first matching keyword object or null
 */
export function findMatchInGroups(text, groups, itemEtvMin = null, itemEtvMax = null) {
	if (!text || !Array.isArray(groups)) {
		return null;
	}

	// Process groups in order
	for (const group of groups) {
		// Skip disabled groups
		if (group.enabled === false) {
			continue;
		}

		if (!group.keywords || !Array.isArray(group.keywords) || group.keywords.length === 0) {
			continue;
		}

		// Compile keywords for this group
		const compiledKeywords = compileKeywordObjects(group.keywords);

		// Find match in this group
		const match = findMatch(text, compiledKeywords, itemEtvMin, itemEtvMax);
		if (match) {
			// Add group info to the match for reference
			return {
				...match,
				groupId: group.id,
				groupName: group.name,
			};
		}
	}

	return null;
}

/**
 * Finds a match in highlight/hide groups, processing them together in order and stopping at first match
 * This respects the group order and stops as soon as a highlight or hide keyword matches
 * @param {string} text - The text to match against
 * @param {Object} settingsManager - The settings manager instance
 * @param {number|null} itemEtvMin - Item's minimum ETV
 * @param {number|null} itemEtvMax - Item's maximum ETV
 * @returns {Object|null} The first matching keyword object with type ('highlight' or 'hide') or null
 */
export async function findMatchInOrderedGroups(text, settingsManager, itemEtvMin = null, itemEtvMax = null) {
	if (!text) {
		return null;
	}

	const groups = await getGroups(settingsManager);

	// Filter to only enabled highlight and hide groups, sorted by order
	const highlightHideGroups = groups
		.filter((group) => (group.type === "highlight" || group.type === "hide") && group.enabled !== false)
		.sort((a, b) => a.order - b.order);

	// Process groups in order, stopping at first match
	for (const group of highlightHideGroups) {
		if (!group.keywords || !Array.isArray(group.keywords) || group.keywords.length === 0) {
			continue;
		}

		// Compile keywords for this group
		const compiledKeywords = compileKeywordObjects(group.keywords);

		// Find match in this group
		const match = findMatch(text, compiledKeywords, itemEtvMin, itemEtvMax);
		if (match) {
			// Return match with group type information
			return {
				...match,
				type: group.type, // 'highlight' or 'hide'
				groupId: group.id,
				groupName: group.name,
			};
		}
	}

	return null;
}
