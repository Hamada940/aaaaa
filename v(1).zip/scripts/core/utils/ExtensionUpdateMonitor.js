/* global chrome */

import { getMessage } from "/scripts/core/services/Internationalization.js";

const DEFAULT_INTERVAL_MS = 30_000;
const MODAL_KEY = "extension-update";
const MODAL_STYLE_ID = "vh-extension-update-modal-style";

let pageVersion = null;
let intervalId = null;
let dismissed = false;
let modalVisible = false;
let started = false;
let contextInvalidatedListener = null;

/**
 * @param {unknown} error
 * @returns {boolean}
 */
export function isExtensionContextInvalidError(error) {
	const msg = String(error?.message ?? error ?? "");
	return /extension context invalidat|receiving end does not exist/i.test(msg);
}

/**
 * @param {string | null | undefined} pageVer
 * @param {string | null | undefined} liveVer
 * @param {boolean} contextInvalid
 * @returns {boolean}
 */
export function shouldShowExtensionUpdate(pageVer, liveVer, contextInvalid) {
	if (contextInvalid) {
		return true;
	}
	if (!pageVer || !liveVer) {
		return false;
	}
	return pageVer !== liveVer;
}

/**
 * @returns {string | null}
 */
export function readPageExtensionVersion() {
	try {
		if (typeof chrome === "undefined" || !chrome.runtime?.getManifest) {
			return null;
		}
		return chrome.runtime.getManifest().version ?? null;
	} catch {
		return null;
	}
}

/**
 * @returns {boolean}
 */
export function isRuntimeContextValid() {
	return readPageExtensionVersion() != null;
}

/**
 * @param {string | null} oldVersion
 * @param {string | null} newVersion
 * @returns {{ title: string, body: string }}
 */
export function getExtensionUpdateCopy(oldVersion, newVersion) {
	const title = getMessage("extensionUpdatedTitle", "Extension updated");
	if (newVersion) {
		return {
			title,
			body: getMessage(
				"extensionUpdatedBody",
				"VHelper was updated from $1$ to $2$. Please refresh this page to avoid issues.",
				[oldVersion || "?", newVersion]
			),
		};
	}
	return {
		title,
		body: getMessage(
			"extensionUpdatedBodyUnknown",
			"VHelper was updated. Please refresh this page to avoid issues."
		),
	};
}

/**
 * @param {object} message
 * @returns {Promise<unknown>}
 */
function sendRuntimeMessage(message) {
	return new Promise((resolve, reject) => {
		try {
			const result = chrome.runtime.sendMessage(message, (response) => {
				if (chrome.runtime.lastError) {
					reject(new Error(chrome.runtime.lastError.message));
					return;
				}
				resolve(response);
			});
			if (result != null && typeof result.catch === "function") {
				result.catch(reject);
			}
		} catch (error) {
			reject(error);
		}
	});
}

/**
 * @returns {Promise<{ ok: true, version: string } | { ok: false, error?: Error }>}
 */
export async function queryLiveExtensionVersion() {
	if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
		return { ok: false };
	}
	try {
		const response = await sendRuntimeMessage({ action: "getExtensionVersion" });
		if (response?.success && typeof response.version === "string") {
			return { ok: true, version: response.version };
		}
		return { ok: false };
	} catch (error) {
		return { ok: false, error: error instanceof Error ? error : new Error(String(error)) };
	}
}

/**
 * Resolves extension asset URLs even when `chrome.runtime` is invalidated.
 * @param {string} path
 * @returns {string | null}
 */
function resolveExtensionAssetUrl(path) {
	try {
		if (typeof chrome !== "undefined" && chrome.runtime?.getURL) {
			return chrome.runtime.getURL(path);
		}
	} catch {
		// Extension context invalidated — fall back to an already-loaded asset URL.
	}
	const existing =
		document.querySelector('link[href^="chrome-extension://"]') ||
		document.querySelector('link[href^="moz-extension://"]') ||
		document.querySelector('script[src^="chrome-extension://"]') ||
		document.querySelector('script[src^="moz-extension://"]');
	const url = existing?.href || existing?.src || "";
	const match = url.match(/^(?:chrome|moz)-extension:\/\/[^/]+/);
	if (!match) {
		return null;
	}
	return `${match[0]}/${path.replace(/^\//, "")}`;
}

/** Inline fallback when modal.css cannot be loaded (e.g. invalidated context). */
const EXTENSION_UPDATE_MODAL_FALLBACK_CSS = `
#overlay-${MODAL_KEY}, #modal-${MODAL_KEY} {
	z-index: 2147483646 !important;
}
#overlay-${MODAL_KEY} {
	position: fixed;
	inset: 0;
	background: rgba(0, 0, 0, 0.5);
}
#modal-${MODAL_KEY} {
	position: fixed;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	min-width: 400px;
	max-width: 80%;
}
#modal-${MODAL_KEY} .modal-container {
	padding: 20px;
	border: 2px solid #424242;
	border-radius: 10px;
	color: #d5d5d5;
	box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
	background-color: #2e2e2e;
}
#modal-${MODAL_KEY} .modal-header-logo-top {
	height: 50px;
	background-size: 100px !important;
	background-position: center 0;
	margin: 0 20px;
}
#modal-${MODAL_KEY} .modal-header-logo-bottom {
	display: flex;
	align-items: flex-end;
	justify-content: space-between;
	height: 60px;
	margin-top: -23px;
	padding-bottom: 10px;
	margin-bottom: 10px;
	background-size: 100px !important;
	background-position: center -50px;
	border-bottom: 1px solid #424242;
}
#modal-${MODAL_KEY} .footer {
	border-top: 1px solid #424242;
	padding-top: 10px;
	display: flex;
	justify-content: center;
	align-items: center;
	gap: 10px;
	flex-wrap: wrap;
}
#modal-${MODAL_KEY} .close-btn .modal-ok {
	background: #424242;
	color: #d5d5d5;
	border: 1px solid #ababab;
	padding: 4px 12px;
	cursor: pointer;
}
#modal-${MODAL_KEY} .vh-extension-update__refresh {
	padding: 10px 22px;
	border: none;
	border-radius: 999px;
	background: #2c8e38;
	color: #fff;
	font-size: 14px;
	font-weight: 600;
	cursor: pointer;
	box-shadow: 0 10px 24px rgba(44, 142, 56, 0.28);
}
#modal-${MODAL_KEY} .vh-extension-update__ignore {
	padding: 10px 18px;
	border: none;
	border-radius: 999px;
	background: transparent;
	color: rgba(213, 213, 213, 0.68);
	font-size: 14px;
	font-weight: 500;
	cursor: pointer;
	text-decoration: underline;
	text-underline-offset: 3px;
}
#modal-${MODAL_KEY} .vh-extension-update__body {
	margin: 0;
	font-size: 15px;
	line-height: 1.6;
}`;

function injectExtensionUpdateModalStyles() {
	if (document.getElementById(MODAL_STYLE_ID)) {
		return;
	}
	const style = document.createElement("style");
	style.id = MODAL_STYLE_ID;
	style.textContent = EXTENSION_UPDATE_MODAL_FALLBACK_CSS;
	(document.head || document.documentElement).appendChild(style);
}

function ensureModalStyles() {
	const href = resolveExtensionAssetUrl("resource/css/modal.css");
	if (href && !document.querySelector(`link[href="${href}"]`)) {
		const link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = href;
		(document.head || document.documentElement).appendChild(link);
	}
	injectExtensionUpdateModalStyles();
}

function removeModal() {
	if (typeof document === "undefined") {
		modalVisible = false;
		return;
	}
	document.getElementById(`overlay-${MODAL_KEY}`)?.remove();
	document.getElementById(`modal-${MODAL_KEY}`)?.remove();
	modalVisible = false;
}

/**
 * @param {string | null} oldVersion
 * @param {string | null} newVersion
 */
function showExtensionUpdateModal(oldVersion, newVersion) {
	if (dismissed || modalVisible || !document.body) {
		return;
	}
	try {
		ensureModalStyles();
	} catch {
		injectExtensionUpdateModalStyles();
	}
	const { title, body } = getExtensionUpdateCopy(oldVersion, newVersion);

	const overlay = document.createElement("div");
	overlay.id = `overlay-${MODAL_KEY}`;
	overlay.className = "overlay";

	const modal = document.createElement("div");
	modal.id = `modal-${MODAL_KEY}`;
	modal.className = "modal";
	modal.setAttribute("role", "dialog");
	modal.setAttribute("aria-modal", "true");
	modal.setAttribute("aria-label", title);

	const dismiss = () => {
		removeModal();
		dismissed = true;
		document.removeEventListener("keydown", onKeyDown);
	};

	const onKeyDown = (event) => {
		if (event.key === "Escape") {
			dismiss();
		}
	};

	const closeButton = document.createElement("button");
	closeButton.type = "button";
	closeButton.className = "modal-ok";
	closeButton.textContent = "X";
	closeButton.setAttribute("aria-label", getMessage("dialogClose", "Close"));
	closeButton.addEventListener("click", () => {
		dismiss();
	});

	const footerClose = document.createElement("button");
	footerClose.type = "button";
	footerClose.className = "vh-extension-update__ignore";
	footerClose.textContent = getMessage("dialogIgnore", "Ignore");
	footerClose.addEventListener("click", () => {
		dismiss();
	});

	const refreshButton = document.createElement("button");
	refreshButton.type = "button";
	refreshButton.className = "vh-extension-update__refresh";
	refreshButton.textContent = getMessage("extensionUpdatedRefresh", "Refresh page");
	refreshButton.addEventListener("click", () => {
		window.location.reload();
	});

	const titleEl = document.createElement("span");
	titleEl.className = "title";
	titleEl.textContent = title;

	const bodyEl = document.createElement("p");
	bodyEl.className = "vh-extension-update__body";
	bodyEl.textContent = body;

	modal.innerHTML = `
		<div class="modal-header-logo-top vh-logo-vh"></div>
		<div class="modal-container">
			<div class="modal-header-logo-bottom vh-logo-vh">
				<span class="title"></span>
				<div class="close-btn"></div>
			</div>
			<div class="content"></div>
			<div class="footer"></div>
		</div>`;

	modal.querySelector(".modal-header-logo-bottom .title")?.replaceWith(titleEl);
	modal.querySelector(".close-btn")?.appendChild(closeButton);
	modal.querySelector(".content")?.appendChild(bodyEl);
	const footer = modal.querySelector(".footer");
	footer?.appendChild(refreshButton);
	footer?.appendChild(footerClose);

	overlay.addEventListener("click", dismiss);
	modal.addEventListener("click", (event) => event.stopPropagation());

	document.body.appendChild(overlay);
	document.body.appendChild(modal);
	document.addEventListener("keydown", onKeyDown);
	modalVisible = true;
}

/**
 * @returns {Promise<void>}
 */
export async function checkExtensionUpdate() {
	if (dismissed || modalVisible) {
		return;
	}
	if (pageVersion == null) {
		pageVersion = readPageExtensionVersion();
	}

	const contextInvalid = !isRuntimeContextValid();
	if (shouldShowExtensionUpdate(pageVersion, null, contextInvalid)) {
		showExtensionUpdateModal(pageVersion, null);
		return;
	}

	const live = await queryLiveExtensionVersion();
	if (live.ok) {
		if (shouldShowExtensionUpdate(pageVersion, live.version, false)) {
			showExtensionUpdateModal(pageVersion, live.version);
		}
		return;
	}

	if (live.error && isExtensionContextInvalidError(live.error)) {
		showExtensionUpdateModal(pageVersion, null);
		return;
	}

	if (!isRuntimeContextValid()) {
		showExtensionUpdateModal(pageVersion, null);
	}
}

/**
 * Polls the service worker for the live extension version and shows a
 * dismissible overlay when this page was loaded with an older build.
 *
 * @param {{ intervalMs?: number }} [options]
 */
export function startExtensionUpdateMonitor(options = {}) {
	if (started || typeof window === "undefined") {
		return;
	}
	started = true;

	pageVersion = readPageExtensionVersion();
	const intervalMs = Number(options.intervalMs) > 0 ? Number(options.intervalMs) : DEFAULT_INTERVAL_MS;

	void checkExtensionUpdate();
	intervalId = window.setInterval(() => {
		void checkExtensionUpdate();
	}, intervalMs);

	contextInvalidatedListener = () => {
		void checkExtensionUpdate();
	};
	window.addEventListener("vh:context-invalidated", contextInvalidatedListener);
}

/**
 * Stops polling. Intended for tests.
 */
export function stopExtensionUpdateMonitor() {
	if (intervalId != null) {
		clearInterval(intervalId);
		intervalId = null;
	}
	if (contextInvalidatedListener != null && typeof window !== "undefined") {
		window.removeEventListener("vh:context-invalidated", contextInvalidatedListener);
		contextInvalidatedListener = null;
	}
	started = false;
	dismissed = false;
	modalVisible = false;
	pageVersion = null;
	removeModal();
}
