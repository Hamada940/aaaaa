/**
 * See Details `<input>` data-* helpers (shared by ItemFactory and notification monitor tiles).
 */

/** Canonical fields — extras from Amazon must not overwrite these when merging. */
const SEE_DETAILS_DATASET_CANONICAL_KEYS = new Set([
	"asin",
	"queue",
	"isParentAsin",
	"isPreRelease",
	"recommendationId",
	"recommendationType",
	"enrollmentGuid",
]);

/**
 * @param {HTMLInputElement | null | undefined} input
 * @returns {Record<string, string>}
 */
function collectExtraSeeDetailsDatasetFromInput(input) {
	if (!input?.dataset) {
		return {};
	}
	/** @type {Record<string, string>} */
	const out = {};
	for (const key of Object.keys(input.dataset)) {
		if (SEE_DETAILS_DATASET_CANONICAL_KEYS.has(key)) {
			continue;
		}
		const v = input.dataset[key];
		if (v !== undefined && v !== null && v !== "") {
			out[key] = v;
		}
	}
	return out;
}

export { collectExtraSeeDetailsDatasetFromInput, SEE_DETAILS_DATASET_CANONICAL_KEYS };
