/** Helper class with function to detect browsers
 *
 */
export function isSafari() {
	return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
}

export function isFirefox() {
	return navigator.userAgent.includes("Firefox");
}

export function isChromium() {
	if (typeof navigator === "undefined") {
		return false;
	}
	const ua = navigator.userAgent || "";
	const hasChromiumToken = /Chrome|Chromium|CriOS/i.test(ua);
	if (!hasChromiumToken) {
		return false;
	}
	// Real Chromium-based browsers report AppleWebKit/537.36. Orion may spoof a Chrome token
	// while reporting a Safari/WebKit engine version (e.g. AppleWebKit/624.x), so exclude those.
	const hasChromiumWebKitSignature = /AppleWebKit\/537\.36/i.test(ua);
	return hasChromiumWebKitSignature;
}

/**
 * Orion (WebKit) — not Chromium; UA may not match {@link isSafari}.
 */
export function isOrionBrowser() {
	if (typeof navigator === "undefined") {
		return false;
	}
	const ua = navigator.userAgent || "";
	if (/Orion/i.test(ua)) {
		return true;
	}
	// iOS Orion can look like plain Safari in UA; use Orion/Kagi-specific globals when present.
	if (typeof window !== "undefined" && ("KAGI" in window || "__ORION__" in window)) {
		return true;
	}
	const brands = Array.isArray(navigator.userAgentData?.brands) ? navigator.userAgentData.brands : [];
	return brands.some((entry) => /Orion|Kagi/i.test(String(entry?.brand || "")));
}

/**
 * WebKit engine browsers excluding Chromium-based ones.
 * Covers Safari and Orion even when brand tokens vary.
 */
export function isWebKitNonChromium() {
	if (typeof navigator === "undefined") {
		return false;
	}
	if (isOrionBrowser()) {
		return true;
	}
	const ua = navigator.userAgent || "";
	return /AppleWebKit/i.test(ua) && !/jsdom/i.test(ua) && !isChromium() && !isFirefox();
}

export function isMobileBrowser() {
	// Check if we're in a browser environment (not service worker)
	if (typeof window === "undefined" || !navigator) {
		return false;
	}
	// Check for touch capability
	const hasTouch = "ontouchstart" in window || navigator.maxTouchPoints > 0;

	// Check for mobile-specific features
	const hasMobileFeatures = "orientation" in window || window.devicePixelRatio > 1 || window.innerWidth <= 768;

	return hasTouch && hasMobileFeatures;
}
