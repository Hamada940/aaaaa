/**
 * Persist per-favourite page rotation state for assisted-load (FAV queue).
 *
 * @module FavouriteCategoryProgress
 */

import { makeFavouriteKey } from "/scripts/core/utils/FavouriteCategoriesManager.js";

/** @type {string} chrome.storage.local key */
export const PROGRESS_STORAGE_KEY = "favouriteCategoryProgress";

/**
 * @typedef {Object} FavouriteCategoryProgress
 * @property {number} currentIndex - Index into `notification.autoload.favouriteCategories`.
 * @property {Record<string, number>} pages - Next page to load per `pn_cn` key.
 */

/**
 * Load rotation progress from chrome.storage.local.
 *
 * @returns {Promise<FavouriteCategoryProgress>}
 *
 * @example
 * const progress = await loadFavouriteProgress();
 * // { currentIndex: 0, pages: { "6948389011_6654958010": 3 } }
 */
export async function loadFavouriteProgress() {
	let stored;
	try {
		stored = await chrome.storage.local.get(PROGRESS_STORAGE_KEY);
	} catch {
		return { currentIndex: 0, pages: {} };
	}
	const raw = stored[PROGRESS_STORAGE_KEY];
	if (!raw || typeof raw !== "object") {
		return { currentIndex: 0, pages: {} };
	}
	return {
		currentIndex: Number.isFinite(raw.currentIndex) ? raw.currentIndex : 0,
		pages: raw.pages && typeof raw.pages === "object" ? { ...raw.pages } : {},
	};
}

/**
 * Save rotation progress.
 *
 * @param {FavouriteCategoryProgress} progress
 * @returns {Promise<void>}
 *
 * @example
 * await saveFavouriteProgress({ currentIndex: 1, pages: { "667823011_99": 2 } });
 */
export async function saveFavouriteProgress(progress) {
	try {
		await chrome.storage.local.set({ [PROGRESS_STORAGE_KEY]: progress });
	} catch {
		/* extension context invalidated */
	}
}

/**
 * Get the next page number to load for a favourite entry.
 *
 * @param {FavouriteCategoryProgress} progress
 * @param {string} pn
 * @param {string} cn
 * @returns {number}
 *
 * @example
 * const page = getNextPageForFavourite(progress, "6948389011", "6654958010");
 * // page === 3 when progress.pages["6948389011_6654958010"] is 3
 */
export function getNextPageForFavourite(progress, pn, cn) {
	const key = makeFavouriteKey(pn, cn);
	const page = progress.pages[key];
	return Number.isFinite(page) && page > 0 ? page : 1;
}

/**
 * Advance rotation after a successful FAV load.
 *
 * @param {FavouriteCategoryProgress} progress
 * @param {Array<{pn: string, cn: string}>} favourites - Ordered favourites list.
 * @param {string} pn - Parent node just loaded.
 * @param {string} cn - Child node just loaded.
 * @param {number} pageLoaded - Page number that was just fetched.
 * @param {number} pageCount - Total pages reported by the listing.
 * @returns {FavouriteCategoryProgress} Updated progress (not yet persisted).
 *
 * @example
 * const next = advanceFavouriteProgress(
 *   progress,
 *   favourites,
 *   "6948389011",
 *   "6654958010",
 *   3,
 *   6
 * );
 * // next.pages["6948389011_6654958010"] becomes 4
 */
export function advanceFavouriteProgress(progress, favourites, pn, cn, pageLoaded, pageCount) {
	const key = makeFavouriteKey(pn, cn);
	const next = {
		currentIndex: progress.currentIndex,
		pages: { ...progress.pages },
	};

	if (pageLoaded < pageCount) {
		next.pages[key] = pageLoaded + 1;
		return next;
	}

	// Finished this subcategory — move to next favourite, reset its page to 1.
	let idx = favourites.findIndex((f) => f.pn === String(pn) && f.cn === String(cn));
	if (idx < 0) idx = progress.currentIndex;
	const nextIndex = (idx + 1) % Math.max(favourites.length, 1);
	next.currentIndex = nextIndex;
	next.pages[key] = 1;
	if (favourites[nextIndex]) {
		const nextKey = makeFavouriteKey(favourites[nextIndex].pn, favourites[nextIndex].cn);
		next.pages[nextKey] = 1;
	}
	return next;
}

/**
 * Drop progress keys that no longer exist after favourites were edited.
 *
 * @param {FavouriteCategoryProgress} progress
 * @param {Array<{pn: string, cn: string}>} favourites
 * @returns {FavouriteCategoryProgress}
 *
 * @example
 * const cleaned = reconcileFavouriteProgress(progress, Settings.get("notification.autoload.favouriteCategories"));
 */
/**
 * Reset rotation to the first favourite, page 1 (used when boost mode starts).
 *
 * @returns {FavouriteCategoryProgress}
 *
 * @example
 * const fresh = resetFavouriteProgress();
 * // { currentIndex: 0, pages: {} }
 */
export function resetFavouriteProgress() {
	return { currentIndex: 0, pages: {} };
}

/**
 * Whether the last page of the final favourite in the list was just loaded.
 *
 * @param {Array<{pn: string, cn: string}>} favourites
 * @param {string} pn
 * @param {string} cn
 * @param {number} pageLoaded
 * @param {number} pageCount
 * @returns {boolean}
 *
 * @example
 * didCompleteFavouriteRun(favourites, "2", "b", 3, 3); // true when "2_b" is the last entry
 */
export function didCompleteFavouriteRun(favourites, pn, cn, pageLoaded, pageCount) {
	if (!favourites.length) return false;
	const last = favourites[favourites.length - 1];
	return String(last.pn) === String(pn) && String(last.cn) === String(cn) && pageLoaded >= pageCount;
}

export function reconcileFavouriteProgress(progress, favourites) {
	const validKeys = new Set(favourites.map((f) => makeFavouriteKey(f.pn, f.cn)));
	const pages = {};
	for (const [key, val] of Object.entries(progress.pages)) {
		if (validKeys.has(key)) pages[key] = val;
	}
	let currentIndex = progress.currentIndex;
	if (favourites.length === 0) {
		currentIndex = 0;
	} else if (currentIndex >= favourites.length) {
		currentIndex = 0;
	}
	return { currentIndex, pages };
}
