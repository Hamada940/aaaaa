/**
 * CRUD helpers for favourite Vine subcategories stored in settings.
 * Each favourite is keyed by parent node (`pn`) + child node (`cn`).
 *
 * @module FavouriteCategoriesManager
 */

const SETTINGS_KEY = "notification.autoload.favouriteCategories";

/** @type {Promise<unknown>} Serializes favourite-category writes to avoid storage races. */
let favouriteWriteChain = Promise.resolve();

/**
 * Run a favourite-categories storage mutation after prior writes complete.
 *
 * @template T
 * @param {() => Promise<T>} task
 * @returns {Promise<T>}
 *
 * @example
 * await enqueueFavouriteWrite(async () => {
 *   await settings.set("notification.autoload.favouriteCategories", nextList);
 * });
 */
function enqueueFavouriteWrite(task) {
	const run = favouriteWriteChain.then(task, task);
	favouriteWriteChain = run.then(
		() => undefined,
		() => undefined
	);
	return run;
}

/**
 * Build a stable storage key for a parent/child browse-node pair.
 *
 * @param {string|number} pn - Parent browse-node id from the Vine URL (`pn` query param).
 * @param {string|number} cn - Child browse-node id from the Vine URL (`cn` query param).
 * @returns {string} Composite key in the form `"pn_cn"`.
 *
 * @example
 * const key = makeFavouriteKey("6948389011", "6654958010");
 * // key === "6948389011_6654958010"
 */
export function makeFavouriteKey(pn, cn) {
	return `${String(pn)}_${String(cn)}`;
}

/**
 * Read the ordered favourite-categories array from settings.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings - Settings manager instance.
 * @returns {Array<{pn: string, cn: string, parentTitle: string, childTitle: string}>}
 *
 * @example
 * const favourites = getFavouriteCategories(Settings);
 * // [{ pn: "6948389011", cn: "6654958010", parentTitle: "Automotive", childTitle: "Replacement Parts" }]
 */
export function getFavouriteCategories(settings) {
	const list = settings.get(SETTINGS_KEY);
	return Array.isArray(list) ? [...list] : [];
}

/**
 * Persist the favourite-categories array.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @param {Array<{pn: string, cn: string, parentTitle: string, childTitle: string}>} list
 * @returns {Promise<void>}
 *
 * @example
 * await saveFavouriteCategories(Settings, [
 *   { pn: "667823011", cn: "123", parentTitle: "Electronics", childTitle: "TV & Video" },
 * ]);
 */
export async function saveFavouriteCategories(settings, list) {
	await settings.set(SETTINGS_KEY, list);
}

/**
 * Check whether a subcategory is already starred.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @param {string|number} pn
 * @param {string|number} cn
 * @returns {boolean}
 *
 * @example
 * if (isFavourite(Settings, "6948389011", "6654958010")) { ... }
 */
export function isFavourite(settings, pn, cn) {
	const list = settings.get(SETTINGS_KEY);
	if (!Array.isArray(list)) return false;
	return list.some((f) => f.pn === String(pn) && f.cn === String(cn));
}

/**
 * Add or remove a favourite subcategory. Returns the updated list.
 * Writes are serialized so multiple stars can be toggled without losing prior selections.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @param {string|number} pn
 * @param {string|number} cn
 * @param {string} parentTitle - Display name of the parent category.
 * @param {string} childTitle - Display name of the subcategory.
 * @returns {Promise<Array<{pn: string, cn: string, parentTitle: string, childTitle: string}>>}
 *
 * @example
 * await toggleFavourite(Settings, "6948389011", "6654958010", "Automotive", "Replacement Parts");
 * await toggleFavourite(Settings, "667823011", "99", "Electronics", "Computers");
 * // Both subcategories remain starred.
 */
export function toggleFavourite(settings, pn, cn, parentTitle, childTitle) {
	return enqueueFavouriteWrite(async () => {
		const pnStr = String(pn);
		const cnStr = String(cn);
		await settings.waitForLoad();
		await settings.refresh();
		const list = getFavouriteCategories(settings);
		const idx = list.findIndex((f) => f.pn === pnStr && f.cn === cnStr);
		const next =
			idx >= 0 ? list.filter((_, i) => i !== idx) : [...list, { pn: pnStr, cn: cnStr, parentTitle, childTitle }];
		await saveFavouriteCategories(settings, next);
		return next;
	});
}

/**
 * Move a favourite up or down in the assisted-load order.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @param {number} index - Zero-based index in the favourites list.
 * @param {-1|1} direction - `-1` moves up, `1` moves down.
 * @returns {Promise<Array<{pn: string, cn: string, parentTitle: string, childTitle: string}>>}
 *
 * @example
 * await moveFavourite(Settings, 2, -1); // swap index 2 with index 1
 */
export function moveFavourite(settings, index, direction) {
	return enqueueFavouriteWrite(async () => {
		await settings.waitForLoad();
		await settings.refresh();
		const list = getFavouriteCategories(settings);
		const target = index + direction;
		if (target < 0 || target >= list.length) return list;
		const next = [...list];
		[next[index], next[target]] = [next[target], next[index]];
		await saveFavouriteCategories(settings, next);
		return next;
	});
}

/**
 * Remove a favourite by list index.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 * @param {number} index
 * @returns {Promise<Array<{pn: string, cn: string, parentTitle: string, childTitle: string}>>}
 *
 * @example
 * await removeFavourite(Settings, 0); // removes the first favourite
 */
export function removeFavourite(settings, index) {
	return enqueueFavouriteWrite(async () => {
		await settings.waitForLoad();
		await settings.refresh();
		const list = getFavouriteCategories(settings);
		if (index < 0 || index >= list.length) return list;
		const next = list.filter((_, i) => i !== index);
		await saveFavouriteCategories(settings, next);
		return next;
	});
}

/**
 * Format a favourite entry for display (`Parent > Child`).
 *
 * @param {{parentTitle: string, childTitle: string}} entry
 * @returns {string}
 *
 * @example
 * formatFavouriteLabel({ parentTitle: "Electronics", childTitle: "TV & Video" });
 * // "Electronics > TV & Video"
 */
export function formatFavouriteLabel(entry) {
	return `${entry.parentTitle} > ${entry.childTitle}`;
}
