/**
 * Resolve the `p` field for `get_info` API requests.
 * Category browse URLs (`pn` / `cn`) and search URLs are not main queue pages, so page is omitted.
 *
 * @param {string} url - Vine listing URL (absolute or relative).
 * @param {number|null|undefined} page - Parsed page number for non-category listings.
 * @returns {number|null}
 *
 * @example
 * getInfoPageParam("https://www.amazon.ca/vine/vine-items?queue=encore&page=2", 2);
 * // 2
 *
 * @example
 * getInfoPageParam("https://www.amazon.ca/vine/vine-items?queue=encore&pn=1&cn=2", 1);
 * // null
 */
export function getInfoPageParam(url, page) {
	try {
		const parsed = new URL(url, "https://www.amazon.com");
		if (parsed.searchParams.has("pn") || parsed.searchParams.has("cn") || parsed.searchParams.has("search")) {
			return null;
		}
	} catch {
		// Fall through to page when URL cannot be parsed.
	}
	return page ?? null;
}

/**
 * True when the Vine URL is browsing an RFY (or other queue) category (`pn` query param).
 * Empty `pn=` is treated as no category (main queue listing).
 *
 * @param {string} url - Vine listing URL (absolute or relative).
 * @returns {boolean}
 *
 * @example
 * isVineCategoryBrowseUrl("https://www.amazon.com/vine/vine-items?queue=potluck&pn=667823011");
 * // true
 *
 * @example
 * isVineCategoryBrowseUrl("https://www.amazon.com/vine/vine-items?queue=potluck");
 * // false
 */
export function isVineCategoryBrowseUrl(url) {
	try {
		const parsed = new URL(url, "https://www.amazon.com");
		const pn = parsed.searchParams.get("pn");
		return pn != null && pn !== "";
	} catch {
		return false;
	}
}
