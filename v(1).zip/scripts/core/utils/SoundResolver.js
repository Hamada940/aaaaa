/*global chrome*/

import {
	createPlaybackObjectUrl,
	getCustomSoundId,
	isCustomSoundValue,
	loadLibrary,
} from "../services/CustomSoundLibrary.js";

function isExtensionPage() {
	try {
		return location.protocol === "chrome-extension:" || location.protocol === "moz-extension:";
	} catch {
		return false;
	}
}

function hasExtensionRuntime() {
	try {
		return typeof chrome !== "undefined" && typeof chrome.runtime?.getURL === "function";
	} catch {
		return false;
	}
}

/**
 * Custom sounds on Amazon-hosted Monitor pages run as extension modules with
 * full chrome.storage access — play blob URLs directly instead of an iframe
 * whose inline script violates MV3 CSP (`script-src 'self'`).
 */
function shouldUseCustomSoundIframe(soundValue) {
	return isCustomSoundValue(soundValue) && !isExtensionPage() && !hasExtensionRuntime();
}

/**
 * Resolve a notification sound setting to an Audio src URL.
 * @param {string} soundValue
 * @returns {Promise<string|null>}
 */
export async function resolveSoundSrc(soundValue) {
	if (!soundValue || soundValue === "0") {
		return null;
	}
	if (isCustomSoundValue(soundValue)) {
		const library = await loadLibrary();
		return createPlaybackObjectUrl(library, soundValue);
	}
	return chrome.runtime.getURL("resource/sound/" + soundValue + ".mp3");
}

function playCustomSoundInExtensionFrame(soundValue, volume) {
	return new Promise((resolve) => {
		const iframe = document.createElement("iframe");
		iframe.hidden = true;
		iframe.setAttribute("aria-hidden", "true");

		const playerUrl = new URL(chrome.runtime.getURL("page/custom_sound_player.html"));
		playerUrl.searchParams.set("sound", soundValue);
		playerUrl.searchParams.set("volume", String(volume));
		iframe.src = playerUrl.href;

		let cleanedUp = false;
		const cleanup = (result) => {
			if (cleanedUp) {
				return;
			}
			cleanedUp = true;
			iframe.remove();
			window.removeEventListener("message", onMessage);
			resolve(result);
		};

		const onMessage = (event) => {
			if (event.data?.type === "vh-custom-sound-ended") {
				cleanup(true);
			}
		};

		window.addEventListener("message", onMessage);
		(document.body || document.documentElement).appendChild(iframe);
		setTimeout(() => cleanup(false), 60000);
	});
}

/**
 * Play a notification sound by setting value.
 * @param {string} soundValue
 * @param {number} volume
 * @returns {Promise<boolean>}
 */
export async function playNotificationSound(soundValue, volume = 1) {
	if (shouldUseCustomSoundIframe(soundValue)) {
		return playCustomSoundInExtensionFrame(soundValue, volume);
	}

	const src = await resolveSoundSrc(soundValue);
	if (!src) {
		return false;
	}

	const audioElement = new Audio(src);
	const handleEnded = () => {
		audioElement.removeEventListener("ended", handleEnded);
		audioElement.removeEventListener("error", handleEnded);
		if (src.startsWith("blob:")) {
			URL.revokeObjectURL(src);
		}
		audioElement.remove();
	};
	audioElement.addEventListener("ended", handleEnded);
	audioElement.addEventListener("error", handleEnded);
	if (volume >= 0 && volume <= 1) {
		audioElement.volume = Number(volume);
	}

	try {
		await audioElement.play();
	} catch (error) {
		handleEnded();
		if (error.name === "NotAllowedError") {
			console.error(
				"VHelper: A sound effect was blocked by the browser because you did not interact with the page."
			);
		}
		return false;
	}
	return true;
}

export { getCustomSoundId, isCustomSoundValue, hasExtensionRuntime, shouldUseCustomSoundIframe };
