export { isPageLogin, isPageCaptcha, isPageDog } from "/scripts/core/amazon/parsers/guards.js";
