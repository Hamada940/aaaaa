import { isMobileBrowser } from "/scripts/core/utils/BrowserDetection.js";

const BANNER_ID = "vh-mobile-boot-error";
const STYLE_ID = "vh-mobile-boot-error-style";

/** @returns {boolean} */
export function shouldShowMobileBootErrors() {
	return isMobileBrowser();
}

/**
 * @param {unknown} error
 * @returns {string}
 */
export function formatBootError(error) {
	if (error == null) {
		return "Unknown error";
	}
	if (typeof error === "string") {
		return error;
	}
	const message = error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error && error.stack ? error.stack.split("\n").slice(0, 8).join("\n") : "";
	return stack ? `${message}\n\n${stack}` : message;
}

/**
 * Show a fixed on-page error banner on mobile (e.g. Orion iOS) where DevTools are unavailable.
 * No-op on desktop; errors are still logged to the console.
 *
 * @param {unknown} error
 * @param {{ source?: string, phase?: string }} [options]
 */
export function showMobileBootError(error, options = {}) {
	const source = options.source || "VHelper";
	const phase = options.phase || "";
	const text = formatBootError(error);

	console.error(`[${source}${phase ? ` / ${phase}` : ""}]`, error);

	if (!shouldShowMobileBootErrors()) {
		return;
	}

	const dedupeKey = `${source}::${phase}::${text}`;
	if (typeof window !== "undefined") {
		window.__VH_MOBILE_BOOT_ERRORS__ = window.__VH_MOBILE_BOOT_ERRORS__ || new Set();
		if (window.__VH_MOBILE_BOOT_ERRORS__.has(dedupeKey)) {
			return;
		}
		window.__VH_MOBILE_BOOT_ERRORS__.add(dedupeKey);
	}

	ensureMobileBootErrorStyles();

	let banner = document.getElementById(BANNER_ID);
	if (!banner) {
		banner = document.createElement("div");
		banner.id = BANNER_ID;
		banner.setAttribute("role", "alert");
		document.documentElement.appendChild(banner);
	}

	const phaseLine = phase ? `<div class="vh-mobile-boot-error-phase">${escapeHtml(phase)}</div>` : "";

	banner.innerHTML = `
		<div class="vh-mobile-boot-error-inner">
			<div class="vh-mobile-boot-error-header">
				<strong class="vh-mobile-boot-error-title">VHelper failed to start</strong>
				<button type="button" class="vh-mobile-boot-error-dismiss" aria-label="Dismiss">×</button>
			</div>
			<div class="vh-mobile-boot-error-source">${escapeHtml(source)}</div>
			${phaseLine}
			<pre class="vh-mobile-boot-error-message"></pre>
		</div>
	`;

	const messageEl = banner.querySelector(".vh-mobile-boot-error-message");
	if (messageEl) {
		messageEl.textContent = text;
	}

	const dismiss = banner.querySelector(".vh-mobile-boot-error-dismiss");
	if (dismiss) {
		dismiss.addEventListener(
			"click",
			() => {
				banner.remove();
			},
			{ once: true }
		);
	}

	mountMobileBootErrorBanner(banner);
}

/**
 * @param {string} label e.g. "bootloader.js"
 * @param {unknown} error
 */
export async function reportMobileLoaderFailure(label, error) {
	console.error(`Error loading ${label}:`, error);
	if (!shouldShowMobileBootErrors()) {
		return;
	}
	try {
		showMobileBootError(error, { source: label, phase: "module import" });
	} catch (reportError) {
		console.error("Failed to show mobile boot error UI:", reportError);
	}
}

/**
 * @param {HTMLElement} banner
 */
function mountMobileBootErrorBanner(banner) {
	const mount = () => {
		const parent = document.body || document.documentElement;
		if (banner.parentNode !== parent) {
			parent.appendChild(banner);
		}
	};

	if (document.body) {
		mount();
	} else {
		document.addEventListener("DOMContentLoaded", mount, { once: true });
	}
}

function ensureMobileBootErrorStyles() {
	if (document.getElementById(STYLE_ID)) {
		return;
	}
	const style = document.createElement("style");
	style.id = STYLE_ID;
	style.textContent = `
#${BANNER_ID} {
	position: fixed;
	left: 0;
	right: 0;
	bottom: 0;
	z-index: 2147483646;
	max-height: 45vh;
	overflow: auto;
	-webkit-overflow-scrolling: touch;
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
	font-size: 13px;
	line-height: 1.35;
	box-sizing: border-box;
	pointer-events: auto;
}
#${BANNER_ID} * {
	box-sizing: border-box;
}
.vh-mobile-boot-error-inner {
	margin: 8px;
	padding: 12px;
	border-radius: 10px;
	border: 2px solid #b91c1c;
	background: #fef2f2;
	color: #1f2937;
	box-shadow: 0 4px 16px rgba(0, 0, 0, 0.25);
}
.vh-mobile-boot-error-header {
	display: flex;
	align-items: flex-start;
	justify-content: space-between;
	gap: 8px;
	margin-bottom: 6px;
}
.vh-mobile-boot-error-title {
	color: #991b1b;
	font-size: 14px;
}
.vh-mobile-boot-error-dismiss {
	flex-shrink: 0;
	border: none;
	background: transparent;
	color: #6b7280;
	font-size: 22px;
	line-height: 1;
	padding: 0 4px;
	cursor: pointer;
}
.vh-mobile-boot-error-source,
.vh-mobile-boot-error-phase {
	font-size: 12px;
	color: #4b5563;
	margin-bottom: 4px;
}
.vh-mobile-boot-error-message {
	margin: 0;
	white-space: pre-wrap;
	word-break: break-word;
	font-size: 11px;
	max-height: 30vh;
	overflow: auto;
	background: rgba(255, 255, 255, 0.7);
	padding: 8px;
	border-radius: 6px;
	border: 1px solid #fecaca;
}
`;
	document.documentElement.appendChild(style);
}

/**
 * @param {string} value
 * @returns {string}
 */
function escapeHtml(value) {
	return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
