/**
 * @fileoverview Compiles VH keyword objects into OpenSearch query clauses (client-side only).
 */

export const MAX_VARIANTS_PER_PATTERN = 32;
export const MAX_CLAUSES = 900;
export const SKIP_REASON_TOO_MANY_VARIANTS = "too_many_variants";
export const SKIP_REASON_UNSUPPORTED = "unsupported";

const EXPAND_TOO_MANY = Symbol("expandTooMany");

const OPTIONAL_TOKENS = [
	{ token: "[ -]?", choices: ["", " ", "-"] },
	{ token: "[- ]?", choices: ["", " ", "-"] },
	{ token: "[ ]?", choices: ["", " "] },
	{ token: "[-]?", choices: ["", "-"] },
	{ token: "[es]?", choices: ["", "es"] },
	{ token: "[s]?", choices: ["", "s"] },
	{ token: "['-]?", choices: ["", "'", "-"] },
	{ token: "[']?", choices: ["", "'"] },
];

const REQUIRED_TOKENS = [
	{ token: "[ -]", choices: [" ", "-"] },
	{ token: "[- ]", choices: [" ", "-"] },
];

export function hasUnsupportedPattern(pattern) {
	if (!pattern || typeof pattern !== "string") {
		return true;
	}
	if (pattern.includes("(?<")) {
		return true;
	}
	if (pattern.includes("(?=") || pattern.includes("(?!")) {
		return true;
	}
	if (/\\[1-9]/.test(pattern)) {
		return true;
	}
	if (/\{\d*,\}/.test(pattern)) {
		return true;
	}
	if (/\[\^/.test(pattern)) {
		return true;
	}
	return false;
}

function unescapeRegexLiterals(segment) {
	return segment.replace(/\\(.)/g, "$1");
}

function splitTopLevelAlternation(pattern) {
	const parts = [];
	let current = "";
	let depth = 0;

	for (let i = 0; i < pattern.length; i++) {
		const ch = pattern[i];
		if (ch === "\\") {
			current += ch + (pattern[i + 1] || "");
			i++;
			continue;
		}
		if (ch === "(") {
			depth++;
			current += ch;
			continue;
		}
		if (ch === ")") {
			depth--;
			current += ch;
			continue;
		}
		if (ch === "|" && depth === 0) {
			parts.push(current);
			current = "";
			continue;
		}
		current += ch;
	}

	parts.push(current);
	return parts;
}

function normalizeExpandedVariants(expanded) {
	const normalized = [...new Set(expanded.map((v) => unescapeRegexLiterals(v)).filter((v) => v.trim().length > 0))];
	if (normalized.length > MAX_VARIANTS_PER_PATTERN) {
		return { variants: null, tooManyVariants: true };
	}
	return {
		variants: normalized.length > 0 ? normalized : null,
		tooManyVariants: false,
	};
}

function expandPatternVariants(pattern) {
	const trimmed = typeof pattern === "string" ? pattern.trim() : "";
	if (!trimmed) {
		return { variants: null, tooManyVariants: false };
	}

	const alternates = splitTopLevelAlternation(trimmed);
	if (alternates.length > 1) {
		const merged = [];
		for (const alternate of alternates) {
			const expansion = expandPatternVariants(alternate.trim());
			if (expansion.tooManyVariants) {
				return { variants: null, tooManyVariants: true };
			}
			if (!expansion.variants) {
				return { variants: null, tooManyVariants: false };
			}
			merged.push(...expansion.variants);
		}
		const unique = [...new Set(merged)];
		if (unique.length > MAX_VARIANTS_PER_PATTERN) {
			return { variants: null, tooManyVariants: true };
		}
		return {
			variants: unique.length > 0 ? unique : null,
			tooManyVariants: false,
		};
	}

	const expanded = expandSingleAlternate(trimmed);
	if (expanded === EXPAND_TOO_MANY) {
		return { variants: null, tooManyVariants: true };
	}
	if (!expanded) {
		return { variants: null, tooManyVariants: false };
	}
	return normalizeExpandedVariants(expanded);
}

function expandInnerToVariants(inner) {
	const trimmed = inner.trim();
	if (!trimmed) {
		return null;
	}

	const expansion = expandPatternVariants(trimmed);
	if (expansion.tooManyVariants) {
		return EXPAND_TOO_MANY;
	}
	return expansion.variants;
}

function expandSingleAlternate(pattern) {
	let variants = [""];
	let i = 0;

	while (i < pattern.length) {
		if (pattern[i] === "\\") {
			const literal = pattern[i + 1] || "";
			if (pattern[i + 2] === "?") {
				const escaped = "\\" + literal;
				const choices = ["", escaped];
				variants = variants.flatMap((v) => choices.map((choice) => v + choice));
				if (variants.length > MAX_VARIANTS_PER_PATTERN) {
					return EXPAND_TOO_MANY;
				}
				i += 3;
				continue;
			}
			variants = variants.map((v) => v + "\\" + literal);
			i += 2;
			continue;
		}

		if (pattern[i] === "(") {
			const end = findMatchingParen(pattern, i);
			if (end === -1) {
				return null;
			}
			const inner = pattern.slice(i + 1, end);
			const isOptional = pattern[end + 1] === "?";

			if (isOptional) {
				const innerVariants = expandInnerToVariants(inner);
				if (innerVariants === EXPAND_TOO_MANY) {
					return EXPAND_TOO_MANY;
				}
				if (!innerVariants) {
					return null;
				}
				const choices = ["", ...innerVariants];
				variants = variants.flatMap((v) => choices.map((choice) => v + choice));
				if (variants.length > MAX_VARIANTS_PER_PATTERN) {
					return EXPAND_TOO_MANY;
				}
				i = end + 2;
				continue;
			}

			const options = splitTopLevelAlternation(inner);
			if (options.length < 2) {
				if (pattern.slice(end + 1).length > 0) {
					return null;
				}
				const innerExpanded = expandSingleAlternate(inner);
				if (innerExpanded === EXPAND_TOO_MANY) {
					return EXPAND_TOO_MANY;
				}
				if (!innerExpanded) {
					return null;
				}
				variants = variants.flatMap((v) => innerExpanded.map((piece) => v + piece));
				if (variants.length > MAX_VARIANTS_PER_PATTERN) {
					return EXPAND_TOO_MANY;
				}
				i = end + 1;
				continue;
			}
			variants = variants.flatMap((v) => options.map((opt) => v + opt));
			if (variants.length > MAX_VARIANTS_PER_PATTERN) {
				return EXPAND_TOO_MANY;
			}
			i = end + 1;
			continue;
		}

		const optionalToken = OPTIONAL_TOKENS.find((entry) => pattern.startsWith(entry.token, i));
		if (optionalToken) {
			variants = variants.flatMap((v) => optionalToken.choices.map((c) => v + c));
			if (variants.length > MAX_VARIANTS_PER_PATTERN) {
				return EXPAND_TOO_MANY;
			}
			i += optionalToken.token.length;
			continue;
		}

		const requiredToken = REQUIRED_TOKENS.find((entry) => pattern.startsWith(entry.token, i));
		if (requiredToken) {
			variants = variants.flatMap((v) => requiredToken.choices.map((c) => v + c));
			if (variants.length > MAX_VARIANTS_PER_PATTERN) {
				return EXPAND_TOO_MANY;
			}
			i += requiredToken.token.length;
			continue;
		}

		if (pattern[i] === "[") {
			return null;
		}

		const ch = pattern[i];
		variants = variants.map((v) => v + ch);
		i++;
	}

	return variants;
}

function findMatchingParen(pattern, openIndex) {
	let depth = 0;
	for (let i = openIndex; i < pattern.length; i++) {
		if (pattern[i] === "\\") {
			i++;
			continue;
		}
		if (pattern[i] === "(") {
			depth++;
		} else if (pattern[i] === ")") {
			depth--;
			if (depth === 0) {
				return i;
			}
		}
	}
	return -1;
}

function textToTitleClause(text) {
	const normalized = text.trim();
	if (!normalized) {
		return null;
	}
	if (/\s/.test(normalized) || /[.'"]/.test(normalized)) {
		return { match_phrase: { title: normalized } };
	}
	return { match: { title: normalized } };
}

function variantsToClause(variants) {
	const clauses = variants.map(textToTitleClause).filter(Boolean);
	if (clauses.length === 0) {
		return null;
	}
	if (clauses.length === 1) {
		return clauses[0];
	}
	return {
		bool: {
			should: clauses,
			minimum_should_match: 1,
		},
	};
}

function compileSegmentMeta(segment) {
	const trimmed = segment.trim();
	if (!trimmed) {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}

	const expansion = expandPatternVariants(trimmed);
	if (expansion.tooManyVariants) {
		return { clause: null, skipReason: SKIP_REASON_TOO_MANY_VARIANTS };
	}
	if (!expansion.variants) {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}
	return { clause: variantsToClause(expansion.variants), skipReason: null };
}

function compileSegment(segment) {
	return compileSegmentMeta(segment).clause;
}

function compileContainsPatternMeta(pattern) {
	if (!pattern || typeof pattern !== "string") {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}
	const trimmed = pattern.trim();
	if (!trimmed) {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}
	if (hasUnsupportedPattern(trimmed)) {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}

	if (trimmed.includes(".*")) {
		const segments = trimmed
			.split(".*")
			.map((s) => s.trim())
			.filter(Boolean);
		if (segments.length === 0) {
			return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
		}
		const results = segments.map((segment) => compileSegmentMeta(segment));
		if (results.some((result) => result.skipReason === SKIP_REASON_TOO_MANY_VARIANTS)) {
			return { clause: null, skipReason: SKIP_REASON_TOO_MANY_VARIANTS };
		}
		const mustClauses = results.map((result) => result.clause).filter(Boolean);
		if (mustClauses.length !== segments.length) {
			return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
		}
		if (mustClauses.length === 1) {
			return { clause: mustClauses[0], skipReason: null };
		}
		return {
			clause: {
				bool: {
					must: mustClauses,
				},
			},
			skipReason: null,
		};
	}

	return compileSegmentMeta(trimmed);
}

export function compileContainsPattern(pattern) {
	return compileContainsPatternMeta(pattern).clause;
}

function parseWithoutTerms(without) {
	if (!without || typeof without !== "string") {
		return [];
	}
	return without
		.split("|")
		.map((t) => t.trim())
		.filter(Boolean);
}

function isEffectivelySet(value) {
	return value !== undefined && value !== null && value !== "";
}

function buildEtvFilters(keyword) {
	const filters = [];
	if (isEffectivelySet(keyword.etv_min)) {
		const minValue = Number(keyword.etv_min);
		if (!Number.isNaN(minValue)) {
			filters.push({ range: { etv: { gte: minValue } } });
		}
	}
	if (isEffectivelySet(keyword.etv_max)) {
		const maxValue = Number(keyword.etv_max);
		if (!Number.isNaN(maxValue)) {
			filters.push({ range: { etv: { lte: maxValue } } });
		}
	}
	return filters;
}

function compileWithoutClauses(without) {
	const terms = parseWithoutTerms(without);
	const clauses = [];
	for (const term of terms) {
		const clause = compileContainsPattern(term);
		if (clause) {
			clauses.push(clause);
		} else {
			const fallback = textToTitleClause(unescapeRegexLiterals(term));
			if (fallback) {
				clauses.push(fallback);
			}
		}
	}
	return clauses;
}

export function compileKeywordObject(keyword) {
	if (!keyword || typeof keyword !== "object") {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}

	const contains = typeof keyword.contains === "string" ? keyword.contains.trim() : "";
	const without = typeof keyword.without === "string" ? keyword.without.trim() : "";
	const etvFilters = buildEtvFilters(keyword);
	const mustNot = compileWithoutClauses(without);

	if (!contains) {
		return { clause: null, skipReason: SKIP_REASON_UNSUPPORTED };
	}

	const containsResult = compileContainsPatternMeta(contains);
	if (!containsResult.clause) {
		return { clause: null, skipReason: containsResult.skipReason };
	}

	const boolClause = {
		bool: {
			must: [containsResult.clause],
		},
	};

	if (mustNot.length > 0) {
		boolClause.bool.must_not = mustNot;
	}
	if (etvFilters.length > 0) {
		boolClause.bool.filter = etvFilters;
	}

	return { clause: boolClause, skipReason: null };
}

/**
 * Collects keywords from enabled groups of the given type, preserving group order.
 * @param {object[]} groups
 * @param {"highlight"|"hide"|"blur"} type
 * @returns {object[]}
 */
export function collectKeywordsFromEnabledGroups(groups, type, groupIds = null) {
	if (!Array.isArray(groups)) {
		return [];
	}

	const selectedIds = Array.isArray(groupIds) ? new Set(groupIds) : null;
	const keywords = [];

	for (const group of groups) {
		if (group.enabled === false || group.type !== type) {
			continue;
		}
		if (selectedIds && !selectedIds.has(group.id)) {
			continue;
		}
		if (!Array.isArray(group.keywords)) {
			continue;
		}
		for (const keyword of group.keywords) {
			if (typeof keyword === "string") {
				keywords.push({ contains: keyword });
			} else if (keyword && typeof keyword === "object") {
				keywords.push(keyword);
			}
		}
	}

	return keywords;
}

/**
 * Compiles enabled keyword groups of the given type into OpenSearch filter clauses.
 * @param {object[]} groups
 * @param {"highlight"|"hide"|"blur"} type
 * @param {string[]|null} [groupIds=null] When set, only keywords from these group ids are included.
 * @returns {{ clauses: object[], skipped: string[] }}
 */
export function compileKeywordGroupsFilter(groups, type, groupIds = null) {
	return compileKeywordFilter(collectKeywordsFromEnabledGroups(groups, type, groupIds));
}

/**
 * Compiles keyword objects into OpenSearch filter clauses.
 * @param {object[]} keywords
 * @returns {{ clauses: object[], skipped: string[], skippedTooManyVariants: string[] }}
 */
export function compileKeywordFilter(keywords) {
	if (!Array.isArray(keywords)) {
		return { clauses: [], skipped: [], skippedTooManyVariants: [] };
	}

	const clauses = [];
	const skipped = [];
	const skippedTooManyVariants = [];

	for (const keyword of keywords) {
		const contains = typeof keyword?.contains === "string" ? keyword.contains.trim() : "";
		if (!contains) {
			continue;
		}

		if (clauses.length >= MAX_CLAUSES) {
			skipped.push(contains);
			continue;
		}

		const result = compileKeywordObject(keyword);
		if (result.clause) {
			clauses.push(result.clause);
		} else if (result.skipReason === SKIP_REASON_TOO_MANY_VARIANTS) {
			skippedTooManyVariants.push(contains);
		} else {
			skipped.push(contains);
		}
	}

	return {
		clauses,
		skipped: [...new Set(skipped)],
		skippedTooManyVariants: [...new Set(skippedTooManyVariants)],
	};
}

export default compileKeywordFilter;
