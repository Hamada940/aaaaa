const DEFAULT_START = { hour: 0, minute: 0 };
const DEFAULT_END = { hour: 23, minute: 59 };

/**
 * @param {string|null|undefined} timeStr
 * @param {{ hour: number, minute: number }} [fallback]
 * @returns {{ hour: number, minute: number }}
 */
export function parseAutoloadTime(timeStr, fallback = DEFAULT_START) {
	const [rawHour, rawMinute] = (timeStr || `${fallback.hour}:${String(fallback.minute).padStart(2, "0")}`)
		.split(":")
		.map(Number);
	const hour = Math.max(0, Math.min(24, Number.isFinite(rawHour) ? rawHour : fallback.hour));
	const minute = Math.max(0, Math.min(59, Number.isFinite(rawMinute) ? rawMinute : fallback.minute));
	return { hour, minute };
}

/**
 * @param {string} hourStart
 * @param {string} hourEnd
 * @param {{ startFallback?: { hour: number, minute: number }, endFallback?: { hour: number, minute: number } }} [fallbacks]
 * @returns {number}
 */
export function getAutoloadWindowDurationHours(hourStart, hourEnd, fallbacks = {}) {
	const start = parseAutoloadTime(hourStart, fallbacks.startFallback ?? DEFAULT_START);
	const end = parseAutoloadTime(hourEnd, fallbacks.endFallback ?? DEFAULT_END);
	const startMins = start.hour * 60 + start.minute;
	const endMins = end.hour * 60 + end.minute;
	let diffMins = endMins - startMins;
	if (diffMins <= 0) {
		diffMins += 24 * 60;
	}
	return diffMins / 60;
}

/**
 * @param {string} hourStart
 * @param {string} hourEnd
 * @param {Date} [now]
 * @param {{ startFallback?: { hour: number, minute: number }, endFallback?: { hour: number, minute: number } }} [fallbacks]
 * @returns {boolean}
 */
export function isAutoloadTimeWithinRange(hourStart, hourEnd, now = new Date(), fallbacks = {}) {
	const start = new Date(now);
	const { hour: startHour, minute: startMinute } = parseAutoloadTime(
		hourStart,
		fallbacks.startFallback ?? DEFAULT_START
	);
	start.setHours(startHour, startMinute, 0, 0);

	const end = new Date(now);
	const { hour: endHour, minute: endMinute } = parseAutoloadTime(hourEnd, fallbacks.endFallback ?? DEFAULT_END);
	end.setHours(endHour, endMinute, 0, 0);

	const hours = getAutoloadWindowDurationHours(hourStart, hourEnd, fallbacks);
	if (hours < 8) {
		start.setHours(0, 0, 0, 0);
		end.setHours(23, 59, 0, 0);
	}

	if (start > end) {
		if (now <= end) {
			start.setDate(start.getDate() - 1);
		} else if (now >= start) {
			end.setDate(end.getDate() + 1);
		}
	}

	return now >= start && now <= end;
}
