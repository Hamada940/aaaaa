/* global chrome */

import { getMessage } from "/scripts/core/services/Internationalization.js";
import { getMinutesUsed } from "/scripts/core/utils/MetricStorage.js";

export const SUPPORT_PROMPT_INTERVAL_MS = 720 * 60 * 60 * 1000;
export const SUPPORT_PROMPT_STORAGE_KEY = "supportPrompt";
const MODAL_KEY = "support-prompt";
const MODAL_STYLE_ID = "vh-support-prompt-modal-style";
const DEFAULT_RETRY_MS = 2000;
const MAX_RETRIES = 8;

let modalVisible = false;
let scheduled = false;

/**
 * @param {unknown} tier
 * @param {number | null | undefined} hiddenUntil
 * @param {number} [now]
 * @returns {boolean}
 */
export function shouldShowSupportPrompt(tier, hiddenUntil, now = Date.now()) {
	if ((parseInt(tier, 10) || 0) !== 0) {
		return false;
	}
	if (!hiddenUntil || hiddenUntil <= 0) {
		return true;
	}
	return now >= hiddenUntil;
}

/**
 * @param {number} minutesUsed
 * @returns {{ days: number, hours: number }}
 */
export function computeUsageDaysAndHours(minutesUsed) {
	const total = Math.max(0, Math.floor(Number(minutesUsed) || 0));
	return {
		days: Math.floor(total / 1440),
		hours: Math.floor((total % 1440) / 60),
	};
}

/**
 * @param {number} days
 * @param {number} hours
 * @returns {{ title: string, usage: string, body: string, premiumLabel: string, hideLabel: string }}
 */
export function getSupportPromptCopy(days, hours) {
	return {
		title: getMessage("supportPromptTitle", "Thank you for using VHelper"),
		usage: getMessage("supportPromptUsage", "You've actively used VH for $1$ Days, $2$ Hours.", [
			String(days),
			String(hours),
		]),
		body: getMessage(
			"supportPromptBody",
			"I'm glad you're enjoying it! It takes a lot of efforts to maintain, support and improve such a project. If you have the means, please consider supporting VH by checking the Premium section of VH's settings."
		),
		premiumLabel: getMessage("supportPromptOpenPremium", "Open Premium settings"),
		hideLabel: getMessage("supportPromptHide30Days", "Hide for 30 days"),
	};
}

/**
 * @param {number} [now]
 * @returns {number}
 */
export function nextSupportPromptHiddenUntil(now = Date.now()) {
	return now + SUPPORT_PROMPT_INTERVAL_MS;
}

/**
 * @returns {Promise<number>}
 */
export async function readSupportPromptHiddenUntil() {
	const data = await chrome.storage.local.get(SUPPORT_PROMPT_STORAGE_KEY);
	const rec = data[SUPPORT_PROMPT_STORAGE_KEY];
	const hiddenUntil = rec?.hiddenUntil;
	return typeof hiddenUntil === "number" && Number.isFinite(hiddenUntil) ? hiddenUntil : 0;
}

/**
 * @param {number} [now]
 * @returns {Promise<void>}
 */
export async function snoozeSupportPrompt(now = Date.now()) {
	await chrome.storage.local.set({
		[SUPPORT_PROMPT_STORAGE_KEY]: { hiddenUntil: nextSupportPromptHiddenUntil(now) },
	});
}

/**
 * @returns {boolean}
 */
export function isBlockingModalVisible() {
	if (typeof document === "undefined") {
		return false;
	}
	return Array.from(document.querySelectorAll(".modal")).some((modal) => {
		if (modal.id === `modal-${MODAL_KEY}`) {
			return false;
		}
		const style = window.getComputedStyle(modal);
		return style.display !== "none" && style.visibility !== "hidden";
	});
}

function ensureModalStyles() {
	const href = chrome.runtime.getURL("resource/css/modal.css");
	if (!document.querySelector(`link[href="${href}"]`)) {
		const link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = href;
		(document.head || document.documentElement).appendChild(link);
	}
	if (!document.getElementById(MODAL_STYLE_ID)) {
		const style = document.createElement("style");
		style.id = MODAL_STYLE_ID;
		style.textContent = `
#overlay-${MODAL_KEY}, #modal-${MODAL_KEY} {
	z-index: 2147483645 !important;
}`;
		(document.head || document.documentElement).appendChild(style);
	}
}

function removeModal() {
	if (typeof document === "undefined") {
		modalVisible = false;
		return;
	}
	document.getElementById(`overlay-${MODAL_KEY}`)?.remove();
	document.getElementById(`modal-${MODAL_KEY}`)?.remove();
	modalVisible = false;
}

/**
 * @param {number} days
 * @param {number} hours
 * @param {() => void | Promise<void>} onHide
 */
function showSupportPromptModal(days, hours, onHide) {
	if (modalVisible || !document.body) {
		return;
	}

	ensureModalStyles();
	const { title, usage, body, premiumLabel, hideLabel } = getSupportPromptCopy(days, hours);
	const premiumUrl = chrome.runtime.getURL("page/settings.html#premium");

	const overlay = document.createElement("div");
	overlay.id = `overlay-${MODAL_KEY}`;
	overlay.className = "overlay";

	const modal = document.createElement("div");
	modal.id = `modal-${MODAL_KEY}`;
	modal.className = "modal";
	modal.style.minWidth = "320px";
	modal.style.maxWidth = "min(520px, 92vw)";
	modal.setAttribute("role", "dialog");
	modal.setAttribute("aria-modal", "true");
	modal.setAttribute("aria-label", title);

	const dismiss = async () => {
		removeModal();
		document.removeEventListener("keydown", onKeyDown);
		await onHide();
	};

	const onKeyDown = (event) => {
		if (event.key === "Escape") {
			void dismiss();
		}
	};

	const closeButton = document.createElement("button");
	closeButton.type = "button";
	closeButton.className = "modal-ok";
	closeButton.textContent = "X";
	closeButton.setAttribute("aria-label", getMessage("dialogClose", "Close"));
	closeButton.addEventListener("click", () => {
		void dismiss();
	});

	const hideButton = document.createElement("button");
	hideButton.type = "button";
	hideButton.className = "vh-support-prompt__hide";
	hideButton.textContent = hideLabel;
	hideButton.addEventListener("click", () => {
		void dismiss();
	});

	const premiumLink = document.createElement("a");
	premiumLink.className = "vh-support-prompt__premium";
	premiumLink.href = premiumUrl;
	premiumLink.target = "_blank";
	premiumLink.rel = "noopener";
	premiumLink.textContent = premiumLabel;

	modal.innerHTML = `
		<div class="modal-header-logo-top vh-logo-vh"></div>
		<div class="modal-container vh-support-prompt">
			<div class="modal-header-logo-bottom vh-logo-vh">
				<span class="title"></span>
				<div class="close-btn"></div>
			</div>
			<div class="content">
				<div class="vh-support-prompt__inner">
					<p class="vh-support-prompt__usage"></p>
					<div class="vh-support-prompt__metrics" aria-hidden="true">
						<div class="vh-support-prompt__metric">
							<span class="vh-support-prompt__metric-value" data-metric="days"></span>
							<span class="vh-support-prompt__metric-label">${getMessage("pageSettingsPremiumUnitDays", "day(s)")}</span>
						</div>
						<div class="vh-support-prompt__metric">
							<span class="vh-support-prompt__metric-value" data-metric="hours"></span>
							<span class="vh-support-prompt__metric-label">${getMessage("pageSettingsPremiumUnitHours", "hour(s)")}</span>
						</div>
					</div>
					<p class="vh-support-prompt__body"></p>
					<div class="vh-support-prompt__actions"></div>
				</div>
			</div>
			<div class="footer vh-support-prompt__footer"></div>
		</div>`;

	const titleEl = modal.querySelector(".modal-header-logo-bottom .title");
	if (titleEl) {
		titleEl.textContent = title;
	}
	modal.querySelector(".close-btn")?.appendChild(closeButton);
	modal.querySelector(".vh-support-prompt__usage").textContent = usage;
	modal.querySelector('[data-metric="days"]').textContent = String(days);
	modal.querySelector('[data-metric="hours"]').textContent = String(hours);
	modal.querySelector(".vh-support-prompt__body").textContent = body;
	modal.querySelector(".vh-support-prompt__actions")?.appendChild(premiumLink);
	modal.querySelector(".vh-support-prompt__footer")?.appendChild(hideButton);

	overlay.addEventListener("click", () => {
		void dismiss();
	});
	modal.addEventListener("click", (event) => event.stopPropagation());

	document.body.appendChild(overlay);
	document.body.appendChild(modal);
	document.addEventListener("keydown", onKeyDown);
	modalVisible = true;
}

/**
 * @param {{ get: (path: string) => unknown }} settingsMgr
 * @param {{ retryMs?: number, retriesLeft?: number }} [options]
 * @returns {Promise<void>}
 */
export async function maybeShowSupportPrompt(settingsMgr, options = {}) {
	if (modalVisible || typeof document === "undefined" || !document.body) {
		return;
	}

	const tier = parseInt(settingsMgr.get("general.patreon.tier"), 10) || 0;
	const hiddenUntil = await readSupportPromptHiddenUntil();
	if (!shouldShowSupportPrompt(tier, hiddenUntil)) {
		return;
	}

	const retryMs = Number(options.retryMs) > 0 ? Number(options.retryMs) : DEFAULT_RETRY_MS;
	const retriesLeft = Number.isInteger(options.retriesLeft) ? options.retriesLeft : MAX_RETRIES;
	if (isBlockingModalVisible()) {
		if (retriesLeft > 0) {
			window.setTimeout(() => {
				void maybeShowSupportPrompt(settingsMgr, { retryMs, retriesLeft: retriesLeft - 1 });
			}, retryMs);
		}
		return;
	}

	const minutesUsed = await getMinutesUsed(settingsMgr);
	const { days, hours } = computeUsageDaysAndHours(minutesUsed);
	showSupportPromptModal(days, hours, () => snoozeSupportPrompt());
}

/**
 * Schedules the support prompt check after boot, with retries when other modals are open.
 *
 * @param {{ get: (path: string) => unknown }} settingsMgr
 * @param {{ delayMs?: number }} [options]
 */
export function scheduleSupportPromptCheck(settingsMgr, options = {}) {
	if (scheduled || typeof window === "undefined") {
		return;
	}
	scheduled = true;

	const delayMs = Number(options.delayMs) >= 0 ? Number(options.delayMs) : 1500;
	window.setTimeout(() => {
		void maybeShowSupportPrompt(settingsMgr);
	}, delayMs);
}

/**
 * Stops any visible prompt. Intended for tests.
 */
export function resetSupportPromptState() {
	scheduled = false;
	removeModal();
}
