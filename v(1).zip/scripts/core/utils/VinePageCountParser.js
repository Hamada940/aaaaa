/**
 * @module VinePageCountParser
 * Re-exports from central amazon parsers.
 */
export { getPageCount } from "/scripts/core/amazon/parsers/pagination.js";
