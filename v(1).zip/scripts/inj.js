const origFetch = window.fetch;
var extHelper_LastParentVariant = null;
var extHelper_responseData = {};
var extHelper_postData = {};

const scriptTag = document.currentScript;
const countryCode = scriptTag.getAttribute("data-country-code");

window.fetch = async (...args) => {
	let response = await origFetch(...args);
	let lastParent = extHelper_LastParentVariant;
	let lastParentAsin = null;
	let regex = null;

	const url = args[0] || "";

	if (lastParent != null) {
		regex = /^.+?#(.+?)#.+$/;
		lastParentAsin = extHelper_LastParentVariant.recommendationId.match(regex)[1];
	}

	//Voice Orders API
	if (url.startsWith("api/voiceOrders")) {
		extHelper_postData = JSON.parse(args[1].body);
		const asin = extHelper_postData.itemAsin;

		try {
			extHelper_responseData = await response.clone().json();
		} catch (e) {
			console.error(e);
		}

		let data = {};
		if (extHelper_responseData.error !== null) {
			window.postMessage(
				{
					type: "order",
					data: {
						status: "failed",
						error: extHelper_responseData.error, //CROSS_BORDER_SHIPMENT, SCHEDULED_DELIVERY_REQUIRED, ITEM_NOT_IN_ENROLLMENT, ITEM_ALREADY_ORDERED
						parent_asin: lastParentAsin,
						asin: asin,
					},
				},
				"/" //message should be sent to the same origin as the current document.
			);
		} else if (
			extHelper_responseData.result?.offerListingId !== undefined &&
			extHelper_responseData.result?.offerListingId !== null
		) {
			//Amazon checkout process
			window.postMessage(
				{
					type: "offerListingId",
					offerListingId: extHelper_responseData.result.offerListingId,
				},
				"/" //message should be sent to the same origin as the current document.
			);
		} else {
			//Old vine checkout process
			if (extHelper_responseData.result?.orderId) {
				data = {
					status: "success",
					error: null,
					//orderId: extHelper_responseData.result.orderId,
					parent_asin: lastParentAsin,
					asin: asin,
				};
			} else {
				data = {
					status: "failed",
					error: "No orderId received back. Refreshing the notifications monitor may help.",
					parent_asin: lastParentAsin,
					asin: asin,
				};
			}
			window.postMessage(
				{
					type: "order",
					data,
				},
				"/" //message should be sent to the same origin as the current document.
			);
		}

		//Wait 500ms following an order to allow for the order report query to go through before the redirect happens.
		await new Promise((r) => setTimeout(r, 500));
		return response;
	}

	//See Details modal window
	regex = /^api\/recommendations\/.*$/;
	let parent_asin = null;
	let enrollment_guid = null;
	if (url.startsWith("api/recommendations")) {
		try {
			extHelper_responseData = await response.clone().json();
		} catch (e) {
			console.error(e);
		}

		//Extract the parent_asin and enrollment_guid from the URL
		//ie (AI).: /api/recommendations/AASDFSDAFASFD%23B0FHQVR8MP%23vine.enrollment.7a6eb8c7-7557-49d7-b4b7-45480ba3c689/item/B0FHQN1Q4Z?imageSize=180
		//ie (RFY): /api/recommendations/AASDFSDAFASFD%23B0FNLPFPQF%23AASDFSDAFASFD%23vine.enrollment.209d886d-0462-4e51-b230-39500a3dae00/item/B0FKMDP3WD?imageSize=180
		const url_regex = /^api\/recommendations\/(?:.+?)%23(.+?)(?:%23[^%]+)?%23vine\.enrollment\.(.+?)\/.+$/;
		const url_match = url.match(url_regex);
		if (url_match) {
			parent_asin = url_match[1];
			enrollment_guid = url_match[2];
		}

		let { result, error } = extHelper_responseData;

		if (result === null) {
			let regex;
			let arrMatch;
			let asin = null;

			regex = new RegExp(`.*/item/([^?]+)`);
			arrMatch = url.match(regex);

			if (arrMatch) {
				asin = arrMatch[1];
			} else {
				//Alternative method when the asin is not in the url
				regex = new RegExp(`.+#([^#]+)#.+`);
				arrMatch = error.message.match(regex);
				if (arrMatch) {
					asin = arrMatch[1];
				}
			}
			if (asin) {
				window.postMessage(
					{
						type: "error",
						data: {
							errorType: error.exceptionType,
							error: error.message,
							asin: asin,
						},
					},
					"/" //message should be sent to the same origin as the current document.
				);
			}
			return response;
		}

		//There are 2 requests which occur back to back:
		// 1. The variations request (will only happen if is-parent-asin is true)
		// 2. The ETV & product info request

		if (result.variations !== undefined) {
			//The item has variations and so is a parent, get the bootloader to store them as we are still awaiting the ETV.
			extHelper_LastParentVariant = result;
			regex = /^.+?#(.+?)#.+$/;
			let arrMatchesP = result.recommendationId.match(regex);
			result.parent_asin = arrMatchesP[1];
			window.postMessage(
				{
					type: "variations",
					asin: result.parent_asin,
					data: result.variations,
				},
				"/" //message should be sent to the same origin as the current document.
			);
		} else if (result.taxValue !== undefined) {
			// We received an ETV value, send the info to the bootloader
			// ... which will add the previously stored variants, if applicable and send the data to the server.
			const isChild = parent_asin !== result.asin;
			let data = {
				title: result.productTitle,
				thumbnail: result.imageUrl,
				parent_asin: isChild ? parent_asin : null,
				enrollment_guid: enrollment_guid,
				asin: result.asin,
				etv: result.taxValue,
			};
			if (!isChild) {
				extHelper_LastParentVariant = null;
			}
			window.postMessage(
				{
					type: "etv",
					data,
				},
				"/" //message should be sent to the same origin as the current document.
			);
		}

		//Amazon checkout process
		if (result.promotionId !== undefined) {
			window.postMessage(
				{
					type: "promotionId",
					promotionId: result.promotionId,
					asin: result.asin,
					parent_asin: lastParentAsin,
				},
				"/" //message should be sent to the same origin as the current document.
			);
		}

		//Fix broken variants causing infinite loop
		let fixed = 0;
		let arrKeyNames = [];

		//Make the list of all keys/dimensions accross all variants:
		//Ensure the key for each dimension exist for all the variations:
		if (result.variations) {
			for (const variation of result.variations) {
				for (const key in variation.dimensions) {
					if (!arrKeyNames.includes(key)) {
						arrKeyNames.push(key);
					}
				}
			}
		}

		result.variations = result.variations?.map((variation) => {
			if (Object.keys(variation.dimensions || {}).length === 0) {
				variation.dimensions = {
					asin_no: variation.asin,
				};
				fixed++;
				return variation;
			}

			//Check if all the variations contain all the key names
			if (arrKeyNames.length > 0) {
				for (const key of arrKeyNames) {
					if (!variation.dimensions[key]) {
						variation.dimensions[key] = "VH FIX";
						fixed++;
					}
				}
			}

			for (const key in variation.dimensions) {
				//If the country code is not jp or si:
				if (countryCode !== "jp" && countryCode !== "sg") {
					//Replace all non-standard characters
					newValue = variation.dimensions[key].replace(/[^a-zA-Z0-9\][(){}/.,\-"'¼½¾+&%# ]/g, "_");
					if (newValue !== variation.dimensions[key]) {
						variation.dimensions[key] = newValue;
						fixed++;
					}
				}

				//Escape the key for CSS
				/*
				newValue = CSS.escape(newValue);
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}
				*/

				//& without a space after it will crash, add a space after it.
				newValue = variation.dimensions[key].replace(/[&]([^\s])/g, "& $1");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				//Escape the special characters
				newValue = variation.dimensions[key].replace(/[/\\()[\]{}]/g, "\\$&");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// Remove apostrophes / single quotes which can break jQuery selectors
				newValue = variation.dimensions[key].replace(/'+/g, "");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// Normalize comma-separated lists to ensure a space after commas
				newValue = variation.dimensions[key].replace(/,\s*/g, ", ");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// Any variation ending with a space will crash, ensure there is no space at the end.
				newValue = variation.dimensions[key].replace(/\s+$/g, "");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// The core of the issue is when a special character is at the end of a variation, the jQuery UI which amazon uses will attempt to evaluate it and fail since it attempts to utilize it as part of an html attribute.
				// In order to resolve this, we make the string safe for an html attribute by escaping the special characters.
				if (!variation.dimensions[key].match(/[a-z0-9)\]]$/i)) {
					variation.dimensions[key] = variation.dimensions[key] + ` VH${fixed}`;
					fixed++;
				}

				// Any variation with a : or ) without a space after will crash, ensure : always has a space after.
				newValue = variation.dimensions[key].replace(/([:)])([^\s])/g, "$1 $2");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// Any variation with a ( with a space after will crash, ensure never has a space after.
				newValue = variation.dimensions[key].replace(/([(])\s/g, "$1");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// Any variation with a / with a space before it will crash, remove the space before.
				newValue = variation.dimensions[key].replace(/(\s[/])/g, "/");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}

				// Any variation with a | by ;.
				newValue = variation.dimensions[key].replace(/([|])/g, "-");
				if (newValue !== variation.dimensions[key]) {
					variation.dimensions[key] = newValue;
					fixed++;
				}
				//variation.dimensions[key] = fixed++ + "test | test| test |test#";
			}

			return variation;
		});

		// Ensure no two variations share identical dimension names and values (breaks Amazon's variant UI).
		if (result.variations) {
			const dimensionSignature = (dim) =>
				JSON.stringify(
					Object.keys(dim)
						.sort()
						.map((k) => [k, dim[k]])
				);
			const sigToIndices = new Map();
			for (let i = 0; i < result.variations.length; i++) {
				const dim = result.variations[i].dimensions || {};
				const sig = dimensionSignature(dim);
				if (!sigToIndices.has(sig)) {
					sigToIndices.set(sig, []);
				}
				sigToIndices.get(sig).push(i);
			}
			for (const indices of sigToIndices.values()) {
				if (indices.length < 2) {
					continue;
				}
				for (let n = 1; n < indices.length; n++) {
					const v = result.variations[indices[n]];
					const keys = Object.keys(v.dimensions).sort();
					const targetKey = keys[keys.length - 1];
					v.dimensions[targetKey] = `${v.dimensions[targetKey]} VH${n}`;
					fixed++;
				}
			}
		}

		if (fixed > 0) {
			window.postMessage(
				{
					type: "infiniteWheelFixed",
					text: fixed + " variation(s) fixed.",
				},
				"/" //message should be sent to the same origin as the current document.
			);
		}

		return new Response(JSON.stringify(extHelper_responseData));
	}

	return response;
};

//Send the opts options containing the customerId and obfuscatedMarketId
/*
if (typeof opts !== "undefined") {
	window.postMessage({ type: "websiteOpts", data: opts }, "/");
} else if (typeof fwcimData === "object" && typeof ue_mid === "string") {
	//Mobile often doesn't have opts, but will have fwcimData and ue_mid
	let opts = { obfuscatedMarketId: ue_mid, customerId: fwcimData.customerId };
	window.postMessage({ type: "websiteOpts", data: opts }, "/");
}
*/

window.postMessage({ type: "injLoaded" }, "/");
