import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { playNotificationSound } from "/scripts/core/utils/SoundResolver.js";

const Settings = new SettingsMgr();

const NOTIFICATION_TYPE = {
	0: "New item",
	1: "RFY",
	2: "Zero ETV",
	3: "Keyword match",
};

const STATE_READY = 0;
const STATE_WAIT = 1;
const STATE_PLAY = 2;
const STATE_COOLDOWN = 3;
class NotificationsSoundPlayer {
	#state;
	#waitTimer;
	#waitDelay;
	#cooldownDelay;
	#notificationType;
	#highlightSound = undefined;
	#highlightVolume = undefined;
	#itemTitleQueue = [];
	#maxSpeechLength = 8000; // 8 seconds

	constructor() {
		this.#state = STATE_READY;
		this.#waitDelay = 250;
		this.#notificationType = -1; //-1 = no sound to play
		this.#loadSettings();

		//Wait until the computer is awaken from sleep
		window.addEventListener("pageshow", (event) => {
			if (event.persisted) {
				this.#state = STATE_COOLDOWN;
				setTimeout(() => {
					this.#state = STATE_READY;
				}, 5000);
			}
		});
	}
	async #loadSettings() {
		await Settings.waitForLoad();
		this.#cooldownDelay = Settings.get("notification.soundCooldownDelay");
	}

	play(notificationType, soundFilename = undefined, volume = undefined) {
		const previousNotificationType = this.#notificationType;
		//Save the highest notification type
		this.#setHighestNotificationType(notificationType);
		// Store sound and volume for highlight (type 3); used in #getSoundAccordingToNotificationType
		if (notificationType === 3) {
			this.#highlightSound = soundFilename;
			this.#highlightVolume = volume;
		} else if (previousNotificationType < this.#notificationType && this.#notificationType !== 3) {
			this.#highlightSound = undefined;
			this.#highlightVolume = undefined;
		}

		const resolved = this.#getSoundAccordingToNotificationType(this.#notificationType);
		this.#debugSoundPlayback("sound.play.queued", {
			requestedType: notificationType,
			queuedType: this.#notificationType,
			queuedTypeName: NOTIFICATION_TYPE[this.#notificationType],
			playerState: this.#stateName(),
			inCooldown: this.#state === STATE_COOLDOWN,
			resolvedFilename: resolved?.filename ?? null,
			resolvedVolume: resolved?.volume ?? null,
			willSchedulePlayback: this.#state !== STATE_COOLDOWN,
		});

		//Play logic
		if (this.#state !== STATE_COOLDOWN) {
			this.#setState(STATE_WAIT);
			window.clearTimeout(this.#waitTimer);
			this.#waitTimer = window.setTimeout(() => {
				this.#playSound();
			}, this.#waitDelay);
		}
	}

	#setState(stateType) {
		this.#state = stateType;
		//console.log("State: " + this.#state);
	}
	#setHighestNotificationType(notificationType) {
		if (notificationType >= this.#notificationType) {
			this.#notificationType = notificationType;
		}
	}

	#playSound() {
		const attemptedType = this.#notificationType;
		this.#setState(STATE_PLAY);

		let data = this.#getSoundAccordingToNotificationType(attemptedType);
		if (data == null) {
			this.#debugSoundPlayback("sound.play.skipped", {
				notificationType: attemptedType,
				notificationTypeName: NOTIFICATION_TYPE[attemptedType],
				reason: "noSoundConfigured",
				playerState: this.#stateName(),
			});
			this.#notificationType = -1;
			this.#highlightSound = undefined;
			this.#highlightVolume = undefined;
			this.#setState(STATE_READY);
			return false;
		}
		let filename = data.filename;
		let volume = data.volume;

		this.#debugSoundPlayback("sound.play.executing", {
			notificationType: attemptedType,
			notificationTypeName: NOTIFICATION_TYPE[attemptedType],
			filename,
			volume,
		});

		void playNotificationSound(filename, volume)
			.then((success) => {
				this.#debugSoundPlayback("sound.play.result", {
					notificationType: attemptedType,
					notificationTypeName: NOTIFICATION_TYPE[attemptedType],
					filename,
					volume,
					success: !!success,
				});
			})
			.catch((error) => {
				this.#debugSoundPlayback("sound.play.result", {
					notificationType: attemptedType,
					notificationTypeName: NOTIFICATION_TYPE[attemptedType],
					filename,
					volume,
					success: false,
					error: error?.message ?? String(error),
				});
				console.error("VHelper: Failed to play notification sound:", error);
			});

		//Set the cooldown
		this.#notificationType = -1;
		this.#highlightSound = undefined;
		this.#highlightVolume = undefined;
		this.#setState(STATE_COOLDOWN);
		setTimeout(() => {
			if (this.#notificationType > -1) {
				this.#playSound();
			} else {
				this.#setState(STATE_READY);
			}
			this.#notificationType = -1;
		}, this.#cooldownDelay);
	}

	#stateName() {
		switch (this.#state) {
			case STATE_READY:
				return "ready";
			case STATE_WAIT:
				return "wait";
			case STATE_PLAY:
				return "play";
			case STATE_COOLDOWN:
				return "cooldown";
			default:
				return "unknown";
		}
	}

	#debugSoundPlayback(topic, payload = {}) {
		if (!Settings.get("general.debugSound")) {
			return;
		}
		const logPayload = { ...payload, timestamp: new Date().toISOString() };
		if (typeof window !== "undefined" && window.__VH_MONITOR_DEBUG_EMIT__) {
			window.__VH_MONITOR_DEBUG_EMIT__("general.debugSound", "Sound", topic, logPayload, Settings);
			return;
		}
		console.log("[SOUND DEBUG]", topic, logPayload);
	}

	#getSoundAccordingToNotificationType(soundType) {
		switch (soundType) {
			case 0:
				if (Settings.get("notification.monitor.regular.sound") == "0") {
					return null;
				}
				return {
					volume: Settings.get("notification.monitor.regular.volume"),
					filename: Settings.get("notification.monitor.regular.sound"),
				};
			case 1:
				if (Settings.get("notification.monitor.rfy.sound") == "0") {
					return this.#getSoundAccordingToNotificationType(0);
				}
				return {
					volume: Settings.get("notification.monitor.rfy.volume"),
					filename: Settings.get("notification.monitor.rfy.sound"),
				};
			case 2:
				if (Settings.get("notification.monitor.zeroETV.sound") == "0") {
					return this.#getSoundAccordingToNotificationType(0);
				}
				return {
					volume: Settings.get("notification.monitor.zeroETV.volume"),
					filename: Settings.get("notification.monitor.zeroETV.sound"),
				};

			case 3: {
				// Use group-specific sound when provided; null = fall to next priority (regular); undefined = use default
				if (this.#highlightSound === null) {
					return this.#getSoundAccordingToNotificationType(0);
				}
				const filename = this.#highlightSound;
				if (!filename || filename == "0") {
					return this.#getSoundAccordingToNotificationType(0);
				}
				// Per-group volume when provided (0–1), else global default
				const volume =
					typeof this.#highlightVolume === "number" &&
					this.#highlightVolume >= 0 &&
					this.#highlightVolume <= 1
						? this.#highlightVolume
						: 1;
				return {
					volume,
					filename,
				};
			}
		}

		throw new Error("Sound type '" + soundType + "' unsupported.");
	}

	speak(itemType, text) {
		const voice = this.#getVoice();
		if (!voice) {
			return;
		}

		// Put spaces between numbers if it's more than 4 digits,
		// so that 12345 would be read as "one two three four five"
		// rather than "twelve thousand three hundred forty five"
		text = text.replace(/(\d)(?=(?:\d{4,}))/g, "$1 ");

		const itemTypeName = NOTIFICATION_TYPE[itemType] || "New item";
		const utterance = new SpeechSynthesisUtterance(`${itemTypeName}: ${text}`);
		utterance.voice = voice;
		this.#itemTitleQueue.push(utterance);

		this.#speakNextInQueue();
	}

	#speakNextInQueue() {
		if (speechSynthesis.speaking || !this.#itemTitleQueue.length) {
			return;
		}

		const utterance = this.#itemTitleQueue.shift();
		const speechTimer = setTimeout(() => {
			speechSynthesis.cancel();
			this.#speakNextInQueue();
		}, this.#maxSpeechLength); // Cut off speech after max length

		utterance.onend = () => {
			clearTimeout(speechTimer);
			this.#speakNextInQueue();
		};

		speechSynthesis.speak(utterance);
	}

	#getVoice() {
		if (!("speechSynthesis" in window)) {
			// Speech Synthesis is not supported in the current browser
			return null;
		}
		const voiceSettings = Settings.get("notification.monitor.voice");
		let configuredVoice;
		if (typeof voiceSettings === "string") {
			// Migrate old string setting to new object format
			if (voiceSettings) {
				Settings.set("notification.monitor.voice", { enabled: true, voiceURI: voiceSettings });
				configuredVoice = voiceSettings;
			} else {
				Settings.set("notification.monitor.voice", undefined);
				return null;
			}
		} else if (!voiceSettings || !voiceSettings.enabled || !voiceSettings.voiceURI) {
			return null;
		} else {
			configuredVoice = voiceSettings.voiceURI;
		}
		if (!this.#getSoundAccordingToNotificationType(this.#notificationType)) {
			// The corresponding notification sound is off
			return null;
		}
		return speechSynthesis.getVoices().find((voice) => voice.voiceURI === configuredVoice);
	}
}

export { NotificationsSoundPlayer };
