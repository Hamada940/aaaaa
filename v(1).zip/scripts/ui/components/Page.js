import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { Environment } from "/scripts/core/services/Environment.js";
var env = new Environment();

import { Template } from "/scripts/core/utils/Template.js";
var Tpl = new Template();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
var Settings = new SettingsMgr();

import { Internationalization, getMessage } from "/scripts/core/services/Internationalization.js";
var i18n = new Internationalization();

import { TileSizer } from "/scripts/ui/controllers/TileSizer.js";
var tileSizer = new TileSizer();

import { Item } from "/scripts/core/models/Item.js";

import { unescapeHTML } from "/scripts/core/utils/StringHelper.js";

import { PinnedListMgr } from "/scripts/core/services/PinnedListMgr.js";
var PinnedList = new PinnedListMgr();

import { HiddenListMgr } from "/scripts/core/services/HiddenListMgr.js";
var HiddenList = new HiddenListMgr();

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
var cryptoKeys = new CryptoKeys();

import { Tile } from "/scripts/ui/components/Tile.js";

import { Grid } from "/scripts/ui/components/Grid.js";

import { Pagination } from "/scripts/ui/controllers/Pagination.js";

const PINNED_ITEMS_PER_PAGE = 100;

class Page {
	currentTab = "vvp-items-grid";
	arrGrid = [];
	static instance = null;
	pinnedRemoteTotalCount = null;
	pinnedCurrentPage = 0;
	pinnedItemsLoading = false;
	#pinnedPagination = new Pagination();

	constructor() {
		if (Page.instance) {
			return Page.instance;
		}
		Page.instance = this;
		// Expose to window for static methods that need to avoid circular dependencies
		window.VHelperPageInstance = this;

		this.#pinnedPagination.setPageGeneratorMethod((url, pageNo, currentPage, caption = null) => {
			const li = document.createElement("li");
			if (pageNo == currentPage) {
				li.classList.add("a-selected");
			}
			const a = document.createElement("a");
			a.href = "#";
			a.innerText = caption ? caption : pageNo;
			a.onclick = (e) => {
				e.preventDefault();
				this.loadPinnedItemsPage(pageNo);
			};
			li.appendChild(a);
			return li;
		});
	}

	usesRemotePinnedStorage() {
		return Settings.isPremiumUser(1) && Settings.get("pinnedTab.active") && Settings.get("pinnedTab.remote");
	}

	setPinnedRemoteTotalCount(count) {
		this.pinnedRemoteTotalCount = count;
	}

	adjustPinnedRemoteCount(delta) {
		if (this.pinnedRemoteTotalCount != null) {
			this.pinnedRemoteTotalCount = Math.max(0, this.pinnedRemoteTotalCount + delta);
		}
	}

	addGrid(id, gridDOM) {
		this.arrGrid[id] = new Grid(id, gridDOM, this);
	}

	getGrid(id) {
		return this.arrGrid[id];
	}

	getTileByASIN(asin) {
		if (!asin) {
			return null;
		}

		//Loop through the arrGrid and get the tile from the grid
		for (const gridId in this.arrGrid) {
			const grid = this.arrGrid[gridId];
			const tile = grid.getTileByASIN(asin);
			if (tile) {
				return tile;
			}
		}
		return null;
	}

	/**
	 * Get all tiles from all grids on the page
	 * @returns {Object} Object with ASINs as keys and Tile instances as values
	 */
	getAllTiles() {
		const allTiles = {};
		// Loop through all grids and collect their tiles
		for (const gridId in this.arrGrid) {
			const grid = this.arrGrid[gridId];
			if (grid) {
				const gridTiles = grid.getAllTiles();
				// Merge tiles from this grid into the allTiles object
				for (const asin in gridTiles) {
					if (gridTiles[asin] != null) {
						allTiles[asin] = gridTiles[asin];
					}
				}
			}
		}
		return allTiles;
	}

	updateTileCounts() {
		//Calculate how many tiles within each grids
		if (Settings.get("unavailableTab.active") || Settings.get("hiddenTab.active")) {
			const tab1 = document.getElementById("vh-available-count");
			if (tab1) {
				const count = this.getGrid("vvp-items-grid").getTileCount(true);
				tab1.innerText = count;
			}
		}
		if (Settings.get("unavailableTab.active")) {
			const tab2 = document.getElementById("vh-unavailable-count");
			if (tab2) {
				const count = this.getGrid("tab-unavailable").getTileCount(true);
				tab2.innerText = count;
			}
		}
		if (Settings.get("hiddenTab.active")) {
			const tab3 = document.getElementById("vh-hidden-count");
			if (tab3) {
				const count = this.getGrid("tab-hidden").getTileCount(true);
				tab3.innerText = count;
			}
		}
		if (Settings.get("pinnedTab.active")) {
			const tab4 = document.getElementById("vh-pinned-count");
			if (tab4) {
				let count;
				if (this.usesRemotePinnedStorage() && this.pinnedRemoteTotalCount != null) {
					count = this.pinnedRemoteTotalCount;
				} else {
					count = this.getGrid("tab-pinned").getTileCount(true);
				}
				tab4.innerText = count;
			}
		}
	}

	async createGridInterface() {
		//Clean up interface (in case of the extension being reloaded)
		let tab0 = document.querySelector("ul#vh-tabs");
		if (tab0) tab0.remove();
		let tab2 = document.querySelector("div#tab-unavailable");
		if (tab2) tab2.remove();
		let tab3 = document.querySelector("div#tab-hidden");
		if (tab3) tab3.remove();
		let tab4 = document.querySelector("div#tab-pinned");
		if (tab4) tab4.remove();
		let pinnedPagination = document.getElementById("vh-pinned-pagination");
		if (pinnedPagination) pinnedPagination.remove();
		let tbs = document.querySelectorAll(".vh-status");
		tbs.forEach(function (toolbar) {
			toolbar.remove();
		});

		if (this.getGrid("vvp-items-grid") == undefined) {
			console.log("No listing on this page, not drawing tabs.");
			return false; // No listing on this page
		}

		//Implement the tab system.
		let tabs = document.createElement("div");
		tabs.setAttribute("id", "vh-tabs");
		tabs.classList.add("theme-default");

		let itemsGrid = this.getGrid("vvp-items-grid").getDOM();
		if (!itemsGrid) {
			return; //No items on this page
		}
		itemsGrid.parentNode.insertBefore(tabs, itemsGrid);
		itemsGrid.parentNode.removeChild(itemsGrid);
		itemsGrid.classList.add("tab-grid");
		tabs.appendChild(itemsGrid);

		let tplTabs = await Tpl.loadFile("scripts/ui/templates/tabs.html");
		const isMobileDisplay = env.isMobileView();

		Tpl.setIf("not_mobile", true);
		if (isMobileDisplay) {
			Tpl.setVar("available", getMessage("bootTabAvailableShort", "A"));
			Tpl.setVar("unavailable", getMessage("bootTabUnavailableShort", "U"));
			Tpl.setVar("hidden", getMessage("bootTabHiddenShort", "H"));
			Tpl.setVar("pinned", getMessage("bootTabPinnedShort", "P"));
			Tpl.setVar("tab_class", "compact");
		} else {
			Tpl.setVar("available", getMessage("bootTabAvailable", "Available"));
			Tpl.setVar("unavailable", getMessage("bootTabUnavailable", "Unavailable"));
			Tpl.setVar("hidden", getMessage("bootTabHidden", "Hidden"));
			Tpl.setVar("pinned", getMessage("bootTabPinned", "Pinned"));
			Tpl.setVar("tab_class", "");
		}
		//If ordering system enabled
		Tpl.setIf("unavailable", Settings.get("unavailableTab.active"));

		//If the hidden tab system is activated
		Tpl.setIf("hidden", Settings.get("hiddenTab.active"));

		//If the hidden tab system is activated
		Tpl.setIf("pinned", Settings.get("pinnedTab.active"));

		const tabsContent = Tpl.render(tplTabs, true);
		tabs.insertBefore(tabsContent, tabs.firstChild);

		if (Settings.get("hiddenTab.active")) {
			//Add the toolbar for Hide All & Show All
			//Delete the previous one if any exist:
			this.removeElements("#vh-tabs .hidden-toolbar");

			//Generate the html for the hide all and show all widget
			let prom = await Tpl.loadFile("scripts/ui/templates/widget_hideall.html");
			const darkThemes = new Set(["dark", "scifi", "midnight"]);
			const isDarkTheme = darkThemes.has(Settings.get("general.theme"));
			Tpl.setVar("class", isDarkTheme ? "invert" : "");
			if (isMobileDisplay) {
				Tpl.setIf("not_mobile", false);
				Tpl.setIf("mobile", true);
			} else {
				Tpl.setIf("not_mobile", true);
				Tpl.setIf("mobile", false);
			}
			let content = Tpl.render(prom, true);
			if (content == null) {
				logger.add("!!ERROR: Unable to fetch view/widget_hideall.html. Skipping.");
			} else {
				let clonedContent = content.cloneNode(true);

				// Prepend content to #vh-tabs
				let vtabs = document.querySelector("#vh-tabs");
				vtabs.insertBefore(content, vtabs.firstChild);
				vtabs.appendChild(clonedContent);
				const bottomToolbarClear = document.createElement("div");
				bottomToolbarClear.style.clear = "both";
				vtabs.appendChild(bottomToolbarClear);
				clonedContent.style.marginTop = "5px";

				// Add event listeners to .vh-hideall and .vh-showall elements AND vh-hideallnext
				document.querySelectorAll(".vh-hideall").forEach((element) => {
					element.addEventListener("click", (e) => {
						e.preventDefault();
						this.hideAllItems();
					});
				});

				document.querySelectorAll(".vh-hideallnext").forEach((element) => {
					element.addEventListener("click", (e) => {
						e.preventDefault();
						this.hideAllItemsNext();
					});
				});

				document.querySelectorAll(".vh-showall").forEach((element) => {
					element.addEventListener("click", (e) => {
						e.preventDefault();
						this.showAllItems();
					});
				});
			}
		}

		//Actiate the tab system
		//Bind the click event for the tabs
		document.querySelectorAll("#tabs > ul li").forEach((item) => {
			item.onclick = (event) => {
				this.currentTab = item.querySelector("a").href.split("#").pop();
				this.#selectCurrentTab();
				item.classList.add("active");
				this.#onTabSelected(this.currentTab);
			};
		});
		//Prevent links from being clickable
		document.querySelectorAll("#tabs > ul li a").forEach(function (item) {
			item.onclick = function (event) {
				event.preventDefault();
			};
		});
		this.#selectCurrentTab(true);
	}

	async addPinnedTile(item) {
		if (!(item instanceof Item)) {
			throw new Error("item is not an instance of Item");
		}
		if (!document.getElementById("tab-pinned")) return; // Page without items may not have the tabs container

		const {
			asin,
			title,
			img_url,
			is_parent_asin,
			is_pre_release,
			enrollment_guid,
			unavailable,
			etv_min,
			etv_max,
			price,
			order_success,
			order_failed,
		} = item.data;

		//Check if the pin already exist:
		if (document.getElementById("vh-pin-" + asin) != undefined) return false;

		let templateFile;
		if (Settings.get("general.listView")) {
			templateFile = "pinned_tile_listview.html";
		} else {
			templateFile = "pinned_tile_gridview.html";
		}

		let promOrderWidget = await Tpl.loadFile("scripts/ui/templates/widget_order.html");
		Tpl.setVar("order_success", order_success);
		Tpl.setVar("order_failed", order_failed);
		let orderWidget = Tpl.render(promOrderWidget, false);

		let prom2 = await Tpl.loadFile("scripts/ui/templates/" + templateFile);

		let truncatedTitle = title.length > 40 ? title.substr(0, 40).split(" ").slice(0, -1).join(" ") : title;

		// These characters were breaking search, resulting in zero results
		truncatedTitle = unescapeHTML(unescapeHTML(truncatedTitle)).replace(/[&,±]/g, " ");

		const search_url_slug = encodeURIComponent(truncatedTitle);

		const recommendationType = item.getRecommendationType();
		const recommendationId = item.getRecommendationString(env);

		Tpl.setVar("id", asin);
		Tpl.setVar("domain", i18n.getDomainTLD());
		Tpl.setVar("search_url_slug", search_url_slug);
		Tpl.setVar("img_url", img_url);
		Tpl.setVar("asin", asin);
		Tpl.setVar("etv", etv_min == etv_max ? (etv_min == null ? "" : etv_min) : etv_min + " - " + etv_max);
		Tpl.setVar("price", price);
		Tpl.setVar("description", title);
		Tpl.setVar("is_parent_asin", is_parent_asin);
		Tpl.setVar("is_pre_release", is_pre_release);
		Tpl.setIf("pre_release", !!is_pre_release);
		Tpl.setVar("enrollment_guid", enrollment_guid);
		Tpl.setVar("recommendationType", recommendationType);
		Tpl.setVar("recommendationId", recommendationId);
		Tpl.setVar("orderWidget", orderWidget);
		Tpl.setIf("SHOW_PRICE", Settings.isPremiumUser(3) && Settings.get("general.displayPrice") && price != null);
		Tpl.setIf("unavailable", !!unavailable);

		let content = Tpl.render(prom2, true);
		const tabPinned = document.getElementById("tab-pinned");
		tabPinned.insertBefore(content, tabPinned.firstChild);

		tileSizer.adjustAll(content);

		if (unavailable) {
			this.#disableItem(content);
		}

		//Bind the click event for the unpin button
		document.querySelector("#vh-pin-" + asin + " .unpin-link").onclick = (e) => {
			e.preventDefault();

			this.removePinnedTile(asin);
			// updateTileCounts() is already called by tile.setPinned(false) in removePinnedTile
		};

		//Bind the click event the the reload button
		/*
		const pinnedReloadLink = document.querySelector("#vh-pin-" + asin + " .pinned-reload-link");
		if (pinnedReloadLink) {
			pinnedReloadLink.onclick = (e) => {
				e.preventDefault();

				if (!Settings.isPremiumUser(1) || !Settings.get("pinnedTab.remote")) {
					return false;
				}

				//Reload all pinned tiles
				this.reloadAllPinnedTile();
			};
		}
		*/
	}

	async loadPinnedItemsPage(page) {
		if (!this.usesRemotePinnedStorage() || this.pinnedItemsLoading) {
			return;
		}

		this.pinnedItemsLoading = true;
		this.#setPinnedPaginationLoading(true);

		const content = {
			api_version: 5,
			app_version: env.data.appVersion,
			action: "load_pinned_items",
			country: i18n.getCountryCode(),
			uuid: await Settings.get("general.uuid", false),
			cid: await env.getCID(),
			page: page,
		};
		const s = await cryptoKeys.signData(content);
		content.s = s;
		content.pk = await cryptoKeys.getExportedPublicKey();

		try {
			const response = await fetch(env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
			const data = await response.json();
			if (!response.ok) {
				throw new Error(data.error || "Server error");
			}

			this.#clearPinnedTiles();
			this.pinnedCurrentPage = data.page;
			this.setPinnedRemoteTotalCount(data.total_items);

			for (let i = data.pinned_products.length - 1; i >= 0; i--) {
				const productData = data.pinned_products[i];
				const tile = this.getTileByASIN(productData.asin);
				if (tile) {
					tile.setPinned(true);
				}
				try {
					const item = new Item(productData);
					await this.addPinnedTile(item);
				} catch (error) {
					console.error("[Grid] Cannot create item for pinned tile -", error.message, {
						source: "load_pinned_items response",
						index: i,
						product_data: productData,
					});
				}
			}

			this.#renderPinnedPagination(data.total_items, data.page);
			this.updateTileCounts();
		} catch (error) {
			logger.add("ERROR: Failed to load pinned items: " + error.message);
		} finally {
			this.pinnedItemsLoading = false;
			this.#setPinnedPaginationLoading(false);
		}
	}

	#clearPinnedTiles() {
		document.querySelectorAll("#tab-pinned .pinned").forEach((element) => {
			element.remove();
		});
	}

	#ensurePinnedPaginationContainer() {
		const tabPinned = document.getElementById("tab-pinned");
		if (!tabPinned) {
			return null;
		}
		let paginationEl = document.getElementById("vh-pinned-pagination");
		if (!paginationEl) {
			paginationEl = document.createElement("div");
			paginationEl.id = "vh-pinned-pagination";
			tabPinned.parentNode.insertBefore(paginationEl, tabPinned);
		}
		return paginationEl;
	}

	#updatePinnedPaginationVisibility() {
		const paginationEl = document.getElementById("vh-pinned-pagination");
		if (!paginationEl) {
			return;
		}
		const hasPages = paginationEl.childElementCount > 0;
		paginationEl.style.display = this.currentTab === "tab-pinned" && hasPages ? "block" : "none";
	}

	#renderPinnedPagination(totalItems, currentPage) {
		const paginationEl = this.#ensurePinnedPaginationContainer();
		if (!paginationEl) {
			return;
		}

		paginationEl.replaceChildren();
		if (totalItems <= PINNED_ITEMS_PER_PAGE) {
			this.#updatePinnedPaginationVisibility();
			return;
		}

		paginationEl.appendChild(
			this.#pinnedPagination.generatePagination("", totalItems, PINNED_ITEMS_PER_PAGE, currentPage, true)
		);
		this.#updatePinnedPaginationVisibility();
	}

	#setPinnedPaginationLoading(loading) {
		const paginationEl = document.getElementById("vh-pinned-pagination");
		if (paginationEl) {
			paginationEl.style.opacity = loading ? "0.5" : "unset";
			paginationEl.style.pointerEvents = loading ? "none" : "auto";
		}
	}

	async #onTabSelected(tabId) {
		if (tabId !== "tab-pinned" || !this.usesRemotePinnedStorage()) {
			return;
		}
		if (this.pinnedCurrentPage === 0) {
			await this.loadPinnedItemsPage(1);
		}
	}

	async reloadAllPinnedTile() {
		//Reload all pinned tiles
		const content = {
			api_version: 5,
			app_version: env.data.appVersion,
			action: "reload_pinned_items",
			country: i18n.getCountryCode(),
			uuid: await Settings.get("general.uuid", false),
			fid: await Settings.get("general.fingerprint.id", false),
			cid: await env.getCID(),
		};
		const s = await cryptoKeys.signData(content);
		content.s = s;
		content.pk = await cryptoKeys.getExportedPublicKey();

		await fetch(env.getAPIUrl(), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		})
			.then((response) => response.json())
			.then(async (response) => {
				//console.log("Reloading all pinned tiles", response);
				//Reload all pinned tiles
				document.querySelectorAll(`#tab-pinned .pinned`).forEach((element) => {
					console.log("Removing pinned tile", element);
					element.remove();
				});

				//Add all pinned items
				for (let i = response["pinned_products"].length; i >= 0; i--) {
					//console.log("Adding pinned tile", response["pinned_products"][i]);

					const productData = response["pinned_products"][i];
					try {
						const item = new Item(productData);
						await this.addPinnedTile(item);
					} catch (error) {
						console.error("[Grid] Cannot create item for pinned tile -", error.message, {
							source: "pinned products from server response",
							index: i,
							total_pinned_items: response["pinned_products"].length,
							product_data: productData,
							has_asin: productData?.asin !== undefined,
							has_enrollment_guid: productData?.enrollment_guid !== undefined,
						});
					}
				}
			});
	}

	async #disableItem(notif) {
		if (!notif) {
			return false;
		}

		//Remove the banner if it already existed
		notif.querySelector(".unavailable-banner")?.remove();

		//Add a new banner
		const banner = document.createElement("div");
		banner.classList.add("unavailable-banner");
		banner.innerText = getMessage("bootTabUnavailable", "Unavailable");
		banner.style.isolation = "isolate"; // This prevents the banner from inheriting the filter effects
		const imgThumb = notif.querySelector(".vh-img-thumb");
		(imgThumb ?? notif.querySelector(".vh-img-container"))?.appendChild(banner);

		notif.classList.add("vh-item-disabled");
	}

	async removePinnedTile(asin) {
		PinnedList.removeItem(asin);
		const pinnedTile = document.getElementById("vh-pin-" + asin);
		if (pinnedTile) {
			pinnedTile.remove();
		}

		if (this.usesRemotePinnedStorage()) {
			this.adjustPinnedRemoteCount(-1);
			this.updateTileCounts();
		}

		//If it exists, mark the tile in the available grid as unpinned
		const tile = this.getTileByASIN(asin);
		//console.log("Removing pinned tile", asin, tile);
		if (tile) {
			tile.setPinned(false);
		}
	}

	async hideAllItems() {
		let arrTile = [];
		HiddenList.loadFromLocalStorage(); //Refresh the list in case it was altered in a different tab

		//Find out what the current active tab is
		let currentTab2 = "#vvp-items-grid";
		if (
			document.querySelector("#tab-unavailable") &&
			document.querySelector("#tab-unavailable").style.display !== "none"
		) {
			currentTab2 = "#tab-unavailable";
		}

		const vvpItemTiles = document.querySelectorAll(currentTab2 + " .vvp-item-tile");
		for (const vvpItemTile of vvpItemTiles) {
			let asin = Tile.getASINFromDom(vvpItemTile);
			if (!asin) {
				console.warn("VHelper: Skipping tile without ASIN in hideAllItems");
				continue; // Skip this tile if no ASIN found
			}
			arrTile.push({ asin: asin, hidden: true });
			let tile = this.getTileByASIN(asin); // Obtain the real tile
			if (tile && !tile.isPinned()) {
				await tile.hideTile(false, false); // Do not update local storage
			}
		}
		HiddenList.saveList();

		// Scoll to the RFY/AFA/AI header
		if (Settings.get("hiddenTab.scrollToRFY")) {
			var scrollTarget = document.getElementById("vvp-items-button-container");
			if (scrollTarget) {
				scrollTarget.scrollIntoView({ behavior: "instant", block: "start" });
			}
		}
	}

	async hideAllItemsNext() {
		await this.hideAllItems();

		// Add a small delay to ensure all DOM operations complete before navigation
		// This helps with Firefox Android click handling issues
		await new Promise((resolve) => setTimeout(resolve, 50));

		try {
			const nextLi = document.querySelector("#vvp-items-grid-container nav ul li:last-child a");
			if (nextLi) {
				const nextPage = nextLi.getAttribute("href");
				window.location = nextPage;
			}
		} catch (e) {
			//Do nothing
		}
	}

	async showAllItems() {
		let arrTile = [];
		HiddenList.loadFromLocalStorage(); //Refresh the list in case it was altered in a different tab

		const vvpItemTiles = document.querySelectorAll("#tab-hidden .vvp-item-tile");
		for (const vvpItemTile of vvpItemTiles) {
			let asin = Tile.getASINFromDom(vvpItemTile);
			if (!asin) {
				console.warn("VHelper: Skipping tile without ASIN in showAllItems");
				continue; // Skip this tile if no ASIN found
			}
			arrTile.push({ asin: asin, hidden: false });
			let tile = this.getTileByASIN(asin); //Obtain the real tile
			if (tile) {
				await tile.showTile(false, false); //Do not update local storage
			}
		}
		HiddenList.saveList();

		// Scoll to the RFY/AFA/AI header
		if (Settings.get("hiddenTab.scrollToRFY")) {
			var scrollTarget = document.getElementById("vvp-items-button-container");
			if (scrollTarget) {
				scrollTarget.scrollIntoView({ behavior: "instant", block: "start" });
			}
		}
	}

	#selectCurrentTab(firstRun = false) {
		//Hide all tabs
		document.querySelectorAll(".tab-grid").forEach(function (item) {
			item.style.display = "none";
		});

		if (!firstRun) {
			document.querySelectorAll("#tabs > ul li").forEach(function (item) {
				item.classList.remove("active");
			});
		} else {
			document.querySelector("#tabs > ul li:first-child").classList.add("active");
		}

		//Display the current tab
		document.querySelector("#" + this.currentTab).style.display = "grid";
		this.#updatePinnedPaginationVisibility();
	}

	/** Remove an element from the DOM, ignore if it does not exist
	 * @param selector CSS style selector of the element to remove
	 */
	removeElements(selector) {
		let elementsToRemove = document.querySelectorAll(selector);

		elementsToRemove.forEach(function (element) {
			element.remove();
		});
	}
}

export { Page };
