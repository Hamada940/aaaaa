/* global chrome */

import { BUILD_NUMBER } from "/scripts/build_info.js";

const ELEMENT_ID = "vh-version-debug-label";
const STYLE_ID = "vh-version-debug-label-style";
const SETTING_KEY = "general.debugVersionLabel";

const LABEL_STYLE = `
#${ELEMENT_ID} {
	position: fixed;
	top: 4px;
	left: 4px;
	z-index: 2147483000;
	padding: 2px 6px;
	font-family: system-ui, -apple-system, sans-serif;
	font-size: 10px;
	font-weight: 500;
	line-height: 1.3;
	color: rgba(255, 255, 255, 0.9);
	background: rgba(0, 0, 0, 0.55);
	border-radius: 3px;
	pointer-events: none;
	user-select: none;
	letter-spacing: 0.02em;
}`;

function ensureLabelStyles() {
	if (document.getElementById(STYLE_ID)) {
		return;
	}
	const style = document.createElement("style");
	style.id = STYLE_ID;
	style.textContent = LABEL_STYLE;
	(document.head || document.documentElement).appendChild(style);
}

/**
 * Shows a small fixed label in the upper-left corner with the extension
 * version and build number when `general.debugVersionLabel` is enabled.
 *
 * @param {import("/scripts/core/services/SettingsMgr.js").SettingsMgr} settings
 */
export function initVersionDebugLabel(settings) {
	let labelEl = null;

	const getVersionText = () => {
		const manifest = chrome.runtime.getManifest();
		const version = manifest.version_name || manifest.version;
		return `v${version} · #${BUILD_NUMBER}`;
	};

	const removeLabel = () => {
		if (labelEl) {
			labelEl.remove();
			labelEl = null;
		}
	};

	const showLabel = () => {
		if (!document.body) {
			return;
		}
		ensureLabelStyles();
		if (labelEl) {
			labelEl.textContent = getVersionText();
			return;
		}
		labelEl = document.createElement("div");
		labelEl.id = ELEMENT_ID;
		labelEl.setAttribute("aria-hidden", "true");
		labelEl.textContent = getVersionText();
		document.body.appendChild(labelEl);
	};

	const sync = () => {
		if (settings.get(SETTING_KEY)) {
			showLabel();
		} else {
			removeLabel();
		}
	};

	const waitForBody = () =>
		new Promise((resolve) => {
			if (document.body) {
				resolve();
				return;
			}
			const observer = new MutationObserver(() => {
				if (document.body) {
					observer.disconnect();
					resolve();
				}
			});
			observer.observe(document.documentElement, { childList: true });
		});

	const init = async () => {
		await settings.waitForLoad();
		await waitForBody();
		sync();

		if (typeof settings.addSettingsChangeObserver === "function") {
			settings.addSettingsChangeObserver((payload) => {
				if (payload?.changedPaths?.length && !payload.changedPaths.includes(SETTING_KEY)) {
					return;
				}
				sync();
			});
		}
	};

	void init();
}
