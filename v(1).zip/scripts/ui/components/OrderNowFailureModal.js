import { ModalMgr } from "/scripts/ui/controllers/ModalMgr.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";
import {
	buildOrderNowFailureHtml,
	buildOrderNowFailurePlainText,
} from "/scripts/ui/components/OrderNowFailureReport.js";

export { OrderNowFailureError } from "/scripts/ui/components/OrderNowFailureReport.js";

let dialogMgr = null;

function getDialogMgr() {
	if (!dialogMgr) {
		dialogMgr = new ModalMgr();
	}
	return dialogMgr;
}

/**
 * @param {import("/scripts/ui/components/OrderNowFailureReport.js").OrderNowFailureDebugReport} report
 * @returns {Promise<void>}
 */
export async function showOrderNowFailureModal(report) {
	const modalId = `order-now-failure-${Date.now()}`;
	const modal = getDialogMgr().newModal(modalId);
	modal.title = getMessage("buyNowFailureModalTitle", "Order Now failed :(");
	modal.content = buildOrderNowFailureHtml(report);
	modal.style = "min-width: 360px; max-width: 95vw; width: min(720px, 95vw);";
	await modal.show();

	const root = document.getElementById(`modal-${modalId}`);
	const copyBtn = root?.querySelector(".vh-order-now-failure__copy");
	if (!copyBtn) {
		return;
	}

	const plainText = buildOrderNowFailurePlainText(report);
	copyBtn.addEventListener("click", async () => {
		const copiedLabel = copyBtn.getAttribute("data-copied-label") || "Copied!";
		const defaultLabel = copyBtn.textContent || "Copy all details";
		try {
			await navigator.clipboard.writeText(plainText);
			copyBtn.textContent = copiedLabel;
			copyBtn.classList.add("vh-order-now-failure__copy--done");
			window.setTimeout(() => {
				copyBtn.textContent = defaultLabel;
				copyBtn.classList.remove("vh-order-now-failure__copy--done");
			}, 2000);
		} catch (e) {
			console.warn("[OrderNowFailureModal] Clipboard copy failed:", e);
		}
	});
}
