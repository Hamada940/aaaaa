import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
var Settings = new SettingsMgr();

// Lazy-load TitleDebugLogger only when debug is enabled
let titleDebugger = null;
const getTitleDebugger = async () => {
	if (!titleDebugger) {
		const { TitleDebugLogger } = await import("/scripts/ui/components/TitleDebugLogger.js");
		titleDebugger = TitleDebugLogger.getInstance();
	}
	return titleDebugger;
};

import { Environment } from "/scripts/core/services/Environment.js";
var env = new Environment();

import { HiddenListMgr } from "/scripts/core/services/HiddenListMgr.js";
var HiddenList = new HiddenListMgr();

import { VariantButton } from "/scripts/ui/components/VariantButton.js";
import { lazyImageLoader } from "/scripts/notifications-monitor/services/LazyImageLoader.js";

import { StyleUtils } from "/scripts/ui/utils/StyleUtils.js";

import { YMDHiStoISODate } from "/scripts/core/utils/DateHelper.js";
import { unescapeHTML, escapeHTML } from "/scripts/core/utils/StringHelper.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";

import "/scripts/vendor/canvas-confetti/dist/confetti.browser.js";
import "/scripts/vendor/splide/dist/js/splide.min.js";

class Tile {
	#tileDOM;
	#grid;
	#toolbar;
	#hidden = false;
	#item; // Store the Item instance

	#asin;
	#isPinned = false;
	#orderSuccess = 0;
	#orderFailed = 0;
	#orderUnavailable = false;
	#title = null;
	#thumbnailUrl = null;
	#variantButton = null;
	#splideInstance = null; // Store Splide carousel instance for cleanup

	constructor(itemInstance, tileDOM, gridInstance) {
		// Validate Item instance
		if (!itemInstance || !itemInstance.data || !itemInstance.data.asin) {
			throw new Error("Tile constructor requires a valid Item instance as the first parameter");
		}

		this.#item = itemInstance;
		this.#tileDOM = tileDOM;
		this.#grid = gridInstance;
		this.#toolbar = null;

		// Get ASIN from Item instance
		this.#asin = itemInstance.data.asin;

		// Log tile creation for memory debugging
		if (window.MEMORY_DEBUGGER && Settings.get("general.debugMemory")) {
			console.log(`🏗️ Creating tile for ASIN: ${this.#asin}`);
		}

		this.#orderSuccess = 0;
		this.#orderFailed = 0;

		// Check if ASIN is valid
		if (!this.#asin) {
			logger.add("WARNING: Creating Tile with null ASIN - tile will have limited functionality");
			console.warn("VHelper: Tile created without ASIN", tileDOM);
			// Mark the tile DOM to indicate it has no ASIN
			if (this.#tileDOM) {
				this.#tileDOM.classList.add("vh-no-asin");
				this.#tileDOM.dataset.vhNoAsin = "true";
			}
		}

		logger.add("Created Tile: " + this.#asin + " to grid: " + gridInstance?.getId());
	}

	/**
	 * Get the Item instance associated with this tile
	 * @returns {Item} The Item instance
	 */
	getItem() {
		return this.#item;
	}

	//#################
	//## Public methods

	async addVariant(asin, title, etv) {
		// Only add button if it doesn't exist
		if (!this.#variantButton) {
			this.#variantButton = new VariantButton(this);
			await this.#variantButton.initialize();
		}

		await this.#variantButton.addVariant(asin, title, etv);
	}

	getVariantButton() {
		return this.#variantButton;
	}

	isPinned() {
		return this.#isPinned;
	}

	setPinned(isPinned) {
		this.#isPinned = isPinned;

		if (this.#asin) {
			const pinIcon = this.#tileDOM.querySelector("#vh-pin-icon-" + this.#asin);
			if (pinIcon) {
				pinIcon.classList.toggle("vh-icon-pin", !isPinned);
				pinIcon.classList.toggle("vh-icon-unpin", isPinned);
			}
		}
	}

	async animateVanish() {
		const defaultOpacity = window.getComputedStyle(this.#tileDOM).opacity;

		// Animate opacity to 0 (hide)
		await this.#animateOpacity(this.#tileDOM, 0, 150);

		// Reset styles
		this.#tileDOM.style.opacity = defaultOpacity;
		this.#tileDOM.style.height = "100%";
	}

	setToolbar = function (toolbarInstance) {
		this.#toolbar = toolbarInstance;
	};
	getToolbar() {
		return this.#toolbar;
	}

	setOrders(success, failed) {
		const successElement = this.#tileDOM.querySelector(".vh-order-success");
		const failedElement = this.#tileDOM.querySelector(".vh-order-failed");
		if (successElement) {
			successElement.textContent = success;
		} else {
			logger.add(`TILE WARNING: .vh-order-success not found for ASIN: ${this.getAsin()}`);
		}
		if (failedElement) {
			failedElement.textContent = failed;
		} else {
			logger.add(`TILE WARNING: .vh-order-failed not found for ASIN: ${this.getAsin()}`);
		}

		this.#orderSuccess = success;
		this.#orderFailed = failed;
	}

	setUnavailable(orderUnavailable) {
		this.#orderUnavailable = orderUnavailable;
	}

	getUnavailable() {
		return this.#orderUnavailable;
	}

	getOrderSuccess() {
		return this.#orderSuccess;
	}
	getOrderFailed() {
		return this.#orderFailed;
	}

	wasOrdered() {
		return this.#orderSuccess > 0 || this.#orderFailed > 0;
	}

	getStatus() {
		if (Settings.get("unavailableTab.active")) {
			if (this.#orderSuccess > 0 && this.#orderSuccess > this.#orderFailed)
				return env.data.NOT_DISCARDED_ORDER_SUCCESS;

			if (this.#orderFailed > 0 && this.#orderFailed > this.#orderSuccess) return env.data.DISCARDED_ORDER_FAILED;
		}
		return env.data.NOT_DISCARDED;
	}

	getAsin() {
		return this.#asin;
	}

	getDOM() {
		return this.#tileDOM;
	}

	getGrid() {
		return this.#grid;
	}

	getGridId() {
		return this.#grid.getId();
	}
	getTitle() {
		if (this.#title == null) {
			// Prefer Item data, fallback to DOM extraction
			if (this.#item && this.#item.data && this.#item.data.title) {
				this.#title = this.#item.data.title;
			} else if (this.#tileDOM) {
				this.#title = this.#getTitleFromDom(this.#tileDOM);
			} else {
				this.#title = "";
			}
			// Debug logging
			const settings = new SettingsMgr();
			if (settings.get("general.debugKeywords")) {
				console.log("[Tile] Title retrieved:", {
					asin: this.getAsin(),
					title: this.#title.substring(0, 100) + (this.#title.length > 100 ? "..." : ""),
					source: this.#item?.data?.title ? "Item" : "DOM",
					domElement: this.#tileDOM,
				});
			}
			// Title debug logging - only if debug is enabled
			if (Settings.get("general.debugTitleDisplay")) {
				getTitleDebugger().then((logger) => logger.logDOMExtraction(this.#asin, "getTitle", this.#title));
			}
		}
		return this.#title;
	}

	getThumbnailURL() {
		if (this.#thumbnailUrl == null) {
			// Prefer Item data, fallback to DOM extraction
			if (this.#item && this.#item.data && this.#item.data.img_url) {
				this.#thumbnailUrl = this.#item.data.img_url;
			} else if (this.#tileDOM) {
				this.#thumbnailUrl = this.#getThumbnailURLFromDom(this.#tileDOM);
			} else {
				this.#thumbnailUrl = null;
			}
		}
		return this.#thumbnailUrl;
	}

	markAsDiscovered() {
		const container = this.#tileDOM.querySelector(".vh-img-container");

		const newCorner = document.createElement("div");
		newCorner.classList.add("vh-new-corner-discovered");
		//Add a span into the div
		const span = document.createElement("span");
		span.innerHTML = getMessage("tileFirstDiscovery", "FIRST<br>DISCOVERY");
		newCorner.appendChild(span);

		//Insert newCorner as the first child of the container
		container.insertBefore(newCorner, container.firstChild);

		if (Settings.get("general.discoveryFirst")) {
			logger.add("Tile: markAsDiscovered: discoveryFirst");
			//Move the highlighted item to the top of the grid
			this.getGrid().getDOM().insertBefore(this.getDOM(), this.getGrid().getDOM().firstChild);
		}

		//Confetti animation
		//Wait 1 seconds for the item to take their final position
		setTimeout(() => {
			this.explodeConfettiFromDiv(this.getDOM());
		}, 1000);
	}

	explodeConfettiFromDiv(div) {
		if (!div) return;

		const rect = div.getBoundingClientRect();

		if (rect.top == 0 && rect.left == 0) {
			return; //div not visible.
		}

		// Create confetti from three sides
		const positions = [
			// Left side
			{ x: rect.left / window.innerWidth, y: rect.top / window.innerHeight },
			{ x: rect.left / window.innerWidth, y: (rect.top + rect.height / 2) / window.innerHeight },
			{ x: rect.left / window.innerWidth, y: rect.bottom / window.innerHeight },
			// Top side
			{ x: (rect.left + rect.width / 4) / window.innerWidth, y: rect.top / window.innerHeight },
			{ x: (rect.left + rect.width / 2) / window.innerWidth, y: rect.top / window.innerHeight },
			{ x: (rect.left + (rect.width * 3) / 4) / window.innerWidth, y: rect.top / window.innerHeight },
			// Right side
			{ x: rect.right / window.innerWidth, y: rect.top / window.innerHeight },
			{ x: rect.right / window.innerWidth, y: (rect.top + rect.height / 2) / window.innerHeight },
			{ x: rect.right / window.innerWidth, y: rect.bottom / window.innerHeight },
		];

		positions.forEach((pos) => {
			confetti({
				particleCount: 15, // Reduced particle count per origin point
				spread: 45,
				startVelocity: 15, // Reduced velocity for shorter distance
				decay: 0.9, // Faster decay
				gravity: 0.8, // Reduced gravity
				ticks: 100, // Controls animation duration (~500ms)
				origin: pos,
				colors: ["#ff0", "#ff4500", "#ff1493", "#00ffff", "#00ff00"],
				scalar: 0.8, // Smaller particles
				drift: 0, // No sideways drift
				disableForReducedMotion: true,
			});
		});
	}

	setDateAdded(timenow, mysqlDate) {
		if (mysqlDate == undefined || !Settings.get("general.displayFirstSeen")) {
			return false;
		}

		let serverCurrentDate = YMDHiStoISODate(timenow);
		let itemDateAdded = YMDHiStoISODate(mysqlDate);
		let bookmarkDate = new Date(Settings.get("general.bookmarkDate"));
		if (isNaN(serverCurrentDate.getTime()) || isNaN(itemDateAdded.getTime())) {
			logger.add(
				"! Time firstseen wrong: serverCurrentDate:" +
					serverCurrentDate +
					" itemDateAdded:" +
					itemDateAdded +
					"preformated current time: " +
					timenow +
					"preformatted item time" +
					mysqlDate
			);
			return;
		}
		//Add the data-date attribute to the tile
		// Convert to local time and store in dataset
		this.#tileDOM.dataset.date = new Date(itemDateAdded).toLocaleString();

		const { count, unitKey } = this.#timeSince(serverCurrentDate, itemDateAdded);
		const unitFallbacks = {
			bootTimeYear: "year",
			bootTimeYears: "years",
			bootTimeMonth: "month",
			bootTimeMonths: "months",
			bootTimeDay: "day",
			bootTimeDays: "days",
			bootTimeHr: "hr",
			bootTimeHrs: "hrs",
			bootTimeMin: "min",
			bootTimeMins: "mins",
			bootTimeSec: "sec",
			bootTimeSecs: "secs",
		};
		const unitLabel = getMessage(unitKey, unitFallbacks[unitKey] ?? unitKey);
		const dateAddedMessage = `${count} ${unitLabel}`;

		let dateAddedDiv = document.createElement("div");
		dateAddedDiv.classList.add("vh-date-added"); // Add the class
		dateAddedDiv.textContent = dateAddedMessage;

		// Find the container and append the new div
		const container = this.#tileDOM.querySelector(".vh-img-container");
		if (container) {
			container.appendChild(dateAddedDiv);
		} else {
			logger.add(`TILE: Cannot add date - .vh-img-container not found for ASIN: ${this.#asin}`);
		}

		//Highlight the tile background if the bookmark date is in the past
		if (
			Settings.get("general.bookmark") &&
			itemDateAdded > bookmarkDate &&
			Settings.get("general.bookmarkDate") != 0
		) {
			logger.add("TILE: The item is more recent than the time marker, highlight its toolbar.");
			const statusContainer = this.#tileDOM.querySelector(".vh-status-container");
			if (statusContainer) {
				statusContainer.style.backgroundColor = Settings.get("general.bookmarkColor");
			}
			this.#tileDOM.classList.add("vh-new-item-highlight");
		}
	}

	async initiateTile() {
		// Check if blur should be applied based on pre-computed blur keyword match
		// The blur keyword matching is done in NewItemStreamProcessing.js
		// dataset.blurkw contains the actual blur keyword if matched, or empty/undefined if not
		const shouldBlur = this.#tileDOM.dataset.blurkw && this.#tileDOM.dataset.blurkw !== "false";

		// Debug logging for blur keyword application
		if (Settings.get("general.debugKeywords")) {
			console.log("[Tile.initiateTile] Applying blur based on pre-computed match", {
				asin: this.getAsin(),
				title: this.getTitle(),
				shouldBlur: shouldBlur,
				dataBlurKw: this.#tileDOM.dataset.blurkw,
			});
		}

		// Always set blurredKeyword from blurkw if available (for display in toolbar details)
		const blurKeyword = this.#tileDOM.dataset.blurkw || "";
		this.#tileDOM.dataset.blurredKeyword = blurKeyword ? escapeHTML(blurKeyword) : "";

		if (Settings.isPremiumUser() && shouldBlur) {
			logger.add("TILE: The item matches blur keyword, applying blur");
			const img = this.#tileDOM.querySelector("img");
			if (img) {
				if (Settings.get("general.unblurImageOnHover")) {
					img.classList.add("dynamic-blur");
				} else {
					img.classList.add("blur");
				}
			}
			this.#tileDOM.querySelector(".vvp-item-product-title-container")?.classList.add("dynamic-blur");
		}

		/*
		//Unescape titles and ensure they remain visible
		const truncateFull = this.getDOM().querySelector(".a-truncate-full");
		const truncateCut = this.getDOM().querySelector(".a-truncate-cut");

		// Log initial tile creation - only if debug is enabled
		if (Settings.get("general.debugTitleDisplay")) {
			getTitleDebugger().then((logger) =>
				logger.logTileCreation(
					this.#asin,
					truncateFull || truncateCut,
					truncateFull?.innerText || truncateCut?.innerText
				)
			);
		}

		// Get the title text - try multiple sources
		let titleText = truncateFull?.innerText || truncateCut?.innerText;

		// If both are empty, try to get from the link's data-tooltip
		if (!titleText) {
			const linkElement = this.getDOM().querySelector(".a-link-normal");
			titleText = linkElement?.getAttribute("data-tooltip") || "";
			if (Settings.get("general.debugTitleDisplay")) {
				getTitleDebugger().then((logger) =>
					logger.logDOMExtraction(this.#asin, "data-tooltip fallback", titleText)
				);
			}
		}

		// If still empty, get from the tile's stored title
		if (!titleText) {
			titleText = this.getTitle();
			if (Settings.get("general.debugTitleDisplay")) {
				getTitleDebugger().then((logger) =>
					logger.logDOMExtraction(this.#asin, "getTitle fallback", titleText)
				);
			}
		}

		// Apply unescaped text to both spans
		if (titleText) {
			const unescapedText = unescapeHTML(unescapeHTML(titleText));

			// Set text content for both spans
			if (truncateFull) {
				truncateFull.innerText = unescapedText;
				// Ensure it stays visible by removing a-offscreen if Amazon adds it
				truncateFull.classList.remove("a-offscreen");
				if (Settings.get("general.debugTitleDisplay")) {
					getTitleDebugger().then((logger) =>
						logger.log(this.#asin, "TITLE_SET", {
							element: "truncateFull",
							text: unescapedText.substring(0, 100),
							length: unescapedText.length,
						})
					);
				}
			}
			if (truncateCut) {
				truncateCut.innerText = unescapedText;
				// Ensure it's visible
				truncateCut.style.visibility = "visible";
				truncateCut.style.display = "";
				if (Settings.get("general.debugTitleDisplay")) {
					getTitleDebugger().then((logger) =>
						logger.log(this.#asin, "TITLE_SET", {
							element: "truncateCut",
							text: unescapedText.substring(0, 100),
							length: unescapedText.length,
						})
					);
				}
			}

			//Move the banners inside the image container, at the end of it (after the carousel if it exists)
			const imgContainer = this.#tileDOM.querySelector(".vh-img-container");
			const banners = this.#tileDOM.querySelector(".vvp-item-badges");
			if (banners) {
				imgContainer.appendChild(banners);
			}

			// Only apply title restoration on Amazon pages where the issue occurs
			//(is this a made up problem?)
			// Skip on Notification Monitor where titles display correctly
			const isNotificationMonitor =
				window.location.href.includes("#monitor") ||
				window.location.hash.startsWith("#vh-monitor") ||
				/^\/(?:[^/]+\/)?vine\/vh-monitor\/?$/.test(window.location.pathname);
			const isAmazonVinePage = window.location.href.includes("/vine/vine-items") && !isNotificationMonitor;

			if (isAmazonVinePage) {
				// Store the original title for restoration
				this.#tileDOM.dataset.vhOriginalTitle = unescapedText;

				// Use a simpler periodic check instead of MutationObserver
				// This avoids memory leaks and is much simpler
				if (!Tile.titleRestorationInterval) {
					Tile.titleRestorationInterval = setInterval(() => {
						// Check all tiles with stored titles
						const tilesWithStoredTitles = document.querySelectorAll(
							".vvp-item-tile[data-vh-original-title]"
						);

						tilesWithStoredTitles.forEach((tileElement) => {
							const storedTitle = tileElement.dataset.vhOriginalTitle;
							if (storedTitle) {
								// Check both title elements
								const truncateFull = tileElement.querySelector(".a-truncate-full");
								const truncateCut = tileElement.querySelector(".a-truncate-cut");

								// Restore if text was cleared
								if (truncateFull && !truncateFull.innerText) {
									truncateFull.innerText = storedTitle;
									truncateFull.classList.remove("a-offscreen");

									if (Settings.get("general.debugTitleDisplay")) {
										console.log(
											`🔄 [TitleFix] Restored title for ASIN: ${tileElement.dataset.asin}`
										);
									}
								}

								if (truncateCut && !truncateCut.innerText) {
									truncateCut.innerText = storedTitle;
									truncateCut.style.visibility = "visible";
									truncateCut.style.display = "";

									if (Settings.get("general.debugTitleDisplay")) {
										console.log(
											`🔄 [TitleFix] Restored title for ASIN: ${tileElement.dataset.asin}`
										);
									}
								}
							}
						});
					}, 2000); // Check every 2 seconds

					if (Settings.get("general.debugTitleDisplay")) {
						console.log("🔄 [TitleFix] Started periodic title restoration");
					}
				}
			}
		}
		//Assign the ASIN to the tile content
		if (this.#asin) {
			this.getDOM().closest(".vvp-item-tile").dataset.asin = this.#asin;
		}
		*/
	}

	async #initCarousel(additionalImages) {
		if (!Settings.isPremiumUser(3)) {
			return;
		}
		const useLazyCarouselImages = window.location.hash.includes("monitor");

		if (additionalImages.length <= 1) {
			return;
		}

		const existingCarousel = this.#tileDOM.querySelector("#thumbnail-carousel-" + this.#asin);
		const thumb = this.#tileDOM.querySelector(".vh-img-thumb");
		const preReleaseIndicator = this.#tileDOM.querySelector(".vh-pre-release-indicator");
		if (preReleaseIndicator && existingCarousel?.contains(preReleaseIndicator) && thumb) {
			thumb.appendChild(preReleaseIndicator);
		}

		//Find the img of the tile
		const img = this.#tileDOM.querySelector("img");
		if (!useLazyCarouselImages && img) {
			// Regular Vine pages should never lazy-load carousel images (Firefox/Orion first-slide issue).
			img.removeAttribute("loading");
			img.loading = "eager";
		}

		//Detach the image from is container
		img.parentNode.removeChild(img);

		//Delete any pre-existing carousel
		if (existingCarousel) {
			existingCarousel.remove();
		}

		//Find the image container
		const imgContainer = this.#tileDOM.querySelector(".vh-img-container");

		//Create the carousel
		const carousel = document.createElement("section");
		carousel.id = "thumbnail-carousel-" + this.#asin;
		carousel.classList.add("splide");
		carousel.setAttribute("aria-label", "Carousel of thumbnails.");

		const track = document.createElement("div");
		track.classList.add("splide__track");
		carousel.appendChild(track);

		const list = document.createElement("ul");
		list.classList.add("splide__list");
		track.appendChild(list);

		const slide1 = document.createElement("li");
		slide1.classList.add("splide__slide");
		list.appendChild(slide1);

		slide1.appendChild(img);
		if (preReleaseIndicator) {
			slide1.appendChild(preReleaseIndicator);
		}

		//Add the additional images
		for (let i = 1; i < additionalImages.length; i++) {
			const slide = document.createElement("li");
			slide.classList.add("splide__slide");
			list.appendChild(slide);

			const img = document.createElement("img");
			if (useLazyCarouselImages) {
				img.dataset.vhSrc = additionalImages[i];
				img.loading = "lazy";
			} else {
				img.src = additionalImages[i];
				img.loading = "eager";
			}
			img.alt = "thumbnail " + i;
			slide.appendChild(img);
		}

		//Attach the carousel to the image container
		imgContainer.insertBefore(carousel, imgContainer.firstChild);

		//Initialize the carousel and store the instance for cleanup
		// Pass the element (not a selector): tiles may be off-document (e.g. virtual grid pool),
		// so document.querySelector("#thumbnail-carousel-…") would be null.
		// Set live: false to prevent screen reader elements from being created
		// This prevents detached DOM nodes when tiles are moved/reordered
		this.#splideInstance = new Splide(carousel, {
			gap: 1,
			rewind: true,
			pagination: false,
			live: false, // Disable screen reader elements to prevent memory leaks
		});
		this.#splideInstance.on("move", () => {
			if (!useLazyCarouselImages) {
				return;
			}
			// Load the active slide only when this tile is actually visible.
			if (!this.#isTileVisibleInViewport()) {
				return;
			}
			const activeSlideImg = carousel.querySelector(".splide__slide.is-active img[data-vh-src]");
			if (activeSlideImg) {
				lazyImageLoader.loadImage(activeSlideImg);
			}
		});
		this.#splideInstance.mount();
		if (useLazyCarouselImages) {
			lazyImageLoader.observeWithin(carousel);
		}
	}

	setAdditionalImages(images) {
		if (!Settings.isPremiumUser(3) || !Settings.get("general.carousel.active")) {
			return false;
		}
		this.#initCarousel(images);
	}

	async colorizeHighlight() {
		const zeroETV = this.#tileDOM.dataset.typeZeroETV === "1" && Settings.get("general.zeroETVHighlight.active");
		const highlight = this.#tileDOM.dataset.typeHighlight === "1";
		const unknownETV =
			this.#tileDOM.dataset.typeUnknownETV === "1" && Settings.get("general.unknownETVHighlight.active");

		// Get listing color from group if available, otherwise use default
		let highlightColor = null;
		const highlightGroupId = this.#tileDOM.dataset.highlightGroupId;
		if (highlightGroupId && highlight) {
			const { getGroupById } = await import("/scripts/core/utils/KeywordGroupsManager.js");
			const group = await getGroupById(Settings, highlightGroupId);
			if (group) {
				// Use listingColor if set, otherwise fall back to default
				if (group.listingColor !== null && group.listingColor !== undefined) {
					highlightColor = group.listingColor;
				} else {
					// If listingColor is explicitly null, don't highlight (use null)
					highlightColor = null;
				}
			}
		}

		// Debug logging
		if (Settings.get("general.debugKeywords")) {
			console.log("[Tile] colorizeHighlight called:", {
				asin: this.#asin,
				typeHighlight: this.#tileDOM.dataset.typeHighlight,
				typeZeroETV: this.#tileDOM.dataset.typeZeroETV,
				typeUnknownETV: this.#tileDOM.dataset.typeUnknownETV,
				zeroETVHighlightActive: Settings.get("general.zeroETVHighlight.active"),
				unknownETVHighlightActive: Settings.get("general.unknownETVHighlight.active"),
				willHighlight: highlight,
				willHighlightZeroETV: zeroETV,
				willHighlightUnknownETV: unknownETV,
				highlightGroupId,
				customHighlightColor: highlightGroupId && highlight ? highlightColor : null,
			});
		}

		// Use StyleUtils to handle background styling
		// Only apply highlight if highlightColor is not null
		if (highlight && highlightColor !== null) {
			if (zeroETV && !Settings.get("general.highlightColor.ignore0ETVhighlight")) {
				const color1 = Settings.get("general.zeroETVHighlight.color");
				const gradient = StyleUtils.createStripedGradient(color1, highlightColor);
				StyleUtils.applyBackground(this.#tileDOM, gradient, true);
			} else if (unknownETV && !Settings.get("general.highlightColor.ignoreUnknownETVhighlight")) {
				const color1 = Settings.get("general.unknownETVHighlight.color");
				const gradient = StyleUtils.createStripedGradient(color1, highlightColor);
				StyleUtils.applyBackground(this.#tileDOM, gradient, true);
			} else {
				StyleUtils.applyBackground(this.#tileDOM, highlightColor, false);
			}
		} else if (zeroETV) {
			StyleUtils.applyBackground(this.#tileDOM, Settings.get("general.zeroETVHighlight.color"), false);
		} else if (unknownETV) {
			StyleUtils.applyBackground(this.#tileDOM, Settings.get("general.unknownETVHighlight.color"), false);
		} else {
			// Clear any existing styling
			StyleUtils.clearBackgrounds(this.#tileDOM);
		}
	}

	async moveToGrid(g, animate = false) {
		if (g === null) {
			return false;
		}

		//If we are asking to move the tile to the same grid, don't do anything
		if (g.getId() == this.#grid.getId()) return false;

		if (animate) {
			await this.#grid.removeTileAnimate(this);
		} else {
			await this.#grid.removeTile(this); //Avoiding the await keep the method synchronous
		}

		this.#grid = g; //Update the new grid as the current one
		await this.#grid.addTile(this);

		return true;
	}

	async setLocalTileVisibility() {
		// Hidden if in user's hidden list or matches a hide keyword (keyword groups)
		this.#hidden = (await HiddenList.isHidden(this.#asin)) || this.#tileDOM.dataset.hideKeywordMatch === "1";
	}

	#isTileVisibleInViewport() {
		if (!this.#tileDOM) {
			return false;
		}
		if (this.#tileDOM.dataset?.feedPaused === "true" || this.#tileDOM.dataset?.display === "none") {
			return false;
		}
		const rect = this.#tileDOM.getBoundingClientRect();
		const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
		const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
		return rect.bottom > 0 && rect.right > 0 && rect.top < viewportHeight && rect.left < viewportWidth;
	}

	async isHidden() {
		if (!Settings.get("hiddenTab.active") || !this.#asin) {
			return false;
		}

		return this.#hidden;
	}

	async hideTile(animate = true, updateLocalStorage = true, skipHiddenListMgr = false) {
		this.#hidden = true;

		//Add the item to the list of hidden items
		if (!this.#asin) {
			logger.add("WARNING: Cannot hide tile without ASIN");
			return;
		}

		if (!skipHiddenListMgr) {
			HiddenList.addItem(this.#asin, updateLocalStorage);
		}

		//Move the tile
		await this.moveToGrid(this.getGrid().getPage().getGrid("tab-hidden"), animate);

		if (this.#toolbar) {
			this.#toolbar.updateVisibilityIcon();
		}

		//Refresh grid counts
		this.getGrid().getPage().updateTileCounts();
	}

	async showTile(animate = true, updateLocalStorage = true) {
		this.#hidden = false;

		//Remove the item from the array of hidden items
		if (!this.#asin) {
			logger.add("WARNING: Cannot show tile without ASIN");
			return;
		}

		HiddenList.removeItem(this.#asin, updateLocalStorage);

		//Move the tile
		await this.moveToGrid(this.getGrid().getPage().getGrid("vvp-items-grid"), animate);

		if (this.#toolbar) {
			this.#toolbar.updateVisibilityIcon();
		}

		//Refresh grid counts
		this.getGrid().getPage().updateTileCounts();
	}

	#timeSince(timenow, date) {
		const units = [
			{ value: 31536000, unitKeySingular: "bootTimeYear", unitKeyPlural: "bootTimeYears" },
			{ value: 2592000, unitKeySingular: "bootTimeMonth", unitKeyPlural: "bootTimeMonths" },
			{ value: 86400, unitKeySingular: "bootTimeDay", unitKeyPlural: "bootTimeDays" },
			{ value: 3600, unitKeySingular: "bootTimeHr", unitKeyPlural: "bootTimeHrs" },
			{ value: 60, unitKeySingular: "bootTimeMin", unitKeyPlural: "bootTimeMins" },
			{ value: 1, unitKeySingular: "bootTimeSec", unitKeyPlural: "bootTimeSecs" },
		];

		const seconds = Math.floor((timenow - date) / 1000);
		for (const { value, unitKeySingular, unitKeyPlural } of units) {
			const interval = seconds / value;
			if (interval >= 1) {
				const count = Math.floor(interval);
				const unitKey = count > 1 ? unitKeyPlural : unitKeySingular;
				return { count, unitKey };
			}
		}
		return { count: Math.floor(seconds), unitKey: "bootTimeSecs" };
	}

	// Function to animate opacity
	#animateOpacity(element, targetOpacity, duration) {
		return new Promise((resolve) => {
			const startOpacity = parseFloat(getComputedStyle(element).opacity);
			const opacityChange = targetOpacity - startOpacity;
			const startTime = performance.now();

			function animate(time) {
				const elapsed = time - startTime;
				const progress = Math.min(elapsed / duration, 1);
				element.style.opacity = startOpacity + opacityChange * progress;

				if (progress < 1) {
					requestAnimationFrame(animate);
				} else {
					element.style.display = "none"; // Optionally hide the element
					resolve();
				}
			}

			requestAnimationFrame(animate);
		});
	}

	/**
	 * Clean up all event listeners and resources before removing the tile
	 */
	destroy() {
		// Destroy VariantButton instance
		if (this.#variantButton && typeof this.#variantButton.destroy === "function") {
			this.#variantButton.destroy();
			this.#variantButton = null;
		}

		// Clean up Splide carousel
		if (this.#tileDOM) {
			const carousel = this.#tileDOM.querySelector("#thumbnail-carousel-" + this.#asin);
			if (carousel) {
				// Destroy Splide instance (carousel.splide and this.#splideInstance are the same)
				const splide = carousel.splide || this.#splideInstance;
				if (splide && typeof splide.destroy === "function") {
					try {
						splide.destroy(true);
					} catch (e) {
						// Ignore errors
					}
				}
				// Clear img references before removing carousel
				const images = carousel.querySelectorAll("img");
				images.forEach((img) => {
					img.src = "";
					img.srcset = "";
				});
				// Remove carousel from DOM
				if (carousel.parentNode) {
					carousel.parentNode.removeChild(carousel);
				}
			}
			this.#tileDOM = null;
		}
		this.#splideInstance = null;

		// Clean up shared interval if no tiles remain
		if (Tile.titleRestorationInterval) {
			const remainingTiles = document.querySelectorAll(".vvp-item-tile[data-vh-original-title]");
			if (remainingTiles.length === 0) {
				clearInterval(Tile.titleRestorationInterval);
				Tile.titleRestorationInterval = null;
			}
		}
	}
	#getTitleFromDom(tileDom) {
		let textElement = tileDom.querySelector(".a-truncate-full");
		const title = textElement ? textElement.textContent : "";

		// Debug logging
		const settings = new SettingsMgr();
		const asinElement = tileDom.querySelector("[data-asin]");
		const asin = asinElement ? asinElement.dataset.asin : "unknown";

		if (settings.get("general.debugKeywords")) {
			console.log("[getTitleFromDom] Extracting title:", {
				asin: asin,
				title: title.substring(0, 100) + (title.length > 100 ? "..." : ""),
				textElement: textElement,
				tileDom: tileDom,
			});
		}

		// Title debug logging - only if debug is enabled
		if (asin !== "unknown" && settings.get("general.debugTitleDisplay")) {
			getTitleDebugger().then((logger) => logger.logDOMExtraction(asin, "getTitleFromDom", title));
		}

		return title;
	}
	#getThumbnailURLFromDom(tileDom) {
		//Preload.
		let imgElement = tileDom.querySelector(".vvp-item-tile-content > img");
		let url = imgElement ? imgElement.getAttribute("src") || imgElement.dataset?.vhSrc : null;

		if (url == undefined) {
			//Post load of VH added an image container.
			imgElement = tileDom.querySelector(".vh-img-container img");
			url = imgElement ? imgElement.getAttribute("src") || imgElement.dataset?.vhSrc : null;
		}

		return url == undefined ? null : url;
	}
	static getASINFromDom(tileDom) {
		const seeDetailsBtn = tileDom.querySelector("input[type='submit']");
		let asin = null;
		if (seeDetailsBtn) {
			asin = seeDetailsBtn.getAttribute("data-asin");
			if (asin) {
				//logger.add("TILE: Extracted ASIN from See details button: " + asin);
				return asin;
			} else {
				// Fallback: Try to extract ASIN from data-recommendation-id attribute
				// Format: "ATVPDKIKX0DER#B0DWXBZW8K#vine.enrollment...."
				const recommendationId = tileDom.getAttribute("data-recommendation-id");
				if (recommendationId) {
					const parts = recommendationId.split("#");
					if (parts.length >= 2 && parts[1]) {
						// The ASIN is the second part
						//logger.add("TILE: Extracted ASIN from data-recommendation-id: " + parts[1]);
						return parts[1];
					}
				}
			}
		}

		//Extract the ASIN from the URL
		const url = tileDom.querySelector("a.a-link-normal")?.href;
		if (url) {
			const regex = /\/dp\/([A-Z0-9]{10})/;
			asin = url.match(regex)[1];
			if (asin) {
				//logger.add("TILE: Extracted ASIN from URL: " + asin);
				return asin;
			}
		}

		// If all methods fail, log a warning and return null instead of throwing
		logger.add(
			"TILE: WARNING - Could not extract ASIN from tile. Tile HTML: " + tileDom.outerHTML.substring(0, 200)
		);
		console.warn("VHelper: Could not extract ASIN from tile", tileDom);
		return null;
	}

	static getTileFromDom(tileDom) {
		const asin = Tile.getASINFromDom(tileDom);
		if (!asin) {
			logger.add("TILE: WARNING - getTileFromDom called with tile that has no ASIN");
			return null;
		}
		// Access Page instance through window to avoid circular dependency
		// Page is a singleton, so we can access it this way
		if (window.VHelperPageInstance) {
			return window.VHelperPageInstance.getTileByASIN(asin);
		}
		// Fallback: try to find Page instance through the tile's DOM
		const gridElement = tileDom.closest('[id^="vvp-items-grid"], [id^="tab-"]');
		if (gridElement && gridElement._VHelperGrid) {
			return gridElement._VHelperGrid.getPage().getTileByASIN(asin);
		}
		logger.add("TILE: WARNING - Could not find Page instance to get tile");
		return null;
	}
}

export { Tile };
