import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
var Settings = new SettingsMgr();

import { Environment } from "/scripts/core/services/Environment.js";
var env = new Environment();

import { ModalMgr } from "/scripts/ui/controllers/ModalMgr.js";
var dialogMgr = new ModalMgr();

import { Internationalization } from "/scripts/core/services/Internationalization.js";
var i18n = new Internationalization();

import { Item } from "/scripts/core/models/Item.js";

import { PinnedListMgr } from "/scripts/core/services/PinnedListMgr.js";
var PinnedList = new PinnedListMgr();

import { HiddenListMgr } from "/scripts/core/services/HiddenListMgr.js";
var HiddenList = new HiddenListMgr();

import { Template } from "/scripts/core/utils/Template.js";
var Tpl = new Template();

import { escapeHTML } from "/scripts/core/utils/StringHelper.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";

import { BrendaAnnounceQueue } from "/scripts/core/services/BrendaAnnounce.js";
import { KeywordMatcherService } from "/scripts/core/services/KeywordMatcherService.js";
var brendaAnnounceQueue = new BrendaAnnounceQueue();

import { ScreenNotifier, ScreenNotification } from "/scripts/ui/components/ScreenNotifier.js";
var Notifications = new ScreenNotifier();

class Toolbar {
	#tile;
	#toolbarDOM;

	#pinDebounceTimer = null;
	#pinDebounceClickable = true;

	// Keyword matcher service (handles all keyword logic with lazy compilation)
	#keywordMatcher = null;
	#keywordsInitialized = false;
	#keywordsInitPromise = null;

	constructor(tileInstance) {
		this.#tile = tileInstance;
		this.#tile.setToolbar(this);

		// Initialize keyword matcher service (lazy loads keywords when first used)
		this.#keywordsInitPromise = this.#initializeKeywords();
	}

	async #initializeKeywords() {
		await Settings.waitForLoad();
		const isPremiumTier2 = Settings.isPremiumUser(2);
		this.#keywordMatcher = new KeywordMatcherService(Settings, isPremiumTier2);
		await this.#keywordMatcher.initialize();
		this.#keywordsInitialized = true;
	}

	async #ensureKeywordsInitialized() {
		if (!this.#keywordsInitialized && this.#keywordsInitPromise) {
			await this.#keywordsInitPromise;
		}
	}

	getTile() {
		return this.#tile;
	}

	//Create the bare bone structure of the toolbar
	async updateProductToolbar() {
		// Use a fallback ID if ASIN is not available
		const asin = this.#tile.getAsin() || `no-asin-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
		const toolbarId = "vh-toolbar-" + asin;
		let anchorTo = this.#tile.getDOM().querySelector(".vvp-item-tile-content"); //.vvp-item-tile-content should be the first child

		if (!anchorTo) {
			throw new Error("Cannot find .vvp-item-tile-content to attach toolbar");
		}

		// Check if toolbar already exists (from template) BEFORE rendering a new one
		this.#toolbarDOM = anchorTo.querySelector(`#${toolbarId}`);
		if (!this.#toolbarDOM) {
			logger.add(`TOOLBAR: Not found for ASIN: ${asin}.`);
		}

		this.updateOrderWidget();

		// Apply toolbar styling
		const container = this.#toolbarDOM.querySelector(`.vh-status-container`);
		if (container) {
			container.style.backgroundColor = Settings.get("general.toolbarBackgroundColor");
		}

		const container2 = this.#toolbarDOM.querySelector(`.vh-status-container2`);
		if (!container2) {
			logger.add(`TOOLBAR ERROR: .vh-status-container2 not found for ASIN: ${asin}`);
			console.error("TOOLBAR: Toolbar DOM structure:", this.#toolbarDOM.outerHTML);
			// Don't return - continue to attach other event handlers
		}

		const etvToolbar = this.#toolbarDOM.querySelector(`.vh-toolbar-etv`);
		if (etvToolbar && !Settings.get("general.listView")) {
			etvToolbar.style.display = "none";
		}

		// Activate the announce button when the ETV is set (changed)
		if (container2) {
			const etvElements = container2.querySelectorAll(".etv");
			etvElements.forEach((etv) => {
				// Create the click handler outside the change event
				const announceClickHandler = async (e) => {
					e.preventDefault();

					if (env.data.vineQueue == null) throw new Exception("Cannot announce an item in an unknown queue.");

					const etvElement = this.#tile.getDOM().querySelector(".etv");
					if (!etvElement) {
						logger.add(
							`TOOLBAR: Cannot find .etv element for announcement - ASIN: ${this.#tile.getAsin()}`
						);
						return;
					}
					let etv = etvElement.textContent;

					// In case of price range, only send the highest value
					etv = etv.split("-").pop();
					etv = Number(etv.replace(/[^0-9-.]+/g, ""));

					brendaAnnounceQueue.announce(this.#tile.getAsin(), etv, env.data.vineQueue, i18n.getDomainTLD());

					if (!Settings.get("notification.reduce")) {
						let note = new ScreenNotification();
						note.title = "Announce to Brenda";
						note.lifespan = 10;
						note.content = `Sending this product ${this.#tile.getAsin()} from the ${env.data.vineQueueAbbr} queue to Brenda over on discord`;
						await Notifications.pushNotification(note);
					}

					// Visually deactivate this item
					let tileDOM = this.#tile.getDOM();
					let announcementIcon = tileDOM.querySelector(".vh-icon-announcement");
					if (announcementIcon) {
						let parentAnchor = announcementIcon.parentElement;
						if (parentAnchor && parentAnchor.tagName === "A") {
							parentAnchor.removeEventListener("click", announceClickHandler);
							parentAnchor.style.opacity = "0.3";
						}
					}
				};

				etv.addEventListener("change", (event) => {
					if (event.currentTarget.textContent === "") return false;
					if (env.data.vineSearch) return false;

					let tileDOM = this.#tile.getDOM();
					let announcementIcon = tileDOM.querySelector(".vh-icon-announcement");

					if (announcementIcon) {
						announcementIcon.style.opacity = "1";
						let parentAnchor = announcementIcon.parentElement;
						if (parentAnchor && parentAnchor.tagName === "A") {
							// Only add the click handler once
							parentAnchor.removeEventListener("click", announceClickHandler);
							parentAnchor.addEventListener("click", announceClickHandler);
						}
					}
				});
			});
		} else {
			logger.add(`TOOLBAR WARNING: Cannot set up ETV change handlers - container2 is null for ASIN: ${asin}`);
		}

		//Display the hide link
		if (Settings.get("hiddenTab.active")) {
			let h = this.#toolbarDOM.querySelector(`#vh-hide-link-${this.#tile.getAsin()}`);
			if (h) {
				h.addEventListener("click", async (event) => {
					event.preventDefault();
					// A hide/display item button was pressed
					let asin = this.#tile.getAsin(); // Directly access ASIN from the context
					let tile = this.getTile().getGrid().getPage().getTileByASIN(asin);
					let gridId = tile.getGridId();

					switch (
						gridId // Current Grid
					) {
						case "vvp-items-grid":
						case "tab-unavailable":
							tile.hideTile();
							break;
						case "tab-hidden":
							tile.showTile();
							break;
					}

					this.getTile().getGrid().getPage().updateTileCounts();
				});
			} else {
				logger.add(`TOOLBAR WARNING: Hide link not found for ASIN: ${this.#tile.getAsin()}`);
			}

			this.updateVisibilityIcon();
		}

		//Details icon
		if (Settings.get("general.detailsIcon")) {
			let detailsIcon = this.#toolbarDOM.querySelector(`#vh-details-link-${this.#tile.getAsin()}`);
			if (detailsIcon) {
				detailsIcon.addEventListener("click", async (event) => {
					event.preventDefault();
					//Get the details from the parent dom element matching .vvp-item-tile
					let tileDOM = this.#tile.getDOM();
					let details = tileDOM.closest(".vvp-item-tile").dataset;

					//Display modal windows with the details.
					let m = dialogMgr.newModal("item-details-" + this.#tile.getAsin());
					m.title = "Item " + this.#tile.getAsin();
					// Get blur keyword from blurredKeyword or fallback to blurkw
					const blurKeyword = details.blurredKeyword || details.blurkw || "";
					const firstSeenLbl = getMessage("itemDetailsFirstSeenColon", "First Seen: ");
					const highlightLbl = getMessage("itemDetailsHighlightKWMatching", "Highlight Keyword matching: ");
					const hideLbl = getMessage("itemDetailsHideKWMatching", "Hide Keyword matching: ");
					const blurLbl = getMessage("itemDetailsBlurKWMatching", "Blur Keyword matching: ");
					m.content = `
			<ul style="margin-bottom: 10px;">
				<li>${firstSeenLbl}${details.date}</li>
				<li>${highlightLbl}${details.highlightedKeyword || ""}</li>
				<li>${hideLbl}${details.hideKeyword || ""}</li>
				<li>${blurLbl}${blurKeyword}</li>
			</ul>
		`;
					m.show();
				});
			} else {
				logger.add(`TOOLBAR WARNING: Details link not found for ASIN: ${this.#tile.getAsin()}`);
			}
		}

		//Pinned items event handler
		if (Settings.get("pinnedTab.active")) {
			let h2 = this.#toolbarDOM.querySelector(`#vh-pin-link-${this.#tile.getAsin()}`);

			if (h2) {
				h2.addEventListener("click", async (event) => {
					event.preventDefault();
					const target = event.target;
					//Debounce the pin click event
					if (!this.#pinDebounceClickable) {
						return false;
					}
					this.#pinDebounceClickable = false;
					target.classList.add("vh-disabled"); //Visually disable the pin click
					this.#pinDebounceTimer = setTimeout(async () => {
						this.#pinDebounceClickable = true;
						target.classList.remove("vh-disabled");
						clearTimeout(this.#pinDebounceTimer);
					}, 1000);
					//End of debounce

					// A hide/display item button was pressed
					let asin = this.#tile.getAsin(); // Directly access ASIN
					let tile = this.getTile().getGrid().getPage().getTileByASIN(asin);

					// Get the item title and thumbnail
					let title = tile.getTitle();
					let thumbnail = tile.getThumbnailURL();
					let etv_min = tile.getItem().data.etv_min || null;
					let etv_max = tile.getItem().data.etv_max || null;
					let price = tile.getItem().data.price || null;
					let order_success = tile.getItem().data.order_success || "-";
					let order_failed = tile.getItem().data.order_failed || "-";

					const btn = document.querySelector(`input[data-asin="${asin}"]`);

					if (btn) {
						//Check if the item is already pinned
						if (tile.isPinned()) {
							//Unpin the item
							tile.setPinned(false);
							await this.getTile().getGrid().getPage().removePinnedTile(asin);
						} else {
							//Pin the item
							tile.setPinned(true);
							const is_parent_asin = btn.dataset.isParentAsin;
							const enrollment_guid = btn.dataset.recommendationId.match(
								/#vine\.enrollment\.([a-f0-9-]+)/i
							)[1];

							try {
								const item = new Item({
									asin: asin,
									queue: env.data.vineQueue,
									title: title,
									etv_min: etv_min,
									etv_max: etv_max,
									price: price,
									order_success: order_success,
									order_failed: order_failed,
									img_url: thumbnail,
									is_parent_asin: is_parent_asin,
									enrollment_guid: enrollment_guid,
								});
								PinnedList.addItem(item);
								const page = this.getTile().getGrid().getPage();
								await page.addPinnedTile(item);
								if (page.usesRemotePinnedStorage()) {
									page.adjustPinnedRemoteCount(1);
								}
							} catch (error) {
								console.error("[Toolbar] Cannot create item for pinning -", error.message, {
									source: "pin button click",
									asin: asin,
									queue: env.data.vineQueue,
									is_parent_asin: is_parent_asin,
									enrollment_guid: enrollment_guid,
								});
							}
						}

						this.getTile().getGrid().getPage().updateTileCounts();
					}
				});
			}
		}
	}

	updateVisibilityIcon() {
		if (!Settings.get("hiddenTab.active")) {
			return false;
		}

		if (!this.#toolbarDOM) {
			return false;
		}

		let icon = this.#toolbarDOM.querySelector(`#vh-hide-link-${this.#tile.getAsin()} div.vh-toolbar-icon`);
		let gridId = this.#tile.getGridId();

		if (icon) {
			// Remove classes
			icon.classList.remove("vh-icon-hide", "vh-icon-show");

			// Add classes based on gridId
			switch (gridId) {
				case "vvp-items-grid":
				case "tab-unavailable":
					icon.classList.add("vh-icon-hide");
					break;
				case "tab-hidden":
					icon.classList.add("vh-icon-show");
					break;
			}
		}
	}

	setETV(etv1, etv2, onlyIfEmpty = false) {
		// Check if toolbar DOM exists
		if (!this.#toolbarDOM) {
			logger.add(`TOOLBAR: Cannot set ETV - toolbar DOM is null for ASIN: ${this.#tile.getAsin()}`);
			return false;
		}

		if (Settings.get("general.displayETV")) {
			const etvToolbar = this.#toolbarDOM.querySelector(".vh-toolbar-etv");
			if (etvToolbar) {
				etvToolbar.style.display = "flex";
			}
		} else {
			return false;
		}

		let span = this.#toolbarDOM.querySelector(".vh-toolbar-etv .etv");

		// Check if the ETV span exists
		if (!span) {
			logger.add(`TOOLBAR: Cannot set ETV - .vh-toolbar-etv .etv not found for ASIN: ${this.#tile.getAsin()}`);
			return false;
		}

		if (onlyIfEmpty && span.textContent !== "") {
			return false;
		}

		let etv1ToFormat = etv1;
		let etv2ToFormat = etv2;
		if (Settings.isPremiumUser(2)) {
			etv1ToFormat = etv1 * Settings.get("general.ETV.modifier");
			etv2ToFormat = etv2 * Settings.get("general.ETV.modifier");
		}
		const formattedETV1 = new Intl.NumberFormat(i18n.getLocale(), {
			style: "currency",
			currency: i18n.getCurrency(),
		}).format(etv1ToFormat);
		const formattedETV2 = new Intl.NumberFormat(i18n.getLocale(), {
			style: "currency",
			currency: i18n.getCurrency(),
		}).format(etv2ToFormat);

		const originalETV = etv1 === etv2 ? etv2 : `${etv1}-${etv2}`;
		const newETV = etv1 === etv2 ? formattedETV2 : `${formattedETV1}-${formattedETV2}`;
		span.textContent = newETV;
		span.title = getMessage("nmETVTitleSingle", "ETV: $1$", [String(originalETV)]);

		// processHighlight is async but we don't need to await it here
		this.processHighlight(etv1, etv2).catch((e) => {
			console.error("Error in processHighlight:", e);
		});

		// Trigger change event manually
		let changeEvent = new Event("change", { bubbles: true });
		span.dispatchEvent(changeEvent);
	}

	setPrice(price) {
		if (!Settings.isPremiumUser(3) || !Settings.get("general.displayPrice")) {
			return false;
		}

		const etvToolbar = this.#toolbarDOM.querySelector(".vh-toolbar-etv");
		if (etvToolbar) {
			etvToolbar.style.display = "flex";
		}

		const formattedPrice = new Intl.NumberFormat(i18n.getLocale(), {
			style: "currency",
			currency: i18n.getCurrency(),
		}).format(price);

		let span = this.#toolbarDOM.querySelector(".vh-toolbar-etv .price");
		if (span) {
			span.textContent = formattedPrice;
			span.classList.add("defined");

			//If list view mode, add a margin-left and margin-right to the span
			if (Settings.get("general.listView")) {
				span.style.marginLeft = "20px";
				span.style.marginRight = "20px";
			}
		}
	}

	unknownETV() {
		// processHighlight is async but we don't need to await it here
		this.processHighlight(null, null).catch((e) => {
			console.error("Error in processHighlight:", e);
		});
	}

	//Why is this method in the toolbar class and not the tile class? Who coded this?!
	async processHighlight(etv1, etv2) {
		// Ensure keywords are initialized before processing
		await this.#ensureKeywordsInitialized();

		logger.add("Toolbar: processHighlight");

		let match;
		const oldHighlight = this.#tile.getDOM().dataset.highlightedKeyword;
		this.#tile.getDOM().dataset.highlightedKeyword = "";
		this.#tile.getDOM().dataset.hideKeyword = "";

		const title = this.#tile.getTitle();
		const asin = this.#tile.getAsin();

		// Use keyword matcher service
		if (this.#keywordMatcher) {
			match = this.#keywordMatcher.findHighlightHideMatchSync(title, etv1, etv2);

			if (match && match.type === "highlight") {
				logger.add("Toolbar: processHighlight: match");
				const matchString = typeof match === "object" ? match.contains || match.word || "" : match;

				if (Settings.get("general.debugKeywords")) {
					console.log("[Toolbar] Highlight match found:", {
						asin: asin,
						title: title.substring(0, 100),
						matchedKeyword: matchString,
						matchObject: match,
					});
				}

				const currentTypeHighlight = this.#tile.getDOM().dataset.typeHighlight;

				this.#tile.getDOM().dataset.highlightedKeyword = escapeHTML(matchString);
				this.#tile.getDOM().dataset.keywordHighlight = true;
				this.#tile.getDOM().dataset.typeHighlight = "1";

				// Only move to top if typeHighlight value is actually changing (to prevent unnecessary moves)
				if (
					Settings.get("general.highlightKWFirst") &&
					!(await HiddenList.isHidden(asin)) &&
					currentTypeHighlight != "1" //If the item is already highlighted, do not move it to the top
				) {
					// Check if item is already at the top
					const gridDOM = this.#tile.getGrid().getDOM();
					const isAtTop = gridDOM.firstChild === this.#tile.getDOM();

					// Move to top if not already there (either first time highlighting or tiles were regenerated)
					if (!isAtTop) {
						logger.add("Toolbar: processHighlight: highlightKWFirst - moving to top");
						gridDOM.insertBefore(this.#tile.getDOM(), gridDOM.firstChild);
					} else if (!oldHighlight) {
						// Only log if this is the first time highlighting (not a re-highlight after tile regeneration)
						logger.add("Toolbar: processHighlight: highlightKWFirst - already at top");
					}
				}
			} else if (match && match.type === "hide") {
				logger.add("Toolbar: processHide: hide match");
				// Hide the tile
				if (Settings.get("hiddenTab.active")) {
					this.#tile.hideTile(false, false, true); //Do not save, skip the hidden manager: just move the tile.
					const hideLink = document.getElementById("vh-hide-link-" + asin);
					if (hideLink) {
						hideLink.style.display = "none";
					}

					//Add a data-hide-keyword attribute to the tile
					const hideMatchString = typeof match === "object" ? match.contains || match.word || "" : match;
					this.#tile.getDOM().dataset.hideKeyword = escapeHTML(hideMatchString);
				}
				this.#tile.getDOM().dataset.keywordHighlight = false;
				this.#tile.getDOM().dataset.typeHighlight = "0";
			} else {
				logger.add("Toolbar: processHighlight: no match");
				//No match now, remove the highlight
				this.#tile.getDOM().dataset.keywordHighlight = false;
				this.#tile.getDOM().dataset.typeHighlight = "0";
			}
		} else {
			this.#tile.getDOM().dataset.keywordHighlight = false;
			this.#tile.getDOM().dataset.typeHighlight = "0";
		}

		if (etv1 === null && etv2 === null) {
			logger.add("Toolbar: processHighlight: unknownETV");
			this.#tile.getDOM().dataset.unknownETV = true;
			this.#tile.getDOM().dataset.zeroETV = false;
			this.#tile.getDOM().dataset.typeUnknownETV = "1";
			this.#tile.getDOM().dataset.typeZeroETV = "0";
		} else if (parseFloat(etv1) == 0 || parseFloat(etv2) == 0) {
			logger.add("Toolbar: processHighlight: zeroETV");
			this.#tile.getDOM().dataset.zeroETV = true;
			this.#tile.getDOM().dataset.unknownETV = false;
			this.#tile.getDOM().dataset.typeZeroETV = "1";
			this.#tile.getDOM().dataset.typeUnknownETV = "0";
		} else {
			this.#tile.getDOM().dataset.zeroETV = false;
			this.#tile.getDOM().dataset.unknownETV = false;
			this.#tile.getDOM().dataset.typeZeroETV = "0";
			this.#tile.getDOM().dataset.typeUnknownETV = "0";
		}

		logger.add("Toolbar: processHighlight: colorize");
		this.#tile.colorizeHighlight();
	}

	/** Update the order widget part of the toolbar
	 * Can be called by bootloader when receiving order messages
	 * @param {boolean} status - The status of the order
	 * @returns {Promise<string>} The HTML for the order widget
	 */
	async updateOrderWidget(status = null) {
		// Get the current order info
		let success = status && status !== null ? this.#tile.getOrderSuccess() + 1 : this.#tile.getOrderSuccess();
		let failed = !status && status !== null ? this.#tile.getOrderFailed() + 1 : this.#tile.getOrderFailed();
		this.#tile.setOrders(success, failed);
	}

	async createOrderWidget() {
		// Generate the HTML for the widget
		let prom = await Tpl.loadFile("scripts/ui/templates/widget_order.html");
		Tpl.setVar("order_success", "-");
		Tpl.setVar("order_failed", "-");
		let content = Tpl.render(prom, false);
		return content;
	}
}

export { Toolbar };
