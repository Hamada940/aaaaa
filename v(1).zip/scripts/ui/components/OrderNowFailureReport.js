import { getMessage } from "/scripts/core/services/Internationalization.js";
import { serializeForDebug } from "/scripts/core/utils/serializeForDebug.js";
import { ValidationError } from "/scripts/core/utils/ExpectationValidator.js";
import { queueApiValidationFailure } from "/scripts/core/services/ApiValidationMonitor.js";

/** @typedef {"see-details" | "voiceOrders" | "variants" | "voiceOrders-json"} OrderNowFailureStep */
/** @typedef {"validation" | "invalid-json" | "http" | "vine-error"} OrderNowFailureKind */

/**
 * @typedef {Object} OrderNowFailureRequest
 * @property {string} method
 * @property {string} url
 * @property {string} [referrer]
 * @property {unknown} [body]
 */

/**
 * @typedef {Object} OrderNowFailureValidation
 * @property {string} path
 * @property {string} message
 * @property {string|undefined} expected
 * @property {unknown} actual
 * @property {unknown} expectationTemplate
 * @property {unknown} receivedPayload
 */

/**
 * @typedef {Object} OrderNowFailureDebugReport
 * @property {OrderNowFailureStep} step
 * @property {OrderNowFailureKind} failureKind
 * @property {OrderNowFailureRequest} request
 * @property {OrderNowFailureValidation|null} validation
 * @property {string} [httpStatus]
 * @property {string} [vineError]
 * @property {string} [rawResponseText]
 * @property {string} [contextNote]
 */

/**
 * @returns {string}
 */
export function getInvalidJsonCsrfContextNote() {
	return getMessage(
		"buyNowFailureInvalidJsonCsrfHint",
		"This usually happens when the CSRF token is invalid. Refresh an Amazon Vine page and the monitor, then try again."
	);
}

export class OrderNowFailureError extends Error {
	/**
	 * @param {OrderNowFailureDebugReport} debugReport
	 */
	constructor(debugReport) {
		super(
			getMessage(
				"buyNowFailureModalLead",
				"VH received an unexpected value from Vine's server and aborted the ordering process."
			)
		);
		this.name = "OrderNowFailureError";
		/** @type {OrderNowFailureDebugReport} */
		this.debugReport = debugReport;
	}

	/**
	 * @param {Object} params
	 * @param {OrderNowFailureStep} params.step
	 * @param {OrderNowFailureRequest} params.request
	 * @param {ValidationError} params.validationError
	 * @param {unknown} params.expectation
	 * @param {unknown} params.received
	 * @returns {OrderNowFailureError}
	 */
	static fromValidation({ step, request, validationError, expectation, received }) {
		const debugReport = {
			step,
			failureKind: "validation",
			request,
			validation: {
				path: validationError.path,
				message: validationError.reason || validationError.message,
				expected: validationError.expected,
				actual: validationError.actual,
				expectationTemplate: expectation,
				receivedPayload: received,
			},
		};
		queueApiValidationFailure(debugReport);
		return new OrderNowFailureError(debugReport);
	}

	/**
	 * @param {Object} params
	 * @param {OrderNowFailureStep} params.step
	 * @param {OrderNowFailureRequest} params.request
	 * @param {string} params.rawResponseText
	 * @returns {OrderNowFailureError}
	 */
	static fromInvalidJson({ step, request, rawResponseText }) {
		const debugReport = {
			step,
			failureKind: "invalid-json",
			request,
			validation: null,
			rawResponseText,
			contextNote: getInvalidJsonCsrfContextNote(),
		};
		return new OrderNowFailureError(debugReport);
	}
}

/**
 * @param {string} value
 * @returns {string}
 */
function escapeHtml(value) {
	return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/**
 * @param {unknown} value
 * @returns {string}
 */
function formatDebugBlock(value) {
	return escapeHtml(serializeForDebug(value));
}

/**
 * @param {unknown} value
 * @returns {boolean}
 */
function isObjectLike(value) {
	return value !== null && typeof value === "object";
}

/**
 * @param {unknown} value
 * @returns {string}
 */
function formatScalar(value) {
	if (value === undefined) {
		return "[undefined]";
	}
	if (value === null) {
		return "null";
	}
	if (typeof value === "object") {
		return serializeForDebug(value);
	}
	return String(value);
}

/**
 * @param {Record<string, unknown>|unknown} root
 * @param {string} path
 * @returns {unknown}
 */
function getValueAtPath(root, path) {
	if (!path) {
		return root;
	}
	if (!isObjectLike(root)) {
		return undefined;
	}
	const parts = path.split(".");
	let current = root;
	for (const part of parts) {
		if (!isObjectLike(current) || !(part in current)) {
			return undefined;
		}
		current = current[part];
	}
	return current;
}

/**
 * @param {unknown} value
 * @returns {string}
 */
function formatDiffBlock(value) {
	return formatDebugBlock(value === undefined ? "[path not found]" : value);
}

/**
 * @param {OrderNowFailureDebugReport} report
 * @returns {string}
 */
export function buildOrderNowFailurePlainText(report) {
	const lines = [];
	const title = getMessage("buyNowFailureModalTitle", "Order Now failed :(");
	const lead = getMessage(
		"buyNowFailureModalLead",
		"VH received an unexpected value from Vine's server and aborted the ordering process."
	);

	lines.push(title);
	lines.push(lead);
	lines.push("");
	lines.push("=== Failed request ===");
	lines.push(`Step: ${report.step}`);
	lines.push(`Failure kind: ${report.failureKind}`);
	lines.push(`Method: ${report.request.method}`);
	lines.push(`URL: ${report.request.url}`);
	if (report.request.referrer) {
		lines.push(`Referrer: ${report.request.referrer}`);
	}
	if (report.request.body !== undefined) {
		lines.push("Request body:");
		lines.push(serializeForDebug(report.request.body));
	}
	if (report.httpStatus) {
		lines.push(`HTTP status: ${report.httpStatus}`);
	}
	if (report.vineError) {
		lines.push(`Vine error: ${report.vineError}`);
	}
	if (report.contextNote) {
		lines.push(`Note: ${report.contextNote}`);
	}

	if (report.validation) {
		const expectedAtPath = getValueAtPath(report.validation.expectationTemplate, report.validation.path || "");
		const receivedAtPath = getValueAtPath(report.validation.receivedPayload, report.validation.path || "");
		lines.push("");
		lines.push("=== Validation failure ===");
		lines.push(`Field path: ${report.validation.path || "(root)"}`);
		lines.push(`Reason: ${report.validation.message}`);
		if (report.validation.expected != null && report.validation.expected !== "") {
			lines.push(`Expected: ${report.validation.expected}`);
		}
		lines.push(`Received at path: ${formatScalar(report.validation.actual)}`);
		lines.push("");
		lines.push("=== Failed criteria diff ===");
		lines.push("[Expected at path]");
		lines.push(serializeForDebug(expectedAtPath === undefined ? "[path not found]" : expectedAtPath));
		lines.push("[Received at path]");
		lines.push(serializeForDebug(receivedAtPath === undefined ? report.validation.actual : receivedAtPath));
		lines.push("");
		lines.push("=== Full expected schema ===");
		lines.push(serializeForDebug(report.validation.expectationTemplate));
		lines.push("");
		lines.push("=== Full received response ===");
		lines.push(serializeForDebug(report.validation.receivedPayload));
	} else if (report.rawResponseText != null) {
		lines.push("");
		lines.push("=== Raw response body (not valid JSON) ===");
		lines.push(report.rawResponseText);
	}

	lines.push("");
	lines.push(`Generated: ${new Date().toISOString()}`);
	return lines.join("\n");
}

/**
 * @param {OrderNowFailureDebugReport} report
 * @returns {string}
 */
export function buildOrderNowFailureHtml(report) {
	const lead = escapeHtml(
		getMessage(
			"buyNowFailureModalLead",
			"VH received an unexpected value from Vine's server and aborted the ordering process."
		)
	);
	const detailsLabel = escapeHtml(getMessage("buyNowFailureModalDetailsLabel", "Details:"));
	const requestLabel = escapeHtml(getMessage("buyNowFailureModalRequestLabel", "Failed request"));
	const validationLabel = escapeHtml(getMessage("buyNowFailureModalValidationLabel", "Validation failure"));
	const expectedLabel = escapeHtml(getMessage("buyNowFailureModalExpectedLabel", "Full expected schema"));
	const receivedLabel = escapeHtml(getMessage("buyNowFailureModalReceivedLabel", "Full received response"));
	const rawLabel = escapeHtml(getMessage("buyNowFailureModalRawResponseLabel", "Raw response body (not valid JSON)"));
	const copyLabel = escapeHtml(getMessage("buyNowFailureModalCopyButton", "Copy all details"));
	const copiedLabel = escapeHtml(getMessage("buyNowFailureModalCopiedButton", "Copied!"));

	const requestBody =
		report.request.body !== undefined
			? `<div class="vh-order-now-failure__block">
					<div class="vh-order-now-failure__label">${escapeHtml(getMessage("buyNowFailureModalRequestBodyLabel", "Request body"))}</div>
					<pre class="vh-order-now-failure__pre" tabindex="0">${formatDebugBlock(report.request.body)}</pre>
				</div>`
			: "";

	const requestSection = `<section class="vh-order-now-failure__section">
		<h3 class="vh-order-now-failure__heading">${requestLabel}</h3>
		<dl class="vh-order-now-failure__defs">
			<dt>${escapeHtml(getMessage("buyNowFailureModalStepLabel", "Step"))}</dt><dd>${escapeHtml(report.step)}</dd>
			<dt>${escapeHtml(getMessage("buyNowFailureModalKindLabel", "Failure kind"))}</dt><dd>${escapeHtml(report.failureKind)}</dd>
			<dt>${escapeHtml(getMessage("buyNowFailureModalMethodLabel", "Method"))}</dt><dd>${escapeHtml(report.request.method)}</dd>
			<dt>${escapeHtml(getMessage("buyNowFailureModalUrlLabel", "URL"))}</dt><dd class="vh-order-now-failure__mono">${escapeHtml(report.request.url)}</dd>
			${
				report.request.referrer
					? `<dt>${escapeHtml(getMessage("buyNowFailureModalReferrerLabel", "Referrer"))}</dt><dd class="vh-order-now-failure__mono">${escapeHtml(report.request.referrer)}</dd>`
					: ""
			}
			${
				report.httpStatus
					? `<dt>${escapeHtml(getMessage("buyNowFailureModalHttpStatusLabel", "HTTP status"))}</dt><dd>${escapeHtml(report.httpStatus)}</dd>`
					: ""
			}
			${
				report.vineError
					? `<dt>${escapeHtml(getMessage("buyNowFailureModalVineErrorLabel", "Vine error"))}</dt><dd>${escapeHtml(report.vineError)}</dd>`
					: ""
			}
		</dl>
		${requestBody}
	</section>`;

	let validationSection = "";
	if (report.validation) {
		const v = report.validation;
		const expectedAtPath = getValueAtPath(v.expectationTemplate, v.path || "");
		const receivedAtPath = getValueAtPath(v.receivedPayload, v.path || "");
		const expectedCriterionText =
			v.expected != null && v.expected !== ""
				? escapeHtml(v.expected)
				: escapeHtml(getMessage("buyNowFailureModalNoCriterionLabel", "No explicit criterion"));

		validationSection = `<section class="vh-order-now-failure__section">
			<h3 class="vh-order-now-failure__heading">${validationLabel}</h3>
			<dl class="vh-order-now-failure__defs">
				<dt>${escapeHtml(getMessage("buyNowFailureModalFieldPathLabel", "Field path"))}</dt><dd class="vh-order-now-failure__mono">${escapeHtml(v.path || "(root)")}</dd>
				<dt>${escapeHtml(getMessage("buyNowFailureModalReasonLabel", "Reason"))}</dt><dd>${escapeHtml(v.message)}</dd>
				<dt>${escapeHtml(getMessage("buyNowFailureModalExpectedCriterionLabel", "Expected criterion"))}</dt><dd class="vh-order-now-failure__mono">${expectedCriterionText}</dd>
				<dt>${escapeHtml(getMessage("buyNowFailureModalReceivedValueLabel", "Received value at path"))}</dt>
				<dd><pre class="vh-order-now-failure__pre vh-order-now-failure__pre--inline" tabindex="0">${formatDebugBlock(v.actual)}</pre></dd>
			</dl>
			<div class="vh-order-now-failure__diff" role="group" aria-label="${escapeHtml(getMessage("buyNowFailureModalDiffLabel", "Expected vs received at failed path"))}">
				<div class="vh-order-now-failure__diff-col vh-order-now-failure__diff-col--expected">
					<div class="vh-order-now-failure__label">${escapeHtml(getMessage("buyNowFailureModalExpectedAtPathLabel", "Expected at failed path"))}</div>
					<pre class="vh-order-now-failure__pre" tabindex="0">${formatDiffBlock(expectedAtPath)}</pre>
				</div>
				<div class="vh-order-now-failure__diff-col vh-order-now-failure__diff-col--received">
					<div class="vh-order-now-failure__label">${escapeHtml(getMessage("buyNowFailureModalReceivedAtPathLabel", "Received at failed path"))}</div>
					<pre class="vh-order-now-failure__pre" tabindex="0">${formatDiffBlock(receivedAtPath === undefined ? v.actual : receivedAtPath)}</pre>
				</div>
			</div>
			<div class="vh-order-now-failure__block">
				<div class="vh-order-now-failure__label">${expectedLabel}</div>
				<pre class="vh-order-now-failure__pre" tabindex="0">${formatDebugBlock(v.expectationTemplate)}</pre>
			</div>
			<div class="vh-order-now-failure__block">
				<div class="vh-order-now-failure__label">${receivedLabel}</div>
				<pre class="vh-order-now-failure__pre" tabindex="0">${formatDebugBlock(v.receivedPayload)}</pre>
			</div>
		</section>`;
	} else if (report.rawResponseText != null) {
		validationSection = `<section class="vh-order-now-failure__section">
			<h3 class="vh-order-now-failure__heading">${rawLabel}</h3>
			<pre class="vh-order-now-failure__pre" tabindex="0">${escapeHtml(report.rawResponseText)}</pre>
		</section>`;
	}

	const contextNote = report.contextNote
		? `<p class="vh-order-now-failure__hint">${escapeHtml(report.contextNote)}</p>`
		: "";

	return `<div class="vh-order-now-failure">
		<p class="vh-order-now-failure__lead">${lead}</p>
		${contextNote}
		<p class="vh-order-now-failure__details-label"><strong>${detailsLabel}</strong></p>
		${requestSection}
		${validationSection}
		<div class="vh-order-now-failure__actions">
			<button type="button" class="vh-order-now-failure__copy" data-copied-label="${copiedLabel}">${copyLabel}</button>
		</div>
	</div>`;
}
