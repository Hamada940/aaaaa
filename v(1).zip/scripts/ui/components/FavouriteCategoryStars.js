/**
 * Injects toggleable star icons next to Vine browse-node subcategories.
 *
 * @module FavouriteCategoryStars
 */

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { isFavourite, toggleFavourite } from "/scripts/core/utils/FavouriteCategoriesManager.js";

const Settings = new SettingsMgr();

/** @type {string} Mobile category picker root (Amazon Vine sheet) */
export const MOBILE_CATEGORY_SHEET_ID = "categories-sheet-content";

/** @type {string} Desktop and mobile subcategory row selectors */
export const FAVOURITE_CHILD_ROW_SELECTOR = ".child-node, .vvp-mobile-child-node";

/** @type {Set<string>} VineHelper themes that need black PNG icons inverted on-page */
const DARK_THEMES = new Set(["dark", "scifi", "midnight"]);

/**
 * Whether the active VH theme requires inverting black-on-transparent toolbar icons.
 *
 * @returns {boolean}
 *
 * @example
 * if (isFavouriteIconDarkTheme()) {
 *   icon.classList.add("invert");
 * }
 */
export function isFavouriteIconDarkTheme() {
	return DARK_THEMES.has(Settings.get("general.theme"));
}

/**
 * Toggle the shared `.invert` class (see resource/css/icon.css) on a favourite icon.
 *
 * @param {HTMLElement} icon
 *
 * @example
 * applyFavouriteIconTheme(star);
 */
export function applyFavouriteIconTheme(icon) {
	icon.classList.toggle("invert", isFavouriteIconDarkTheme());
}

/**
 * Parse `pn` and `cn` from a Vine browse-node link href.
 *
 * @param {string} href - Relative or absolute Vine items URL.
 * @returns {{pn: string, cn: string}|null}
 *
 * @example
 * parseBrowseNodeParams("/vine/vine-items?queue=encore&pn=6948389011&cn=6654958010");
 * // { pn: "6948389011", cn: "6654958010" }
 */
export function parseBrowseNodeParams(href) {
	try {
		const url = new URL(href, window.location.origin);
		const pn = url.searchParams.get("pn");
		const cn = url.searchParams.get("cn");
		if (!pn || !cn) return null;
		return { pn, cn };
	} catch {
		return null;
	}
}

/**
 * Parent category title from a mobile sheet row (`.vvp-mobile-category-sheet-item`).
 *
 * @param {HTMLElement} childNodeEl
 * @returns {string}
 *
 * @example
 * getParentTitleForMobileChildNode(mobileChildRow); // "Electronics"
 */
export function getParentTitleForMobileChildNode(childNodeEl) {
	const sheetItem = childNodeEl.closest(".vvp-mobile-category-sheet-item");
	if (!sheetItem) return "";
	const parentRow = sheetItem.querySelector(".vvp-mobile-item-text .a-section");
	if (!parentRow) return "";
	let title = "";
	for (const node of parentRow.childNodes) {
		if (node.nodeType === Node.TEXT_NODE) {
			title += node.textContent ?? "";
		}
	}
	return title.trim();
}

/**
 * Find the parent category title for a child browse-node element.
 *
 * @param {HTMLElement} childNodeEl - `.child-node` or `.vvp-mobile-child-node` element.
 * @returns {string}
 *
 * @example
 * getParentTitleForChildNode(childDiv);
 * // "Automotive"
 */
export function getParentTitleForChildNode(childNodeEl) {
	if (childNodeEl.closest(".vvp-mobile-category-sheet-item")) {
		return getParentTitleForMobileChildNode(childNodeEl);
	}

	let prev = childNodeEl.previousElementSibling;
	while (prev) {
		if (prev.classList.contains("parent-node")) {
			const link = prev.querySelector("a");
			return link?.textContent?.trim() ?? "";
		}
		prev = prev.previousElementSibling;
	}
	const parentLink = document.querySelector("#vvp-browse-nodes-container .parent-node a.selectedNode");
	return parentLink?.textContent?.trim() ?? "";
}

/**
 * Create a star icon element for one subcategory row.
 *
 * @param {string} pn
 * @param {string} cn
 * @param {string} parentTitle
 * @param {string} childTitle
 * @returns {HTMLElement}
 *
 * Uses `favourite.png` (outline) when unselected and `favourite_full.png` (filled) when selected.
 * Both icons invert on dark themes via the `.invert` class and theme CSS.
 *
 * @example
 * const star = createStarIcon("6948389011", "6654958010", "Automotive", "Replacement Parts");
 * // starred === true  → vh-icon-favourite      → favourite_full.png
 * // starred === false → vh-icon-unfavourite    → favourite.png
 */
export function createStarIcon(pn, cn, parentTitle, childTitle) {
	const starred = isFavourite(Settings, pn, cn);
	const icon = document.createElement("span");
	icon.className = `vh-toolbar-icon vh-icon-16 vh-fav-category-star ${starred ? "vh-icon-favourite" : "vh-icon-unfavourite"}`;
	icon.setAttribute("role", "button");
	icon.setAttribute("tabindex", "0");
	icon.dataset.pn = pn;
	icon.dataset.cn = cn;
	icon.dataset.parentTitle = parentTitle;
	icon.dataset.childTitle = childTitle;
	const title = starred
		? getMessageOrDefault("favCategoryUnstarTitle", "Remove from favourite categories")
		: getMessageOrDefault("favCategoryStarTitle", "Add to favourite categories");
	icon.setAttribute("title", title);
	icon.setAttribute("aria-label", title);
	applyFavouriteIconTheme(icon);
	return icon;
}

/**
 * Wire click/keyboard handlers on a star icon.
 *
 * @param {HTMLElement} icon
 * @param {() => void} [onChange] - Called after toggle so the UI can refresh.
 *
 * @example
 * bindStarIcon(star, () => renderFavouriteCategoryStars(container));
 */
export function bindStarIcon(icon, onChange) {
	const handleToggle = async (event) => {
		event.preventDefault();
		event.stopPropagation();
		const pn = icon.dataset.pn;
		const cn = icon.dataset.cn;
		const parentTitle = icon.dataset.parentTitle ?? "";
		const childTitle = icon.dataset.childTitle ?? "";
		await toggleFavourite(Settings, pn, cn, parentTitle, childTitle);
		onChange?.();
	};
	icon.addEventListener("click", handleToggle);
	icon.addEventListener("keydown", (event) => {
		if (event.key === "Enter" || event.key === " ") {
			void handleToggle(event);
		}
	});
}

/**
 * @param {HTMLElement} container
 */
function wireFavouriteCategoryContainer(container) {
	if (!container || container._vhFavStarsObserver) return;
	renderFavouriteCategoryStars(container);
	Settings.addSettingsChangeObserver(() => renderFavouriteCategoryStars(container));
	container._vhFavStarsObserver = true;
}

/**
 * Observe the document for the mobile category sheet (loaded when the user opens categories).
 */
function watchMobileCategorySheet() {
	if (document._vhFavMobileSheetWatcher) return;
	document._vhFavMobileSheetWatcher = true;

	let debounceTimer = null;
	const scheduleRender = (root) => {
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => renderFavouriteCategoryStars(root), 50);
	};

	const observer = new MutationObserver(() => {
		const sheet = document.getElementById(MOBILE_CATEGORY_SHEET_ID);
		if (!sheet) return;
		wireFavouriteCategoryContainer(sheet);
		scheduleRender(sheet);
	});

	observer.observe(document.body, { childList: true, subtree: true });
}

/**
 * Render stars beside every subcategory in a browse-nodes or mobile category container.
 *
 * @param {HTMLElement|null} [container] - Desktop `#vvp-browse-nodes-container`, mobile `#categories-sheet-content`, or auto-detect.
 *
 * @example
 * await initFavouriteCategoryStars();
 */
export async function initFavouriteCategoryStars(container = null) {
	await Settings.waitForLoad();

	if (container) {
		wireFavouriteCategoryContainer(container);
	} else {
		const desktop = document.getElementById("vvp-browse-nodes-container");
		if (desktop && desktop.style.display !== "none") {
			wireFavouriteCategoryContainer(desktop);
		}
	}

	const mobileSheet = document.getElementById(MOBILE_CATEGORY_SHEET_ID);
	if (mobileSheet) {
		wireFavouriteCategoryContainer(mobileSheet);
	}

	watchMobileCategorySheet();
}

/**
 * @param {HTMLElement} childNode
 * @param {HTMLElement} container
 */
function decorateChildRow(childNode, container) {
	const link = childNode.querySelector("a.a-link-normal, a.a-color-base");
	if (!link) return;
	const params = parseBrowseNodeParams(link.getAttribute("href") ?? "");
	if (!params) return;

	let star = childNode.querySelector(".vh-fav-category-star");
	const parentTitle = getParentTitleForChildNode(childNode);
	const childTitle = link.textContent?.trim() ?? "";

	if (!star) {
		star = createStarIcon(params.pn, params.cn, parentTitle, childTitle);
		bindStarIcon(star, () => renderFavouriteCategoryStars(container));
		childNode.insertBefore(star, childNode.firstChild);
		return;
	}

	const starred = isFavourite(Settings, params.pn, params.cn);
	star.classList.toggle("vh-icon-favourite", starred);
	star.classList.toggle("vh-icon-unfavourite", !starred);
	star.dataset.parentTitle = parentTitle;
	star.dataset.childTitle = childTitle;
	const title = starred
		? getMessageOrDefault("favCategoryUnstarTitle", "Remove from favourite categories")
		: getMessageOrDefault("favCategoryStarTitle", "Add to favourite categories");
	star.setAttribute("title", title);
	star.setAttribute("aria-label", title);
	applyFavouriteIconTheme(star);
}

/**
 * Inject or refresh star icons for all subcategory rows in a container.
 *
 * @param {HTMLElement} container
 *
 * @example
 * renderFavouriteCategoryStars(document.getElementById("vvp-browse-nodes-container"));
 */
export function renderFavouriteCategoryStars(container) {
	const childNodes = container.querySelectorAll(FAVOURITE_CHILD_ROW_SELECTOR);
	for (const childNode of childNodes) {
		decorateChildRow(childNode, container);
	}
}
