import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { UnixTimeStampToDate } from "/scripts/core/utils/DateHelper.js";

import { Template } from "/scripts/core/utils/Template.js";
var Tpl = new Template();

export class News {
	#localNewsData = [];
	#data = [];
	#newsContainer = null;
	#newsFeed = null;
	#shadowHost = null;
	#shadowRoot = null;
	#onDocumentKeyDown = null;
	#newsStylesText = null;

	constructor(data) {
		if (!Array.isArray(data) || data.length <= 0) {
			return false;
		}

		this.#data = data;

		this.#createInterface();
	}

	async #loadLocalReadNewsData() {
		const localNewsData = await chrome.storage.local.get("readnews");
		this.#localNewsData = localNewsData.readnews || [];
	}

	async #createInterface() {
		await this.#loadLocalReadNewsData();

		if (!this.#isUnreadNews(this.#data) && Settings.get("general.hideNoNews")) {
			return false;
		}

		await this.#createBasicElement();
		await this.#loadNewsFeed();
	}

	#getMessage(key, fallback) {
		if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
			return chrome.i18n.getMessage(key) || fallback;
		}
		return fallback;
	}

	#formatNewsContent(raw) {
		if (raw == null) {
			return "";
		}
		return String(raw)
			.replace(/<br\s*\/?>/gi, "\n")
			.replace(/\r\n/g, "\n")
			.replace(/\r/g, "\n");
	}

	async #loadNewsStyles() {
		if (this.#newsStylesText) {
			return this.#newsStylesText;
		}
		const response = await fetch(chrome.runtime.getURL("resource/css/news.css"));
		if (!response.ok) {
			throw new Error(`Failed to load news styles: ${response.status}`);
		}
		this.#newsStylesText = await response.text();
		return this.#newsStylesText;
	}

	#injectLightDomNewsStyles(css) {
		if (document.getElementById("vh-news-styles")) {
			return;
		}
		const styleEl = document.createElement("style");
		styleEl.id = "vh-news-styles";
		styleEl.textContent = css;
		document.head.appendChild(styleEl);
	}

	#closePanel() {
		this.#newsContainer.hidden = true;
		this.#shadowHost.style.pointerEvents = "none";
	}

	#togglePanel() {
		const willOpen = this.#newsContainer.hidden;
		this.#newsContainer.hidden = !willOpen;
		this.#shadowHost.style.pointerEvents = willOpen ? "auto" : "none";
	}

	#setNewsItemExpanded(newsItem, expanded) {
		const body = newsItem.querySelector(".vh-news-body");
		const toggle = newsItem.querySelector(".vh-news-item-toggle");
		newsItem.classList.toggle("vh-news-item--expanded", expanded);
		body.hidden = !expanded;
		toggle.setAttribute("aria-expanded", expanded ? "true" : "false");

		if (expanded) {
			requestAnimationFrame(() => {
				newsItem.scrollIntoView({ block: "nearest", behavior: "smooth" });
			});
		}
	}

	#bindToggleEvents(toggle, newsItem) {
		const toggleExpanded = () => {
			const expanded = newsItem.classList.contains("vh-news-item--expanded");
			this.#setNewsItemExpanded(newsItem, !expanded);
		};

		toggle.addEventListener("click", toggleExpanded);
		toggle.addEventListener("keydown", (event) => {
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				toggleExpanded();
			}
		});
	}

	async #createBasicElement() {
		const newsStyles = await this.#loadNewsStyles();
		this.#injectLightDomNewsStyles(newsStyles);

		const iconTpl = await Tpl.loadFile("scripts/ui/templates/news.html", true);
		Tpl.setIf("isUnread", this.#isUnreadNews());
		document.body.appendChild(Tpl.render(iconTpl, true));

		this.#shadowHost = document.createElement("div");
		this.#shadowHost.id = "vh-news-shadow-host";
		Object.assign(this.#shadowHost.style, {
			position: "fixed",
			top: "64px",
			right: "12px",
			zIndex: "2147483640",
			pointerEvents: "none",
		});
		document.body.appendChild(this.#shadowHost);

		this.#shadowRoot = this.#shadowHost.attachShadow({ mode: "open" });

		const styleEl = document.createElement("style");
		styleEl.textContent = newsStyles;
		this.#shadowRoot.appendChild(styleEl);

		const panelTpl = await Tpl.loadFile("scripts/ui/templates/news_panel.html", true);
		const panelContent = Tpl.render(panelTpl, true);
		panelContent.hidden = true;
		this.#shadowRoot.appendChild(panelContent);

		this.#newsContainer = panelContent;
		this.#newsFeed = panelContent.querySelector("#vh-news-feed");

		document.querySelector("#vh-news-icon-container").addEventListener("click", () => {
			this.#togglePanel();
		});

		panelContent.querySelector(".vh-news-panel-close").addEventListener("click", (event) => {
			event.preventDefault();
			event.stopPropagation();
			this.#closePanel();
		});

		this.#onDocumentKeyDown = (event) => {
			if (event.key === "Escape" && !this.#newsContainer.hidden) {
				this.#closePanel();
			}
		};
		document.addEventListener("keydown", this.#onDocumentKeyDown);
	}

	async #loadNewsFeed() {
		const markAsReadLabel = this.#getMessage("newsMarkAsRead", "Mark as read");
		const newsTpl = await Tpl.loadFile("scripts/ui/templates/news_container.html", true);

		for (const news of this.#data) {
			const isUnread = !this.#isNewsRead(news.id);
			Tpl.setVar("date", UnixTimeStampToDate(news.date));
			Tpl.setVar("title", news.title);
			Tpl.setVar("markAsReadLabel", markAsReadLabel);
			Tpl.setIf("isUnread", isUnread);

			const newsItem = Tpl.render(newsTpl, true);
			newsItem.querySelector(".vh-news-body-text").textContent = this.#formatNewsContent(news.content);
			this.#newsFeed.appendChild(newsItem);

			this.#bindToggleEvents(newsItem.querySelector(".vh-news-item-toggle"), newsItem);

			const markReadButton = newsItem.querySelector(".vh-news-mark-read");
			if (markReadButton) {
				markReadButton.addEventListener("click", async (event) => {
					event.preventDefault();
					event.stopPropagation();
					await this.#markNewsItemRead(newsItem, news.id);
				});
			}
		}
	}

	async #markNewsItemRead(newsItem, newsId) {
		this.#setNewsItemExpanded(newsItem, false);
		newsItem.classList.remove("vh-news-item--unread");
		newsItem.querySelector(".vh-news-unread-dot")?.remove();
		newsItem.querySelector(".vh-news-body-actions")?.remove();
		await this.#markNewsAsRead(newsId);

		if (!this.#isUnreadNews()) {
			document.querySelector("#vh-news-icon-container .vh-news-icon-new")?.remove();
		}
	}

	#isNewsRead(newsId) {
		return this.#localNewsData.includes(newsId);
	}

	async #markNewsAsRead(newsId) {
		if (!this.#localNewsData.includes(newsId)) {
			this.#localNewsData.push(newsId);
			chrome.runtime.sendMessage({ type: "saveToLocalStorage", key: "readnews", value: this.#localNewsData });
		}
	}

	#isUnreadNews() {
		return this.#data.some((news) => !this.#isNewsRead(news.id));
	}
}
