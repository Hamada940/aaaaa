import { Template } from "/scripts/core/utils/Template.js";
var Tpl = new Template();

class ModalElement {
	constructor(id) {
		this.id = id;
		this.overlay = true;
		this.title = "";
		this.content = "";
		this.style = "";
	}

	async show(template = "/scripts/ui/templates/modal.html") {
		const modal = document.getElementById(`modal-${this.id}`);
		if (modal && modal.style.display !== "none") {
			this.close();
			return;
		}

		await this.getContent(template);

		const modalElement = document.getElementById(`modal-${this.id}`);
		const overlayElement = document.getElementById(`overlay-${this.id}`);
		const hasVisibleModal =
			!!modalElement && modalElement.isConnected && window.getComputedStyle(modalElement).display !== "none";
		if (!hasVisibleModal) {
			// Avoid locking scroll if modal rendering failed or was removed externally.
			if (overlayElement && overlayElement.parentElement) {
				overlayElement.parentElement.removeChild(overlayElement);
			}
			return;
		}

		const modalButtons = document.querySelectorAll(`#modal-${this.id} .modal-ok`);

		for (let i = 0; i < modalButtons.length; i++) {
			modalButtons[i].addEventListener("click", () => {
				const modelMgr = new ModalMgr();
				modelMgr.closeModal(this.id);
			});
		}

		if (overlayElement) {
			overlayElement.addEventListener("click", () => {
				const modalMgr = new ModalMgr();
				modalMgr.closeModal(this.id);
			});
		}

		const modalMgr = new ModalMgr();
		modalMgr.lockBodyScroll();
	}

	async getContent(templatePath) {
		const prom = await Tpl.loadFile(templatePath);
		Tpl.setIf("overlay", this.overlay);
		Tpl.setVar("title", this.title);
		Tpl.setVar("id", this.id);
		Tpl.setVar("content", this.content);
		Tpl.setVar("style", this.style);
		const content = Tpl.render(prom, true);
		document.body.appendChild(content);
	}

	close() {
		const modal = document.getElementById(`modal-${this.id}`);
		const overlay = document.getElementById(`overlay-${this.id}`);

		if (modal && modal.parentElement) {
			modal.parentElement.removeChild(modal);
		}
		if (overlay && overlay.parentElement) {
			overlay.parentElement.removeChild(overlay);
		}

		const modalMgr = new ModalMgr();
		modalMgr.unlockBodyScroll();

		//remove eventlisteners
		this.removeEventListeners();
	}

	removeEventListeners() {
		// Note: removeEventListener needs the exact same function reference that was used in addEventListener
		// Since we're using an arrow function in addEventListener, we can't remove it this way
		// The modal will be removed from DOM anyway, so event listeners will be garbage collected
	}
}

class ModalMgr {
	static #instance = null;

	constructor() {
		if (ModalMgr.#instance) {
			// Return the existing instance if it already exists
			return ModalMgr.#instance;
		}
		// Initialize the instance if it doesn't exist
		ModalMgr.#instance = this;

		this.arrModal = [];
		this.scrollLockCount = 0;
		this.savedBodyOverflow = "";
		this.savedHtmlOverflow = "";

		window.addEventListener("keydown", this.closeOnKey);
	}

	lockBodyScroll() {
		this.scrollLockCount += 1;
		if (this.scrollLockCount > 1) {
			return;
		}

		const body = document.body;
		const html = document.documentElement;
		if (!body || !html) {
			return;
		}

		this.savedBodyOverflow = body.style.overflow;
		this.savedHtmlOverflow = html.style.overflow;

		// Prevent page scrolling while a modal is open.
		html.style.overflow = "hidden";
		body.style.overflow = "hidden";
	}

	unlockBodyScroll() {
		if (this.scrollLockCount <= 0) {
			this.scrollLockCount = 0;
			return;
		}

		this.scrollLockCount -= 1;
		if (this.scrollLockCount > 0) {
			return;
		}

		const body = document.body;
		const html = document.documentElement;
		if (!body || !html) {
			return;
		}

		body.style.overflow = this.savedBodyOverflow;
		html.style.overflow = this.savedHtmlOverflow;
	}

	newModal(id) {
		const m = new ModalElement(id);
		this.arrModal.push(m);
		return m;
	}

	closeModal(id) {
		const m = this.arrModal.find((m) => m.id === id);
		if (m) {
			m.close();
		}

		// Remove the modal from the array
		this.arrModal = this.arrModal.filter((m) => m.id !== id);
	}

	closeOnKey = (event) => {
		if (["Escape", " ", "Enter"].includes(event.key)) {
			// Get the last modal without removing it from array
			const m = this.arrModal[this.arrModal.length - 1];
			if (m) {
				// Use closeModal to properly clean up
				this.closeModal(m.id);
			}
		}
	};
}

export { ModalMgr };
