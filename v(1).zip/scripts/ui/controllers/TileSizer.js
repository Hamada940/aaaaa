import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { Template } from "/scripts/core/utils/Template.js";
var Tpl = new Template();

class TileSizer {
	#settingPrefix = null;
	#documentClickHandler = null;
	constructor(settingPrefix = "general.tileSize") {
		this.#settingPrefix = settingPrefix;
	}

	injectGUI = async function (container) {
		//Insert the template
		const prom = await Tpl.loadFile("scripts/ui/templates/widget_tilesize.html");
		let content = Tpl.render(prom, true);
		container.insertBefore(content, container.firstChild);

		//Bind the actions to the template elements.
		const widgetContainer = container.querySelector("#vh-tile-size-tool-container");
		const sizeSection = container.querySelector("#tileSizeTool");
		const sizeHeader = container.querySelector("#tileSizeTool .vh-tile-size-header");

		// Ensure initial state: collapsed (matching filter behavior)
		if (sizeSection) {
			sizeSection.classList.add("collapsed");
		}

		// Handle header click to toggle collapsed state
		if (sizeHeader && sizeSection) {
			const toggleHandler = (e) => {
				// Don't toggle if clicking on interactive elements (sliders, inputs, etc.)
				const target = e.target;
				const isInteractive =
					target.closest("input, button, select, .vh-button-icon-compact, .vh-icon-only-button") !== null;

				if (!isInteractive) {
					sizeSection.classList.toggle("collapsed");
				}
			};

			sizeHeader.addEventListener("click", toggleHandler);

			// Add click-outside handler to collapse tile size widget when clicking outside
			// Remove existing handler if it exists (from previous injection)
			if (this.#documentClickHandler) {
				document.removeEventListener("click", this.#documentClickHandler);
			}

			this.#documentClickHandler = (e) => {
				// Check all tile size sections on the page (in case there are multiple instances)
				const allTileSizeSections = document.querySelectorAll(".vh-tile-size-section");
				allTileSizeSections.forEach((section) => {
					// Only collapse if the panel is currently expanded
					if (!section.classList.contains("collapsed")) {
						// Check if the click is outside this tile size section (including header and content)
						if (!section.contains(e.target)) {
							section.classList.add("collapsed");
						}
					}
				});
			};

			document.addEventListener("click", this.#documentClickHandler);
		}

		//Bind the action to all the sliders
		if (
			!this.#bindSlider(container, "general.tileSize.width", "width", {
				onChange: () => this.#adjustTileSize(),
				onInput: (v) => this.#adjustTileSize(null, v),
			}) ||
			!this.#bindSlider(container, "general.tileSize.iconSize", "iconSize", {
				onChange: () => this.#adjustIconsSize(),
				onInput: (v) => this.#adjustIconsSize(null, v),
			}) ||
			!this.#bindSlider(container, "general.tileSize.verticalSpacing", "verticalSpacing", {
				onChange: () => {
					this.#adjustVerticalSpacing();
					this.#emitTileHeightSettingChanged("verticalSpacing");
				},
				onInput: (v) => {
					this.#adjustVerticalSpacing(null, v);
					this.#emitTileHeightSettingChanged("verticalSpacing");
				},
			}) ||
			!this.#bindSlider(container, "general.tileSize.rowSpacing", "rowSpacing", {
				defaultValue: 0,
				onChange: () => {
					this.#adjustRowSpacing();
					this.#emitTileHeightSettingChanged("rowSpacing");
				},
				onInput: (v) => this.#adjustRowSpacing(null, v),
			}) ||
			!this.#bindSlider(container, "general.tileSize.titleSpacing", "titleSpacing", {
				onChange: () => {
					this.#adjustTitleSpacing();
					this.#emitTileHeightSettingChanged("titleSpacing");
				},
				onInput: (v) => {
					this.#adjustTitleSpacing(null, v);
					this.#emitTileHeightSettingChanged("titleSpacing");
				},
			}) ||
			!this.#bindSlider(container, "general.tileSize.fontSize", "fontSize", {
				onChange: () => this.#adjustFontSize(),
				onInput: (v) => this.#adjustFontSize(null, v),
			}) ||
			!this.#bindSlider(container, "general.tileSize.toolbarFontSize", "toolbarFontSize", {
				onChange: () => this.#adjustToolbarFontSize(),
				onInput: (v) => this.#adjustToolbarFontSize(null, v),
			})
		) {
			return;
		}
	};

	#bindSlider(container, inputName, settingSuffix, { defaultValue, onChange, onInput }) {
		const slider = container.querySelector(`input[name='${inputName}']`);
		if (!slider) {
			logger.error(`TileSizer: Could not find slider ${inputName}`);
			return false;
		}

		const updateDisplay = () => {
			const valueEl = slider.closest("label")?.querySelector(".vh-tile-size-value");
			if (valueEl) valueEl.textContent = slider.value;
		};

		const stored = Settings.get(`${this.#settingPrefix}.${settingSuffix}`);
		slider.value = stored ?? defaultValue;
		updateDisplay();

		if (onChange) {
			slider.addEventListener("change", async () => {
				const sliderValue = parseInt(slider.value);
				updateDisplay();
				await Settings.set(`${this.#settingPrefix}.${settingSuffix}`, sliderValue);
				onChange(sliderValue);
			});
		}

		if (onInput) {
			slider.addEventListener("input", () => {
				const sliderValue = parseInt(slider.value);
				updateDisplay();
				onInput(sliderValue);
			});
		}

		return true;
	}

	adjustAll = function (DOMElem = null) {
		if (Settings.get("general.tileSize.enabled")) {
			this.#adjustTileSize(DOMElem);
			this.#adjustIconsSize(DOMElem);
			this.#adjustVerticalSpacing(DOMElem);
			this.#adjustRowSpacing(DOMElem);
			this.#adjustTitleSpacing(DOMElem);
			this.#adjustFontSize(DOMElem);
			this.#adjustToolbarFontSize(DOMElem);
		}
	};

	#adjustTileSize = function (DOMElem = null, sliderValue = null) {
		const width = parseInt(sliderValue || Settings.get(`${this.#settingPrefix}.width`));
		if (DOMElem == null) {
			//Adjust all elements on the page
			const grids = document.querySelectorAll("div#vh-tabs .tab-grid");
			grids.forEach((elem) => {
				elem.style.gridTemplateColumns = `repeat(auto-fill,minmax(${width}px,auto))`;
				elem.style.columnGap = `0px`;
				elem.querySelectorAll(".vvp-item-tile .vvp-item-tile-content").forEach((tile) => {
					tile.style.width = parseInt(width) - 4 + "px";
				});
			});
		} else {
			//Target 1 specific element
			DOMElem.querySelector(".vvp-item-tile-content").style.width = parseInt(width) - 4 + "px";
		}
	};

	#adjustIconsSize = function (DOMElem = null, sliderValue = null) {
		const size = parseInt(sliderValue || Settings.get(`${this.#settingPrefix}.iconSize`));
		const selector = ".vh-status-container a>.vh-toolbar-icon";
		const elements = (DOMElem || document).querySelectorAll(
			DOMElem ? selector : `div#vh-tabs .tab-grid ${selector}`
		);
		elements.forEach((elem) => {
			elem.style.width = size + "px";
			elem.style.height = size + "px";
		});

		// Adjust the margin-right of the price element in the toolbar ETV section
		// so it visually aligns with the icon size (iconSize - 5px). List view keeps
		// the price left of the hide icon instead of pulling under it.
		const priceMargin = 0 - size - 5;
		const applyPriceMargin = (elem) => {
			const inListView =
				elem.closest(".vh-listview") != null || document.body.classList.contains("vh-listview-mode");
			elem.style.marginRight = inListView ? "0" : `${priceMargin}px`;
		};
		if (DOMElem) {
			const priceElements = DOMElem.querySelectorAll(".price");
			priceElements.forEach(applyPriceMargin);
		} else {
			const priceElements = document.querySelectorAll("div#vh-tabs .tab-grid:not(#tab-pinned) .price");
			priceElements.forEach(applyPriceMargin);
		}
	};

	#adjustRowSpacing = function (DOMElem = null, sliderValue = null) {
		const size = parseInt(sliderValue ?? Settings.get(`${this.#settingPrefix}.rowSpacing`) ?? 0);
		const gap = Number.isFinite(size) && size >= 0 ? size : 0;
		const applyToGrid = (grid) => {
			if (grid) grid.style.rowGap = `${gap}px`;
		};
		if (DOMElem == null) {
			document.querySelectorAll("div#vh-tabs .tab-grid, #vvp-items-grid.tab-grid").forEach(applyToGrid);
		} else {
			applyToGrid(DOMElem.closest(".tab-grid, #vvp-items-grid"));
		}
	};

	#adjustVerticalSpacing = function (DOMElem = null, sliderValue = null) {
		const size = parseInt(sliderValue || Settings.get(`${this.#settingPrefix}.verticalSpacing`));
		const selectors = [
			".vvp-item-tile-content>.vvp-item-product-title-container",
			".vvp-item-tile-content>.vvp-details-btn, .vvp-item-tile-content>.vh-details-btn",
			".vvp-item-tile-content>.a-button-primary",
			".vvp-item-tile-content>.vh-btn-container",
		];
		for (const selector of selectors) {
			const elements = (DOMElem || document).querySelectorAll(selector);
			elements.forEach((elem) => {
				elem.style.margin = size + "px 0";
			});
		}

		//Adjust the vertical spacing in case of vh-btn-container
		const grandChildren = [".vvp-item-tile-content>.vh-btn-container>.vvp-details-btn"];
		for (const selector of grandChildren) {
			const elements = (DOMElem || document).querySelectorAll(selector);
			elements.forEach((elem) => {
				elem.style.flexGrow = "1";
			});
		}
	};

	#adjustTitleSpacing = function (DOMElem = null, sliderValue = null) {
		const size = parseFloat(sliderValue || Settings.get(`${this.#settingPrefix}.titleSpacing`));
		//Adjust all elements on the page
		const box1 = (DOMElem || document).querySelectorAll(
			".vvp-item-tile-content .vvp-item-product-title-container .a-truncate, .vvp-item-tile-content .vvp-item-product-title-container .a-truncate-cut, .vvp-item-tile-content .vvp-item-product-title-container"
		);
		box1.forEach((elem) => {
			const px = size + "px";
			// Use !important so vine-styling / Amazon defaults cannot pin the container at ~60px on reload.
			elem.style.setProperty("height", px, "important");
			elem.style.setProperty("max-height", px, "important");
		});
	};

	#adjustFontSize = function (DOMElem = null, sliderValue = null) {
		const size = parseInt(sliderValue || Settings.get(`${this.#settingPrefix}.fontSize`));
		const selector = ".vvp-item-tile-content .vvp-item-product-title-container .a-truncate";
		const elements = (DOMElem || document).querySelectorAll(selector);
		elements.forEach((elem) => {
			elem.style.fontSize = size + "px";
		});
	};

	#adjustToolbarFontSize = function (DOMElem = null, sliderValue = null) {
		const size = parseInt(sliderValue || Settings.get(`${this.#settingPrefix}.toolbarFontSize`));
		const selector =
			".vh-toolbar-etv, .vh-toolbar-etv .etv, .vh-toolbar-etv .price, .vh-order-success, .vh-order-failed";
		const elements = (DOMElem || document).querySelectorAll(selector);
		elements.forEach((elem) => {
			elem.style.fontSize = size + "px";
		});
	};

	/** Notify monitor V4 (and other React surfaces) that a tile-height setting changed. */
	#emitTileHeightSettingChanged = function (suffix) {
		if (typeof window === "undefined") return;
		window.dispatchEvent(
			new CustomEvent("vh:settings-changed", {
				detail: { key: `${this.#settingPrefix}.${suffix}` },
			})
		);
	};
}

export { TileSizer };
