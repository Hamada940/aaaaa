const THEME_STYLESHEETS = {
	dark: "resource/theme/dark.css",
	aurora: "resource/theme/aurora.css",
	garish: "resource/theme/garish.css",
	midnight: "resource/theme/midnight.css",
	scifi: "resource/theme/scifi.css",
	win31: "resource/theme/win31.css",
};

/**
 * Injects the user's selected theme stylesheet (forest is the base palette).
 * @param {{ get: (key: string, fallback?: unknown) => unknown }} settings
 */
export function applyUserTheme(settings) {
	const theme = settings.get("general.theme") || "forest";
	if (theme === "forest") {
		return;
	}

	const href = THEME_STYLESHEETS[theme];
	if (!href) {
		return;
	}

	const id = `vh-${theme}-theme-css`;
	if (document.getElementById(id)) {
		return;
	}

	const link = document.createElement("link");
	link.id = id;
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = chrome.runtime.getURL(href);
	document.head.appendChild(link);
}
