//Load the preboot file as a module
(async () => {
	try {
		await import(chrome.runtime.getURL("./scripts/preboot.js"));
	} catch (error) {
		console.error("Error loading module:", error);
		const { reportMobileLoaderFailure } = await import(
			chrome.runtime.getURL("./scripts/core/utils/MobileBootError.js")
		);
		await reportMobileLoaderFailure("preboot.js", error);
	}
})();
