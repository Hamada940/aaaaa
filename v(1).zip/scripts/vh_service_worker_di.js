/*global chrome*/

import { ChromeStorageAdapter } from "/scripts/infrastructure/StorageAdapter.js";
import { Item, WITH_VARIANT } from "/scripts/core/models/Item.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { Websocket } from "/scripts/notifications-monitor/stream/Websocket.js";
import { WebsocketRelaySW } from "/scripts/notifications-monitor/stream/WebsocketRelaySW.js";
import { Internationalization } from "/scripts/core/services/Internationalization.js";
import { isSafari } from "/scripts/core/utils/BrowserDetection.js";
import { initCheckoutMonitoringFallback } from "/scripts/checkoutMonitoringBackground.js";
import { getMinutesUsed, incrementMinutesUsed } from "/scripts/core/utils/MetricStorage.js";
import { handleRollingVineMessage } from "/scripts/rolling-vine/background-sync.js";
import {
	getGroups,
	getGroupById,
	getGroupsByType,
	addKeywordToGroup,
} from "/scripts/core/utils/KeywordGroupsManager.js";
import { submitIfDue, SETTINGS_ANALYTICS_ALARM } from "/scripts/core/services/SettingsAnalytics.js";
var i18n = new Internationalization();

// Initialize services
let storage = new ChromeStorageAdapter("local");
let Settings = null;
let notificationsData = {};
let masterCheckInterval = 0.2; //Firefox shutdown the background script after 30seconds.
let websocket = null;
// BroadcastChannel for communicating with extension pages (MonitorV2)
// Note: Service workers and extension pages share the same origin, so BroadcastChannel works
// Web pages (MonitorV3) are different origin, so they won't receive these messages (no duplicates)
let extensionPageChannel = null;

// Register message handlers IMMEDIATELY to avoid race conditions
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.action === "keywordsUpdated") {
		// Clear keyword cache in settings manager
		if (Settings && Settings.clearKeywordCache) {
			Settings.clearKeywordCache();
			if (Settings && Settings.get("general.debugServiceWorker")) {
				console.log("[ServiceWorker] Keyword cache cleared after update");
			}
		}
		// Update context menu when keywords are updated
		void updateContextMenu();
	}
});

// Initialize services on startup
(async function initializeServiceWorker() {
	try {
		// Initialize settings directly
		Settings = new SettingsMgr();
		await Settings.waitForLoad();
		await submitIfDue(false, { settingsMgr: Settings, i18n });

		let countryCode = Settings.get("general.country");
		while (countryCode === null) {
			await new Promise((r) => setTimeout(r, 500));
			countryCode = Settings.get("general.country");
		}
		i18n.setCountryCode(countryCode);

		// Usage minutes: chrome.storage.local "metric" only (avoids Settings.refresh touching every page each minute)
		await getMinutesUsed(Settings);
		setInterval(() => {
			void incrementMinutesUsed();
		}, 60000);

		//Websocket
		initializeWebsocket();

		// Initialize BroadcastChannel for extension pages (MonitorV2)
		// Service workers and extension pages share the same origin, so BroadcastChannel works
		if (typeof BroadcastChannel !== "undefined") {
			extensionPageChannel = new BroadcastChannel("VHelper-notification-monitor");
		}

		// Update context menu after Settings is initialized
		await updateContextMenu();

		// Firefox: re-inject checkout monitoring when manifest content_scripts miss POST/SPA navigations.
		if (typeof navigator !== "undefined" && /Firefox/i.test(navigator.userAgent)) {
			initCheckoutMonitoringFallback();
		}

		chrome.alarms.create(SETTINGS_ANALYTICS_ALARM, { periodInMinutes: 10080 });
	} catch (error) {
		console.error("[ServiceWorker] Failed to initialize DI services:", error);
		// Service workers cannot recover from this error - DI is required
		throw error;
	}
})();

// NOTE: Keywords in the service worker are NOT mission-critical
// The service worker only uses keywords for:
// 1. Adding new keywords via context menu (right-click)
// 2. Clearing keyword cache when keywords are updated
// All actual keyword matching happens in content scripts and the notification monitor
// If the service worker goes offline, keyword functionality continues to work

//#####################################################
//## CONTEXT MENU
//#####################################################

let selectedWord = "";

// Function to update context menu with current groups
async function updateContextMenu() {
	if (!chrome.contextMenus) {
		console.warn("[ServiceWorker] chrome.contextMenus API not available");
		return;
	}

	try {
		// Clear existing menu items before creating new ones
		chrome.contextMenus.removeAll();

		const patterns = [
			"https://*.amazon.com/vine/*",
			"https://*.amazon.co.uk/vine/*",
			"https://*.amazon.co.jp/vine/*",
			"https://*.amazon.de/vine/*",
			"https://*.amazon.fr/vine/*",
			"https://*.amazon.it/vine/*",
			"https://*.amazon.es/vine/*",
			"https://*.amazon.ca/vine/*",
			"https://*.amazon.com.au/vine/*",
			"https://*.amazon.com.br/vine/*",
			"https://*.amazon.com.mx/vine/*",
			"https://*.amazon.sg/vine/*",
		];

		// Create Copy ASIN menu item
		chrome.contextMenus.create({
			id: "copy-asin",
			title: chrome.i18n.getMessage("contextMenuCopyAsin") || "Copy ASIN",
			contexts: ["all"],
			documentUrlPatterns: patterns,
		});

		// Wait for Settings to be initialized
		if (!Settings) {
			return;
		}

		await Settings.waitForLoad();
		const highlightGroups = await getGroupsByType(Settings, "highlight");
		const hideGroups = await getGroupsByType(Settings, "hide");
		const blurGroups = await getGroupsByType(Settings, "blur");
		const allGroups = [...highlightGroups, ...hideGroups, ...blurGroups];

		// Create menu items directly for each group
		if (allGroups.length > 0) {
			allGroups.forEach((group) => {
				const typeLabel =
					group.type === "highlight"
						? chrome.i18n.getMessage("kwAddGroupTypeHighlight") || "Highlight"
						: group.type === "hide"
							? chrome.i18n.getMessage("kwAddGroupTypeHide") || "Hide"
							: chrome.i18n.getMessage("kwAddGroupTypeBlur") || "Blur";
				chrome.contextMenus.create({
					id: `group-${group.id}`,
					title:
						chrome.i18n.getMessage("contextMenuAddWordToList", [typeLabel, group.name]) ||
						`Add word to ${typeLabel} list: ${group.name}`,
					contexts: ["all"],
					documentUrlPatterns: patterns,
				});
			});
		}
	} catch (error) {
		console.error("[ServiceWorker] Error creating context menus:", error);
	}
}

// Create context menu items on install
chrome.runtime.onInstalled.addListener(async () => {
	await updateContextMenu();
});

// Store the word sent by the content script
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
	let handled = false;

	if (message.action === "getSenderTabUrl") {
		handled = true;
		try {
			const tabUrl = sender?.tab?.url;
			const senderUrl = sender?.url;
			sendResponse({ success: true, url: tabUrl || senderUrl || null });
		} catch (error) {
			sendResponse({ success: false, url: null, error: error?.message || String(error) });
		}
		return true;
	}

	if (message.action === "getExtensionVersion") {
		handled = true;
		try {
			const version = chrome.runtime.getManifest().version;
			sendResponse({ success: true, version });
		} catch (error) {
			sendResponse({ success: false, error: error?.message || String(error) });
		}
		return true;
	}

	if (message.action === "setWord" && message.word) {
		selectedWord = message.word; // Update the selected word
		// No response needed for setWord
		return false; // Don't keep channel open
	}

	if (message.action === "addWord" && message.word) {
		handled = true;
		const confirmedWord = message.word;

		const newKeyword = {
			contains: confirmedWord,
			without: "",
			etv_min: "",
			etv_max: "",
		};

		// Keyword groups only; legacy lists are not used for add-word (migration only).
		if (message.groupId) {
			try {
				await addKeywordToGroup(Settings, message.groupId, newKeyword);
				// Notify that keywords were updated
				chrome.runtime.sendMessage({ action: "keywordsUpdated" });
				sendResponse({ success: true });
				return true; // Keep channel open for async response
			} catch (error) {
				console.error("[ServiceWorker] Error adding keyword to group:", error);
				sendResponse({ success: false, error: error.message });
				return true; // Keep channel open for async response
			}
		}

		sendResponse({ success: false, error: "groupId required" });
		return true; // Keep channel open for async response
	}

	// Don't send response if we didn't handle the message
	return false;
});

// Handle context menu clicks and save the word
if (chrome.contextMenus && chrome.contextMenus.onClicked) {
	chrome.contextMenus.onClicked.addListener(async (info, tab) => {
		if (info.menuItemId === "copy-asin") {
			sendMessageToTabSafely(tab?.id, { action: "copyASIN" });
			return;
		}

		if (!selectedWord) {
			console.error("No word selected!");
			return;
		}

		// Check if this is a group menu item (starts with "group-")
		if (info.menuItemId.startsWith("group-")) {
			const groupId = info.menuItemId.replace("group-", "");
			// Get group name for display
			const group = await getGroupById(Settings, groupId);
			const groupName = group ? group.name : "selected group";
			const groupType = group ? group.type : "";

			sendMessageToTabSafely(tab?.id, {
				action: "showPrompt",
				word: selectedWord,
				groupId: groupId,
				groupName: groupName,
				groupType: groupType,
			});
			return;
		}

		// Fallback to legacy system
		const list = info.menuItemId === "add-to-hideKeywords" ? "Hide" : "Highlight";
		sendMessageToTabSafely(tab?.id, { action: "showPrompt", word: selectedWord, list: list });
	});
} else {
	console.warn("[ServiceWorker] chrome.contextMenus API not available");
}

//#####################################################
//## BROADCAST MESSAGE PROCESSING
//#####################################################

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	// Handle broadcast messages (including pushNotification)
	if (message.type !== undefined) {
		processBroadcastMessage(message, sender, sendResponse);
		return true; // Indicate that sendResponse will be called asynchronously
	}
});

function processBroadcastMessage(data, sender, sendResponse) {
	// Rolling Vine sync
	if (data.type === "rollingVine.startSync") {
		handleRollingVineMessage(data, sender, sendResponse);
		return true;
	}

	if (data.type == "openUrlInNewTab" && data.url) {
		try {
			chrome.tabs.create({ url: String(data.url) });
			sendResponse?.({ success: true });
		} catch (error) {
			sendResponse?.({ success: false, error: error?.message || String(error) });
		}
		return true;
	}

	if (data.type == "saveToLocalStorage") {
		storage
			.set(data.key, data.value)
			.then(() => {
				sendResponse({ success: true });
			})
			.catch((error) => {
				console.log("Service worker caught error:", error);
				console.log("Error message:", error.message);
				console.log("Error name:", error.name);
				sendResponse({ success: false, error: error.message });
			});
		return true; // Indicate that sendResponse will be called asynchronously
	}
	if (data.type == "clearLocalStorage") {
		storage
			.clear()
			.then(() => {
				sendResponse({ success: true });
			})
			.catch((error) => {
				sendResponse({ success: false, error: error.message });
			});
		return true; // Indicate that sendResponse will be called asynchronously
	}

	if (data.type == "pushNotification") {
		try {
			// ServerCom sends { type: "pushNotification", item: {...}, title: ... }
			// where item contains all the item data from item.getAllInfo()
			if (!data.item) {
				throw new Error("pushNotification message missing item data");
			}

			const item = new Item({
				asin: data.item.asin,
				queue: data.item.queue,
				is_parent_asin: data.item.is_parent_asin,
				is_pre_release: data.item.is_pre_release,
				enrollment_guid: data.item.enrollment_guid,
			});
			item.setTitle(data.item.title);
			item.setImgUrl(data.item.img_url);
			item.setSearch(data.item.search);
			pushNotification(data.title, item);
		} catch (error) {
			console.error("[ServiceWorker] Cannot create item for push notification -", error.message, {
				data: data,
				source: "pushNotification message",
			});
		}
		return true;
	}

	// Monitor lite (extension page) asks SW to relay to Vine tabs only; only the SW can reliably use chrome.tabs.sendMessage to content scripts
	if (data.type == "relayToVineTabs" && data.payload) {
		sendToVineTabsOnly(data.payload);
		return true;
	}

	// Content scripts can ask SW to relay monitor payloads to extension pages (Monitor V3 Lite).
	if (data.type == "relayToExtensionPages" && data.payload && extensionPageChannel) {
		extensionPageChannel.postMessage(data.payload);
		return true;
	}

	// Handle getConnectionDetails request
	if (data.type == "getConnectionDetails") {
		const connectionDetails =
			websocket && typeof websocket.getConnectionDetails === "function" ? websocket.getConnectionDetails() : {};
		if (extensionPageChannel) {
			extensionPageChannel.postMessage({ type: "getConnectionDetailsResponse", connectionDetails });
		}
		return true;
	}

	//Websocket messages
	if (websocket) {
		websocketMessageRelay(data);
		return true;
	}
}

//#####################################################
//## WEBSOCKET (For non-Safari browsers)
//#####################################################

function initializeWebsocket() {
	if (!isSafari() && Settings && Settings.get("notification.connectionMode") == "1") {
		if (!websocket || !websocket.isConnected()) {
			console.log("initialize websocket in SW");
			const messageRelayer = new WebsocketRelaySW(sendMessageToAllTabs);
			websocket = new Websocket(messageRelayer);
		}
	} else {
		// Terminate the websocket connection and destroy instance (clears reconnect timer, listeners)
		if (websocket) {
			websocket.destroyInstance();
			websocket = null;
		}
	}
}

const processedMessages = new Set();
function websocketMessageRelay(message) {
	//Prevent duplicate messages from being processed (theorical fix for multiple identical messages being sent)
	// Create unique message ID
	const messageId = `${message.type}_${Date.now()}_${JSON.stringify(message)}`;

	if (processedMessages.has(messageId)) {
		console.log(`[Service Worker] Duplicate message ignored: ${message.type}`);
		return;
	}

	processedMessages.add(messageId);

	// Clean up old message IDs (keep only last 100)
	if (processedMessages.size > 100) {
		const toDelete = Array.from(processedMessages).slice(0, processedMessages.size - 100);
		toDelete.forEach((id) => processedMessages.delete(id));
	}

	if (
		message.type === "fetchLatestItems" ||
		message.type === "wsStatus" ||
		message.type === "reloadRequest" ||
		message.type === "wsConnect" ||
		message.type === "disconnectRequest"
	) {
		if (Settings && Settings.get("general.debugServiceWorker")) {
			console.log("Relaying message to websocket", message);
		}
		websocket.processMessage(message);
		return;
	}
}

//#####################################################
//## BUSINESS LOGIC
//#####################################################

// Alarm for master check, keeps the service worker alive
chrome.alarms.create("masterCheck", { periodInMinutes: masterCheckInterval });
chrome.alarms.onAlarm.addListener((alarm) => {
	if (alarm.name === "masterCheck") {
		// Only send messages if Settings is initialized
		if (Settings) {
			initializeWebsocket();
		}
	}
	if (alarm.name === SETTINGS_ANALYTICS_ALARM && Settings) {
		void submitIfDue(false, { settingsMgr: Settings, i18n });
	}
});

async function sendMessageToAllTabs(data) {
	if (Settings && Settings.get("general.debugServiceWorker")) {
		console.log("Sending message to all tabs", data);
	}
	try {
		const tabs = await chrome.tabs.query({});
		const regex = /^.+?amazon\.([a-z.]+).*\/vine\/.*$/;
		tabs.forEach((tab) => {
			if (tab) {
				//Check to make sure this is a VHelper tab:
				const match = regex.exec(tab.url);
				//Edge Canari Mobile does not support tab.url
				if (tab.url == undefined || match) {
					if (Settings && Settings.get("general.debugServiceWorker")) {
						console.log("Sending to tab id " + tab.id, data);
					}
					sendMessageToTab(tab.id, data);
				}
			}
		});
	} catch (error) {
		console.error("Error querying tabs:", error);
	}

	// Send to extension pages (MonitorV2) via BroadcastChannel
	// Service workers and extension pages share the same origin, so BroadcastChannel works
	if (extensionPageChannel) {
		extensionPageChannel.postMessage(data);
	}
}

/**
 * Send payload only to Vine tabs (content scripts). Used when monitor lite (extension page) relays
 * newItem/fetch100 so bootloader can show on-screen notifications; only the SW is guaranteed to
 * be able to use chrome.tabs.sendMessage to content scripts.
 * @param {Object} payload - Plain message object (e.g. { type: "newItem", item: { data: ... }, index, ... } or { type: "fetch100", data: ... })
 */
function sendToVineTabsOnly(payload) {
	const tld = i18n && typeof i18n.getDomainTLD === "function" ? i18n.getDomainTLD() : "com";
	const pattern = `*://*.amazon.${tld}/vine/*`;
	chrome.tabs.query({ url: pattern }, (tabs) => {
		if (chrome.runtime.lastError) return;
		(tabs || []).forEach((tab) => {
			if (tab && tab.id) sendMessageToTab(tab.id, payload);
		});
	});
}

function sendMessageToTab(tabId, data) {
	//Check if the scripting permission is enabled
	chrome.permissions.contains({ permissions: ["scripting"] }, (result) => {
		if (result) {
			//Try sending message via scripting (new method, as Safari does not support tab messaging)
			try {
				chrome.scripting.executeScript({
					target: { tabId: tabId },
					func: (data) => {
						window.postMessage(data, "*");
					},
					args: [data],
				});
			} catch (e) {
				console.error("Error sending message to tab via scripting:", e);
			}
		} else {
			//Try sending a message via tab (classic method)
			try {
				chrome.tabs.sendMessage(tabId, data, (response) => {
					if (chrome.runtime.lastError) {
						console.error("Error sending message to tab:", chrome.runtime.lastError.message);
					}
				});
			} catch (e) {
				console.error("Error sending message to tab:", e);
			}
		}
	});
}

function sendMessageToTabSafely(tabId, data) {
	if (!tabId) {
		return;
	}

	try {
		chrome.tabs.sendMessage(tabId, data, () => {
			// Ignore missing receiver errors - this can happen when the content script is not injected yet.
			if (
				chrome.runtime.lastError &&
				!chrome.runtime.lastError.message?.includes("Receiving end does not exist")
			) {
				console.error("Error sending message to tab:", chrome.runtime.lastError.message);
			}
		});
	} catch (e) {
		console.error("Error sending message to tab:", e);
	}
}

//#####################################################
//## PUSH NOTIFICATIONS
//#####################################################

try {
	if (!isSafari()) {
		chrome.permissions.contains({ permissions: ["notifications"] }, (result) => {
			chrome.notifications.onClicked.addListener((notificationId) => {
				if (Settings && Settings.get("general.debugServiceWorker")) {
					console.log("[ServiceWorker] Notification clicked", {
						notificationId,
						data: notificationsData[notificationId],
					});
				}

				const { asin, queue, is_parent_asin, enrollment_guid, search, is_pre_release } =
					notificationsData[notificationId] || {};

				let url;
				const tld = i18n.getDomainTLD() || "com";

				// Check if we should open modal (requires all necessary data)
				if (
					Settings &&
					Settings.get("general.searchOpenModal") &&
					is_parent_asin != null &&
					enrollment_guid != null
				) {
					try {
						// Create the openModal URL like the old code did
						const item = new Item({
							asin: asin,
							queue: queue,
							is_parent_asin: is_parent_asin,
							is_pre_release: is_pre_release,
							enrollment_guid: enrollment_guid,
						});
						url = item.getVHOpenModalURL(WITH_VARIANT);
						if (Settings && Settings.get("general.debugServiceWorker")) {
							console.log("[ServiceWorker] Opening modal URL:", url);
						}
					} catch (error) {
						console.error("[ServiceWorker] Cannot create modal URL, falling back to search", error);
						// Fall back to search URL
						if (search) {
							url = `https://www.amazon.${tld}/vine/vine-items?search=${encodeURIComponent(search)}`;
						}
					}
				} else if (search) {
					// Use search string (item title) not ASIN
					url = `https://www.amazon.${tld}/vine/vine-items?search=${encodeURIComponent(search)}`;
				} else {
					// Last resort: just open vine items page
					url = `https://www.amazon.${tld}/vine/vine-items`;
					console.warn("[ServiceWorker] No search string available for notification", {
						notificationData: notificationsData[notificationId],
					});
				}

				if (Settings && Settings.get("general.debugServiceWorker")) {
					console.log("[ServiceWorker] Opening URL from notification click:", url);
				}
				chrome.tabs.create({ url: url });
				chrome.notifications.clear(notificationId);
				delete notificationsData[notificationId];
			});
		});
	}
} catch (err) {
	//Not supported, probably safari.
}

async function pushNotification(title, item) {
	if (isSafari()) {
		return false;
	}

	// Handle both object with methods and plain object formats
	// If item is an Item instance, get the data from getAllInfo()
	const itemData = item.getAllInfo ? item.getAllInfo() : item;

	// Use ASIN-based notification ID to prevent duplicates
	const notificationId = `notification_${itemData.asin}`;
	const iconUrl = chrome.runtime.getURL("resource/image/icon-128.png");

	// Store notification data
	notificationsData[notificationId] = {
		asin: itemData.asin,
		queue: itemData.queue,
		is_parent_asin: itemData.is_parent_asin,
		enrollment_guid: itemData.enrollment_guid,
		search: itemData.search,
		is_pre_release: itemData.is_pre_release,
	};

	// Get the product image URL if available
	const imageUrl = itemData.img_url;

	// Debug logging for notification images
	if (Settings && Settings.get("general.debugServiceWorker")) {
		console.log("[ServiceWorker] Notification image data", {
			asin: itemData.asin,
			title: itemData.title,
			imageUrl: imageUrl,
			hasImgUrl: !!itemData.img_url,
			itemDataKeys: Object.keys(itemData),
			fullItemData: itemData,
		});

		if (!imageUrl) {
			console.warn("[ServiceWorker] No image URL for notification");
		}
	}

	const notificationOptions = {
		type: "basic",
		iconUrl: imageUrl || iconUrl, // Use product image as icon if available, fallback to extension icon
		title: title,
		message: itemData.title || "",
		priority: 2,
		silent: false,
	};

	if (Settings && Settings.get("general.debugServiceWorker")) {
		console.log("[ServiceWorker] Creating notification", {
			asin: itemData.asin,
			type: notificationOptions.type,
			iconUrl: notificationOptions.iconUrl,
			hasProductImage: !!imageUrl,
		});
	}

	chrome.notifications.create(notificationId, notificationOptions);
}
