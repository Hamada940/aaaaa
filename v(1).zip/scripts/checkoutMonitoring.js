/**
 * Todo:
 * - Find a way to associate the ASIN with the p-number, and store that temporarily in memory as an ongoing checkout.
 * - When we getto be able to confirm when it has been ordered.
 * - Update VH server when a product is ordered successfully or get a failure error.
 */
console.log("Checkout monitoring loaded.");
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
var Settings = new SettingsMgr();

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
var cryptoKeys = new CryptoKeys();

import { Environment } from "/scripts/core/services/Environment.js";
var env = new Environment();

import {
	initLocaleOverride,
	getMessageOrDefault,
	getMessageForTemplate,
} from "/scripts/core/services/Internationalization.js";
import { AMAZON_CHECKOUT } from "/scripts/core/amazon/selectors.js";

//###########################
//If the productId was not registered: Register the current checkout and link it to an ASIN.
//If the productId was registered, the ASIN will be available for the process.

async function init() {
	await Settings.waitForLoad();
	await initLocaleOverride(Settings.get("i18n.localeOverride"));

	const { initVersionDebugLabel } = await import("/scripts/ui/components/VersionDebugLabel.js");
	initVersionDebugLabel(Settings);

	// URL guard: ensure we are on a checkout or thank-you page with a valid productId
	const url = new URL(window.location.href);
	const path = url.pathname;
	const hasPNumber = path.includes(AMAZON_CHECKOUT.CHECKOUT_PATH_P) || path.includes(AMAZON_CHECKOUT.THANKYOU_PATH);
	const isCheckoutPage = path.includes(AMAZON_CHECKOUT.CHECKOUT_PATH_P);
	if (!hasPNumber) {
		console.log("Non-Vine checkout page detected, aborting monitoring");
		return;
	}
	window.__VH_GET_MESSAGE__ = getMessageForTemplate;

	//Auto decline prime membership is prompted.
	if (Settings.isPremiumUser(2) && Settings.get("general.skipPrimeAd")) {
		const skipPrimeLink = document.querySelector(AMAZON_CHECKOUT.PRIME_DECLINE);
		if (skipPrimeLink) {
			skipPrimeLink.click();
			return;
		}
	}

	let currentASIN = await Settings.get("checkout.currentASIN", false);
	let currentParentASIN = await Settings.get("checkout.currentParentASIN", false);
	let arrCurrentCheckouts = (await Settings.get("checkout.arrCurrentCheckouts", false)) || [];
	const isLikelyVineCheckout = isCheckoutPage ? isLikelyVineCheckoutEntry() : true;

	if (currentASIN && !isLikelyVineCheckout) {
		console.log("Checkout does not look Vine-originated, clearing checkout marker and aborting monitoring", {
			currentASIN,
			referrer: document.referrer,
			path,
		});
		await Settings.set("checkout.currentASIN", null);
		await Settings.set("checkout.currentParentASIN", null);
		await Settings.set("checkout.currentBuyNowASIN", null);
		return;
	}

	if (currentASIN) {
		//If the current checkout does not exist, create it.
		if (!(await getCurrentCheckout(currentASIN))) {
			//Add the current checkout to the array
			arrCurrentCheckouts.push({
				asin: currentASIN,
				parent_asin: currentParentASIN,
				productId: getProductId(),
				isVine: true,
				expires: Date.now() + 1000 * 60 * 60 * 1, // 1 hour
			});
			await Settings.set("checkout.arrCurrentCheckouts", arrCurrentCheckouts);
		} else {
			//The current ASIN is already exists as a checkout, but we have a new checkout session for it, update it.
			const currentCheckout = await getCurrentCheckout(currentASIN);
			if (currentCheckout) {
				currentCheckout.productId = getProductId();
				currentCheckout.expires = Date.now() + 1000 * 60 * 60 * 1; // 1 hour
				//Replace the productId and Expire data in arrCurrentCheckouts
				arrCurrentCheckouts = arrCurrentCheckouts.map((checkout) =>
					checkout.asin === currentASIN ? currentCheckout : checkout
				);
				await Settings.set("checkout.arrCurrentCheckouts", arrCurrentCheckouts);
			}
		}
		await Settings.set("checkout.currentASIN", null);
		await Settings.set("checkout.currentParentASIN", null);
	}

	//Garbage collect expired checkouts
	arrCurrentCheckouts = arrCurrentCheckouts.filter((checkout) => checkout.expires > Date.now());
	await Settings.set("checkout.arrCurrentCheckouts", arrCurrentCheckouts);

	const currentInfo = await getCurrentInfo();
	if (!currentInfo) {
		console.log("No current info found");
		//This is not a vine checkout, don't do anything.
		return;
	}

	// Additional validation: Ensure we have a valid productId from the URL
	// This prevents false positives if getProductId() returns null
	// (getCurrentInfo() already verified the productId matches, but this is an explicit safety check)
	const productId = getProductId();
	if (!productId) {
		// No product ID found in URL - this is not a valid checkout page
		console.log("No product ID found in URL - this is not a valid checkout page");
		return;
	}

	//###########################
	//Order confirmation page
	checkForError();

	//###########################
	//Thank you page
	checkForSuccess();

	if (isPageThankYou() || checkForVineOrderCannotBeProcessedError() || checkForOutOfStockError()) {
		Settings.set("checkout.currentBuyNowASIN", null);
		return; //Do not try to process the checkout if we are on the thank you page or if we have an error, or if we are not in a vine checkout.
	}

	const orderNow =
		Settings.isPremiumUser(3) &&
		Settings.get("general.orderNow.skipConfirmOrder") &&
		currentASIN &&
		Settings.get("checkout.currentBuyNowASIN") == currentASIN;

	if (Settings.get("general.debugCheckout")) {
		console.log("VH Debug [Checkout]: Order Now check -", {
			isPremiumTier3: Settings.isPremiumUser(3),
			skipConfirmOrder: Settings.get("general.orderNow.skipConfirmOrder"),
			hasCurrentASIN: !!currentASIN,
			buyNowASINMatches: Settings.get("checkout.currentBuyNowASIN") == currentASIN,
			orderNowEnabled: orderNow,
		});
	}

	// Helper to click place order once it becomes available and loading spinner hides
	const attemptPlaceOrder = () => {
		console.log("Will attempt to place order...");
		let waitTries = 0;
		const waitInterval = setInterval(() => {
			waitTries++;
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout] Looking for place order button, attempt: ", waitTries);
			}
			if (waitTries > 100) {
				// 10s max
				clearInterval(waitInterval);
				if (Settings.get("general.debugCheckout")) {
					console.warn(
						"VH Debug [Checkout] Buy now checkout detected, but the place order button was not found or remained disabled, all attempts failed."
					);
				}
				return;
			}
			// Check if there is an active loading spinner blocking the UI
			const spinner = document.querySelector("#a-popover-luna-background");
			if (spinner && window.getComputedStyle(spinner).display !== "none") {
				if (Settings.get("general.debugCheckout")) {
					console.log("VH Debug [Checkout] Loading spinner is active, aborting this attempt");
				}
				return; // Still loading
			}

			const placeOrderButton =
				document.querySelector("#placeOrder") ||
				document.querySelector('input[name="placeYourOrder1"]') ||
				document.querySelector('input[data-testid="SPC_selectPlaceOrder"]') ||
				document.querySelector('input[data-csa-c-slot-id="checkout-place-your-order-button"]') ||
				document.querySelector(".place-your-order-button");

			if (!placeOrderButton) {
				if (Settings.get("general.debugCheckout")) {
					console.log("VH Debug [Checkout] Place order button not found, aborting this attempt");
				}
				return;
			}

			const isDisabled = placeOrderButton.disabled || placeOrderButton.classList.contains("a-button-disabled");
			if (isDisabled) {
				if (Settings.get("general.debugCheckout")) {
					console.log("VH Debug [Checkout] Place order button is disabled, aborting this attempt");
				}
				return;
			}

			clearInterval(waitInterval);
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Order placement attempt - clicking place order button");
			}
			Settings.set("checkout.currentBuyNowASIN", null);
			// Attempt a "real" click sequence in case the page is listening for mousedown/mouseup events
			try {
				placeOrderButton.scrollIntoView({ block: "center", inline: "center" });
				placeOrderButton.focus();
				const clickTargets = [placeOrderButton, placeOrderButton.closest("button, span, div")].filter(Boolean);
				const mouseEventOptions = { bubbles: true, cancelable: true, view: window };
				clickTargets.forEach((target) => {
					["mouseover", "mousemove", "mousedown", "mouseup", "click"].forEach((type) =>
						target.dispatchEvent(new MouseEvent(type, mouseEventOptions))
					);
				});
			} catch (e) {
				// ignore click dispatch failure (best-effort behavior)
			}
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Place order button clicked");
			}

			placeOrderButton.click();
			const form = placeOrderButton.closest("form");
			if (form) {
				form.submit();
			}
		}, 100);
	};

	// Wrapper that checks for non-zero price before attempting to place order
	const attemptPlaceOrderWithPriceCheck = () => {
		const price = getTotal();
		if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: attemptPlaceOrderWithPriceCheck - price:", price);
		}
		if (price !== false && parseFloat(price) !== 0) {
			const message = getMessageOrDefault("alertCheckoutPriceNotZero", "VHelper warning: Price is not zero.");
			alert(message);
			return;
		}
		attemptPlaceOrder();
	};

	//###########################
	// Auto-select preferred address for Order Now checkouts
	const isBuyNow = currentASIN && Settings.get("checkout.currentBuyNowASIN") == currentASIN;
	const preferredAddressId = Settings.get("general.orderNow.preferredAddressId");

	// If "Amazon Default" is selected, skip all address change logic
	if (preferredAddressId === "default" || preferredAddressId === "Amazon Default") {
		// Just proceed to place order if enabled, no address validation needed
		if (orderNow) attemptPlaceOrderWithPriceCheck();
		return;
	}

	if (Settings.get("general.debugCheckout")) {
		console.log("VH Debug [Checkout]: isBuyNow:", isBuyNow, "preferredAddressId:", preferredAddressId);
	}

	if (isBuyNow && preferredAddressId && !sessionStorage.getItem("vh_address_changed")) {
		// Only attempt once per session to avoid loops
		sessionStorage.setItem("vh_address_changed", "1");

		// Pre-check to see if the preferred address is ALREADY the selected default address
		let isAlreadySelected = false;

		const checkedRadio = document.querySelector(`input[type="radio"][value*="${preferredAddressId}"]:checked`);
		if (checkedRadio) {
			isAlreadySelected = true;
		} else {
			// Scan the raw HTML for exact JSON mapping patterns used by Amazon for the ACTIVE address
			const rawHtml = document.documentElement.innerHTML;
			if (
				rawHtml.includes(`"addressId":"${preferredAddressId}"`) ||
				rawHtml.includes(`"addressID":"${preferredAddressId}"`) ||
				rawHtml.includes(`"shippingAddressId":"${preferredAddressId}"`) ||
				rawHtml.includes(`"isDefault":true,"addressId":"${preferredAddressId}"`) ||
				rawHtml.includes(`name="purchase-pref-address-id" value="${preferredAddressId}"`) ||
				rawHtml.includes(`name="addressID" value="${preferredAddressId}"`) ||
				rawHtml.includes(`"address-ui-widgets-AddressId_${preferredAddressId}"`)
			) {
				isAlreadySelected = true;
			} else {
				// Check the inputs in the active delivery panel
				const panel = document.querySelector("#checkout-deliveryAddressPanel");
				if (panel) {
					// Highly aggressive: if the active delivery panel's HTML contains the ID literally anywhere
					// (in data attributes, hidden fields, links, etc). The ID is a long hash, so this is safe.
					if (panel.innerHTML.includes(preferredAddressId)) {
						isAlreadySelected = true;
					}

					const hiddenInputs = panel.querySelectorAll('input[type="hidden"]');
					for (const input of hiddenInputs) {
						if (input.value.includes(preferredAddressId)) {
							isAlreadySelected = true;
							break;
						}
					}
				}

				// Check main form hidden inputs Amazon uses (cast a broader net for safety)
				const allFormsHiddenInputs = document.querySelectorAll('input[type="hidden"]');
				for (const input of allFormsHiddenInputs) {
					const name = (input.name || "").toLowerCase();
					const id = (input.id || "").toLowerCase();
					// If the input name/id hints at 'address' and contains our ID
					if (
						(name.includes("address") ||
							id.includes("address") ||
							name.includes("location") ||
							name.includes("dest")) &&
						input.value.includes(preferredAddressId)
					) {
						isAlreadySelected = true;
						console.log("isAlreadySelected4", isAlreadySelected);
						break;
					}
				}
			}
		}

		// Also check if we already opened the panel and the radio is checked
		if (isAlreadySelected) {
			// If it's already the default address, do not open the panel, just proceed instantly
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Address already selected, skipping switch");
			}
			if (orderNow) attemptPlaceOrderWithPriceCheck();
			return;
		}

		if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: Address mismatch, initiating address switch");
		}

		console.log("Changing address...");
		const changeBtn = document.querySelector(
			"#checkout-deliveryAddressPanel > div > div.a-column.a-span4.a-text-right.a-spacing-base.a-span-last > span > a"
		);

		if (changeBtn && changeBtn.offsetParent !== null) {
			// Ensure it's not already open and is visible
			changeBtn.click();
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Change address button clicked");
			}

			// Wait for the address radio buttons to appear
			let tries = 0;
			const addressInterval = setInterval(() => {
				tries++;
				if (tries > 50) {
					// 5 seconds max
					clearInterval(addressInterval);
					if (orderNow) attemptPlaceOrderWithPriceCheck();
					return;
				}

				const rd = document.querySelector(`input[type="radio"][value*="${preferredAddressId}"]`);
				if (rd) {
					clearInterval(addressInterval);

					// Is it already checked?
					if (!rd.checked) {
						rd.click();

						// Now we need to click the "Deliver to this address" submit button
						setTimeout(() => {
							const deliverBtn =
								document.querySelector("#checkout-secondary-continue-button-id input") ||
								document.querySelector('input[data-testid="secondary-continue-button"]') ||
								document.querySelector("#checkout-primary-continue-button-id input") ||
								document.querySelector('input[data-testid="bottom-continue-button"]') ||
								rd
									.closest(".a-row")
									?.querySelector('[data-action="select-destination-on-sasp-desktop-panel"] input') ||
								rd.closest("form")?.querySelector('input[type="submit"]') ||
								document.querySelector(
									'[data-action="select-destination-on-sasp-desktop-panel"] input'
								) ||
								document.querySelector('.sasp-desktop-submit-button-container input[type="submit"]') ||
								document.querySelector('#checkout-deliveryAddressPanel input[type="submit"]');

							if (deliverBtn) {
								deliverBtn.click();
								if (orderNow) {
									setTimeout(attemptPlaceOrderWithPriceCheck, 1500); // Wait for Chewbacca to initiate the save request
								}
							} else if (orderNow) {
								attemptPlaceOrderWithPriceCheck();
							}
						}, 300);
					} else {
						// Already checked, we can just submit or collapse
						const deliverBtn =
							document.querySelector("#checkout-secondary-continue-button-id input") ||
							document.querySelector('input[data-testid="secondary-continue-button"]') ||
							document.querySelector("#checkout-primary-continue-button-id input") ||
							document.querySelector('input[data-testid="bottom-continue-button"]') ||
							document.querySelector('[data-action="select-destination-on-sasp-desktop-panel"] input');
						if (deliverBtn) deliverBtn.click();
						if (orderNow) attemptPlaceOrderWithPriceCheck();
					}
				}
			}, 100);

			// Return here so we don't immediately auto-confirm the order while we are changing the address.
			// The interval above handles continuing the flow.
			return;
		}
	}

	// After address handling (or if there was nothing to handle),
	// check for a delivery option error (Amazon uses data-messageid, not an element id)
	// and auto-select the first option if needed.
	const deliveryError = document.querySelector('div[data-messageid="selectDeliveryOptionMessage"]');
	if (isBuyNow && deliveryError) {
		if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: Delivery option error detected on page");
		}
		const firstDeliveryRadio = document.querySelector('#col-delivery-group input[type="radio"]');
		if (firstDeliveryRadio && !firstDeliveryRadio.disabled && !firstDeliveryRadio.checked) {
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Auto-selecting first delivery option radio");
			}
			firstDeliveryRadio.click();
		} else if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: First delivery radio not found or already checked");
		}
	}

	// Auto-select shipping priority for Buy Now checkouts
	const shippingPriority = Settings.get("general.orderNow.shippingPriority");
	if (isBuyNow && shippingPriority && shippingPriority !== "") {
		if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: Attempting to auto-select shipping option:", shippingPriority);
		}

		const normalize = (s) =>
			(s || "")
				.toLowerCase()
				.replace(/\u00A0/g, " ")
				.replace(/[^\w\s-]/g, " ")
				.replace(/\s+/g, " ")
				.trim();

		const tokenMap = {
			"Amazon Day": [
				normalize(getMessageOrDefault("pageSettingsCheckoutShippingAmazonDay", "Amazon Day")),
				"amazon day",
				"amazon-day",
				"amazon",
			],
			"No-Rush": [
				normalize(getMessageOrDefault("pageSettingsCheckoutShippingNoRush", "No-Rush")),
				"no-rush",
				"no rush",
				"no rush shipping",
				"fewer boxes",
			],
			"Standard Shipping": [
				normalize(getMessageOrDefault("pageSettingsCheckoutShippingStandard", "Standard Shipping")),
				"standard shipping",
				"standard",
			],
		};

		const fallbackOrder = {
			"Amazon Day": ["Amazon Day", "Standard Shipping"],
			"No-Rush": ["No-Rush", "Standard Shipping"],
			"Standard Shipping": ["Standard Shipping"],
		};

		const desiredOrder = fallbackOrder[shippingPriority] || [shippingPriority];
		const desiredTokenSets = desiredOrder.map((opt) => tokenMap[opt] || [normalize(opt)]);

		const selector =
			'.shipping-option-radio, .a-radio input[type="radio"], input[name="shippingSpeed"], input[id*="shipping"], input[name*="ship"], input[type="radio"][name*="miq://"], input[type="radio"][id*="miq://"], #col-delivery-group input[type="radio"], input[type="radio"][value="first"], input[type="radio"][value="second"], input[type="radio"][value="third"]';

		const waitAndSelect = async (timeout = 5000, interval = 150) => {
			const start = Date.now();
			while (Date.now() - start < timeout) {
				const radios = Array.from(document.querySelectorAll(selector));
				if (Settings.get("general.debugCheckout")) {
					console.log("VH Debug [Checkout]: Found", radios.length, "shipping radios");
				}
				if (radios.length > 0) {
					for (const radio of radios) {
						try {
							if (radio.disabled) continue;

							let labelText = "";
							if (radio.id) {
								const lbl = document.querySelector(`label[for='${CSS.escape(radio.id)}']`);
								if (lbl) labelText = lbl.textContent || "";
							}
							if (!labelText && radio.getAttribute("aria-labelledby")) {
								const ids = radio.getAttribute("aria-labelledby").split(/\s+/);
								labelText = ids
									.map((id) => {
										const el = document.getElementById(id);
										return el ? el.textContent || "" : "";
									})
									.join(" ");
							}
							if (!labelText) {
								const lbl = radio.closest("label");
								if (lbl) labelText = lbl.textContent || "";
							}
							if (!labelText && radio.getAttribute("aria-label")) {
								labelText = radio.getAttribute("aria-label") || "";
							}
							if (!labelText) {
								const container =
									radio.closest(".shipping-option, .a-column, .a-row") || radio.parentElement;
								labelText = (container && container.textContent) || radio.textContent || "";
							}
							if (!labelText) {
								labelText = radio.value || "";
							}

							if (Settings.get("general.debugCheckout")) {
								console.log(
									"VH Debug [Checkout]: Radio labelText=",
									labelText,
									"norm=",
									normalize(labelText),
									"value=",
									radio.value,
									"id=",
									radio.id
								);
							}
							const norm = normalize(labelText);
							for (const desiredTokens of desiredTokenSets) {
								for (const tok of desiredTokens) {
									if (tok && norm.includes(tok)) {
										if (!radio.checked) {
											try {
												radio.scrollIntoView({ block: "center", inline: "nearest" });
												radio.click();
												radio.dispatchEvent(new Event("change", { bubbles: true }));
												radio.dispatchEvent(new Event("input", { bubbles: true }));
											} catch (e) {
												// best-effort
											}
										}
										return true;
									}
								}
							}
						} catch (e) {
							continue;
						}
					}
				}
				await new Promise((r) => setTimeout(r, interval));
			}
			return false;
		};

		const ok = await waitAndSelect(4000, 120);
		if (!ok) {
			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Shipping option not found or not selectable; leaving default.");
			}
		} else if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: Shipping option auto-selected for:", shippingPriority);
		}
	}

	//###########################
	//Check if price is not zero, if so, alert the user.
	// Only check price if we have confirmed this is a Vine checkout
	if (Settings.get("general.displayNonZeroPriceWarning") || orderNow) {
		const price = getTotal();
		if (Settings.get("general.debugCheckout")) {
			console.log(
				"VH Debug [Checkout]: Non-Zero Price Check - warning enabled:",
				Settings.get("general.displayNonZeroPriceWarning"),
				"orderNow:",
				orderNow,
				"price:",
				price
			);
		}
		if (price !== false && parseFloat(price) !== 0) {
			console.log("getCurrentInfo(): " + (await getCurrentInfo()));
			console.log("currentASIN: " + currentASIN);
			if (Settings.get("general.debugCheckout")) {
				console.log(
					"VH Debug [Checkout]: Non-zero price detected ($" + price + "), showing alert and halting checkout"
				);
			}
			const message = getMessageOrDefault("alertCheckoutPriceNotZero", "VHelper warning: Price is not zero.");
			alert(message);
			return;
		} else if (Settings.get("general.debugCheckout")) {
			console.log("VH Debug [Checkout]: Price is zero or not found, proceeding with checkout");
		}
	}

	//If the current checkout is a buy now checkout, check for the place order button
	if (orderNow) {
		attemptPlaceOrder();
	}
}
init();

async function getCurrentCheckout(currentASIN) {
	const arrCurrentCheckouts = (await Settings.get("checkout.arrCurrentCheckouts", false)) || [];
	return arrCurrentCheckouts.find((checkout) => checkout.asin === currentASIN);
}

/**
 * Get the current checkout information from the settings.
 * Return null if the checkout is not a vine checkout.
 * @returns {Object} {asin: string, parent_asin: string, productId: string, expires: number}
 */
async function getCurrentInfo() {
	const arrCurrentCheckouts = (await Settings.get("checkout.arrCurrentCheckouts", false)) || [];
	if (arrCurrentCheckouts.length > 0) {
		return arrCurrentCheckouts.find((checkout) => getProductId() === checkout.productId);
	}
	return null;
}

function getProductId() {
	//Parse the URL to get the product id from either:
	// https://www.amazon.ca/checkout/p/p-733-6232317-0987411/whatever
	// https://www.amazon.ca/gp/buy/thankyou/handlers/display.html?purchaseId=703-9520370-5320250
	const url = new URL(window.location.href);

	// Try to get ID from checkout URL path
	const pNumber = url.pathname
		.split("/")
		.find((segment) => segment.startsWith("p-"))
		?.substring(2);

	if (pNumber) {
		return pNumber;
	}

	// Try to get ID from thank you page URL params
	const purchaseId = url.searchParams.get("purchaseId");
	if (purchaseId) {
		return purchaseId;
	}

	return null;
}

function getCountry() {
	//Get the URL's domain TLD
	const url = new URL(window.location.href);
	const domain = url.hostname;
	return domain.split(".").pop();
}

//###########################
//Order confirmation page

function getTotal() {
	const rawTotal = document.querySelector(
		"ul#subtotals-marketplace-table li:last-child .order-summary-line-definition"
	);
	if (!rawTotal) {
		return false;
	}
	const total = parseFloat(rawTotal.textContent.replace(/[^\d.]/g, ""));
	return total;
}

function isLikelyVineCheckoutEntry() {
	const html = document.documentElement.innerHTML || "";
	const hasVineCheckoutMarkers =
		html.includes("/vine/help") ||
		html.includes("/vine/about") ||
		html.includes("For items from Amazon Vine") ||
		html.includes("estimated tax value of the item");
	if (hasVineCheckoutMarkers) {
		return true;
	}
	const referrer = document.referrer || "";
	return referrer.includes("/vine/");
}

/**
 * This error is not specific to vine, but is displayed when there is no stock available for the quantity requested.
 * @returns boolean
 */
function checkForOutOfStockError() {
	const outOfStockError = document.querySelector(
		`div[data-messageid="OfferListingUnavailableCvMessage"],div[data-messageid="ItemQuantityUnavailableCVMessage"]`
	);
	if (outOfStockError) {
		console.log("Out of stock error found");
		return true;
	}
}

/**
 * This error is specific to vine, but can happen when we take too long (>10 minutes?) to complete the checkout.
 * @returns boolean
 */
function checkForVineOrderCannotBeProcessedError() {
	const orderCannotBeProcessedError = document.querySelector(`div[data-messageid="VineCVMessage"]`);
	if (orderCannotBeProcessedError) {
		console.log("Vine order cannot be processed error found");
		return true;
	}
}

function getQuantity() {
	const quantity = document.querySelector(".quantity-display");
	if (!quantity) {
		return false;
	}
	return parseInt(quantity.textContent);
}

//###########################
//Error(s) on the page

async function checkForError() {
	const currentInfo = await getCurrentInfo();
	if (currentInfo) {
		console.log("Item ASIN: " + currentInfo.asin);
		console.log("Parent ASIN: " + currentInfo.parent_asin);
		console.log("Country: " + getCountry());
		//We want the error confirming this is a vine listing AND the error confirming there is no stock available.
		if (checkForVineOrderCannotBeProcessedError() && checkForOutOfStockError()) {
			console.log("vine error stock not available");
			console.log("Assume ITEM_NOT_IN_ENROLLMENT error");
			contactVHServer(false);
		}
	}
}

//###########################
//Thank you page

async function checkForSuccess() {
	if (isPageThankYou() && isOrderIdIssued()) {
		console.log("Thank you page, order sucessful: " + isOrderIdIssued());

		const currentInfo = await getCurrentInfo();
		if (currentInfo) {
			console.log("Current ASIN: " + currentInfo.asin);
			console.log("Current parent ASIN: " + currentInfo.parent_asin);
			console.log("Current country: " + getCountry());
			contactVHServer(true);
		} else {
			console.log(
				"No ASIN found in the current checkouts, could not establish this to be a vine order. Not updating VH server."
			);
		}
	}
}

function isPageThankYou() {
	//If the URL match that of a thank you page
	const url = window.location.href;
	if (url.includes("/buy/thankyou")) {
		return true;
	}
	return false;
}

function isOrderIdIssued() {
	const orderId = new URL(window.location.href).searchParams.get("purchaseId");
	return !!orderId;
}

//###########################
//VH server

async function contactVHServer(status) {
	const currentInfo = await getCurrentInfo();
	if (!currentInfo) {
		console.log("No ASIN found, not contacting VH server");
		return;
	}

	const content = {
		api_version: 5,
		app_version: env.data.appVersion,
		action: "record_order",
		country: getCountry(),
		uuid: await Settings.get("general.uuid", false),
		cid: await Settings.get("general.cid", false),
		fid: await Settings.get("general.fingerprint.id", false),
		asin: currentInfo.asin,
		parent_asin: currentInfo.parent_asin,
		order_status: status ? "success" : "failed",
		order_error: status ? null : "ITEM_NOT_IN_ENROLLMENT",
	};

	const s = await cryptoKeys.signData(content);
	content.s = s;
	content.pk = await cryptoKeys.getExportedPublicKey();

	//Form the full URL
	await fetch(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(content),
	});
}
