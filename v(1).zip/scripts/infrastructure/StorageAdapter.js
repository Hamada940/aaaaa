/*global chrome*/

/**
 * Storage Adapter Interface
 *
 * This provides an abstraction over chrome.storage to:
 * - Enable unit testing without browser APIs
 * - Support different storage backends (local, sync, memory)
 * - Provide a consistent async/await interface
 */

/**
 * Base storage adapter interface
 */
export class StorageAdapter {
	/**
	 * Get a value from storage
	 * @param {string} key - Storage key
	 * @returns {Promise<*>} The stored value or undefined
	 */
	async get() {
		throw new Error("get() must be implemented by subclass");
	}

	/**
	 * Get multiple values from storage
	 * @param {Array<string>} keys - Array of storage keys
	 * @returns {Promise<Object>} Object with key-value pairs
	 */
	async getMultiple() {
		throw new Error("getMultiple() must be implemented by subclass");
	}

	/**
	 * Set a value in storage
	 * @param {string} key - Storage key
	 * @param {*} value - Value to store
	 * @returns {Promise<void>}
	 */
	async set() {
		throw new Error("set() must be implemented by subclass");
	}

	/**
	 * Set multiple values in storage
	 * @param {Object} items - Object with key-value pairs
	 * @returns {Promise<void>}
	 */
	async setMultiple() {
		throw new Error("setMultiple() must be implemented by subclass");
	}

	/**
	 * Remove a value from storage
	 * @param {string} key - Storage key
	 * @returns {Promise<void>}
	 */
	async remove() {
		throw new Error("remove() must be implemented by subclass");
	}

	/**
	 * Clear all values from storage
	 * @returns {Promise<void>}
	 */
	async clear() {
		throw new Error("clear() must be implemented by subclass");
	}
}

/**
 * Chrome storage adapter for production use
 */
export class ChromeStorageAdapter extends StorageAdapter {
	_storage;

	constructor(storageArea = "local") {
		super();
		try {
			this._storage = typeof chrome !== "undefined" && chrome.storage ? chrome.storage[storageArea] : null;
		} catch {
			this._storage = null;
		}
	}

	_isValid() {
		try {
			const valid = this._storage && typeof chrome !== "undefined" && chrome.runtime?.id != null;
			if (!valid && typeof window !== "undefined" && !window.__vh_context_invalidated_dispatched) {
				window.__vh_context_invalidated_dispatched = true;
				window.dispatchEvent(new CustomEvent("vh:context-invalidated"));
			}
			return valid;
		} catch {
			if (typeof window !== "undefined" && !window.__vh_context_invalidated_dispatched) {
				window.__vh_context_invalidated_dispatched = true;
				window.dispatchEvent(new CustomEvent("vh:context-invalidated"));
			}
			return false;
		}
	}

	async get(key) {
		if (!this._isValid()) {
			throw new Error("Extension context invalidated");
		}
		try {
			return new Promise((resolve, reject) => {
				this._storage.get(key, (result) => {
					if (chrome.runtime.lastError) {
						reject(new Error(chrome.runtime.lastError.message));
					} else {
						resolve(result[key]);
					}
				});
			});
		} catch (err) {
			throw new Error("Extension context invalidated");
		}
	}

	async getMultiple(keys) {
		if (!this._isValid()) {
			throw new Error("Extension context invalidated");
		}
		try {
			return new Promise((resolve, reject) => {
				this._storage.get(keys, (result) => {
					if (chrome.runtime.lastError) {
						reject(new Error(chrome.runtime.lastError.message));
					} else {
						resolve(result);
					}
				});
			});
		} catch (err) {
			throw new Error("Extension context invalidated");
		}
	}

	async set(key, value) {
		if (!this._isValid()) {
			throw new Error("Extension context invalidated");
		}
		try {
			return new Promise((resolve, reject) => {
				this._storage.set({ [key]: value }, () => {
					if (chrome.runtime.lastError) {
						const error = chrome.runtime.lastError;
						// Handle quota errors specifically
						if (error.message && error.message.includes("quota")) {
							const quotaError = new Error(error.message);
							quotaError.name = "QuotaExceededError";
							reject(quotaError);
						} else {
							// Ensure we have a meaningful error message
							const errorMessage = error.message || error.toString() || "Unknown Chrome storage error";
							console.log("Final error message:", errorMessage);
							reject(new Error(errorMessage));
						}
					} else {
						resolve();
					}
				});
			});
		} catch (err) {
			throw new Error("Extension context invalidated");
		}
	}
	async setMultiple(items) {
		if (!this._isValid()) {
			throw new Error("Extension context invalidated");
		}
		try {
			return new Promise((resolve, reject) => {
				this._storage.set(items, () => {
					if (chrome.runtime.lastError) {
						const error = chrome.runtime.lastError;
						// Safari-specific quota error handling
						if (error.message && error.message.includes("Exceeded storage quota")) {
							const quotaError = new Error(error.message);
							quotaError.name = "QuotaExceededError";
							reject(quotaError);
						} else if (error.message && error.message.includes("QUOTA_BYTES quota exceeded")) {
							const quotaError = new Error(error.message);
							quotaError.name = "QuotaExceededError";
							reject(quotaError);
						} else {
							reject(new Error(error.message));
						}
					} else {
						resolve();
					}
				});
			});
		} catch (err) {
			throw new Error("Extension context invalidated");
		}
	}

	async remove(key) {
		if (!this._isValid()) {
			throw new Error("Extension context invalidated");
		}
		try {
			return new Promise((resolve, reject) => {
				this._storage.remove(key, () => {
					if (chrome.runtime.lastError) {
						reject(new Error(chrome.runtime.lastError.message));
					} else {
						resolve();
					}
				});
			});
		} catch (err) {
			throw new Error("Extension context invalidated");
		}
	}

	async clear() {
		if (!this._isValid()) {
			throw new Error("Extension context invalidated");
		}
		try {
			return new Promise((resolve, reject) => {
				this._storage.clear(() => {
					if (chrome.runtime.lastError) {
						reject(new Error(chrome.runtime.lastError.message));
					} else {
						resolve();
					}
				});
			});
		} catch (err) {
			throw new Error("Extension context invalidated");
		}
	}
}

/** Service Worker adapter for production use */
export class ServiceWorkerStorageAdapter extends ChromeStorageAdapter {
	constructor() {
		super();
	}

	async set(key, value) {
		return new Promise((resolve, reject) => {
			// Try service worker messaging first, fall back to direct storage if it fails
			chrome.runtime.sendMessage(
				{
					type: "saveToLocalStorage",
					key,
					value,
				},
				(response) => {
					if (chrome.runtime.lastError) {
						// If service worker messaging fails (e.g., "message port closed"),
						// fall back to direct storage
						if (chrome.runtime.lastError.message.includes("message port closed")) {
							super.set(key, value).then(resolve).catch(reject);
						} else {
							reject(new Error(chrome.runtime.lastError.message + ": " + key));
						}
					} else if (response && response.success) {
						resolve();
					} else if (response && !response.success) {
						// Service worker returned an error
						console.log("ServiceWorkerStorageAdapter received error response:", response);
						console.log("Response error:", response.error);
						const error = new Error(response.error || "Storage operation failed");
						if (response.errorName) {
							error.name = response.errorName;
						}
						reject(error);
					} else {
						// Null/empty SW responses can happen during worker lifecycle changes; fall back to direct storage.
						super.set(key, value).then(resolve).catch(reject);
					}
				}
			);
		});
	}

	async clear() {
		return new Promise((resolve, reject) => {
			// Try service worker messaging first, fall back to direct storage if it fails
			chrome.runtime.sendMessage(
				{
					type: "clearLocalStorage",
				},
				(response) => {
					if (chrome.runtime.lastError) {
						// If service worker messaging fails (e.g., "message port closed"),
						// fall back to direct storage
						if (chrome.runtime.lastError.message.includes("message port closed")) {
							super.clear().then(resolve).catch(reject);
						} else {
							reject(new Error(chrome.runtime.lastError.message));
						}
					} else if (response) {
						resolve();
					} else {
						// Null/empty SW responses can happen during worker lifecycle changes; fall back to direct storage.
						super.clear().then(resolve).catch(reject);
					}
				}
			);
		});
	}
}

/**
 * In-memory storage adapter for testing
 */
export class MemoryStorageAdapter extends StorageAdapter {
	#data;

	constructor() {
		super();
		this.#data = new Map();
	}

	async get(key) {
		return this.#data.get(key);
	}

	async getMultiple(keys) {
		const result = {};
		for (const key of keys) {
			const value = this.#data.get(key);
			if (value !== undefined) {
				result[key] = value;
			}
		}
		return result;
	}

	async set(key, value) {
		this.#data.set(key, value);
	}

	async setMultiple(items) {
		for (const [key, value] of Object.entries(items)) {
			this.#data.set(key, value);
		}
	}

	async remove(key) {
		this.#data.delete(key);
	}

	async clear() {
		this.#data.clear();
	}
}
