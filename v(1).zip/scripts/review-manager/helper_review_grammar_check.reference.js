/**
 * Reference for VH API action `review_grammar_check` (server-side; not loaded by extension).
 *
 * Request (signed, api_version 5):
 *   action: "review_grammar_check"
 *   text: string (review body, max ~16 KB)
 *   language: string — locale code or "auto"
 *   preferred_languages: optional comma-separated list when language is "auto"
 *
 * Response:
 *   {
 *     matches: Array<{ offset, length, message, shortMessage?, replacements?, rule? }>,
 *     tokens_remaining: number,
 *     tokens_max: number
 *   }
 *
 * Server uses OpenAI (same token pool as review_suggest_topics). Tier 3 required.
 * Review text is sent to OpenAI for analysis only; not stored in VH database.
 */

export const REVIEW_GRAMMAR_CHECK_ACTION = "review_grammar_check";
