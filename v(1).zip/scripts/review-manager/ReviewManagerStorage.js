/**
 * Local filesystem storage via File System Access API + IndexedDB handle persistence.
 */

const IDB_NAME = "vh-review-manager";
const IDB_STORE = "handles";
const IDB_KEY = "rootDirectory";
const PENDING_LIST_FILE = "_vine_pending_reviews.json";
const REVIEW_TEXT_FILE = "review.txt";
const DATA_JSON_FILE = "data.json";
const ARCHIVED_DIR = "archived";

function openDb() {
	return new Promise((resolve, reject) => {
		const request = indexedDB.open(IDB_NAME, 1);
		request.onerror = () => reject(request.error);
		request.onsuccess = () => resolve(request.result);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains(IDB_STORE)) {
				db.createObjectStore(IDB_STORE);
			}
		};
	});
}

export function normalizeSuggestedTopics(topics) {
	if (!Array.isArray(topics)) {
		return [];
	}
	return topics.filter((t) => typeof t === "string" && t.trim()).map((t) => t.trim());
}

export function normalizeSuggestedEvaluation(evaluation) {
	if (!evaluation || typeof evaluation !== "object") {
		return null;
	}
	const result = typeof evaluation.result === "string" ? evaluation.result.trim() : "";
	const recommendations = Array.isArray(evaluation.recommendations)
		? evaluation.recommendations.filter((r) => typeof r === "string" && r.trim()).map((r) => r.trim())
		: [];
	if (!result && recommendations.length === 0) {
		return null;
	}
	return { result, recommendations };
}

/** @param {string} folderName */
export function asinFromFolderName(folderName) {
	const dash = folderName.indexOf("-");
	if (dash <= 0) {
		return null;
	}
	return folderName.slice(0, dash);
}

export function sanitizeTitleSlug(title) {
	return String(title || "")
		.slice(0, 50)
		.replace(/\s+/g, "-")
		.replace(/[^a-zA-Z0-9-]/g, "")
		.replace(/-+/g, "-")
		.replace(/^-+|-+$/g, "");
}

export function sanitizeFolderName(title, asin) {
	const slug = sanitizeTitleSlug(title) || "review";
	return `${asin}-${slug}`;
}

/** @param {unknown} order @param {string[]} fileNames */
export function normalizeImageOrder(order, fileNames) {
	const names = new Set(fileNames);
	const result = [];
	const seen = new Set();
	if (Array.isArray(order)) {
		for (const entry of order) {
			if (typeof entry === "string" && names.has(entry) && !seen.has(entry)) {
				result.push(entry);
				seen.add(entry);
			}
		}
	}
	for (const name of [...names].sort((a, b) => a.localeCompare(b))) {
		if (!seen.has(name)) {
			result.push(name);
		}
	}
	return result;
}

/** @param {string[]} names @param {number} fromIndex @param {number} toIndex */
export function reorderImageNames(names, fromIndex, toIndex) {
	if (fromIndex < 0 || toIndex < 0 || fromIndex >= names.length || toIndex >= names.length) {
		return names;
	}
	const result = [...names];
	const [item] = result.splice(fromIndex, 1);
	result.splice(toIndex, 0, item);
	return result;
}

/** @param {{ name: string }[]} files @param {unknown} imageOrder */
export function sortImageFiles(files, imageOrder) {
	return sortFilesByNameOrder(files, imageOrder);
}

/** @param {{ name: string }[]} files @param {unknown} imageOrder */
export function sortFilesByNameOrder(files, imageOrder) {
	const order = normalizeImageOrder(
		imageOrder,
		files.map((f) => f.name)
	);
	const byName = new Map(files.map((f) => [f.name, f]));
	return order.map((name) => byName.get(name)).filter(Boolean);
}

export class ReviewManagerStorage {
	#rootHandle = null;

	async hasDirectory() {
		if (this.#rootHandle) {
			return true;
		}
		const handle = await this.#loadStoredHandle();
		return !!handle;
	}

	async pickDirectory() {
		if (!window.showDirectoryPicker) {
			throw new Error("Your browser does not support folder access. Use Chrome or Edge on desktop.");
		}
		const handle = await window.showDirectoryPicker({ mode: "readwrite" });
		await this.#persistHandle(handle);
		this.#rootHandle = handle;
		return handle;
	}

	async getRootHandle() {
		if (this.#rootHandle) {
			return this.#rootHandle;
		}
		const handle = await this.#loadStoredHandle();
		if (!handle) {
			return null;
		}
		const permission = await handle.queryPermission({ mode: "readwrite" });
		if (permission !== "granted") {
			const requested = await handle.requestPermission({ mode: "readwrite" });
			if (requested !== "granted") {
				return null;
			}
		}
		this.#rootHandle = handle;
		return handle;
	}

	async #persistHandle(handle) {
		const db = await openDb();
		await new Promise((resolve, reject) => {
			const tx = db.transaction(IDB_STORE, "readwrite");
			tx.objectStore(IDB_STORE).put(handle, IDB_KEY);
			tx.oncomplete = () => resolve();
			tx.onerror = () => reject(tx.error);
		});
	}

	async #loadStoredHandle() {
		const db = await openDb();
		return new Promise((resolve, reject) => {
			const tx = db.transaction(IDB_STORE, "readonly");
			const req = tx.objectStore(IDB_STORE).get(IDB_KEY);
			req.onsuccess = () => resolve(req.result || null);
			req.onerror = () => reject(req.error);
		});
	}

	async #findReviewFolderIn(parent, asin) {
		const prefix = `${asin}-`;
		for await (const [name, handle] of parent.entries()) {
			if (handle.kind !== "directory") {
				continue;
			}
			if (name.startsWith(prefix)) {
				return { name, handle };
			}
		}
		return null;
	}

	async #findReviewFolderByAsin(root, asin) {
		for await (const [name, handle] of root.entries()) {
			if (handle.kind !== "directory" || name === ARCHIVED_DIR) {
				continue;
			}
			const prefix = `${asin}-`;
			if (name.startsWith(prefix)) {
				return { name, handle };
			}
		}
		return null;
	}

	async #getArchivedDir() {
		const root = await this.getRootHandle();
		if (!root) {
			return null;
		}
		try {
			return await root.getDirectoryHandle(ARCHIVED_DIR);
		} catch {
			return null;
		}
	}

	async #getArchivedFolderHandle(asin) {
		const archivedDir = await this.#getArchivedDir();
		if (!archivedDir) {
			throw new Error(`No archived review folder for ASIN ${asin}`);
		}
		const existing = await this.#findReviewFolderIn(archivedDir, asin);
		if (!existing) {
			throw new Error(`No archived review folder for ASIN ${asin}`);
		}
		return existing.handle;
	}

	async #maybeRenameReviewFolder(root, existing, asin, productTitle) {
		const desiredName = sanitizeFolderName(productTitle, asin);
		if (existing.name === desiredName) {
			return existing.handle;
		}
		try {
			if (typeof existing.handle.move === "function") {
				await existing.handle.move(root, desiredName);
				return root.getDirectoryHandle(desiredName);
			}
		} catch {
			// keep existing folder name if rename fails
		}
		return existing.handle;
	}

	async getReviewFolder(review, { create = true } = {}) {
		const root = await this.getRootHandle();
		if (!root) {
			throw new Error("No storage folder selected.");
		}
		const asin = review.asin;
		const existing = await this.#findReviewFolderByAsin(root, asin);
		if (existing) {
			return this.#maybeRenameReviewFolder(root, existing, asin, review.productTitle);
		}
		if (!create) {
			throw new Error(`No review folder for ASIN ${asin}`);
		}
		const dirName = sanitizeFolderName(review.productTitle, asin);
		return root.getDirectoryHandle(dirName, { create: true });
	}

	async #writeTextFile(folder, fileName, text) {
		const fileHandle = await folder.getFileHandle(fileName, { create: true });
		const writable = await fileHandle.createWritable();
		await writable.write(text);
		await writable.close();
	}

	async #readTextFile(folder, fileName) {
		const fileHandle = await folder.getFileHandle(fileName);
		const file = await fileHandle.getFile();
		return file.text();
	}

	async #isReviewFolder(folderHandle) {
		try {
			await folderHandle.getFileHandle(DATA_JSON_FILE);
			return true;
		} catch {
			// fall through
		}
		try {
			await folderHandle.getFileHandle(REVIEW_TEXT_FILE);
			return true;
		} catch {
			// fall through
		}
		for await (const [fileName] of folderHandle.entries()) {
			if (fileName.endsWith("_review.txt")) {
				return true;
			}
		}
		return false;
	}

	async #loadLegacyReviewJson(folder, asin) {
		try {
			const fileHandle = await folder.getFileHandle(`${asin}_review.txt`);
			const file = await fileHandle.getFile();
			return JSON.parse(await file.text());
		} catch {
			return null;
		}
	}

	async saveReview(review) {
		const folder = await this.getReviewFolder(review);
		await folder.getDirectoryHandle("images", { create: true });
		const existing = await this.loadReview(review.asin);
		const topicsProvided = Object.prototype.hasOwnProperty.call(review, "suggestedTopics");
		const evaluationProvided = Object.prototype.hasOwnProperty.call(review, "suggestedEvaluation");
		const descriptionProvided = Object.prototype.hasOwnProperty.call(review, "productDescription");
		const vhPriceProvided = Object.prototype.hasOwnProperty.call(review, "vhPrice");
		const currentPriceProvided = Object.prototype.hasOwnProperty.call(review, "currentPrice");
		const productCacheUpdated = descriptionProvided || vhPriceProvided || currentPriceProvided;
		const reviewContent = review.reviewContent ?? existing?.reviewContent ?? "";
		const payload = {
			asin: review.asin,
			productTitle: review.productTitle,
			productUrl: review.productUrl,
			imageUrl: review.imageUrl,
			orderDateMs: review.orderDateMs,
			stars: review.stars ?? existing?.stars ?? 5,
			reviewTitle: review.reviewTitle ?? existing?.reviewTitle ?? "",
			suggestedTopics: topicsProvided
				? normalizeSuggestedTopics(review.suggestedTopics)
				: normalizeSuggestedTopics(existing?.suggestedTopics),
			suggestedEvaluation: evaluationProvided
				? normalizeSuggestedEvaluation(review.suggestedEvaluation)
				: normalizeSuggestedEvaluation(existing?.suggestedEvaluation),
			suggestionsUpdatedAt:
				topicsProvided || evaluationProvided
					? new Date().toISOString()
					: (existing?.suggestionsUpdatedAt ?? null),
			productDescription: descriptionProvided
				? String(review.productDescription ?? "")
				: (existing?.productDescription ?? ""),
			vhPrice: vhPriceProvided ? (review.vhPrice ?? null) : (existing?.vhPrice ?? null),
			currentPrice: currentPriceProvided ? (review.currentPrice ?? null) : (existing?.currentPrice ?? null),
			productCacheUpdatedAt: productCacheUpdated
				? new Date().toISOString()
				: (existing?.productCacheUpdatedAt ?? null),
			imageOrder: Object.prototype.hasOwnProperty.call(review, "imageOrder")
				? normalizeImageOrder(review.imageOrder, await this.#listImageFileNames(folder))
				: normalizeImageOrder(existing?.imageOrder, await this.#listImageFileNames(folder)),
			updatedAt: new Date().toISOString(),
		};
		await this.#writeTextFile(folder, REVIEW_TEXT_FILE, reviewContent);
		const dataHandle = await folder.getFileHandle(DATA_JSON_FILE, { create: true });
		const writable = await dataHandle.createWritable();
		await writable.write(JSON.stringify(payload, null, 2));
		await writable.close();
	}

	async savePendingReviewList(reviews) {
		const root = await this.getRootHandle();
		if (!root) {
			throw new Error("No storage folder selected.");
		}
		const fileHandle = await root.getFileHandle(PENDING_LIST_FILE, { create: true });
		const writable = await fileHandle.createWritable();
		await writable.write(
			JSON.stringify(
				{
					syncedAt: new Date().toISOString(),
					reviews: Array.isArray(reviews) ? reviews : [],
				},
				null,
				2
			)
		);
		await writable.close();
	}

	async loadPendingReviewList() {
		try {
			const root = await this.getRootHandle();
			if (!root) {
				return null;
			}
			const fileHandle = await root.getFileHandle(PENDING_LIST_FILE);
			const file = await fileHandle.getFile();
			return JSON.parse(await file.text());
		} catch {
			return null;
		}
	}

	async #loadReviewFromFolder(folder, asin) {
		let data = null;
		try {
			data = JSON.parse(await this.#readTextFile(folder, DATA_JSON_FILE));
		} catch {
			data = await this.#loadLegacyReviewJson(folder, asin);
		}
		if (!data) {
			return null;
		}
		let reviewContent = "";
		try {
			reviewContent = await this.#readTextFile(folder, REVIEW_TEXT_FILE);
		} catch {
			reviewContent = typeof data.reviewContent === "string" ? data.reviewContent : "";
		}
		const { reviewContent: _legacyContent, ...meta } = data;
		return { ...meta, reviewContent };
	}

	async loadReview(asin, _productTitle, { archived = false } = {}) {
		try {
			const folder = archived
				? await this.#getArchivedFolderHandle(asin)
				: await this.getReviewFolder({ asin }, { create: false });
			return await this.#loadReviewFromFolder(folder, asin);
		} catch {
			return null;
		}
	}

	async listSavedReviews() {
		const root = await this.getRootHandle();
		if (!root) {
			return [];
		}
		const entries = [];
		for await (const [name, handle] of root.entries()) {
			if (handle.kind !== "directory" || name === ARCHIVED_DIR) {
				continue;
			}
			const asin = asinFromFolderName(name);
			if (!asin) {
				continue;
			}
			const data = await this.#loadReviewFromFolder(handle, asin);
			if (data) {
				entries.push({ folderName: name, ...data });
			}
		}
		return entries;
	}

	async listArchivedReviews() {
		const archivedDir = await this.#getArchivedDir();
		if (!archivedDir) {
			return [];
		}
		const entries = [];
		for await (const [name, handle] of archivedDir.entries()) {
			if (handle.kind !== "directory") {
				continue;
			}
			const asin = asinFromFolderName(name);
			if (!asin) {
				continue;
			}
			const data = await this.#loadReviewFromFolder(handle, asin);
			if (data) {
				entries.push({ folderName: name, archived: true, ...data });
			}
		}
		return entries;
	}

	/**
	 * Move review folders to archived/ only when sync was complete and the ASIN was on the
	 * previous pending list but is absent from the new list (avoids false positives on partial scrapes).
	 * @param {string[]} activeAsins
	 * @param {{ previousActiveAsins?: string[] }} [options]
	 */
	async archiveStaleReviews(activeAsins, { previousActiveAsins = [] } = {}) {
		const root = await this.getRootHandle();
		if (!root) {
			return;
		}
		const activeSet = new Set(Array.isArray(activeAsins) ? activeAsins : []);
		const previousSet = new Set(Array.isArray(previousActiveAsins) ? previousActiveAsins : []);
		if (previousSet.size === 0) {
			return;
		}
		const archivedDir = await root.getDirectoryHandle(ARCHIVED_DIR, { create: true });
		const toArchive = [];
		for await (const [name, handle] of root.entries()) {
			if (handle.kind !== "directory" || name === ARCHIVED_DIR) {
				continue;
			}
			const asin = asinFromFolderName(name);
			if (!asin || activeSet.has(asin) || !previousSet.has(asin)) {
				continue;
			}
			if (await this.#isReviewFolder(handle)) {
				toArchive.push({ name, handle });
			}
		}
		for (const { name, handle } of toArchive) {
			await this.#moveFolderToArchived(root, archivedDir, name, handle);
		}
	}

	async #moveFolderToArchived(root, archivedDir, name, handle) {
		let destName = name;
		try {
			await archivedDir.getDirectoryHandle(name);
			destName = `${name}-${Date.now()}`;
		} catch {
			// no conflict
		}
		try {
			if (typeof handle.move === "function") {
				await handle.move(archivedDir, destName);
				return;
			}
		} catch (err) {
			console.warn("[VHelper Review Manager] Could not move folder to archived", name, err);
		}
		try {
			const dest = await archivedDir.getDirectoryHandle(destName, { create: true });
			await this.#copyDirectoryContents(handle, dest);
			await root.removeEntry(name, { recursive: true });
		} catch (err) {
			console.warn("[VHelper Review Manager] Could not archive folder", name, err);
		}
	}

	async #copyDirectoryContents(source, dest) {
		for await (const [entryName, entry] of source.entries()) {
			if (entry.kind === "file") {
				const file = await entry.getFile();
				const writable = await (await dest.getFileHandle(entryName, { create: true })).createWritable();
				await writable.write(file);
				await writable.close();
			} else {
				const subDest = await dest.getDirectoryHandle(entryName, { create: true });
				await this.#copyDirectoryContents(entry, subDest);
			}
		}
	}

	async #listImageFileNames(folder) {
		try {
			const imagesDir = await folder.getDirectoryHandle("images");
			const names = [];
			for await (const [name, handle] of imagesDir.entries()) {
				if (handle.kind === "file") {
					names.push(name);
				}
			}
			return names;
		} catch {
			return [];
		}
	}

	async #listRawImages(folder) {
		let imagesDir;
		try {
			imagesDir = await folder.getDirectoryHandle("images");
		} catch {
			return [];
		}
		const files = [];
		for await (const [name, handle] of imagesDir.entries()) {
			if (handle.kind === "file") {
				files.push({ name, handle });
			}
		}
		return files;
	}

	async listImages(asin, productTitle, { archived = false } = {}) {
		const folder = archived
			? await this.#getArchivedFolderHandle(asin)
			: await this.getReviewFolder({ asin, productTitle });
		const files = await this.#listRawImages(folder);
		const review = await this.loadReview(asin, productTitle, { archived });
		return sortImageFiles(files, review?.imageOrder);
	}

	async setImageOrder(asin, productTitle, orderedNames) {
		const folder = await this.getReviewFolder({ asin, productTitle });
		const fileNames = await this.#listImageFileNames(folder);
		const imageOrder = normalizeImageOrder(orderedNames, fileNames);
		let data = { asin };
		try {
			data = JSON.parse(await this.#readTextFile(folder, DATA_JSON_FILE));
		} catch {
			// new or legacy folder — start fresh metadata
		}
		data.imageOrder = imageOrder;
		data.updatedAt = new Date().toISOString();
		const dataHandle = await folder.getFileHandle(DATA_JSON_FILE, { create: true });
		const writable = await dataHandle.createWritable();
		await writable.write(JSON.stringify(data, null, 2));
		await writable.close();
	}

	async deleteImage(asin, productTitle, fileName) {
		const folder = await this.getReviewFolder({ asin, productTitle });
		const imagesDir = await folder.getDirectoryHandle("images");
		await imagesDir.removeEntry(fileName);
		const review = await this.loadReview(asin, productTitle);
		const nextOrder = (Array.isArray(review?.imageOrder) ? review.imageOrder : []).filter((n) => n !== fileName);
		await this.setImageOrder(asin, productTitle, nextOrder);
	}

	async addImageFiles(asin, productTitle, fileList) {
		const folder = await this.getReviewFolder({ asin, productTitle });
		const imagesDir = await folder.getDirectoryHandle("images", { create: true });
		const added = [];
		for (const file of fileList) {
			if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
				continue;
			}
			const fileHandle = await imagesDir.getFileHandle(file.name, { create: true });
			const writable = await fileHandle.createWritable();
			await writable.write(file);
			await writable.close();
			added.push(file.name);
		}
		if (added.length) {
			const review = await this.loadReview(asin, productTitle);
			const prior = Array.isArray(review?.imageOrder) ? review.imageOrder : [];
			await this.setImageOrder(asin, productTitle, [...prior, ...added]);
		}
	}

	async readImageBlobs(asin, productTitle, imageOrderOverride) {
		const folder = await this.getReviewFolder({ asin, productTitle });
		const raw = await this.#listRawImages(folder);
		const review = await this.loadReview(asin, productTitle);
		const order =
			imageOrderOverride ??
			(Array.isArray(review?.imageOrder) && review.imageOrder.length ? review.imageOrder : null);
		const sorted = sortImageFiles(raw, order);
		const blobs = [];
		for (const { name, handle } of sorted) {
			const file = await handle.getFile();
			blobs.push(new File([file], name, { type: file.type }));
		}
		return blobs;
	}
}
