/**
 * Scrape pending Vine reviews from /vine/vine-reviews (all pages).
 * Parsing logic lives in scripts/core/amazon/ — this file handles fetch orchestration only.
 */

import {
	buildVineReviewsPageUrl,
	enrichProductTitles,
	getAmazonOrigin,
	isGenericProductTitle,
	isVineReviewsPage,
	parseReviewsFromDocument,
} from "/scripts/core/amazon/parsers/reviews.js";
import { getPageCount, hasNextPageFromHtml } from "/scripts/core/amazon/parsers/pagination.js";
import { fetchProductPageData, fetchProductDescription } from "/scripts/core/amazon/parsers/product.js";

export {
	buildVineReviewsPageUrl,
	enrichProductTitles,
	getAmazonOrigin,
	hasNextPageFromHtml,
	isGenericProductTitle,
	isVineReviewsPage,
	parseReviewsFromDocument,
	fetchProductPageData,
	fetchProductDescription,
};
export { parseCurrentPriceFromDocument, fetchProductTitleFromDp } from "/scripts/core/amazon/index.js";

const MAX_PENDING_REVIEW_PAGES = 50;

/**
 * @typedef {{ reviews: Array<object>, complete: boolean, stopReason: string }} PendingReviewsFetchResult
 */

/**
 * @param {string} origin
 * @param {(page: number, totalPages: number | null) => void} [onPage]
 * @param {(done: number, total: number) => void} [onEnrich]
 * @returns {Promise<PendingReviewsFetchResult>}
 */
export async function fetchAllPendingReviews(origin, onPage, onEnrich) {
	const all = [];
	const seen = new Set();
	let page = 1;
	let complete = true;
	let stopReason = "no-next-page";
	/** @type {number | null} */
	let totalPages = null;

	while (page <= MAX_PENDING_REVIEW_PAGES) {
		const pageUrl = buildVineReviewsPageUrl(origin, page);
		const response = await fetch(pageUrl, { credentials: "include" });
		if (!response.ok) {
			complete = false;
			stopReason = `http-${response.status}`;
			break;
		}
		const html = await response.text();

		const doc = new DOMParser().parseFromString(html, "text/html");
		if (totalPages == null) {
			totalPages = getPageCount(doc);
		}
		let items = [];
		try {
			items = parseReviewsFromDocument(doc);
		} catch (err) {
			console.warn("[VHelper Review Manager] Could not parse reviews page", page, err);
		}
		const hasNext = hasNextPageFromHtml(html);
		if (!items.length) {
			if (hasNext && page < MAX_PENDING_REVIEW_PAGES) {
				if (onPage) {
					onPage(page, totalPages);
				}
				page += 1;
				continue;
			}
			stopReason = all.length === 0 ? "empty-list" : "no-next-page";
			break;
		}
		for (const item of items) {
			if (!seen.has(item.asin)) {
				seen.add(item.asin);
				all.push(item);
			}
		}
		if (onPage) {
			onPage(page, totalPages);
		}
		if (!hasNext) {
			stopReason = "no-next-page";
			break;
		}
		if (page >= MAX_PENDING_REVIEW_PAGES) {
			complete = false;
			stopReason = "max-pages";
			break;
		}
		page += 1;
	}

	await enrichProductTitles(all, origin, onEnrich);
	return { reviews: all, complete, stopReason };
}
