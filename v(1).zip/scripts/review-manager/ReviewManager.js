/**
 * Review Manager — pending Vine reviews with local folder storage.
 */

import {
	normalizeSuggestedEvaluation,
	normalizeSuggestedTopics,
	reorderImageNames,
	ReviewManagerStorage,
} from "./ReviewManagerStorage.js";
import {
	fetchAllPendingReviews,
	fetchProductPageData,
	fetchProductTitleFromDp,
	isVineReviewsPage,
	getAmazonOrigin,
	isGenericProductTitle,
} from "./ReviewManagerScraper.js";
import { applySpellcheck, detectSpellcheckLang } from "./ReviewManagerSpellCheck.js";
import { GRAMMAR_CHECK_MIN_CHARS, normalizeGrammarMatches, toLanguageToolLang } from "./ReviewManagerGrammarCheck.js";
import { ReviewManagerGrammarPanel } from "./ReviewManagerGrammarPanel.js";
import {
	checkGrammar,
	fetchTokenBalance,
	fetchTokenCosts,
	fetchVhProductPrice,
	suggestTopics,
} from "./ReviewManagerApi.js";
import { queueReviewInsert } from "./ReviewInsertQueue.js";
import { setPendingReviewInsert } from "./ReviewInsertBridge.js";
import { parseAiSuggestions } from "./parseAiSuggestions.js";
import { getMessage } from "/scripts/core/services/Internationalization.js";

const IMAGE_EXT_RE = /\.(jpe?g|png|gif|webp|bmp|svg|avif|heic|heif)$/i;
const VVP_CONTEXT_STORAGE_KEY = "vvpContext";
const EVALUATION_PERIOD_MS = 180 * 24 * 60 * 60 * 1000;

/** @param {number | string | null | undefined} reevaluationDate */
export function getEvaluationPeriodStartMs(reevaluationDate) {
	if (reevaluationDate == null || reevaluationDate === "") {
		return null;
	}
	const n = Number(reevaluationDate);
	if (!Number.isFinite(n)) {
		return null;
	}
	const ms = n < 1e12 ? n * 1000 : n;
	return ms - EVALUATION_PERIOD_MS;
}

/** @param {{ orderDateMs?: number | null }} review @param {number | null} periodStartMs */
export function isReviewInEvaluationPeriod(review, periodStartMs) {
	if (periodStartMs == null) {
		return true;
	}
	const orderMs = review.orderDateMs;
	if (orderMs == null) {
		return true;
	}
	return orderMs >= periodStartMs;
}

function isImageMedia(file, name) {
	if (file.type?.startsWith("image/")) {
		return true;
	}
	if (file.type?.startsWith("video/")) {
		return false;
	}
	return IMAGE_EXT_RE.test(name);
}

export class ReviewManager {
	#deps;
	#storage = new ReviewManagerStorage();
	#reviews = [];
	#archivedReviews = [];
	/** @type {"awaiting" | "archived"} */
	#activeListTab = "awaiting";
	#listFilterQuery = "";
	#selected = null;
	#tokens = null;
	#tokensMax = null;
	#tokenCosts = { grammar: 1, suggest: 10 };
	#suggestInFlight = false;
	#editorAutosaveEnabled = false;
	#autosaveTimer = null;
	#productDescription = "";
	#fabEl = null;
	#panelEl = null;
	#listAwaitingSync = true;
	#awaitingSyncStatusText = "";
	#syncInFlight = false;
	/** @type {number | null} */
	#evaluationPeriodStartMs = null;
	/** @type {ReviewManagerGrammarPanel | null} */
	#grammarPanel = null;
	#grammarCheckInFlight = false;
	#imageObjectUrls = new Set();
	#closeAnimationTimer = null;
	#imageDragName = null;

	constructor(deps) {
		this.#deps = deps;
	}

	#msg(key, fallback, substitutions) {
		return getMessage(key, fallback, substitutions);
	}

	#hasValidCachedVhPrice(saved) {
		return saved?.vhPrice != null && saved.vhPrice !== "" && !Number.isNaN(Number(saved.vhPrice));
	}

	async init() {
		if (!isVineReviewsPage() || typeof window.showDirectoryPicker !== "function") {
			return;
		}
		const { Settings, Tpl } = this.#deps;
		if (!Settings.get("general.reviewManager", true)) {
			return;
		}

		this.#injectStyles();
		await this.#mountFab();
		await this.#mountPanel(Tpl);
		const { startExtensionUpdateMonitor } = await import(
			chrome.runtime.getURL("/scripts/core/utils/ExtensionUpdateMonitor.js")
		);
		startExtensionUpdateMonitor();
	}

	#injectStyles() {
		const href = chrome.runtime.getURL("resource/css/review-manager.css?v=37");
		if (document.querySelector(`link[href="${href}"]`)) {
			return;
		}
		const link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = href;
		document.head.appendChild(link);
	}

	#applyFabLabel(fab) {
		const label = this.#msg("rmFabLabel", "VH's Review Manager");
		fab.title = label;
		fab.setAttribute("aria-label", label);
		fab.innerHTML = `<span class="vh-rm-fab-icon" aria-hidden="true">✎</span><span class="vh-rm-fab-label">${this.#escape(label)}</span>`;
	}

	async #mountFab() {
		const existing = document.getElementById("vh-review-manager-fab");
		if (existing) {
			this.#fabEl = existing;
			this.#applyFabLabel(existing);
			return;
		}
		const fab = document.createElement("button");
		fab.id = "vh-review-manager-fab";
		fab.type = "button";
		this.#applyFabLabel(fab);
		fab.addEventListener("click", () => this.open());
		document.body.appendChild(fab);
		this.#fabEl = fab;
	}

	async #mountPanel(Tpl) {
		if (document.getElementById("vh-review-manager-panel")) {
			this.#panelEl = document.getElementById("vh-review-manager-panel");
			return;
		}
		const theme = this.#deps.Settings.get("general.theme") || "forest";
		const rawHtml = await Tpl.loadFile("scripts/ui/templates/review_manager_panel.html");
		const html = Tpl.render(rawHtml);
		const wrap = document.createElement("div");
		wrap.innerHTML = html;
		const panel = wrap.firstElementChild;
		panel.classList.add(`theme-${theme}`, "theme-default");
		document.body.appendChild(panel);
		this.#panelEl = panel;
		this.#bindPanelEvents();
		this.#updateTokenCostButtons();
	}

	#bindPanelEvents() {
		const panel = this.#panelEl;
		panel.querySelector(".vh-rm-close")?.addEventListener("click", () => this.close());
		panel.querySelector(".vh-rm-backdrop")?.addEventListener("click", () => this.close());
		panel.querySelectorAll("#vh-rm-pick-folder, .vh-rm-pick-folder-btn").forEach((btn) => {
			btn.addEventListener("click", () => this.#pickFolder());
		});
		panel.querySelector("#vh-rm-sync")?.addEventListener("click", () => this.#syncReviews());
		panel.querySelector("#vh-rm-tab-awaiting")?.addEventListener("click", () => {
			void this.#switchListTab("awaiting");
		});
		panel.querySelector("#vh-rm-tab-archived")?.addEventListener("click", () => {
			void this.#switchListTab("archived");
		});
		panel.querySelector("#vh-rm-list-filter")?.addEventListener("input", (e) => {
			this.#listFilterQuery = e.target.value ?? "";
			this.#renderList();
		});
		const periodFilter = panel.querySelector("#vh-rm-current-period-filter");
		if (periodFilter) {
			periodFilter.checked = this.#deps.Settings.get("general.reviewManagerCurrentPeriodOnly", false);
			periodFilter.addEventListener("change", async () => {
				await this.#deps.Settings.set("general.reviewManagerCurrentPeriodOnly", periodFilter.checked);
				await this.#refreshEvaluationPeriodStart();
				this.#renderList();
			});
		}
		panel.querySelector("#vh-rm-back-list")?.addEventListener("click", () => this.#showList());
		panel.querySelector("#vh-rm-insert-overlay-back")?.addEventListener("click", () => {
			this.#hideInsertOverlay();
			this.#showList();
		});
		panel.querySelector("#vh-rm-suggest")?.addEventListener("click", () => this.#runSuggest());
		panel.querySelector("#vh-rm-insert")?.addEventListener("click", () => this.#insertOnAmazon());
		panel.querySelector("#vh-rm-upload-images")?.addEventListener("click", () => {
			panel.querySelector("#vh-rm-image-input")?.click();
		});
		panel.querySelector("#vh-rm-image-input")?.addEventListener("change", (e) => {
			this.#uploadImages(e.target.files);
			e.target.value = "";
		});
		this.#bindImageListDragDrop(panel);

		panel.querySelectorAll(".vh-rm-star").forEach((btn) => {
			btn.addEventListener("click", () => {
				const stars = Number(btn.dataset.stars);
				this.#setStars(stars, true);
			});
		});

		const titleEl = panel.querySelector("#vh-rm-review-title");
		const bodyEl = panel.querySelector("#vh-rm-review-body");
		const lang = detectSpellcheckLang(
			"",
			this.#deps.Settings.get("i18n.localeOverride"),
			this.#deps.i18n.getCountryCode()
		);
		if (titleEl) {
			applySpellcheck(titleEl, lang);
			titleEl.addEventListener("input", () => this.#scheduleAutosave());
		}
		if (bodyEl) {
			applySpellcheck(bodyEl, lang);
			bodyEl.addEventListener("input", () => {
				const detected = detectSpellcheckLang(
					bodyEl.value,
					this.#deps.Settings.get("i18n.localeOverride"),
					this.#deps.i18n.getCountryCode()
				);
				applySpellcheck(titleEl, detected);
				applySpellcheck(bodyEl, detected);
				this.#scheduleAutosave();
			});
		}

		this.#initGrammarUi(panel);
		this.#initCollapsibleSections(panel);
		panel.querySelector("#vh-rm-suggestions")?.addEventListener("click", (e) => {
			const toggle = e.target.closest(".vh-rm-suggest-section .vh-rm-collapsible-toggle");
			if (!toggle) {
				return;
			}
			const section = toggle.closest(".vh-rm-suggest-section");
			if (!section) {
				return;
			}
			const collapsed = !section.classList.contains("vh-rm-collapsible--collapsed");
			section.classList.toggle("vh-rm-collapsible--collapsed", collapsed);
			toggle.setAttribute("aria-expanded", collapsed ? "false" : "true");
		});
	}

	#initCollapsibleSections(panel) {
		panel.querySelector("#vh-rm-grammar-collapse-toggle")?.addEventListener("click", () => {
			void this.#setGrammarCollapsed(!this.#isGrammarCollapsed());
		});
		panel.querySelector("#vh-rm-ai-collapse-toggle")?.addEventListener("click", () => {
			void this.#setAiCollapsed(true);
		});
		panel.querySelector("#vh-rm-ai-expand-tab")?.addEventListener("click", () => {
			void this.#setAiCollapsed(false);
		});
		this.#applyGrammarCollapsed(this.#deps.Settings.get("general.reviewManagerGrammarCollapsed", false));
		this.#applyAiCollapsed(this.#deps.Settings.get("general.reviewManagerAiCollapsed", false));
	}

	#isGrammarCollapsed() {
		return (
			this.#panelEl?.querySelector("#vh-rm-grammar")?.classList.contains("vh-rm-collapsible--collapsed") ?? false
		);
	}

	#applyGrammarCollapsed(collapsed) {
		const wrap = this.#panelEl?.querySelector("#vh-rm-grammar");
		const toggle = this.#panelEl?.querySelector("#vh-rm-grammar-collapse-toggle");
		if (!wrap || !toggle) {
			return;
		}
		wrap.classList.toggle("vh-rm-collapsible--collapsed", collapsed);
		toggle.setAttribute("aria-expanded", collapsed ? "false" : "true");
		toggle.setAttribute(
			"aria-label",
			collapsed
				? this.#msg("rmExpandGrammar", "Expand grammar & style")
				: this.#msg("rmCollapseGrammar", "Collapse grammar & style")
		);
	}

	async #setGrammarCollapsed(collapsed) {
		this.#applyGrammarCollapsed(collapsed);
		await this.#deps.Settings.set("general.reviewManagerGrammarCollapsed", collapsed);
	}

	#applyAiCollapsed(collapsed) {
		const sidebar = this.#panelEl?.querySelector("#vh-rm-sidebar-ai");
		const layout = this.#panelEl?.querySelector(".vh-rm-editor-layout");
		const collapseBtn = this.#panelEl?.querySelector("#vh-rm-ai-collapse-toggle");
		const expandTab = this.#panelEl?.querySelector("#vh-rm-ai-expand-tab");
		if (!sidebar) {
			return;
		}
		sidebar.classList.toggle("vh-rm-sidebar-ai--collapsed", collapsed);
		layout?.classList.toggle("vh-rm-editor-layout--ai-collapsed", collapsed);
		if (collapseBtn) {
			collapseBtn.setAttribute("aria-expanded", collapsed ? "false" : "true");
			collapseBtn.setAttribute(
				"aria-label",
				collapsed
					? this.#msg("rmExpandAi", "Expand AI suggestions")
					: this.#msg("rmCollapseAi", "Collapse AI suggestions")
			);
		}
		if (expandTab) {
			expandTab.hidden = !collapsed;
			expandTab.setAttribute("aria-expanded", collapsed ? "false" : "true");
			expandTab.setAttribute("aria-label", this.#msg("rmExpandAi", "Expand AI suggestions"));
		}
	}

	async #setAiCollapsed(collapsed) {
		this.#applyAiCollapsed(collapsed);
		await this.#deps.Settings.set("general.reviewManagerAiCollapsed", collapsed);
	}

	#initGrammarUi(panel) {
		const wrap = panel.querySelector("#vh-rm-grammar");
		const status = panel.querySelector("#vh-rm-grammar-status");
		const badge = panel.querySelector("#vh-rm-grammar-badge");
		const list = panel.querySelector("#vh-rm-grammar-issues");
		const checkBtn = panel.querySelector("#vh-rm-grammar-check");
		if (!wrap || !status || !badge || !list) {
			return;
		}
		this.#grammarPanel = new ReviewManagerGrammarPanel({
			wrapEl: wrap,
			statusEl: status,
			badgeEl: badge,
			listEl: list,
			getMessage: (key, fallback, subs) => this.#msg(key, fallback, subs),
		});
		checkBtn?.addEventListener("click", () => {
			void this.#runGrammarCheck();
		});
	}

	#getGrammarApiDeps() {
		return {
			env: this.#deps.env,
			cryptoKeys: this.#deps.cryptoKeys,
			Settings: this.#deps.Settings,
			i18n: this.#deps.i18n,
		};
	}

	#getGrammarLanguage() {
		const bodyEl = this.#panelEl?.querySelector("#vh-rm-review-body");
		const titleEl = this.#panelEl?.querySelector("#vh-rm-review-title");
		const sample = `${titleEl?.value || ""}\n${bodyEl?.value || ""}`;
		const spellLang = detectSpellcheckLang(
			sample,
			this.#deps.Settings.get("i18n.localeOverride"),
			this.#deps.i18n.getCountryCode()
		);
		return toLanguageToolLang(spellLang);
	}

	#prepareGrammarSection() {
		if (!this.#grammarPanel) {
			this.#grammarPanel?.setVisible(false);
			return;
		}
		this.#grammarPanel.setVisible(true);
		this.#applyTier3Restrictions();
		if (this.#isTier3Member()) {
			this.#grammarPanel.setIdle(this.#msg("rmGrammarIdle", "Click “Check grammar” to analyze your review."));
		}
		this.#setGrammarCheckButtonBusy(false);
	}

	#isTier3Member() {
		return this.#deps.Settings.isPremiumUser(3);
	}

	#tier3UpgradeMessage() {
		return this.#msg("rmTier3UpgradeRequired", "Upgrade your membership to unlock this feature!");
	}

	#tier3FeatureLabel() {
		return this.#msg("rmTier3FeatureLabel", "Tier 3");
	}

	#setSuggestStatus(message, { locked = false, loading = false } = {}) {
		const panel = this.#panelEl?.querySelector("#vh-rm-ai-suggest");
		const status = this.#panelEl?.querySelector("#vh-rm-suggest-status");
		if (!panel || !status) {
			return;
		}
		panel.classList.toggle("vh-rm-ai--locked", locked);
		panel.classList.toggle("vh-rm-ai--checking", loading);
		status.textContent = message;
	}

	#applyTier3Restrictions() {
		const isTier3 = this.#isTier3Member();
		const upgradeMsg = this.#tier3UpgradeMessage();
		const vhPriceRow = this.#panelEl?.querySelector("#vh-rm-vh-price-row");
		const vhPriceEl = this.#panelEl?.querySelector("#vh-rm-vh-price");
		const aiPanel = this.#panelEl?.querySelector("#vh-rm-ai-suggest");
		const grammarWrap = this.#panelEl?.querySelector("#vh-rm-grammar");
		const suggestBtn = this.#panelEl?.querySelector("#vh-rm-suggest");
		const checkBtn = this.#panelEl?.querySelector("#vh-rm-grammar-check");

		if (!isTier3) {
			vhPriceRow?.classList.add("vh-rm-price-row--tier3-locked");
			if (vhPriceEl) {
				vhPriceEl.textContent = this.#tier3FeatureLabel();
			}
			aiPanel?.classList.add("vh-rm-tier3-locked");
			grammarWrap?.classList.add("vh-rm-tier3-locked");
			this.#setSuggestStatus(upgradeMsg, { locked: true });
			this.#renderSuggestTierPreview();
			suggestBtn?.setAttribute("disabled", "true");
			suggestBtn?.classList.add("vh-rm-tier3-disabled");
			suggestBtn?.setAttribute("title", upgradeMsg);
			suggestBtn?.setAttribute("aria-disabled", "true");
			checkBtn?.setAttribute("disabled", "true");
			checkBtn?.classList.add("vh-rm-tier3-disabled");
			checkBtn?.setAttribute("aria-disabled", "true");
			this.#grammarPanel?.setTierLocked(upgradeMsg);
			return;
		}

		vhPriceRow?.classList.remove("vh-rm-price-row--tier3-locked");
		aiPanel?.classList.remove("vh-rm-tier3-locked");
		grammarWrap?.classList.remove("vh-rm-tier3-locked");
		if (!this.#suggestInFlight) {
			this.#setSuggestStatus("");
			this.#renderSuggestions({
				evaluation: this.#selected?.suggestedEvaluation ?? null,
				topics: this.#selected?.suggestedTopics ?? [],
			});
		}
		suggestBtn?.classList.remove("vh-rm-tier3-disabled");
		suggestBtn?.removeAttribute("aria-disabled");
		suggestBtn?.removeAttribute("title");
		checkBtn?.classList.remove("vh-rm-tier3-disabled");
		checkBtn?.removeAttribute("aria-disabled");
		if (!this.#suggestInFlight) {
			suggestBtn?.removeAttribute("disabled");
		}
		if (!this.#grammarCheckInFlight) {
			checkBtn?.removeAttribute("disabled");
		}
	}

	async #runGrammarCheck() {
		if (!this.#grammarPanel || !this.#selected || this.#grammarCheckInFlight) {
			return;
		}
		if (!this.#isTier3Member()) {
			this.#grammarPanel.setTierLocked(this.#tier3UpgradeMessage());
			return;
		}
		const bodyEl = this.#panelEl?.querySelector("#vh-rm-review-body");
		if (!bodyEl) {
			return;
		}
		const text = bodyEl.value;
		const trimmed = text.trim();
		if (trimmed.length < GRAMMAR_CHECK_MIN_CHARS) {
			this.#grammarPanel.setVisible(true);
			this.#grammarPanel.setIdle(
				this.#msg("rmGrammarTooShort", "Write at least $1$ characters, then check grammar.", [
					String(GRAMMAR_CHECK_MIN_CHARS),
				])
			);
			return;
		}

		this.#grammarPanel.setVisible(true);
		this.#grammarCheckInFlight = true;
		this.#setGrammarCheckButtonBusy(true);
		this.#grammarPanel.setChecking();

		const language = this.#getGrammarLanguage();
		try {
			const result = await checkGrammar(this.#getGrammarApiDeps(), text, language);
			this.#applyTokenInfo({
				remaining: result.tokensRemaining,
				max: result.tokensMax,
			});
			const matches = normalizeGrammarMatches(result.matches);
			this.#grammarPanel.render(matches, text, bodyEl, () => {
				this.#scheduleAutosave();
			});
			this.#updateTokenMeter();
		} catch (err) {
			console.warn("[VHelper Review Manager] Grammar check failed:", err);
			if (err.status === 402) {
				alert(err.message);
				this.#grammarPanel.setIdle(this.#msg("rmGrammarIdle", "Click “Check grammar” to analyze your review."));
			} else {
				this.#grammarPanel.setError(this.#msg("rmGrammarError", "Grammar check is temporarily unavailable."));
			}
		} finally {
			this.#grammarCheckInFlight = false;
			this.#setGrammarCheckButtonBusy(false);
		}
	}

	#setGrammarCheckButtonBusy(busy) {
		const btn = this.#panelEl?.querySelector("#vh-rm-grammar-check");
		if (!btn) {
			return;
		}
		btn.disabled = busy;
		btn.classList.toggle("vh-rm-grammar-check-btn--busy", busy);
		btn.setAttribute("aria-busy", busy ? "true" : "false");
	}

	#resetGrammarUi() {
		this.#grammarCheckInFlight = false;
		this.#setGrammarCheckButtonBusy(false);
		this.#grammarPanel?.clear();
		this.#grammarPanel?.setVisible(false);
	}

	async open() {
		if (this.#closeAnimationTimer) {
			clearTimeout(this.#closeAnimationTimer);
			this.#closeAnimationTimer = null;
		}
		void this.#refreshTokenCosts();
		this.#panelEl?.classList.remove("vh-rm-closing");
		this.#fabEl?.classList.remove("vh-rm-fab-active");
		this.#fabEl?.classList.remove("vh-rm-fab-launching");
		void this.#fabEl?.offsetWidth;
		this.#panelEl?.classList.add("vh-rm-open");
		this.#fabEl?.classList.add("vh-rm-fab-launching");
		setTimeout(() => {
			this.#fabEl?.classList.add("vh-rm-fab-active");
			this.#fabEl?.classList.remove("vh-rm-fab-launching");
		}, 420);
		document.documentElement.style.overflow = "hidden";
		document.body.style.overflow = "hidden";
		const hasDir = await this.#storage.hasDirectory();
		this.#setFolderStatus(hasDir);
		if (!hasDir) {
			this.#showSetup();
		} else {
			this.#showMain();
			await this.#loadCachedReviewList();
		}
	}

	close() {
		if (!this.#panelEl?.classList.contains("vh-rm-open") || this.#panelEl.classList.contains("vh-rm-closing")) {
			return;
		}
		this.#resetGrammarUi();
		this.#revokeImageObjectUrls();
		this.#hideInsertOverlay();
		this.#hideSyncOverlay();
		this.#panelEl.classList.add("vh-rm-closing");
		this.#panelEl.classList.remove("vh-rm-open");
		this.#fabEl?.classList.remove("vh-rm-fab-launching", "vh-rm-fab-active");
		document.documentElement.style.overflow = "";
		document.body.style.overflow = "";
		if (this.#closeAnimationTimer) {
			clearTimeout(this.#closeAnimationTimer);
		}
		this.#closeAnimationTimer = setTimeout(() => {
			this.#closeAnimationTimer = null;
			this.#panelEl?.classList.remove("vh-rm-closing");
		}, 720);
	}

	async #pickFolder() {
		try {
			await this.#storage.pickDirectory();
			this.#setFolderStatus(true);
			this.#showMain();
			await this.#loadCachedReviewList();
		} catch (err) {
			if (err?.name === "AbortError") {
				return;
			}
			alert(err?.message || this.#msg("rmFolderAccessError", "Could not access the selected folder."));
		}
	}

	#setFolderStatus(ok) {
		const el = this.#panelEl?.querySelector("#vh-rm-folder-status");
		if (el) {
			el.textContent = ok
				? this.#msg("rmCacheFolderConnected", "Cache folder connected.")
				: this.#msg("rmCacheFolderNone", "No cache folder selected yet.");
		}
	}

	#showSetup() {
		this.#panelEl?.querySelector(".vh-rm-setup")?.classList.remove("vh-rm-hidden");
		this.#panelEl?.querySelector(".vh-rm-main")?.classList.add("vh-rm-hidden");
	}

	#showMain() {
		this.#panelEl?.querySelector(".vh-rm-setup")?.classList.add("vh-rm-hidden");
		this.#panelEl?.querySelector(".vh-rm-main")?.classList.remove("vh-rm-hidden");
		this.#panelEl?.querySelector(".vh-rm-list-view")?.classList.remove("vh-rm-hidden");
		this.#panelEl?.querySelector(".vh-rm-editor-view")?.classList.add("vh-rm-hidden");
	}

	async #refreshEvaluationPeriodStart() {
		let reevaluationDate = this.#deps.env?.getVoiceDetails?.("reevaluationDate");
		if (reevaluationDate == null) {
			try {
				const data = await chrome.storage.local.get(VVP_CONTEXT_STORAGE_KEY);
				reevaluationDate = data?.[VVP_CONTEXT_STORAGE_KEY]?.voiceDetails?.reevaluationDate;
			} catch {
				reevaluationDate = null;
			}
		}
		this.#evaluationPeriodStartMs = getEvaluationPeriodStartMs(reevaluationDate);
	}

	#isCurrentPeriodFilterEnabled() {
		return this.#deps.Settings.get("general.reviewManagerCurrentPeriodOnly", false);
	}

	#getVisibleReviews() {
		const sorted = [...this.#reviews].sort((a, b) => (b.orderDateMs || 0) - (a.orderDateMs || 0));
		if (!this.#isCurrentPeriodFilterEnabled() || this.#evaluationPeriodStartMs == null) {
			return sorted;
		}
		return sorted.filter((review) => isReviewInEvaluationPeriod(review, this.#evaluationPeriodStartMs));
	}

	#normalizeListReview(review) {
		const orderDateMs = review.orderDateMs ?? null;
		return {
			asin: review.asin,
			productTitle: review.productTitle ?? review.asin,
			productUrl: review.productUrl ?? `${getAmazonOrigin()}/dp/${review.asin}`,
			imageUrl: review.imageUrl ?? null,
			orderDateMs,
			reviewTitle: review.reviewTitle ?? "",
			reviewContent: review.reviewContent ?? "",
			updatedAt: review.updatedAt ?? null,
			isOverdue: orderDateMs ? Date.now() - orderDateMs > 30 * 24 * 60 * 60 * 1000 : false,
			archived: !!review.archived,
		};
	}

	#isArchivedTab() {
		return this.#activeListTab === "archived";
	}

	#isEditorReadOnly() {
		return !!this.#selected?.archived;
	}

	async #switchListTab(tab) {
		if (this.#activeListTab === tab) {
			return;
		}
		this.#activeListTab = tab;
		if (tab === "archived") {
			this.#archivedReviews = (await this.#storage.listArchivedReviews()).map((r) =>
				this.#normalizeListReview(r)
			);
		}
		this.#updateListTabUi();
		this.#renderList();
	}

	#setAwaitingSyncStatus(text) {
		this.#awaitingSyncStatusText = text;
		if (!this.#isArchivedTab()) {
			const status = this.#panelEl?.querySelector("#vh-rm-sync-status");
			if (status) {
				status.textContent = text;
			}
		}
	}

	#applyListTabSyncStatus() {
		const status = this.#panelEl?.querySelector("#vh-rm-sync-status");
		if (!status) {
			return;
		}
		if (this.#isArchivedTab()) {
			status.textContent = this.#msg("rmArchivedListCount", "$1$ archived review(s)", [
				String(this.#archivedReviews.length),
			]);
			return;
		}
		if (this.#awaitingSyncStatusText) {
			status.textContent = this.#awaitingSyncStatusText;
		}
	}

	#updateListTabUi() {
		const main = this.#panelEl?.querySelector(".vh-rm-main");
		const awaitingTab = this.#panelEl?.querySelector("#vh-rm-tab-awaiting");
		const archivedTab = this.#panelEl?.querySelector("#vh-rm-tab-archived");
		const isArchived = this.#isArchivedTab();
		main?.classList.toggle("vh-rm-main--archived-tab", isArchived);
		awaitingTab?.classList.toggle("vh-rm-list-tab--active", !isArchived);
		archivedTab?.classList.toggle("vh-rm-list-tab--active", isArchived);
		awaitingTab?.setAttribute("aria-selected", isArchived ? "false" : "true");
		archivedTab?.setAttribute("aria-selected", isArchived ? "true" : "false");
		this.#applyListTabSyncStatus();
	}

	#matchesListFilter(review) {
		const query = this.#listFilterQuery.trim().toLowerCase();
		if (!query) {
			return true;
		}
		const keywords = query.split(/\s+/).filter(Boolean);
		const haystack = [review.productTitle, review.asin, review.reviewTitle, review.reviewContent]
			.filter(Boolean)
			.join(" ")
			.toLowerCase();
		return keywords.every((keyword) => haystack.includes(keyword));
	}

	#getSourceReviews() {
		return this.#isArchivedTab() ? this.#archivedReviews : this.#reviews;
	}

	#getFilteredReviews() {
		const source = this.#getSourceReviews();
		if (this.#isArchivedTab()) {
			return [...source]
				.filter((review) => this.#matchesListFilter(review))
				.sort((a, b) => {
					const aMs = a.updatedAt ? Date.parse(a.updatedAt) : a.orderDateMs || 0;
					const bMs = b.updatedAt ? Date.parse(b.updatedAt) : b.orderDateMs || 0;
					return bMs - aMs;
				});
		}
		return this.#getVisibleReviews().filter((review) => this.#matchesListFilter(review));
	}

	async #loadCachedReviewList() {
		this.#showMain();
		await this.#refreshEvaluationPeriodStart();
		const cached = await this.#storage.loadPendingReviewList();
		if (cached && Array.isArray(cached.reviews)) {
			this.#reviews = cached.reviews.map((r) => this.#normalizeListReview(r));
			this.#listAwaitingSync = false;
			const when = cached.syncedAt
				? new Date(cached.syncedAt).toLocaleString()
				: this.#msg("rmListUnknownDate", "Unknown date");
			this.#setAwaitingSyncStatus(
				this.#msg("rmSyncListCached", "$1$ pending review(s) · last synced $2$", [
					String(this.#reviews.length),
					when,
				])
			);
			this.#renderList();
			return;
		}
		this.#reviews = [];
		this.#listAwaitingSync = true;
		this.#setAwaitingSyncStatus(this.#msg("rmSyncClickToLoad", 'Click "Sync from Vine" to load pending reviews'));
		this.#renderList();
	}

	async #syncReviews() {
		if (this.#syncInFlight) {
			return;
		}
		this.#syncInFlight = true;
		this.#showMain();
		this.#showList();
		const syncingMsg = this.#msg("rmSyncing", "Syncing reviews from Amazon…");
		this.#showSyncOverlay(syncingMsg);
		this.#setAwaitingSyncStatus(syncingMsg);
		try {
			const origin = getAmazonOrigin();
			const cached = await this.#storage.loadPendingReviewList();
			const previousAsins = Array.isArray(cached?.reviews)
				? cached.reviews.map((r) => r.asin).filter(Boolean)
				: [];
			const {
				reviews: fetched,
				complete,
				stopReason,
			} = await fetchAllPendingReviews(
				origin,
				(page, totalPages) => {
					const pageMsg =
						totalPages != null
							? this.#msg("rmSyncOverlayPageProgress", "Importing page $1$ of $2$…", [
									String(page),
									String(totalPages),
								])
							: this.#msg("rmSyncLoadingPage", "Loading page $1$…", [String(page)]);
					this.#setAwaitingSyncStatus(pageMsg);
					this.#updateSyncOverlay({
						message: syncingMsg,
						showProgress: totalPages != null,
						progress: totalPages != null ? (page / totalPages) * 100 : 0,
						progressLabel: pageMsg,
					});
				},
				(done, total) => {
					if (total > 0) {
						const titleMsg = this.#msg("rmSyncLoadingTitles", "Loading product titles $1$/$2$…", [
							String(done),
							String(total),
						]);
						this.#setAwaitingSyncStatus(titleMsg);
						this.#updateSyncOverlay({
							message: syncingMsg,
							showProgress: true,
							progress: (done / total) * 100,
							progressLabel: titleMsg,
						});
					}
				}
			);
			if (!complete) {
				this.#setAwaitingSyncStatus(
					this.#msg("rmSyncIncomplete", "Sync incomplete ($1$). List and folders were not updated.", [
						stopReason,
					])
				);
				this.#renderList();
				return;
			}
			this.#updateSyncOverlay({
				message: this.#msg("rmSyncOverlaySaving", "Saving reviews to cache folder…"),
				showProgress: true,
				progress: 100,
				progressLabel: "",
			});
			this.#reviews = fetched.map((r) => this.#normalizeListReview(r));
			for (const review of this.#reviews) {
				try {
					const saved = await this.#storage.loadReview(review.asin, review.productTitle);
					if (saved) {
						review.stars = saved.stars;
						review.reviewTitle = saved.reviewTitle;
						review.reviewContent = saved.reviewContent;
					}
					await this.#storage.saveReview({
						...review,
						stars: review.stars ?? 5,
						reviewTitle: review.reviewTitle ?? "",
						reviewContent: review.reviewContent ?? "",
					});
				} catch (saveErr) {
					console.warn("[VHelper Review Manager] Could not save review", review.asin, saveErr);
				}
			}
			await this.#storage.savePendingReviewList(this.#reviews);
			await this.#storage.archiveStaleReviews(
				this.#reviews.map((r) => r.asin),
				{
					previousActiveAsins: previousAsins,
				}
			);
			this.#listAwaitingSync = false;
			await this.#refreshEvaluationPeriodStart();
			this.#renderList();
			const when = new Date().toLocaleString();
			this.#setAwaitingSyncStatus(
				this.#msg("rmSyncDone", "$1$ pending review(s) synced · $2$", [String(this.#reviews.length), when])
			);
		} catch (err) {
			this.#setAwaitingSyncStatus(this.#msg("rmSyncFailed", "Sync failed: $1$", [err.message]));
			this.#renderList();
		} finally {
			this.#syncInFlight = false;
			this.#hideSyncOverlay();
		}
	}

	#renderList() {
		const list = this.#panelEl?.querySelector("#vh-rm-review-list");
		if (!list) {
			return;
		}
		this.#updateListTabUi();
		list.innerHTML = "";
		const source = this.#getSourceReviews();
		if (!source.length) {
			if (this.#isArchivedTab()) {
				list.innerHTML = `<p class="vh-rm-empty">${this.#escape(this.#msg("rmEmptyNoArchived", "No archived reviews found."))}</p>`;
			} else if (this.#listAwaitingSync) {
				const syncLabel = this.#escape(this.#msg("rmSyncFromVine", "Sync from Vine"));
				list.innerHTML = `<p class="vh-rm-empty">${this.#escape(this.#msg("rmEmptyNoCacheBefore", "No cached reviews yet. Click"))} <strong>${syncLabel}</strong> ${this.#escape(this.#msg("rmEmptyNoCacheAfter", "to load your pending review list."))}</p>`;
			} else {
				list.innerHTML = `<p class="vh-rm-empty">${this.#escape(this.#msg("rmEmptyNoPending", "No awaiting reviews found on this account."))}</p>`;
			}
			return;
		}
		const visible = this.#getFilteredReviews();
		if (!visible.length) {
			if (this.#listFilterQuery.trim()) {
				list.innerHTML = `<p class="vh-rm-empty">${this.#escape(this.#msg("rmEmptyNoFilterMatch", "No reviews match your search."))}</p>`;
				return;
			}
			if (this.#isArchivedTab()) {
				list.innerHTML = `<p class="vh-rm-empty">${this.#escape(this.#msg("rmEmptyNoArchived", "No archived reviews found."))}</p>`;
			} else {
				list.innerHTML = `<p class="vh-rm-empty">${this.#escape(this.#msg("rmEmptyNoCurrentPeriod", "No awaiting reviews from the current evaluation period."))}</p>`;
			}
			return;
		}
		for (const review of visible) {
			const row = document.createElement("button");
			row.type = "button";
			row.className = "vh-rm-list-item";
			if (!this.#isArchivedTab() && review.isOverdue) {
				row.classList.add("vh-rm-overdue");
			}
			const dateStr = review.orderDateMs
				? new Date(review.orderDateMs).toLocaleDateString()
				: this.#msg("rmListUnknownDate", "Unknown date");
			const displayTitle = isGenericProductTitle(review.productTitle, review.asin)
				? review.asin
				: review.productTitle;
			const dateLine = this.#isArchivedTab()
				? this.#escape(this.#msg("rmListOrdered", "Ordered: $1$", [dateStr]))
				: `${this.#escape(this.#msg("rmListOrdered", "Ordered: $1$", [dateStr]))}${review.isOverdue ? ` · <em>${this.#escape(this.#msg("rmListOverdue", "30+ days"))}</em>` : ""}`;
			row.innerHTML = `
				<img class="vh-rm-thumb" src="${review.imageUrl || ""}" alt="" />
				<div class="vh-rm-list-text">
					<strong>${this.#escape(displayTitle)}</strong>
					<span class="vh-rm-asin">${review.asin}</span>
					<span class="vh-rm-date">${dateLine}</span>
				</div>`;
			row.addEventListener("click", () => this.#openEditor(review));
			list.appendChild(row);
		}
	}

	async #openEditor(review) {
		this.#hideInsertOverlay();
		this.#editorAutosaveEnabled = false;
		const readOnly = !!review.archived;
		if (!readOnly && isGenericProductTitle(review.productTitle, review.asin)) {
			const title = await fetchProductTitleFromDp(getAmazonOrigin(), review.asin);
			if (title) {
				review.productTitle = title;
			}
		}
		this.#selected = { ...review };
		const editorView = this.#panelEl?.querySelector(".vh-rm-editor-view");
		this.#panelEl?.querySelector(".vh-rm-list-view")?.classList.add("vh-rm-hidden");
		editorView?.classList.remove("vh-rm-hidden");
		this.#applyEditorReadOnlyMode(readOnly);
		this.#applyGrammarCollapsed(this.#deps.Settings.get("general.reviewManagerGrammarCollapsed", false));
		this.#applyAiCollapsed(readOnly ? true : this.#deps.Settings.get("general.reviewManagerAiCollapsed", false));

		const saved = await this.#storage.loadReview(review.asin, review.productTitle, { archived: readOnly });
		const stars = saved?.stars ?? 5;
		this.#setStars(stars, false);
		const titleEl = this.#panelEl.querySelector("#vh-rm-review-title");
		const bodyEl = this.#panelEl.querySelector("#vh-rm-review-body");
		if (titleEl) {
			titleEl.value = saved?.reviewTitle ?? "";
		}
		if (bodyEl) {
			bodyEl.value = saved?.reviewContent ?? "";
		}

		const headingLink = this.#panelEl.querySelector("#vh-rm-editor-heading-link");
		if (headingLink) {
			headingLink.href = review.productUrl ?? `${getAmazonOrigin()}/dp/${review.asin}`;
			headingLink.textContent = review.productTitle;
		}

		const cachedTopics = normalizeSuggestedTopics(saved?.suggestedTopics);
		const cachedEvaluation = normalizeSuggestedEvaluation(saved?.suggestedEvaluation);
		const cachedSuggestions = parseAiSuggestions({
			evaluation: cachedEvaluation,
			topics: cachedTopics,
		});
		this.#selected.suggestedTopics = cachedSuggestions.topics;
		this.#selected.suggestedEvaluation = cachedSuggestions.evaluation;
		if (!readOnly && this.#isTier3Member()) {
			this.#renderSuggestions(cachedSuggestions);
		}

		const hasCachedDescription =
			typeof saved?.productDescription === "string" && saved.productDescription.length > 0;
		const hasCachedVhPrice = this.#hasValidCachedVhPrice(saved);
		const hasCachedCurrentPrice = saved != null && Object.prototype.hasOwnProperty.call(saved, "currentPrice");

		this.#productDescription = hasCachedDescription ? saved.productDescription : "";
		if (readOnly) {
			this.#setPriceDisplays(
				hasCachedVhPrice ? this.#formatVhPrice(saved.vhPrice) : this.#msg("rmPriceNa", "n/a"),
				hasCachedCurrentPrice ? this.#formatCurrentPrice(saved.currentPrice) : this.#msg("rmPriceNa", "n/a")
			);
		} else if (this.#isTier3Member()) {
			this.#setPriceDisplays(
				hasCachedVhPrice ? this.#formatVhPrice(saved.vhPrice) : this.#msg("rmLoading", "…"),
				hasCachedCurrentPrice ? this.#formatCurrentPrice(saved.currentPrice) : this.#msg("rmLoading", "…")
			);
			void this.#loadVhPrice(review.asin, saved);
		} else {
			this.#setPriceDisplays(
				this.#tier3FeatureLabel(),
				hasCachedCurrentPrice ? this.#formatCurrentPrice(saved.currentPrice) : this.#msg("rmLoading", "…")
			);
		}
		if (!readOnly && (!hasCachedDescription || !hasCachedCurrentPrice)) {
			void this.#loadProductPage(review.productUrl);
		}
		this.#renderImageList();
		if (!readOnly && this.#isTier3Member()) {
			this.#updateTokenMeter();
			await this.#refreshTokens();
		} else {
			this.#updateTokenMeter();
		}
		this.#editorAutosaveEnabled = !readOnly;
		if (!readOnly) {
			this.#applyTier3Restrictions();
			this.#prepareGrammarSection();
		} else {
			this.#resetGrammarUi();
		}
	}

	#applyEditorReadOnlyMode(readOnly) {
		const editorView = this.#panelEl?.querySelector(".vh-rm-editor-view");
		const titleEl = this.#panelEl?.querySelector("#vh-rm-review-title");
		const bodyEl = this.#panelEl?.querySelector("#vh-rm-review-body");
		editorView?.classList.toggle("vh-rm-editor-view--readonly", readOnly);
		if (titleEl) {
			titleEl.readOnly = readOnly;
		}
		if (bodyEl) {
			bodyEl.readOnly = readOnly;
		}
		this.#panelEl?.querySelectorAll(".vh-rm-star").forEach((btn) => {
			btn.disabled = readOnly;
		});
	}

	#setPriceDisplays(vhPriceText, currentPriceText) {
		const vhEl = this.#panelEl?.querySelector("#vh-rm-vh-price");
		const currentEl = this.#panelEl?.querySelector("#vh-rm-current-price");
		if (vhEl && vhPriceText !== undefined) {
			vhEl.textContent = vhPriceText;
		}
		if (currentEl && currentPriceText !== undefined) {
			currentEl.textContent = currentPriceText;
		}
	}

	#formatVhPrice(price) {
		if (price == null || price === "" || Number.isNaN(Number(price))) {
			return this.#msg("rmPriceNa", "n/a");
		}
		try {
			return new Intl.NumberFormat(this.#deps.i18n.getLocale(), {
				style: "currency",
				currency: this.#deps.i18n.getCurrency(),
			}).format(Number(price));
		} catch {
			return String(price);
		}
	}

	#formatCurrentPrice(priceText) {
		const text = typeof priceText === "string" ? priceText.trim() : "";
		return text || this.#msg("rmPriceNa", "n/a");
	}

	#getVhPriceFromPage(asin) {
		const tile = this.#deps.page?.getTileByASIN?.(asin);
		const price = tile?.getItem?.()?.data?.price;
		return price != null && price !== "" ? price : null;
	}

	async #loadVhPrice(asin, saved) {
		const vhEl = this.#panelEl?.querySelector("#vh-rm-vh-price");
		if (!this.#isTier3Member()) {
			if (vhEl && !this.#hasValidCachedVhPrice(saved)) {
				vhEl.textContent = this.#msg("rmPriceNa", "n/a");
			}
			return;
		}
		if (!this.#hasValidCachedVhPrice(saved) && vhEl) {
			vhEl.textContent = this.#msg("rmLoading", "…");
		}
		const tilePrice = this.#getVhPriceFromPage(asin);
		if (tilePrice != null) {
			if (vhEl) {
				vhEl.textContent = this.#formatVhPrice(tilePrice);
			}
			await this.#persistReviewFields({ vhPrice: tilePrice });
			return;
		}
		try {
			const price = await fetchVhProductPrice(
				{
					env: this.#deps.env,
					cryptoKeys: this.#deps.cryptoKeys,
					Settings: this.#deps.Settings,
					i18n: this.#deps.i18n,
				},
				asin
			);
			if (vhEl) {
				vhEl.textContent = this.#formatVhPrice(price);
			}
			await this.#persistReviewFields({ vhPrice: price ?? null });
		} catch (err) {
			console.warn("[VHelper Review Manager] Could not load VH price", err);
			if (vhEl) {
				vhEl.textContent = this.#msg("rmPriceNa", "n/a");
			}
		}
	}

	async #loadProductPage(productUrl) {
		const currentEl = this.#panelEl?.querySelector("#vh-rm-current-price");
		if (currentEl) {
			currentEl.textContent = this.#msg("rmLoading", "…");
		}
		try {
			const { description, currentPrice } = await fetchProductPageData(productUrl);
			this.#productDescription = description;
			const currentPriceValue = currentPrice?.trim() ? currentPrice.trim() : null;
			if (currentEl) {
				currentEl.textContent = this.#formatCurrentPrice(currentPrice);
			}
			await this.#persistReviewFields({
				productDescription: description,
				currentPrice: currentPriceValue,
			});
		} catch {
			this.#productDescription = "";
			if (currentEl) {
				currentEl.textContent = this.#msg("rmPriceNa", "n/a");
			}
			await this.#persistReviewFields({
				productDescription: "",
				currentPrice: null,
			});
		}
	}

	#showList() {
		this.#editorAutosaveEnabled = false;
		if (this.#autosaveTimer) {
			clearTimeout(this.#autosaveTimer);
			this.#autosaveTimer = null;
		}
		this.#resetGrammarUi();
		this.#revokeImageObjectUrls();
		this.#selected = null;
		this.#hideInsertOverlay();
		this.#applyEditorReadOnlyMode(false);
		this.#panelEl?.querySelector(".vh-rm-list-view")?.classList.remove("vh-rm-hidden");
		this.#panelEl?.querySelector(".vh-rm-editor-view")?.classList.add("vh-rm-hidden");
		if (this.#isArchivedTab()) {
			void this.#refreshArchivedList();
		}
	}

	async #refreshArchivedList() {
		this.#archivedReviews = (await this.#storage.listArchivedReviews()).map((r) => this.#normalizeListReview(r));
		this.#renderList();
	}

	#showInsertOverlay() {
		const overlay = this.#panelEl?.querySelector("#vh-rm-insert-overlay");
		if (!overlay) {
			return;
		}
		overlay.classList.remove("vh-rm-hidden");
		overlay.setAttribute("aria-hidden", "false");
	}

	#showSyncOverlay(message) {
		const overlay = this.#panelEl?.querySelector("#vh-rm-sync-overlay");
		if (!overlay) {
			return;
		}
		overlay.classList.remove("vh-rm-hidden");
		overlay.setAttribute("aria-hidden", "false");
		this.#panelEl?.querySelectorAll("#vh-rm-sync").forEach((btn) => {
			btn.disabled = true;
			btn.setAttribute("aria-disabled", "true");
		});
		this.#updateSyncOverlay({
			message,
			showProgress: false,
			progress: 0,
			progressLabel: "",
		});
	}

	#hideSyncOverlay() {
		const overlay = this.#panelEl?.querySelector("#vh-rm-sync-overlay");
		if (!overlay) {
			return;
		}
		overlay.classList.add("vh-rm-hidden");
		overlay.setAttribute("aria-hidden", "true");
		this.#panelEl?.querySelectorAll("#vh-rm-sync").forEach((btn) => {
			btn.disabled = false;
			btn.removeAttribute("aria-disabled");
		});
	}

	#updateSyncOverlay({ message, showProgress = false, progress = 0, progressLabel = "" } = {}) {
		const overlay = this.#panelEl?.querySelector("#vh-rm-sync-overlay");
		if (!overlay) {
			return;
		}
		const messageEl = overlay.querySelector("#vh-rm-sync-overlay-message");
		const progressWrap = overlay.querySelector("#vh-rm-sync-overlay-progress");
		const progressFill = overlay.querySelector("#vh-rm-sync-overlay-progress-fill");
		const progressLabelEl = overlay.querySelector("#vh-rm-sync-overlay-progress-label");
		if (messageEl && message != null) {
			messageEl.textContent = message;
		}
		if (progressWrap) {
			progressWrap.classList.toggle("vh-rm-hidden", !showProgress);
			progressWrap.setAttribute("aria-hidden", showProgress ? "false" : "true");
		}
		if (progressFill) {
			progressFill.style.width = `${Math.min(100, Math.max(0, progress))}%`;
		}
		if (progressLabelEl) {
			progressLabelEl.textContent = progressLabel;
		}
	}

	#hideInsertOverlay() {
		const overlay = this.#panelEl?.querySelector("#vh-rm-insert-overlay");
		if (!overlay) {
			return;
		}
		overlay.classList.add("vh-rm-hidden");
		overlay.setAttribute("aria-hidden", "true");
	}

	#setStars(n, autosave = true) {
		if (!this.#selected || (autosave && this.#isEditorReadOnly())) {
			return;
		}
		this.#selected.stars = n;
		this.#panelEl?.querySelectorAll(".vh-rm-star").forEach((btn) => {
			const v = Number(btn.dataset.stars);
			btn.classList.toggle("vh-rm-star-active", v <= n);
			btn.setAttribute("aria-pressed", v <= n ? "true" : "false");
		});
		if (autosave) {
			this.#scheduleAutosave();
		}
	}

	#scheduleAutosave() {
		if (!this.#editorAutosaveEnabled || !this.#selected || this.#isEditorReadOnly()) {
			return;
		}
		if (this.#autosaveTimer) {
			clearTimeout(this.#autosaveTimer);
		}
		this.#autosaveTimer = setTimeout(() => {
			this.#autosaveTimer = null;
			void this.#saveEditor();
		}, 400);
	}

	async #saveEditor() {
		if (!this.#selected || this.#isEditorReadOnly()) {
			return;
		}
		const titleEl = this.#panelEl.querySelector("#vh-rm-review-title");
		const bodyEl = this.#panelEl.querySelector("#vh-rm-review-body");
		const payload = {
			...this.#selected,
			reviewTitle: titleEl?.value ?? "",
			reviewContent: bodyEl?.value ?? "",
			stars: this.#selected.stars ?? 5,
		};
		await this.#storage.saveReview(payload);
		const idx = this.#reviews.findIndex((r) => r.asin === payload.asin);
		if (idx >= 0) {
			this.#reviews[idx] = { ...this.#reviews[idx], ...payload };
		}
		this.#flashAutosaveStatus();
	}

	#flashAutosaveStatus() {
		const msg = this.#panelEl?.querySelector("#vh-rm-save-status");
		if (!msg) {
			return;
		}
		msg.textContent = this.#msg("rmSavedToFolder", "Saved to folder");
		setTimeout(() => {
			msg.textContent = "";
		}, 2000);
	}

	async #uploadImages(fileList) {
		if (!this.#selected || !fileList?.length || this.#isEditorReadOnly()) {
			return;
		}
		await this.#storage.addImageFiles(this.#selected.asin, this.#selected.productTitle, Array.from(fileList));
		await this.#renderImageList();
		this.#flashAutosaveStatus();
	}

	#revokeImageObjectUrls() {
		for (const url of this.#imageObjectUrls) {
			URL.revokeObjectURL(url);
		}
		this.#imageObjectUrls.clear();
	}

	#bindImageListDragDrop(panel) {
		const ul = panel.querySelector("#vh-rm-image-list");
		if (!ul || ul.dataset.dragBound === "1") {
			return;
		}
		ul.dataset.dragBound = "1";

		const clearDropMarkers = () => {
			ul.querySelectorAll(".vh-rm-image-item--drop-before, .vh-rm-image-item--drop-after").forEach((el) => {
				el.classList.remove("vh-rm-image-item--drop-before", "vh-rm-image-item--drop-after");
			});
		};

		ul.addEventListener("dragstart", (e) => {
			if (e.target.closest(".vh-rm-delete-image")) {
				e.preventDefault();
				return;
			}
			const item = e.target.closest(".vh-rm-image-item[data-file-name]");
			if (!item) {
				e.preventDefault();
				return;
			}
			this.#imageDragName = item.dataset.fileName;
			e.dataTransfer.effectAllowed = "move";
			e.dataTransfer.setData("text/plain", this.#imageDragName);
			item.classList.add("vh-rm-image-item--dragging");
		});

		ul.addEventListener("dragend", () => {
			this.#imageDragName = null;
			clearDropMarkers();
			ul.querySelectorAll(".vh-rm-image-item--dragging").forEach((el) => {
				el.classList.remove("vh-rm-image-item--dragging");
			});
		});

		ul.addEventListener("dragover", (e) => {
			if (!this.#imageDragName) {
				return;
			}
			e.preventDefault();
			e.dataTransfer.dropEffect = "move";
			const item = e.target.closest(".vh-rm-image-item[data-file-name]");
			clearDropMarkers();
			if (!item || item.dataset.fileName === this.#imageDragName) {
				return;
			}
			const rect = item.getBoundingClientRect();
			const before = e.clientX < rect.left + rect.width / 2;
			item.classList.add(before ? "vh-rm-image-item--drop-before" : "vh-rm-image-item--drop-after");
		});

		ul.addEventListener("dragleave", (e) => {
			if (!ul.contains(e.relatedTarget)) {
				clearDropMarkers();
			}
		});

		ul.addEventListener("drop", async (e) => {
			e.preventDefault();
			const draggedName = this.#imageDragName || e.dataTransfer.getData("text/plain");
			const target = e.target.closest(".vh-rm-image-item[data-file-name]");
			clearDropMarkers();
			this.#imageDragName = null;
			if (!draggedName || !target || !this.#selected) {
				return;
			}
			const targetName = target.dataset.fileName;
			if (draggedName === targetName) {
				return;
			}
			const names = [...ul.querySelectorAll(".vh-rm-image-item[data-file-name]")].map(
				(li) => li.dataset.fileName
			);
			const fromIndex = names.indexOf(draggedName);
			let toIndex = names.indexOf(targetName);
			if (fromIndex < 0 || toIndex < 0) {
				return;
			}
			const rect = target.getBoundingClientRect();
			const insertAfter = e.clientX >= rect.left + rect.width / 2;
			if (insertAfter) {
				toIndex += 1;
			}
			if (fromIndex < toIndex) {
				toIndex -= 1;
			}
			const reordered = reorderImageNames(names, fromIndex, toIndex);
			await this.#storage.setImageOrder(this.#selected.asin, this.#selected.productTitle, reordered);
			await this.#renderImageList();
			this.#flashAutosaveStatus();
		});
	}

	async #renderImageList() {
		const ul = this.#panelEl?.querySelector("#vh-rm-image-list");
		if (!ul || !this.#selected) {
			return;
		}
		const readOnly = this.#isEditorReadOnly();
		this.#revokeImageObjectUrls();
		ul.innerHTML = "";
		const files = await this.#storage.listImages(this.#selected.asin, this.#selected.productTitle, {
			archived: readOnly,
		});
		if (!files.length) {
			const emptyMsg = readOnly
				? this.#msg("rmNoImagesArchived", "No images in this archived review.")
				: this.#msg("rmNoImages", "No images yet — upload or copy files into the images folder");
			ul.innerHTML = `<li class="vh-rm-muted">${this.#escape(emptyMsg)}</li>`;
			return;
		}
		const dragTitle = this.#msg("rmImageDragTitle", "Drag to reorder");
		for (const { name, handle } of files) {
			const li = document.createElement("li");
			li.className = "vh-rm-image-item";
			li.draggable = !readOnly;
			li.dataset.fileName = name;
			if (!readOnly) {
				li.title = dragTitle;
			}

			const card = document.createElement("div");
			card.className = "vh-rm-image-card";
			card.title = name;

			try {
				const file = await handle.getFile();
				if (isImageMedia(file, name)) {
					const url = URL.createObjectURL(file);
					this.#imageObjectUrls.add(url);
					const img = document.createElement("img");
					img.className = "vh-rm-image-thumb";
					img.src = url;
					img.alt = name;
					img.title = name;
					img.loading = "lazy";
					card.appendChild(img);
				} else {
					const placeholder = document.createElement("span");
					placeholder.className = "vh-rm-image-thumb vh-rm-image-thumb--video";
					placeholder.setAttribute("aria-hidden", "true");
					placeholder.title = name;
					placeholder.textContent = "▶";
					card.appendChild(placeholder);
				}
			} catch {
				// omit thumbnail when the file cannot be read
			}

			if (!readOnly) {
				const delBtn = document.createElement("button");
				delBtn.type = "button";
				delBtn.className = "vh-rm-delete-image";
				delBtn.textContent = "×";
				delBtn.setAttribute("aria-label", this.#msg("rmDeleteImageAria", "Delete $1$", [name]));
				delBtn.addEventListener("click", (e) => {
					e.stopPropagation();
					this.#deleteImage(name);
				});
				card.appendChild(delBtn);
			}
			li.appendChild(card);
			ul.appendChild(li);
		}
	}

	async #deleteImage(fileName) {
		if (!this.#selected || !fileName) {
			return;
		}
		const confirmed = confirm(
			this.#msg("rmDeleteImageConfirm", 'Delete "$1$" from this review folder?', [fileName])
		);
		if (!confirmed) {
			return;
		}
		try {
			await this.#storage.deleteImage(this.#selected.asin, this.#selected.productTitle, fileName);
			await this.#renderImageList();
			this.#flashAutosaveStatus();
		} catch (err) {
			alert(err?.message || this.#msg("rmDeleteImageFailed", "Could not delete the image."));
		}
	}

	#applyTokenInfo(info) {
		if (info?.max != null) {
			this.#tokensMax = info.max;
			this.#deps.env.data.tokensMax = info.max;
		}
		if (info?.remaining != null) {
			this.#tokens = info.remaining;
			this.#deps.env.data.tokens = info.remaining;
		}
	}

	#getTokenMax() {
		if (this.#tokensMax != null && this.#tokensMax > 0) {
			return this.#tokensMax;
		}
		const envMax = this.#deps.env?.data?.tokensMax;
		if (typeof envMax === "number" && envMax > 0) {
			return envMax;
		}
		if (typeof envMax === "string" && envMax.trim() !== "") {
			const n = Number(envMax);
			if (!Number.isNaN(n) && n > 0) {
				return n;
			}
		}
		return null;
	}

	#setTokenMeterTooltip(wrap, pctEl, text) {
		if (wrap) {
			if (text) {
				wrap.setAttribute("title", text);
			} else {
				wrap.removeAttribute("title");
			}
		}
		if (pctEl) {
			if (text) {
				pctEl.setAttribute("title", text);
			} else {
				pctEl.removeAttribute("title");
			}
		}
	}

	async #refreshTokenCosts() {
		try {
			const costs = await fetchTokenCosts({
				env: this.#deps.env,
				cryptoKeys: this.#deps.cryptoKeys,
				Settings: this.#deps.Settings,
				i18n: this.#deps.i18n,
			});
			if (costs.grammar != null) {
				this.#tokenCosts.grammar = costs.grammar;
			}
			if (costs.suggest != null) {
				this.#tokenCosts.suggest = costs.suggest;
			}
		} catch (err) {
			console.warn("[VHelper Review Manager] Could not load token costs", err);
		}
		this.#updateTokenCostButtons();
	}

	#updateTokenCostButtons() {
		const grammarCost = this.#tokenCosts.grammar;
		const suggestCost = this.#tokenCosts.suggest;
		const checkBtn = this.#panelEl?.querySelector("#vh-rm-grammar-check");
		const suggestBtn = this.#panelEl?.querySelector("#vh-rm-suggest");
		if (checkBtn) {
			const grammarKey = grammarCost === 1 ? "rmGrammarCheckButton" : "rmGrammarCheckButtonPlural";
			const grammarFallback = grammarCost === 1 ? "Check grammar ($1$ token)" : "Check grammar ($1$ tokens)";
			checkBtn.textContent = this.#msg(grammarKey, grammarFallback, [String(grammarCost)]);
		}
		if (suggestBtn) {
			suggestBtn.textContent = this.#msg("rmSuggestTopics", "Analyze review ($1$ tokens)", [String(suggestCost)]);
		}
	}

	async #refreshTokens() {
		if (!this.#isTier3Member()) {
			this.#updateTokenMeter();
			return;
		}
		try {
			const info = await fetchTokenBalance({
				env: this.#deps.env,
				cryptoKeys: this.#deps.cryptoKeys,
				Settings: this.#deps.Settings,
				i18n: this.#deps.i18n,
			});
			this.#applyTokenInfo(info);
		} catch (err) {
			console.warn("[VHelper Review Manager] Could not load token balance", err);
		}
		this.#updateTokenMeter();
	}

	#updateTokenMeter() {
		const wrap = this.#panelEl?.querySelector("#vh-rm-token-meter-wrap");
		const meter = this.#panelEl?.querySelector("#vh-rm-token-meter");
		const fill = this.#panelEl?.querySelector("#vh-rm-token-meter-fill");
		const pctEl = this.#panelEl?.querySelector("#vh-rm-token-usage-pct");
		if (!meter || !fill) {
			this.#applyTier3Restrictions();
			return;
		}
		if (!this.#isTier3Member()) {
			wrap?.classList.add("vh-rm-hidden");
			meter.removeAttribute("title");
			this.#setTokenMeterTooltip(wrap, pctEl, "");
			if (pctEl) {
				pctEl.textContent = "";
			}
			this.#applyTier3Restrictions();
			return;
		}
		this.#applyTier3Restrictions();
		wrap?.classList.remove("vh-rm-hidden");
		meter.removeAttribute("title");
		const remaining =
			this.#tokens != null
				? this.#tokens
				: typeof this.#deps.env?.data?.tokens === "number"
					? this.#deps.env.data.tokens
					: null;
		const max = this.#getTokenMax();
		if (remaining == null || max == null) {
			fill.style.width = "0%";
			meter.setAttribute("aria-valuenow", "0");
			meter.setAttribute("aria-valuemax", max != null ? String(max) : "0");
			if (pctEl) {
				pctEl.textContent = this.#msg("rmLoading", "…");
			}
			this.#setTokenMeterTooltip(wrap, pctEl, this.#msg("rmAiTokensLoading", "Loading AI token usage…"));
			meter.classList.remove("vh-rm-token-meter-low", "vh-rm-token-meter-empty");
			return;
		}
		const remainingClamped = Math.max(0, Math.min(max, remaining));
		const used = max - remainingClamped;
		const usagePct = max > 0 ? Math.round((used / max) * 100) : 0;
		const tooltip = this.#msg("rmAiTokensUsed", "$1$/$2$ tokens used", [String(used), String(max)]);
		fill.style.width = `${usagePct}%`;
		meter.setAttribute("aria-valuenow", String(used));
		meter.setAttribute("aria-valuemax", String(max));
		this.#setTokenMeterTooltip(wrap, pctEl, tooltip);
		if (pctEl) {
			pctEl.textContent = this.#msg("rmAiTokensUsagePct", "$1$%", [String(usagePct)]);
		}
		meter.classList.toggle("vh-rm-token-meter-empty", remainingClamped === 0);
		meter.classList.toggle(
			"vh-rm-token-meter-low",
			remainingClamped > 0 && remainingClamped <= Math.ceil(max * 0.2)
		);
	}

	#setSuggestLoading(loading) {
		const btn = this.#panelEl?.querySelector("#vh-rm-suggest");
		const panel = this.#panelEl?.querySelector("#vh-rm-ai-suggest");
		if (btn) {
			btn.disabled = loading;
			btn.classList.toggle("vh-rm-suggest-btn--busy", loading);
			btn.setAttribute("aria-busy", loading ? "true" : "false");
		}
		if (loading) {
			this.#setSuggestStatus(this.#msg("rmSuggestLoading", "Generating suggestions…"), { loading: true });
		} else if (this.#isTier3Member()) {
			this.#setSuggestStatus("");
		}
		panel?.classList.toggle("vh-rm-ai--checking", loading);
	}

	async #persistReviewFields(fields) {
		if (!this.#selected) {
			return;
		}
		await this.#storage.saveReview({
			...this.#selected,
			reviewTitle: this.#panelEl.querySelector("#vh-rm-review-title")?.value ?? "",
			reviewContent: this.#panelEl.querySelector("#vh-rm-review-body")?.value ?? "",
			stars: this.#selected.stars ?? 5,
			...fields,
		});
	}

	async #persistSuggestions({ evaluation, topics }) {
		const normalizedTopics = normalizeSuggestedTopics(topics);
		const normalizedEvaluation = normalizeSuggestedEvaluation(evaluation);
		this.#selected.suggestedTopics = normalizedTopics;
		this.#selected.suggestedEvaluation = normalizedEvaluation;
		await this.#persistReviewFields({
			suggestedTopics: normalizedTopics,
			suggestedEvaluation: normalizedEvaluation,
		});
	}

	async #runSuggest() {
		if (this.#suggestInFlight) {
			return;
		}
		if (!this.#isTier3Member()) {
			return;
		}
		if (!this.#selected) {
			return;
		}
		if (!this.#productDescription) {
			alert(this.#msg("rmSuggestWaitDescAlert", "Product description is still loading. Please wait a moment."));
			return;
		}
		const bodyEl = this.#panelEl.querySelector("#vh-rm-review-body");
		this.#suggestInFlight = true;
		this.#setSuggestLoading(true);
		const container = this.#panelEl?.querySelector("#vh-rm-suggestions");
		if (container) {
			container.replaceChildren();
		}
		try {
			const result = await suggestTopics({
				env: this.#deps.env,
				cryptoKeys: this.#deps.cryptoKeys,
				Settings: this.#deps.Settings,
				i18n: this.#deps.i18n,
				asin: this.#selected.asin,
				reviewText: bodyEl?.value ?? "",
				productDescription: this.#productDescription,
			});
			this.#applyTokenInfo({
				remaining: result.tokensRemaining,
				max: result.tokensMax,
			});
			const suggestions = parseAiSuggestions({
				evaluation: result.evaluation,
				topics: result.topics,
			});
			this.#renderSuggestions(suggestions);
			await this.#persistSuggestions(suggestions);
			this.#updateTokenMeter();
		} catch (err) {
			alert(err.message);
			this.#renderSuggestions({
				evaluation: this.#selected.suggestedEvaluation ?? null,
				topics: this.#selected.suggestedTopics ?? [],
			});
		} finally {
			this.#suggestInFlight = false;
			this.#setSuggestLoading(false);
			this.#updateTokenMeter();
		}
	}

	#renderSuggestTierPreview() {
		const evaluation = {
			result: this.#msg("rmSuggestPreviewResult", "🟢 Good start — keep building on your draft"),
			recommendations: [
				this.#msg("rmSuggestPreviewRec1", "Add a specific example from daily use."),
				this.#msg("rmSuggestPreviewRec2", "Mention how it compares to similar products you have tried."),
			],
		};
		const topics = [
			this.#msg("rmSuggestPreviewTopic1", "How easy is it to set up and use day to day?"),
			this.#msg("rmSuggestPreviewTopic2", "Does the build quality feel durable over time?"),
		];
		this.#renderSuggestions({ evaluation, topics }, { preview: true });
	}

	#normalizeSuggestionsInput(suggestions) {
		return parseAiSuggestions(suggestions);
	}

	#createSuggestAccordionSection(title, bodyId, buildBody, { headerSuffix = "", preview = false } = {}) {
		const section = document.createElement("div");
		section.className = "vh-rm-suggest-section vh-rm-collapsible";

		const head = document.createElement("div");
		head.className = "vh-rm-collapsible-head vh-rm-suggest-section-head";

		const toggle = document.createElement("button");
		toggle.type = "button";
		toggle.className = "vh-rm-collapsible-toggle";
		toggle.setAttribute("aria-expanded", "true");
		toggle.setAttribute("aria-controls", bodyId);

		const chevron = document.createElement("span");
		chevron.className = "vh-rm-collapsible-chevron";
		chevron.setAttribute("aria-hidden", "true");

		const heading = document.createElement("span");
		heading.className = "vh-rm-suggest-section-title vh-rm-feature-heading";
		heading.textContent = title;

		toggle.append(chevron, heading);
		head.appendChild(toggle);

		if (headerSuffix) {
			const resultEl = document.createElement("span");
			resultEl.className = "vh-rm-suggest-result-inline";
			resultEl.textContent = headerSuffix;
			if (preview) {
				resultEl.setAttribute("aria-hidden", "true");
			}
			head.appendChild(resultEl);
		}

		const body = document.createElement("div");
		body.id = bodyId;
		body.className = "vh-rm-collapsible-body vh-rm-suggest-section-body";
		buildBody(body);

		section.append(head, body);
		return section;
	}

	#renderSuggestionList(body, items, { preview = false } = {}) {
		const list = document.createElement("ul");
		list.className = "vh-rm-suggest-list";
		for (const item of items) {
			const li = document.createElement("li");
			li.textContent = item;
			if (preview) {
				li.setAttribute("aria-hidden", "true");
			}
			list.appendChild(li);
		}
		body.appendChild(list);
	}

	#renderSuggestions(suggestions, { preview = false } = {}) {
		const container = this.#panelEl?.querySelector("#vh-rm-suggestions");
		if (!container) {
			return;
		}
		container.classList.remove("vh-rm-tier3-preview");
		container.replaceChildren();

		const { evaluation, topics } = this.#normalizeSuggestionsInput(suggestions);
		const hasEvaluation = !!(evaluation?.result || evaluation?.recommendations?.length);
		const hasTopics = topics.length > 0;
		if (!hasEvaluation && !hasTopics) {
			return;
		}

		if (hasEvaluation) {
			container.appendChild(
				this.#createSuggestAccordionSection(
					this.#msg("rmAiFeedback", "Feedback"),
					"vh-rm-suggest-feedback-body",
					(body) => {
						if (evaluation.recommendations?.length) {
							this.#renderSuggestionList(body, evaluation.recommendations, { preview });
						}
					},
					{ headerSuffix: evaluation.result || "", preview }
				)
			);
		}

		if (hasTopics) {
			container.appendChild(
				this.#createSuggestAccordionSection(
					this.#msg("rmAiSuggestedTopics", "Suggested topics"),
					"vh-rm-suggest-topics-body",
					(body) => this.#renderSuggestionList(body, topics, { preview })
				)
			);
		}

		if (preview) {
			container.classList.add("vh-rm-tier3-preview");
		}
	}

	#collectImageNamesFromEditor() {
		const ul = this.#panelEl?.querySelector("#vh-rm-image-list");
		if (!ul) {
			return [];
		}
		return [...ul.querySelectorAll(".vh-rm-image-item[data-file-name]")]
			.map((li) => li.dataset.fileName)
			.filter(Boolean);
	}

	async #insertOnAmazon() {
		if (!this.#selected || this.#isEditorReadOnly()) {
			return;
		}
		if (this.#autosaveTimer) {
			clearTimeout(this.#autosaveTimer);
			this.#autosaveTimer = null;
		}
		await this.#saveEditor();
		const titleEl = this.#panelEl.querySelector("#vh-rm-review-title");
		const bodyEl = this.#panelEl.querySelector("#vh-rm-review-body");
		const imageOrder = this.#collectImageNamesFromEditor();
		if (imageOrder.length) {
			await this.#storage.setImageOrder(this.#selected.asin, this.#selected.productTitle, imageOrder);
		}
		const imageFiles = await this.#storage.readImageBlobs(
			this.#selected.asin,
			this.#selected.productTitle,
			imageOrder.length ? imageOrder : undefined
		);
		const insertPayload = {
			stars: this.#selected.stars ?? 5,
			reviewTitle: titleEl?.value ?? "",
			reviewContent: bodyEl?.value ?? "",
			imageFiles,
			imageOrder: imageOrder.length ? imageOrder : imageFiles.map((f) => f.name),
		};
		await setPendingReviewInsert(this.#selected.asin, insertPayload);
		await queueReviewInsert(this.#selected.asin, insertPayload);
		const origin = getAmazonOrigin();
		const url = `${origin}/review/create-review?encoding=UTF&channel=vine-portal&asin=${encodeURIComponent(this.#selected.asin)}`;
		this.#showInsertOverlay();
		await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
		window.open(url, "_blank");
	}

	#escape(str) {
		const d = document.createElement("div");
		d.textContent = str;
		return d.innerHTML;
	}
}

export async function initReviewManager(deps) {
	const mgr = new ReviewManager(deps);
	await mgr.init();
	return mgr;
}
