/**
 * Client-side mirror of API helper_review_topics.js
 * @deprecated Import from parseAiSuggestions.js
 */
export { parseTopicsFromAiResponse } from "./parseAiSuggestions.js";
