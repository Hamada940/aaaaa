/**
 * Grammar issue list UI for the Review Manager editor.
 */

import {
	applyGrammarReplacement,
	attachGrammarMatchSnippets,
	grammarMatchKind,
	resolveGrammarMatchPosition,
} from "./ReviewManagerGrammarCheck.js";

export class ReviewManagerGrammarPanel {
	#wrapEl;
	#statusEl;
	#badgeEl;
	#listEl;
	#getMessage;

	/**
	 * @param {{ wrapEl: HTMLElement, statusEl: HTMLElement, badgeEl: HTMLElement, listEl: HTMLElement, getMessage: (key: string, fallback: string, subs?: string[]) => string }} opts
	 */
	constructor(opts) {
		this.#wrapEl = opts.wrapEl;
		this.#statusEl = opts.statusEl;
		this.#badgeEl = opts.badgeEl;
		this.#listEl = opts.listEl;
		this.#getMessage = opts.getMessage;
	}

	setVisible(visible) {
		this.#wrapEl.classList.toggle("vh-rm-hidden", !visible);
	}

	clear() {
		this.#wrapEl.classList.remove("vh-rm-grammar--checking", "vh-rm-grammar--error", "vh-rm-grammar--locked");
		this.#statusEl.textContent = "";
		this.#badgeEl.textContent = "";
		this.#badgeEl.className = "vh-rm-grammar-badge";
		this.#badgeEl.setAttribute("aria-hidden", "true");
		this.#listEl.classList.remove("vh-rm-tier3-preview");
		this.#listEl.replaceChildren();
	}

	/**
	 * @param {string} message
	 */
	setIdle(message) {
		this.#wrapEl.classList.remove("vh-rm-grammar--checking", "vh-rm-grammar--error", "vh-rm-grammar--locked");
		this.#statusEl.textContent = message;
		this.#badgeEl.textContent = "";
		this.#badgeEl.className = "vh-rm-grammar-badge";
		this.#badgeEl.setAttribute("aria-hidden", "true");
		this.#listEl.classList.remove("vh-rm-tier3-preview");
		this.#listEl.replaceChildren();
	}

	setChecking() {
		this.#wrapEl.classList.add("vh-rm-grammar--checking");
		this.#wrapEl.classList.remove("vh-rm-grammar--error", "vh-rm-grammar--locked");
		this.#statusEl.textContent = this.#getMessage("rmGrammarChecking", "Checking grammar…");
		this.#badgeEl.textContent = "";
		this.#badgeEl.className = "vh-rm-grammar-badge";
		this.#badgeEl.setAttribute("aria-hidden", "true");
		this.#listEl.classList.remove("vh-rm-tier3-preview");
		this.#listEl.replaceChildren();
	}

	/**
	 * @param {string} message
	 */
	setError(message) {
		this.#wrapEl.classList.remove("vh-rm-grammar--checking", "vh-rm-grammar--locked");
		this.#wrapEl.classList.add("vh-rm-grammar--error");
		this.#statusEl.textContent = message;
		this.#badgeEl.textContent = "!";
		this.#badgeEl.className = "vh-rm-grammar-badge vh-rm-grammar-badge--error";
		this.#badgeEl.removeAttribute("aria-hidden");
		this.#listEl.classList.remove("vh-rm-tier3-preview");
		this.#listEl.replaceChildren();
	}

	/**
	 * @param {string} message
	 */
	setTierLocked(message) {
		this.#wrapEl.classList.remove("vh-rm-grammar--checking", "vh-rm-grammar--error");
		this.#wrapEl.classList.add("vh-rm-grammar--locked");
		this.#statusEl.textContent = message;
		this.#badgeEl.textContent = "";
		this.#badgeEl.className = "vh-rm-grammar-badge";
		this.#badgeEl.setAttribute("aria-hidden", "true");
		this.#renderTierPreview();
	}

	#renderTierPreview() {
		const previewItems = [
			{
				kind: "grammar",
				snippet: this.#getMessage("rmGrammarPreviewSnippet1", "This product work great"),
				message: this.#getMessage("rmGrammarPreviewMessage1", "Possible subject-verb agreement issue"),
				fix: this.#getMessage("rmGrammarPreviewFix1", "works"),
			},
			{
				kind: "style",
				snippet: this.#getMessage("rmGrammarPreviewSnippet2", "very unique design"),
				message: this.#getMessage(
					"rmGrammarPreviewMessage2",
					"Consider a more precise word than “very unique”"
				),
				fix: this.#getMessage("rmGrammarPreviewFix2", "distinctive"),
			},
		];

		this.#listEl.classList.add("vh-rm-tier3-preview");
		this.#listEl.replaceChildren();
		for (const item of previewItems) {
			this.#listEl.appendChild(this.#createPreviewIssueCard(item));
		}
	}

	/**
	 * @param {{ kind: string, snippet: string, message: string, fix: string }} item
	 */
	#appendSnippetHeader(parent, snippetLabel, { interactive = true } = {}) {
		const text = document.createElement("span");
		text.className = "vh-rm-grammar-snippet-text";
		text.textContent = snippetLabel;

		const hint = document.createElement("span");
		hint.className = "vh-rm-grammar-snippet-hint";
		hint.textContent = this.#getMessage("rmGrammarClickToHighlight", "(click to highlight)");

		if (interactive) {
			parent.className = "vh-rm-grammar-snippet";
			parent.appendChild(text);
			parent.appendChild(hint);
			return;
		}

		parent.className = "vh-rm-grammar-snippet vh-rm-grammar-snippet--preview";
		parent.appendChild(text);
		parent.appendChild(hint);
	}

	#createPreviewIssueCard(item) {
		const li = document.createElement("li");
		li.className = `vh-rm-grammar-issue vh-rm-grammar-issue--${item.kind} vh-rm-grammar-issue--preview`;
		li.setAttribute("aria-hidden", "true");

		const snippet = document.createElement("span");
		this.#appendSnippetHeader(snippet, item.snippet, { interactive: false });

		const msg = document.createElement("p");
		msg.className = "vh-rm-grammar-msg";
		msg.textContent = item.message;

		const fixes = document.createElement("div");
		fixes.className = "vh-rm-grammar-fixes";
		const fix = document.createElement("span");
		fix.className = "vh-rm-grammar-fix vh-rm-grammar-fix--preview";
		fix.textContent = item.fix;
		fixes.appendChild(fix);

		li.appendChild(snippet);
		li.appendChild(msg);
		li.appendChild(fixes);
		return li;
	}

	/**
	 * @param {import("./ReviewManagerGrammarCheck.js").GrammarMatch[]} matches
	 * @param {string} text
	 * @param {HTMLTextAreaElement} bodyEl
	 * @param {(newText: string) => void} onTextChange
	 */
	render(matches, text, bodyEl, onTextChange) {
		this.#wrapEl.classList.remove("vh-rm-grammar--checking", "vh-rm-grammar--error", "vh-rm-grammar--locked");
		this.#listEl.classList.remove("vh-rm-tier3-preview");
		const enriched = attachGrammarMatchSnippets(matches, text);
		const count = enriched.length;

		if (count === 0) {
			this.#statusEl.textContent = this.#getMessage("rmGrammarOk", "No grammar issues found.");
			this.#badgeEl.textContent = "✓";
			this.#badgeEl.className = "vh-rm-grammar-badge vh-rm-grammar-badge--ok";
			this.#badgeEl.removeAttribute("aria-hidden");
			this.#listEl.replaceChildren();
			return;
		}

		this.#statusEl.textContent = this.#getMessage("rmGrammarIssuesCount", "$1$ issue(s) found", [String(count)]);
		this.#badgeEl.textContent = String(count);
		this.#badgeEl.className = "vh-rm-grammar-badge vh-rm-grammar-badge--issues";
		this.#badgeEl.removeAttribute("aria-hidden");

		this.#listEl.replaceChildren();
		for (const match of enriched) {
			this.#listEl.appendChild(this.#createIssueCard(match, bodyEl, onTextChange));
		}
	}

	/**
	 * @param {import("./ReviewManagerGrammarCheck.js").GrammarMatch} match
	 */
	#createIssueCard(match, bodyEl, onTextChange) {
		const kind = grammarMatchKind(match);
		const li = document.createElement("li");
		li.className = `vh-rm-grammar-issue vh-rm-grammar-issue--${kind}`;

		const snippetLabel = match.snippet || "…";
		const snippetBtn = document.createElement("button");
		snippetBtn.type = "button";
		this.#appendSnippetHeader(snippetBtn, snippetLabel);
		const highlightHint = this.#getMessage("rmGrammarClickToHighlight", "(click to highlight)");
		snippetBtn.title = this.#getMessage("rmGrammarHighlightFull", "Flagged text: $1$ — $2$", [
			snippetLabel,
			highlightHint,
		]);
		snippetBtn.addEventListener("click", () => {
			const resolved = resolveGrammarMatchPosition(bodyEl.value, match);
			if (!resolved) {
				snippetBtn.disabled = true;
				snippetBtn.title = this.#getMessage("rmGrammarFixStale", "Text changed; run grammar check again.");
				return;
			}
			bodyEl.focus();
			bodyEl.setSelectionRange(resolved.offset, resolved.offset + resolved.length);
			const ratio = resolved.offset / Math.max(bodyEl.value.length, 1);
			bodyEl.scrollTop = Math.max(0, bodyEl.scrollHeight * ratio - 40);
		});

		const msg = document.createElement("p");
		msg.className = "vh-rm-grammar-msg";
		msg.textContent = match.shortMessage || match.message;

		li.appendChild(snippetBtn);
		li.appendChild(msg);

		const fixes = document.createElement("div");
		fixes.className = "vh-rm-grammar-fixes";

		if (match.replacements.length > 0) {
			const limit = Math.min(match.replacements.length, 4);
			for (let i = 0; i < limit; i++) {
				const rep = match.replacements[i];
				const fixBtn = document.createElement("button");
				fixBtn.type = "button";
				fixBtn.className = "vh-rm-grammar-fix";
				fixBtn.textContent = rep;
				fixBtn.title = this.#getMessage("rmGrammarReplaceFull", 'Replace "$1$" with "$2$"', [
					match.snippet || snippetLabel,
					rep,
				]);
				fixBtn.addEventListener("click", () => {
					if (fixBtn.disabled) {
						return;
					}
					const result = applyGrammarReplacement(bodyEl.value, match, rep);
					if (!result.applied) {
						this.#disableIssueActions(li, snippetBtn, fixes);
						return;
					}
					bodyEl.value = result.text;
					bodyEl.dispatchEvent(new InputEvent("input", { bubbles: true }));
					onTextChange(result.text);
					li.remove();
					this.#syncIssueCountAfterRemoval();
				});
				fixes.appendChild(fixBtn);
			}
		}

		const dismissBtn = document.createElement("button");
		dismissBtn.type = "button";
		dismissBtn.className = "vh-rm-grammar-dismiss";
		dismissBtn.textContent = this.#getMessage("rmGrammarDismiss", "Dismiss");
		dismissBtn.title = this.#getMessage("rmGrammarDismissHint", "Ignore this suggestion");
		dismissBtn.addEventListener("click", () => {
			li.remove();
			this.#syncIssueCountAfterRemoval();
		});
		fixes.appendChild(dismissBtn);
		li.appendChild(fixes);

		return li;
	}

	/**
	 * @param {HTMLLIElement} li
	 * @param {HTMLButtonElement} snippetBtn
	 * @param {HTMLElement} fixes
	 */
	#disableIssueActions(li, snippetBtn, fixes) {
		const staleMsg = this.#getMessage("rmGrammarFixStale", "Text changed; run grammar check again.");
		snippetBtn.disabled = true;
		snippetBtn.title = staleMsg;
		for (const btn of fixes.querySelectorAll(".vh-rm-grammar-fix")) {
			btn.disabled = true;
			btn.title = staleMsg;
		}
		li.classList.add("vh-rm-grammar-issue--stale");
	}

	#syncIssueCountAfterRemoval() {
		const remaining = this.#listEl.querySelectorAll(".vh-rm-grammar-issue").length;
		if (remaining === 0) {
			this.#statusEl.textContent = this.#getMessage("rmGrammarOk", "No grammar issues found.");
			this.#badgeEl.textContent = "✓";
			this.#badgeEl.className = "vh-rm-grammar-badge vh-rm-grammar-badge--ok";
			return;
		}
		this.#badgeEl.textContent = String(remaining);
		this.#statusEl.textContent = this.#getMessage("rmGrammarIssuesCount", "$1$ issue(s) found", [
			String(remaining),
		]);
	}
}
