/**
 * VineHelper API client for review manager.
 */

import { PREFERRED_LANGUAGES } from "./ReviewManagerGrammarCheck.js";
import { parseAiSuggestions } from "./parseAiSuggestions.js";

async function signedReviewRequest(env, cryptoKeys, Settings, i18n, action, extra = {}) {
	const content = {
		api_version: 5,
		app_version: env.data.appVersion,
		action,
		country: i18n.getCountryCode(),
		uuid: await Settings.get("general.uuid", false),
		fid: await Settings.get("general.fingerprint.id", false),
		cid: await env.getCID(),
		...extra,
	};
	content.s = await cryptoKeys.signData(content);
	content.pk = await cryptoKeys.getExportedPublicKey();

	const response = await fetch(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(content),
	});
	const data = await response.json();
	if (!response.ok || data.error) {
		const err = new Error(data.error || `Request failed (${response.status})`);
		err.status = response.status;
		throw err;
	}
	return data;
}

function parseTokenNumber(value) {
	if (typeof value === "number" && !Number.isNaN(value)) {
		return value;
	}
	if (typeof value === "string" && value.trim() !== "") {
		const n = Number(value);
		if (!Number.isNaN(n)) {
			return n;
		}
	}
	return null;
}

export function parseTokenInfo(data) {
	const remaining = parseTokenNumber(data.tokens_remaining ?? data.tokensRemaining);
	const max = parseTokenNumber(data.tokens_max ?? data.tokensMax);
	return {
		remaining: remaining != null && remaining >= 0 ? remaining : null,
		max: max != null && max > 0 ? max : null,
	};
}

export async function fetchVhProductPrice(deps, asin) {
	const data = await signedReviewRequest(
		deps.env,
		deps.cryptoKeys,
		deps.Settings,
		deps.i18n,
		"review_product_price",
		{
			asin,
		}
	);
	const price = data.price;
	return price != null && price !== "" ? price : null;
}

export async function fetchTokenBalance(deps) {
	const data = await signedReviewRequest(deps.env, deps.cryptoKeys, deps.Settings, deps.i18n, "review_token_balance");
	return parseTokenInfo(data);
}

function parseTokenCost(value) {
	const n = parseTokenNumber(value);
	return n != null && n > 0 ? Math.floor(n) : null;
}

/**
 * Fetch Tier 3 review-assistant token costs from the server.
 * @param {object} deps
 * @returns {Promise<{ grammar: number | null, suggest: number | null }>}
 */
export async function fetchTokenCosts(deps) {
	const data = await signedReviewRequest(deps.env, deps.cryptoKeys, deps.Settings, deps.i18n, "review_token_costs");
	return {
		grammar: parseTokenCost(data.grammar_check ?? data.grammarCheck),
		suggest: parseTokenCost(data.suggest_topics ?? data.suggestTopics),
	};
}

export async function suggestTopics({ env, cryptoKeys, Settings, i18n, asin, reviewText, productDescription }) {
	const data = await signedReviewRequest(env, cryptoKeys, Settings, i18n, "review_suggest_topics", {
		asin,
		review_text: reviewText,
		product_description: productDescription,
	});
	const tokenInfo = parseTokenInfo(data);
	const suggestions = parseAiSuggestions(data);
	return {
		evaluation: suggestions.evaluation,
		topics: suggestions.topics,
		tokensRemaining: tokenInfo.remaining,
		tokensMax: tokenInfo.max,
	};
}

/**
 * Grammar check via VH API (OpenAI, Tier 3 tokens). Requires backend action review_grammar_check.
 * @param {object} deps
 * @param {string} text
 * @param {string} language LanguageTool code or "auto"
 */
export async function checkGrammar(deps, text, language) {
	const lang = language && language !== "auto" ? language : "auto";
	const extra = { text, language: lang };
	if (lang === "auto") {
		extra.preferred_languages = PREFERRED_LANGUAGES;
	}
	const data = await signedReviewRequest(
		deps.env,
		deps.cryptoKeys,
		deps.Settings,
		deps.i18n,
		"review_grammar_check",
		extra
	);
	const tokenInfo = parseTokenInfo(data);
	return {
		matches: Array.isArray(data.matches) ? data.matches : [],
		tokensRemaining: tokenInfo.remaining,
		tokensMax: tokenInfo.max,
	};
}
