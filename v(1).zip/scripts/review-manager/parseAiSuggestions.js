/**
 * Parse AI review suggestions from API responses or raw model output.
 */

import { normalizeSuggestedEvaluation, normalizeSuggestedTopics } from "./ReviewManagerStorage.js";

const EMPTY = { evaluation: null, topics: [] };

function isAiSuggestionsBlob(value) {
	if (typeof value !== "string") {
		return false;
	}
	const text = value.trim();
	return text.startsWith("{") && (/"topics"/i.test(text) || /"evaluation"/i.test(text));
}

export function repairAiSuggestionsJson(text) {
	let s = text.trim();
	const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
	if (fence) {
		s = fence[1].trim();
	}
	if (/"evaluation"\s*:\s*\[/i.test(s)) {
		s = s.replace(/"evaluation"\s*:\s*\[/i, '"evaluation":{');
		s = s.replace(/(\])\s*\]\s*,(\s*"topics")/i, "$1},$2");
	}
	return s;
}

function normalizeEvaluationFromParsed(evaluation) {
	if (!evaluation) {
		return null;
	}
	if (typeof evaluation === "string") {
		return normalizeSuggestedEvaluation({ result: evaluation, recommendations: [] });
	}
	if (Array.isArray(evaluation)) {
		if (evaluation.length === 1 && evaluation[0] && typeof evaluation[0] === "object") {
			return normalizeSuggestedEvaluation(evaluation[0]);
		}
		return null;
	}
	if (typeof evaluation === "object") {
		return normalizeSuggestedEvaluation(evaluation);
	}
	return null;
}

function parseAiSuggestionsFromObject(obj) {
	const evaluation = normalizeEvaluationFromParsed(obj.evaluation);
	const topics = normalizeSuggestedTopics(Array.isArray(obj.topics) ? obj.topics : []);
	return { evaluation, topics };
}

function parseAiSuggestionsFallback(text) {
	const resultMatch = text.match(/"result"\s*:\s*"((?:\\.|[^"\\])*)"/);
	let recommendations = [];
	const recBlock = text.match(/"recommendations"\s*:\s*(\[[\s\S]*?\])\s*\]?/i);
	if (recBlock) {
		try {
			const parsed = JSON.parse(recBlock[1]);
			if (Array.isArray(parsed)) {
				recommendations = parsed.filter((r) => typeof r === "string");
			}
		} catch {
			// ignore
		}
	}

	let topics = [];
	const topicsBlock = text.match(/"topics"\s*:\s*(\[[\s\S]*?\])\s*\}?/i);
	if (topicsBlock) {
		try {
			const parsed = JSON.parse(topicsBlock[1]);
			if (Array.isArray(parsed)) {
				topics = parsed.filter((t) => typeof t === "string");
			}
		} catch {
			// ignore
		}
	}

	const evaluation = normalizeSuggestedEvaluation({
		result: resultMatch?.[1]?.replace(/\\"/g, '"') ?? "",
		recommendations,
	});

	if (!evaluation && topics.length === 0) {
		return EMPTY;
	}
	return { evaluation, topics: normalizeSuggestedTopics(topics) };
}

function parseAiSuggestionsText(text) {
	const repaired = repairAiSuggestionsJson(text);
	try {
		const parsed = JSON.parse(repaired);
		if (parsed && typeof parsed === "object") {
			return parseAiSuggestions(parsed);
		}
	} catch {
		// continue to regex fallback
	}
	return parseAiSuggestionsFallback(repaired);
}

/**
 * @param {unknown} raw API payload, JSON string, or legacy topics array
 * @returns {{ evaluation: { result: string, recommendations: string[] } | null, topics: string[] }}
 */
export function parseAiSuggestions(raw) {
	if (raw == null) {
		return EMPTY;
	}

	if (typeof raw === "string") {
		if (!raw.trim()) {
			return EMPTY;
		}
		return parseAiSuggestionsText(raw);
	}

	if (Array.isArray(raw)) {
		const joined = raw
			.filter((t) => typeof t === "string")
			.join("\n")
			.trim();
		if (joined && isAiSuggestionsBlob(joined)) {
			return parseAiSuggestionsText(joined);
		}
		if (raw.length === 1 && isAiSuggestionsBlob(raw[0])) {
			return parseAiSuggestionsText(raw[0]);
		}
		return { evaluation: null, topics: normalizeSuggestedTopics(raw) };
	}

	if (typeof raw === "object") {
		const topics = raw.topics;
		if (typeof topics === "string" && isAiSuggestionsBlob(topics)) {
			return parseAiSuggestionsText(topics);
		}
		if (Array.isArray(topics) && topics.length === 1 && isAiSuggestionsBlob(topics[0])) {
			return parseAiSuggestionsText(topics[0]);
		}
		if (topics && typeof topics === "object" && !Array.isArray(topics) && Array.isArray(topics.topics)) {
			return parseAiSuggestionsFromObject(topics);
		}
		if (raw.evaluation || Array.isArray(topics)) {
			return parseAiSuggestionsFromObject(raw);
		}
		for (const key of ["response", "content", "result", "suggestions"]) {
			if (isAiSuggestionsBlob(raw[key])) {
				return parseAiSuggestionsText(raw[key]);
			}
		}
	}

	return EMPTY;
}

/**
 * @param {string} raw
 * @returns {string[]}
 */
export function parseTopicsFromAiResponse(raw) {
	return parseAiSuggestions(raw).topics;
}
