/**
 * Queue review insert payloads for Amazon create-review pages (IndexedDB).
 */

import { normalizeImageOrder, sortFilesByNameOrder } from "./ReviewManagerStorage.js";

const IDB_NAME = "vh-review-insert";
const IDB_STORE = "queue";

function openDb() {
	return new Promise((resolve, reject) => {
		const request = indexedDB.open(IDB_NAME, 1);
		request.onerror = () => reject(request.error);
		request.onsuccess = () => resolve(request.result);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains(IDB_STORE)) {
				db.createObjectStore(IDB_STORE);
			}
		};
	});
}

/**
 * @param {string} asin
 * @param {{ stars: number, reviewTitle: string, reviewContent: string, imageFiles: File[], imageOrder?: string[] }} payload
 */
export async function queueReviewInsert(asin, payload) {
	const db = await openDb();
	const imageOrder = normalizeImageOrder(
		payload.imageOrder ?? (payload.imageFiles || []).map((f) => f.name),
		(payload.imageFiles || []).map((f) => f.name)
	);
	const orderedFiles = sortFilesByNameOrder(payload.imageFiles || [], imageOrder);
	const imageBlobs = [];
	for (const file of orderedFiles) {
		const buffer = await file.arrayBuffer();
		imageBlobs.push({
			name: file.name,
			type: file.type,
			buffer,
		});
	}
	const record = {
		asin,
		stars: payload.stars,
		reviewTitle: payload.reviewTitle,
		reviewContent: payload.reviewContent,
		imageBlobs,
		imageOrder,
		createdAt: Date.now(),
	};
	await new Promise((resolve, reject) => {
		const tx = db.transaction(IDB_STORE, "readwrite");
		tx.objectStore(IDB_STORE).put(record, asin);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}

function recordToPayload(record) {
	if (!record) {
		return null;
	}
	const imageFiles = (record.imageBlobs || []).map((b) => new File([b.buffer], b.name, { type: b.type }));
	const orderedFiles =
		Array.isArray(record.imageOrder) && record.imageOrder.length
			? sortFilesByNameOrder(imageFiles, record.imageOrder)
			: imageFiles;
	return {
		stars: record.stars,
		reviewTitle: record.reviewTitle,
		reviewContent: record.reviewContent,
		imageFiles: orderedFiles,
	};
}

/**
 * @param {string} asin
 */
export async function peekReviewInsert(asin) {
	const db = await openDb();
	const record = await new Promise((resolve, reject) => {
		const tx = db.transaction(IDB_STORE, "readonly");
		const req = tx.objectStore(IDB_STORE).get(asin);
		req.onsuccess = () => resolve(req.result || null);
		req.onerror = () => reject(req.error);
	});
	return recordToPayload(record);
}

/**
 * @param {string} asin
 */
export async function removeReviewInsert(asin) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(IDB_STORE, "readwrite");
		tx.objectStore(IDB_STORE).delete(asin);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}

/**
 * @param {string} asin
 */
export async function consumeReviewInsert(asin) {
	const payload = await peekReviewInsert(asin);
	if (!payload) {
		return null;
	}
	await removeReviewInsert(asin);
	return payload;
}
