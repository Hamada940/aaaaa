/**
 * Grammar check helpers (VH API / OpenAI).
 */

/** @typedef {{ offset: number, length: number, message: string, shortMessage: string, replacements: string[], category?: string, snippet?: string }} GrammarMatch */

export const PREFERRED_LANGUAGES = "en-US,en-GB,en-CA,en-AU,fr,fr-CA,de,es,it,ja,pt-BR";

/** Minimum review body length before a grammar check is allowed. */
export const GRAMMAR_CHECK_MIN_CHARS = 20;

/** Characters to search on each side of the expected offset when the snippet moved. */
export const GRAMMAR_MATCH_SEARCH_RADIUS = 500;

const LT_LANG_MAP = {
	en: "en-US",
	"en-US": "en-US",
	"en-GB": "en-GB",
	"en-CA": "en-CA",
	"en-AU": "en-AU",
	fr: "fr",
	"fr-FR": "fr",
	"fr-CA": "fr-CA",
	de: "de",
	es: "es",
	it: "it",
	ja: "ja",
	"pt-BR": "pt-BR",
};

/**
 * @param {string} spellLang
 * @returns {string}
 */
export function toLanguageToolLang(spellLang) {
	if (!spellLang) {
		return "auto";
	}
	return LT_LANG_MAP[spellLang] || spellLang;
}

/**
 * @param {unknown[]} matches
 * @returns {GrammarMatch[]}
 */
export function normalizeGrammarMatches(matches) {
	if (!Array.isArray(matches)) {
		return [];
	}
	return matches
		.map((m) => {
			if (!m || typeof m !== "object") {
				return null;
			}
			const offset = Number(m.offset);
			const length = Number(m.length);
			if (!Number.isFinite(offset) || !Number.isFinite(length) || length <= 0) {
				return null;
			}
			const replacements = Array.isArray(m.replacements)
				? m.replacements
						.map((r) => (typeof r === "string" ? r : r?.value))
						.filter((v) => typeof v === "string" && v.length > 0)
				: [];
			const message = typeof m.message === "string" ? m.message : "";
			const shortMessage = typeof m.shortMessage === "string" && m.shortMessage ? m.shortMessage : message;
			const category =
				typeof m.category === "string"
					? m.category
					: typeof m.rule?.category?.id === "string"
						? m.rule.category.id
						: undefined;
			const snippet =
				typeof m.snippet === "string" && m.snippet
					? m.snippet
					: typeof m.flagged === "string" && m.flagged
						? m.flagged
						: undefined;
			return {
				offset,
				length,
				message,
				shortMessage: shortMessage || message,
				replacements,
				category,
				...(snippet ? { snippet } : {}),
			};
		})
		.filter(Boolean);
}

/**
 * @param {string} snippet
 * @param {string[]} replacements
 * @returns {boolean}
 */
export function replacementLooksLikeFullRewrite(snippet, replacements) {
	if (!snippet || replacements.length === 0) {
		return false;
	}
	const longest = replacements.reduce((best, current) => (current.length > best.length ? current : best), "");
	if (longest.length > snippet.length + 10) {
		return true;
	}
	if (longest.length > snippet.length * 1.35) {
		return true;
	}
	return false;
}

/**
 * @param {string} text
 * @param {number} offset
 * @param {number} length
 * @returns {{ offset: number, length: number, snippet: string }}
 */
export function expandSpanToSentenceBounds(text, offset, length) {
	let start = offset;
	let end = offset + length;

	while (start > 0) {
		const ch = text[start - 1];
		if (ch === "\n" || ch === "." || ch === "?" || ch === "!") {
			break;
		}
		start--;
	}
	while (start < offset && /\s/.test(text[start])) {
		start++;
	}

	while (end < text.length) {
		const ch = text[end];
		if (ch === "\n") {
			break;
		}
		end++;
		if (ch === "." || ch === "?" || ch === "!") {
			break;
		}
	}

	return {
		offset: start,
		length: end - start,
		snippet: text.slice(start, end),
	};
}

/**
 * @param {string} text
 * @param {GrammarMatch} match
 * @returns {GrammarMatch}
 */
export function reconcileGrammarMatchSpan(text, match) {
	let offset = Number(match.offset);
	let length = Number(match.length);
	const apiSnippet = typeof match.snippet === "string" ? match.snippet : "";

	if (apiSnippet && text.slice(offset, offset + apiSnippet.length) === apiSnippet) {
		length = apiSnippet.length;
	} else {
		const atOffset = text.slice(offset, offset + length);
		if (atOffset) {
			length = atOffset.length;
		}
	}

	let snippet = apiSnippet || text.slice(offset, offset + length);
	if (replacementLooksLikeFullRewrite(snippet, match.replacements || [])) {
		const expanded = expandSpanToSentenceBounds(text, offset, length);
		offset = expanded.offset;
		length = expanded.length;
		snippet = expanded.snippet;
	} else {
		snippet = text.slice(offset, offset + length);
	}

	return {
		...match,
		offset,
		length,
		snippet,
	};
}

/**
 * Store the flagged substring from the text that was analyzed.
 * @param {GrammarMatch[]} matches
 * @param {string} sourceText
 * @returns {GrammarMatch[]}
 */
export function attachGrammarMatchSnippets(matches, sourceText) {
	return matches.map((match) => reconcileGrammarMatchSpan(sourceText, match));
}

/**
 * Find the best span for a grammar match in the current editor text.
 * @param {string} text
 * @param {GrammarMatch} match
 * @param {number} [searchRadius]
 * @returns {{ offset: number, length: number } | null}
 */
const SNIPPET_WORD_CHAR = /[\p{L}\p{N}']/u;

/**
 * @param {string} ch
 * @returns {boolean}
 */
function isSnippetWordChar(ch) {
	return ch !== "" && SNIPPET_WORD_CHAR.test(ch);
}

/**
 * @param {string} text
 * @param {number} offset
 * @param {string} snippet
 * @returns {boolean}
 */
export function isStandaloneSnippetAt(text, offset, snippet) {
	if (!snippet || offset < 0 || offset + snippet.length > text.length) {
		return false;
	}
	if (text.slice(offset, offset + snippet.length) !== snippet) {
		return false;
	}
	const before = offset > 0 ? text[offset - 1] : "";
	const after = offset + snippet.length < text.length ? text[offset + snippet.length] : "";
	if (isSnippetWordChar(before) && isSnippetWordChar(snippet[0])) {
		return false;
	}
	if (isSnippetWordChar(after) && isSnippetWordChar(snippet[snippet.length - 1])) {
		return false;
	}
	return true;
}

export function resolveGrammarMatchPosition(text, match, searchRadius = GRAMMAR_MATCH_SEARCH_RADIUS) {
	const expected = Number(match.offset);
	const snippet = typeof match.snippet === "string" ? match.snippet : "";
	const fallbackLength = Number(match.length);

	if (snippet.length > 0) {
		const exact = trySnippetAt(text, expected, snippet);
		if (exact) {
			return exact;
		}

		const near = findClosestSnippet(text, snippet, expected, searchRadius);
		if (near) {
			return near;
		}

		return findClosestSnippet(text, snippet, expected, text.length);
	}

	if (
		Number.isFinite(expected) &&
		Number.isFinite(fallbackLength) &&
		fallbackLength > 0 &&
		expected >= 0 &&
		expected + fallbackLength <= text.length
	) {
		return { offset: expected, length: fallbackLength };
	}

	return null;
}

/**
 * @param {string} text
 * @param {number} offset
 * @param {string} snippet
 * @returns {{ offset: number, length: number } | null}
 */
function trySnippetAt(text, offset, snippet) {
	if (offset < 0 || offset + snippet.length > text.length) {
		return null;
	}
	if (text.slice(offset, offset + snippet.length) === snippet && isStandaloneSnippetAt(text, offset, snippet)) {
		return { offset, length: snippet.length };
	}
	return null;
}

/**
 * @param {string} text
 * @param {string} snippet
 * @param {number} expectedOffset
 * @param {number} radius
 * @returns {{ offset: number, length: number } | null}
 */
function findClosestSnippet(text, snippet, expectedOffset, radius) {
	let best = null;
	let bestDistance = Infinity;

	const windowStart = Math.max(0, expectedOffset - radius);
	const windowEnd = Math.min(text.length, expectedOffset + radius + snippet.length);
	searchSnippetInRange(text, snippet, windowStart, windowEnd, expectedOffset, (candidate, distance) => {
		if (distance < bestDistance) {
			bestDistance = distance;
			best = candidate;
		}
	});

	return best;
}

/**
 * @param {string} text
 * @param {string} snippet
 * @param {number} rangeStart
 * @param {number} rangeEnd
 * @param {number} expectedOffset
 * @param {(candidate: { offset: number, length: number }, distance: number) => void} onCandidate
 */
function searchSnippetInRange(text, snippet, rangeStart, rangeEnd, expectedOffset, onCandidate) {
	if (!snippet || rangeEnd <= rangeStart) {
		return;
	}
	let idx = rangeStart;
	while (idx <= rangeEnd - snippet.length) {
		const found = text.indexOf(snippet, idx);
		if (found === -1 || found > rangeEnd - snippet.length) {
			break;
		}
		if (isStandaloneSnippetAt(text, found, snippet)) {
			onCandidate({ offset: found, length: snippet.length }, Math.abs(found - expectedOffset));
		}
		idx = found + 1;
	}
}

/**
 * @param {string} text
 * @param {GrammarMatch} match
 * @param {string} replacement
 * @returns {{ text: string, applied: boolean }}
 */
export function applyGrammarReplacement(text, match, replacement) {
	const resolved = resolveGrammarMatchPosition(text, match);
	if (!resolved) {
		return { text, applied: false };
	}

	const before = text.slice(0, resolved.offset);
	const after = text.slice(resolved.offset + resolved.length);
	return {
		text: before + replacement + after,
		applied: true,
	};
}

/**
 * @param {GrammarMatch} match
 * @returns {"typo"|"style"|"grammar"}
 */
export function grammarMatchKind(match) {
	const id = (match.category || "").toUpperCase();
	if (id.includes("TYPO") || id.includes("SPELL")) {
		return "typo";
	}
	if (id.includes("STYLE") || id.includes("PUNCTUATION")) {
		return "style";
	}
	return "grammar";
}
