/**
 * Cross-tab review insert payload (chrome.storage.local — shared across Amazon tabs).
 */

const storageKey = (asin) => `vh_review_insert_${asin}`;

/**
 * @param {string} asin
 * @param {{ stars: number, reviewTitle: string, reviewContent: string }} payload
 */
export async function setPendingReviewInsert(asin, payload) {
	await chrome.storage.local.set({
		[storageKey(asin)]: {
			stars: payload.stars ?? 5,
			reviewTitle: payload.reviewTitle ?? "",
			reviewContent: payload.reviewContent ?? "",
			queuedAt: Date.now(),
		},
	});
}

/**
 * @param {string} asin
 */
export async function getPendingReviewInsert(asin) {
	const key = storageKey(asin);
	const data = await chrome.storage.local.get(key);
	return data[key] || null;
}

/**
 * @param {string} asin
 */
export async function clearPendingReviewInsert(asin) {
	await chrome.storage.local.remove(storageKey(asin));
}
