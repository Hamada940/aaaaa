/**
 * Browser-native spellcheck with locale detection for supported VineHelper locales.
 */

const LOCALE_LANG_MAP = {
	en: "en",
	"en-US": "en-US",
	"en-GB": "en-GB",
	"en-CA": "en-CA",
	"en-AU": "en-AU",
	fr: "fr",
	"fr-FR": "fr",
	"fr-CA": "fr-CA",
	de: "de",
	es: "es",
	it: "it",
	ja: "ja",
	"pt-BR": "pt-BR",
};

const COUNTRY_LANG_MAP = {
	com: "en-US",
	ca: "en-CA",
	uk: "en-GB",
	de: "de",
	fr: "fr-FR",
	es: "es",
	it: "it",
	jp: "ja",
	au: "en-AU",
	br: "pt-BR",
	mx: "es",
	sg: "en",
};

/**
 * @param {string} text
 * @param {string} [localeOverride]
 * @param {string} [countryCode]
 */
export function detectSpellcheckLang(text, localeOverride, countryCode) {
	if (localeOverride && LOCALE_LANG_MAP[localeOverride]) {
		return LOCALE_LANG_MAP[localeOverride];
	}
	if (countryCode && COUNTRY_LANG_MAP[countryCode]) {
		return COUNTRY_LANG_MAP[countryCode];
	}
	const sample = (text || "").slice(0, 500).toLowerCase();
	if (/[àâäæçéèêëîïôùûü]/i.test(sample)) {
		return "fr";
	}
	if (/[äöüß]/i.test(sample)) {
		return "de";
	}
	if (/[ñ¿¡]/i.test(sample)) {
		return "es";
	}
	return navigator.language || "en";
}

/**
 * @param {HTMLTextAreaElement|HTMLInputElement} el
 * @param {string} lang
 */
export function applySpellcheck(el, lang) {
	el.setAttribute("spellcheck", "true");
	el.setAttribute("lang", lang);
	el.classList.add("vh-rm-spellcheck");
}

/** @type {readonly string[]} */
export const SUPPORTED_SPELL_LANGS = Object.keys(LOCALE_LANG_MAP);
