//Load the preboot file as a module
(async () => {
	if (globalThis.__VH_CHECKOUT_MONITORING_ACTIVE__) return;
	try {
		await import(chrome.runtime.getURL("./scripts/checkoutMonitoring.js"));
		globalThis.__VH_CHECKOUT_MONITORING_ACTIVE__ = true;
	} catch (error) {
		console.error("Error loading module:", error);
	}
})();
