/**
 * Increments BUILD_NUMBER in scripts/build_info.js. Invoked from .husky/pre-commit
 * after lint-staged so failed lint does not advance the counter.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const target = path.join(__dirname, "build_info.js");

let src = fs.readFileSync(target, "utf8");
const match = src.match(/BUILD_NUMBER\s*=\s*(\d+)/);
if (!match) {
	console.error("increment-build: could not parse BUILD_NUMBER in", target);
	process.exit(1);
}
const next = Number(match[1]) + 1;
src = src.replace(/BUILD_NUMBER\s*=\s*\d+/, `BUILD_NUMBER = ${next}`);
fs.writeFileSync(target, src, "utf8");
console.log(`increment-build: BUILD_NUMBER -> ${next}`);
