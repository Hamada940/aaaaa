/*global chrome*/

import { Logger } from "/scripts/core/utils/Logger.js";
var logger = new Logger();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
var Settings = new SettingsMgr();

import { Template } from "/scripts/core/utils/Template.js";
const Tpl = new Template();
import { isOrionBrowser } from "/scripts/core/utils/BrowserDetection.js";
import { VVP_CONTEXT } from "/scripts/core/amazon/selectors.js";

//###############################################33
//Code start

async function getResolvedCurrentUrl() {
	try {
		if (isOrionBrowser()) {
			const response = await chrome.runtime.sendMessage({ action: "getSenderTabUrl" });
			if (typeof response?.url === "string") {
				return new URL(response.url);
			}
		}
	} catch {
		// Ignore and fall back to window location.
	}
	try {
		return new URL(window.location.href);
	} catch {
		return null;
	}
}

async function runPreboot() {
	const currentUrl = await getResolvedCurrentUrl();
	const pathname = currentUrl?.pathname || "";
	const hash = currentUrl?.hash || "";
	const isLegacyVhMonitorPath = /^\/(?:[^/]+\/)?vine\/vh-monitor\/?$/.test(pathname);
	const isMonitorV4Path = /^\/(?:[^/]+\/)?vine\/resources\/?$/.test(pathname) && hash.startsWith("#vh-monitor");
	const isCheckoutRedirectPath = /^\/(?:[^/]+\/)?vine\/vh-monitor\/checkout-redirect\/?$/.test(pathname);

	if (isLegacyVhMonitorPath || isMonitorV4Path || isCheckoutRedirectPath) {
		// Directly modify the inline style of body as early as possible for maximal speed
		const hideMonitorBody = () => {
			if (document.body) {
				document.body.style.display = "none";
			}
		};
		hideMonitorBody();
		if (!document.body) {
			document.addEventListener("DOMContentLoaded", hideMonitorBody, { once: true });
		}
	}

	if (isMonitorV4Path) {
		// Early script strip on /vine/resources#vh-monitor. Keep vvp-context (CSRF JSON).
		// Fuller guards run in preboot_inj.js → inj_preboot.js in the page main world.
		document.querySelectorAll("head script, body script").forEach((elem) => {
			const src = elem.src || "";
			if (elem.matches(VVP_CONTEXT.SCRIPT)) return;
			if (src.startsWith("chrome-extension://")) return;
			elem.remove();
		});
	}

	//Do not run the extension if ultraviner is running
	let regex = /^.+?amazon\..+\/vine\/.*ultraviner.*?$/;
	if (!regex.test(currentUrl?.href || "")) {
		loadStyleSheets(isMonitorV4Path); //First call to launch the extension.
	} else {
		console.log("VHelper detected UltraViner. Disabling VHelper on this page.");
	}
}
runPreboot();

//Loading the settings from the local storage
async function loadStyleSheets(isMonitorV4Path = false) {
	logger.add("PREBOOT: Waiting on config to be loaded...");
	await Settings.waitForLoad();
	logger.add("PREBOOT: config loaded!");

	loadStyleSheet("scripts/vendor/splide/dist/css/splide.min.css");
	// Theme: load on every Vine page so --vh-primary etc. are defined (centralized in theme files)
	const theme = Settings.get("general.theme") || "forest";
	if (theme === "dark") {
		loadStyleSheet("resource/theme/dark.css");
	} else if (theme === "aurora") {
		loadStyleSheet("resource/theme/aurora.css");
	} else if (theme === "garish") {
		loadStyleSheet("resource/theme/garish.css");
	} else if (theme === "midnight") {
		loadStyleSheet("resource/theme/midnight.css");
	} else if (theme === "scifi") {
		loadStyleSheet("resource/theme/scifi.css");
	} else if (theme === "win31") {
		loadStyleSheet("resource/theme/win31.css");
	} else {
		loadStyleSheet("resource/theme/forest.css");
	}

	// Monitor V4 injects custom CSS after its stylesheets in main.tsx (same order as V3 Lite).
	if (Settings.get("general.customCSS") && !isMonitorV4Path) {
		loadCustomCSS(Settings.get("general.customCSS"));
	}
}

//#################################################3
//### UTILITY FUNCTIONS

async function loadStyleSheet(path, mediaQuery = null, injected = false) {
	if (injected) {
		const prom = await Tpl.loadFile(path);
		let content = Tpl.render(prom);

		if (mediaQuery) {
			content = `@media ${mediaQuery} { ${content} }`;
		}

		loadStyleSheetContent(content, path); //Put content between <style></style>
	} else {
		loadStyleSheetExternal(path); //Insert as an external stylesheet.
	}
}

function loadStyleSheetContent(content, path = "injected") {
	if (content != "") {
		const style = document.createElement("style");
		style.textContent = "/*" + path + "*/\n" + content;
		document.head.appendChild(style);
	}
}

function loadCustomCSS(content) {
	const styleId = "vh-custom-css";
	let style = document.getElementById(styleId);
	if (!style) {
		style = document.createElement("style");
		style.id = styleId;
		document.head.appendChild(style);
	}
	style.textContent = content ? `/*general.customCSS*/\n${content}` : "";
}

function loadStyleSheetExternal(path) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.href = chrome.runtime.getURL(path); // Set the path to the CSS file
	document.head.appendChild(link);
}
