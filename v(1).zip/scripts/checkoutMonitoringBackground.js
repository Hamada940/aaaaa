/*global chrome*/

const AMAZON_HOST = /^(?:.*\.)?amazon\.(?:ca|com|de|fr|co\.uk|co\.jp|com\.au|com\.br|com\.mx|sg|it|es)$/i;

/** True when the URL should run checkout monitoring (mirrors manifest content_script matches). */
export function isCheckoutMonitoringUrl(urlString) {
	if (!urlString || typeof urlString !== "string") return false;
	try {
		const url = new URL(urlString);
		if (url.protocol !== "http:" && url.protocol !== "https:") return false;
		if (!AMAZON_HOST.test(url.hostname)) return false;
		const path = url.pathname;
		return path.includes("/checkout/p/") || path.includes("/gp/buy/thankyou/");
	} catch {
		return false;
	}
}

const pendingByTab = new Map();
const inFlight = new Set();

function scheduleCheckoutInjection(tabId, url) {
	if (!Number.isInteger(tabId) || tabId < 0) return;
	if (!isCheckoutMonitoringUrl(url)) return;

	const existing = pendingByTab.get(tabId);
	if (existing != null) clearTimeout(existing);

	const timeoutId = setTimeout(() => {
		pendingByTab.delete(tabId);
		void injectCheckoutMonitoringIfNeeded(tabId);
	}, 75);
	pendingByTab.set(tabId, timeoutId);
}

async function injectCheckoutMonitoringIfNeeded(tabId) {
	if (inFlight.has(tabId)) return;
	if (!chrome.scripting?.executeScript) return;

	inFlight.add(tabId);
	try {
		const tab = await chrome.tabs.get(tabId);
		if (!tab?.url || !isCheckoutMonitoringUrl(tab.url)) return;

		const probe = await chrome.scripting.executeScript({
			target: { tabId },
			func: () => globalThis.__VH_CHECKOUT_MONITORING_ACTIVE__ === true,
		});
		if (probe?.[0]?.result === true) return;

		await chrome.scripting.executeScript({
			target: { tabId },
			files: ["scripts/checkoutMonitoringLoader.js"],
		});
	} catch {
		// Tab may not be injectable yet (auth interstitial, prerender, etc.).
	} finally {
		inFlight.delete(tabId);
	}
}

function onNavigation(details) {
	if (details.frameId !== 0) return;
	scheduleCheckoutInjection(details.tabId, details.url);
}

/**
 * Firefox-only fallback: manifest content_scripts can miss checkout after POST
 * redirect chains or client-side URL updates. Chrome keeps manifest injection only.
 */
export function initCheckoutMonitoringFallback() {
	if (!chrome.webNavigation?.onCommitted) return;

	chrome.webNavigation.onCommitted.addListener(onNavigation);
	chrome.webNavigation.onHistoryStateUpdated?.addListener(onNavigation);
	chrome.webNavigation.onDOMContentLoaded?.addListener(onNavigation);
}
