if (typeof browser === "undefined") {
	var browser = chrome;
}

var Settings = null;
var Tpl = null;
var Env = null;
var CryptoKeys = null;
var ScreenNotification = null;
var Notifications = null;
// Factory function to load a module
(async () => {
	try {
		let module = null;
		//Load the SettingMgr.
		module = await import(chrome.runtime.getURL("/scripts/core/services/SettingsMgr.js"));
		Settings = new module.SettingsMgr();

		//Load the Template manager
		module = await import(chrome.runtime.getURL("/scripts/core/utils/Template.js"));
		Tpl = new module.Template();

		//Load the Environment
		module = await import(chrome.runtime.getURL("/scripts/core/services/Environment.js"));
		Env = new module.Environment();

		//Load the CryptoKeys
		module = await import(chrome.runtime.getURL("/scripts/core/utils/CryptoKeys.js"));
		CryptoKeys = new module.CryptoKeys();

		// Load screen notifier and initialize container for this page
		module = await import(chrome.runtime.getURL("/scripts/ui/components/ScreenNotifier.js"));
		ScreenNotification = module.ScreenNotification;
		Notifications = new module.ScreenNotifier();
	} catch (error) {
		console.error("Error loading module:", error);
	}
})();

var arrReview = [];
var arrTemplate = [];
var asin = null;
let reviewManagerInsertDone = false;
let reviewManagerInsertRunning = false;

/**
 * Resolves i18n strings; replaced in loadSettings() with Internationalization helpers
 * so Settings → locale override (e.g. forced English) applies on the review page.
 * @type {(key: string, fallback: string, substitutions?: string | string[]) => string}
 */
let resolveMessage = (key, fallback, substitutions) => {
	if (typeof chrome !== "undefined" && chrome.i18n && typeof chrome.i18n.getMessage === "function") {
		const msg = chrome.i18n.getMessage(key, substitutions);
		if (msg) {
			return msg;
		}
	}
	return fallback;
};

function getMessageOrDefault(key, fallback, substitutions) {
	return resolveMessage(key, fallback, substitutions);
}

/** Log a runtime error (review script runs alone, no shared showRuntime). */
function showRuntime(message) {
	console.error("[VHelper Review]", message);
}

window.addEventListener("locationchange", async () => {
	const url = new URL(window.location.href);
	const thankyou_asin = url.searchParams.get("asin");

	notifyServerOfReviewCompleted(thankyou_asin);
});

/**
 * Injects theme and review toolbar styles into the page.
 * Review script runs alone on review pages, so it must load the selected theme and toolbar CSS.
 */
function loadThemeAndStylesForReviewPage() {
	const theme = Settings.get("general.theme") || "forest";

	const themeMap = {
		forest: "resource/theme/forest.css",
		dark: "resource/theme/dark.css",
		aurora: "resource/theme/aurora.css",
		garish: "resource/theme/garish.css",
		midnight: "resource/theme/midnight.css",
		scifi: "resource/theme/scifi.css",
		win31: "resource/theme/win31.css",
	};

	function injectLink(href, media = null) {
		console.log("injectLink", href, media);
		const link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = chrome.runtime.getURL(href);
		if (media) link.setAttribute("media", media);
		document.head.appendChild(link);
	}

	injectLink(themeMap[theme] || themeMap.forest);

	injectLink("resource/css/notification.css");
	injectLink("resource/css/review.css");
}

async function loadSettings() {
	while (!Settings || !Settings.isLoaded()) {
		await new Promise((r) => setTimeout(r, 10));
	}

	// Apply locale override and set Template.js expected hook (replaces __MSG_xxx__ in templates)
	try {
		const i18n = await import(chrome.runtime.getURL("/scripts/core/services/Internationalization.js"));
		await i18n.initLocaleOverride(Settings.get("i18n.localeOverride"));
		window.__VH_GET_MESSAGE__ = i18n.getMessageForTemplate;
		resolveMessage = (key, fallback, substitutions) => i18n.getMessageOrDefault(key, fallback, substitutions);
	} catch (e) {
		console.warn("[VHelper Review] i18n init failed", e);
	}

	// Load theme and toolbar styles first so the toolbar is themed
	loadThemeAndStylesForReviewPage();

	//Enable the review submission marker system
	if (Settings.isPremiumUser(2) && Settings.get("general.reviewSubmissionMarker")) {
		//Inject the review_inj.js script to the "main world"
		const scriptTag = document.createElement("script");

		scriptTag.src = chrome.runtime.getURL("scripts/review_inj.js");
		scriptTag.onload = function () {
			this.remove();
		};

		(document.head || document.documentElement).appendChild(scriptTag);

		/*
		//Alternative method if the injected script is not working
		const submitButton = document.querySelector(
			".ryp-submit-button-desktop input[type='submit'], .ryp-submit-button-mobile input[type='submit']"
		);
		if (submitButton) {
			submitButton.addEventListener("click", () => {
				const reviewTitle = document.querySelector("#reviewTitle").value;
				const reviewContent = document.querySelector("#reviewText").value;
				const starClear = document.querySelector(".in-context-ryp__form-field--starRating--clear");
				if (!reviewTitle || !reviewContent || !starClear) {
					return;
				}

				const url = new URL(window.location.href);
				const thankyou_asin = url.searchParams.get("asin");
				notifyServerOfReviewCompleted(thankyou_asin);
			});
		}
		*/
	}

	//Enable the review toolbar system
	if (Settings.get("general.reviewToolbar")) {
		await initializeLocalStorageKeys("reviews", arrReview, []);
		await initializeLocalStorageKeys("reviews_templates", arrTemplate, []);

		init_review(); //We want to wait for the settings to be loaded before continuing
	}

	const { initVersionDebugLabel } = await import(
		chrome.runtime.getURL("/scripts/ui/components/VersionDebugLabel.js")
	);
	initVersionDebugLabel(Settings);
}

//Wait for the DOM+remote content to be loaded to begin the script
window.addEventListener("load", function () {
	console.log("Loading review system...");
	loadSettings();
});

async function initializeLocalStorageKeys(key, object, value, loadOnly) {
	try {
		const data = await chrome.storage.local.get(key);
		if (loadOnly || Object.keys(data).length > 0) {
			Object.assign(object, data[key]);
		} else {
			await chrome.storage.local.set({ [key]: value });
		}
	} catch (e) {
		showRuntime("Error in initializeLocalStorageKeys" + e.message);
	}
}

function init_review() {
	const currentUrl = window.location.href;

	const arrRegex = [
		/^(?:.+?).amazon\.(?:.+?)\/review\/create-review.*[?&]asin=([^&]+).*?$/,
		/^(?:.+?).amazon\.(?:.+?)\/review\/review-your-purchases.*[?&]asin=([^&]+).*$/,
		/^(?:.+?).amazon\.(?:.+?)\/reviews\/edit-review\/edit.*[?&]asin=([^&]+).*$/,
	];
	for (let i = 0; i < arrRegex.length; i++) {
		arrMatches = currentUrl.match(arrRegex[i]);
		if (arrMatches != null) {
			asin = arrMatches[1];
			console.log("URL Match confirmed for ASIN " + asin + ". Booting review toolbar...");
			boot_review();
			break;
		}
	}
}

async function boot_review() {
	scheduleReviewManagerInsert();

	//Wait for the template to be loaded
	while (!Tpl) {
		await new Promise((r) => setTimeout(r, 50));
	}

	//Load the toolbar template
	const prom = await Tpl.loadFile("/scripts/ui/templates/review_toolbar.html");
	Tpl.setVar("tpl_manage_url", chrome.runtime.getURL("/page/reviews_templates.html"));
	Tpl.setVar("review_manage_url", chrome.runtime.getURL("/page/reviews_manage.html"));
	Tpl.setVar("asin", asin);

	//Firefox seems to execute this script before the content (presumably loaded from a fetch request)
	//is available. Waiting 500ms seems to give time to the elements to exist.

	const reviewToolbar = Tpl.render(prom, true);
	let attempts = 0;
	while (attempts >= 0) {
		const mobileReviewInputsContainer = document.querySelector(".in-context-ryp__form_fields_container-mweb");
		const submitContainer = document.querySelector(
			".in-context-ryp__submit-button-frame-desktop, .in-context-ryp__submit-button-frame-mobile"
		);
		if (mobileReviewInputsContainer) {
			// For mobile, insert the toolbar inside the form fields container
			// so it doesn't take up the bottom half the screen
			mobileReviewInputsContainer.appendChild(reviewToolbar);
			break;
		} else if (submitContainer) {
			submitContainer.parentElement.insertBefore(reviewToolbar, submitContainer);
			break;
		} else {
			arrZone = document.querySelectorAll("form.ryp__review-form__form .ryp__card-frame");
			container = arrZone[arrZone.length - 1];
			if (container !== undefined) {
				container.parentNode.insertBefore(reviewToolbar, container.nextSibling);
				break;
			}
		}

		if (attempts > 20) {
			break; //Something is wrong, don't loop infinitely.
		} else {
			//Wait 100ms and try again
			await new Promise((r) => setTimeout(r, 100));
			attempts++;
		}
	}

	//Resize the review box
	const reviewTextarea = getReviewContentObject();
	if (reviewTextarea) {
		// Use ResizeObserver to detect textarea size changes
		const resizeObserver = new ResizeObserver((entries) => {
			for (const entry of entries) {
				if (entry.target === reviewTextarea) {
					if (reviewTextarea.style.height.includes("em")) {
						if (Settings.get("general.reviewTextareaHeight", false)) {
							reviewTextarea.style.height = Settings.get("general.reviewTextareaHeight");
						}
					} else {
						Settings.set("general.reviewTextareaHeight", reviewTextarea.style.height);
					}
				}
			}
		});

		// Start observing the textarea
		resizeObserver.observe(reviewTextarea);
	}

	//Add the template titles in the select box
	let selectBox = document.getElementById("template_name");
	let title = "";
	if (arrTemplate.length > 0) {
		for (let i = 0; i < arrTemplate.length; i++) {
			try {
				title = JSON.parse(arrTemplate[i].title);
				const option = document.createElement("option");
				option.value = arrTemplate[i].id;
				option.textContent = title;
				selectBox.appendChild(option);
			} catch (e) {
				console.log("some error in adding template error: " + e.message);
			}
		}
	} else {
		const option = document.createElement("option");
		option.value = "no_saved_templates";
		option.textContent = getMessageOrDefault("reviewNoSavedTemplates", "No Saved Templates");
		selectBox.appendChild(option);
	}

	//If the Insert button is clicked, insert the content of the selected
	//template into the review box.
	document.getElementById("insertTemplate").addEventListener("click", function () {
		let id = document.getElementById("template_name").value;
		for (let i = 0; i < arrTemplate.length; i++) {
			if (arrTemplate[i].id == id) {
				let title = getReviewTitleObject();
				let review = getReviewContentObject();
				try {
					title.value += JSON.parse(arrTemplate[i].title);
					review.value += JSON.parse(arrTemplate[i].content);
				} catch (e) {
					showRuntime("Error with insertTemplate listener: " + e.message);
				}

				return;
			}
		}
	});

	//Load review button
	document.getElementById("loadReview").addEventListener("click", async function () {
		let index = arrReview.findIndex((review) => review.asin === asin);
		if (index > -1) {
			// Check if there is already content in the review title or content fields
			let currentTitle = getReviewTitleObject().value;
			let currentContent = getReviewContentObject().value;

			let shouldOverwrite = true;
			if (currentTitle || currentContent) {
				const msg =
					(typeof window.__VH_GET_MESSAGE__ === "function" &&
						window.__VH_GET_MESSAGE__("reviewOverwriteConfirm")) ||
					getMessageOrDefault(
						"reviewOverwriteConfirm",
						"Loading a review will overwrite your current title and content. Continue?"
					);
				shouldOverwrite = window.confirm(msg);
			}

			if (shouldOverwrite) {
				let reviewTitle = JSON.parse(arrReview[index].title);
				let reviewContent = JSON.parse(arrReview[index].content);
				getReviewTitleObject().value = reviewTitle;
				getReviewContentObject().value = reviewContent;
			}
		}
		return;
	});

	//Save review button
	document.getElementById("saveReview").addEventListener("click", async function () {
		let found = false;

		//Check if the review title is empt
		let reviewTitle = getReviewTitleObject().value;

		let reviewContent = getReviewContentObject().value;

		if (!reviewTitle || !reviewContent) {
			const msg =
				(typeof window.__VH_GET_MESSAGE__ === "function" &&
					window.__VH_GET_MESSAGE__("reviewSaveFillTitleContent")) ||
				getMessageOrDefault(
					"reviewSaveFillTitleContent",
					"Please fill in the review title and content in order to save the review."
				);
			alert(msg);
			return;
		}

		let index = arrReview.findIndex((review) => review.asin === asin);
		if (index > -1) {
			arrReview[index].date = new Date().toString();
			arrReview[index].title = JSON.stringify(reviewTitle);
			arrReview[index].content = JSON.stringify(reviewContent);
			found = true;
		}
		if (!found) {
			arrReview.push({
				asin: asin,
				date: new Date().toString(),
				title: JSON.stringify(getReviewTitleObject().value),
				content: JSON.stringify(getReviewContentObject().value),
			});

			//Limit the saved array to the configured max. Delete older ones.
			const maxReviews = Math.max(1, parseInt(Settings.get("general.reviewToolbarMaxReviews", 100), 10) || 100);
			if (arrReview.length > maxReviews) {
				arrReview.splice(0, arrReview.length - maxReviews);
			}
		}
		try {
			await chrome.storage.local.set({ reviews: arrReview });
			const messageDiv = document.getElementById("save-message");
			messageDiv.style.display = "block";
			setTimeout(() => {
				messageDiv.style.display = "none";
			}, 3000);
		} catch (e) {
			showRuntime("Error saving review: " + e.message);
		}
	});

	//Insert div after the review title (reviewTitle)
	const reviewTitleInput = document.getElementById("reviewTitle");
	if (reviewTitleInput) {
		const div = document.createElement("div");
		div.id = "reviewTitleDiv";
		div.style.float = "right";
		div.style.marginBottom = "20px";
		div.textContent = "0 / 100";
		reviewTitleInput.insertAdjacentElement("afterend", div);
		reviewTitleInput.addEventListener("keyup", () => {
			const chrCount = reviewTitleInput.value.length;
			const reviewTitleDiv = document.getElementById("reviewTitleDiv");
			reviewTitleDiv.textContent = chrCount + " / 100";
		});
	}

	// Initialize the bulk media upload drop zone (click-to-pick + drag & drop).
	// Must be called after the toolbar template is confirmed injected above.
	addBulkMediaUpload();

	scheduleReviewManagerInsert();
}

/**
 * Wait for Review Manager insert queue and apply when Amazon's React form is ready.
 */
function scheduleReviewManagerInsert() {
	if (!asin) {
		return;
	}
	applyQueuedReviewInsert().catch((e) => console.warn("[VHelper Review] Insert queue failed:", e));
	// React may hydrate after our toolbar; retry until applied or timeout.
	const delays = [500, 1200, 2500, 4500, 7000, 10000];
	for (const ms of delays) {
		setTimeout(() => {
			applyQueuedReviewInsert().catch(() => undefined);
		}, ms);
	}
}

/**
 * Set value on React-controlled inputs (Amazon create-review page).
 * @param {HTMLInputElement|HTMLTextAreaElement} element
 * @param {string} value
 */
function setReactInputValue(element, value) {
	if (!element || value == null) {
		return;
	}
	const text = String(value);
	const prototype =
		element.tagName === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
	const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
	if (descriptor?.set) {
		descriptor.set.call(element, text);
	} else {
		element.value = text;
	}
	element.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
	element.dispatchEvent(new Event("change", { bubbles: true }));

	try {
		element.focus();
		element.select?.();
		if (document.execCommand("insertText", false, text)) {
			element.dispatchEvent(new InputEvent("input", { bubbles: true }));
		}
	} catch {
		// ignore
	}
}

/**
 * @returns {Promise<boolean>}
 */
function waitForReviewFormReady(timeoutMs = 20000) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			const content = document.getElementById("reviewText");
			const title = document.getElementById("reviewTitle");
			const stars = document.querySelectorAll(
				'[data-testid="in-context-ryp__form-field--starRating-single"], .in-context-ryp__form-field--starRating-single[role="radio"]'
			);
			if (content && title && stars.length >= 5) {
				resolve(true);
				return;
			}
			if (Date.now() - start >= timeoutMs) {
				resolve(false);
				return;
			}
			requestAnimationFrame(tick);
		};
		tick();
	});
}

/**
 * Prefill Amazon review form from Review Manager insert queue.
 */
async function loadPendingReviewInsertPayload(targetAsin) {
	const { getPendingReviewInsert } = await import(
		chrome.runtime.getURL("/scripts/review-manager/ReviewInsertBridge.js")
	);
	const { peekReviewInsert } = await import(chrome.runtime.getURL("/scripts/review-manager/ReviewInsertQueue.js"));

	const fromStorage = await getPendingReviewInsert(targetAsin);
	const fromQueue = await peekReviewInsert(targetAsin);

	if (fromStorage && fromQueue) {
		return {
			stars: fromStorage.stars ?? fromQueue.stars ?? 5,
			reviewTitle: fromStorage.reviewTitle || fromQueue.reviewTitle || "",
			reviewContent: fromStorage.reviewContent || fromQueue.reviewContent || "",
			imageFiles: fromQueue.imageFiles || [],
		};
	}
	if (fromStorage) {
		return {
			stars: fromStorage.stars ?? 5,
			reviewTitle: fromStorage.reviewTitle || "",
			reviewContent: fromStorage.reviewContent || "",
			imageFiles: [],
		};
	}
	return fromQueue;
}

async function clearPendingReviewInsertPayload(targetAsin) {
	const { clearPendingReviewInsert } = await import(
		chrome.runtime.getURL("/scripts/review-manager/ReviewInsertBridge.js")
	);
	const { removeReviewInsert } = await import(chrome.runtime.getURL("/scripts/review-manager/ReviewInsertQueue.js"));
	await clearPendingReviewInsert(targetAsin);
	await removeReviewInsert(targetAsin);
}

async function applyQueuedReviewInsert() {
	if (!asin || reviewManagerInsertDone || reviewManagerInsertRunning) {
		return;
	}
	reviewManagerInsertRunning = true;
	try {
		const payload = await loadPendingReviewInsertPayload(asin);
		if (!payload) {
			return;
		}

		const ready = await waitForReviewFormReady();
		if (!ready) {
			return;
		}

		const titleEl = getReviewTitleObject();
		const contentEl = getReviewContentObject();

		if (titleEl && payload.reviewTitle) {
			setReactInputValue(titleEl, payload.reviewTitle);
		}
		if (contentEl && payload.reviewContent) {
			setReactInputValue(contentEl, payload.reviewContent);
		}

		setAmazonStarRating(payload.stars || 5);

		await new Promise((r) => setTimeout(r, 200));

		const titleFilled = !payload.reviewTitle || (titleEl && titleEl.value.trim().length > 0);
		const contentFilled = !payload.reviewContent || (contentEl && contentEl.value.trim().length > 0);
		if (!titleFilled && !contentFilled) {
			return;
		}

		if (payload.imageFiles?.length) {
			const dropZone = document.getElementById("vh-bulk-media-drop-zone");
			await processBulkMediaFiles(payload.imageFiles, dropZone);
		}

		await clearPendingReviewInsertPayload(asin);
		reviewManagerInsertDone = true;
		showToast("Review draft inserted from Review Manager.");
	} catch (e) {
		console.warn("[VHelper Review] Insert queue failed:", e);
	} finally {
		reviewManagerInsertRunning = false;
	}
}

/**
 * @param {number} stars 1–5
 */
function setAmazonStarRating(stars) {
	const n = Math.min(5, Math.max(1, Number(stars) || 5));
	const field = document.querySelector(".in-context-ryp__form-field--starRating, [class*='starRating']");
	if (!field) {
		return false;
	}

	// Modern Vine create-review (React): role="radio" star spans
	const starSpans = field.querySelectorAll(
		'[data-testid="in-context-ryp__form-field--starRating-single"], .in-context-ryp__form-field--starRating-single[role="radio"]'
	);
	if (starSpans.length >= n) {
		const target = starSpans[n - 1];
		target.focus();
		target.click();
		target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
		return true;
	}

	const radios = field.querySelectorAll('input[type="radio"]');
	if (radios.length >= n) {
		radios[n - 1].click();
		return true;
	}

	const buttons = field.querySelectorAll("button, [role='button']");
	if (buttons.length >= n) {
		buttons[n - 1].click();
		return true;
	}

	return false;
}
/**
 * Displays a short-lived notification using the extension's ScreenNotifier.
 *
 * @param {string} msg - The message text to display.
 */
async function showToast(msg) {
	if (!ScreenNotification || !Notifications) {
		// Fail safe if module loading is still in progress on first interaction.
		console.warn("[VHelper Review] ScreenNotifier not ready, skipping toast:", msg);
		return;
	}

	console.log("Showing toast:", msg);

	const note = new ScreenNotification({
		title: msg,
		content: "",
		title_only: true,
		lifespan: 10,
	});
	await Notifications.pushNotification(note);
}

/** @type {typeof import("./review/AmazonMediaUploadSync.js") | null} */
let amazonMediaUploadSyncModule = null;

async function loadAmazonMediaUploadSync() {
	if (!amazonMediaUploadSyncModule) {
		amazonMediaUploadSyncModule = await import(chrome.runtime.getURL("/scripts/review/AmazonMediaUploadSync.js"));
	}
	return amazonMediaUploadSyncModule;
}

/**
 * Sequentially injects an array of File objects into Amazon's native media
 * file input using DataTransfer, dispatching a synthetic 'change' event per
 * file to trigger Amazon's internal upload handler.
 *
 * Each file waits until Amazon's uploader finishes (spinner clears / preview
 * appears) before the next file is injected so mixed image+video batches keep
 * the editor order instead of faster images jumping ahead.
 *
 * NOTE: Amazon occasionally updates the media input selector. If uploads stop
 * working, the querySelector in this function is the first place to check.
 *
 * @param {File[]} files     - Array of image/video File objects to upload.
 * @param {HTMLElement} dropZone - The drop zone element; used to show live progress.
 */
async function processBulkMediaFiles(files, dropZone) {
	if (!files.length) return;

	// Locate Amazon's native file input (Vine create-review uses #media)
	const fileInput =
		document.querySelector("#media") ||
		document.querySelector('input[type="file"][accept*="image"], input[type="file"][accept*="video"]');
	if (!fileInput) {
		alert(
			getMessageOrDefault(
				"reviewMediaUploaderNotFound",
				"Media uploader not found. Make sure the photo/video section is visible on the review form."
			)
		);
		return;
	}

	const {
		getAmazonMediaUploadRoot,
		beginAmazonMediaUpload,
		ensureAmazonMediaUploadHook,
		waitForAmazonMediaUploadSettle,
	} = await loadAmazonMediaUploadSync();
	const mediaRoot = getAmazonMediaUploadRoot(fileInput);
	await ensureAmazonMediaUploadHook();

	const dropLabel = dropZone ? dropZone.querySelector("#vh-bulk-media-drop-label") : null;
	const originalLabel = dropLabel ? dropLabel.textContent : "";

	for (let i = 0; i < files.length; i++) {
		const file = files[i];
		const isVideo = file.type.startsWith("video/");
		const session = beginAmazonMediaUpload(file);

		if (dropLabel) {
			dropLabel.textContent = getMessageOrDefault("reviewMediaUploadProgress", "Uploading $1$ / $2$: $3$", [
				String(i + 1),
				String(files.length),
				file.name,
			]);
		}

		const dt = new DataTransfer();
		dt.items.add(file);
		fileInput.files = dt.files;
		fileInput.dispatchEvent(new Event("change", { bubbles: true }));

		if (dropLabel) {
			const waitingKey = isVideo ? "reviewMediaUploadWaitingVideo" : "reviewMediaUploadWaitingImage";
			const waitingFallback = isVideo
				? "Waiting for video to finish on Amazon ($1$ / $2$)…"
				: "Waiting for image to finish on Amazon ($1$ / $2$)…";
			dropLabel.textContent = getMessageOrDefault(waitingKey, waitingFallback, [
				String(i + 1),
				String(files.length),
			]);
		}

		const result = await waitForAmazonMediaUploadSettle(mediaRoot, file, { session });
		if (!result.ok) {
			console.warn(`[VHelper Review] Media upload wait timed out for ${file.name}; continuing with next file.`);
		}
	}

	if (dropLabel) {
		dropLabel.textContent = originalLabel;
	}

	showToast(getMessageOrDefault("reviewMediaUploadComplete", "$1$ file(s) uploaded", [String(files.length)]));
}

/**
 * Initializes the bulk media upload feature on the #vh-bulk-media-drop-zone
 * element rendered by review_toolbar.html. Must be called after the toolbar
 * template has been successfully injected into the DOM (end of boot_review()).
 *
 * Supports two input methods:
 *  - Click: opens a multi-file picker filtered to image/* and video/*
 *  - Drag & Drop: accepts files dragged directly from the OS file manager
 *
 * Both paths delegate to processBulkMediaFiles() for sequential upload.
 * Non-image/video files dropped onto the zone are silently filtered out.
 */
function addBulkMediaUpload() {
	const dropZone = document.getElementById("vh-bulk-media-drop-zone");
	if (!dropZone) {
		// Drop zone element not found — toolbar injection may have failed
		console.error("Bulk media drop zone (#vh-bulk-media-drop-zone) not found in DOM.");
		return;
	}

	// ── Click to open file picker ────────────────────────────────────────────
	const hiddenPhotoInput = document.createElement("input");
	hiddenPhotoInput.type = "file";
	hiddenPhotoInput.multiple = true;
	hiddenPhotoInput.accept = "image/*,video/*";
	hiddenPhotoInput.onchange = () => {
		processBulkMediaFiles(Array.from(hiddenPhotoInput.files), dropZone);
	};
	dropZone.addEventListener("click", () => {
		hiddenPhotoInput.click();
	});

	// ── Drag over: highlight drop zone ──────────────────────────────────────
	dropZone.addEventListener("dragover", (e) => {
		e.preventDefault(); // Required to permit the drop event to fire
		e.stopPropagation();
		dropZone.classList.add("vh-bulk-media-drop-zone--active");
	});

	// ── Drag leave: remove highlight ────────────────────────────────────────
	dropZone.addEventListener("dragleave", (e) => {
		e.preventDefault();
		e.stopPropagation();
		dropZone.classList.remove("vh-bulk-media-drop-zone--active");
	});

	// ── Drop: filter to valid types and process ──────────────────────────────
	dropZone.addEventListener("drop", (e) => {
		e.preventDefault();
		e.stopPropagation();
		dropZone.classList.remove("vh-bulk-media-drop-zone--active");

		// Filter dropped items — reject anything that isn't image or video
		const files = Array.from(e.dataTransfer.files).filter(
			(f) => f.type.startsWith("image/") || f.type.startsWith("video/")
		);

		if (!files.length) {
			showToast(getMessageOrDefault("reviewMediaNoValidFiles", "No valid image or video files found."));
			return;
		}

		processBulkMediaFiles(files, dropZone);
	});
}

function getReviewTitleObject() {
	let reviewTitle;
	reviewTitle = document.getElementById("reviewTitle");
	if (reviewTitle == undefined) {
		return document.getElementById("scarface-review-title-label");
	}
	return reviewTitle;
}

function getReviewContentObject() {
	const direct = document.getElementById("reviewText");
	if (direct && direct.tagName === "TEXTAREA") {
		return direct;
	}
	const nested = document.querySelector("#reviewText textarea");
	if (nested) {
		return nested;
	}
	const legacy = document.getElementById("scarface-review-text-card-title");
	return legacy || direct;
}

async function notifyServerOfReviewCompleted(asin) {
	//Wait for the settings to be loaded
	while (!Settings || !Settings.isLoaded()) {
		await new Promise((r) => setTimeout(r, 10));
	}

	if (!Settings.isPremiumUser(2)) {
		return;
	}

	//Update the server with the new ETV
	const content = {
		api_version: 5,
		app_version: Env.data.appVersion,
		action: "record_review",
		country: await Settings.get("general.country", false),
		uuid: await Settings.get("general.uuid", false),
		fid: await Settings.get("general.fingerprint.id", false),
		cid: await Settings.get("general.cid", false),
		asin: asin,
		done: true,
	};
	const s = await CryptoKeys.signData(content);
	content.s = s;
	content.pk = await CryptoKeys.getExportedPublicKey();

	// Perform your fetch
	await fetch(Env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(content),
	})
		.then((response) => response.json())
		.then((data) => {
			// Your fetch completed successfully
			console.log("Fetch completed:", data);
		})
		.catch((error) => {
			console.error("Fetch failed:", error);
		});
}
