/**
 * Monitor V4 — Amazon telemetry silencer (main world).
 *
 * Monitor V4 runs on an Amazon page (/vine/resources#vh-monitor), then replaces
 * the page body with the React app. Amazon's header/nav JavaScript may already
 * be running in memory and keeps trying to update flyouts and log analytics
 * warnings (e.g. "MIX C004", "Candidate root not found"). Those warnings are
 * harmless but noisy in the console.
 *
 * This script re-applies the same silencing as inj_preboot.js, right before
 * the bootloader tears down the host page. It is loaded as an external file
 * (not inline) because Amazon's Content-Security-Policy blocks inline scripts
 * at document_end.
 *
 * Loaded once from bootloader.js → silenceAmazonMonitorTelemetryInPage().
 *
 * What we do (and what we deliberately avoid):
 * - Stub mix_csa so Prime flyout analytics never fire.
 * - Wrap ue.log / ue.logError / window.ueLogError to drop known-harmless messages.
 * - Patch jQuery globalEval to skip inline MIX scripts.
 * - We do NOT replace or trap window.ue — that breaks Amazon bootstrap (ue.viz, etc.).
 */
(function () {
	if (window.__VH_MONITOR_SILENCE__) return;
	window.__VH_MONITOR_SILENCE__ = true;

	/** Amazon CSM messages we intentionally swallow on the monitor host page. */
	const SILENT = /MIX C004|Candidate root not found|Could not register card/i;
	const noop = () => {};

	/** Wrap a logging function: pass everything through except SILENT messages. */
	const wrapLog = (fn) => {
		if (typeof fn !== "function") return noop;
		return function (msg, ...rest) {
			const text = typeof msg === "string" ? msg : msg?.m || "";
			if (SILENT.test(text)) return;
			return fn.call(this, msg, ...rest);
		};
	};

	/** Patch ue.log and ue.logError on the real Amazon object (never replace ue itself). */
	const wrapUeInPlace = (ue) => {
		if (!ue || typeof ue !== "object") return;
		if (typeof ue.logError === "function" && !ue.logError.__vhWrapped) {
			ue.logError = wrapLog(ue.logError);
			ue.logError.__vhWrapped = true;
		}
		if (typeof ue.log === "function" && !ue.log.__vhWrapped) {
			const origLog = ue.log;
			ue.log = function (...args) {
				const text = typeof args[0] === "string" ? args[0] : args[0]?.m || "";
				if (SILENT.test(text)) return;
				return origLog.apply(this, args);
			};
			ue.log.__vhWrapped = true;
		}
	};

	// Prime flyout analytics call this; a no-op prevents MIX C004 entirely.
	try {
		Object.defineProperty(window, "mix_csa", {
			configurable: true,
			get: () => noop,
			set: () => {},
		});
	} catch {
		window.mix_csa = noop;
	}

	if (window.ue) wrapUeInPlace(window.ue);

	// Amazon may assign window.ue / window.ueLogError after this script runs.
	const uePoll = window.setInterval(() => {
		if (window.ue) wrapUeInPlace(window.ue);
		if (typeof window.ueLogError === "function" && !window.ueLogError.__vhWrapped) {
			window.ueLogError = wrapLog(window.ueLogError);
			window.ueLogError.__vhWrapped = true;
		}
	}, 50);
	window.setTimeout(() => window.clearInterval(uePoll), 60_000);

	// Block jQuery from eval-ing inline MIX scripts injected via .html() / flyout AJAX.
	const $ = window.jQuery || window.$;
	if ($?.globalEval && !$.globalEval.__vhPatched) {
		const origEval = $.globalEval;
		$.globalEval = function (code) {
			if (typeof code === "string" && /mix_csa|mix_d|PrimeAcquisition|MIX[\s_]/i.test(code)) return;
			return origEval.apply(this, arguments);
		};
		$.globalEval.__vhPatched = true;
	}
})();
