//Load the bootloader file as a module
(async () => {
	try {
		await import(chrome.runtime.getURL("./scripts/bootloader.js"));
	} catch (error) {
		console.error("Error loading module:", error);
		console.trace();
		const { reportMobileLoaderFailure } = await import(
			chrome.runtime.getURL("./scripts/core/utils/MobileBootError.js")
		);
		await reportMobileLoaderFailure("bootloader.js", error);
	}
})();
