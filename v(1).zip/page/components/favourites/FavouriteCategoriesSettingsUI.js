/**
 * Settings UI for managing favourite Vine subcategories (reorder, delete).
 *
 * @module FavouriteCategoriesSettingsUI
 */

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import {
	getFavouriteCategories,
	moveFavourite,
	removeFavourite,
	formatFavouriteLabel,
} from "/scripts/core/utils/FavouriteCategoriesManager.js";
import { confirmPrompt } from "/page/components/dialogs/DialogUtils.js";

const Settings = new SettingsMgr();
const LIST_ID = "vh-favourite-categories-list";
const EMPTY_ID = "vh-favourite-categories-empty";

/**
 * Initialize the favourite-categories list in the Notifications settings tab.
 *
 * @example
 * initFavouriteCategoriesSettingsUI();
 */
export function initFavouriteCategoriesSettingsUI() {
	const list = document.getElementById(LIST_ID);
	if (!list) return;
	renderFavouriteCategoriesList();
	Settings.addSettingsChangeObserver(() => renderFavouriteCategoriesList());
}

/**
 * Re-render the favourite-categories list from current settings.
 *
 * @example
 * renderFavouriteCategoriesList();
 */
export function renderFavouriteCategoriesList() {
	const list = document.getElementById(LIST_ID);
	const empty = document.getElementById(EMPTY_ID);
	if (!list) return;

	const favourites = getFavouriteCategories(Settings);
	list.innerHTML = "";

	if (empty) {
		empty.style.display = favourites.length ? "none" : "block";
	}

	favourites.forEach((fav, index) => {
		const row = document.createElement("div");
		row.className = "vh-favourite-category-row";

		const reorderLegend = document.createElement("div");
		reorderLegend.className = "vh-favourite-category-reorder";

		const downDisabled = index === favourites.length - 1;
		const downBtn = createReorderButton(
			"down",
			downDisabled,
			getMessageOrDefault("pageSettingsNotificationsFavMoveDown", "Move down"),
			async () => {
				await moveFavourite(Settings, index, 1);
				renderFavouriteCategoriesList();
			}
		);

		const upDisabled = index === 0;
		const upBtn = createReorderButton(
			"up",
			upDisabled,
			getMessageOrDefault("pageSettingsNotificationsFavMoveUp", "Move up"),
			async () => {
				await moveFavourite(Settings, index, -1);
				renderFavouriteCategoriesList();
			}
		);

		reorderLegend.appendChild(downBtn);
		reorderLegend.appendChild(upBtn);

		const label = document.createElement("span");
		label.className = "vh-favourite-category-label";
		label.textContent = formatFavouriteLabel(fav);

		const deleteBtn = document.createElement("div");
		deleteBtn.className = "vh-button-icon-compact vh-icon-only-button vh-button-delete";
		deleteBtn.title = getMessageOrDefault("pageSettingsNotificationsFavDelete", "Delete");
		deleteBtn.setAttribute("role", "button");
		deleteBtn.tabIndex = 0;
		const deleteInner = document.createElement("div");
		deleteInner.className = "button-inner vh-icon-trash";
		deleteBtn.appendChild(deleteInner);

		const categoryLabel = formatFavouriteLabel(fav);
		deleteBtn.addEventListener("click", async () => {
			const ok = await confirmPrompt(
				getMessageOrDefault(
					"pageSettingsNotificationsFavDeleteConfirm",
					'Remove "$1$" from your favourite categories?',
					[categoryLabel]
				)
			);
			if (ok) {
				await removeFavourite(Settings, index);
				renderFavouriteCategoriesList();
			}
		});

		row.appendChild(reorderLegend);
		row.appendChild(label);
		row.appendChild(deleteBtn);
		list.appendChild(row);
	});
}

/**
 * @param {"up" | "down"} direction
 * @param {boolean} disabled
 * @param {string} title
 * @param {() => void | Promise<void>} onClick
 * @returns {HTMLDivElement}
 */
function createReorderButton(direction, disabled, title, onClick) {
	const btn = document.createElement("div");
	btn.className = `vh-button-icon-compact vh-icon-only-button keyword-group-reorder-button ${
		disabled ? "keyword-group-reorder-button-disabled" : "keyword-group-reorder-button-enabled"
	}`;
	btn.title = title;
	btn.setAttribute("role", "button");
	btn.tabIndex = disabled ? -1 : 0;
	const inner = document.createElement("div");
	inner.className = "button-inner keyword-group-reorder-button-inner";
	inner.textContent = direction === "down" ? "↓" : "↑";
	btn.appendChild(inner);
	if (!disabled) {
		btn.addEventListener("click", onClick);
	}
	return btn;
}
