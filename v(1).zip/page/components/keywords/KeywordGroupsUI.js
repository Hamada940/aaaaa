/**
 * @fileoverview KeywordGroupsUI - Orchestrates the keyword groups UI
 *
 * This module handles:
 * - Wiring container and button handlers (Add, Import/Export, Load/Save server)
 * - Delegating list rendering to KeywordGroupsList (which uses KeywordGroupCard, KeywordTable, etc.)
 * - Saving keywords, moving groups, showing add/note dialogs
 * - Import/export and legacy migration
 */

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { Environment } from "/scripts/core/services/Environment.js";
const env = new Environment();

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
const cryptoKeys = new CryptoKeys();

import {
	getGroups,
	getGroupById,
	addGroup,
	updateGroup,
	deleteGroup,
	reorderGroups,
	deleteKeywordFromGroup,
	migrateOldKeywordsToGroups,
	normalizeCommunityLink,
	isGroupCollapsed,
} from "/scripts/core/utils/KeywordGroupsManager.js";

import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { confirmPrompt, selectKeywordTypePrompt, displayMultiLinePopup } from "../dialogs/DialogUtils.js";
import { setupKeywordRowDragHandlers, initKeywordDragAndDrop } from "./KeywordDragAndDrop.js";
import { renderKeywordGroupsList } from "./KeywordGroupsList.js";
import { showAddGroupDialog as showAddGroupDialogComponent } from "./AddGroupDialog.js";
import { showKeywordNoteDialog as showKeywordNoteDialogComponent } from "./KeywordNoteDialog.js";
import {
	buildKeywordGroupsExport,
	validateKeywordGroupsImport,
	importKeywordGroups,
} from "./keywordGroupsExportImport.js";
import {
	initCommunityKeywordListsUI,
	handleCommunityUploadClick,
	handleCommunityDownloadClick,
	handleCommunityGroupDelete,
	hasCommunityListUpdate,
	refreshCommunityListUpdates,
} from "./communityKeywordListsUI.js";

export { showAddGroupDialogComponent as showAddGroupDialog };

/**
 * Main function to manage keyword groups UI
 */
export async function manageKeywordGroups() {
	const container = document.getElementById("keywordGroupsContainer");
	if (!container) return;

	const addButton = document.getElementById("addKeywordGroup");
	if (addButton && !addButton._VHelperClickHandler) {
		addButton._VHelperClickHandler = async () => {
			const result = await showAddGroupDialogComponent({ isPremiumBlur: Settings.isPremiumUser(2) });
			if (result) {
				await addGroup(Settings, result.name, result.type);
				await renderKeywordGroups();
				chrome.runtime.sendMessage({ action: "keywordsUpdated" });
			}
		};
		addButton.addEventListener("click", addButton._VHelperClickHandler);
	}

	// Import JSON handler
	const importJSONButton = document.getElementById("bulkImportJSONkeywordGroups");
	if (importJSONButton && !importJSONButton._VHelperClickHandler) {
		importJSONButton._VHelperClickHandler = async () => {
			displayMultiLinePopup(
				"",
				getMessageOrDefault("kwImportPastePlaceholder", "Paste your JSON content here..."),
				getMessageOrDefault("kwImportButtonLabel", "Import JSON"),
				async (data) => {
					try {
						const json = JSON.parse(data);

						// Check if this is the new format (keyword groups) or legacy format (array of keywords)
						if (Array.isArray(json) && json.length > 0) {
							const firstItem = json[0];
							// Legacy format detection: array of strings (blur) or objects with contains property (highlight/hide)
							if (typeof firstItem === "string" || firstItem.contains !== undefined) {
								// Legacy format - array of keyword objects or strings
								// Ask user to select the keyword type
								const legacyPromptMsg = getMessageOrDefault(
									"kwImportLegacyPrompt",
									`This appears to be legacy keyword format (${json.length} keyword(s)). Please select the keyword type for these keywords:`,
									[String(json.length)]
								);
								const keywordType = await selectKeywordTypePrompt(
									legacyPromptMsg.replace(/\n/g, "<br/>")
								);

								if (!keywordType) {
									// User cancelled
									return false;
								}

								// Convert to new keyword groups format using the same logic as convertLegacyKeywordsToGroups
								const legacyKeywords = json;

								// Convert old format to new format (same logic as convertLegacyKeywordsToGroups)
								const keywords = legacyKeywords.map((kw) => {
									if (typeof kw === "string") {
										return { contains: kw };
									}
									return kw;
								});

								// Create a group for the imported legacy keywords
								const typeLabel = keywordType.charAt(0).toUpperCase() + keywordType.slice(1);
								const groupName = `Imported Legacy ${typeLabel} Keywords (${new Date().toLocaleDateString()})`;
								const group = await addGroup(Settings, groupName, keywordType);
								await updateGroup(Settings, group.id, { keywords });

								await renderKeywordGroups();
								// Notify service worker to refresh context menu
								chrome.runtime.sendMessage({ action: "keywordsUpdated" });
								alert(
									getMessageOrDefault(
										"kwImportLegacySuccess",
										`Successfully converted and imported ${legacyKeywords.length} legacy keyword(s) as a ${keywordType} keyword group.`,
										[String(legacyKeywords.length), keywordType]
									)
								);
								return true;
							}
						}

						const validated = validateKeywordGroupsImport(json);
						if (!validated.valid) {
							alert(getMessageOrDefault(validated.errorKey, validated.error));
							return false;
						}

						await importKeywordGroups(Settings, validated.keywordGroups);

						await renderKeywordGroups();
						// Notify service worker to refresh context menu
						chrome.runtime.sendMessage({ action: "keywordsUpdated" });
						alert(
							getMessageOrDefault(
								"kwImportSuccess",
								`Successfully imported ${json.keywordGroups.length} keyword groups.`,
								[String(json.keywordGroups.length)]
							)
						);
						return true;
					} catch (err) {
						alert(
							getMessageOrDefault("kwImportJsonError", "JSON data incomplete or invalid: ") + err.message
						);
						return false;
					}
				}
			);
		};
		importJSONButton.addEventListener("click", importJSONButton._VHelperClickHandler);
	}

	// Export JSON handler
	const exportJSONButton = document.getElementById("bulkExportJSONkeywordGroups");
	if (exportJSONButton && !exportJSONButton._VHelperClickHandler) {
		exportJSONButton._VHelperClickHandler = async () => {
			const groups = await getGroups(Settings);
			const exportData = buildKeywordGroupsExport(groups);
			displayMultiLinePopup(JSON.stringify(exportData, null, 2), "", null, null, {
				copyTooltip: getMessageOrDefault("kwImportCopyTooltip", "Copy Export JSON Keyword Groups to Clipboard"),
			});
		};
		exportJSONButton.addEventListener("click", exportJSONButton._VHelperClickHandler);
	}

	// Import Legacy Keywords handler
	const importLegacyButton = document.getElementById("importLegacyKeywords");
	if (importLegacyButton && !importLegacyButton._VHelperClickHandler) {
		importLegacyButton._VHelperClickHandler = async () => {
			const shouldImport = await confirmPrompt(
				"This will migrate any legacy keywords (highlight, hide, and blur) stored in your settings to the new keyword groups format.<br/><br/>" +
					"Existing keyword groups will be preserved, and legacy keywords will be merged into the appropriate groups (Highlight Keywords, Hide Keywords, or Blur Keywords).<br/><br/>" +
					"Duplicate keywords will be automatically removed.<br/><br/>" +
					"Continue with migration?"
			);

			if (!shouldImport) {
				return;
			}

			try {
				// Call the migration function which will merge legacy keywords
				const migrationResult = await migrateOldKeywordsToGroups(Settings, null);

				if (migrationResult && migrationResult.migrationPerformed) {
					await renderKeywordGroups();
					// Notify service worker to refresh context menu
					chrome.runtime.sendMessage({ action: "keywordsUpdated" });
					alert(
						"Successfully migrated legacy keywords to keyword groups. Existing groups were preserved and keywords were merged."
					);
				} else {
					alert(
						"No legacy keywords found to migrate. All keywords have already been migrated or no legacy keywords exist."
					);
				}
			} catch (error) {
				console.error("Error migrating legacy keywords:", error);
				alert("Error migrating legacy keywords: " + error.message);
			}
		};
		importLegacyButton.addEventListener("click", importLegacyButton._VHelperClickHandler);
	}

	/**
	 * Fetches keywords from server for a specific type
	 * @param {string} keywordType - The keyword type ("highlight", "hidden", or "blur")
	 * @returns {Promise<Array>} Array of keywords or empty array if error
	 */
	async function fetchKeywordsFromServer(keywordType) {
		try {
			const content = {
				api_version: 5,
				app_version: env.data.appVersion,
				action: "get_keywords",
				country: Settings.get("general.country", false),
				uuid: Settings.get("general.uuid", false),
				cid: await env.getCID(),
				keywords: keywordType,
			};
			const s = await cryptoKeys.signData(content);
			content.s = s;
			content.pk = await cryptoKeys.getExportedPublicKey();

			const response = await fetch(env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			});
			const data = await response.json();

			// Return keywords array if it exists and is in legacy format
			// Blur keywords are just arrays of strings: ["cat", "dog"]
			// Highlight/hide keywords are arrays of objects: [{contains: "cat"}, {contains: "dog"}]
			if (data.keywords && Array.isArray(data.keywords) && data.keywords.length > 0) {
				// Check if it's an array of strings (blur) or objects with contains property (highlight/hide)
				const firstItem = data.keywords[0];
				if (typeof firstItem === "string" || firstItem.contains !== undefined) {
					return data.keywords;
				}
			}
			return [];
		} catch (error) {
			console.error(`Error fetching ${keywordType} keywords:`, error);
			return [];
		}
	}

	/**
	 * Converts legacy keyword format from server response to keyword groups
	 * @param {Array} highlightKeywords - Highlight keywords array from server
	 * @param {Array} hideKeywords - Hide keywords array from server
	 * @param {Array} blurKeywords - Blur keywords array from server
	 * @returns {Promise<boolean>} True if conversion was performed
	 */
	async function convertLegacyKeywordsToGroups(highlightKeywords, hideKeywords, blurKeywords) {
		let converted = false;
		const groupsCreated = [];

		// Convert highlight keywords
		if (highlightKeywords && Array.isArray(highlightKeywords) && highlightKeywords.length > 0) {
			const groupName = `Imported Highlight Keywords (${new Date().toLocaleDateString()})`;
			const group = await addGroup(Settings, groupName, "highlight");
			// Convert old format to new format
			const keywords = highlightKeywords.map((kw) => {
				if (typeof kw === "string") {
					return { contains: kw };
				}
				return kw;
			});
			await updateGroup(Settings, group.id, { keywords });
			groupsCreated.push({ type: "highlight", count: highlightKeywords.length });
			converted = true;
		}

		// Convert hide keywords
		if (hideKeywords && Array.isArray(hideKeywords) && hideKeywords.length > 0) {
			const groupName = `Imported Hide Keywords (${new Date().toLocaleDateString()})`;
			const group = await addGroup(Settings, groupName, "hide");
			// Convert old format to new format
			const keywords = hideKeywords.map((kw) => {
				if (typeof kw === "string") {
					return { contains: kw };
				}
				return kw;
			});
			await updateGroup(Settings, group.id, { keywords });
			groupsCreated.push({ type: "hide", count: hideKeywords.length });
			converted = true;
		}

		// Convert blur keywords
		if (blurKeywords && Array.isArray(blurKeywords) && blurKeywords.length > 0) {
			const groupName = `Imported Blur Keywords (${new Date().toLocaleDateString()})`;
			const group = await addGroup(Settings, groupName, "blur");
			// Convert old format to new format
			const keywords = blurKeywords.map((kw) => {
				if (typeof kw === "string") {
					return { contains: kw };
				}
				return kw;
			});
			await updateGroup(Settings, group.id, { keywords });
			groupsCreated.push({ type: "blur", count: blurKeywords.length });
			converted = true;
		}

		if (converted) {
			await renderKeywordGroups();
			// Notify service worker to refresh context menu
			chrome.runtime.sendMessage({ action: "keywordsUpdated" });

			const summary = groupsCreated
				.map((g) => `${g.count} ${g.type} keyword${g.count !== 1 ? "s" : ""}`)
				.join(", ");
			alert(`Successfully converted and imported legacy keywords:\n${summary}`);
		}

		return converted;
	}

	// Load from server handler (Premium Tier 2)
	const loadFromServerButton = document.getElementById("loadKeywordGroups");
	if (loadFromServerButton && !loadFromServerButton._VHelperClickHandler) {
		loadFromServerButton._VHelperClickHandler = async () => {
			if (!Settings.isPremiumUser(2)) {
				alert("This feature requires Premium Tier 2 subscription.");
				return;
			}

			if (await confirmPrompt("Load remote keyword groups and overwrite local groups?")) {
				const content = {
					api_version: 5,
					app_version: env.data.appVersion,
					action: "get_keywords",
					country: Settings.get("general.country", false),
					uuid: Settings.get("general.uuid", false),
					cid: await env.getCID(),
					keywords: "highlight", // Repurpose the highlight keywords field
				};
				const s = await cryptoKeys.signData(content);
				content.s = s;
				content.pk = await cryptoKeys.getExportedPublicKey();

				try {
					const response = await fetch(env.getAPIUrl(), {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify(content),
					});
					const data = await response.json();

					// Check if this is the new format (keyword groups) or legacy format
					// The server might return keywords as an array (legacy) or as an object with keywordGroups (new)
					let keywordGroupsData = null;

					if (data.keywordGroups && Array.isArray(data.keywordGroups)) {
						// New format - keywordGroups array directly
						keywordGroupsData = data.keywordGroups;
					} else if (data.keywords) {
						// Could be legacy array or new format stored in keywords field
						if (Array.isArray(data.keywords)) {
							// Check if it's legacy format (array of keyword objects with contains property)
							if (data.keywords.length > 0 && data.keywords[0].contains !== undefined) {
								// Legacy format - array of keyword objects (highlight keywords)
								const shouldConvert = await confirmPrompt(
									"Server contains legacy keyword format. Would you like to import and convert the legacy keywords (highlight, hide, and blur) to the new keyword groups format?<br/>(This will create new groups).<br/><br/>Warning: Your keywords should have been migrated with the update process. If that is the case, simply save them to the server again.<br/><br/>You should only attempt this if the keywords migration failed."
								);
								if (shouldConvert) {
									// Fetch all three keyword types from server
									const highlightKeywords = data.keywords; // Already have highlight from initial request
									const hideKeywords = await fetchKeywordsFromServer("hidden");
									const blurKeywords = await fetchKeywordsFromServer("blur");

									await convertLegacyKeywordsToGroups(highlightKeywords, hideKeywords, blurKeywords);
								}
								return;
							}
							// If it's an array but not legacy, might be malformed
							alert("Invalid format received from server. Expected keyword groups format.");
							return;
						} else if (typeof data.keywords === "object" && data.keywords.keywordGroups) {
							// New format stored in keywords field as object
							keywordGroupsData = data.keywords.keywordGroups;
						} else {
							alert("Invalid format received from server. Expected keyword groups format.");
							return;
						}
					} else {
						alert("No keyword data found in server response.");
						return;
					}

					if (!keywordGroupsData || !Array.isArray(keywordGroupsData)) {
						alert("Invalid keyword groups format received from server.");
						return;
					}

					const validServerGroups = keywordGroupsData.filter((groupData) => {
						if (!groupData.name || !groupData.type || !Array.isArray(groupData.keywords)) {
							console.warn("Skipping invalid group:", groupData);
							return false;
						}
						return true;
					});

					await importKeywordGroups(Settings, validServerGroups);

					await renderKeywordGroups();
					// Notify service worker to refresh context menu
					chrome.runtime.sendMessage({ action: "keywordsUpdated" });
					alert(`Successfully loaded ${keywordGroupsData.length} keyword groups from server.`);
				} catch (error) {
					alert("Error loading from server: " + error.message);
				}
			}
		};
		loadFromServerButton.addEventListener("click", loadFromServerButton._VHelperClickHandler);
	}

	// Save to server handler (Premium Tier 2)
	const saveToServerButton = document.getElementById("saveKeywordGroups");
	if (saveToServerButton && !saveToServerButton._VHelperClickHandler) {
		saveToServerButton._VHelperClickHandler = async () => {
			if (!Settings.isPremiumUser(2)) {
				alert("This feature requires Premium Tier 2 subscription.");
				return;
			}

			if (await confirmPrompt("Overwrite remote stored keyword groups with the current groups?")) {
				const groups = await getGroups(Settings);
				const keywordGroupsData = groups.map((g) => ({
					id: g.id,
					name: g.name,
					type: g.type,
					order: g.order || 0,
					keywords: g.keywords || [],
					enabled: g.enabled !== undefined ? g.enabled : true,
					listingColor: g.listingColor !== undefined ? g.listingColor : null,
					monitorColor: g.monitorColor !== undefined ? g.monitorColor : null,
					monitorSound: g.monitorSound !== undefined ? g.monitorSound : null,
					monitorVolume:
						g.monitorVolume !== undefined &&
						typeof g.monitorVolume === "number" &&
						g.monitorVolume >= 0 &&
						g.monitorVolume <= 1
							? g.monitorVolume
							: null,
					webhook: g.webhook !== undefined ? g.webhook : false,
				}));

				// Store in keywords field as object with keywordGroups property
				// This allows the server to distinguish between legacy (array) and new format (object)
				const content = {
					api_version: 5,
					app_version: env.data.appVersion,
					action: "save_keywords",
					country: Settings.get("general.country", false),
					uuid: Settings.get("general.uuid", false),
					cid: await env.getCID(),
					keywords_type: "highlight", // Repurpose the highlight keywords field
					keywords: {
						format: "keywordGroups",
						version: 1,
						keywordGroups: keywordGroupsData,
					}, // Store as object to distinguish from legacy array format
				};
				const s = await cryptoKeys.signData(content);
				content.s = s;
				content.pk = await cryptoKeys.getExportedPublicKey();

				try {
					const response = await fetch(env.getAPIUrl(), {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify(content),
					});
					alert("Keyword groups saved remotely.");
				} catch (error) {
					alert("Error saving to server: " + error.message);
				}
			}
		};
		saveToServerButton.addEventListener("click", saveToServerButton._VHelperClickHandler);
	}

	await initCommunityKeywordListsUI(renderKeywordGroups);
	await renderKeywordGroups();
	await refreshCommunityListUpdates(renderKeywordGroups);
	// Initialize drag and drop after rendering
	initKeywordDragAndDrop(renderKeywordGroups);
}

/**
 * Community-linked groups are collapsed by default unless the user has expanded them.
 * @param {HTMLElement} container
 * @param {Array<Object>} groups
 * @param {Set<string>} preserveCollapsedState
 */
function applyDefaultCommunityCollapsedState(container, groups, preserveCollapsedState) {
	for (const group of groups) {
		if (!normalizeCommunityLink(group.communityLink)) continue;
		if (group.collapsed !== undefined) continue;
		const existingEl = container.querySelector(`[data-group-id="${group.id}"]`);
		if (!existingEl || existingEl.classList.contains("collapsed")) {
			preserveCollapsedState.add(group.id);
		}
	}
}

/**
 * Renders all keyword groups in the container
 * @param {Set<string>} preserveCollapsedState - Optional set of group IDs that should remain collapsed
 */
export async function renderKeywordGroups(preserveCollapsedState = null) {
	const container = document.getElementById("keywordGroupsContainer");
	if (!container) return;

	const shouldApplyCommunityDefaults = preserveCollapsedState === null;

	const groups = await getGroups(Settings);

	// Store collapsed state before clearing if not provided
	if (preserveCollapsedState === null) {
		const existingGroups = container.querySelectorAll(".keyword-group");
		if (existingGroups.length > 0) {
			preserveCollapsedState = new Set();
			existingGroups.forEach((groupDiv) => {
				if (groupDiv.classList.contains("collapsed")) {
					const groupId = groupDiv.dataset.groupId;
					if (groupId) {
						preserveCollapsedState.add(groupId);
					}
				}
			});
		} else {
			preserveCollapsedState = new Set(
				groups.filter((group) => isGroupCollapsed(group)).map((group) => group.id)
			);
		}
	}

	if (shouldApplyCommunityDefaults) {
		applyDefaultCommunityCollapsedState(container, groups, preserveCollapsedState);
	}

	const deps = {
		Settings,
		updateGroup,
		deleteGroup,
		renderKeywordGroups,
		moveGroup,
		confirmPrompt,
		getGroupById,
		saveGroupKeywords,
		showKeywordNoteDialog,
		setupKeywordRowDragHandlers,
		isPremiumUser: () => Settings.isPremiumUser(2),
		deleteKeywordFromGroup,
		hasCommunityListUpdate,
		handleCommunityUploadClick: (group) => handleCommunityUploadClick(group, renderKeywordGroups),
		handleCommunityDownloadClick: (group) => handleCommunityDownloadClick(group, renderKeywordGroups),
		handleCommunityGroupDelete,
	};

	await renderKeywordGroupsList({ container, groups, preserveCollapsedState, deps });
}

/**
 * Saves keywords for a group
 * @param {string} groupId - The group ID
 */
export async function saveGroupKeywords(groupId) {
	const groupDiv = document.querySelector(`[data-group-id="${groupId}"]`);
	if (!groupDiv) return;

	// Get the current group to preserve notes
	const group = await getGroupById(Settings, groupId);
	const currentKeywords = group && group.keywords ? group.keywords : [];

	const tbody = groupDiv.querySelector("tbody");
	const rows = tbody.querySelectorAll("tr");

	const keywords = [];
	for (let i = 0; i < rows.length; i++) {
		const row = rows[i];
		const contains = row.querySelector('input[name="contains"]').value.trim();
		const without = row.querySelector('input[name="without"]').value.trim();
		const etv_min = row.querySelector('input[name="etv_min"]').value.trim();
		const etv_max = row.querySelector('input[name="etv_max"]').value.trim();

		// Get the keyword index from the row's data attribute
		const rowKeywordIndex = parseInt(row.dataset.keywordIndex) || i;

		// Validate regex syntax
		try {
			if (contains) new RegExp(contains);
			row.querySelector('input[name="contains"]').classList.remove("keyword-group-invalid-regex");
			row.querySelector('input[name="contains"]').classList.add("keyword-group-row-input-valid");
		} catch (e) {
			alert("Invalid regex syntax in 'Contains' field: " + contains);
			row.querySelector('input[name="contains"]').classList.add("keyword-group-invalid-regex");
			return;
		}

		try {
			if (without) new RegExp(without);
			row.querySelector('input[name="without"]').classList.remove("keyword-group-invalid-regex");
			row.querySelector('input[name="without"]').classList.add("keyword-group-row-input-valid");
		} catch (e) {
			alert("Invalid regex syntax in 'Without' field: " + without);
			row.querySelector('input[name="without"]').classList.add("keyword-group-invalid-regex");
			return;
		}

		// Skip empty rows
		if (contains || without || etv_min || etv_max) {
			// Preserve note from the original keyword if it exists
			// For unsaved rows (index >= 10000), there's no original keyword
			const keywordObj = {
				contains: contains || undefined,
				without: without || undefined,
				etv_min: etv_min || undefined,
				etv_max: etv_max || undefined,
			};
			// Preserve note if it exists in the original keyword (only for saved keywords)
			if (rowKeywordIndex < 10000 && rowKeywordIndex < currentKeywords.length) {
				const originalKeyword = currentKeywords[rowKeywordIndex];
				if (originalKeyword && originalKeyword.note) {
					keywordObj.note = originalKeyword.note;
				}
			}
			// Also check if note was stored in data attribute (for unsaved keywords)
			if (row.dataset.keywordNote) {
				const noteValue = row.dataset.keywordNote.trim();
				if (noteValue) {
					keywordObj.note = noteValue;
				}
			}
			keywords.push(keywordObj);
		}
	}

	// Sort keywords alphabetically by "contains" field
	keywords.sort((a, b) => {
		const aContains = (a.contains || "").toLowerCase();
		const bContains = (b.contains || "").toLowerCase();
		return aContains.localeCompare(bContains);
	});

	await updateGroup(Settings, groupId, { keywords });

	// Show success feedback
	const saveButton = groupDiv.querySelector(".vh-button-icon-compact .button-inner");
	if (saveButton) {
		const originalText = saveButton.textContent;
		saveButton.textContent = "Saved!";
		setTimeout(() => {
			saveButton.textContent = originalText;
		}, 1000);
	}

	await renderKeywordGroups();
}

/**
 * Moves a group up or down in the order
 * @param {string} groupId - The group ID
 * @param {number} direction - -1 for up, 1 for down
 */
export async function moveGroup(groupId, direction) {
	const groupToMove = await getGroupById(Settings, groupId);
	if (!groupToMove) return;

	const groups = await getGroups(Settings);
	// Find the section this group belongs to
	const isBlurGroup = groupToMove.type === "blur";
	const sectionGroups = isBlurGroup
		? groups.filter((g) => g.type === "blur")
		: groups.filter((g) => g.type === "highlight" || g.type === "hide");

	const currentIndex = sectionGroups.findIndex((g) => g.id === groupId);
	if (currentIndex === -1) return;

	const newIndex = currentIndex + direction;
	if (newIndex < 0 || newIndex >= sectionGroups.length) return;

	// Reorder within the section
	const reorderedSection = [...sectionGroups];
	const temp = reorderedSection[currentIndex];
	reorderedSection[currentIndex] = reorderedSection[newIndex];
	reorderedSection[newIndex] = temp;

	// Rebuild the full groups array maintaining section separation
	// Highlight/hide groups first, then blur groups
	const highlightHideGroups = isBlurGroup
		? groups.filter((g) => g.type === "highlight" || g.type === "hide")
		: reorderedSection;
	const blurGroups = isBlurGroup ? reorderedSection : groups.filter((g) => g.type === "blur");

	const allGroups = [...highlightHideGroups, ...blurGroups];

	// Update orders based on new positions
	allGroups.forEach((g, idx) => {
		g.order = idx;
	});

	// Save the reordered groups
	await reorderGroups(
		Settings,
		allGroups.map((g) => g.id)
	);
	await renderKeywordGroups();
	// Notify service worker to refresh context menu
	chrome.runtime.sendMessage({ action: "keywordsUpdated" });
}

/**
 * Shows a dialog to edit a keyword note
 * @param {string} groupId - The group ID
 * @param {number} keywordIndex - The keyword index
 * @param {Object} keyword - The keyword object
 */
export async function showKeywordNoteDialog(groupId, keywordIndex, keyword) {
	const group = await getGroupById(Settings, groupId);
	const currentKeyword =
		group && group.keywords && keywordIndex < group.keywords.length ? group.keywords[keywordIndex] : keyword;

	const groupDiv = document.querySelector(`[data-group-id="${groupId}"]`);
	let containsValue = currentKeyword.contains || "";
	if (groupDiv) {
		const row = groupDiv.querySelector(`tr[data-keyword-index="${keywordIndex}"]`);
		if (row) {
			const containsInput = row.querySelector('input[name="contains"]');
			if (containsInput) {
				containsValue = containsInput.value.trim() || containsValue;
			}
		}
	}

	const note = await showKeywordNoteDialogComponent({
		keywordLabel: containsValue || "(empty)",
		initialNote: currentKeyword.note || "",
	});

	if (note === null) return;

	if (keywordIndex < 10000 && group && group.keywords && keywordIndex < group.keywords.length) {
		const updatedKeywords = [...group.keywords];
		if (updatedKeywords[keywordIndex]) {
			updatedKeywords[keywordIndex] = {
				...updatedKeywords[keywordIndex],
				note: note || undefined,
			};
			await updateGroup(Settings, groupId, { keywords: updatedKeywords });
		}
		await renderKeywordGroups();
	} else {
		const row = groupDiv?.querySelector(`tr[data-keyword-index="${keywordIndex}"]`);
		if (row) {
			if (note) {
				row.dataset.keywordNote = note;
			} else {
				delete row.dataset.keywordNote;
			}
		}
		await saveGroupKeywords(groupId);
	}
}
