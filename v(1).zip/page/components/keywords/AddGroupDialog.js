/**
 * Add Group dialog component. Loads template, shows modal, returns user result or null.
 * @module AddGroupDialog
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";

const Tpl = new Template();

const TEMPLATE_URL = "/page/components/keywords/templates/add_group_dialog.tpl.html";

/**
 * Shows the Add Group dialog.
 * @param {Object} options
 * @param {boolean} options.isPremiumBlur - Whether blur option should be enabled
 * @returns {Promise<{ name: string, type: string } | null>} Result or null if cancelled
 */
export async function showAddGroupDialog({ isPremiumBlur }) {
	const html = await Tpl.loadFile(TEMPLATE_URL, true);
	const rendered = Tpl.render(html);

	const wrap = document.createElement("div");
	wrap.innerHTML = rendered;
	const overlay = wrap.querySelector("#addGroupDialogOverlay");
	const popup = wrap.querySelector("#addGroupDialogPopup");
	const closeBtn = wrap.querySelector("#addGroupDialogClose");
	const cancelBtn = wrap.querySelector("#addGroupDialogCancel");
	const createBtn = wrap.querySelector("#addGroupDialogCreate");
	const nameInput = wrap.querySelector("#addGroupNameInput");
	const typeSelect = wrap.querySelector("#addGroupTypeSelect");
	const blurOption = wrap.querySelector("#addGroupTypeBlurOption");
	const blurNotice = wrap.querySelector("#addGroupBlurNotice");

	if (!blurOption || !blurNotice) {
		// Fallback if template IDs change
		const blurOpt = typeSelect?.querySelector('option[value="blur"]');
		if (blurOpt && !isPremiumBlur) {
			blurOpt.disabled = true;
			blurOpt.textContent = getMessageOrDefault(
				"kwAddGroupBlurUpgradeRequired",
				"Blur (Premium Tier 2) - Upgrade Required"
			);
		}
	} else {
		if (!isPremiumBlur) {
			blurOption.disabled = true;
			blurOption.textContent = getMessageOrDefault(
				"kwAddGroupBlurUpgradeRequired",
				"Blur (Premium Tier 2) - Upgrade Required"
			);
			blurNotice.style.display = "block";
		}
	}

	return new Promise((resolve) => {
		const remove = () => {
			document.removeEventListener("keydown", onEscape);
			wrap.remove();
		};

		const close = (result) => {
			remove();
			resolve(result);
		};

		const onEscape = (e) => {
			if (e.key === "Escape") {
				close(null);
			}
		};

		overlay?.addEventListener("click", () => close(null));
		closeBtn?.addEventListener("click", () => close(null));
		cancelBtn?.addEventListener("click", () => close(null));

		createBtn?.addEventListener("click", () => {
			const name = nameInput?.value?.trim();
			const type = typeSelect?.value;
			if (!name) {
				alert(getMessageOrDefault("kwAddGroupAlertEnterName", "Please enter a group name."));
				nameInput?.focus();
				return;
			}
			if (type === "blur" && !isPremiumBlur) {
				alert(
					getMessageOrDefault(
						"kwAddGroupAlertBlurPremium",
						"Blur groups are reserved for Premium Tier 2 members."
					)
				);
				return;
			}
			close({ name, type });
		});

		nameInput?.addEventListener("keydown", (e) => {
			if (e.key === "Enter") {
				createBtn?.click();
			}
		});

		document.addEventListener("keydown", onEscape);
		document.body.appendChild(wrap);
		nameInput?.focus();
	});
}
