/**
 * Keyword group options component (highlight type only).
 * Renders color legends, sound, webhook, scroll wrapper from templates; wires behavior in JS.
 * @module KeywordGroupOptions
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { populateSoundSelectOptions, pickAndImportCustomSound } from "/page/components/controls/FormControls.js";
import { UPLOAD_OPTION_VALUE } from "/scripts/core/services/CustomSoundLibrary.js";
import { playNotificationSound } from "/scripts/core/utils/SoundResolver.js";

const Tpl = new Template();
const SCROLL_TEMPLATE_URL = "/page/components/keywords/templates/keyword_group_options_scroll.tpl.html";
const COLOR_LEGEND_URL = "/page/components/keywords/templates/keyword_group_color_legend.tpl.html";
const SOUND_LEGEND_URL = "/page/components/keywords/templates/keyword_group_sound_legend.tpl.html";
const WEBHOOK_URL = "/page/components/keywords/templates/keyword_group_webhook.tpl.html";
const OPTIONS_CONTAINER_URL = "/page/components/keywords/templates/keyword_group_options_container.tpl.html";

let cachedScrollHtml = null;
let cachedColorLegendHtml = null;
let cachedSoundLegendHtml = null;
let cachedWebhookHtml = null;
let cachedOptionsContainerHtml = null;

async function getScrollHtml() {
	if (cachedScrollHtml) return cachedScrollHtml;
	cachedScrollHtml = await Tpl.loadFile(SCROLL_TEMPLATE_URL, true);
	return cachedScrollHtml;
}

async function getColorLegendHtml() {
	if (cachedColorLegendHtml) return cachedColorLegendHtml;
	cachedColorLegendHtml = await Tpl.loadFile(COLOR_LEGEND_URL, true);
	return cachedColorLegendHtml;
}

async function getSoundLegendHtml() {
	if (cachedSoundLegendHtml) return cachedSoundLegendHtml;
	cachedSoundLegendHtml = await Tpl.loadFile(SOUND_LEGEND_URL, true);
	return cachedSoundLegendHtml;
}

async function getWebhookHtml() {
	if (cachedWebhookHtml) return cachedWebhookHtml;
	cachedWebhookHtml = await Tpl.loadFile(WEBHOOK_URL, true);
	return cachedWebhookHtml;
}

async function getOptionsContainerHtml() {
	if (cachedOptionsContainerHtml) return cachedOptionsContainerHtml;
	cachedOptionsContainerHtml = await Tpl.loadFile(OPTIONS_CONTAINER_URL, true);
	return cachedOptionsContainerHtml;
}

function parseTemplateToElement(html) {
	const wrap = document.createElement("div");
	wrap.innerHTML = html.trim();
	return wrap.firstElementChild;
}

/**
 * Renders the highlight options block (color, sound, webhook, scroll) into container.
 * @param {Object} options
 * @param {Object} options.group - Group data
 * @param {HTMLElement} options.container - contentWrapper to append into
 * @param {Function} options.getSetting - (key) => value
 * @param {Function} options.updateGroup - (groupId, updates) => Promise<void>
 */
export async function renderKeywordGroupOptions(options) {
	const { group, container, getSetting, updateGroup } = options;

	const defaultListing = getSetting("general.highlightColor.color") || "#ffff00";
	const defaultMonitor = getSetting("notification.monitor.highlight.color") || "#ffff00";
	const defaultVolume = getSetting("notification.monitor.highlight.volume");
	const volumeValue =
		group.monitorVolume !== undefined && typeof group.monitorVolume === "number"
			? String(group.monitorVolume)
			: defaultVolume !== undefined && defaultVolume !== null
				? String(defaultVolume)
				: "0.5";

	async function renderColorLegend(labelText, colorProperty, defaultColor) {
		const currentColor = group[colorProperty];
		const hasColor = currentColor !== null && currentColor !== undefined;
		Tpl.setVar("label", labelText);
		Tpl.setVar("colorProperty", colorProperty);
		Tpl.setVar("checked", hasColor ? "checked" : "");
		Tpl.setVar("colorValue", hasColor ? currentColor || defaultColor : defaultColor);
		Tpl.setVar("noColorClass", hasColor ? "" : "keyword-group-color-input--no-color");
		return Tpl.render(await getColorLegendHtml());
	}

	const listingColorLegendHtml = await renderColorLegend(
		getMessageOrDefault("kwColorListingColor", "Listing Color"),
		"listingColor",
		defaultListing
	);
	const monitorColorLegendHtml = await renderColorLegend(
		getMessageOrDefault("kwColorMonitorColor", "Monitor Color"),
		"monitorColor",
		defaultMonitor
	);

	Tpl.setVar("volumeValue", volumeValue);
	const soundLegendHtml = Tpl.render(await getSoundLegendHtml());

	Tpl.setVar("webhookChecked", group.webhook === true ? "checked" : "");
	const webhookHtml = Tpl.render(await getWebhookHtml());

	Tpl.setVar("listingColorLegendHtml", listingColorLegendHtml);
	Tpl.setVar("monitorColorLegendHtml", monitorColorLegendHtml);
	Tpl.setVar("soundLegendHtml", soundLegendHtml);
	Tpl.setVar("webhookHtml", webhookHtml);

	const optionsContainerHtml = Tpl.render(await getOptionsContainerHtml());
	const optionsContainer = parseTemplateToElement(optionsContainerHtml);

	const colorLegends = optionsContainer.querySelectorAll(".keyword-group-color-legend");
	const defaultColors = { listingColor: defaultListing, monitorColor: defaultMonitor };
	["listingColor", "monitorColor"].forEach((colorProperty, idx) => {
		const legend = colorLegends[idx];
		if (!legend) return;
		const checkbox = legend.querySelector(".keyword-group-color-checkbox");
		const colorInput = legend.querySelector(".keyword-group-color-input");
		if (!checkbox || !colorInput) return;
		const defaultColor = defaultColors[colorProperty];
		colorInput.disabled = !checkbox.checked;
		if (!checkbox.checked) colorInput.classList.add("keyword-group-color-input--no-color");

		checkbox.addEventListener("change", async (e) => {
			e.stopPropagation();
			if (!checkbox.checked) {
				await updateGroup(group.id, { [colorProperty]: null });
				colorInput.disabled = true;
				colorInput.classList.add("keyword-group-color-input--no-color");
			} else {
				colorInput.disabled = false;
				colorInput.classList.remove("keyword-group-color-input--no-color");
				const newColor = group[colorProperty] || defaultColor;
				colorInput.value = newColor;
				await updateGroup(group.id, { [colorProperty]: newColor });
			}
		});
		colorInput.addEventListener("change", async (e) => {
			e.stopPropagation();
			await updateGroup(group.id, { [colorProperty]: colorInput.value });
		});
	});

	const soundSelect = optionsContainer.querySelector(".keyword-group-sound-select");
	const volumeInput = optionsContainer.querySelector(".keyword-group-volume-input");
	const playButton = optionsContainer.querySelector(".keyword-group-play-button");
	if (soundSelect) {
		const currentSound = group.monitorSound || "0";
		await populateSoundSelectOptions(soundSelect, currentSound);
		soundSelect.value = currentSound;
		soundSelect.addEventListener("change", async (e) => {
			e.stopPropagation();
			const previousValue = group.monitorSound || "0";
			if (soundSelect.value === UPLOAD_OPTION_VALUE) {
				const newValue = await pickAndImportCustomSound();
				if (!newValue) {
					soundSelect.value = previousValue;
					return;
				}
				await populateSoundSelectOptions(soundSelect, newValue);
				soundSelect.value = newValue;
				await updateGroup(group.id, { monitorSound: newValue });
				return;
			}
			const value = soundSelect.value === "0" ? null : soundSelect.value;
			await updateGroup(group.id, { monitorSound: value });
		});
	}
	if (volumeInput) {
		volumeInput.addEventListener("change", async (e) => {
			e.stopPropagation();
			const v = parseFloat(volumeInput.value);
			if (Number.isFinite(v) && v >= 0 && v <= 1) {
				await updateGroup(group.id, { monitorVolume: v });
			}
		});
	}
	if (playButton && soundSelect) {
		playButton.addEventListener("click", async (e) => {
			e.stopPropagation();
			const soundToPlay = soundSelect.value;
			if (soundToPlay === "0" || !soundToPlay || soundToPlay === UPLOAD_OPTION_VALUE) return;
			void playNotificationSound(soundToPlay, parseFloat(volumeInput?.value ?? "0.5"));
		});
	}

	const webhookCheckbox = optionsContainer.querySelector(".keyword-group-webhook-checkbox");
	if (webhookCheckbox) {
		webhookCheckbox.addEventListener("change", async (e) => {
			e.stopPropagation();
			await updateGroup(group.id, { webhook: webhookCheckbox.checked });
		});
	}

	const scrollHtml = await getScrollHtml();
	const scrollRendered = Tpl.render(scrollHtml);
	const scrollWrap = document.createElement("div");
	scrollWrap.innerHTML = scrollRendered;

	const optionsWrapper = scrollWrap.querySelector(".keyword-group-options-wrapper");
	const viewport = scrollWrap.querySelector("#keywordGroupOptionsViewport");
	const leftArrow = scrollWrap.querySelector("#keywordGroupOptionsScrollLeft");
	const rightArrow = scrollWrap.querySelector("#keywordGroupOptionsScrollRight");

	if (viewport) viewport.appendChild(optionsContainer);

	const scrollStep = 280;
	const updateScrollArrows = () => {
		if (!viewport || !leftArrow || !rightArrow) return;
		const atStart = viewport.scrollLeft <= 2;
		const atEnd = viewport.scrollLeft >= viewport.scrollWidth - viewport.clientWidth - 2;
		leftArrow.classList.toggle("keyword-group-options-scroll-arrow--disabled", atStart);
		rightArrow.classList.toggle("keyword-group-options-scroll-arrow--disabled", atEnd);
		leftArrow.disabled = atStart;
		rightArrow.disabled = atEnd;
	};

	if (leftArrow)
		leftArrow.addEventListener("click", () => viewport?.scrollBy({ left: -scrollStep, behavior: "smooth" }));
	if (rightArrow)
		rightArrow.addEventListener("click", () => viewport?.scrollBy({ left: scrollStep, behavior: "smooth" }));
	if (viewport) viewport.addEventListener("scroll", updateScrollArrows);

	const ro = typeof ResizeObserver !== "undefined" && viewport ? new ResizeObserver(updateScrollArrows) : null;
	if (ro) ro.observe(viewport);

	if (optionsWrapper) container.appendChild(optionsWrapper);
	requestAnimationFrame(updateScrollArrows);
}
