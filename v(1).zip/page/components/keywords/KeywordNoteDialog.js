/**
 * Keyword Note dialog component. Loads template, shows modal, returns note or null.
 * @module KeywordNoteDialog
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";

const Tpl = new Template();

const TEMPLATE_URL = "/page/components/keywords/templates/keyword_note_dialog.tpl.html";

/**
 * Shows the Keyword Note dialog.
 * @param {Object} options
 * @param {string} options.keywordLabel - Label for the keyword (e.g. "contains" value or "(empty)")
 * @param {string} options.initialNote - Initial note content
 * @returns {Promise<string | null>} Note content if saved, null if cancelled
 */
export async function showKeywordNoteDialog({ keywordLabel, initialNote }) {
	const label = keywordLabel || getMessageOrDefault("kwNoteDialogEmptyLabel", "(empty)");
	Tpl.setVar("keywordLabel", label);
	const html = await Tpl.loadFile(TEMPLATE_URL, true);
	const rendered = Tpl.render(html);

	const wrap = document.createElement("div");
	wrap.innerHTML = rendered;
	const overlay = wrap.querySelector("#keywordNoteDialogOverlay");
	const closeBtn = wrap.querySelector("#keywordNoteDialogClose");
	const cancelBtn = wrap.querySelector("#keywordNoteDialogCancel");
	const saveBtn = wrap.querySelector("#keywordNoteDialogSave");
	const textarea = wrap.querySelector("#keywordNoteDialogTextarea");
	const titleEl = wrap.querySelector("#keywordNoteDialogTitle");

	if (titleEl) {
		titleEl.textContent = getMessageOrDefault("kwNoteDialogTitle", 'Note for keyword: "' + label + '"', [label]);
	}
	if (textarea && initialNote !== undefined) {
		textarea.value = initialNote;
	}

	return new Promise((resolve) => {
		const remove = () => {
			document.removeEventListener("keydown", onEscape);
			wrap.remove();
		};

		const close = (result) => {
			remove();
			resolve(result);
		};

		const onEscape = (e) => {
			if (e.key === "Escape") {
				close(null);
			}
		};

		overlay?.addEventListener("click", () => close(null));
		closeBtn?.addEventListener("click", () => close(null));
		cancelBtn?.addEventListener("click", () => close(null));

		saveBtn?.addEventListener("click", () => {
			const note = textarea?.value?.trim() ?? "";
			close(note);
		});

		document.addEventListener("keydown", onEscape);
		document.body.appendChild(wrap);
		textarea?.focus();
	});
}
