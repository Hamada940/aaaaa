/**
 * Pure helpers for keyword groups export/import. Used by KeywordGroupsUI and tests.
 * @module keywordGroupsExportImport
 */

import { createGroup, getGroups, saveGroups } from "/scripts/core/utils/KeywordGroupsManager.js";

/**
 * Builds the export payload from an array of groups.
 * @param {Array<Object>} groups - Keyword groups from getGroups()
 * @returns {{ version: number, format: string, keywordGroups: Array<Object> }}
 */
export function buildKeywordGroupsExport(groups) {
	return {
		version: 1,
		format: "keywordGroups",
		keywordGroups: (groups || []).map((g) => ({
			id: g.id,
			name: g.name,
			type: g.type,
			order: g.order || 0,
			keywords: g.keywords || [],
			enabled: g.enabled !== undefined ? g.enabled : true,
			listingColor: g.listingColor !== undefined ? g.listingColor : null,
			monitorColor: g.monitorColor !== undefined ? g.monitorColor : null,
			monitorSound: g.monitorSound !== undefined ? g.monitorSound : null,
			monitorVolume:
				g.monitorVolume !== undefined &&
				typeof g.monitorVolume === "number" &&
				g.monitorVolume >= 0 &&
				g.monitorVolume <= 1
					? g.monitorVolume
					: null,
			webhook: g.webhook !== undefined ? g.webhook : false,
		})),
	};
}

/**
 * Validates imported JSON and returns parsed result or error.
 * @param {any} json - Parsed JSON
 * @returns {{ valid: true, keywordGroups: Array<Object> } | { valid: false, error: string, errorKey: string }}
 */
export function validateKeywordGroupsImport(json) {
	if (!json || typeof json !== "object") {
		return {
			valid: false,
			error: "Invalid format. Expected an object with a 'keywordGroups' array.",
			errorKey: "kwImportInvalidFormat",
		};
	}
	if (!json.keywordGroups || !Array.isArray(json.keywordGroups)) {
		return {
			valid: false,
			error: "Invalid format. Expected an object with a 'keywordGroups' array.",
			errorKey: "kwImportInvalidFormat",
		};
	}
	for (const group of json.keywordGroups) {
		if (!group.id || !group.name || !group.type || !Array.isArray(group.keywords)) {
			return {
				valid: false,
				error: "Invalid group structure. Each group must have id, name, type, and keywords array.",
				errorKey: "kwImportInvalidStructure",
			};
		}
	}
	return { valid: true, keywordGroups: json.keywordGroups };
}

/**
 * Maps an imported group data object to the updates object for updateGroup().
 * @param {Object} groupData - One item from keywordGroups in import JSON
 * @returns {Object} Updates to pass to updateGroup
 */
/**
 * Builds in-memory keyword group objects from validated import data.
 * Mirrors the former addGroup + updateGroup sequence (new ids, highlight defaults, then import fields).
 * @param {Array<Object>} groupDataList - Validated items from keywordGroups in import JSON
 * @param {{ getSetting?: (path: string) => * }} [options]
 * @returns {Array<Object>}
 */
export function buildKeywordGroupsForImport(groupDataList, { getSetting = () => undefined } = {}) {
	return (groupDataList || []).map((groupData, index) => {
		const normalizedType = (groupData.type || "").trim().toLowerCase();
		const order = groupData.order ?? index;
		const group = createGroup(groupData.name, normalizedType, order);

		if (normalizedType === "highlight") {
			group.listingColor = getSetting("general.highlightColor.color") ?? "#FFE815";
			group.monitorColor = getSetting("notification.monitor.highlight.color") ?? "#FFE815";
		}

		return { ...group, ...mapImportedGroupToUpdates(groupData) };
	});
}

/**
 * Replaces all keyword groups in a single storage write (atomic import).
 * @param {Object} settingsManager - Settings manager instance
 * @param {Array<Object>} groupDataList - Validated items from keywordGroups in import JSON
 * @returns {Promise<Array<Object>>} Saved groups
 */
export async function importKeywordGroups(settingsManager, groupDataList) {
	const groups = buildKeywordGroupsForImport(groupDataList, {
		getSetting: (path) => settingsManager.get(path, false),
	});
	await saveGroups(settingsManager, groups);
	return groups;
}

export function mapImportedGroupToUpdates(groupData) {
	const monitorVolume =
		groupData.monitorVolume != null &&
		typeof groupData.monitorVolume === "number" &&
		groupData.monitorVolume >= 0 &&
		groupData.monitorVolume <= 1
			? groupData.monitorVolume
			: undefined;
	return {
		keywords: groupData.keywords || [],
		order: groupData.order || 0,
		enabled: groupData.enabled !== undefined ? groupData.enabled : true,
		listingColor: groupData.listingColor !== undefined ? groupData.listingColor : null,
		monitorColor: groupData.monitorColor !== undefined ? groupData.monitorColor : null,
		monitorSound: groupData.monitorSound !== undefined ? groupData.monitorSound : null,
		monitorVolume,
		webhook: groupData.webhook !== undefined ? groupData.webhook : false,
	};
}
