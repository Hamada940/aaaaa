/**
 * API client for community keyword lists.
 */

import { Environment } from "/scripts/core/services/Environment.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";

const env = new Environment();
const Settings = new SettingsMgr();
const cryptoKeys = new CryptoKeys();

async function buildBaseContent(action, extra = {}) {
	return {
		api_version: 5,
		app_version: env.data.appVersion,
		action,
		country: Settings.get("general.country", false),
		uuid: Settings.get("general.uuid", false),
		cid: await env.getCID(),
		...extra,
	};
}

async function signedPost(extraFields, action) {
	const content = await buildBaseContent(action, extraFields);
	content.s = await cryptoKeys.signData(content);
	content.pk = await cryptoKeys.getExportedPublicKey();

	const response = await fetch(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(content),
	});

	const data = await response.json().catch(() => ({}));
	if (!response.ok) {
		const error = new Error(data.error || `Request failed (${response.status})`);
		error.status = response.status;
		error.data = data;
		throw error;
	}
	return data;
}

export async function listCommunityKeywordLists() {
	const data = await signedPost({}, "list_community_keyword_lists");
	return data.lists || [];
}

export async function getCommunityKeywordList(listId) {
	const data = await signedPost({ list_id: listId }, "get_community_keyword_list");
	return data.list;
}

export async function checkCommunityKeywordUpdates(checks) {
	const data = await signedPost({ checks }, "check_community_keyword_updates");
	return data.results || [];
}

export async function getCommunityKeywordContributionContext(listId) {
	return signedPost({ list_id: listId }, "get_community_keyword_contribution_context");
}

export async function checkCommunityKeywordName(name) {
	const data = await signedPost({ name }, "check_community_keyword_name");
	return data.available === true;
}

export async function submitCommunityKeywordList({ name, description, keywords }) {
	return signedPost({ name, description, keywords }, "submit_community_keyword_list");
}

export async function submitCommunityKeywordContribution({ listId, keywords, changeNote }) {
	return signedPost({ list_id: listId, keywords, change_note: changeNote }, "submit_community_keyword_contribution");
}

export async function subscribeCommunityKeywordList(listId) {
	return signedPost({ list_id: listId }, "subscribe_community_keyword_list");
}

export async function unsubscribeCommunityKeywordList(listId) {
	return signedPost({ list_id: listId }, "unsubscribe_community_keyword_list");
}

export { buildBaseContent };
