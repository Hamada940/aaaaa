/**
 * @fileoverview English templates and formatters for keyword testing step messages.
 * Used by KeywordTesting.js and unit-tested directly (English output).
 */

export const ENGLISH_TEMPLATES = {
	matchWithoutEmpty:
		'Group "$1$", Contains keyword "$2$" matching with the title, and the without clause is empty. We have a match. Stop processing the list, consider this item as $3$.',
	matchWithoutNotMatched:
		'Group "$1$", Contains keyword "$2$" matching with the title, and does not match "$3$". We have a match. Stop processing the list, consider this item as $4$.',
	withoutExcluded:
		'Group "$1$", Contains keyword "$2$" matching with the title, but without clause "$3$" also matches. Ignoring and continuing the list.',
	etvExcluded:
		'Group "$1$", Contains keyword "$2$" matching with the title, but ETV conditions (min: $3$, max: $4$) are not satisfied. Ignoring and continuing the list.',
	skippedDisabledGroup: 'Skipping disabled group "$1$".',
	groupNoMatch: 'Group "$1$": No match.',
	sectionHighlightHide: "Highlight/Hide keywords processing",
	sectionBlur: "Blur keywords processing",
	noHighlightHideMatch: "No highlight or hide keyword matched. Continuing with blur groups.",
	noMatch: "No keyword matched.",
	summarySingle: "Result: $1$.",
	summaryMultiple: "Result: $1$.",
	unsavedDomMismatch:
		"Warning: unsaved keyword edits in this page differ from saved keyword groups. The monitor uses saved groups only — click Save on each keyword group before testing.",
};

export function isEffectivelyEmpty(value) {
	return value === undefined || value === null || String(value).trim() === "";
}

export function formatMessage(template, substitutions = []) {
	let msg = template;
	for (let i = 0; i < substitutions.length; i++) {
		const value = String(substitutions[i]);
		const placeholder = `$${i + 1}$`;
		msg = msg.split(placeholder).join(value);
	}
	return msg;
}

export function buildMatchStepMessage(groupName, contains, without, actionLabel) {
	if (isEffectivelyEmpty(without)) {
		return formatMessage(ENGLISH_TEMPLATES.matchWithoutEmpty, [groupName, contains, actionLabel]);
	}
	return formatMessage(ENGLISH_TEMPLATES.matchWithoutNotMatched, [groupName, contains, without, actionLabel]);
}

export function buildWithoutExcludedMessage(groupName, contains, without) {
	return formatMessage(ENGLISH_TEMPLATES.withoutExcluded, [groupName, contains, without]);
}

export function buildEtvExcludedMessage(groupName, contains, etvMin, etvMax) {
	return formatMessage(ENGLISH_TEMPLATES.etvExcluded, [groupName, contains, etvMin || "—", etvMax || "—"]);
}

export function buildSkippedDisabledGroupMessage(groupName) {
	return formatMessage(ENGLISH_TEMPLATES.skippedDisabledGroup, [groupName]);
}

export function buildGroupNoMatchMessage(groupName) {
	return formatMessage(ENGLISH_TEMPLATES.groupNoMatch, [groupName]);
}

export function buildHighlightHideSectionHeaderMessage() {
	return ENGLISH_TEMPLATES.sectionHighlightHide;
}

export function buildBlurSectionHeaderMessage() {
	return ENGLISH_TEMPLATES.sectionBlur;
}

export function buildNoHighlightHideMatchMessage() {
	return ENGLISH_TEMPLATES.noHighlightHideMatch;
}

export function buildNoMatchMessage() {
	return ENGLISH_TEMPLATES.noMatch;
}

export function buildSummarySingleMessage(actionLabel) {
	return formatMessage(ENGLISH_TEMPLATES.summarySingle, [actionLabel]);
}

export function buildSummaryMultipleMessage(actions) {
	return formatMessage(ENGLISH_TEMPLATES.summaryMultiple, [actions]);
}
