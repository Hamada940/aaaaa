/**
 * Batch Keywords dialog component. Loads template, shows modal, returns keyword lines or null.
 * @module BatchKeywordsDialog
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";

const Tpl = new Template();

const TEMPLATE_URL = "/page/components/keywords/templates/batch_keywords_dialog.tpl.html";

/**
 * Shows the Batch Keywords dialog.
 * @returns {Promise<string[] | null>} Non-empty lines if confirmed, null if cancelled
 */
export async function showBatchKeywordsDialog() {
	const html = await Tpl.loadFile(TEMPLATE_URL, true);
	const rendered = Tpl.render(html);

	const wrap = document.createElement("div");
	wrap.innerHTML = rendered;
	const overlay = wrap.querySelector("#batchKeywordsDialogOverlay");
	const closeBtn = wrap.querySelector("#batchKeywordsDialogClose");
	const cancelBtn = wrap.querySelector("#batchKeywordsDialogCancel");
	const addBtn = wrap.querySelector("#batchKeywordsDialogAdd");
	const textarea = wrap.querySelector("#batchKeywordsDialogTextarea");

	return new Promise((resolve) => {
		const remove = () => {
			document.removeEventListener("keydown", onEscape);
			wrap.remove();
		};

		const close = (result) => {
			remove();
			resolve(result);
		};

		const onEscape = (e) => {
			if (e.key === "Escape") {
				close(null);
			}
		};

		overlay?.addEventListener("click", () => close(null));
		closeBtn?.addEventListener("click", () => close(null));
		cancelBtn?.addEventListener("click", () => close(null));

		addBtn?.addEventListener("click", () => {
			const lines = (textarea?.value ?? "")
				.split(/\r?\n/)
				.map((line) => line.trim())
				.filter((line) => line.length > 0);
			if (lines.length === 0) {
				alert(
					getMessageOrDefault(
						"kwBatchKeywordsDialogEmptyAlert",
						"Please enter at least one keyword (one per line)."
					)
				);
				textarea?.focus();
				return;
			}
			close(lines);
		});

		document.addEventListener("keydown", onEscape);
		document.body.appendChild(wrap);
		textarea?.focus();
	});
}
