/**
 * @fileoverview KeywordDragAndDrop - Handles drag and drop functionality for keywords
 */

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import {
	getGroups,
	getGroupById,
	addKeywordToGroup,
	updateGroup,
	deleteKeywordFromGroup,
} from "/scripts/core/utils/KeywordGroupsManager.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";

// Drag and drop state - expose via window for table dragover handler
let dragState = {
	isDragging: false,
	draggedRow: null,
	sourceGroupId: null,
	sourceKeywordIndex: null,
	keywordData: null,
	groupStates: {}, // Store collapsed state of groups
	dropZones: [],
};

// Expose drag state globally for table dragover handler
window._keywordDragState = dragState;

/**
 * Initializes drag and drop handlers
 * @param {Function} renderKeywordGroups - Function to re-render keyword groups
 */
export function initKeywordDragAndDrop(renderKeywordGroups) {
	// Store render function for use in handlers
	window._renderKeywordGroups = renderKeywordGroups;

	// Global handlers for drag over and drop
	// Note: drag handlers are added directly to rows via setupKeywordRowDragHandlers
	document.addEventListener("dragover", handleDragOver);
	document.addEventListener("drop", handleDrop);
}

/**
 * Creates drop zones for all groups except the source
 */
function createDropZones() {
	// Remove existing drop zones
	dragState.dropZones.forEach((zone) => zone.remove());
	dragState.dropZones = [];

	// Create drop zone for each group
	document.querySelectorAll(".keyword-group").forEach((groupDiv) => {
		const groupId = groupDiv.dataset.groupId;

		// Skip the source group
		if (groupId === dragState.sourceGroupId) return;

		// Find or create the drop zone container
		let dropZoneContainer = groupDiv.querySelector(".keyword-drop-zone-container");
		if (!dropZoneContainer) {
			// Create container if it doesn't exist (for backward compatibility)
			dropZoneContainer = document.createElement("div");
			dropZoneContainer.className = "keyword-drop-zone-container";
			groupDiv.appendChild(dropZoneContainer);
		}
		dropZoneContainer.style.display = "block";

		// Create drop zone
		const dropZone = document.createElement("div");
		dropZone.className = "keyword-drop-zone";
		dropZone.dataset.targetGroupId = groupId;
		dropZone.textContent = getMessageOrDefault("kwDropKeywordHere", "Drop keyword here");

		dropZoneContainer.appendChild(dropZone);
		dragState.dropZones.push(dropZone);
	});
}

/**
 * Handles drag over event
 * @param {DragEvent} e - The drag event
 */
function handleDragOver(e) {
	if (!dragState.isDragging) {
		// Still prevent default to allow drag to continue
		e.preventDefault();
		return;
	}
	e.preventDefault();
	e.stopPropagation();
	e.dataTransfer.dropEffect = "move";

	// Highlight drop zone if hovering over it
	const dropZone = e.target.closest(".keyword-drop-zone");
	dragState.dropZones.forEach((zone) => {
		zone.classList.toggle("keyword-drop-zone--drag-over", zone === dropZone);
	});
}

/**
 * Handles drop event
 * @param {DragEvent} e - The drop event
 */
async function handleDrop(e) {
	if (!dragState.isDragging) return;
	e.preventDefault();
	e.stopPropagation();

	const dropZone = e.target.closest(".keyword-drop-zone");
	if (!dropZone) {
		// Dropped outside a zone, cancel
		cleanupDragState();
		return;
	}

	const targetGroupId = dropZone.dataset.targetGroupId;
	if (!targetGroupId || targetGroupId === dragState.sourceGroupId) {
		cleanupDragState();
		return;
	}

	// Save keyword data to local variable immediately, before dragend can clear it
	const keywordData = dragState.keywordData ? { ...dragState.keywordData } : null;
	const sourceGroupId = dragState.sourceGroupId;
	const sourceKeywordIndex = dragState.sourceKeywordIndex;

	try {
		// Get the target group
		const targetGroup = await getGroupById(Settings, targetGroupId);
		if (!targetGroup) {
			cleanupDragState();
			return;
		}

		// Validate keyword data before proceeding
		if (!keywordData || typeof keywordData !== "object") {
			alert(getMessageOrDefault("kwErrorInvalidKeywordData", "Cannot move keyword: invalid keyword data."));
			cleanupDragState();
			return;
		}

		// Check if at least one field has a truthy value
		const hasValidField =
			(keywordData.contains && keywordData.contains.trim()) ||
			(keywordData.without && keywordData.without.trim()) ||
			(keywordData.etv_min && keywordData.etv_min.trim()) ||
			(keywordData.etv_max && keywordData.etv_max.trim());

		if (!hasValidField) {
			alert(
				getMessageOrDefault(
					"kwErrorKeywordFieldRequired",
					"Cannot move keyword: at least one field must have a value."
				)
			);
			cleanupDragState();
			return;
		}

		// Remove keyword from source group if it's a saved keyword
		if (sourceKeywordIndex < 10000) {
			// It's a saved keyword, remove it from the source group
			await deleteKeywordFromGroup(Settings, sourceGroupId, sourceKeywordIndex);
		}

		// Add keyword to target group using the addKeywordToGroup function
		await addKeywordToGroup(Settings, targetGroupId, keywordData);

		// Get updated group to sort keywords
		const updatedTargetGroup = await getGroupById(Settings, targetGroupId);
		if (updatedTargetGroup && updatedTargetGroup.keywords) {
			// Sort keywords alphabetically by "contains" field
			const sortedKeywords = [...updatedTargetGroup.keywords].sort((a, b) => {
				const aContains = (a.contains || "").toLowerCase();
				const bContains = (b.contains || "").toLowerCase();
				return aContains.localeCompare(bContains);
			});

			// Update with sorted keywords
			await updateGroup(Settings, targetGroupId, { keywords: sortedKeywords });
		}

		// Re-render groups
		if (window._renderKeywordGroups) {
			await window._renderKeywordGroups();
		}

		// Notify service worker
		chrome.runtime.sendMessage({ action: "keywordsUpdated" });
	} catch (error) {
		console.error("Error moving keyword:", error);
		alert(getMessageOrDefault("kwErrorMovingKeyword", "Error moving keyword: ") + error.message);
	} finally {
		cleanupDragState();
	}
}

/**
 * Handles drag end event
 * @param {DragEvent} e - The drag end event
 */
function handleDragEnd(e) {
	// Only cleanup if this is our drag
	if (dragState.isDragging) {
		cleanupDragState();
	}
}

/**
 * Cleans up drag state and restores UI
 */
function cleanupDragState() {
	if (dragState.draggedRow) {
		dragState.draggedRow.style.opacity = "";
		dragState.draggedRow.draggable = false;
	}

	// Remove drop zones and hide containers
	dragState.dropZones.forEach((zone) => zone.remove());
	dragState.dropZones = [];
	document.querySelectorAll(".keyword-drop-zone-container").forEach((container) => {
		container.style.display = "none";
	});

	// Restore group collapsed states
	document.querySelectorAll(".keyword-group").forEach((groupDiv) => {
		const gId = groupDiv.dataset.groupId;
		const wasCollapsed = dragState.groupStates[gId];
		if (wasCollapsed) {
			groupDiv.classList.add("collapsed");
		} else {
			groupDiv.classList.remove("collapsed");
		}
	});

	// Reset drag state
	dragState.isDragging = false;
	dragState.draggedRow = null;
	dragState.sourceGroupId = null;
	dragState.sourceKeywordIndex = null;
	dragState.keywordData = null;
	dragState.groupStates = {};
}

/**
 * Sets up drag handlers for a keyword row
 * This should be called after the row is created and the handle div is added
 * @param {HTMLTableRowElement} tr - The table row element
 */
export function setupKeywordRowDragHandlers(tr) {
	// Row is non-draggable by default so Firefox allows caret positioning in inputs (draggable parent blocks click-to-position in FF).
	// Only enable draggable when user mousedowns on the handle.
	tr.draggable = false;
	tr.style.cursor = "default";
	tr.dataset.dragAllowed = "false"; // Flag to control if drag is allowed

	const handleDiv = tr.querySelector(".keyword-drag-handle > div");
	if (!handleDiv) return;

	// When handle is clicked, enable drag for this row
	handleDiv.addEventListener("mousedown", (e) => {
		tr.dataset.dragAllowed = "true";
		tr.draggable = true;
		e.stopPropagation();
	});

	// Handle drag start on the row (triggered when dragging from handle)
	tr.addEventListener("dragstart", async (e) => {
		// Only allow drag if it was initiated from the handle
		if (tr.dataset.dragAllowed !== "true") {
			e.preventDefault();
			e.stopPropagation();
			return false;
		}

		const row = e.currentTarget;
		if (!row || !row.dataset.groupId) {
			e.preventDefault();
			return;
		}

		const groupId = row.dataset.groupId;
		const keywordIndex = parseInt(row.dataset.keywordIndex) || 0;

		// Get keyword data - try to get original from group first, then update with current input values
		let keywordData = null;

		// Get current input values
		const containsInput = row.querySelector('input[name="contains"]');
		const withoutInput = row.querySelector('input[name="without"]');
		const etvMinInput = row.querySelector('input[name="etv_min"]');
		const etvMaxInput = row.querySelector('input[name="etv_max"]');

		const contains = containsInput ? containsInput.value.trim() : "";
		const without = withoutInput ? withoutInput.value.trim() : "";
		const etv_min = etvMinInput ? etvMinInput.value.trim() : "";
		const etv_max = etvMaxInput ? etvMaxInput.value.trim() : "";

		// If this is a saved keyword, get the original from the group
		if (keywordIndex < 10000) {
			try {
				const group = await getGroupById(Settings, groupId);
				if (group && group.keywords && group.keywords[keywordIndex]) {
					// Clone the original keyword
					keywordData = { ...group.keywords[keywordIndex] };
				}
			} catch (err) {
				// Error getting keyword from group, will build from inputs
			}
		}

		// If we don't have keyword data, build it from inputs
		if (!keywordData) {
			keywordData = {};
		}

		// Update with current input values (overwrite original with current values)
		// Only include properties that have non-empty values
		if (contains) {
			keywordData.contains = contains;
		} else {
			delete keywordData.contains;
		}

		if (without) {
			keywordData.without = without;
		} else {
			delete keywordData.without;
		}

		if (etv_min) {
			keywordData.etv_min = etv_min;
		} else {
			delete keywordData.etv_min;
		}

		if (etv_max) {
			keywordData.etv_max = etv_max;
		} else {
			delete keywordData.etv_max;
		}

		// Preserve note if it exists
		if (row.dataset.keywordNote) {
			keywordData.note = row.dataset.keywordNote;
		} else if (keywordData.note) {
			// Keep existing note from original keyword
		}

		// Validate that at least one field has a value
		// The validation function checks: !keyword.contains && !keyword.without && !keyword.etv_min && !keyword.etv_max
		// So at least one must be truthy (non-empty string)
		const hasValidField = keywordData.contains || keywordData.without || keywordData.etv_min || keywordData.etv_max;

		if (!hasValidField) {
			e.preventDefault();
			alert("Cannot move keyword: at least one field must have a value.");
			return;
		}

		// Store drag state
		dragState.isDragging = true;
		dragState.draggedRow = row;
		dragState.sourceGroupId = groupId;
		dragState.sourceKeywordIndex = keywordIndex;
		dragState.keywordData = keywordData;

		// Store current collapsed state of all groups
		document.querySelectorAll(".keyword-group").forEach((groupDiv) => {
			const gId = groupDiv.dataset.groupId;
			dragState.groupStates[gId] = groupDiv.classList.contains("collapsed");
		});

		// Scroll to the first keyword group
		const firstGroup = document.querySelector(".keyword-group");
		if (firstGroup) {
			firstGroup.scrollIntoView({ behavior: "smooth", block: "start" });
		}

		// Defer DOM manipulation to avoid cancelling drag
		// Use requestAnimationFrame to ensure drag is fully started
		requestAnimationFrame(() => {
			// Collapse all groups
			document.querySelectorAll(".keyword-group").forEach((groupDiv) => {
				groupDiv.classList.add("collapsed");
			});

			// Create drop zones for each group
			createDropZones();
		});

		// Set drag data
		e.dataTransfer.effectAllowed = "move";
		e.dataTransfer.setData("text/plain", groupId + ":" + keywordIndex);

		// Create a simple drag image showing the "contains" keyword
		// Use the 'contains' variable already extracted above
		const displayText = contains || "(empty keyword)";

		// Create a simple div with the contains value
		const dragImage = document.createElement("div");
		dragImage.textContent = displayText;
		dragImage.style.cssText = `
			position: absolute;
			top: -10000px;
			left: -10000px;
			padding: 8px 12px;
			background: #fff;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-shadow: 0 4px 8px rgba(0,0,0,0.2);
			font-size: 14px;
			white-space: nowrap;
			z-index: 10000;
		`;
		document.body.appendChild(dragImage);

		// Set drag image with offset to center it on cursor
		const offsetX = 10;
		const offsetY = 10;
		e.dataTransfer.setDragImage(dragImage, offsetX, offsetY);

		// Clean up immediately after setting drag image
		setTimeout(() => {
			if (document.body.contains(dragImage)) {
				document.body.removeChild(dragImage);
			}
		}, 0);

		// Visual feedback
		row.style.opacity = "0.5";
	});

	// Handle drag end on the row
	tr.addEventListener("dragend", (e) => {
		tr.dataset.dragAllowed = "false";
		tr.draggable = false; // Back to non-draggable so input clicks work in Firefox
		setTimeout(() => {
			handleDragEnd(e);
		}, 100);
	});

	// When mousedown is on an input/button, keep row non-draggable and stop propagation.
	// In Firefox, a draggable parent prevents click-to-position caret in inputs; keeping
	// the row non-draggable until the handle is used fixes this.
	tr.querySelectorAll("input, button, .vh-button-icon-compact, .vh-icon-only-button").forEach((element) => {
		element.addEventListener("mousedown", (e) => {
			tr.dataset.dragAllowed = "false";
			tr.draggable = false;
			e.stopPropagation();
		});
	});
}
