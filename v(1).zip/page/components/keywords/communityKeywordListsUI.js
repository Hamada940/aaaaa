/**
 * Community keyword lists UI orchestration.
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import {
	addGroup,
	updateGroup,
	findGroupByName,
	linkGroupToCommunityList,
	unlinkGroupFromCommunityList,
	getLinkedCommunityGroups,
	getGroupById,
	normalizeCommunityLink,
} from "/scripts/core/utils/KeywordGroupsManager.js";
import {
	listCommunityKeywordLists,
	getCommunityKeywordList,
	checkCommunityKeywordUpdates,
	getCommunityKeywordContributionContext,
	checkCommunityKeywordName,
	submitCommunityKeywordList,
	submitCommunityKeywordContribution,
	subscribeCommunityKeywordList,
	unsubscribeCommunityKeywordList,
} from "./communityKeywordListsApi.js";
import {
	diffKeywordLists,
	keywordsAreEqual,
	sortKeywords,
	renderKeywordDiff,
	formatKeywordLabel,
} from "./communityKeywordListDiff.js";

const Settings = new SettingsMgr();
const Tpl = new Template();

/** @type {Map<number, boolean>} */
const updateAvailableMap = new Map();

export function hasCommunityListUpdate(listId) {
	return updateAvailableMap.get(Number(listId)) === true;
}

function getDiffLabels() {
	return {
		leftTitle: getMessageOrDefault("kwCommunityDiffCurrent", "Current"),
		rightTitle: getMessageOrDefault("kwCommunityDiffNew", "New"),
		addedLabel: getMessageOrDefault("kwCommunityDiffAdded", "Added"),
		removedLabel: getMessageOrDefault("kwCommunityDiffRemoved", "Removed"),
		unchangedLabel: getMessageOrDefault("kwCommunityDiffUnchanged", "Unchanged"),
	};
}

async function loadTemplate(url) {
	const html = await Tpl.loadFile(url, true);
	return Tpl.render(html);
}

function mountDialog(html) {
	const wrap = document.createElement("div");
	wrap.innerHTML = html;
	document.body.appendChild(wrap);
	return wrap;
}

function dialogPromise(wrap, { onConfirm, validate }) {
	return new Promise((resolve) => {
		const overlay = wrap.querySelector(".vh-dialog-overlay");
		const close = (result) => {
			document.removeEventListener("keydown", onEscape);
			wrap.remove();
			resolve(result);
		};
		const onEscape = (e) => {
			if (e.key === "Escape") close(null);
		};
		document.addEventListener("keydown", onEscape);
		overlay?.addEventListener("click", (e) => {
			if (e.target === overlay) close(null);
		});
		wrap.querySelectorAll(".vh-dialog-close, [id$='Cancel']").forEach((btn) => {
			btn.addEventListener("click", () => close(null));
		});
		const confirmBtn = wrap.querySelector("[id$='Confirm'], [id$='Submit']");
		confirmBtn?.addEventListener("click", async () => {
			if (validate) {
				const ok = await validate();
				if (!ok) return;
			}
			if (onConfirm) {
				const result = await onConfirm();
				if (result === false) return;
			}
			close(true);
		});
	});
}

export async function showKeywordDiffDialog({ title, intro, oldKeywords, newKeywords, confirmLabel }) {
	const html = await loadTemplate("/page/components/keywords/templates/community_list_diff_dialog.tpl.html");
	const wrap = mountDialog(html);
	wrap.querySelector("#communityDiffTitle").textContent = title;
	wrap.querySelector("#communityDiffIntro").textContent = intro;
	const diffContainer = wrap.querySelector("#communityDiffContainer");
	renderKeywordDiff(diffContainer, diffKeywordLists(oldKeywords, newKeywords), getDiffLabels());
	wrap.querySelector("#communityDiffConfirm").textContent =
		confirmLabel || getMessageOrDefault("kwCommunityConfirm", "Confirm");
	return dialogPromise(wrap, {});
}

function filterCommunityLists(lists, query) {
	const q = query.trim().toLowerCase();
	if (!q) return lists;
	return lists.filter((list) => {
		const name = (list.name || "").toLowerCase();
		const description = (list.description || "").toLowerCase();
		return name.includes(q) || description.includes(q);
	});
}

function renderCommunityListRow(list, { onPreview, onImport }) {
	const row = document.createElement("div");
	row.className = "kw-community-browser-row";
	row.dataset.listName = (list.name || "").toLowerCase();
	row.dataset.listDescription = (list.description || "").toLowerCase();
	row.innerHTML = `
		<div class="kw-community-browser-name" title="${escapeHtml(list.name)}">${escapeHtml(list.name)}</div>
		<div class="kw-community-browser-desc" title="${escapeHtml(list.description || "")}">${escapeHtml(list.description || "")}</div>
		<div class="kw-community-browser-meta">${getMessageOrDefault("kwCommunitySubscribers", "Users")}: ${list.subscriber_count} · ${getMessageOrDefault("kwCommunityKeywords", "Keywords")}: ${list.keyword_count}</div>
		<div class="kw-community-browser-actions">
			<button type="button" class="vh-dialog-btn vh-dialog-btn-secondary vh-dialog-btn-compact kw-community-preview-btn">${getMessageOrDefault("kwCommunityPreview", "Preview")}</button>
			<button type="button" class="vh-dialog-btn vh-dialog-btn-primary vh-dialog-btn-compact kw-community-import-btn">${getMessageOrDefault("kwCommunityImport", "Import")}</button>
		</div>`;
	row.querySelector(".kw-community-preview-btn").addEventListener("click", () => onPreview(list));
	row.querySelector(".kw-community-import-btn").addEventListener("click", () => onImport(list));
	return row;
}

export async function showCommunityListsBrowser({ onImport }) {
	const html = await loadTemplate("/page/components/keywords/templates/community_lists_browser.tpl.html");
	const wrap = mountDialog(html);
	const loading = wrap.querySelector("#communityListsLoading");
	const empty = wrap.querySelector("#communityListsEmpty");
	const noResults = wrap.querySelector("#communityListsNoResults");
	const container = wrap.querySelector("#communityListsContainer");
	const toolbar = wrap.querySelector("#communityListsToolbar");
	const searchInput = wrap.querySelector("#communityListsSearch");
	const searchCount = wrap.querySelector("#communityListsSearchCount");

	const close = () => wrap.remove();
	wrap.querySelector("#communityListsBrowserClose")?.addEventListener("click", close);
	wrap.querySelector("#communityListsBrowserOverlay")?.addEventListener("click", (e) => {
		if (e.target.id === "communityListsBrowserOverlay") close();
	});

	const onPreview = async (list) => {
		const detail = await getCommunityKeywordList(list.list_id);
		const keywords = sortKeywords(detail.keywords_json);
		const previewHtml = await loadTemplate(
			"/page/components/keywords/templates/community_list_diff_dialog.tpl.html"
		);
		const previewWrap = mountDialog(previewHtml);
		previewWrap.querySelector("#communityDiffTitle").textContent = getMessageOrDefault(
			"kwCommunityPreviewTitle",
			"Preview: $1$",
			[list.name]
		);
		previewWrap.querySelector("#communityDiffIntro").textContent = list.description || "";
		const previewContainer = previewWrap.querySelector("#communityDiffContainer");
		previewContainer.innerHTML = `<ul class="kw-community-preview-list">${keywords
			.map((kw) => `<li>${escapeHtml(formatKeywordLabel(kw))}</li>`)
			.join("")}</ul>`;
		previewWrap.querySelector("#communityDiffConfirm").textContent = getMessageOrDefault("dialogClose", "Close");
		previewWrap.querySelector("#communityDiffCancel").hidden = true;
		await dialogPromise(previewWrap, {});
	};

	const onImportRow = (list) => {
		close();
		if (onImport) onImport(list);
	};

	const renderFilteredLists = (allLists, query = "") => {
		const filtered = filterCommunityLists(allLists, query);
		container.innerHTML = "";
		noResults.hidden = true;

		if (query.trim()) {
			searchCount.hidden = false;
			searchCount.textContent = getMessageOrDefault("kwCommunitySearchCount", "Showing $1$ of $2$ lists", [
				String(filtered.length),
				String(allLists.length),
			]);
		} else {
			searchCount.hidden = true;
		}

		if (!filtered.length) {
			noResults.hidden = false;
			return;
		}

		for (const list of filtered) {
			container.appendChild(renderCommunityListRow(list, { onPreview, onImport: onImportRow }));
		}
	};

	try {
		const lists = await listCommunityKeywordLists();
		loading.hidden = true;
		if (!lists.length) {
			empty.hidden = false;
			return;
		}

		toolbar.hidden = false;
		renderFilteredLists(lists);

		searchInput?.addEventListener("input", () => {
			renderFilteredLists(lists, searchInput.value);
		});
	} catch (err) {
		loading.textContent =
			err.message || getMessageOrDefault("kwCommunityErrorLoad", "Failed to load community lists.");
	}
}

function escapeHtml(value) {
	return String(value ?? "")
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;")
		.replace(/"/g, "&quot;");
}

export async function showCommunityImportDialog(list) {
	const existing = await findGroupByName(Settings, list.name);

	if (existing) {
		const detail = await getCommunityKeywordList(list.list_id);
		const ok = await showKeywordDiffDialog({
			title: getMessageOrDefault("kwCommunityOverrideTitle", "Replace existing group?"),
			intro: getMessageOrDefault(
				"kwCommunityOverrideIntro",
				'A local group named "$NAME$" already exists. Importing will replace its keywords.',
				[list.name]
			),
			oldKeywords: existing.keywords || [],
			newKeywords: detail.keywords_json,
			confirmLabel: getMessageOrDefault("kwCommunityOverrideConfirm", "Replace keywords"),
		});
		if (!ok) return false;

		if (existing.communityLink?.listId && existing.communityLink.listId !== list.list_id) {
			await unsubscribeCommunityKeywordList(existing.communityLink.listId).catch(() => {});
		}
		await updateGroup(Settings, existing.id, { keywords: detail.keywords_json });
		await linkGroupToCommunityList(Settings, existing.id, {
			listId: list.list_id,
			name: list.name,
			revision: detail.revision,
		});
		await subscribeCommunityKeywordList(list.list_id).catch(() => {});
		return true;
	}

	const isPremiumBlur = Settings.isPremiumUser(2);
	const html = await loadTemplate("/page/components/keywords/templates/community_list_import_dialog.tpl.html");
	const wrap = mountDialog(html);
	const intro = wrap.querySelector("#communityImportIntro");
	const typeSelect = wrap.querySelector("#communityImportType");
	intro.textContent = getMessageOrDefault("kwCommunityImportIntro", 'Import "$NAME$" as a new local keyword group.', [
		list.name,
	]);
	if (!isPremiumBlur) {
		const blurOpt = typeSelect.querySelector('option[value="blur"]');
		if (blurOpt) {
			blurOpt.disabled = true;
			blurOpt.textContent = getMessageOrDefault(
				"kwAddGroupBlurUpgradeRequired",
				"Blur (Premium Tier 2) - Upgrade Required"
			);
		}
	}

	const confirmed = await dialogPromise(wrap, {
		validate: async () => {
			if (typeSelect.value === "blur" && !isPremiumBlur) {
				alert(
					getMessageOrDefault(
						"kwAddGroupAlertBlurPremium",
						"Blur groups are reserved for Premium Tier 2 members."
					)
				);
				return false;
			}
			return true;
		},
	});
	if (!confirmed) return false;

	const detail = await getCommunityKeywordList(list.list_id);
	const type = typeSelect.value;

	const newGroup = await addGroup(Settings, list.name, type);
	await updateGroup(Settings, newGroup.id, { keywords: detail.keywords_json });
	await linkGroupToCommunityList(Settings, newGroup.id, {
		listId: list.list_id,
		name: list.name,
		revision: detail.revision,
	});
	await subscribeCommunityKeywordList(list.list_id).catch(() => {});
	return true;
}

export async function showCommunityUploadDialog(group) {
	const html = await loadTemplate("/page/components/keywords/templates/community_list_upload_dialog.tpl.html");
	const wrap = mountDialog(html);
	const nameInput = wrap.querySelector("#communityUploadName");
	const descInput = wrap.querySelector("#communityUploadDescription");
	const statusEl = wrap.querySelector("#communityUploadNameStatus");
	nameInput.value = group.name;

	let nameAvailable = false;
	const checkName = async () => {
		const name = nameInput.value.trim();
		if (!name) {
			statusEl.textContent = "";
			nameAvailable = false;
			return;
		}
		try {
			nameAvailable = await checkCommunityKeywordName(name);
			statusEl.textContent = nameAvailable
				? getMessageOrDefault("kwCommunityNameAvailable", "Name is available.")
				: getMessageOrDefault("kwCommunityNameTaken", "This name is already taken or pending.");
			statusEl.className = nameAvailable
				? "vh-dialog-hint kw-community-name-ok"
				: "vh-dialog-hint kw-community-name-taken";
		} catch {
			statusEl.textContent = "";
		}
	};
	nameInput.addEventListener("blur", checkName);
	await checkName();

	const confirmed = await dialogPromise(wrap, {
		validate: async () => {
			await checkName();
			if (!nameInput.value.trim()) {
				alert(getMessageOrDefault("kwAddGroupAlertEnterName", "Please enter a group name."));
				return false;
			}
			if (!descInput.value.trim()) {
				alert(getMessageOrDefault("kwCommunityDescriptionRequired", "Please enter a description."));
				return false;
			}
			if (!nameAvailable) {
				alert(getMessageOrDefault("kwCommunityNameTaken", "This name is already taken or pending."));
				return false;
			}
			return true;
		},
		onConfirm: async () => {
			const keywords = (group.keywords || []).filter(
				(kw) => kw.contains || kw.without || kw.etv_min || kw.etv_max
			);
			await submitCommunityKeywordList({
				name: nameInput.value.trim(),
				description: descInput.value.trim(),
				keywords: sortKeywords(keywords),
			});
			alert(
				getMessageOrDefault(
					"kwCommunityUploadPending",
					"Your list has been submitted and is pending admin approval."
				)
			);
			return true;
		},
	});
	return confirmed;
}

export async function showCommunityContributionDialog(group) {
	const link = group.communityLink;
	if (!link) return false;

	let context;
	try {
		context = await getCommunityKeywordContributionContext(link.listId);
	} catch (err) {
		alert(err.message);
		return false;
	}

	if (!context.exists) {
		await unlinkGroupFromCommunityList(Settings, group.id);
		alert(
			getMessageOrDefault(
				"kwCommunityListRemoved",
				"This community list no longer exists. The link has been removed."
			)
		);
		return "unlinked";
	}

	if (context.has_pending_contribution) {
		alert(
			getMessageOrDefault(
				"kwCommunityPendingContribution",
				"You already have a pending submission for this list."
			)
		);
		return false;
	}

	const localKeywords = (group.keywords || []).filter((kw) => kw.contains || kw.without || kw.etv_min || kw.etv_max);
	if (keywordsAreEqual(localKeywords, context.keywords_json)) {
		alert(getMessageOrDefault("kwCommunityNoChanges", "No changes to submit."));
		return false;
	}

	const isUpdate = context.contribution_mode === "publish_update";
	const html = await loadTemplate("/page/components/keywords/templates/community_list_contribution_dialog.tpl.html");
	const wrap = mountDialog(html);
	wrap.querySelector("#communityContributionTitle").textContent = isUpdate
		? getMessageOrDefault("kwCommunityPublishUpdateTitle", "Publish update")
		: getMessageOrDefault("kwCommunityProposeChangeTitle", "Propose changes");
	wrap.querySelector("#communityContributionIntro").textContent = isUpdate
		? getMessageOrDefault(
				"kwCommunityPublishUpdateIntro",
				"The live list stays unchanged until an admin approves your update."
			)
		: getMessageOrDefault(
				"kwCommunityProposeChangeIntro",
				"Your proposal will be reviewed by moderators. The live list stays unchanged until approved."
			);
	renderKeywordDiff(
		wrap.querySelector("#communityContributionDiff"),
		diffKeywordLists(context.keywords_json, localKeywords),
		getDiffLabels()
	);
	const submitBtn = wrap.querySelector("#communityContributionSubmit");
	submitBtn.textContent = isUpdate
		? getMessageOrDefault("kwCommunityPublishUpdateSubmit", "Submit update")
		: getMessageOrDefault("kwCommunityProposeChangeSubmit", "Submit proposal");
	const noteInput = wrap.querySelector("#communityContributionNote");

	const confirmed = await dialogPromise(wrap, {
		validate: async () => {
			if (!noteInput.value.trim()) {
				alert(getMessageOrDefault("kwCommunityChangeNoteRequired", "Please explain your changes."));
				return false;
			}
			return true;
		},
		onConfirm: async () => {
			const result = await submitCommunityKeywordContribution({
				listId: link.listId,
				keywords: sortKeywords(localKeywords),
				changeNote: noteInput.value.trim(),
			});
			const msg =
				result.submission_type === "update"
					? getMessageOrDefault("kwCommunityUpdatePending", "Your update is pending admin approval.")
					: getMessageOrDefault("kwCommunityProposalPending", "Your proposal is pending admin approval.");
			alert(msg);
			return true;
		},
	});
	return confirmed;
}

export async function showCommunityDownloadDialog(group) {
	const link = group.communityLink;
	if (!link) return false;

	const results = await checkCommunityKeywordUpdates([{ list_id: link.listId, revision: link.revision }]);
	const result = results[0];

	if (!result || !result.exists) {
		await unlinkGroupFromCommunityList(Settings, group.id);
		updateAvailableMap.delete(link.listId);
		alert(
			getMessageOrDefault(
				"kwCommunityListRemoved",
				"This community list no longer exists. The link has been removed."
			)
		);
		return "unlinked";
	}

	updateAvailableMap.set(link.listId, result.has_update);

	if (!result.has_update) {
		alert(getMessageOrDefault("kwCommunityUpToDate", "Your list is already up to date."));
		return false;
	}

	const detail = await getCommunityKeywordList(link.listId);
	const localKeywords = group.keywords || [];
	const ok = await showKeywordDiffDialog({
		title: getMessageOrDefault("kwCommunityDownloadTitle", "Download latest version"),
		intro: getMessageOrDefault("kwCommunityDownloadIntro", "A newer version of this community list is available."),
		oldKeywords: localKeywords,
		newKeywords: detail.keywords_json,
		confirmLabel: getMessageOrDefault("kwCommunityDownloadConfirm", "Apply update"),
	});
	if (!ok) return false;

	await updateGroup(Settings, group.id, { keywords: detail.keywords_json });
	await linkGroupToCommunityList(Settings, group.id, {
		listId: link.listId,
		name: link.name,
		revision: detail.revision,
	});
	updateAvailableMap.set(link.listId, false);
	return true;
}

export async function handleCommunityGroupDelete(group) {
	if (!group.communityLink?.listId) return;
	try {
		await unsubscribeCommunityKeywordList(group.communityLink.listId);
	} catch {
		// Best-effort unsubscribe
	}
}

export async function refreshCommunityListUpdates(renderCallback) {
	const linked = await getLinkedCommunityGroups(Settings);
	if (!linked.length) return;

	const checks = linked.map((g) => {
		const link = normalizeCommunityLink(g.communityLink);
		return { list_id: link.listId, revision: link.revision };
	});
	try {
		const results = await checkCommunityKeywordUpdates(checks);
		let anyUnlinked = false;
		let anyUpdate = false;
		for (const result of results) {
			const listId = Number(result.list_id);
			if (!result.exists) {
				const group = linked.find((g) => normalizeCommunityLink(g.communityLink)?.listId === listId);
				if (group) {
					await unlinkGroupFromCommunityList(Settings, group.id);
					anyUnlinked = true;
				}
				updateAvailableMap.delete(listId);
			} else {
				updateAvailableMap.set(listId, !!result.has_update);
				if (result.has_update) anyUpdate = true;
			}
		}
		if ((anyUpdate || anyUnlinked) && renderCallback) {
			await renderCallback();
		}
	} catch {
		// Silent on load failure
	}
}

export async function handleCommunityUploadClick(group, renderCallback) {
	if (group.communityLink) {
		const result = await showCommunityContributionDialog(group);
		if (result === "unlinked" && renderCallback) await renderCallback();
		else if (result && renderCallback) await renderCallback();
	} else {
		await showCommunityUploadDialog(group);
	}
}

export async function handleCommunityDownloadClick(group, renderCallback) {
	const result = await showCommunityDownloadDialog(group);
	if (result && renderCallback) await renderCallback();
}

export async function initCommunityKeywordListsUI(renderCallback) {
	const browseBtn = document.getElementById("browseCommunityKeywordLists");
	if (browseBtn && !browseBtn._VHelperClickHandler) {
		browseBtn._VHelperClickHandler = async () => {
			await showCommunityListsBrowser({
				onImport: async (list) => {
					const imported = await showCommunityImportDialog(list);
					if (imported && renderCallback) {
						await renderCallback();
						chrome.runtime.sendMessage({ action: "keywordsUpdated" });
					}
				},
			});
		};
		browseBtn.addEventListener("click", browseBtn._VHelperClickHandler);
	}
}
