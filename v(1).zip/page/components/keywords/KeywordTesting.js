/**
 * @fileoverview Keyword testing UI — traces keyword matching against a test title.
 */

import { compileKeywordObjects } from "/scripts/core/utils/KeywordCompiler.js";
import { traceKeywordObject } from "/scripts/core/utils/KeywordMatcher.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { getGroups } from "/scripts/core/utils/KeywordGroupsManager.js";
import { isEffectivelyEmpty, ENGLISH_TEMPLATES } from "./keywordTestingMessages.js";

const TYPE_ACTION_KEYS = {
	highlight: "kwAddGroupTypeHighlight",
	hide: "kwAddGroupTypeHide",
	blur: "kwAddGroupTypeBlur",
};

const TYPE_ACTION_DEFAULTS = {
	highlight: "Highlight",
	hide: "Hide",
	blur: "Blur",
};

function getTypeActionLabel(type) {
	const key = TYPE_ACTION_KEYS[type];
	return key ? getMessageOrDefault(key, TYPE_ACTION_DEFAULTS[type] || type) : type;
}

function isEffectivelyEmptyValue(value) {
	return isEffectivelyEmpty(value);
}

function readKeywordFromRow(row) {
	return {
		contains: row.querySelector('input[name="contains"]')?.value?.trim() || "",
		without: row.querySelector('input[name="without"]')?.value?.trim() || "",
		etv_min: row.querySelector('input[name="etv_min"]')?.value?.trim() || "",
		etv_max: row.querySelector('input[name="etv_max"]')?.value?.trim() || "",
	};
}

function normalizeStoredKeyword(keyword) {
	if (!keyword || typeof keyword !== "object") {
		return { contains: "", without: "", etv_min: "", etv_max: "" };
	}
	return {
		contains: keyword.contains != null ? String(keyword.contains).trim() : "",
		without: keyword.without != null ? String(keyword.without).trim() : "",
		etv_min: keyword.etv_min != null ? String(keyword.etv_min).trim() : "",
		etv_max: keyword.etv_max != null ? String(keyword.etv_max).trim() : "",
	};
}

function getKeywordEntriesFromGroup(group) {
	if (group.rows && group.rows.length > 0) {
		return group.rows.map((row) => ({ keyword: readKeywordFromRow(row), row }));
	}
	return (group.keywords || []).map((keyword) => ({
		keyword: normalizeStoredKeyword(keyword),
		row: null,
	}));
}

function readGroupFromElement(groupEl) {
	const enabled = groupEl.querySelector(".keyword-group-enabled-toggle")?.checked !== false;
	const name = groupEl.querySelector(".keyword-group-name-input")?.value?.trim() || "";
	const type = groupEl.querySelector(".keyword-group-type-select")?.value || "highlight";
	const rows = [...groupEl.querySelectorAll(".keyword-row")];
	return { id: groupEl.dataset.groupId || "", enabled, name, type, rows };
}

function buildEtvStep(groupName, contains, etvMin, etvMax) {
	return getMessageOrDefault("kwTestStepEtvExcluded", ENGLISH_TEMPLATES.etvExcluded, [
		groupName,
		contains,
		etvMin || "—",
		etvMax || "—",
	]);
}

function buildWithoutExcludedStep(groupName, contains, without) {
	return getMessageOrDefault("kwTestStepWithoutExcluded", ENGLISH_TEMPLATES.withoutExcluded, [
		groupName,
		contains,
		without,
	]);
}

function buildGroupNoMatchStep(groupName) {
	return getMessageOrDefault("kwTestGroupNoMatch", ENGLISH_TEMPLATES.groupNoMatch, [groupName]);
}

function buildHighlightHideSectionHeader() {
	return getMessageOrDefault("kwTestSectionHighlightHide", ENGLISH_TEMPLATES.sectionHighlightHide);
}

function buildBlurSectionHeader() {
	return getMessageOrDefault("kwTestSectionBlur", ENGLISH_TEMPLATES.sectionBlur);
}

function appendSectionHeader(steps, message) {
	steps.push({ kind: "section-header", message });
}

function appendGroupSteps(allSteps, group, steps, matchedRow) {
	allSteps.push(...steps);
	if (group.enabled && !matchedRow && group.name) {
		allSteps.push({
			kind: "no-match",
			message: buildGroupNoMatchStep(group.name),
		});
	}
}

function buildMatchStep(groupName, contains, without, actionLabel) {
	if (isEffectivelyEmpty(without)) {
		return getMessageOrDefault("kwTestStepMatchWithoutEmpty", ENGLISH_TEMPLATES.matchWithoutEmpty, [
			groupName,
			contains,
			actionLabel,
		]);
	}
	return getMessageOrDefault("kwTestStepMatchWithoutNotMatched", ENGLISH_TEMPLATES.matchWithoutNotMatched, [
		groupName,
		contains,
		without,
		actionLabel,
	]);
}

function traceKeywordRow(title, keyword, groupName, groupType, itemEtvMin = null, itemEtvMax = null) {
	if (!keyword.contains && !keyword.without) {
		return null;
	}

	let compiled;
	try {
		[compiled] = compileKeywordObjects([keyword]);
	} catch {
		return null;
	}

	if (!compiled) {
		return null;
	}

	const trace = traceKeywordObject(title, compiled, itemEtvMin, itemEtvMax);
	if (!trace.containsMatch) {
		return null;
	}

	const actionLabel = getTypeActionLabel(groupType);

	if (!trace.etvSatisfied) {
		return {
			kind: "excluded",
			message: buildEtvStep(groupName, keyword.contains, keyword.etv_min, keyword.etv_max),
			trace,
		};
	}

	if (trace.withoutMatch) {
		return {
			kind: "excluded",
			message: buildWithoutExcludedStep(groupName, keyword.contains, keyword.without),
			trace,
		};
	}

	if (trace.isFullMatch) {
		return {
			kind: "match",
			message: buildMatchStep(groupName, keyword.contains, keyword.without, actionLabel),
			trace,
			groupType,
		};
	}

	return null;
}

function traceGroupKeywords(title, group, itemEtvMin, itemEtvMax, stopOnMatch) {
	const steps = [];
	let matchedRow = null;

	if (!group.enabled) {
		if (group.name) {
			steps.push({
				kind: "info",
				message: getMessageOrDefault("kwTestSkippedDisabledGroup", ENGLISH_TEMPLATES.skippedDisabledGroup, [
					group.name,
				]),
			});
		}
		return { steps, matchedRow };
	}

	for (const { keyword, row } of getKeywordEntriesFromGroup(group)) {
		if (isEffectivelyEmptyValue(keyword.contains) && isEffectivelyEmptyValue(keyword.without)) {
			continue;
		}

		const rowTrace = traceKeywordRow(title, keyword, group.name, group.type, itemEtvMin, itemEtvMax);
		if (!rowTrace) {
			continue;
		}

		steps.push(rowTrace);

		if (rowTrace.kind === "match") {
			matchedRow = row;
			if (stopOnMatch) {
				break;
			}
		}
	}

	return { steps, matchedRow };
}

function getGroupsFromContainer(container, sectionType) {
	const selector =
		sectionType === "blur"
			? ".keyword-groups-blur-container .keyword-group"
			: ".keyword-groups-highlight-hide-container .keyword-group";
	return [...container.querySelectorAll(selector)].map(readGroupFromElement);
}

function clearTestHighlights(container) {
	container.querySelectorAll(".keyword-row-test-match").forEach((row) => {
		row.classList.remove("keyword-row-test-match");
	});
}

function renderTestLog(logEl, steps, summaryMessage) {
	logEl.innerHTML = "";

	if (steps.length === 0 && !summaryMessage) {
		logEl.classList.add("keywords-testing-log-empty");
		return;
	}

	logEl.classList.remove("keywords-testing-log-empty");

	for (const step of steps) {
		const line = document.createElement("div");
		line.className = `keywords-testing-log-line keywords-testing-log-line--${step.kind}`;
		line.textContent = step.message;
		logEl.appendChild(line);
	}

	if (summaryMessage) {
		const summary = document.createElement("div");
		summary.className = "keywords-testing-log-summary";
		summary.textContent = summaryMessage;
		logEl.appendChild(summary);
	}
}

function savedGroupsToTestGroups(groups, types) {
	return groups
		.filter((g) => types.includes(g.type) && g.enabled !== false)
		.sort((a, b) => a.order - b.order)
		.map((g) => ({
			enabled: true,
			name: g.name,
			type: g.type,
			keywords: g.keywords || [],
		}));
}

function summarizeMatch(steps) {
	const matchSteps = steps.filter((s) => s.kind === "match");
	if (matchSteps.length === 0) {
		return getMessageOrDefault("kwTestNoMatch", ENGLISH_TEMPLATES.noMatch);
	}
	if (matchSteps.length === 1) {
		return getMessageOrDefault("kwTestSummarySingle", ENGLISH_TEMPLATES.summarySingle, [
			getTypeActionLabel(matchSteps[0].groupType),
		]);
	}
	const actions = matchSteps.map((s) => getTypeActionLabel(s.groupType)).join(", ");
	return getMessageOrDefault("kwTestSummaryMultiple", ENGLISH_TEMPLATES.summaryMultiple, [actions]);
}

function runHighlightHideAndBlurTests(title, highlightHideGroups, blurGroups, itemEtvMin, itemEtvMax) {
	const highlightHideSteps = [];
	const blurSteps = [];
	const matchedRows = [];

	if (highlightHideGroups.length > 0) {
		appendSectionHeader(highlightHideSteps, buildHighlightHideSectionHeader());
	}

	for (const group of highlightHideGroups) {
		const { steps, matchedRow } = traceGroupKeywords(title, group, itemEtvMin, itemEtvMax, true);
		appendGroupSteps(highlightHideSteps, group, steps, matchedRow);
		if (matchedRow) {
			matchedRows.push(matchedRow);
			break;
		}
	}

	if (blurGroups.length > 0) {
		appendSectionHeader(blurSteps, buildBlurSectionHeader());
	}

	for (const group of blurGroups) {
		const { steps, matchedRow } = traceGroupKeywords(title, group, itemEtvMin, itemEtvMax, true);
		appendGroupSteps(blurSteps, group, steps, matchedRow);
		if (matchedRow) {
			matchedRows.push(matchedRow);
			break;
		}
	}

	return {
		allSteps: [...highlightHideSteps, ...blurSteps],
		matchedRows,
		summaryMessage: summarizeMatch([...highlightHideSteps, ...blurSteps]),
	};
}

function domSavedKeywordGroupsDiffer(container, savedGroups) {
	if (!container) return false;
	const domGroups = [
		...getGroupsFromContainer(container, "highlight-hide"),
		...getGroupsFromContainer(container, "blur"),
	];
	const savedById = new Map(savedGroups.map((g) => [g.id, g]));

	for (const domGroup of domGroups) {
		const groupId = domGroup.id;
		if (!groupId) continue;
		const saved = savedById.get(groupId);
		if (!saved) continue;

		const domEnabled = domGroup.enabled !== false;
		const savedEnabled = saved.enabled !== false;
		if (domEnabled !== savedEnabled) return true;

		const domKeywords = domGroup.rows
			.map((row) => readKeywordFromRow(row))
			.filter((kw) => kw.contains || kw.without || kw.etv_min || kw.etv_max)
			.map(normalizeStoredKeyword);
		const savedKeywords = (saved.keywords || []).map(normalizeStoredKeyword);
		if (JSON.stringify(domKeywords) !== JSON.stringify(savedKeywords)) {
			return true;
		}
	}
	return false;
}

/**
 * Tests a title against saved keyword groups (same source as the monitor) and
 * optionally warns when unsaved DOM edits differ.
 */
export async function runKeywordTest(title, container, logEl, settingsManager, itemEtvMin = null, itemEtvMax = null) {
	if (container) {
		clearTestHighlights(container);
	}

	const trimmedTitle = title?.trim() || "";
	if (!trimmedTitle) {
		if (logEl) {
			logEl.innerHTML = "";
			logEl.classList.add("keywords-testing-log-empty");
		}
		return;
	}

	const savedGroups = await getGroups(settingsManager);
	const highlightHideGroups = savedGroupsToTestGroups(savedGroups, ["highlight", "hide"]);
	const blurGroups = savedGroupsToTestGroups(savedGroups, ["blur"]);

	const { allSteps, matchedRows, summaryMessage } = runHighlightHideAndBlurTests(
		trimmedTitle,
		highlightHideGroups,
		blurGroups,
		itemEtvMin,
		itemEtvMax
	);

	if (container) {
		for (const row of matchedRows) {
			row.classList.add("keyword-row-test-match");
		}
	}

	const steps = [...allSteps];
	if (container && domSavedKeywordGroupsDiffer(container, savedGroups)) {
		steps.unshift({
			kind: "warning",
			message: getMessageOrDefault("kwTestUnsavedDomMismatch", ENGLISH_TEMPLATES.unsavedDomMismatch),
		});
	}

	if (logEl) {
		renderTestLog(logEl, steps, summaryMessage);
	}
}

/**
 * Tests the title against keyword groups rendered in the DOM and updates the testing log + row highlights.
 * @param {string} title - Test title text
 * @param {HTMLElement} container - #keywordGroupsContainer
 * @param {HTMLElement|null} logEl - #keywordsTestingLog
 * @param {number|null} [itemEtvMin=null]
 * @param {number|null} [itemEtvMax=null]
 */
export function runKeywordTestFromDom(title, container, logEl, itemEtvMin = null, itemEtvMax = null) {
	if (!container) {
		return;
	}

	clearTestHighlights(container);

	const trimmedTitle = title?.trim() || "";
	if (!trimmedTitle) {
		if (logEl) {
			logEl.innerHTML = "";
			logEl.classList.add("keywords-testing-log-empty");
		}
		return;
	}

	const highlightHideSteps = [];
	const blurSteps = [];
	const matchedRows = [];

	const highlightHideGroups = getGroupsFromContainer(container, "highlight-hide");
	if (highlightHideGroups.length > 0) {
		appendSectionHeader(highlightHideSteps, buildHighlightHideSectionHeader());
	}

	for (const group of highlightHideGroups) {
		const { steps, matchedRow } = traceGroupKeywords(trimmedTitle, group, itemEtvMin, itemEtvMax, true);
		appendGroupSteps(highlightHideSteps, group, steps, matchedRow);

		if (matchedRow) {
			matchedRows.push(matchedRow);
			break;
		}
	}

	const blurGroups = getGroupsFromContainer(container, "blur");
	if (blurGroups.length > 0) {
		appendSectionHeader(blurSteps, buildBlurSectionHeader());
	}

	for (const group of blurGroups) {
		const { steps, matchedRow } = traceGroupKeywords(trimmedTitle, group, itemEtvMin, itemEtvMax, true);
		appendGroupSteps(blurSteps, group, steps, matchedRow);
		if (matchedRow) {
			matchedRows.push(matchedRow);
			break;
		}
	}

	const allSteps = [...highlightHideSteps, ...blurSteps];

	for (const row of matchedRows) {
		row.classList.add("keyword-row-test-match");
	}

	const summaryMessage = summarizeMatch(allSteps);

	if (logEl) {
		renderTestLog(logEl, allSteps, summaryMessage);
	}
}
