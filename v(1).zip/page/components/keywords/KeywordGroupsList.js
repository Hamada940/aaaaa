/**
 * Keyword groups list component. Renders empty state or section containers with cards.
 * Section structure comes from templates; no createElement for list/section DOM.
 * @module KeywordGroupsList
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { renderKeywordGroupCard } from "./KeywordGroupCard.js";

const Tpl = new Template();
const EMPTY_TEMPLATE_URL = "/page/components/keywords/templates/keyword_groups_empty.tpl.html";
const HIGHLIGHT_HIDE_SECTION_URL = "/page/components/keywords/templates/keyword_groups_highlight_hide_section.tpl.html";
const BLUR_SECTION_URL = "/page/components/keywords/templates/keyword_groups_blur_section.tpl.html";

let cachedEmptyTemplateHtml = null;
let cachedHighlightHideSectionHtml = null;
let cachedBlurSectionHtml = null;

async function getEmptyTemplateHtml() {
	if (cachedEmptyTemplateHtml) return cachedEmptyTemplateHtml;
	cachedEmptyTemplateHtml = await Tpl.loadFile(EMPTY_TEMPLATE_URL, true);
	return cachedEmptyTemplateHtml;
}

async function getHighlightHideSectionHtml() {
	if (cachedHighlightHideSectionHtml) return cachedHighlightHideSectionHtml;
	cachedHighlightHideSectionHtml = await Tpl.loadFile(HIGHLIGHT_HIDE_SECTION_URL, true);
	return cachedHighlightHideSectionHtml;
}

async function getBlurSectionHtml() {
	if (cachedBlurSectionHtml) return cachedBlurSectionHtml;
	cachedBlurSectionHtml = await Tpl.loadFile(BLUR_SECTION_URL, true);
	return cachedBlurSectionHtml;
}

function parseTemplateToElement(html) {
	const wrap = document.createElement("div");
	wrap.innerHTML = html.trim();
	return wrap.firstElementChild;
}

/**
 * Renders the keyword groups list into container (empty message or sections with cards).
 * @param {Object} options
 * @param {HTMLElement} options.container - #keywordGroupsContainer
 * @param {Array<Object>} options.groups - All groups from getGroups()
 * @param {Set<string>} options.preserveCollapsedState - Group IDs to keep collapsed
 * @param {Object} options.deps - Same as KeywordGroupCard deps (Settings, updateGroup, deleteGroup, renderKeywordGroups, moveGroup, confirmPrompt, getGroupById, saveGroupKeywords, showKeywordNoteDialog, setupKeywordRowDragHandlers, isPremiumUser, deleteKeywordFromGroup)
 */
export async function renderKeywordGroupsList(options) {
	const { container, groups, preserveCollapsedState, deps } = options;

	container.innerHTML = "";

	if (!groups || groups.length === 0) {
		Tpl.setVar(
			"message",
			getMessageOrDefault("kwEmptyMessage", "No keyword groups yet. Click 'Add Group' to create one.")
		);
		const html = await getEmptyTemplateHtml();
		const rendered = Tpl.render(html);
		const wrap = document.createElement("div");
		wrap.innerHTML = rendered;
		const p = wrap.querySelector("p");
		if (p) container.appendChild(p);
		else container.appendChild(document.createTextNode(rendered));
		return;
	}

	const highlightHideGroups = groups.filter((g) => g.type === "highlight" || g.type === "hide");
	const blurGroups = groups.filter((g) => g.type === "blur");

	if (highlightHideGroups.length > 0) {
		const sectionHtml = await getHighlightHideSectionHtml();
		const highlightHideContainer = parseTemplateToElement(Tpl.render(sectionHtml));

		for (let i = 0; i < highlightHideGroups.length; i++) {
			const group = highlightHideGroups[i];
			const card = await renderKeywordGroupCard({
				group,
				index: i,
				totalGroups: highlightHideGroups.length,
				sectionType: "highlight-hide",
				deps,
			});
			if (preserveCollapsedState?.has(group.id)) card.classList.add("collapsed");
			highlightHideContainer.appendChild(card);
		}

		container.appendChild(highlightHideContainer);
	}

	if (blurGroups.length > 0) {
		const sectionHtml = await getBlurSectionHtml();
		const blurRoot = parseTemplateToElement(Tpl.render(sectionHtml));
		const blurSectionHeader = blurRoot.firstElementChild;
		const blurContainer = blurRoot.lastElementChild;

		for (let i = 0; i < blurGroups.length; i++) {
			const group = blurGroups[i];
			const card = await renderKeywordGroupCard({
				group,
				index: i,
				totalGroups: blurGroups.length,
				sectionType: "blur",
				deps,
			});
			if (preserveCollapsedState?.has(group.id)) card.classList.add("collapsed");
			blurContainer.appendChild(card);
		}

		container.appendChild(blurSectionHeader);
		container.appendChild(blurContainer);
	}
}
