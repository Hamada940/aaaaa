/**
 * Keyword row component. Renders one keyword table row from template and wires events.
 * @module KeywordRow
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";

const Tpl = new Template();
const TEMPLATE_URL = "/page/components/keywords/templates/keyword_row.tpl.html";

let cachedRowTemplateHtml = null;

async function getRowTemplateHtml() {
	if (cachedRowTemplateHtml) return cachedRowTemplateHtml;
	cachedRowTemplateHtml = await Tpl.loadFile(TEMPLATE_URL, true);
	return cachedRowTemplateHtml;
}

/**
 * Creates a keyword row element (async). Loads template, renders, wires events.
 * @param {Object} options
 * @param {string} options.groupId - Group ID
 * @param {number} options.keywordIndex - Row index
 * @param {Object} options.keyword - Keyword data { contains, without, etv_min, etv_max, note }
 * @param {Function} options.onNoteClick - (groupId, keywordIndex, keyword) => Promise<void>
 * @param {Function} options.onDeleteClick - (groupId, keywordIndex, tr) => Promise<void>
 * @param {Function} options.setupDragHandlers - (tr) => void
 * @returns {Promise<HTMLTableRowElement>}
 */
export async function createKeywordRow(options) {
	const { groupId, keywordIndex, keyword, onNoteClick, onDeleteClick, setupDragHandlers } = options;
	const kw = keyword || {};
	const noteButtonClass = kw.note && String(kw.note).trim() ? "keyword-row-note-button-has-note" : "";
	const noteButtonTitle = kw.note
		? getMessageOrDefault("kwNoteEditNote", "Edit note")
		: getMessageOrDefault("kwNoteAddNote", "Add note");

	Tpl.setVar("groupId", groupId);
	Tpl.setVar("keywordIndex", String(keywordIndex));
	Tpl.setVar("contains", kw.contains ?? "");
	Tpl.setVar("without", kw.without ?? "");
	Tpl.setVar("etv_min", kw.etv_min ?? "");
	Tpl.setVar("etv_max", kw.etv_max ?? "");
	Tpl.setVar("noteButtonClass", noteButtonClass);
	Tpl.setVar("noteButtonTitle", noteButtonTitle);

	const html = await getRowTemplateHtml();
	const rendered = Tpl.render(html);

	const wrap = document.createElement("tbody");
	wrap.innerHTML = rendered;
	const tr = wrap.querySelector("tr");
	if (!tr) throw new Error("Keyword row template did not produce tr");

	// Row starts non-draggable so Firefox allows caret positioning in inputs (see setupKeywordRowDragHandlers)
	tr.draggable = false;
	tr.dataset.dragAllowed = "false";
	if (kw.note) tr.dataset.keywordNote = kw.note;

	const noteBtn = tr.querySelector(".keyword-row-note-button");
	const deleteBtn = tr.querySelector(".vh-button-delete");
	if (noteBtn) {
		noteBtn.addEventListener("click", async (e) => {
			e.stopPropagation?.();
			await onNoteClick?.(groupId, keywordIndex, keyword);
		});
	}
	if (deleteBtn) {
		deleteBtn.addEventListener("click", async (e) => {
			e.stopPropagation?.();
			await onDeleteClick?.(groupId, keywordIndex, tr);
		});
	}
	setupDragHandlers?.(tr);
	return tr;
}
