/**
 * Keyword table component. Renders table from template, appends rows, wires add/save.
 * @module KeywordTable
 */

import { Template } from "/scripts/core/utils/Template.js";
import { createKeywordRow } from "./KeywordRow.js";

const Tpl = new Template();
const TEMPLATE_URL = "/page/components/keywords/templates/keyword_table.tpl.html";

let cachedTableTemplateHtml = null;

async function getTableTemplateHtml() {
	if (cachedTableTemplateHtml) return cachedTableTemplateHtml;
	cachedTableTemplateHtml = await Tpl.loadFile(TEMPLATE_URL, true);
	return cachedTableTemplateHtml;
}

/**
 * Renders the keywords table into contentWrapper and wires events.
 * @param {Object} options
 * @param {Object} options.group - Group { id, keywords }
 * @param {HTMLElement} options.container - Element to append the table into (e.g. contentWrapper)
 * @param {Function} options.onAddRow - (groupId, tableRef) => Promise<void> - called when Add Keyword is clicked; can append row to tbody
 * @param {Function} options.onBatchAdd - (groupId, tableRef) => Promise<void> - called when Batch Add Keywords is clicked
 * @param {Function} options.onSave - (groupId) => Promise<void>
 * @param {Function} options.onNoteClick - (groupId, keywordIndex, keyword) => Promise<void>
 * @param {Function} options.onDeleteRow - (groupId, keywordIndex, tr) => Promise<void>
 * @param {Function} options.setupDragHandlers - (tr) => void
 */
export async function renderKeywordTable(options) {
	const { group, container, onAddRow, onBatchAdd, onSave, onNoteClick, onDeleteRow, setupDragHandlers } = options;

	const html = await getTableTemplateHtml();
	const rendered = Tpl.render(html);

	const wrap = document.createElement("div");
	wrap.innerHTML = rendered;

	const wrapper = wrap.querySelector("#keywordTableWrapper");
	const table = wrap.querySelector("#keywordGroupTable");
	const tbody = wrap.querySelector("#keywordTableBody");
	const addBtn = wrap.querySelector("#keywordTableAddButton");
	const batchAddBtn = wrap.querySelector("#keywordTableBatchAddButton");
	const addBtnTop = wrap.querySelector("#keywordTableAddButtonTop");
	const addContainerTop = wrap.querySelector("#keywordTableAddContainerTop");
	const saveBtn = wrap.querySelector("#keywordTableSaveButton");

	if (!wrapper || !table || !tbody) throw new Error("Keyword table template did not produce expected elements");

	const updateTopAddButtonVisibility = () => {
		if (addContainerTop) {
			addContainerTop.style.display = tbody.children.length > 0 ? "" : "none";
		}
	};

	table.addEventListener("dragover", (e) => {
		if (window._keywordDragState && window._keywordDragState.isDragging) {
			e.preventDefault();
		}
	});

	const addKeywordRow = async (scrollNewRow) => {
		await onAddRow?.(group.id, table);
		updateTopAddButtonVisibility();
		if (scrollNewRow) {
			const lastRow = tbody.lastElementChild;
			lastRow?.scrollIntoView({ behavior: "smooth", block: "nearest" });
		}
	};

	const onDeleteRowWithVisibility = async (...args) => {
		await onDeleteRow?.(...args);
		updateTopAddButtonVisibility();
	};

	if (addBtnTop) {
		addBtnTop.addEventListener("click", () => addKeywordRow(true));
	}
	if (addBtn) {
		addBtn.addEventListener("click", () => addKeywordRow(false));
	}
	if (batchAddBtn) {
		batchAddBtn.addEventListener("click", async () => {
			await onBatchAdd?.(group.id, table);
			updateTopAddButtonVisibility();
		});
	}
	if (saveBtn) {
		saveBtn.addEventListener("click", async () => {
			await onSave?.(group.id);
		});
	}

	const keywords = group.keywords || [];
	for (let i = 0; i < keywords.length; i++) {
		const row = await createKeywordRow({
			groupId: group.id,
			keywordIndex: i,
			keyword: keywords[i],
			onNoteClick,
			onDeleteClick: onDeleteRowWithVisibility,
			setupDragHandlers,
		});
		tbody.appendChild(row);
	}

	updateTopAddButtonVisibility();
	container.appendChild(wrapper);
	return { table, tbody, updateTopAddButtonVisibility };
}
