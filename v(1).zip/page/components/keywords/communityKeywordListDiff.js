/**
 * Keyword list diff utilities for community lists.
 * Keywords are always sorted alphabetically for comparison and display.
 */

export function canonicalizeKeyword(keyword) {
	return JSON.stringify({
		contains: keyword.contains || "",
		without: keyword.without || "",
		etv_min: keyword.etv_min ?? "",
		etv_max: keyword.etv_max ?? "",
		note: keyword.note || "",
	});
}

export function formatKeywordLabel(keyword) {
	const parts = [];
	if (keyword.contains) parts.push(`contains: ${keyword.contains}`);
	if (keyword.without) parts.push(`without: ${keyword.without}`);
	if (keyword.etv_min) parts.push(`etv_min: ${keyword.etv_min}`);
	if (keyword.etv_max) parts.push(`etv_max: ${keyword.etv_max}`);
	if (keyword.note) parts.push(`note: ${keyword.note}`);
	return parts.join(" | ") || JSON.stringify(keyword);
}

export function sortKeywords(keywords) {
	return [...(keywords || [])].sort((a, b) => canonicalizeKeyword(a).localeCompare(canonicalizeKeyword(b)));
}

export function diffKeywordLists(oldKeywords, newKeywords) {
	const oldSorted = sortKeywords(oldKeywords);
	const newSorted = sortKeywords(newKeywords);
	const oldMap = new Map(oldSorted.map((kw) => [canonicalizeKeyword(kw), kw]));
	const newMap = new Map(newSorted.map((kw) => [canonicalizeKeyword(kw), kw]));

	const added = [];
	const removed = [];
	const unchanged = [];

	for (const [key, kw] of newMap) {
		if (oldMap.has(key)) unchanged.push(kw);
		else added.push(kw);
	}
	for (const [key, kw] of oldMap) {
		if (!newMap.has(key)) removed.push(kw);
	}

	return { added, removed, unchanged };
}

export function keywordsAreEqual(a, b) {
	const sortedA = sortKeywords(a).map(canonicalizeKeyword);
	const sortedB = sortKeywords(b).map(canonicalizeKeyword);
	if (sortedA.length !== sortedB.length) return false;
	return sortedA.every((value, index) => value === sortedB[index]);
}

/**
 * Renders a two-column diff into a container element.
 * @param {HTMLElement} container
 * @param {{ added: object[], removed: object[], unchanged: object[] }} diff
 * @param {{ leftTitle: string, rightTitle: string, addedLabel: string, removedLabel: string, unchangedLabel: string }} labels
 */
export function renderKeywordDiff(container, diff, labels) {
	container.innerHTML = "";
	container.classList.add("kw-community-diff");

	const leftCol = document.createElement("div");
	leftCol.className = "kw-community-diff-column";
	const rightCol = document.createElement("div");
	rightCol.className = "kw-community-diff-column";

	const makeSection = (title, items, className) => {
		const section = document.createElement("div");
		section.className = "kw-community-diff-section";
		const heading = document.createElement("h4");
		heading.textContent = title;
		section.appendChild(heading);
		const list = document.createElement("ul");
		list.className = "kw-community-diff-list";
		if (!items.length) {
			const empty = document.createElement("li");
			empty.className = "kw-community-diff-empty";
			empty.textContent = "—";
			list.appendChild(empty);
		} else {
			for (const kw of items) {
				const li = document.createElement("li");
				li.className = className;
				li.textContent = formatKeywordLabel(kw);
				list.appendChild(li);
			}
		}
		section.appendChild(list);
		return section;
	};

	leftCol.appendChild(document.createElement("h3")).textContent = labels.leftTitle;
	leftCol.lastChild.className = "kw-community-diff-heading";
	leftCol.appendChild(makeSection(labels.removedLabel, diff.removed, "kw-community-diff-removed"));
	leftCol.appendChild(makeSection(labels.unchangedLabel, diff.unchanged, "kw-community-diff-unchanged"));

	rightCol.appendChild(document.createElement("h3")).textContent = labels.rightTitle;
	rightCol.lastChild.className = "kw-community-diff-heading";
	rightCol.appendChild(makeSection(labels.addedLabel, diff.added, "kw-community-diff-added"));
	rightCol.appendChild(makeSection(labels.unchangedLabel, diff.unchanged, "kw-community-diff-unchanged"));

	container.appendChild(leftCol);
	container.appendChild(rightCol);
}
