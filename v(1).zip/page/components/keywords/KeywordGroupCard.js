/**
 * Keyword group card component. Renders one group card from template (shell) + options (if highlight) + table.
 * No createElement for card structure; template provides DOM, JS wires behavior.
 * @module KeywordGroupCard
 */

import { Template } from "/scripts/core/utils/Template.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import { normalizeCommunityLink } from "/scripts/core/utils/KeywordGroupsManager.js";
import { renderKeywordGroupOptions } from "./KeywordGroupOptions.js";
import { renderKeywordTable } from "./KeywordTable.js";
import { createKeywordRow } from "./KeywordRow.js";
import { showBatchKeywordsDialog } from "./BatchKeywordsDialog.js";

const Tpl = new Template();
const CARD_SHELL_URL = "/page/components/keywords/templates/keyword_group_card_shell.tpl.html";

let cachedCardShellHtml = null;

async function getCardShellHtml() {
	if (cachedCardShellHtml) return cachedCardShellHtml;
	cachedCardShellHtml = await Tpl.loadFile(CARD_SHELL_URL, true);
	return cachedCardShellHtml;
}

function parseTemplateToElement(html) {
	const wrap = document.createElement("div");
	wrap.innerHTML = html.trim();
	return wrap.firstElementChild;
}

/**
 * Creates the group card element and appends options + table. Async.
 * @param {Object} options
 * @param {Object} options.group - Group data
 * @param {number} options.index - Index in section
 * @param {number} options.totalGroups - Total in section
 * @param {string} options.sectionType - "highlight-hide" | "blur"
 * @param {Object} options.deps - Settings, updateGroup, deleteGroup, renderKeywordGroups, moveGroup, confirmPrompt, getGroupById, saveGroupKeywords, showKeywordNoteDialog, setupKeywordRowDragHandlers, isPremiumUser
 * @returns {Promise<HTMLElement>}
 */
export async function renderKeywordGroupCard(options) {
	const { group, index, totalGroups, sectionType, deps } = options;
	const {
		Settings,
		updateGroup,
		deleteGroup,
		renderKeywordGroups,
		moveGroup,
		confirmPrompt,
		getGroupById,
		saveGroupKeywords,
		showKeywordNoteDialog,
		setupKeywordRowDragHandlers,
		isPremiumUser,
	} = deps;

	Tpl.setVar("groupId", group.id);
	Tpl.setVar("disabledClass", group.enabled === false ? "keyword-group-disabled" : "");
	Tpl.setVar(
		"enabledTitle",
		group.enabled !== false
			? getMessageOrDefault("kwCardDisableGroup", "Disable group")
			: getMessageOrDefault("kwCardEnableGroup", "Enable group")
	);
	Tpl.setVar("enabledChecked", group.enabled !== false ? "checked" : "");
	Tpl.setVar(
		"upButtonClass",
		index === 0 ? "keyword-group-reorder-button-disabled" : "keyword-group-reorder-button-enabled"
	);
	Tpl.setVar(
		"downButtonClass",
		index === totalGroups - 1 ? "keyword-group-reorder-button-disabled" : "keyword-group-reorder-button-enabled"
	);
	Tpl.setVar(
		"groupName",
		group.name.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
	);
	Tpl.setVar(
		"typeSelectDisabledClass",
		group.type === "blur" && !isPremiumUser(2) ? "keyword-group-type-select-disabled" : ""
	);
	const communityLink = normalizeCommunityLink(group.communityLink);
	const hasCommunityLink = !!communityLink;
	const hasUpdate = hasCommunityLink && deps.hasCommunityListUpdate?.(communityLink.listId);
	Tpl.setVar("communityBadgeClass", hasCommunityLink ? "kw-community-link-badge--visible" : "");
	Tpl.setVar(
		"communityBadgeText",
		hasCommunityLink ? getMessageOrDefault("kwCommunityLinkedBadge", "Community") : ""
	);
	Tpl.setVar(
		"communityBadgeTitle",
		hasCommunityLink
			? getMessageOrDefault("kwCommunityLinkedTooltip", "Linked to community list: $NAME$", [communityLink.name])
			: ""
	);
	Tpl.setVar("communityActionsClass", "keyword-group-community-actions--visible");
	Tpl.setVar(
		"communityUploadTitle",
		hasCommunityLink
			? getMessageOrDefault("kwCommunityShareChanges", "Share changes")
			: getMessageOrDefault("kwCommunityUploadTooltip", "Upload as community list")
	);
	Tpl.setVar(
		"communityDownloadTitle",
		hasUpdate
			? getMessageOrDefault("kwCommunityDownloadUpdateAvailable", "Update available — download latest version")
			: getMessageOrDefault("kwCommunityDownloadTooltip", "Download latest version")
	);
	Tpl.setVar("communityDownloadPulseClass", hasUpdate ? "community-list-download--has-update" : "");

	const shellHtml = await getCardShellHtml();
	const groupDiv = parseTemplateToElement(Tpl.render(shellHtml));

	const enabledToggle = groupDiv.querySelector(".keyword-group-enabled-toggle");
	const reorderLegend = groupDiv.querySelector(".keyword-group-reorder-legend");
	const upButton = reorderLegend?.querySelector(".keyword-group-reorder-button:first-child");
	const downButton = reorderLegend?.querySelector(".keyword-group-reorder-button:last-child");
	const nameInput = groupDiv.querySelector(".keyword-group-name-input");
	const typeSelect = groupDiv.querySelector(".keyword-group-type-select");
	const deleteButton = groupDiv.querySelector(".keyword-group-header .vh-button-delete");
	const uploadButton = groupDiv.querySelector(".keyword-group-community-upload");
	const downloadButton = groupDiv.querySelector(".keyword-group-community-download");
	const header = groupDiv.querySelector(".keyword-group-header");
	const contentWrapper = groupDiv.querySelector(".fieldset-content");
	const dropZoneContainer = groupDiv.querySelector(".keyword-drop-zone-container");

	if (enabledToggle) {
		enabledToggle.addEventListener("change", async (e) => {
			e.stopPropagation();
			const preserveCollapsedState = new Set();
			const container = document.getElementById("keywordGroupsContainer");
			if (container) {
				container.querySelectorAll(".keyword-group.collapsed").forEach((el) => {
					if (el.dataset.groupId) preserveCollapsedState.add(el.dataset.groupId);
				});
			}
			await updateGroup(Settings, group.id, { enabled: enabledToggle.checked });
			await renderKeywordGroups(preserveCollapsedState);
			chrome.runtime.sendMessage({ action: "keywordsUpdated" });
		});
	}

	if (index > 0 && upButton) {
		upButton.addEventListener("click", async (e) => {
			e.stopPropagation();
			await moveGroup(group.id, -1);
		});
	}
	if (index < totalGroups - 1 && downButton) {
		downButton.addEventListener("click", async (e) => {
			e.stopPropagation();
			await moveGroup(group.id, 1);
		});
	}

	if (nameInput) {
		nameInput.addEventListener("blur", async () => {
			if (nameInput.value.trim() !== group.name) {
				await updateGroup(Settings, group.id, { name: nameInput.value.trim() });
				await renderKeywordGroups();
			}
		});
	}

	if (typeSelect) {
		typeSelect.value = group.type;
		typeSelect.disabled = !isPremiumUser(2) && group.type === "blur";
		typeSelect.addEventListener("change", async () => {
			if (typeSelect.value === "blur" && !isPremiumUser(2)) {
				alert("Blur groups are reserved for Premium Tier 2 members.");
				typeSelect.value = group.type;
				return;
			}
			const newType = typeSelect.value;
			const updates = { type: newType };
			if (newType !== "highlight") {
				const msg = getMessageOrDefault(
					"kwCardConfirmTypeChangeResetSettings",
					"Changing the group type will preserve keywords, but reset the group settings (color, sound, etc). Are you sure you want to continue?"
				);
				if (!(await confirmPrompt(msg))) {
					typeSelect.value = group.type;
					return;
				}
				if (group.listingColor !== null) updates.listingColor = null;
				if (group.monitorColor !== null) updates.monitorColor = null;
				if (group.monitorSound !== null) updates.monitorSound = null;
				if (group.monitorVolume !== undefined) updates.monitorVolume = undefined;
			}
			await updateGroup(Settings, group.id, updates);
			await renderKeywordGroups();
		});
	}

	if (deleteButton) {
		deleteButton.addEventListener("click", async (e) => {
			e.stopPropagation();
			if (await confirmPrompt(`Delete group "${group.name}" and all its keywords?`)) {
				if (deps.handleCommunityGroupDelete) {
					await deps.handleCommunityGroupDelete(group);
				}
				await deleteGroup(Settings, group.id);
				await renderKeywordGroups();
				chrome.runtime.sendMessage({ action: "keywordsUpdated" });
			}
		});
	}

	if (uploadButton && deps.handleCommunityUploadClick) {
		uploadButton.addEventListener("click", async (e) => {
			e.stopPropagation();
			await deps.handleCommunityUploadClick(group);
		});
		if (hasCommunityLink) {
			uploadButton.classList.add("keyword-group-community-upload--linked");
		} else {
			downloadButton?.classList.add("keyword-group-community-download--hidden");
		}
	}

	if (downloadButton && deps.handleCommunityDownloadClick && hasCommunityLink) {
		if (hasUpdate) {
			downloadButton.classList.add("community-list-download--has-update");
		}
		downloadButton.addEventListener("click", async (e) => {
			e.stopPropagation();
			await deps.handleCommunityDownloadClick(group);
		});
	} else if (downloadButton) {
		downloadButton.classList.add("keyword-group-community-download--hidden");
	}

	if (header) {
		header.addEventListener("click", async (e) => {
			if (e.target.closest("input, button, select, .vh-button-icon-compact, .vh-icon-only-button") === null) {
				groupDiv.classList.toggle("collapsed");
				await updateGroup(Settings, group.id, { collapsed: groupDiv.classList.contains("collapsed") });
			}
		});
	}

	if (group.type === "highlight") {
		await renderKeywordGroupOptions({
			group,
			container: contentWrapper,
			getSetting: (key) => Settings.get(key),
			updateGroup: (groupId, updates) => updateGroup(Settings, groupId, updates),
		});
	}

	const keywordDedupKey = (contains, without = "") =>
		JSON.stringify({ contains: contains || "", without: without || "" });

	const collectExistingKeywordKeys = (tbody) => {
		const keys = new Set();
		for (const row of tbody?.querySelectorAll("tr") || []) {
			const contains = row.querySelector('input[name="contains"]')?.value?.trim() || "";
			const without = row.querySelector('input[name="without"]')?.value?.trim() || "";
			if (contains || without) {
				keys.add(keywordDedupKey(contains, without));
			}
		}
		return keys;
	};

	const { updateTopAddButtonVisibility } = await renderKeywordTable({
		group,
		container: contentWrapper,
		onAddRow: async (groupId, tableRef) => {
			const tbody = tableRef?.querySelector("tbody");
			if (!tbody) return;
			const g = await getGroupById(Settings, groupId);
			const savedCount = g?.keywords?.length ?? 0;
			const newKeyword = { contains: "", without: "", etv_min: "", etv_max: "" };
			const row = await createKeywordRow({
				groupId,
				keywordIndex: savedCount + 10000,
				keyword: newKeyword,
				onNoteClick: showKeywordNoteDialog,
				onDeleteClick: async (gid, idx, tr) => {
					if (idx >= 10000) {
						tr.remove();
						updateTopAddButtonVisibility?.();
					}
				},
				setupDragHandlers: setupKeywordRowDragHandlers,
			});
			tbody.appendChild(row);
		},
		onBatchAdd: async (groupId, tableRef) => {
			const lines = await showBatchKeywordsDialog();
			if (!lines?.length) return;

			const tbody = tableRef?.querySelector("tbody");
			if (!tbody) return;

			const g = await getGroupById(Settings, groupId);
			const existingKeys = collectExistingKeywordKeys(tbody);
			let nextIndex = (g?.keywords?.length ?? 0) + 10000;
			let added = 0;

			for (const line of lines) {
				const key = keywordDedupKey(line);
				if (existingKeys.has(key)) continue;

				try {
					new RegExp(line);
				} catch (e) {
					alert("Invalid regex syntax in 'Contains' field: " + line);
					continue;
				}

				existingKeys.add(key);
				const newKeyword = { contains: line, without: "", etv_min: "", etv_max: "" };
				const row = await createKeywordRow({
					groupId,
					keywordIndex: nextIndex,
					keyword: newKeyword,
					onNoteClick: showKeywordNoteDialog,
					onDeleteClick: async (gid, idx, tr) => {
						if (idx >= 10000) {
							tr.remove();
							updateTopAddButtonVisibility?.();
						}
					},
					setupDragHandlers: setupKeywordRowDragHandlers,
				});
				tbody.appendChild(row);
				nextIndex++;
				added++;
			}

			if (added > 0) {
				await saveGroupKeywords(groupId);
				chrome.runtime.sendMessage({ action: "keywordsUpdated" });
			}
		},
		onSave: saveGroupKeywords,
		onNoteClick: showKeywordNoteDialog,
		onDeleteRow: async (groupId, keywordIndex, tr) => {
			if (await confirmPrompt("Delete keyword?")) {
				const g = await getGroupById(Settings, groupId);
				const savedCount = g?.keywords?.length ?? 0;
				if (keywordIndex >= 10000) tr.remove();
				else if (keywordIndex < savedCount) {
					await deps.deleteKeywordFromGroup(Settings, groupId, keywordIndex);
					await renderKeywordGroups();
				} else tr.remove();
			}
		},
		setupDragHandlers: setupKeywordRowDragHandlers,
	});

	return groupDiv;
}
