/**
 * @fileoverview DialogUtils - Utility functions for creating dialogs and prompts
 */

import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";

/**
 * Displays a multi-line popup dialog
 * @param {string} content - Initial content
 * @param {string} placeholder - Placeholder text
 * @param {string|null} callbackLabel - Label for the callback button
 * @param {Function|null} callback - Callback function
 */
export function displayMultiLinePopup(content, placeholder = "", callbackLabel = null, callback = null, options = {}) {
	//Create a popup with a textarea for multi-line input
	const popup = document.createElement("div");
	popup.className = "vh-multiline-popup";
	popup.style.position = "fixed";
	popup.style.top = "50%";
	popup.style.left = "50%";
	popup.style.transform = "translate(-50%, -50%)";
	popup.style.width = "90%";
	popup.style.height = "200px";
	popup.style.padding = "20px";
	popup.style.paddingTop = "40px";
	popup.style.paddingBottom = "40px";
	popup.style.zIndex = "1000";

	// Create textarea
	const textarea = document.createElement("textarea");
	textarea.id = "textInput";
	textarea.classList.add("vh-code-editor");
	textarea.style.width = "100%";
	textarea.style.height = "100%";
	textarea.style.marginLeft = "0";
	textarea.placeholder = placeholder;
	textarea.textContent = content;
	popup.appendChild(textarea);

	// Create close button
	const closeButton = document.createElement("button");
	closeButton.id = "closePopup";
	closeButton.style.padding = "2px 10px";
	closeButton.style.position = "absolute";
	closeButton.style.top = "5px";
	closeButton.style.right = "5px";
	closeButton.textContent = "X";
	popup.appendChild(closeButton);

	// Only add Copy button when a tooltip/intent for copy is provided (i.e. Export)
	if (options && options.copyTooltip) {
		const copyButton = document.createElement("button");
		copyButton.id = "copyPopup";
		copyButton.textContent = getMessageOrDefault("dialogCopy", "Copy");

		const tooltipText = options.copyTooltip;
		copyButton.title = tooltipText;
		copyButton.setAttribute("aria-label", tooltipText);

		popup.appendChild(copyButton);

		// Copy handler: copy selected text or whole content if none selected
		copyButton.addEventListener("click", async () => {
			const input = document.getElementById("textInput");
			if (!input) return;
			const selection = input.value.substring(input.selectionStart, input.selectionEnd);
			const textToCopy = selection.length ? selection : input.value;
			try {
				await navigator.clipboard.writeText(textToCopy);
				const orig = copyButton.textContent;
				copyButton.textContent = getMessageOrDefault("dialogCopied", "Copied!");
				setTimeout(() => (copyButton.textContent = orig), 1500);
			} catch (err) {
				// Fallback for older browsers
				input.select();
				if (document.execCommand("copy")) {
					const orig = copyButton.textContent;
					copyButton.textContent = getMessageOrDefault("dialogCopied", "Copied!");
					setTimeout(() => (copyButton.textContent = orig), 1500);
				} else {
					alert("Copy failed. The text has been selected for you to copy manually.");
				}
			}
		});
	}

	// Create callback button if needed
	if (callbackLabel != null) {
		const callbackButton = document.createElement("button");
		callbackButton.id = "import";
		callbackButton.style.padding = "2px 10px";
		callbackButton.style.position = "absolute";
		callbackButton.style.bottom = "10px";
		callbackButton.style.right = "10px";
		callbackButton.textContent = callbackLabel;
		popup.appendChild(callbackButton);
	}

	document.body.appendChild(popup);

	document.getElementById("closePopup").addEventListener("click", () => {
		popup.remove();
	});

	if (callbackLabel != null) {
		document.getElementById("import").addEventListener("click", () => {
			if (callback != null) {
				const ret = callback(document.getElementById("textInput").value);
				if (ret) {
					popup.remove();
				}
			} else {
				popup.remove();
			}
		});
	}
}

/**
 * Shows read-only JSON (or text) and asks the user to confirm an action.
 * @param {string} message - Introductory HTML message
 * @param {string} dataText - Payload preview (usually formatted JSON)
 * @param {string} [confirmLabel] - Label for the confirm button
 * @returns {Promise<boolean>} True if confirmed, false if cancelled
 */
export function confirmDataPreview(message, dataText, confirmLabel = null) {
	return new Promise((resolve) => {
		const overlay = document.createElement("div");
		overlay.className = "vh-prompt-overlay";
		overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9998;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

		const confirmBox = document.createElement("div");
		confirmBox.className = "vh-prompt-box";
		confirmBox.style.cssText = `
            padding: 20px;
            border-radius: 5px;
            z-index: 9999;
            width: min(92vw, 720px);
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            gap: 12px;
        `;

		const messageDiv = document.createElement("div");
		messageDiv.className = "vh-prompt-message";
		messageDiv.innerHTML = message;
		confirmBox.appendChild(messageDiv);

		const textarea = document.createElement("textarea");
		textarea.className = "vh-code-editor";
		textarea.readOnly = true;
		textarea.value = dataText;
		textarea.style.cssText = `
            width: 100%;
            min-height: 280px;
            max-height: 50vh;
            resize: vertical;
            font-family: monospace;
            font-size: 12px;
        `;
		confirmBox.appendChild(textarea);

		const buttonContainer = document.createElement("div");
		buttonContainer.className = "vh-prompt-buttons";
		buttonContainer.style.cssText = `
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        `;

		const okButton = document.createElement("button");
		okButton.className = "vh-prompt-btn vh-prompt-btn-ok";
		okButton.textContent = confirmLabel ?? getMessageOrDefault("pageSettingsServerTelemetryConfirm", "Send to VH");
		okButton.style.cssText = `
            padding: 5px 15px;
            cursor: pointer;
            border: none;
            border-radius: 3px;
        `;

		const cancelButton = document.createElement("button");
		cancelButton.className = "vh-prompt-btn vh-prompt-btn-cancel";
		cancelButton.textContent = getMessageOrDefault("dialogCancel", "Cancel");
		cancelButton.style.cssText = `
            padding: 5px 15px;
            cursor: pointer;
            border: none;
            border-radius: 3px;
        `;

		buttonContainer.appendChild(cancelButton);
		buttonContainer.appendChild(okButton);
		confirmBox.appendChild(buttonContainer);
		overlay.appendChild(confirmBox);
		document.body.appendChild(overlay);

		const cleanup = () => {
			document.body.removeChild(overlay);
			document.removeEventListener("keydown", handleKeyPress);
		};

		const handleConfirm = () => {
			cleanup();
			resolve(true);
		};

		const handleCancel = () => {
			cleanup();
			resolve(false);
		};

		okButton.addEventListener("click", handleConfirm);
		cancelButton.addEventListener("click", handleCancel);

		const handleKeyPress = (e) => {
			if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
				handleConfirm();
			} else if (e.key === "Escape") {
				handleCancel();
			}
		};

		document.addEventListener("keydown", handleKeyPress);
		cancelButton.focus();
	});
}

/**
 * Creates a confirmation prompt dialog
 * @param {string} message - The message to display
 * @returns {Promise<boolean>} True if confirmed, false if cancelled
 */
export function confirmPrompt(message) {
	return new Promise((resolve) => {
		// Create overlay
		const overlay = document.createElement("div");
		overlay.className = "vh-prompt-overlay";
		overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9998;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

		// Create confirm box
		const confirmBox = document.createElement("div");
		confirmBox.className = "vh-prompt-box";
		confirmBox.style.cssText = `
            padding: 20px;
            border-radius: 5px;
            z-index: 9999;
            min-width: 300px;
        `;

		// Add message
		const messageDiv = document.createElement("div");
		messageDiv.className = "vh-prompt-message";
		messageDiv.innerHTML = message;
		messageDiv.style.marginBottom = "20px";
		confirmBox.appendChild(messageDiv);

		// Add buttons container
		const buttonContainer = document.createElement("div");
		buttonContainer.className = "vh-prompt-buttons";
		buttonContainer.style.cssText = `
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        `;

		// Create buttons
		const okButton = document.createElement("button");
		okButton.className = "vh-prompt-btn vh-prompt-btn-ok";
		okButton.textContent = getMessageOrDefault("dialogOk", "OK");
		okButton.style.cssText = `
            padding: 5px 15px;
            cursor: pointer;
            border: none;
            border-radius: 3px;
        `;

		const cancelButton = document.createElement("button");
		cancelButton.className = "vh-prompt-btn vh-prompt-btn-cancel";
		cancelButton.textContent = getMessageOrDefault("dialogCancel", "Cancel");
		cancelButton.style.cssText = `
            padding: 5px 15px;
            cursor: pointer;
            border: none;
            border-radius: 3px;
        `;

		// Add buttons to container
		buttonContainer.appendChild(cancelButton);
		buttonContainer.appendChild(okButton);
		confirmBox.appendChild(buttonContainer);

		// Add confirm box to overlay
		overlay.appendChild(confirmBox);

		// Add overlay to body
		document.body.appendChild(overlay);

		// Handle button clicks
		const cleanup = () => {
			document.body.removeChild(overlay);
			document.removeEventListener("keydown", handleKeyPress);
		};

		const handleConfirm = () => {
			cleanup();
			resolve(true);
		};

		const handleCancel = () => {
			cleanup();
			resolve(false);
		};

		// Add click handlers
		okButton.addEventListener("click", handleConfirm);
		cancelButton.addEventListener("click", handleCancel);

		// Handle keyboard events
		const handleKeyPress = (e) => {
			if (e.key === "Enter") {
				handleConfirm();
			} else if (e.key === "Escape") {
				handleCancel();
			}
		};

		document.addEventListener("keydown", handleKeyPress);

		// Focus OK button
		okButton.focus();
	});
}

/**
 * Creates a keyword type selection prompt
 * @param {string} message - The message to display
 * @returns {Promise<string|null>} The selected keyword type or null if cancelled
 */
export function selectKeywordTypePrompt(message) {
	return new Promise((resolve) => {
		// Create overlay
		const overlay = document.createElement("div");
		overlay.className = "vh-prompt-overlay";
		overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9998;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

		// Create prompt box
		const promptBox = document.createElement("div");
		promptBox.className = "vh-prompt-box";
		promptBox.style.cssText = `
            padding: 20px;
            border-radius: 5px;
            z-index: 9999;
            min-width: 300px;
        `;

		// Add message
		const messageDiv = document.createElement("div");
		messageDiv.className = "vh-prompt-message";
		messageDiv.innerHTML = message;
		messageDiv.style.marginBottom = "20px";
		promptBox.appendChild(messageDiv);

		// Add buttons container
		const buttonContainer = document.createElement("div");
		buttonContainer.className = "vh-prompt-buttons";
		buttonContainer.style.cssText = `
            display: flex;
            justify-content: space-around;
            gap: 10px;
            flex-wrap: wrap;
        `;

		// Create buttons for each keyword type
		const types = [
			{ value: "highlight", label: getMessageOrDefault("kwAddGroupTypeHighlight", "Highlight") },
			{ value: "hide", label: getMessageOrDefault("kwAddGroupTypeHide", "Hide") },
			{ value: "blur", label: getMessageOrDefault("kwAddGroupTypeBlur", "Blur") },
		];

		const cancelButton = document.createElement("button");
		cancelButton.className = "vh-prompt-btn vh-prompt-btn-cancel";
		cancelButton.textContent = getMessageOrDefault("dialogCancel", "Cancel");
		cancelButton.style.cssText = `
            padding: 8px 15px;
            cursor: pointer;
            border: none;
            border-radius: 3px;
            flex: 1;
            min-width: 80px;
        `;

		types.forEach((type) => {
			const button = document.createElement("button");
			button.className = "vh-prompt-btn vh-prompt-btn-ok";
			button.textContent = type.label;
			button.style.cssText = `
                padding: 8px 15px;
                cursor: pointer;
                border: none;
                border-radius: 3px;
                flex: 1;
                min-width: 80px;
            `;
			button.addEventListener("click", () => {
				document.body.removeChild(overlay);
				resolve(type.value);
			});
			buttonContainer.appendChild(button);
		});

		buttonContainer.appendChild(cancelButton);
		promptBox.appendChild(buttonContainer);

		// Add prompt box to overlay
		overlay.appendChild(promptBox);

		// Add overlay to body
		document.body.appendChild(overlay);

		// Handle cancel
		const handleCancel = () => {
			document.body.removeChild(overlay);
			resolve(null);
		};

		cancelButton.addEventListener("click", handleCancel);

		// Handle keyboard events
		const handleKeyPress = (e) => {
			if (e.key === "Escape") {
				handleCancel();
			}
		};

		document.addEventListener("keydown", handleKeyPress);

		// Cleanup on close
		const cleanup = () => {
			document.removeEventListener("keydown", handleKeyPress);
		};

		overlay.addEventListener("click", (e) => {
			if (e.target === overlay) {
				handleCancel();
			}
		});
	});
}
