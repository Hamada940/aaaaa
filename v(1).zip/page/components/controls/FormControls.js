/**
 * @fileoverview FormControls - Manages all form control types in settings
 *
 * This module provides functions for managing different types of form controls:
 * - Checkboxes
 * - Text inputs
 * - Textareas
 * - Select boxes
 * - Color pickers
 * - Sliders
 * - Radio buttons
 * - Time inputs
 * - Voice selection
 * - Play buttons
 */

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
import {
	CUSTOM_SOUND_PREFIX,
	UPLOAD_OPTION_VALUE,
	LOCAL_STORAGE_QUOTA_BYTES,
	analyzeSoundFile,
	importAnalyzedSound,
	listCustomSounds,
	loadLibrary,
	bytesToSize,
	customSoundValue,
	findCustomSoundReferences,
	deleteCustomSoundById,
	NOTIFICATION_SOUND_SETTING_KEYS,
} from "/scripts/core/services/CustomSoundLibrary.js";
import { playNotificationSound } from "/scripts/core/utils/SoundResolver.js";
import { confirmPrompt } from "../dialogs/DialogUtils.js";
const Settings = new SettingsMgr();

/**
 * Manages a checkbox setting
 * @param {string} key - The settings key
 * @param {boolean|null} def - Default value if setting doesn't exist
 */
export function manageCheckboxSetting(key, def = null) {
	let val = Settings.get(key);

	// If the setting doesn't exist and we have a default, use it and save it
	if (val === undefined && def !== null) {
		val = def;
		Settings.set(key, val); // Save the default value
	}

	if (val === undefined || val === null) {
		console.log("Setting " + key + " does not exist and no default provided");
		return;
	}

	const keyE = CSS.escape(key);
	const checkObj = document.querySelector(`input[name='${keyE}']`);
	if (checkObj == null) {
		console.log("Checkbox input name='" + key + "' does not exist");
		return;
	}

	// Use explicit default when provided, otherwise fall back to the
	// default value from SettingsMgrDI factory defaults.
	const defaultVal = def !== null ? def : Settings.getDefault(key);
	if (val !== defaultVal) {
		checkObj.classList.add("vh-chk-changed");
	} else {
		checkObj.classList.remove("vh-chk-changed");
	}

	checkObj.checked = val === true;

	//Saving the change
	// Store event listener reference to prevent duplicates
	if (!checkObj._VHelperChangeHandler) {
		checkObj._VHelperChangeHandler = function (event) {
			const newVal = event.target.checked;

			if (newVal !== defaultVal) {
				checkObj.classList.add("vh-chk-changed");
			} else {
				checkObj.classList.remove("vh-chk-changed");
			}

			// Skip save when value is unchanged (avoids loop when refreshSettings redraws the form)
			if (Settings.get(key, false) == newVal) {
				return;
			}
			// versionInfoPopup stores the last seen app version (string); when unchecked, do not overwrite it with false
			if (key === "general.versionInfoPopup" && newVal === false) {
				return;
			}
			console.log("[Settings] Checkbox changed for key: " + key + " to " + newVal);
			Settings.set(key, newVal);
		};
		checkObj.addEventListener("change", checkObj._VHelperChangeHandler);
	}

	//Clicking the label will check the checkbox (skip if input has matching id – native label association handles it)
	const obj = document.querySelector(`label[for='${keyE}']`);
	if (!obj) {
		console.error("Label for '" + keyE + "' does not exist");
		return;
	}
	obj.onclick = async function (event) {
		if (event.target.nodeName == "INPUT") {
			return false;
		}

		//Change the value
		const element = document.querySelector(`input[name='${keyE}']`);
		element.click();
	}.bind(keyE);
}

/**
 * Manages a text input setting
 * @param {string} key - The settings key
 */
export function manageInputText(key) {
	const val = Settings.get(key);
	const obj = document.querySelector(`label[for='${key}'] input`);
	if (obj == null) {
		throw new Error("Item input name='" + key + "' does not exist");
	}
	obj.value = val == null ? "" : val;

	// Store event listener reference to prevent duplicates
	if (!obj._VHelperChangeHandler) {
		obj._VHelperChangeHandler = async function () {
			Settings.set(key, obj.value);
		};
		obj.addEventListener("change", obj._VHelperChangeHandler);
	}
}

/**
 * Manages a textarea setting
 * @param {string} key - The settings key
 */
export function manageTextarea(key) {
	const val = Settings.get(key);
	const obj = document.querySelector(`textarea[name='${key}']`);
	if (obj == null) {
		throw new Error("Textarea name='" + key + "' does not exist");
	}
	obj.value = val;
	// Store event listener reference to prevent duplicates
	if (!obj._VHelperChangeHandler) {
		obj._VHelperChangeHandler = async function () {
			Settings.set(key, obj.value);
		};
		obj.addEventListener("change", obj._VHelperChangeHandler);
	}
}

/**
 * Manages a radio button group setting
 * @param {string} key - The settings key
 */
export function manageRadio(key) {
	const keyE = CSS.escape(key);

	document.querySelectorAll(`input[name="${keyE}"]`).forEach((elem) => {
		if (elem.value == Settings.get(key)) {
			elem.checked = true;
		}

		// Only add listener once to avoid duplicate handlers when initiateSettings
		if (!elem._VHelperRadioHandler) {
			elem._VHelperRadioHandler = function () {
				const newVal = elem.value;
				// Skip save when value unchanged (avoids loop when refreshSettings redraws the form)
				if (Settings.get(key, false) == newVal) {
					return;
				}
				console.log("Radio Setting " + key + " to " + newVal);
				Settings.set(key, newVal);
			};
			elem.addEventListener("click", elem._VHelperRadioHandler);
		}
	});
}

/**
 * Manages a time input setting
 * @param {string} key - The settings key
 */
export function manageTimeSetting(key, defaultValue = "00:00") {
	const val = Settings.get(key);
	const obj = document.querySelector(`input[name='${key}']`);
	if (obj == null) {
		throw new Error("Time input name='" + key + "' does not exist");
	}
	obj.value = val == null ? defaultValue : val;

	// Store event listener reference to prevent duplicates
	if (!obj._VHelperChangeHandler) {
		obj._VHelperChangeHandler = async function () {
			Settings.set(key, obj.value);
		};
		obj.addEventListener("change", obj._VHelperChangeHandler);
	}
}

/**
 * Manages a color picker setting
 * @param {string} key - The settings key
 */
export function manageColorPicker(key) {
	const val = Settings.get(key);
	const keyE = CSS.escape(key);
	const obj = document.querySelector(`input[name='${keyE}']`);
	if (obj == null) {
		throw new Error("Color picker input name='" + key + "' does not exist");
	}
	obj.value = val == null ? "" : val;

	// Store event listener reference to prevent duplicates
	if (!obj._VHelperChangeHandler) {
		obj._VHelperChangeHandler = async function () {
			Settings.set(key, obj.value);
		};
		obj.addEventListener("change", obj._VHelperChangeHandler);
	}
}

/**
 * Snap a tax-rate modifier to the nearest whole percent (slider resolution).
 * @param {unknown} value
 * @returns {number}
 */
function snapEtvModifierPercent(value) {
	const n = Number(value);
	if (!Number.isFinite(n)) return 0;
	return Math.round(n * 100) / 100;
}

/**
 * Manages a slider setting
 * @param {string} key - The settings key
 */
export function manageSlider(key) {
	const val = Settings.get(key);
	const volumeObj = document.querySelector(`label[for='${key}'] input`);
	if (volumeObj == null) {
		throw new Error("Slider input name='" + key + "' does not exist");
	}

	const isEtvModifier = key.includes("ETV.modifier");
	let sliderValue = Number(val == null ? 0 : val);
	if (isEtvModifier) {
		// 1% steps so the stored value matches the displayed percent label.
		volumeObj.setAttribute("step", "0.01");
		sliderValue = snapEtvModifierPercent(sliderValue);
		if (sliderValue !== Number(val)) {
			Settings.set(key, sliderValue);
		}
	}

	volumeObj.value = sliderValue;
	const keyE = CSS.escape(key);
	const textDisplayObj = document.querySelector(`span#${keyE}Value`);
	if (textDisplayObj) {
		textDisplayObj.textContent = (volumeObj.value * 100).toFixed(0) + "%";
	}
	const textDisplayObj2 = document.querySelector(`span#${keyE}Multiplicator`);
	if (textDisplayObj2) {
		textDisplayObj2.textContent = (Number(volumeObj.value) * 1).toFixed(1) + "x";
	}

	// Store event listener reference to prevent duplicates
	if (!volumeObj._VHelperChangeHandler) {
		volumeObj._VHelperChangeHandler = async function () {
			let next = Number(volumeObj.value);
			if (isEtvModifier) {
				next = snapEtvModifierPercent(next);
				volumeObj.value = next;
			}
			Settings.set(key, next);
			const keyE = CSS.escape(key);
			const textDisplayObj = document.querySelector(`span#${keyE}Value`);
			if (textDisplayObj) {
				textDisplayObj.textContent = (volumeObj.value * 100).toFixed(0) + "%";
			}
			const textDisplayObj2 = document.querySelector(`span#${keyE}Multiplicator`);
			if (textDisplayObj2) {
				textDisplayObj2.textContent = (Number(volumeObj.value) * 1).toFixed(1) + "x";
			}
		};
		// Use "input" event for real-time updates while dragging
		volumeObj.addEventListener("input", volumeObj._VHelperChangeHandler);
	}
}

/**
 * Manages a select box setting
 * @param {string} key - The settings key
 */
export function manageSelectBox(key) {
	const val = Settings.get(key);
	const keyE = CSS.escape(key);
	const selectObj = document.querySelector(`label[for='${keyE}'] select`);

	for (let i = 0; i < selectObj.options.length; i++) {
		if (selectObj.options[i].value == val) {
			selectObj.options[i].selected = true;
		}
	}

	// Store event listener reference to prevent duplicates
	if (!selectObj._VHelperChangeHandler) {
		selectObj._VHelperChangeHandler = async function () {
			Settings.set(key, selectObj.value);
		};
		selectObj.addEventListener("change", selectObj._VHelperChangeHandler);
	}
}

let sharedSoundFileInput = null;

function getSharedSoundFileInput() {
	if (!sharedSoundFileInput) {
		sharedSoundFileInput = document.createElement("input");
		sharedSoundFileInput.type = "file";
		sharedSoundFileInput.accept = "audio/*";
		sharedSoundFileInput.style.display = "none";
		document.body.appendChild(sharedSoundFileInput);
	}
	return sharedSoundFileInput;
}

function promptForSoundFile() {
	return new Promise((resolve) => {
		const input = getSharedSoundFileInput();
		const onChange = () => {
			input.removeEventListener("change", onChange);
			const file = input.files?.[0] || null;
			input.value = "";
			resolve(file);
		};
		input.addEventListener("change", onChange);
		input.click();
	});
}

function removeCustomSoundOptions(selectObj) {
	selectObj.querySelectorAll("[data-vh-custom-sound]").forEach((node) => node.remove());
}

function addMissingCustomSoundOption(selectObj, value) {
	const opt = document.createElement("option");
	opt.value = value;
	opt.textContent = getMessageOrDefault("formSoundMissing", "(missing custom sound)");
	opt.dataset.vhCustomSound = "orphan";
	selectObj.appendChild(opt);
}

/**
 * Adds custom sound entries and an upload option to a sound select element.
 * @param {HTMLSelectElement} selectObj
 * @param {string} currentValue
 */
export async function populateSoundSelectOptions(selectObj, currentValue) {
	removeCustomSoundOptions(selectObj);

	const library = await loadLibrary();
	const optgroup = document.createElement("optgroup");
	optgroup.label = getMessageOrDefault("formSoundCustomGroup", "Custom sounds");
	optgroup.dataset.vhCustomSound = "group";

	for (const entry of listCustomSounds(library)) {
		const option = document.createElement("option");
		option.value = CUSTOM_SOUND_PREFIX + entry.id;
		option.textContent = entry.name;
		option.dataset.vhCustomSound = "entry";
		optgroup.appendChild(option);
	}

	const uploadOption = document.createElement("option");
	uploadOption.value = UPLOAD_OPTION_VALUE;
	uploadOption.textContent = getMessageOrDefault("formSoundUploadCustom", "Upload custom sound...");
	uploadOption.dataset.vhCustomSound = "upload";
	optgroup.appendChild(uploadOption);

	selectObj.appendChild(optgroup);

	if (currentValue && currentValue.startsWith(CUSTOM_SOUND_PREFIX)) {
		const hasOption = Array.from(selectObj.options).some((opt) => opt.value === currentValue);
		if (!hasOption) {
			addMissingCustomSoundOption(selectObj, currentValue);
		}
	}
}

async function refreshAllSoundSelectOptions() {
	const groups = document.querySelectorAll('optgroup[data-vh-custom-sound="group"]');
	for (const group of groups) {
		const selectObj = group.parentElement;
		if (!(selectObj instanceof HTMLSelectElement)) {
			continue;
		}
		const currentValue = selectObj.value;
		await populateSoundSelectOptions(selectObj, currentValue);
		selectObj.value = currentValue;
	}
}

async function syncSoundSelectsAfterDelete(deletedValue) {
	const groups = document.querySelectorAll('optgroup[data-vh-custom-sound="group"]');
	for (const group of groups) {
		const selectObj = group.parentElement;
		if (!(selectObj instanceof HTMLSelectElement)) {
			continue;
		}
		if (selectObj.value === deletedValue) {
			selectObj.value = "0";
		}
		await populateSoundSelectOptions(selectObj, selectObj.value);
	}
}

async function clearCustomSoundReferences(soundValue) {
	for (const key of NOTIFICATION_SOUND_SETTING_KEYS) {
		if (Settings.get(key) === soundValue) {
			await Settings.set(key, "0");
		}
	}

	const groups = Settings.get("general.keywordGroups");
	if (!Array.isArray(groups)) {
		return;
	}

	let changed = false;
	const updatedGroups = groups.map((group) => {
		if (group.monitorSound === soundValue) {
			changed = true;
			return { ...group, monitorSound: null };
		}
		return group;
	});

	if (changed) {
		await Settings.set("general.keywordGroups", updatedGroups);
	}
}

function formatDeleteConfirmMessage(entry, referenceCount) {
	const fileLabel = `${entry.name} (${bytesToSize(entry.sizeBytes)})`;
	if (referenceCount > 0) {
		const template = getMessageOrDefault(
			"formSoundDeleteConfirmInUse",
			'Delete "$1$"?\n\nIt is currently assigned to $2$ place(s). They will be reset to None.'
		);
		return template.replace("$1$", fileLabel).replace("$2$", String(referenceCount));
	}
	const template = getMessageOrDefault("formSoundDeleteConfirm", 'Delete "$1$"?');
	return template.replace("$1$", fileLabel);
}

async function deleteCustomSoundEntry(entry) {
	const soundValue = customSoundValue(entry.id);
	const references = findCustomSoundReferences(soundValue, Settings.getSettingsTree());
	const confirmed = await confirmPrompt(formatDeleteConfirmMessage(entry, references.length));
	if (!confirmed) {
		return false;
	}

	await clearCustomSoundReferences(soundValue);
	const deleted = await deleteCustomSoundById(entry.id);
	if (!deleted) {
		return false;
	}

	await syncSoundSelectsAfterDelete(soundValue);
	return true;
}

function createPromptOverlay() {
	const overlay = document.createElement("div");
	overlay.className = "vh-prompt-overlay";
	overlay.style.cssText =
		"position:fixed;top:0;left:0;width:100%;height:100%;z-index:9998;display:flex;align-items:center;justify-content:center;";
	return overlay;
}

function createPromptBox() {
	const box = document.createElement("div");
	box.className = "vh-prompt-box";
	box.style.cssText =
		"padding:20px;border-radius:5px;z-index:9999;min-width:320px;max-width:560px;max-height:80vh;overflow:auto;";
	return box;
}

/**
 * Opens a dialog listing uploaded custom sounds with preview and delete actions.
 */
export async function showCustomSoundManagerDialog() {
	const library = await loadLibrary();

	const overlay = createPromptOverlay();
	const dialogBox = createPromptBox();

	const title = document.createElement("div");
	title.className = "vh-prompt-message";
	title.style.fontWeight = "bold";
	title.style.marginBottom = "12px";
	title.textContent = getMessageOrDefault("formSoundManageTitle", "Manage custom sounds");
	dialogBox.appendChild(title);

	const list = document.createElement("div");
	list.style.display = "flex";
	list.style.flexDirection = "column";
	list.style.gap = "8px";
	list.style.marginBottom = "16px";

	const renderList = () => {
		list.textContent = "";
		const currentLibrary = listCustomSounds(library);
		if (currentLibrary.length === 0) {
			const empty = document.createElement("div");
			empty.textContent = getMessageOrDefault("formSoundNoCustomSounds", "No custom sounds uploaded.");
			list.appendChild(empty);
			return;
		}

		for (const entry of currentLibrary) {
			const soundValue = customSoundValue(entry.id);
			const references = findCustomSoundReferences(soundValue, Settings.getSettingsTree());
			const row = document.createElement("div");
			row.style.display = "flex";
			row.style.alignItems = "center";
			row.style.gap = "8px";
			row.style.justifyContent = "space-between";

			const info = document.createElement("div");
			info.style.flex = "1";
			info.style.minWidth = "0";
			info.textContent = `${entry.name} — ${bytesToSize(entry.sizeBytes)} — ${getMessageOrDefault(
				"formSoundUsageCount",
				"$1$ use(s)"
			).replace("$1$", String(references.length))}`;

			const actions = document.createElement("div");
			actions.style.display = "flex";
			actions.style.gap = "6px";
			actions.style.flexShrink = "0";

			const playBtn = document.createElement("button");
			playBtn.type = "button";
			playBtn.className = "vh-prompt-btn vh-prompt-btn-ok";
			playBtn.textContent = getMessageOrDefault("formSoundPreview", "Play");
			playBtn.addEventListener("click", () => {
				void playNotificationSound(soundValue, 1);
			});

			const deleteBtn = document.createElement("button");
			deleteBtn.type = "button";
			deleteBtn.className = "vh-prompt-btn vh-prompt-btn-cancel";
			deleteBtn.textContent = getMessageOrDefault("formSoundDelete", "Delete");
			deleteBtn.addEventListener("click", async () => {
				const deleted = await deleteCustomSoundEntry(entry);
				if (deleted) {
					renderList();
				}
			});

			actions.appendChild(playBtn);
			actions.appendChild(deleteBtn);
			row.appendChild(info);
			row.appendChild(actions);
			list.appendChild(row);
		}
	};

	renderList();
	dialogBox.appendChild(list);

	const buttonContainer = document.createElement("div");
	buttonContainer.className = "vh-prompt-buttons";
	buttonContainer.style.cssText = "display:flex;justify-content:flex-end;gap:10px;";

	const closeButton = document.createElement("button");
	closeButton.type = "button";
	closeButton.className = "vh-prompt-btn vh-prompt-btn-ok";
	closeButton.textContent = getMessageOrDefault("dialogClose", "Close");
	closeButton.addEventListener("click", () => overlay.remove());

	buttonContainer.appendChild(closeButton);
	dialogBox.appendChild(buttonContainer);
	overlay.appendChild(dialogBox);
	overlay.addEventListener("click", (event) => {
		if (event.target === overlay) {
			overlay.remove();
		}
	});
	document.body.appendChild(overlay);
}

/**
 * Wires the manage-custom-sounds button on the settings page.
 * @param {string} btnId
 */
export function manageCustomSoundLibraryButton(btnId) {
	const btn = document.getElementById(btnId);
	if (!btn) {
		return;
	}

	if (btn._VHelperCustomSoundManageHandler) {
		btn.removeEventListener("click", btn._VHelperCustomSoundManageHandler);
	}

	btn._VHelperCustomSoundManageHandler = () => {
		void showCustomSoundManagerDialog();
	};
	btn.addEventListener("click", btn._VHelperCustomSoundManageHandler);
}

function formatUploadConfirmMessage(analyzed) {
	const fileSize = bytesToSize(analyzed.sizeBytes);
	const currentUsage = bytesToSize(analyzed.currentUsageBytes);
	const template = getMessageOrDefault(
		"formSoundUploadConfirm",
		"This sound file will use $1$ of local storage (limited to 10 MB). You currently use $2$ of local storage.\n\nContinue?"
	);
	return template.replace("$1$", fileSize).replace("$2$", currentUsage);
}

function formatQuotaExceededMessage(analyzed) {
	const fileSize = bytesToSize(analyzed.sizeBytes);
	const currentUsage = bytesToSize(analyzed.currentUsageBytes);
	const available = bytesToSize(Math.max(0, LOCAL_STORAGE_QUOTA_BYTES - analyzed.currentUsageBytes));
	const template = getMessageOrDefault(
		"formSoundQuotaExceeded",
		"Not enough local storage. This file needs $1$ but only $2$ is available (10 MB limit, $3$ already used)."
	);
	return template.replace("$1$", fileSize).replace("$2$", available).replace("$3$", currentUsage);
}

/**
 * Prompt the user to pick an audio file and import it into the shared custom sound library.
 * Reuses an existing entry when the same file was uploaded before.
 * @returns {Promise<string|null>} Custom sound setting value (custom:id) or null when cancelled/failed.
 */
export async function pickAndImportCustomSound() {
	const file = await promptForSoundFile();
	if (!file) {
		return null;
	}

	let analyzed;
	try {
		analyzed = await analyzeSoundFile(file);
	} catch (error) {
		if (error.message === "INVALID_TYPE") {
			alert(getMessageOrDefault("formSoundInvalidType", "Please select an audio file (MP3, WAV, OGG, etc.)."));
		} else {
			alert(
				getMessageOrDefault("formSoundImportFailed", "Could not save custom sound: $1$").replace(
					"$1$",
					error.message
				)
			);
		}
		return null;
	}

	if (!analyzed.existingId) {
		const availableBytes = LOCAL_STORAGE_QUOTA_BYTES - analyzed.currentUsageBytes;
		if (analyzed.sizeBytes > availableBytes) {
			alert(formatQuotaExceededMessage(analyzed));
			return null;
		}

		const confirmed = await confirmPrompt(formatUploadConfirmMessage(analyzed));
		if (!confirmed) {
			return null;
		}
	}

	try {
		const { id } = await importAnalyzedSound(analyzed);
		await refreshAllSoundSelectOptions();
		return CUSTOM_SOUND_PREFIX + id;
	} catch (error) {
		if (error.message === "QUOTA_EXCEEDED") {
			alert(formatQuotaExceededMessage(analyzed));
		} else {
			alert(
				getMessageOrDefault("formSoundImportFailed", "Could not save custom sound: $1$").replace(
					"$1$",
					error.message
				)
			);
		}
		return null;
	}
}

/**
 * Manages a sound select box with built-in sounds, shared custom uploads, and preview support.
 * @param {string} key - The settings key
 */
export async function manageSoundSelectBox(key) {
	const val = Settings.get(key);
	const keyE = CSS.escape(key);
	const selectObj = document.querySelector(`label[for='${keyE}'] select`);
	if (!selectObj) {
		return;
	}

	await populateSoundSelectOptions(selectObj, val);
	selectObj.value = val;
	if (selectObj.value !== val && val) {
		addMissingCustomSoundOption(selectObj, val);
		selectObj.value = val;
	}

	if (!selectObj._VHelperSoundChangeHandler) {
		selectObj._VHelperSoundChangeHandler = async function () {
			const previousValue = Settings.get(key);

			if (selectObj.value === UPLOAD_OPTION_VALUE) {
				const newValue = await pickAndImportCustomSound();
				if (!newValue) {
					selectObj.value = previousValue;
					return;
				}

				await populateSoundSelectOptions(selectObj, newValue);
				selectObj.value = newValue;
				await Settings.set(key, newValue);
				return;
			}

			await Settings.set(key, selectObj.value);
		};
		selectObj.addEventListener("change", selectObj._VHelperSoundChangeHandler);
	}
}

/**
 * Manage the inputs related to the voice notification feature
 */
export async function manageSelectVoice() {
	const key = "notification.monitor.voice";

	// Migrate the old setting if it exists
	// Hopefully we can eventually remove this code in a couple months
	const existing = Settings.get(key);
	if (typeof existing === "string") {
		if (existing) {
			Settings.set(key, { enabled: true, voiceURI: existing });
		} else {
			Settings.set(key, undefined);
		}
	}

	const toggleObj = document.querySelector("input[name='notification.monitor.voice.enabled']");
	const selectObj = document.querySelector(`label[for='${CSS.escape(key)}'] select`);
	const textObj = document.querySelector("input[name='notification.monitor.voice.test.text']");
	const buttonObj = document.getElementById("notification.monitor.voice.test.button");

	if (!selectObj || !textObj || !buttonObj) return;

	const updateEnabledState = () => {
		const isEnabled = toggleObj.checked;
		selectObj.disabled = !isEnabled;

		const enableTester = isEnabled && !!selectObj.value;
		textObj.disabled = !enableTester;
		buttonObj.disabled = !enableTester;
	};

	if (!("speechSynthesis" in window)) {
		// If Speech Synthesis not supported in the current browser,
		// disable all the related elements.
		toggleObj.disabled = true;
		updateEnabledState();
		return;
	}

	// Load existing config
	const { enabled, voiceURI } = Settings.get(key) || {};
	toggleObj.checked = enabled;

	const populateVoices = () => {
		const voices = speechSynthesis.getVoices();
		if (voices?.length === 0) return;

		// Clear existing options (avoid duplicates)
		selectObj.textContent = "";

		// Optional placeholder
		const ph = document.createElement("option");
		ph.value = "";
		ph.textContent = getMessageOrDefault("formVoiceOff", "Off / No voice");
		selectObj.appendChild(ph);

		for (const voice of voices) {
			const option = document.createElement("option");
			option.value = voice.voiceURI;
			option.textContent = `${voice.name} (${voice.lang})${voice.default ? getMessageOrDefault("formVoiceDefault", " [DEFAULT]") : ""}`;
			selectObj.appendChild(option);
		}

		// Restore selection
		if (voiceURI) selectObj.value = voiceURI;

		updateEnabledState();
	};

	// 1) Try immediately (most important)
	populateVoices();

	// 2) Fallback: voices load later
	speechSynthesis.addEventListener("voiceschanged", populateVoices, { once: true });

	// Test button
	const defaultTestText = getMessageOrDefault(
		"formVoiceTestText",
		"This voice will be used to read the item titles after the alert sound"
	);
	const readTestText = () => {
		const utterance = new SpeechSynthesisUtterance(textObj.value || defaultTestText);
		utterance.voice = speechSynthesis.getVoices().find((v) => v.voiceURI === selectObj.value) || null;

		// Optional: cancel any ongoing speech so it doesn't queue up forever
		speechSynthesis.cancel();
		speechSynthesis.speak(utterance);
	};
	if (buttonObj._VHelperVoiceTestHandler) {
		buttonObj.removeEventListener("click", buttonObj._VHelperVoiceTestHandler);
	}
	buttonObj._VHelperVoiceTestHandler = readTestText;
	buttonObj.addEventListener("click", buttonObj._VHelperVoiceTestHandler);

	if (toggleObj._VHelperVoiceToggleHandler) {
		toggleObj.removeEventListener("change", toggleObj._VHelperVoiceToggleHandler);
	}
	toggleObj._VHelperVoiceToggleHandler = (event) => {
		Settings.set(`${key}.enabled`, event.target.checked);
		updateEnabledState();
	};
	toggleObj.addEventListener("change", toggleObj._VHelperVoiceToggleHandler);

	if (selectObj._VHelperVoiceSelectHandler) {
		selectObj.removeEventListener("change", selectObj._VHelperVoiceSelectHandler);
	}
	selectObj._VHelperVoiceSelectHandler = (event) => {
		const newValue = event.target.value;
		Settings.set(`${key}.voiceURI`, newValue);
		updateEnabledState();
	};
	selectObj.addEventListener("change", selectObj._VHelperVoiceSelectHandler);

	updateEnabledState();
}

/**
 * Manages a play button for testing audio
 * @param {string} btnId - The button ID
 * @param {string} selectName - The select element name for audio file
 * @param {string} volumeName - The volume input name
 */
const playButtonHandlers = new WeakMap();

export function managePlayButton(btnId, selectName, volumeName) {
	const btn = document.getElementById(btnId);
	if (!btn) {
		return;
	}

	const previousHandler = playButtonHandlers.get(btn);
	if (previousHandler) {
		btn.removeEventListener("click", previousHandler);
	}

	const clickHandler = function () {
		const volumeObj = document.querySelector(`label[for='${volumeName}'] input`);
		const selectObj = document.querySelector(`label[for='${selectName}'] select`);
		if (!volumeObj || !selectObj) {
			return false;
		}
		if (selectObj.value == "0" || selectObj.value === UPLOAD_OPTION_VALUE) {
			return false;
		}

		void playNotificationSound(selectObj.value, Number(volumeObj.value));
	};

	btn.addEventListener("click", clickHandler);
	playButtonHandlers.set(btn, clickHandler);
}

/**
 * Manages a dual range slider (min/max range selector)
 * @param {Object} config - Configuration object
 * @param {string} config.minKey - Settings key for minimum value
 * @param {string} config.maxKey - Settings key for maximum value
 * @param {string} config.fromSliderId - ID of the "from" slider element
 * @param {string} config.toSliderId - ID of the "to" slider element
 * @param {string} config.fromInputId - ID of the "from" input element
 * @param {string} config.toInputId - ID of the "to" input element
 * @param {number} [config.defaultMin=5] - Default minimum value
 * @param {number} [config.defaultMax=10] - Default maximum value
 * @param {string} [config.sliderColor="#C6C6C6"] - Color for inactive slider portions
 * @param {string} [config.rangeColor="#25daa5"] - Color for active range
 */
export function manageDualRangeSlider(config) {
	const {
		minKey,
		maxKey,
		fromSliderId,
		toSliderId,
		fromInputId,
		toInputId,
		defaultMin = 5,
		defaultMax = 10,
		sliderColor = "#C6C6C6",
		rangeColor = "#25daa5",
	} = config;

	const fromSlider = document.querySelector(`#${fromSliderId}`);
	const toSlider = document.querySelector(`#${toSliderId}`);
	const fromInput = document.querySelector(`#${fromInputId}`);
	const toInput = document.querySelector(`#${toInputId}`);

	if (!fromSlider || !toSlider || !fromInput || !toInput) {
		console.error("Dual range slider: One or more elements not found", {
			fromSliderId,
			toSliderId,
			fromInputId,
			toInputId,
		});
		return;
	}

	function controlFromInput(fromSlider, fromInput, toInput, controlSlider) {
		let [from, to] = getParsed(fromInput, toInput);
		const min = parseInt(fromInput.min, 10);
		const max = parseInt(fromInput.max, 10);
		if (from < min) {
			fromInput.value = min;
			from = min;
		}
		if (from > max) {
			fromInput.value = max;
			from = max;
		}
		if (from > to) {
			fromSlider.value = to;
			fromInput.value = to;
		} else {
			fromSlider.value = from;
		}
		fillSlider(fromInput, toInput, sliderColor, rangeColor, controlSlider);
		saveDualRangeSlider(from, to);
	}

	function controlToInput(toSlider, fromInput, toInput, controlSlider) {
		let [from, to] = getParsed(fromInput, toInput);
		const min = parseInt(toInput.min, 10);
		const max = parseInt(toInput.max, 10);
		if (to < min) {
			toInput.value = min;
			to = min;
		}
		if (to > max) {
			toInput.value = max;
			to = max;
		}
		setToggleAccessible(toSlider);
		if (from <= to) {
			toSlider.value = to;
			toInput.value = to;
		} else {
			toInput.value = from;
		}
		fillSlider(fromInput, toInput, sliderColor, rangeColor, controlSlider);
		saveDualRangeSlider(from, to);
	}

	function controlFromSlider(fromSlider, toSlider, fromInput) {
		const [from, to] = getParsed(fromSlider, toSlider);
		const value = parseInt(fromSlider.value, 10);
		const min = parseInt(fromInput.min, 10);
		const max = parseInt(fromInput.max, 10);
		if (from > to) {
			fromSlider.value = to;
			fromInput.value = to;
		} else {
			if (value < min) {
				fromSlider.value = min;
			} else if (value > max) {
				fromSlider.value = max;
			} else {
				fromInput.value = from;
			}
		}
		fillSlider(fromSlider, toSlider, sliderColor, rangeColor, toSlider);
		saveDualRangeSlider(from, to);
	}

	function controlToSlider(fromSlider, toSlider, toInput) {
		const [from, to] = getParsed(fromSlider, toSlider);
		const value = parseInt(toSlider.value, 10);
		const min = parseInt(toInput.min, 10);
		const max = parseInt(toInput.max, 10);
		setToggleAccessible(toSlider);
		if (from <= to) {
			if (value < min) {
				toSlider.value = min;
			} else if (value > max) {
				toSlider.value = max;
			} else {
				toSlider.value = to;
				toInput.value = to;
			}
		} else {
			toInput.value = from;
			toSlider.value = from;
		}
		fillSlider(fromSlider, toSlider, sliderColor, rangeColor, toSlider);
		saveDualRangeSlider(from, to);
	}

	function getParsed(currentFrom, currentTo) {
		const from = parseInt(currentFrom.value, 10);
		const to = parseInt(currentTo.value, 10);
		return [from, to];
	}

	function fillSlider(from, to, sliderColor, rangeColor, controlSlider) {
		const rangeDistance = to.max - to.min;
		const fromPosition = from.value - to.min;
		const toPosition = to.value - to.min;
		controlSlider.style.background = `linear-gradient(
      to right,
      ${sliderColor} 0%,
      ${sliderColor} ${(fromPosition / rangeDistance) * 100}%,
      ${rangeColor} ${(fromPosition / rangeDistance) * 100}%,
      ${rangeColor} ${(toPosition / rangeDistance) * 100}%,
      ${sliderColor} ${(toPosition / rangeDistance) * 100}%,
      ${sliderColor} 100%)`;
	}

	function setToggleAccessible(currentTarget) {
		if (Number(currentTarget.value) <= 0) {
			toSlider.style.zIndex = 2;
		} else {
			toSlider.style.zIndex = 0;
		}
	}

	function saveDualRangeSlider(from, to) {
		Settings.set(minKey, from);
		Settings.set(maxKey, to);
	}

	function loadDualRangeSlider() {
		const from = Settings.get(minKey) ?? defaultMin;
		const to = Settings.get(maxKey) ?? defaultMax;
		fromInput.value = from;
		toInput.value = to;
		controlFromInput(fromSlider, fromInput, toInput, toSlider);
		controlToInput(toSlider, fromInput, toInput, toSlider);
	}

	// Initialize
	fillSlider(fromSlider, toSlider, sliderColor, rangeColor, toSlider);
	setToggleAccessible(toSlider);

	// Set up event listeners (with duplicate prevention)
	if (!fromSlider._VHelperInputHandler) {
		fromSlider._VHelperInputHandler = () => controlFromSlider(fromSlider, toSlider, fromInput);
		fromSlider.addEventListener("input", fromSlider._VHelperInputHandler);
	}
	if (!toSlider._VHelperInputHandler) {
		toSlider._VHelperInputHandler = () => controlToSlider(fromSlider, toSlider, toInput);
		toSlider.addEventListener("input", toSlider._VHelperInputHandler);
	}
	if (!fromInput._VHelperInputHandler) {
		fromInput._VHelperInputHandler = () => controlFromInput(fromSlider, fromInput, toInput, toSlider);
		fromInput.addEventListener("input", fromInput._VHelperInputHandler);
	}
	if (!toInput._VHelperInputHandler) {
		toInput._VHelperInputHandler = () => controlToInput(toSlider, fromInput, toInput, toSlider);
		toInput.addEventListener("input", toInput._VHelperInputHandler);
	}

	loadDualRangeSlider();
}
