import { NotificationMonitorV3Lite } from "../scripts/notifications-monitor/core/NotificationMonitorV3Lite.js";
import { initLocaleOverride, getMessageForTemplate } from "/scripts/core/services/Internationalization.js";
import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
import { initApiValidationReporter } from "/scripts/core/services/ApiValidationReporter.js";
import { initParseHealthReporter } from "/scripts/core/services/ParseHealthReporter.js";
import { isFirefox, isChromium, isWebKitNonChromium } from "/scripts/core/utils/BrowserDetection.js";
import { applyUserTheme } from "/scripts/ui/utils/applyUserTheme.js";

const NotifMon = new NotificationMonitorV3Lite();
const Settings = new SettingsMgr();

function loadCustomCSS(content) {
	const styleId = "vh-custom-css";
	let style = document.getElementById(styleId);
	if (!style) {
		style = document.createElement("style");
		style.id = styleId;
		document.head.appendChild(style);
	}
	style.textContent = content ? `/*general.customCSS*/\n${content}` : "";
}

//If browser is firefox, load icon_firefox.css
if (isFirefox()) {
	document.head.innerHTML += `<link rel="stylesheet" type="text/css" href="../resource/css/icon_firefox.css" />`;
}
//If the browser is chrome, load icon_chrome.css
if (isChromium()) {
	document.head.innerHTML += `<link rel="stylesheet" type="text/css" href="../resource/css/icon_chrome.css" />`;
}
if (isWebKitNonChromium()) {
	document.head.innerHTML += `<link rel="stylesheet" type="text/css" href="../resource/css/icon_ios.css" />`;
}

(async () => {
	// Apply user's language override before any UI is rendered (monitor, templates, etc.)
	await Settings.waitForLoad();
	initApiValidationReporter();
	initParseHealthReporter();
	await initLocaleOverride(Settings.get("i18n.localeOverride"));
	window.__VH_GET_MESSAGE__ = getMessageForTemplate;

	applyUserTheme(Settings);

	// Keep behavior aligned with Vine-page preboot: inject user custom CSS in V3 Lite too.
	const customCSS = Settings.get("general.customCSS");
	if (customCSS) {
		loadCustomCSS(customCSS);
	}

	await NotifMon.initialize();
})();
