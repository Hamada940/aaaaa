import {
	Internationalization,
	initLocaleOverride,
	getMessageForTemplate,
	getMessageOrDefault,
} from "/scripts/core/services/Internationalization.js";
const i18n = new Internationalization();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { Environment } from "/scripts/core/services/Environment.js";
const env = new Environment();

import { isFirefox, isChromium, isSafari } from "/scripts/core/utils/BrowserDetection.js";

var scriptName = "reviews_manages.js";

//Insert the icon stylesheet based on the browser being used
//If browser is firefox, load icon_firefox.css
if (isFirefox()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "/resource/css/icon_firefox.css";
	document.head.appendChild(link);
}
//If the browser is chrome, load icon_chrome.css
if (isChromium()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "/resource/css/icon_chrome.css";
	document.head.appendChild(link);
}
if (isSafari()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "/resource/css/icon_ios.css";
	document.head.appendChild(link);
}

function logError(errorArray) {
	const [functionName, scriptName, error] = errorArray;
	console.error(`${scriptName}-${functionName} generated the following error: ${error.message}`);
} // testing

var arrReview = [];

function applyPageTranslations() {
	const msg = (key, fallback) => getMessageForTemplate(key) || fallback;
	const el = (id) => document.getElementById(id);
	const q = (sel) => document.querySelector(sel);
	if (q("h1")) q("h1").textContent = msg("pageReviewsManageTitle", "Saved reviews");
	if (q("#save")) q("#save").textContent = msg("pageReviewsManageSave", "Save");
	const note = q(".vh-visible-container");
	if (note && note.firstChild && note.firstChild.nodeType === Node.TEXT_NODE) {
		const maxReviews = Math.max(1, parseInt(Settings.get("general.reviewToolbarMaxReviews", 100), 10) || 100);
		note.firstChild.textContent =
			getMessageOrDefault(
				"pageReviewsManageStorageNote",
				`Your reviews are locally stored. Make sure you are deleting old ones as to keep their size to a minimum. A maximum of ${maxReviews} saved reviews are allowed. `,
				[maxReviews]
			) + " ";
	}
	const tr = q("#reviews_list tbody tr");
	if (tr && tr.cells.length >= 4) {
		tr.cells[0].textContent = msg("pageReviewsManageHeaderAction", "Action");
		tr.cells[1].textContent = msg("pageReviewsManageHeaderTitle", "Title");
		tr.cells[2].textContent = msg("pageReviewsManageHeaderAsin", "ASIN");
		tr.cells[3].textContent = msg("pageReviewsManageHeaderDate", "Date");
	}
}

async function loadSettings() {
	try {
		await Settings.waitForLoad();
		// Apply user's language override so JS and re-applied static content use it
		await initLocaleOverride(Settings.get("i18n.localeOverride"));
		window.__VH_GET_MESSAGE__ = getMessageForTemplate;
		applyPageTranslations();

		//Set the country
		const countryCode = Settings.get("general.country");

		if (countryCode != null) {
			i18n.setCountryCode(countryCode);
		}

		let reviewSet = await chrome.storage.local.get("reviews");
		let reviews = reviewSet?.reviews ?? []; //Nullish coalescing & Optional chaining prevents undefined without extra code
		if (Object.keys(reviews).length === 0) {
			await chrome.storage.local.set({ reviews: [] });
		}
		arrReview = reviews;
		if (arrReview.length) {
			updateReviewTable();
			displayReviewsSize();
		} else {
			const templateTable = document.getElementById("reviews_list");
			templateTable.style.display = "none";
		}
	} catch (e) {
		logError([scriptName, "loadSettings", e.message]);
	}
}
async function displayReviewsSize() {
	document.getElementById("storage-used").textContent =
		`Currently using: ${await getStorageKeySizeinBytes("reviews")}`;
}

async function handleSaveClick() {
	const asin = document.getElementById("asin").value;
	if (asin == "") {
		return false;
	}

	const index = arrReview.findIndex((review) => review.asin === asin);
	arrReview[index].title = JSON.stringify(document.getElementById("title").value);
	arrReview[index].content = JSON.stringify(document.getElementById("content").value);
	await chrome.storage.local.set({ reviews: arrReview });
}

function updateReviewTable() {
	try {
		const tableBody = document.getElementById("reviews_list").querySelector("tbody");
		for (let i = arrReview.length - 1; i >= 0; i--) {
			let { date, asin, title } = arrReview[i];
			let formattedDate = new Date(date).toLocaleDateString();
			const row = tableBody.insertRow();
			const actionCell = row.insertCell();
			const titleCell = row.insertCell();
			const asinCell = row.insertCell();
			const dateCell = row.insertCell();

			// Create action buttons safely
			const viewButton = document.createElement("button");
			viewButton.id = "view";
			viewButton.dataset.asin = asin;
			viewButton.className = "vh-button";
			viewButton.textContent = "View";

			const deleteButton = document.createElement("button");
			deleteButton.id = "delete";
			deleteButton.dataset.asin = asin;
			deleteButton.className = "vh-button";
			deleteButton.textContent = "Delete";

			actionCell.appendChild(viewButton);
			actionCell.appendChild(document.createTextNode(" "));
			actionCell.appendChild(deleteButton);

			dateCell.textContent = formattedDate;

			// Create ASIN cell with link safely
			asinCell.appendChild(document.createTextNode(asin + " "));
			const asinLink = document.createElement("a");
			asinLink.href = `https://www.amazon.${i18n.getDomainTLD()}/dp/${asin}`;
			asinLink.target = "_blank";
			const newtabIcon = document.createElement("div");
			newtabIcon.className = "vh-icon-16 vh-icon-newtab";
			newtabIcon.style.cssText = "margin-left: 5px;filter: invert(1);";
			asinLink.appendChild(newtabIcon);
			asinCell.appendChild(asinLink);

			titleCell.textContent = JSON.parse(title);
		}
	} catch (e) {
		logError([scriptName, "updateReviewTable", e.message]);
	}
}

document.addEventListener("click", (event) => {
	const { target } = event;
	if (target.tagName !== "BUTTON") return;

	if (target.matches("#view")) {
		handleViewClick(target.dataset.asin);
	} else if (target.matches("#delete")) {
		handleDeleteClick(target.dataset.asin);
	} else if (target.matches("#save")) {
		handleSaveClick();
	}
});

function getReview(asin) {
	try {
		return arrReview.find((review) => review.asin === asin);
	} catch (e) {
		logError([scriptName, "getReview", e.message]);
	}
}

async function handleViewClick(asin) {
	try {
		const review = getReview(asin);
		if (review) {
			let { title, content } = review;
			document.getElementById("asin").value = asin;
			document.getElementById("title").value = JSON.parse(title);
			document.getElementById("content").textContent = JSON.parse(content);
		}
	} catch (e) {
		logError([scriptName, "handleViewClick", e.message]);
	}
}

async function handleDeleteClick(asin) {
	try {
		if (confirm("Delete this review?")) {
			await deleteReview(asin);
		}
	} catch (error) {
		logError([scriptName, "handleDeleteClick", e.message]);
	}
}

async function deleteReview(asin) {
	try {
		const index = arrReview.findIndex((review) => review.asin === asin);
		const filteredReviews = arrReview.filter((review, i) => i !== index);
		await chrome.storage.local.set({ reviews: filteredReviews });
		location.reload();
	} catch (e) {
		logError([scriptName, "deleteReview", e.message]);
	}
}

function bytesToSize(bytes, decimals = 2) {
	if (!Number(bytes)) {
		return "0 Bytes";
	}

	const kbToBytes = 1024;
	const dm = decimals < 0 ? 0 : decimals;
	const sizes = ["Bytes", "KB", "MB", "GB", "TB"];

	const index = Math.floor(Math.log(bytes) / Math.log(kbToBytes));

	return `${parseFloat((bytes / Math.pow(kbToBytes, index)).toFixed(dm))} ${sizes[index]}`;
}
function getStorageKeySizeinBytes(key) {
	return new Promise((resolve, reject) => {
		chrome.storage.local.get(key, function (items) {
			if (chrome.runtime.lastError) {
				reject(new Error(chrome.runtime.lastError.message));
			} else {
				const storageSize = JSON.stringify(items[key]).length;
				resolve(bytesToSize(storageSize));
			}
		});
	});
}

window.addEventListener("DOMContentLoaded", function () {
	loadSettings();
});
