/**
 * Injects the user's selected theme into extension pages (reviews_templates, reviews_manage, item_explorer, item_explorer_statistics).
 * Run as first script in head so the theme link can be updated before paint. Reads from chrome.storage (settings key).
 */
(function () {
	const THEME_MAP = {
		forest: "resource/theme/forest.css",
		dark: "resource/theme/dark.css",
		aurora: "resource/theme/aurora.css",
		garish: "resource/theme/garish.css",
		midnight: "resource/theme/midnight.css",
		scifi: "resource/theme/scifi.css",
		win31: "resource/theme/win31.css",
	};

	function injectLink(href, media = null, id = null) {
		const link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = chrome.runtime.getURL(href);
		if (media) link.setAttribute("media", media);
		if (id) link.id = id;
		document.head.appendChild(link);
	}

	function applyTheme(settings) {
		const theme = settings?.general?.theme || "forest";
		const darkTheme = settings?.thorvarium?.darktheme;
		const darkThemeSystem = settings?.thorvarium?.darkthemeSystem;

		let existing = document.getElementById("vh-theme-link");
		if (!existing) {
			existing = document.createElement("link");
			existing.id = "vh-theme-link";
			existing.rel = "stylesheet";
			document.head.appendChild(existing);
		}

		let existingDark = document.getElementById("vh-theme-link-dark");
		if (existingDark) existingDark.remove();

		if (darkTheme || theme === "dark") {
			existing.href = chrome.runtime.getURL(THEME_MAP.dark || THEME_MAP.forest);
		} else if (darkThemeSystem) {
			existing.href = chrome.runtime.getURL(THEME_MAP.forest);
			injectLink(THEME_MAP.dark, "(prefers-color-scheme: dark)", "vh-theme-link-dark");
		} else {
			existing.href = chrome.runtime.getURL(THEME_MAP[theme] || THEME_MAP.forest);
		}
	}

	chrome.storage.local.get("settings", (data) => {
		applyTheme(data?.settings ?? {});
	});
})();
