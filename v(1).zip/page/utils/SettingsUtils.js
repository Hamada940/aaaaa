/**
 * @fileoverview SettingsUtils - Utility functions for settings management
 */

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

/**
 * Returns the suffix for the rank (st, nd, rd, th)
 * @param {number} number - The number to get the suffix for
 * @returns {string} The suffix
 */
export function rankSuffix(number) {
	if (number % 10 == 1 && number % 100 != 11) {
		return "st";
	} else if (number % 10 == 2 && number % 100 != 12) {
		return "nd";
	} else if (number % 10 == 3 && number % 100 != 13) {
		return "rd";
	}
	return "th";
}
