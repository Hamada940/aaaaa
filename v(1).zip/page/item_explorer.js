import { ISODatetoYMDHiS } from "/scripts/core/utils/DateHelper.js";

import { Environment } from "/scripts/core/services/Environment.js";
var env = new Environment();

import {
	Internationalization,
	initLocaleOverride,
	getMessageForTemplate,
	getMessageOrDefault,
} from "/scripts/core/services/Internationalization.js";
const i18n = new Internationalization();

import { Pagination } from "/scripts/ui/controllers/Pagination.js";
const pagination = new Pagination();

import { PinnedListMgr } from "/scripts/core/services/PinnedListMgr.js";
var PinnedList = new PinnedListMgr();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
const cryptoKeys = new CryptoKeys();

import { unescapeHTML, removeSpecialHTML, escapeHTML } from "/scripts/core/utils/StringHelper.js";

import { Item, WITH_VARIANT } from "/scripts/core/models/Item.js";

import { isFirefox, isChromium, isSafari } from "/scripts/core/utils/BrowserDetection.js";

import { Template } from "/scripts/core/utils/Template.js";
const Tpl = new Template();

import { getGroups } from "/scripts/core/utils/KeywordGroupsManager.js";
import { compileKeywordGroupsFilter } from "/scripts/core/utils/KeywordOpenSearchCompiler.js";

import { ModalMgr } from "/scripts/ui/controllers/ModalMgr.js";
const modalMgr = new ModalMgr();

let secondsLeft = 10;
let lastSkippedKeywords = [];
let lastSkippedTooManyVariants = [];

const STORAGE_HIGHLIGHT_GROUP_IDS = "itemExplorer.selectedHighlightGroupIds";
const STORAGE_HIDE_GROUP_IDS = "itemExplorer.selectedHideGroupIds";
const MAX_REQUEST_BODY_BYTES = 900000;

//If browser is firefox, load icon_firefox.css
if (isFirefox()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_firefox.css";
	document.head.appendChild(link);
}
//If the browser is chrome, load icon_chrome.css
if (isChromium()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_chrome.css";
	document.head.appendChild(link);
}
if (isSafari()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_ios.css";
	document.head.appendChild(link);
}

function loadStyleSheetContent(content, path = "injected") {
	if (content != "") {
		const style = document.createElement("style");
		style.textContent = "/*" + path + "*/\n" + content;
		document.head.appendChild(style);
	}
}

function loadCustomCSS(content) {
	const styleId = "vh-custom-css";
	let style = document.getElementById(styleId);
	if (!style) {
		style = document.createElement("style");
		style.id = styleId;
		document.head.appendChild(style);
	}
	style.textContent = content ? `/*general.customCSS*/\n${content}` : "";
}

/**
 * This function will apply the translations with the user selected language, replacing the browser defaults.
 */
function applyItemExplorerTranslations() {
	const m = (key, fallback) => getMessageForTemplate(key) || fallback;
	document.title = m("pageItemExplorerTitle", "VHIE");
	const q = (s) => document.querySelector(s);
	const byId = (id) => document.getElementById(id);
	if (q(".vh-header-text h2"))
		q(".vh-header-text h2").textContent = m("pageItemExplorerHeaderTitle", "Items Explorer");
	if (q(".vh-header-text h3"))
		q(".vh-header-text h3").textContent = m("pageItemExplorerHeaderSubtitle", "Advanced database search tool");
	if (q(".vh-statistics-link"))
		q(".vh-statistics-link").textContent = m("pageItemExplorerViewDropsStats", "View Drops Statistics");
	const setLabel = (id, key, fb) => {
		const el = q(`label[for="${id}"]`);
		if (el) el.textContent = m(key, fb);
	};
	const setLabelWithHint = (id, key, fb, hintKey, hintFb) => {
		const el = q(`label[for="${id}"]`);
		if (!el) return;
		el.textContent = "";
		el.append(m(key, fb), " ");
		const hint = document.createElement("span");
		hint.className = "vh-label-hint";
		hint.textContent = m(hintKey, hintFb);
		el.appendChild(hint);
	};
	const setPlaceholder = (id, key, fb) => {
		const el = byId(id);
		if (el) el.placeholder = m(key, fb);
	};
	setLabel("search-asin", "pageItemExplorerLabelAsin", "ASIN");
	setPlaceholder("search-asin", "pageItemExplorerLabelAsin", "ASIN");
	setLabelWithHint(
		"search-title",
		"pageItemExplorerLabelTitle",
		"Title",
		"pageItemExplorerWildcardHint",
		"* = wildcard"
	);
	setPlaceholder("search-title", "pageItemExplorerLabelTitle", "Title");
	setLabel("vh-queue-select", "pageItemExplorerLabelQueue", "Queue");
	setLabel("vh-order-by-select", "pageItemExplorerLabelOrderBy", "Order by");
	setLabel("search-etv-min", "pageItemExplorerLabelEtvMin", "ETV Min");
	setPlaceholder("search-etv-min", "pageItemExplorerLabelEtvMin", "ETV Min");
	setLabel("search-etv-max", "pageItemExplorerLabelEtvMax", "ETV Max");
	setPlaceholder("search-etv-max", "pageItemExplorerLabelEtvMax", "ETV Max");
	setLabel("search-price-min", "pageItemExplorerLabelPriceMin", "Price Min");
	setPlaceholder("search-price-min", "pageItemExplorerLabelPriceMin", "Price Min");
	setLabel("search-price-max", "pageItemExplorerLabelPriceMax", "Price Max");
	setPlaceholder("search-price-max", "pageItemExplorerLabelPriceMax", "Price Max");
	setLabel("unavailable-select", "pageItemExplorerLabelUnavailable", "Unavailable");
	const opt = (sel, key, fb) => {
		const o = q(sel);
		if (o) o.textContent = m(key, fb);
	};
	opt("#vh-queue-select option[value='all']", "pageItemExplorerQueueAll", "All Queues");
	opt("#vh-queue-select option[value='last_chance_encore']", "pageItemExplorerQueueAfaAi", "AFA & AI");
	opt("#vh-order-by-select option[value='asin_asc']", "pageItemExplorerOrderAsinAsc", "ASIN (A-Z)");
	opt("#vh-order-by-select option[value='asin_desc']", "pageItemExplorerOrderAsinDesc", "ASIN (Z-A)");
	opt("#vh-order-by-select option[value='title_asc']", "pageItemExplorerOrderTitleAsc", "Title (A-Z)");
	opt("#vh-order-by-select option[value='title_desc']", "pageItemExplorerOrderTitleDesc", "Title (Z-A)");
	opt("#vh-order-by-select option[value='etv_asc']", "pageItemExplorerOrderEtvAsc", "ETV (Low-High)");
	opt("#vh-order-by-select option[value='etv_desc']", "pageItemExplorerOrderEtvDesc", "ETV (High-Low)");
	opt("#vh-order-by-select option[value='price_asc']", "pageItemExplorerOrderPriceAsc", "Price (Low-High)");
	opt("#vh-order-by-select option[value='price_desc']", "pageItemExplorerOrderPriceDesc", "Price (High-Low)");
	opt(
		"#vh-order-by-select option[value='date_added_asc']",
		"pageItemExplorerOrderDateAddedAsc",
		"Date created (Old-New)"
	);
	opt(
		"#vh-order-by-select option[value='date_added_desc']",
		"pageItemExplorerOrderDateAddedDesc",
		"Date created (New-Old)"
	);
	opt(
		"#vh-order-by-select option[value='last_broadcast_asc']",
		"pageItemExplorerOrderLastBroadcastAsc",
		"Date broadcast (Old-New)"
	);
	opt(
		"#vh-order-by-select option[value='last_broadcast_desc']",
		"pageItemExplorerOrderLastBroadcastDesc",
		"Date broadcast (New-Old)"
	);
	opt("#unavailable-select option[value='all']", "pageItemExplorerUnavailableAll", "All");
	opt("#unavailable-select option[value='available']", "pageItemExplorerUnavailableAvailable", "Available");
	opt("#unavailable-select option[value='unavailable']", "pageItemExplorerUnavailableUnavailable", "Unavailable");
	setLabel("filter-match-highlight", "pageItemExplorerFilterMatchHighlight", "Has to match keywords from:");
	setLabel("filter-ignore-hide", "pageItemExplorerFilterIgnoreHide", "Ignore keywords from:");
	if (byId("search-button")) byId("search-button").textContent = m("pageItemExplorerButtonSearch", "Search");
}

function getBroadcastLogMessage(key, fallback, substitutions) {
	return getMessageOrDefault(key, fallback, substitutions);
}

function parseGroupIdsParam(value) {
	if (!value || typeof value !== "string") {
		return [];
	}
	return value
		.split(",")
		.map((id) => id.trim())
		.filter(Boolean);
}

function loadStoredGroupIds(storageKey) {
	try {
		const raw = localStorage.getItem(storageKey);
		if (!raw) {
			return [];
		}
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.filter((id) => typeof id === "string" && id) : [];
	} catch {
		return [];
	}
}

function saveStoredGroupIds(storageKey, groupIds) {
	localStorage.setItem(storageKey, JSON.stringify(groupIds));
}

function getEnabledGroupsOfType(groups, type) {
	return groups.filter((group) => group.enabled !== false && group.type === type);
}

function renderKeywordGroupList(container, groups, type, selectedIds) {
	const selectedSet = new Set(selectedIds);
	container.replaceChildren();

	const enabledGroups = getEnabledGroupsOfType(groups, type);
	if (enabledGroups.length === 0) {
		const empty = document.createElement("div");
		empty.className = "vh-keyword-group-empty";
		empty.textContent = getMessageOrDefault(
			"pageItemExplorerNoKeywordGroupsEnabled",
			"No enabled keyword lists are available for this filter."
		);
		container.appendChild(empty);
		return;
	}

	for (const group of enabledGroups) {
		const label = document.createElement("label");
		label.className = "vh-keyword-group-option";

		const checkbox = document.createElement("input");
		checkbox.type = "checkbox";
		checkbox.value = group.id;
		checkbox.checked = selectedSet.has(group.id);

		const text = document.createElement("span");
		text.textContent = group.name || group.id;

		label.appendChild(checkbox);
		label.appendChild(text);
		container.appendChild(label);
	}
}

function getSelectedGroupIdsFromList(container) {
	return [...container.querySelectorAll('input[type="checkbox"]:checked')].map((input) => input.value);
}

function updateKeywordGroupPanelVisibility() {
	const matchHighlight = document.getElementById("filter-match-highlight").checked;
	const ignoreHide = document.getElementById("filter-ignore-hide").checked;
	document.getElementById("highlight-group-select").hidden = !matchHighlight;
	document.getElementById("hide-group-select").hidden = !ignoreHide;
}

async function initKeywordGroupSelectors(urlParams = null) {
	const groups = await getGroups(Settings);
	const highlightList = document.getElementById("highlight-group-list");
	const hideList = document.getElementById("hide-group-list");

	let highlightIds = loadStoredGroupIds(STORAGE_HIGHLIGHT_GROUP_IDS);
	let hideIds = loadStoredGroupIds(STORAGE_HIDE_GROUP_IDS);

	if (urlParams) {
		const urlHighlight = parseGroupIdsParam(urlParams.get("highlightGroups"));
		const urlHide = parseGroupIdsParam(urlParams.get("hideGroups"));
		if (urlHighlight.length > 0) {
			highlightIds = urlHighlight;
		}
		if (urlHide.length > 0) {
			hideIds = urlHide;
		}
	}

	renderKeywordGroupList(highlightList, groups, "highlight", highlightIds);
	renderKeywordGroupList(hideList, groups, "hide", hideIds);
	updateKeywordGroupPanelVisibility();
}

function persistKeywordGroupSelections() {
	saveStoredGroupIds(
		STORAGE_HIGHLIGHT_GROUP_IDS,
		getSelectedGroupIdsFromList(document.getElementById("highlight-group-list"))
	);
	saveStoredGroupIds(STORAGE_HIDE_GROUP_IDS, getSelectedGroupIdsFromList(document.getElementById("hide-group-list")));
}

function getKeywordGroupIdsForSearch(type) {
	const listId = type === "highlight" ? "highlight-group-list" : "hide-group-list";
	return getSelectedGroupIdsFromList(document.getElementById(listId));
}

async function parseItemExplorerResponse(response) {
	if (response.status === 413) {
		const error = new Error("Payload too large");
		error.errorCode = "payload_too_large";
		throw error;
	}

	const contentType = response.headers.get("content-type") || "";
	if (!contentType.includes("application/json")) {
		const error = new Error(`Unexpected response (${response.status})`);
		error.errorCode = response.status === 413 ? "payload_too_large" : "invalid_response";
		throw error;
	}

	const data = await response.json();
	if (!response.ok) {
		const error = new Error(data.error || "Server error");
		error.errorCode = data.error_code;
		throw error;
	}
	return data;
}

function displayItemExplorerFetchError(error) {
	enableSearch();
	if (error.errorCode === "no_compileable_keywords") {
		displayError(
			getMessageOrDefault(
				"pageItemExplorerNoCompileableKeywords",
				"No highlight keywords could be compiled. Adjust your keywords or disable the filter."
			)
		);
		return;
	}
	if (error.errorCode === "no_keyword_groups_selected") {
		displayError(
			getMessageOrDefault(
				"pageItemExplorerNoKeywordGroupsSelected",
				"Select at least one keyword list for the active filter."
			)
		);
		return;
	}
	if (error.errorCode === "payload_too_large") {
		displayError(
			getMessageOrDefault(
				"pageItemExplorerPayloadTooLarge",
				"The search request is too large. Select fewer keyword lists and try again."
			)
		);
		return;
	}
	displayError(
		getMessageOrDefault("pageItemExplorerRequestFailed", "The search could not be completed. Please try again.") +
			(error.message ? ` (${error.message})` : "")
	);
}

(async () => {
	await Settings.waitForLoad();
	await initLocaleOverride(Settings.get("i18n.localeOverride"));
	window.__VH_GET_MESSAGE__ = getMessageForTemplate;
	applyItemExplorerTranslations();

	//Check if the membership is valid
	if (Settings.isPremiumUser(3) == false) {
		displayError(
			getMessageOrDefault(
				"itemExplorerPremiumRequired",
				"You need to be a tier 3 Patreon subscriber to use this feature."
			)
		);
		return;
	}

	if (Settings.get("general.customCSS")) {
		loadCustomCSS(Settings.get("general.customCSS"));
	}

	const countryCode = Settings.get("general.country");

	if (countryCode != null) {
		i18n.setCountryCode(countryCode);
	}

	const searchBtn = document.getElementById("search-button");

	searchBtn.addEventListener("click", function () {
		if (searchBtn.disabled) {
			return;
		}

		queryDB();
		searchBtn.disabled = true;
	});

	document.getElementById("search-asin").addEventListener("keyup", function (event) {
		//If ENTER is pressed, search
		if (event.key === "Enter") {
			searchBtn.click();
		}
	});
	document.getElementById("search-title").addEventListener("keyup", function (event) {
		if (event.key === "Enter") {
			searchBtn.click();
		}
	});

	document.getElementById("filter-match-highlight").addEventListener("change", updateKeywordGroupPanelVisibility);
	document.getElementById("filter-ignore-hide").addEventListener("change", updateKeywordGroupPanelVisibility);

	const urlParams = window.location.search ? new URLSearchParams(window.location.search) : null;
	await initKeywordGroupSelectors(urlParams);

	if (urlParams) {
		loadFormItemsStateFromURL(urlParams);
	}
})();

function disableSearch() {
	const searchBtn = document.getElementById("search-button");
	searchBtn.disabled = true;
	searchBtn.value = getMessageOrDefault("nmWaitSeconds", `Wait ${secondsLeft}s`, [String(secondsLeft)]);

	let countdownInterval = setInterval(() => {
		secondsLeft--;
		if (secondsLeft <= 0) {
			clearInterval(countdownInterval);
			enableSearch();
		} else {
			searchBtn.value = getMessageOrDefault("nmWaitSeconds", `Wait ${secondsLeft}s`, [String(secondsLeft)]);
		}
	}, 1000);

	const paginationContainerTop = document.getElementById("vh-pagination-top");
	const paginationContainerBottom = document.getElementById("vh-pagination-bottom");
	const links = document.querySelectorAll("ul.a-pagination li a");
	links.forEach((link) => {
		link.addEventListener("click", preventDefault);
		link.style.pointerEvents = "none";
	});
	paginationContainerTop.style.opacity = "0.5";
	paginationContainerBottom.style.opacity = "0.5";
}

function enableSearch() {
	const searchBtn = document.getElementById("search-button");
	searchBtn.disabled = false;
	searchBtn.value = "Search";
	const paginationContainerTop = document.getElementById("vh-pagination-top");
	const paginationContainerBottom = document.getElementById("vh-pagination-bottom");
	paginationContainerTop.style.opacity = "unset";
	paginationContainerBottom.style.opacity = "unset";

	const links = document.querySelectorAll("ul.a-pagination li a");
	links.forEach((link) => {
		link.removeEventListener("click", preventDefault);
		link.style.pointerEvents = "auto";
	});
}
function preventDefault(event) {
	alert("preventDefault");
	event.preventDefault();
	return false;
}

function generateUrl() {
	const asin = document.getElementById("search-asin").value;
	const title = document.getElementById("search-title").value;
	const orderBy = document.getElementById("vh-order-by-select").value;
	const etvMin = document.getElementById("search-etv-min").value;
	const etvMax = document.getElementById("search-etv-max").value;
	const priceMin = document.getElementById("search-price-min").value;
	const priceMax = document.getElementById("search-price-max").value;
	const queue = document.getElementById("vh-queue-select").value;
	const unavailable = document.getElementById("unavailable-select").value;
	const matchHighlight = document.getElementById("filter-match-highlight").checked;
	const ignoreHide = document.getElementById("filter-ignore-hide").checked;
	const highlightGroupIds = getSelectedGroupIdsFromList(document.getElementById("highlight-group-list"));
	const hideGroupIds = getSelectedGroupIdsFromList(document.getElementById("hide-group-list"));
	return (
		"/page/item_explorer.html?asin=" +
		encodeURI(asin) +
		"&title=" +
		encodeURI(title) +
		"&orderBy=" +
		encodeURI(orderBy) +
		"&etvMin=" +
		encodeURI(etvMin) +
		"&etvMax=" +
		encodeURI(etvMax) +
		"&priceMin=" +
		encodeURI(priceMin) +
		"&priceMax=" +
		encodeURI(priceMax) +
		"&queue=" +
		encodeURI(queue) +
		"&unavailable=" +
		encodeURI(unavailable) +
		"&matchHighlight=" +
		encodeURI(matchHighlight ? "true" : "false") +
		"&ignoreHide=" +
		encodeURI(ignoreHide ? "true" : "false") +
		"&highlightGroups=" +
		encodeURI(highlightGroupIds.join(",")) +
		"&hideGroups=" +
		encodeURI(hideGroupIds.join(","))
	);
}

function loadFormItemsStateFromURL(urlParams) {
	const asin = document.getElementById("search-asin");
	const title = document.getElementById("search-title");
	const orderBy = document.getElementById("vh-order-by-select");
	const etvMin = document.getElementById("search-etv-min");
	const etvMax = document.getElementById("search-etv-max");
	const priceMin = document.getElementById("search-price-min");
	const priceMax = document.getElementById("search-price-max");
	const queue = document.getElementById("vh-queue-select");
	const unavailable = document.getElementById("unavailable-select");
	const matchHighlight = document.getElementById("filter-match-highlight");
	const ignoreHide = document.getElementById("filter-ignore-hide");
	asin.value = urlParams.get("asin") || "";
	title.value = urlParams.get("title") || "";
	orderBy.value = urlParams.get("orderBy") || orderBy.value;
	etvMin.value = urlParams.get("etvMin") || "";
	etvMax.value = urlParams.get("etvMax") || "";
	priceMin.value = urlParams.get("priceMin") || "";
	priceMax.value = urlParams.get("priceMax") || "";
	queue.value = urlParams.get("queue") || queue.value;
	unavailable.value = urlParams.get("unavailable") || unavailable.value;
	matchHighlight.checked = urlParams.get("matchHighlight") === "true";
	ignoreHide.checked = urlParams.get("ignoreHide") === "true";
	updateKeywordGroupPanelVisibility();
	queryDB(parseInt(urlParams.get("page"), 10) || 1);
}

async function queryDB(page = 1) {
	const asin = document.getElementById("search-asin").value;
	const title = document.getElementById("search-title").value;
	const orderBy = document.getElementById("vh-order-by-select").value;
	const queue = document.getElementById("vh-queue-select").value;
	const etvMin = document.getElementById("search-etv-min").value;
	const etvMax = document.getElementById("search-etv-max").value;
	const priceMin = document.getElementById("search-price-min").value;
	const priceMax = document.getElementById("search-price-max").value;
	const unavailable = document.getElementById("unavailable-select").value;
	const matchHighlightKeywords = document.getElementById("filter-match-highlight").checked;
	const ignoreHideKeywords = document.getElementById("filter-ignore-hide").checked;

	lastSkippedKeywords = [];
	lastSkippedTooManyVariants = [];

	const content = {
		api_version: 5,
		app_version: env.data.appVersion,
		action: "item_explorer",
		country: i18n.getCountryCode(),
		uuid: Settings.get("general.uuid", false),
		cid: await env.getCID(),
		asin: asin,
		title: title,
		orderBy: orderBy,
		queue: queue,
		page: page,
		etvMin: etvMin,
		etvMax: etvMax,
		priceMin: priceMin,
		priceMax: priceMax,
		unavailable: unavailable,
		matchHighlightKeywords: matchHighlightKeywords,
		ignoreHideKeywords: ignoreHideKeywords,
	};

	if (matchHighlightKeywords || ignoreHideKeywords) {
		const groups = await getGroups(Settings);
		persistKeywordGroupSelections();

		if (matchHighlightKeywords) {
			const highlightGroupIds = getKeywordGroupIdsForSearch("highlight");
			if (highlightGroupIds.length === 0) {
				enableSearch();
				displayItemExplorerFetchError({ errorCode: "no_keyword_groups_selected" });
				return;
			}
			const compiled = compileKeywordGroupsFilter(groups, "highlight", highlightGroupIds);
			lastSkippedKeywords = lastSkippedKeywords.concat(compiled.skipped);
			lastSkippedTooManyVariants = lastSkippedTooManyVariants.concat(compiled.skippedTooManyVariants);
			if (compiled.clauses.length === 0) {
				enableSearch();
				displayError(
					getMessageOrDefault(
						"pageItemExplorerNoCompileableKeywords",
						"No highlight keywords could be compiled. Adjust your keywords or disable the filter."
					)
				);
				return;
			}
			content.highlightKeywordClauses = compiled.clauses;
		}

		if (ignoreHideKeywords) {
			const hideGroupIds = getKeywordGroupIdsForSearch("hide");
			if (hideGroupIds.length === 0) {
				enableSearch();
				displayItemExplorerFetchError({ errorCode: "no_keyword_groups_selected" });
				return;
			}
			const compiled = compileKeywordGroupsFilter(groups, "hide", hideGroupIds);
			lastSkippedKeywords = lastSkippedKeywords.concat(compiled.skipped);
			lastSkippedTooManyVariants = lastSkippedTooManyVariants.concat(compiled.skippedTooManyVariants);
			if (compiled.clauses.length > 0) {
				content.hideKeywordClauses = compiled.clauses;
			}
		}
	}

	lastSkippedKeywords = [...new Set(lastSkippedKeywords)];
	lastSkippedTooManyVariants = [...new Set(lastSkippedTooManyVariants)];

	const s = await cryptoKeys.signData(content);
	content.s = s;
	content.pk = await cryptoKeys.getExportedPublicKey();

	const requestBody = JSON.stringify(content);
	if (requestBody.length > MAX_REQUEST_BODY_BYTES) {
		enableSearch();
		displayItemExplorerFetchError({ errorCode: "payload_too_large" });
		return;
	}

	fetch(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: requestBody,
	})
		.then((response) => parseItemExplorerResponse(response))
		.then(serverProductsResponse)
		.catch(displayItemExplorerFetchError);
}
function openSeeDetails(item) {
	if (!(item instanceof Item)) {
		throw new Error("item is not an instance of Item");
	}

	window.open(item.getVHOpenModalURL(WITH_VARIANT), "_blank");
}
async function serverProductsResponse(data) {
	if (data["invalid_uuid"] == true) {
		displayError("Invalid UUID or Patreon subscription insufficient.");
		await env.recoverFromInvalidUuid();
		//Do no complete this execution
		return false;
	}
	const container = document.getElementById("vh-item-explorer-content");
	container.replaceChildren();

	if (lastSkippedTooManyVariants.length > 0) {
		const warning = document.createElement("div");
		warning.className = "notice notice-warning";
		warning.textContent = getMessageOrDefault(
			"pageItemExplorerKeywordsTooManyVariants",
			"The following keywords generated too many variants and will be ignored: $1$",
			[lastSkippedTooManyVariants.join(", ")]
		);
		container.appendChild(warning);
	}

	if (lastSkippedKeywords.length > 0) {
		const warning = document.createElement("div");
		warning.className = "notice notice-warning";
		warning.textContent = getMessageOrDefault(
			"pageItemExplorerKeywordsTooComplex",
			"The following keywords are too complex to be compiled and will be ignored: $1$",
			[lastSkippedKeywords.join(", ")]
		);
		container.appendChild(warning);
	}

	const stats = document.createElement("div");
	stats.id = "vh-item-explorer-stats";
	stats.className = "vh-query-stats";
	stats.textContent = `Query time: ${data.query_time}ms - Result(s): ${data.total_items}`;
	container.appendChild(stats);

	secondsLeft = parseInt(data.wait_time);

	// Load and render table header template
	const headerTemplate = await Tpl.loadFile("scripts/ui/templates/item_explorer_table_header.html");
	Tpl.clearVariables();
	// First render the template to replace variables (if any)
	const renderedHeaderHTML = Tpl.render(headerTemplate, false);
	// Wrap in table structure for proper DOMParser parsing of <thead> elements
	const wrappedHeaderHTML = `<table>${renderedHeaderHTML}</table>`;
	const parser = new DOMParser();
	const headerDoc = parser.parseFromString(wrappedHeaderHTML, "text/html");
	const theadElement = headerDoc.querySelector("thead");

	const table = document.createElement("table");
	table.id = "vh-item-table";
	if (theadElement) {
		table.appendChild(theadElement);
	} else {
		console.error("Failed to render header template. Rendered HTML:", renderedHeaderHTML);
		// Fallback: create a basic header structure
		const fallbackThead = document.createElement("thead");
		table.appendChild(fallbackThead);
	}
	container.appendChild(table);
	const paginationContainerTop = document.getElementById("vh-pagination-top");
	const paginationContainerBottom = document.getElementById("vh-pagination-bottom");

	// Load row template once
	const rowTemplate = await Tpl.loadFile("scripts/ui/templates/item_explorer_table_row.html");

	if (data["items"] == null || data["items"].length == 0) {
		const tbody = document.createElement("tbody");
		const row = document.createElement("tr");
		const cell = document.createElement("td");
		cell.setAttribute("colspan", "10");
		cell.className = "vh-empty-state";
		cell.textContent = "No items found";
		row.appendChild(cell);
		tbody.appendChild(row);
		table.appendChild(tbody);

		paginationContainerTop.replaceChildren();
		paginationContainerBottom.replaceChildren();
		disableSearch();
		return;
	}

	// Create tbody for rows
	const tbody = document.createElement("tbody");

	for (const [key, values] of Object.entries(data["items"])) {
		// Unescape title (it comes double-encoded from API)
		const decodedTitle = unescapeHTML(unescapeHTML(values.title || ""));

		// Determine search URL
		let searchUrl;
		if (
			Settings.get("general.searchOpenModal") &&
			values.is_parent_asin != null &&
			values.enrollment_guid != null &&
			values.queue != "potluck"
		) {
			const item = new Item({
				asin: key,
				queue: values.queue,
				is_parent_asin: values.is_parent_asin,
				is_pre_release: values.is_pre_release,
				enrollment_guid: values.enrollment_guid,
			});
			searchUrl = item.getVHOpenModalURL();
		} else {
			let truncatedTitle =
				decodedTitle.length > 40 ? decodedTitle.substr(0, 40).split(" ").slice(0, -1).join(" ") : decodedTitle;
			truncatedTitle = removeSpecialHTML(truncatedTitle);
			truncatedTitle = truncatedTitle
				.split(" ")
				.filter((word) => word.length > 1)
				.join(" ");
			const search_url_slug = encodeURIComponent(truncatedTitle);
			searchUrl = `https://www.amazon.${i18n.getDomainTLD()}/vine/vine-items?search=${search_url_slug}`;
		}

		// Set template variables (escape HTML for XSS prevention)
		Tpl.clearVariables();
		Tpl.setVar("asin", escapeHTML(values.asin || ""));
		Tpl.setVar("queue", escapeHTML(values.queue || ""));
		Tpl.setVar("is_parent_asin", values.is_parent_asin ? "true" : "false");
		Tpl.setVar("enrollment_guid", escapeHTML(values.enrollment_guid || ""));
		Tpl.setVar("title", escapeHTML(decodedTitle));
		Tpl.setVar("img_url", escapeHTML(values.img_url || ""));
		Tpl.setVar("search_url", escapeHTML(searchUrl || ""));
		Tpl.setVar("domain", i18n.getDomainTLD());
		Tpl.setVar("etv", values.etv == null ? "N/A" : escapeHTML(String(values.etv)));
		Tpl.setVar("price", values.price == null ? "N/A" : escapeHTML(String(values.price)));
		Tpl.setVar("queue_abbr", escapeHTML(queueToAbbr(values.queue) || ""));
		Tpl.setVar("order_success", String(values.order_success || 0));
		Tpl.setVar("order_failed", String(values.order_failed || 0));

		// Format date_added: split date and time
		const dateAddedFormatted = ISODatetoYMDHiS(values.date_added);
		if (dateAddedFormatted) {
			const [datePart, timePart] = dateAddedFormatted.split(" ");
			Tpl.setVar("date_added_date", escapeHTML(datePart || ""));
			Tpl.setVar("date_added_time", escapeHTML(timePart || ""));
		} else {
			Tpl.setVar("date_added_date", "");
			Tpl.setVar("date_added_time", "");
		}

		// Format last_broadcast: split date and time
		if (values.last_broadcast == null) {
			Tpl.setVar("last_broadcast_date", "never");
			Tpl.setVar("last_broadcast_time", "");
			Tpl.setIf("has_last_broadcast_time", false);
			Tpl.setIf("has_last_broadcast", false);
		} else {
			const lastBroadcastFormatted = ISODatetoYMDHiS(values.last_broadcast);
			if (lastBroadcastFormatted) {
				const [datePart, timePart] = lastBroadcastFormatted.split(" ");
				Tpl.setVar("last_broadcast_date", escapeHTML(datePart || ""));
				Tpl.setVar("last_broadcast_time", escapeHTML(timePart || ""));
				Tpl.setIf("has_last_broadcast_time", true);
				Tpl.setIf("has_last_broadcast", true);
			} else {
				Tpl.setVar("last_broadcast_date", "");
				Tpl.setVar("last_broadcast_time", "");
				Tpl.setIf("has_last_broadcast_time", false);
				Tpl.setIf("has_last_broadcast", false);
			}
		}

		Tpl.setVar("is_pre_release", values.is_pre_release ? "true" : "false");

		// Set conditional variables
		Tpl.setIf("is_parent_asin", values.is_parent_asin);
		Tpl.setIf("is_potluck", values.queue == "potluck");
		Tpl.setIf("show_pin", Settings.get("pinnedTab.active") && values.queue != "potluck");
		Tpl.setIf("show_details_link", values.queue !== "potluck");
		Tpl.setIf("unavailable", values.unavailable);

		// Render row template
		// First render the template to replace variables
		const renderedHTML = Tpl.render(rowTemplate, false);
		// Wrap in table structure for proper DOMParser parsing of <tr> elements
		const wrappedHTML = `<table><tbody>${renderedHTML}</tbody></table>`;
		const parser = new DOMParser();
		const doc = parser.parseFromString(wrappedHTML, "text/html");
		const rowElement = doc.querySelector("tr");
		if (rowElement) {
			tbody.appendChild(rowElement);
		} else {
			console.error("Failed to render row template for ASIN:", values.asin, "Rendered HTML:", renderedHTML);
		}
	}

	table.appendChild(tbody);

	paginationContainerTop.replaceChildren();
	paginationContainerBottom.replaceChildren();
	paginationContainerTop.appendChild(
		pagination.generatePagination(generateUrl(), data["total_items"], 50, data["page"], true)
	);
	paginationContainerBottom.appendChild(
		pagination.generatePagination(generateUrl(), data["total_items"], 50, data["page"], true)
	);

	//Add pinned item listerner
	if (Settings.get("pinnedTab.active")) {
		const pinnedItems = document.querySelectorAll(".vh-icon-pin");
		pinnedItems.forEach((pinIcon) => {
			pinIcon.addEventListener("click", () => {
				const coreAttributes = {
					asin: pinIcon.getAttribute("data-asin"),
					queue: pinIcon.getAttribute("data-queue"),
					is_parent_asin: pinIcon.getAttribute("data-is-parent-asin"),
					is_pre_release: pinIcon.getAttribute("data-is-pre-release"),
					enrollment_guid: pinIcon.getAttribute("data-enrollment-guid"),
				};
				const item = new Item(coreAttributes);
				item.setTitle(pinIcon.getAttribute("data-title"));
				item.setImgUrl(pinIcon.getAttribute("data-thumbnail"));

				PinnedList.addItem(item);

				pinIcon.style.opacity = "0.4";
			});
		});
	}

	//Add event listener to the see details link
	const seeDetails = document.querySelectorAll(".open-see-details");
	seeDetails.forEach((itemDOM) => {
		itemDOM.addEventListener("click", (event) => {
			event.preventDefault();
			event.stopPropagation();
			const item = new Item({
				asin: itemDOM.getAttribute("data-asin"),
				queue: itemDOM.getAttribute("data-queue"),
				is_parent_asin: itemDOM.getAttribute("data-is-parent-asin"),
				is_pre_release: itemDOM.getAttribute("data-is-pre-release"),
				enrollment_guid: itemDOM.getAttribute("data-enrollment-guid"),
			});
			openSeeDetails(item);
		});
	});

	//Add event listener to the last broadcast cells
	const lastBroadcastCells = document.querySelectorAll(".vh-last-broadcast-clickable");
	lastBroadcastCells.forEach((cell) => {
		cell.addEventListener("click", (event) => {
			event.preventDefault();
			event.stopPropagation();
			const asin = cell.getAttribute("data-asin");
			if (asin) {
				openBroadcastLog(asin);
			}
		});
	});

	// Load variant row template once (outside the event handler for efficiency)
	const variantRowTemplate = await Tpl.loadFile("scripts/ui/templates/item_explorer_table_variant_row.html");

	//Add event listener to the load variants link
	const loadVariants = document.querySelectorAll(".load-variants");
	loadVariants.forEach((itemDOM) => {
		itemDOM.addEventListener("click", async (event) => {
			event.preventDefault();
			event.stopPropagation();
			const tr = itemDOM.closest("tr");
			if (!tr) {
				console.error("Could not find parent tr element for load variants");
				return;
			}
			const asin = itemDOM.getAttribute("data-asin");

			//Delete the link
			itemDOM.remove();

			//Query the API for the variants
			const content = {
				api_version: 5,
				version: env.data.appVersion,
				action: "item_explorer_variants",
				country: i18n.getCountryCode(),
				uuid: Settings.get("general.uuid", false),
				cid: await env.getCID(),
				asin: asin,
			};
			const s = await cryptoKeys.signData(content);
			content.s = s;
			content.pk = await cryptoKeys.getExportedPublicKey();
			fetch(env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			})
				.then(async (response) => {
					const data = await response.json();
					if (!response.ok) {
						throw new Error(data.error || "Server error");
					}
					return data;
				})
				.then(async (data) => {
					//Delete all pre-existing variant rows for that asin
					const variantRows = document.querySelectorAll(`.variant-row-${asin}`);
					variantRows.forEach((row) => {
						row.remove();
					});

					//Sort the variants by title
					data.variants.sort((a, b) => a.title.localeCompare(b.title));

					if (data.variants.length === 0) {
						const noVariantsRow = document.createElement("tr");
						const noVariantsCell = document.createElement("td");
						noVariantsCell.setAttribute("colspan", "10");
						noVariantsCell.className = "vh-empty-state";
						noVariantsCell.textContent = "Variant(s) not discovered yet.";
						noVariantsRow.appendChild(noVariantsCell);
						tr.insertAdjacentElement("afterend", noVariantsRow);
					} else {
						//Create the new rows using template
						for (const variant of data.variants) {
							// Format title - try to parse as JSON for user-friendly display
							let titleDisplay = variant.title;
							try {
								const json = JSON.parse(variant.title);
								const parts = [];
								for (const key in json) {
									parts.push(`${key}: ${json[key]}`);
								}
								titleDisplay = parts.join(" • ");
							} catch (e) {
								// Not JSON, use as-is
								titleDisplay = variant.title;
							}

							// Set template variables
							Tpl.clearVariables();
							Tpl.setVar("parent_asin", escapeHTML(asin));
							Tpl.setVar("asin", escapeHTML(variant.asin));
							Tpl.setVar("domain", i18n.getDomainTLD());
							Tpl.setVar("title_display", escapeHTML(titleDisplay));
							Tpl.setVar("etv", variant.etv == null ? "N/A" : escapeHTML(String(variant.etv)));
							Tpl.setVar("queue", escapeHTML(tr.getAttribute("data-queue") || ""));
							Tpl.setVar("enrollment_guid", escapeHTML(tr.getAttribute("data-enrollment-guid") || ""));
							Tpl.setIf("show_details_link", tr.getAttribute("data-queue") !== "potluck");

							// Render variant row template
							const renderedVariantHTML = Tpl.render(variantRowTemplate, false);
							const wrappedVariantHTML = `<table><tbody>${renderedVariantHTML}</tbody></table>`;
							const variantParser = new DOMParser();
							const variantDoc = variantParser.parseFromString(wrappedVariantHTML, "text/html");
							const variantRowElement = variantDoc.querySelector("tr");

							if (variantRowElement) {
								tr.insertAdjacentElement("afterend", variantRowElement);
							} else {
								console.error("Failed to render variant row template for ASIN:", variant.asin);
							}
						}

						//Add event listener to the see details links
						const seeDetailsVariants = document.querySelectorAll(".open-variant-see-details");
						seeDetailsVariants.forEach((itemDOM) => {
							itemDOM.addEventListener("click", (event) => {
								event.preventDefault();
								event.stopPropagation();
								const item = new Item({
									asin: itemDOM.getAttribute("data-asin"),
									queue: itemDOM.getAttribute("data-queue"),
									is_parent_asin: itemDOM.getAttribute("data-is-parent-asin"),
									is_pre_release: "false",
									enrollment_guid: itemDOM.getAttribute("data-enrollment-guid"),
									variant_asin: itemDOM.getAttribute("data-variant-asin"),
								});
								openSeeDetails(item);
							});
						});
					}
				});
		});
	});

	disableSearch();
}

function displayError(message) {
	const container = document.getElementById("vh-item-explorer-content");
	// Clear existing content safely
	container.replaceChildren();

	// Create new elements safely
	const div = document.createElement("div");
	div.className = "notice";
	div.textContent = message;
	container.appendChild(div);
}

function buildBroadcastLogTableHtml(broadcasts) {
	const typeHeader = getBroadcastLogMessage("pageItemExplorerBroadcastLogType", "Type");
	const timeHeader = getBroadcastLogMessage("pageItemExplorerBroadcastLogTime", "Broadcast time");
	const detailsHeader = getBroadcastLogMessage("pageItemExplorerBroadcastLogDetails", "Details");

	const rows = broadcasts
		.map((broadcast) => {
			const formattedTime = ISODatetoYMDHiS(broadcast.created_at) || "";
			return `<tr>
				<td>${escapeHTML(broadcast.type || "")}</td>
				<td class="vh-broadcast-log-time">${escapeHTML(formattedTime)}</td>
				<td>${escapeHTML(broadcast.reason || "")}</td>
			</tr>`;
		})
		.join("");

	return `<table class="vh-broadcast-log-table">
		<thead>
			<tr>
				<th>${escapeHTML(typeHeader)}</th>
				<th>${escapeHTML(timeHeader)}</th>
				<th>${escapeHTML(detailsHeader)}</th>
			</tr>
		</thead>
		<tbody>${rows}</tbody>
	</table>`;
}

async function openBroadcastLog(asin) {
	const modalId = `broadcast-log-${asin}`;
	modalMgr.closeModal(modalId);

	const modal = modalMgr.newModal(modalId);
	modal.title = getBroadcastLogMessage("pageItemExplorerBroadcastLogTitle", "Broadcast history for $1$", [asin]);
	modal.content = `<div class="vh-broadcast-log-loading">${escapeHTML(
		getBroadcastLogMessage("pageItemExplorerBroadcastLogLoading", "Loading broadcast history...")
	)}</div>`;
	modal.style = "min-width: 520px; max-width: 95vw; width: min(900px, 95vw);";
	await modal.show();

	try {
		const content = {
			api_version: 5,
			app_version: env.data.appVersion,
			action: "item_explorer_broadcast_log",
			country: i18n.getCountryCode(),
			uuid: Settings.get("general.uuid", false),
			cid: await env.getCID(),
			asin: asin,
		};
		const s = await cryptoKeys.signData(content);
		content.s = s;
		content.pk = await cryptoKeys.getExportedPublicKey();

		const response = await fetch(env.getAPIUrl(), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		});
		const data = await response.json();
		if (!response.ok) {
			throw new Error(data.error || "Server error");
		}

		const modalContent = document.querySelector(`#modal-${modalId} .content`);
		if (!modalContent) {
			return;
		}

		if (!data.broadcasts || data.broadcasts.length === 0) {
			modalContent.textContent = getBroadcastLogMessage(
				"pageItemExplorerBroadcastLogEmpty",
				"No broadcasts found for this item."
			);
			return;
		}

		modalContent.innerHTML = buildBroadcastLogTableHtml(data.broadcasts);
	} catch (error) {
		const modalContent = document.querySelector(`#modal-${modalId} .content`);
		if (modalContent) {
			modalContent.textContent =
				error.message ||
				getBroadcastLogMessage("pageItemExplorerBroadcastLogError", "Failed to load broadcast history.");
		}
	}
}

function queueToAbbr(queue) {
	const arr = {
		potluck: "RFY",
		encore: "AI",
		last_chance: "AFA",
		all_items: "ALL",
	};

	return arr[queue];
}
