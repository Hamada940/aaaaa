import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import {
	Internationalization,
	initLocaleOverride,
	getMessageForTemplate,
} from "/scripts/core/services/Internationalization.js";
const i18n = new Internationalization();

import { Template } from "/scripts/core/utils/Template.js";
var Tpl = new Template();

import { isSafari } from "/scripts/core/utils/BrowserDetection.js";
import { isGarishThemeAvailable } from "/scripts/core/utils/DateHelper.js";
import { getMinutesUsed } from "/scripts/core/utils/MetricStorage.js";
import { BUILD_NUMBER } from "/scripts/build_info.js";

import { initiateSettings, ensureCheckoutTabBound, loadUserContributionStats } from "/page/settings_loadsave.js";

//If browser is firefox, load icon_firefox.css
if (navigator.userAgent.includes("Firefox")) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_firefox.css";
	document.head.appendChild(link);
}
//If the browser is chrome, load icon_chrome.css
if (navigator.userAgent.includes("Chrome") || navigator.userAgent.includes("Chromium")) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_chrome.css";
	document.head.appendChild(link);
}
if (navigator.userAgent.includes("Safari")) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_ios.css";
	document.head.appendChild(link);
}

function loadStyleSheetContent(content, path = "injected") {
	if (content != "") {
		const style = document.createElement("style");
		style.textContent = "/*" + path + "*/\n" + content;
		document.head.appendChild(style);
	}
}

function loadCustomCSS(content) {
	const styleId = "vh-custom-css";
	let style = document.getElementById(styleId);
	if (!style) {
		style = document.createElement("style");
		style.id = styleId;
		document.head.appendChild(style);
	}
	style.textContent = content ? `/*general.customCSS*/\n${content}` : "";
}

//Render the main layout
(async () => {
	// Clear template cache and variables when opening settings
	await Tpl.flushLocalStorage();

	// Check if we're in popup mode
	const isPopupView = window.popupView === true;

	// Load the appropriate template based on view mode
	const promMainTpl = isPopupView
		? await Tpl.loadFile("/page/settings_popup.tpl.html", true)
		: await Tpl.loadFile("/page/settings_main.tpl.html", true);

	// Only load tab templates if not in popup mode
	let promTab1,
		promTab2,
		promTab3,
		promTab4,
		promTab5,
		promTab6,
		promTab7,
		promTab8,
		promTab9,
		promTab10,
		promTab11,
		promTab12,
		promTab13,
		promTab14,
		promTab15,
		promTab16,
		promTab17;
	if (!isPopupView) {
		promTab1 = await Tpl.loadFile("/page/settings_general.tpl.html", true);
		promTab15 = await Tpl.loadFile("/page/settings_locale.tpl.html", true);
		promTab2 = await Tpl.loadFile("/page/settings_notifications.tpl.html", true);
		promTab3 = await Tpl.loadFile("/page/settings_system.tpl.html", true);
		promTab4 = await Tpl.loadFile("/page/settings_styles.tpl.html", true);
		promTab5 = await Tpl.loadFile("/page/settings_discord.tpl.html", true);
		promTab11 = await Tpl.loadFile("/page/settings_webhooks.tpl.html", true);
		promTab6 = await Tpl.loadFile("/page/settings_keywords.tpl.html", true);
		promTab7 = await Tpl.loadFile("/page/settings_keybindings.tpl.html", true);
		promTab8 = await Tpl.loadFile("/page/settings_premium.tpl.html", true);
		promTab9 = await Tpl.loadFile("/page/settings_debug.tpl.html", true);
		promTab10 = await Tpl.loadFile("/page/settings_about.tpl.html", true);
		promTab12 = await Tpl.loadFile("/page/settings_server.tpl.html", true);
		promTab13 = await Tpl.loadFile("/page/settings_checkout.tpl.html", true);
		promTab14 = await Tpl.loadFile("/page/settings_themes.tpl.html", true);
		promTab16 = await Tpl.loadFile("/page/settings_review.tpl.html", true);
		promTab17 = await Tpl.loadFile("/page/settings_account.tpl.html", true);
	}

	// Must load settings and apply locale override before any Tpl.render() so __MSG_ placeholders use the chosen language
	await Settings.waitForLoad();
	await initLocaleOverride(Settings.get("i18n.localeOverride"));
	window.__VH_GET_MESSAGE__ = getMessageForTemplate;

	// Clear any existing template variables before setting new ones
	Tpl.clearVariables();
	// Set Safari detection before loading premium template so it can be used within the template
	Tpl.setIf("isSafari", isSafari());
	Tpl.setVar("APP_VERSION", getAppVersion());
	Tpl.setVar("APP_BUILD", String(BUILD_NUMBER));

	let domainTLD = "";
	const countryCode = Settings.get("general.country");
	if (countryCode != null) {
		i18n.setCountryCode(countryCode);
		domainTLD = i18n.getDomainTLD();
	}
	Tpl.setIf("country_known", countryCode != null);
	Tpl.setVar("monitor_link", "https://www.amazon." + domainTLD + "/vine/vine-items?queue=encore#monitor");
	Tpl.setVar("light_monitor_link", chrome.runtime.getURL("page/notification_monitor_light.html"));
	Tpl.setVar("v4_monitor_link", "https://www.amazon." + domainTLD + "/vine/resources#vh-monitor");
	Tpl.setVar("v4_monitor_extension_link", chrome.runtime.getURL("page/notification_monitor_v4.html"));
	Tpl.setVar("item_explorer_link", chrome.runtime.getURL("page/item_explorer.html"));
	Tpl.setIf("tier_3", Settings.isPremiumUser(3));

	// Only set tab variables if not in popup mode
	if (!isPopupView) {
		Tpl.setVar("TAB1", Tpl.render(promTab1));
		Tpl.setVar("TAB15", Tpl.render(promTab15));
		Tpl.setVar("TAB2", Tpl.render(promTab2));
		Tpl.setVar("TAB3", Tpl.render(promTab3));
		Tpl.setVar("TAB4", Tpl.render(promTab4));
		Tpl.setVar("TAB5", Tpl.render(promTab5));
		Tpl.setVar("TAB11", Tpl.render(promTab11));
		Tpl.setVar("TAB6", Tpl.render(promTab6));
		Tpl.setVar("TAB7", Tpl.render(promTab7));
		Tpl.setVar("TAB8", Tpl.render(promTab8));
		Tpl.setVar("TAB9", Tpl.render(promTab9));
		Tpl.setVar("TAB10", Tpl.render(promTab10));
		Tpl.setVar("TAB12", Tpl.render(promTab12));
		Tpl.setVar("TAB13", Tpl.render(promTab13));
		Tpl.setVar("TAB14", Tpl.render(promTab14));
		Tpl.setVar("TAB16", Tpl.render(promTab16));
		Tpl.setVar("TAB17", Tpl.render(promTab17));
	}

	// Set translated page title (Chrome does not substitute __MSG_ in static HTML for extension pages)
	const titleMsg = getMessageForTemplate("pageSettingsHtmlTitle");
	document.title = titleMsg || document.title;

	//Load the custom CSS if the user is a premium user
	if (Settings.get("general.customCSS")) {
		loadCustomCSS(Settings.get("general.customCSS"));
	}

	document.body.replaceChildren();
	const mainContent = Tpl.render(promMainTpl, true);
	document.body.appendChild(mainContent);

	if (isPopupView) {
		document.body.classList.add("vh-popup");
		applyThemeFromSettings();
	}

	// Set up the settings link (needed for both popup and full settings view)
	const settingsLink = document.getElementById("settingsLink");
	if (settingsLink) {
		settingsLink.href = chrome.runtime.getURL("page/settings.html");
	}

	// For popup mode, only update usage stats (no need to load settings_loadsave.js)
	if (isPopupView && countryCode != null) {
		updatePopupUsageStats();
	}

	// For full settings view, load and initialize all settings
	if (!isPopupView && countryCode != null) {
		initiateSettings(true); //page/settings_loadsave.js, initialize the loading and saving code for the page

		initTabs();
		applyThemeFromSettings();
		initThemes();
		initCollapsibleFieldsets(); // Initialize collapsible fieldsets
		initMemoryDebugging(); // Initialize memory debugging controls
		initTileCounterDebugging(); // Initialize TileCounter debugging controls
		initSettingTooltips(); // Initialize tooltips for (?) icons
		initPremiumTooltips(); // Initialize tooltips for premium tier icons
		initSidebarScrollBehavior(); // Initialize sidebar scroll behavior
	}
})();

// Simple function to update usage stats in popup mode (without loading settings_loadsave.js)
async function updatePopupUsageStats() {
	await Settings.waitForLoad();
	const minutesUsed = await getMinutesUsed(Settings);
	const days = Math.floor(minutesUsed / 1440);
	const hours = Math.floor((minutesUsed % 1440) / 60);
	const minutes = minutesUsed % 60;

	const popupDaysElement = document.getElementById("popupUsageDays");
	const popupHoursElement = document.getElementById("popupUsageHours");
	const popupMinutesElement = document.getElementById("popupUsageMinutes");
	if (popupDaysElement) {
		popupDaysElement.textContent = days;
	}
	if (popupHoursElement) {
		popupHoursElement.textContent = hours;
	}
	if (popupMinutesElement) {
		popupMinutesElement.textContent = minutes;
	}
}

// Memory Debugging Functions
function initMemoryDebugging() {
	// Check if memory debugging is enabled
	const debugMemoryCheckbox = document.querySelector('input[name="general.debugMemory"]');
	const memoryDebugControls = document.getElementById("memoryDebugControls");

	if (!debugMemoryCheckbox || !memoryDebugControls) return;

	// Show/hide controls based on checkbox state
	function updateMemoryDebugVisibility() {
		memoryDebugControls.style.display = debugMemoryCheckbox.checked ? "block" : "none";
	}

	// Initial visibility
	updateMemoryDebugVisibility();

	// Listen for changes
	debugMemoryCheckbox.addEventListener("change", updateMemoryDebugVisibility);

	// Memory debug log
	const logElement = document.getElementById("memoryDebugLog");
	let logContent = [];

	function addToLog(message, type = "info") {
		const timestamp = new Date().toLocaleTimeString("en-US", {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hour12: false,
		});

		// Use icons/symbols for different types
		const typeSymbol = type === "error" ? "❌" : type === "success" ? "✅" : "ℹ️";

		// Format message more compactly - all on one line
		const logEntry = `${timestamp} - ${typeSymbol} - ${message}`;

		logContent.push(logEntry);

		// Keep only last 50 entries for dropdown view
		if (logContent.length > 50) {
			logContent.shift();
		}

		logElement.replaceChildren();
		logContent.forEach((entry) => {
			const div = document.createElement("div");
			div.textContent = entry;
			logElement.appendChild(div);
		});
		logElement.scrollTop = logElement.scrollHeight;
	}

	// Clear log button
	document.getElementById("clearLogBtn")?.addEventListener("click", () => {
		logContent = [];
		logElement.replaceChildren();
		const div = document.createElement("div");
		div.style.color = "#888";
		div.style.fontStyle = "italic";
		div.textContent = "Memory debugging log cleared.";
		logElement.appendChild(div);
		addToLog("Log cleared", "info");
	});

	// Copy log button
	document.getElementById("copyLogBtn")?.addEventListener("click", async () => {
		try {
			// Extract text content from log entries
			const logText = logContent
				.map((entry) => {
					// Parse the HTML to extract text
					const tempDiv = document.createElement("div");
					tempDiv.textContent = entry;
					return tempDiv.textContent || tempDiv.innerText || "";
				})
				.join("\n");

			// Copy to clipboard
			await navigator.clipboard.writeText(logText);

			// Show success feedback
			const copyBtn = document.getElementById("copyLogBtn");
			const originalText = copyBtn.textContent;
			copyBtn.textContent = "✓";
			copyBtn.style.background = "#d4edda";

			setTimeout(() => {
				copyBtn.textContent = originalText;
				copyBtn.style.background = "#f0f0f0";
			}, 1500);

			addToLog("Log copied to clipboard", "success");
		} catch (error) {
			console.error("Failed to copy log:", error);
			addToLog("Failed to copy log: " + error.message, "error");
		}
	});

	// Memory debugging API communication
	async function sendMemoryCommand(command, params = {}) {
		try {
			// Send message to all tabs to execute memory debugging command
			const tabs = await chrome.tabs.query({});
			const vineTab = tabs.find((tab) => tab.url && tab.url.includes("amazon.") && tab.url.includes("/vine/"));

			if (!vineTab) {
				addToLog("No Vine tab found. Please open a Vine page first.", "error");
				return null;
			}

			return new Promise((resolve) => {
				chrome.tabs.sendMessage(
					vineTab.id,
					{
						type: "MEMORY_DEBUG_COMMAND",
						command: command,
						params: params,
					},
					(response) => {
						if (chrome.runtime.lastError) {
							addToLog(`Error: ${chrome.runtime.lastError.message}`, "error");
							resolve(null);
						} else {
							resolve(response);
						}
					}
				);
			});
		} catch (error) {
			addToLog(`Error: ${error.message}`, "error");
			return null;
		}
	}

	// Take snapshot button
	document.getElementById("takeSnapshotBtn")?.addEventListener("click", async () => {
		const snapshotNameInput = document.getElementById("snapshotName");
		const snapshotName = snapshotNameInput.value.trim() || `snap-${Date.now()}`;

		// Disable button during operation
		const btn = document.getElementById("takeSnapshotBtn");
		btn.disabled = true;
		btn.textContent = "Taking...";

		addToLog(`Taking snapshot: ${snapshotName}`);

		const result = await sendMemoryCommand("takeSnapshot", { name: snapshotName });
		if (result && result.success) {
			addToLog(`Snapshot saved: ${snapshotName}`, "success");
			snapshotNameInput.value = ""; // Clear input after success
		} else {
			addToLog(`Snapshot failed: ${result?.error || "Unknown error"}`, "error");
		}

		// Re-enable button
		btn.disabled = false;
		btn.textContent = "Take Snapshot";
	});

	// Generate report button
	document.getElementById("generateReportBtn")?.addEventListener("click", async () => {
		addToLog("Generating memory report...");

		const result = await sendMemoryCommand("generateReport");
		if (result && result.success) {
			addToLog("Memory report generated:", "success");
			addToLog(JSON.stringify(result.data, null, 2));
		} else {
			addToLog(`Failed to generate report: ${result?.error || "Unknown error"}`, "error");
		}
	});

	// Detect leaks button
	document.getElementById("detectLeaksBtn")?.addEventListener("click", async () => {
		addToLog("Detecting memory leaks...");

		const result = await sendMemoryCommand("detectLeaks");
		if (result && result.success) {
			const leaks = result.data;

			// Compact summary
			const hasIssues = leaks.notificationMonitors > 1 || leaks.detachedNodes > 100;
			addToLog("Leak detection complete", hasIssues ? "error" : "success");

			// Only show problematic values
			if (leaks.notificationMonitors > 1) {
				addToLog(`⚠️ Monitors: ${leaks.notificationMonitors} (should be 1)`, "error");
			}
			if (leaks.detachedNodes > 100) {
				addToLog(`⚠️ Detached nodes: ${leaks.detachedNodes}`, "error");
			}
			if (leaks.keywordMatchInstances > 50) {
				addToLog(`⚠️ Keywords: ${leaks.keywordMatchInstances}`, "error");
			}

			// Show summary if no issues
			if (!hasIssues) {
				addToLog(`✓ No memory leaks detected`, "success");
			}
		} else {
			addToLog(`Leak detection failed`, "error");
		}
	});

	// Check detached nodes button
	document.getElementById("checkDetachedBtn")?.addEventListener("click", async () => {
		addToLog("Checking for detached DOM nodes...");

		const result = await sendMemoryCommand("checkDetachedNodes");
		if (result && result.success) {
			const detached = result.data;
			addToLog(`Found ${detached.length} detached nodes`, detached.length > 0 ? "error" : "success");
			if (detached.length > 0 && detached.length <= 10) {
				detached.forEach((node, i) => {
					addToLog(`  ${i + 1}. ${node}`);
				});
			}
		} else {
			addToLog(`Failed to check detached nodes: ${result?.error || "Unknown error"}`, "error");
		}
	});

	// Cleanup button
	document.getElementById("cleanupBtn")?.addEventListener("click", async () => {
		addToLog("Running memory cleanup...");

		const result = await sendMemoryCommand("cleanup");
		if (result && result.success) {
			const cleaned = result.data;
			addToLog(`Cleanup completed! Cleaned ${cleaned.length} items`, "success");
			cleaned.forEach((item) => {
				addToLog(`  - ${item}`);
			});
		} else {
			addToLog(`Failed to run cleanup: ${result?.error || "Unknown error"}`, "error");
		}
	});
}

// TileCounter Debugging Functions
function initTileCounterDebugging() {
	// Check if TileCounter debugging is enabled
	const debugTileCounterCheckbox = document.querySelector('input[name="general.debugTileCounter"]');
	const tileCounterDebugControls = document.getElementById("tileCounterDebugControls");

	if (!debugTileCounterCheckbox || !tileCounterDebugControls) return;

	// Track if this is the first time enabling
	let hasShownReloadNotice = false;

	// Show/hide controls based on checkbox state
	function updateTileCounterDebugVisibility() {
		const isEnabled = debugTileCounterCheckbox.checked;
		tileCounterDebugControls.style.display = isEnabled ? "block" : "none";

		// Show a one-time notice when first enabled
		if (isEnabled && !hasShownReloadNotice) {
			hasShownReloadNotice = true;

			// Add a temporary notice to the log
			addToLog("⚠️ IMPORTANT: Open or reload the Notification Monitor to initialize the debugger!", "warning");
			addToLog("The TileCounter debugger only works in the Notification Monitor tab.", "info");

			// Also update the status to show it's not initialized
			const statusElement = document.getElementById("tcStatus");
			if (statusElement) {
				statusElement.textContent = "Not initialized - open Notification Monitor";
				statusElement.style.color = "#f57c00";
			}
		}
	}

	// Function to check if debugger is already initialized
	async function checkDebuggerStatus() {
		if (!debugTileCounterCheckbox.checked) return;

		try {
			// Check if debugger is initialized by sending a test command
			const result = await sendTileCounterCommand("getMetrics");
			if (result && result.success) {
				// Debugger is initialized and responding
				const statusElement = document.getElementById("tcStatus");
				if (statusElement) {
					statusElement.textContent = "Initialized";
					statusElement.style.color = "#2e7d32";
				}
				// Don't log this on every check, only on initial load
				if (!window.hasLoggedDebuggerReady) {
					window.hasLoggedDebuggerReady = true;
					addToLog("TileCounter debugger is initialized and ready", "success");
				}

				// Update metrics display with current data
				if (result.data) {
					updateMetricsDisplay(result.data);
				}
			} else {
				// Debugger not initialized - but only show warning if checkbox is checked
				const statusElement = document.getElementById("tcStatus");
				if (statusElement && debugTileCounterCheckbox.checked) {
					// Only show "not initialized" if we haven't seen it initialized before
					const currentText = statusElement.textContent;
					if (currentText !== "Initialized" && currentText !== "Monitoring") {
						statusElement.textContent = "Not initialized - open Notification Monitor";
						statusElement.style.color = "#f57c00";
					}
				}
			}
		} catch (error) {
			console.error("Error checking debugger status:", error);
		}
	}

	// Initial visibility
	updateTileCounterDebugVisibility();

	// Listen for changes
	debugTileCounterCheckbox.addEventListener("change", updateTileCounterDebugVisibility);

	// Check debugger status on load if debugging is enabled
	if (debugTileCounterCheckbox.checked) {
		// Small delay to ensure everything is initialized
		setTimeout(() => {
			checkDebuggerStatus();
		}, 500);
	}

	// Periodically check if debugger becomes available (e.g., when user opens a Vine tab)
	setInterval(() => {
		if (debugTileCounterCheckbox.checked && !isMonitoring) {
			checkDebuggerStatus();
		}
	}, 3000); // Check every 3 seconds

	// TileCounter debug log
	const logElement = document.getElementById("tileCounterDebugLog");
	let logContent = [];
	let isMonitoring = false;
	let monitoringInterval = null;

	function addToLog(message, type = "info") {
		const timestamp = new Date().toLocaleTimeString("en-US", {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hour12: false,
		});

		// Use icons/symbols for different types
		const typeSymbol = type === "error" ? "❌" : type === "success" ? "✅" : type === "warning" ? "⚠️" : "ℹ️";
		const color =
			type === "error" ? "#d32f2f" : type === "success" ? "#2e7d32" : type === "warning" ? "#f57c00" : "#555";

		// Format message more compactly - all on one line
		const logEntry =
			`<div style="margin: 3px 0; font-size: 11px; line-height: 1.3;">` +
			`<span style="color: #999; font-size: 10px; display: inline-block; width: 55px;">${timestamp}</span> ` +
			`<span style="display: inline-block; width: 20px; text-align: center;">${typeSymbol}</span> ` +
			`<span style="color: ${color};">${message}</span>` +
			`</div>`;

		logContent.push(logEntry);

		// Keep only last 50 entries for dropdown view
		if (logContent.length > 50) {
			logContent.shift();
		}

		logElement.replaceChildren();
		logContent.forEach((entry) => {
			const div = document.createElement("div");
			div.textContent = entry;
			logElement.appendChild(div);
		});
		logElement.scrollTop = logElement.scrollHeight;
	}

	// Clear log button
	document.getElementById("clearTileCounterLogBtn")?.addEventListener("click", () => {
		logContent = [];
		logElement.replaceChildren();
		const div = document.createElement("div");
		div.style.color = "#888";
		div.style.fontStyle = "italic";
		div.textContent = "TileCounter performance log cleared.";
		logElement.appendChild(div);
		addToLog("Log cleared", "info");
	});

	// Copy log button
	document.getElementById("copyTileCounterLogBtn")?.addEventListener("click", async () => {
		try {
			// Extract text content from log entries
			const logText = logContent
				.map((entry) => {
					// Parse the HTML to extract text
					const tempDiv = document.createElement("div");
					tempDiv.textContent = entry;
					return tempDiv.textContent || tempDiv.innerText || "";
				})
				.join("\n");

			// Copy to clipboard
			await navigator.clipboard.writeText(logText);

			// Show success feedback
			const copyBtn = document.getElementById("copyTileCounterLogBtn");
			const originalText = copyBtn.textContent;
			copyBtn.textContent = "✓";
			copyBtn.style.background = "#d4edda";

			setTimeout(() => {
				copyBtn.textContent = originalText;
				copyBtn.style.background = "#f0f0f0";
			}, 1500);

			addToLog("Log copied to clipboard", "success");
		} catch (error) {
			console.error("Failed to copy log:", error);
			addToLog("Failed to copy log: " + error.message, "error");
		}
	});

	// TileCounter debugging API communication
	async function sendTileCounterCommand(command, params = {}) {
		try {
			// First try to find an active Notification Monitor tab
			const tabs = await chrome.tabs.query({});
			const monitorTab = tabs.find(
				(tab) =>
					tab.url &&
					tab.url.includes("amazon.") &&
					tab.url.includes("/vine/") &&
					(tab.url.includes("#monitor") ||
						tab.url.includes("#vh-monitor") ||
						tab.url.includes("/vine/vh-monitor") ||
						tab.url.includes("/vine/resources"))
			);

			if (!monitorTab) {
				if (command !== "getMetrics") {
					// Don't spam log for polling
					addToLog("No Notification Monitor tab found. Please open the Notification Monitor first.", "error");
					// Debug: show all vine tabs
					const vineTabs = tabs.filter(
						(tab) => tab.url && tab.url.includes("amazon.") && tab.url.includes("/vine/")
					);
					if (vineTabs.length > 0) {
						console.log(
							"Found Vine tabs but no monitor context tab:",
							vineTabs.map((t) => t.url)
						);
					}
				}
				return null;
			}

			// For the initial start command, try to inject the script
			if (command === "startMonitoring") {
				try {
					await chrome.scripting.executeScript({
						target: { tabId: monitorTab.id },
						files: ["scripts/bootloaderLoader.js"],
					});
					// Give the script more time to initialize
					await new Promise((resolve) => setTimeout(resolve, 500));
				} catch (e) {
					// Script might already be injected, which is fine
				}
			}

			// Debug log when we find the monitor tab
			if (command === "startMonitoring") {
				console.log("Found Notification Monitor tab:", monitorTab.url);
			}

			return new Promise((resolve) => {
				chrome.tabs.sendMessage(
					monitorTab.id,
					{
						type: "TILECOUNTER_DEBUG_COMMAND",
						command: command,
						params: params,
					},
					(response) => {
						if (chrome.runtime.lastError) {
							// Only log errors for non-polling commands
							if (command !== "getMetrics") {
								addToLog(`Error: ${chrome.runtime.lastError.message}`, "error");
								console.error("Message send error:", chrome.runtime.lastError);
							}
							resolve(null);
						} else {
							if (command === "startMonitoring") {
								console.log("Response from monitor tab:", response);
							}
							resolve(response);
						}
					}
				);
			});
		} catch (error) {
			if (command !== "getMetrics") {
				// Don't spam log for polling
				addToLog(`Error: ${error.message}`, "error");
			}
			return null;
		}
	}

	// Update metrics display
	function updateMetricsDisplay(metrics) {
		const statusElement = document.getElementById("tcStatus");

		// Determine status text based on current state
		if (isMonitoring) {
			statusElement.textContent = "Monitoring";
			statusElement.style.color = "#2e7d32";
		} else if (metrics) {
			// We have metrics but not monitoring - debugger is initialized
			statusElement.textContent = "Initialized";
			statusElement.style.color = "#2e7d32";
		} else {
			// No metrics - check if we should keep the current status
			const currentText = statusElement.textContent;
			if (currentText === "Initialized" || currentText === "Monitoring") {
				// Debugger was previously initialized, keep showing as initialized
				statusElement.textContent = "Initialized";
				statusElement.style.color = "#2e7d32";
			} else if (currentText === "Not initialized - open Notification Monitor") {
				// Keep the not initialized message
				statusElement.style.color = "#f57c00";
			} else {
				// Default state
				statusElement.textContent = "Not monitoring";
				statusElement.style.color = "#888";
			}
		}

		if (metrics) {
			document.getElementById("tcVisibleCount").textContent = metrics.visibleCount || "-";
			document.getElementById("tcLastRecount").textContent = metrics.lastRecountDuration
				? `${metrics.lastRecountDuration.toFixed(2)}ms`
				: "-";
			document.getElementById("tcAvgDelay").textContent = metrics.averageDelay
				? `${metrics.averageDelay.toFixed(2)}ms`
				: "-";
			document.getElementById("tcCacheHitRate").textContent = metrics.cacheHitRate
				? `${metrics.cacheHitRate.toFixed(1)}%`
				: "-";

			// Determine optimization status
			let optimizationStatus = "Unknown";
			let optimizationColor = "#888";

			if (metrics.averageDelay !== undefined) {
				if (metrics.averageDelay < 10) {
					optimizationStatus = "Optimized";
					optimizationColor = "#2e7d32";
				} else if (metrics.averageDelay < 50) {
					optimizationStatus = "Partial";
					optimizationColor = "#f57c00";
				} else {
					optimizationStatus = "Not optimized";
					optimizationColor = "#d32f2f";
				}
			}

			const tcOptimization = document.getElementById("tcOptimization");
			tcOptimization.textContent = optimizationStatus;
			tcOptimization.style.color = optimizationColor;
		}
	}

	// Start monitoring button
	document.getElementById("startTileCounterMonitorBtn")?.addEventListener("click", async () => {
		if (isMonitoring) {
			addToLog("Already monitoring", "warning");
			return;
		}

		addToLog("Starting TileCounter monitoring...");

		const result = await sendTileCounterCommand("startMonitoring");
		if (result && result.success) {
			isMonitoring = true;
			document.getElementById("startTileCounterMonitorBtn").disabled = true;
			document.getElementById("stopTileCounterMonitorBtn").disabled = false;

			addToLog("Monitoring started", "success");

			// Start polling for metrics
			monitoringInterval = setInterval(async () => {
				const metricsResult = await sendTileCounterCommand("getMetrics");
				if (metricsResult && metricsResult.success) {
					updateMetricsDisplay(metricsResult.data);
				} else if (!metricsResult) {
					// Connection lost, stop monitoring
					clearInterval(monitoringInterval);
					monitoringInterval = null;
					isMonitoring = false;
					document.getElementById("startTileCounterMonitorBtn").disabled = false;
					document.getElementById("stopTileCounterMonitorBtn").disabled = true;
					updateMetricsDisplay(null);
					addToLog(
						"Monitoring stopped - connection lost. Please reload the Vine page and try again.",
						"error"
					);
				}
			}, 2000); // Update every 2 seconds (less frequent to reduce errors)
		} else {
			const errorMsg = result?.error || "Unknown error";
			if (errorMsg.includes("not initialized") || errorMsg.includes("not available")) {
				addToLog("TileCounter debugger not initialized!", "error");
				addToLog("Please open or reload the Notification Monitor and try again.", "warning");
				addToLog("The debugger only works in the Notification Monitor tab.", "info");
			} else {
				addToLog(`Failed to start monitoring: ${errorMsg}`, "error");
			}
		}
	});

	// Stop monitoring button
	document.getElementById("stopTileCounterMonitorBtn")?.addEventListener("click", async () => {
		if (!isMonitoring) {
			addToLog("Not currently monitoring", "warning");
			return;
		}

		addToLog("Stopping TileCounter monitoring...");

		// Stop polling first
		if (monitoringInterval) {
			clearInterval(monitoringInterval);
			monitoringInterval = null;
		}

		const result = await sendTileCounterCommand("stopMonitoring");

		// Update UI regardless of result (connection might be lost)
		isMonitoring = false;
		document.getElementById("startTileCounterMonitorBtn").disabled = false;
		document.getElementById("stopTileCounterMonitorBtn").disabled = true;
		updateMetricsDisplay(null);

		if (result && result.success) {
			addToLog("Monitoring stopped", "success");
		} else if (!result) {
			addToLog("Monitoring stopped (connection was lost)", "warning");
		} else {
			addToLog(`Monitoring stopped with error: ${result?.error || "Unknown error"}`, "warning");
		}
	});

	// Generate report button
	document.getElementById("generateTileCounterReportBtn")?.addEventListener("click", async () => {
		addToLog("Generating TileCounter performance report...");

		const result = await sendTileCounterCommand("generateReport");
		if (result && result.success) {
			const report = result.data;
			addToLog("Performance report generated:", "success");

			// Log report details
			addToLog(`Total observations: ${report.summary.totalObservationTime}ms`);
			addToLog(`DOM mutations: ${report.summary.domMutations}`);
			addToLog(`Count updates: ${report.summary.countUpdates}`);

			if (report.debounceAnalysis) {
				addToLog(`Debounce pattern: ${report.debounceAnalysis.pattern}`);
				addToLog(`Average delay: ${report.debounceAnalysis.averageDelay.toFixed(2)}ms`);
			}

			// Log recommendations
			if (report.recommendations && report.recommendations.length > 0) {
				addToLog("Optimizations detected:");
				report.recommendations.forEach((rec) => {
					addToLog(`  ${rec}`, "success");
				});
			}
		} else {
			addToLog(`Failed to generate report: ${result?.error || "Unknown error"}`, "error");
		}
	});

	// Clear data button
	document.getElementById("clearTileCounterDataBtn")?.addEventListener("click", async () => {
		addToLog("Clearing TileCounter performance data...");

		const result = await sendTileCounterCommand("clearData");
		if (result && result.success) {
			addToLog("Performance data cleared", "success");
			updateMetricsDisplay(null);
		} else {
			addToLog(`Failed to clear data: ${result?.error || "Unknown error"}`, "error");
		}
	});
}

function getAppVersion() {
	const manifest = chrome.runtime.getManifest();
	return manifest.version_name || manifest.version;
}

//Tab management
function initTabs() {
	console.log("Initializing tabs");
	// Bind tab navigation on menu links (not parent <li>) so submenu items do not
	// bubble up to a settings-menu-group and open the Themes tab instead.
	document.querySelectorAll("#tabs-index .settings-menu a[data-tab]").forEach(function (link) {
		link.addEventListener("click", function (event) {
			event.preventDefault();
			event.stopPropagation();
			const currentTab = link.getAttribute("data-tab");
			if (currentTab) {
				selectTab(currentTab);
			}
		});
	});

	// Initialize sidebar toggle for mobile
	initSidebarToggle();

	// Check URL hash for initial tab
	const hash = window.location.hash;
	if (hash) {
		const anchorName = hash.substring(1); // Remove the #
		const tabId = getTabIdFromAnchor(anchorName);
		if (tabId && document.getElementById(tabId)) {
			selectTab(tabId);
			return;
		}
	}

	//Set the first tab as active if no hash
	const firstTabLink = document.querySelector("#tabs-index .settings-menu > li:first-child > a[data-tab]");
	if (firstTabLink) {
		firstTabLink.click();
	}
}

function initSidebarToggle() {
	const toggle = document.getElementById("sidebarToggle");
	const sidebar = document.getElementById("tabs-index");

	if (toggle && sidebar) {
		toggle.addEventListener("click", function () {
			sidebar.classList.toggle("sidebar-open");
			toggle.classList.toggle("active");
		});

		// Close sidebar when clicking on a menu item on mobile
		document.querySelectorAll("#tabs-index .settings-menu li").forEach(function (item) {
			item.addEventListener("click", function () {
				if (window.innerWidth <= 1100) {
					// Match .sidebar-toggle max-width in settings.css
					sidebar.classList.remove("sidebar-open");
					toggle.classList.remove("active");
				}
			});
		});

		// Close sidebar when clicking outside on mobile
		document.addEventListener("click", function (e) {
			if (
				window.innerWidth <= 1100 && // Match .sidebar-toggle max-width in settings.css
				!sidebar.contains(e.target) &&
				!toggle.contains(e.target) &&
				sidebar.classList.contains("sidebar-open")
			) {
				sidebar.classList.remove("sidebar-open");
				toggle.classList.remove("active");
			}
		});
	}
}

// Map anchor names to tab IDs
function getTabIdFromAnchor(anchorName) {
	const anchorToTabMap = {
		general: "tabs-1",
		locale: "tabs-15",
		notifications: "tabs-2",
		system: "tabs-3",
		styles: "tabs-4",
		discord: "tabs-5",
		webhooks: "tabs-11",
		keywords: "tabs-6",
		keyboard: "tabs-7",
		premium: "tabs-8",
		debug: "tabs-9",
		about: "tabs-10",
		server: "tabs-12",
		checkout: "tabs-13",
		themes: "tabs-14",
		review: "tabs-16",
		account: "tabs-17",
	};
	return anchorToTabMap[anchorName.toLowerCase()] || null;
}

const VH_DARK_THEME_LINK_ID = "vh-dark-theme-css";
const VH_AURORA_THEME_LINK_ID = "vh-aurora-theme-css";
const VH_GARISH_THEME_LINK_ID = "vh-garish-theme-css";
const VH_MIDNIGHT_THEME_LINK_ID = "vh-midnight-theme-css";
const VH_SCIFI_THEME_LINK_ID = "vh-scifi-theme-css";
const VH_WIN31_THEME_LINK_ID = "vh-win31-theme-css";

/**
 * Apply the current theme: inject theme CSS when not forest. No html/body classes.
 */
function applyThemeFromSettings() {
	const theme = Settings.get("general.theme") || "forest";
	const darkLink = document.getElementById(VH_DARK_THEME_LINK_ID);
	const auroraLink = document.getElementById(VH_AURORA_THEME_LINK_ID);
	const garishLink = document.getElementById(VH_GARISH_THEME_LINK_ID);
	const midnightLink = document.getElementById(VH_MIDNIGHT_THEME_LINK_ID);
	const scifiLink = document.getElementById(VH_SCIFI_THEME_LINK_ID);
	const win31Link = document.getElementById(VH_WIN31_THEME_LINK_ID);

	function removeOtherThemeLinks() {
		if (darkLink) darkLink.remove();
		if (auroraLink) auroraLink.remove();
		if (garishLink) garishLink.remove();
		if (midnightLink) midnightLink.remove();
		if (scifiLink) scifiLink.remove();
		if (win31Link) win31Link.remove();
	}

	if (theme === "dark") {
		if (!darkLink) {
			const link = document.createElement("link");
			link.id = VH_DARK_THEME_LINK_ID;
			link.rel = "stylesheet";
			link.type = "text/css";
			link.href = "../resource/theme/dark.css";
			document.head.appendChild(link);
		}
		if (auroraLink) auroraLink.remove();
		if (garishLink) garishLink.remove();
		if (midnightLink) midnightLink.remove();
		if (scifiLink) scifiLink.remove();
		if (win31Link) win31Link.remove();
	} else if (theme === "aurora") {
		if (!auroraLink) {
			const link = document.createElement("link");
			link.id = VH_AURORA_THEME_LINK_ID;
			link.rel = "stylesheet";
			link.type = "text/css";
			link.href = "../resource/theme/aurora.css";
			document.head.appendChild(link);
		}
		if (darkLink) darkLink.remove();
		if (garishLink) garishLink.remove();
		if (midnightLink) midnightLink.remove();
		if (scifiLink) scifiLink.remove();
		if (win31Link) win31Link.remove();
	} else if (theme === "garish") {
		if (!garishLink) {
			const link = document.createElement("link");
			link.id = VH_GARISH_THEME_LINK_ID;
			link.rel = "stylesheet";
			link.type = "text/css";
			link.href = "../resource/theme/garish.css";
			document.head.appendChild(link);
		}
		if (darkLink) darkLink.remove();
		if (auroraLink) auroraLink.remove();
		if (midnightLink) midnightLink.remove();
		if (scifiLink) scifiLink.remove();
		if (win31Link) win31Link.remove();
	} else if (theme === "midnight") {
		if (!midnightLink) {
			const link = document.createElement("link");
			link.id = VH_MIDNIGHT_THEME_LINK_ID;
			link.rel = "stylesheet";
			link.type = "text/css";
			link.href = "../resource/theme/midnight.css";
			document.head.appendChild(link);
		}
		if (darkLink) darkLink.remove();
		if (auroraLink) auroraLink.remove();
		if (garishLink) garishLink.remove();
		if (scifiLink) scifiLink.remove();
		if (win31Link) win31Link.remove();
	} else if (theme === "scifi") {
		if (!scifiLink) {
			const link = document.createElement("link");
			link.id = VH_SCIFI_THEME_LINK_ID;
			link.rel = "stylesheet";
			link.type = "text/css";
			link.href = "../resource/theme/scifi.css";
			document.head.appendChild(link);
		}
		if (darkLink) darkLink.remove();
		if (auroraLink) auroraLink.remove();
		if (garishLink) garishLink.remove();
		if (midnightLink) midnightLink.remove();
		if (win31Link) win31Link.remove();
	} else if (theme === "win31") {
		if (!win31Link) {
			const link = document.createElement("link");
			link.id = VH_WIN31_THEME_LINK_ID;
			link.rel = "stylesheet";
			link.type = "text/css";
			link.href = "../resource/theme/win31.css";
			document.head.appendChild(link);
		}
		if (darkLink) darkLink.remove();
		if (auroraLink) auroraLink.remove();
		if (garishLink) garishLink.remove();
		if (midnightLink) midnightLink.remove();
		if (scifiLink) scifiLink.remove();
	} else {
		removeOtherThemeLinks();
	}
}

/**
 * Initialize the Themes tab: bind theme card clicks and sync aria-pressed with current theme.
 */
function initThemes() {
	const list = document.getElementById("vh-themes-list");
	if (!list) return;

	function setActiveCard(themeId) {
		list.querySelectorAll(".vh-theme-card").forEach((btn) => {
			btn.setAttribute("aria-pressed", btn.dataset.theme === themeId ? "true" : "false");
		});
	}

	setActiveCard(Settings.get("general.theme") || "forest");

	// Garish shown in theme list only on April 1st
	const garishCard = list.querySelector('.vh-theme-card[data-theme="garish"]');
	if (garishCard && !isGarishThemeAvailable()) {
		garishCard.style.display = "none";
	}

	list.querySelectorAll(".vh-theme-card").forEach((btn) => {
		btn.addEventListener("click", () => {
			const themeId = btn.getAttribute("data-theme");
			if (!themeId) return;
			Settings.set("general.theme", themeId).then(() => {
				applyThemeFromSettings();
				setActiveCard(themeId);
			});
		});
	});
}

// Map tab IDs to anchor names
function getAnchorFromTabId(tabId) {
	const tabToAnchorMap = {
		"tabs-1": "general",
		"tabs-15": "locale",
		"tabs-2": "notifications",
		"tabs-3": "system",
		"tabs-4": "styles",
		"tabs-5": "discord",
		"tabs-11": "webhooks",
		"tabs-6": "keywords",
		"tabs-7": "keyboard",
		"tabs-8": "premium",
		"tabs-9": "debug",
		"tabs-10": "about",
		"tabs-12": "server",
		"tabs-13": "checkout",
		"tabs-14": "themes",
		"tabs-16": "review",
		"tabs-17": "account",
	};
	return tabToAnchorMap[tabId] || null;
}

function selectTab(tab) {
	//Hide all tabs
	document.querySelectorAll("#tabs-content .tab").forEach(function (item) {
		item.style.display = "none";
	});

	//Remove active class from all menu items
	document.querySelectorAll("#tabs-index .settings-menu li").forEach(function (item) {
		item.classList.remove("active");
	});
	document.querySelectorAll("#tabs-index .settings-menu-group").forEach(function (item) {
		item.classList.remove("group-active");
	});

	//Display the current tab
	const tabElement = document.querySelector("#" + tab);
	if (tabElement) {
		tabElement.style.display = "flex";
		// Reinitialize collapsible fieldsets for the newly shown tab
		initCollapsibleFieldsets();
		// Reinitialize tooltips for the newly shown tab
		initSettingTooltips();
		// Reinitialize premium tooltips for the newly shown tab
		initPremiumTooltips();
		// Re-bind checkout controls and risk gate when checkout tab is shown
		if (tab === "tabs-13") {
			ensureCheckoutTabBound();
		}
		// Refresh contribution stats when About tab is shown
		if (tab === "tabs-10") {
			void loadUserContributionStats();
		}
	}

	//Add active class to the clicked menu item
	const menuItem = document.querySelector(`#tabs-index .settings-menu a[data-tab="${tab}"]`);
	if (menuItem && menuItem.parentElement) {
		menuItem.parentElement.classList.add("active");
		const menuGroup = menuItem.closest(".settings-menu-group");
		if (menuGroup) {
			menuGroup.classList.add("group-active");
		}
	}

	// Update URL hash with anchor name instead of tab ID
	const anchorName = getAnchorFromTabId(tab);
	if (anchorName) {
		if (history.pushState) {
			history.pushState(null, null, "#" + anchorName);
		} else {
			window.location.hash = anchorName;
		}
	}
}

/**
 * Initialize collapsible fieldsets
 * Makes all fieldsets collapsible by clicking on the legend
 */
function initCollapsibleFieldsets() {
	// Wrap fieldset content in a container for smooth animation
	document.querySelectorAll("#tabs-content fieldset").forEach(function (fieldset) {
		// Skip if already processed
		if (fieldset.dataset.collapsibleInitialized === "true") {
			return;
		}

		// Mark as initialized
		fieldset.dataset.collapsibleInitialized = "true";

		// Get all children except the legend
		const children = Array.from(fieldset.children).filter(function (child) {
			return child.tagName !== "LEGEND";
		});

		if (children.length > 0) {
			// Create a wrapper div for the content
			const contentWrapper = document.createElement("div");
			contentWrapper.className = "fieldset-content";

			// Move all non-legend children into the wrapper
			children.forEach(function (child) {
				contentWrapper.appendChild(child);
			});

			// Append the wrapper after the legend
			const legend = fieldset.querySelector("legend");
			if (legend && legend.nextSibling) {
				fieldset.insertBefore(contentWrapper, legend.nextSibling);
			} else {
				fieldset.appendChild(contentWrapper);
			}
		}

		// Add click handler to legend
		const legend = fieldset.querySelector("legend");
		if (legend) {
			legend.addEventListener("click", function (e) {
				// Check if the click target is an interactive element or inside one
				const target = e.target;

				// Check if target is directly an interactive element
				const isDirectInteractive =
					target.tagName === "INPUT" ||
					target.tagName === "BUTTON" ||
					target.tagName === "SELECT" ||
					target.tagName === "TEXTAREA" ||
					target.tagName === "A" ||
					target.tagName === "LABEL";

				// Check if target is inside an interactive element (handles text nodes, spans, etc.)
				const isInsideInteractive = target.closest("input, button, select, textarea, a, label") !== null;

				// If clicking directly on an interactive element, let it handle its own behavior
				if (isDirectInteractive || isInsideInteractive) {
					return;
				}

				// Check if click is in the arrow area (right side of legend)
				// The arrow is positioned on the right with margin-left: auto
				const legendRect = legend.getBoundingClientRect();
				const clickX = e.clientX;
				const legendRight = legendRect.right;
				const arrowAreaWidth = 30; // Approximate width of arrow area (arrow + padding)

				// If click is in the right 30px of the legend (arrow area), just collapse
				if (clickX >= legendRight - arrowAreaWidth) {
					e.preventDefault();
					fieldset.classList.toggle("collapsed");
					return;
				}

				// Check if legend contains a checkbox
				const checkbox = legend.querySelector('input[type="checkbox"]');
				if (checkbox) {
					// Toggle the checkbox when clicking on the legend (but not in arrow area)
					e.preventDefault();
					checkbox.checked = !checkbox.checked;
					// Trigger change event to ensure any listeners are notified
					checkbox.dispatchEvent(new Event("change", { bubbles: true }));
					return;
				}

				// Otherwise, toggle collapse
				e.preventDefault();
				fieldset.classList.toggle("collapsed");
			});
		}
	});
}

/**
 * Custom tooltip system for settings page
 * Creates and manages tooltips that can display HTML content
 */
const settingsTooltip = (function () {
	let tooltipElement = null;
	let currentTarget = null;
	let hideTimeout = null;

	function createTooltipElement() {
		if (tooltipElement) {
			return tooltipElement;
		}
		tooltipElement = document.createElement("div");
		tooltipElement.className = "settings-tooltip";
		document.body.appendChild(tooltipElement);
		return tooltipElement;
	}

	function updateArrowPosition(tooltip, cursorXPos) {
		if (!tooltip) return;

		const tooltipRect = tooltip.getBoundingClientRect();

		// Calculate cursor position relative to the tooltip
		// cursorXPos is in client coordinates (viewport-relative)
		const cursorRelativeX = cursorXPos - tooltipRect.left;

		// Clamp the arrow position to stay within reasonable bounds (8px from edges)
		const minArrowPos = 8;
		const maxArrowPos = tooltipRect.width - 8;
		const arrowPos = Math.max(minArrowPos, Math.min(maxArrowPos, cursorRelativeX));

		// Update the arrow position using CSS custom property
		tooltip.style.setProperty("--arrow-left", arrowPos + "px");
	}

	function showTooltip(target, htmlContent, event) {
		// Clear any pending hide timeout
		if (hideTimeout) {
			clearTimeout(hideTimeout);
			hideTimeout = null;
		}

		const tooltip = createTooltipElement();
		tooltip.innerHTML = htmlContent;
		tooltip.style.display = "block";
		currentTarget = target;

		// Position the tooltip
		positionTooltip(target, tooltip);

		// Update arrow position based on initial cursor position
		if (event) {
			updateArrowPosition(tooltip, event.clientX);
		}

		// Add event listeners to tooltip to keep it visible when hovering over it
		// Remove old listeners first to avoid duplicates
		const newMouseEnter = function () {
			if (hideTimeout) {
				clearTimeout(hideTimeout);
				hideTimeout = null;
			}
		};
		const newMouseLeave = function () {
			hideTooltip();
		};

		// Remove previous listeners if they exist
		if (tooltip._tooltipMouseEnter) {
			tooltip.removeEventListener("mouseenter", tooltip._tooltipMouseEnter);
		}
		if (tooltip._tooltipMouseLeave) {
			tooltip.removeEventListener("mouseleave", tooltip._tooltipMouseLeave);
		}

		// Store references and add new listeners
		tooltip._tooltipMouseEnter = newMouseEnter;
		tooltip._tooltipMouseLeave = newMouseLeave;
		tooltip.addEventListener("mouseenter", newMouseEnter);
		tooltip.addEventListener("mouseleave", newMouseLeave);
	}

	function hideTooltip() {
		if (tooltipElement) {
			// Add a small delay to allow moving from icon to tooltip
			hideTimeout = setTimeout(function () {
				if (tooltipElement) {
					tooltipElement.style.display = "none";
					currentTarget = null;
				}
			}, 100);
		}
	}

	function positionTooltip(target, tooltip) {
		const rect = target.getBoundingClientRect();
		const tooltipRect = tooltip.getBoundingClientRect();
		const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
		const scrollY = window.pageYOffset || document.documentElement.scrollTop;

		// Position below the icon by default
		let top = rect.bottom + scrollY + 8;
		let left = rect.left + scrollX + rect.width / 2 - 400 / 2;

		// Adjust if tooltip would go off-screen
		if (left + tooltipRect.width > window.innerWidth + scrollX) {
			left = window.innerWidth + scrollX - 400 - 10;
		}
		if (left < scrollX) {
			left = scrollX + 10;
		}

		// If tooltip would go off bottom, position above instead
		if (top + tooltipRect.height > window.innerHeight + scrollY) {
			top = rect.top + scrollY - tooltipRect.height - 8;
		}

		tooltip.style.left = left + "px";
		tooltip.style.top = top + "px";
	}

	return {
		show: showTooltip,
		hide: hideTooltip,
	};
})();

/**
 * Initialize tooltips for (?) icons in settings
 * Extracts the HTML content and shows it as a tooltip on hover
 */
function initSettingTooltips() {
	// Find all setting-summary divs that haven't been processed yet
	document.querySelectorAll(".setting-summary:not([data-tooltip-initialized])").forEach(function (summaryDiv) {
		// Mark as processed to avoid duplicate tooltips
		summaryDiv.setAttribute("data-tooltip-initialized", "true");

		// Find the question icon
		const icon = summaryDiv.querySelector(".vh-icon-question");
		if (!icon) {
			return;
		}

		// Get all HTML content from the summary (excluding the icon)
		// Clone the summary div, remove the icon, and get the innerHTML
		const summaryClone = summaryDiv.cloneNode(true);
		const iconClone = summaryClone.querySelector(".vh-icon-question");
		if (iconClone) {
			iconClone.remove();
		}

		// Get the HTML content (preserving any HTML formatting)
		const tooltipHTML = summaryClone.innerHTML.trim();

		// Only add tooltip if there's content
		if (tooltipHTML) {
			// Store the HTML content in a data attribute for reference
			icon.setAttribute("data-tooltip-html", tooltipHTML);

			// Add event listeners for hover
			icon.addEventListener("mouseenter", function (e) {
				settingsTooltip.show(icon, tooltipHTML, e);
			});

			icon.addEventListener("mouseleave", function (e) {
				settingsTooltip.hide();
			});

			// The tooltip element will be created when needed, and event listeners
			// will be added to it in the showTooltip function
		}

		// Hide the summary text (keep only the icon visible)
		// Hide all text nodes and elements except the icon
		Array.from(summaryDiv.childNodes).forEach(function (node) {
			if (node.nodeType === Node.TEXT_NODE) {
				node.textContent = ""; // Clear text nodes
			} else if (node.nodeType === Node.ELEMENT_NODE && !node.classList.contains("vh-icon-question")) {
				node.style.display = "none"; // Hide other elements
			}
		});
	});
}

/**
 * Initialize tooltips for premium tier icons
 * Shows a tooltip explaining that the feature requires a premium subscription
 */
function initPremiumTooltips() {
	// Find all premium tier icons
	document.querySelectorAll(".vh-icon-premium:not([data-premium-tooltip-initialized])").forEach(function (icon) {
		// Mark as processed to avoid duplicate tooltips
		icon.setAttribute("data-premium-tooltip-initialized", "true");

		// Get the tier number from the icon's text content
		const tierNumber = icon.textContent.trim();

		// Create the tooltip message
		const tooltipHTML = `This is a premium feature of tier ${tierNumber}. Check the Premium tab to upgrade your subscription and unlock it!`;

		// Add event listeners for hover
		icon.addEventListener("mouseenter", function (e) {
			settingsTooltip.show(icon, tooltipHTML, e);
		});

		icon.addEventListener("mouseleave", function (e) {
			settingsTooltip.hide();
		});
	});
}

/**
 * Initialize sidebar scroll behavior - moves sidebar to top when header scrolls out of view
 */
function initSidebarScrollBehavior() {
	const header = document.querySelector(".header");
	const sidebar = document.querySelector(".settings-sidebar");

	if (!header || !sidebar) {
		return;
	}

	// Skip on mobile - sidebar is handled differently
	if (window.innerWidth <= 768) {
		return;
	}

	// Get the initial top position from CSS (90px)
	const initialTop = 90;

	// Get header height for smooth transition calculation
	const headerHeight = header.offsetHeight;

	// Function to update sidebar position based on scroll
	function updateSidebarPosition() {
		// Skip on mobile
		if (window.innerWidth <= 768) {
			return;
		}

		const headerRect = header.getBoundingClientRect();

		// Calculate how much of the header is visible
		// When headerRect.bottom is at initialTop, header is fully visible
		// When headerRect.bottom is 0 or less, header is completely out of view
		const headerBottom = headerRect.bottom;

		// Calculate the target top position
		// When header is fully visible (bottom > initialTop), sidebar should be at initialTop
		// When header is completely hidden (bottom <= 0), sidebar should be at 0
		// Smoothly interpolate between these values
		let targetTop;

		if (headerBottom >= initialTop) {
			// Header is fully visible, sidebar at initial position
			targetTop = initialTop;
		} else if (headerBottom <= 0) {
			// Header is completely out of view, sidebar at top
			targetTop = 0;
		} else {
			// Header is partially visible, interpolate smoothly
			// Map headerBottom from [0, initialTop] to [0, initialTop] for sidebar position
			targetTop = Math.max(0, initialTop - (initialTop - headerBottom));
		}

		sidebar.style.top = targetTop + "px";
	}

	// Use requestAnimationFrame for smoother updates
	let ticking = false;
	function onScroll() {
		if (!ticking) {
			window.requestAnimationFrame(function () {
				updateSidebarPosition();
				ticking = false;
			});
			ticking = true;
		}
	}

	// Update on scroll
	window.addEventListener("scroll", onScroll, { passive: true });

	// Handle window resize
	window.addEventListener("resize", function () {
		if (window.innerWidth > 768) {
			updateSidebarPosition();
		} else {
			// Reset sidebar position on mobile
			sidebar.style.top = "0px";
		}
	});

	// Initial update
	updateSidebarPosition();
}
