import { Environment } from "/scripts/core/services/Environment.js";
var env = new Environment();

import {
	Internationalization,
	initLocaleOverride,
	getMessageForTemplate,
	getMessageOrDefault,
} from "/scripts/core/services/Internationalization.js";
const i18n = new Internationalization();

import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
const cryptoKeys = new CryptoKeys();

import { Chart, registerables } from "/scripts/vendor/chart.js/dist/chart.js";

import { isFirefox, isChromium, isSafari } from "/scripts/core/utils/BrowserDetection.js";

//If browser is firefox, load icon_firefox.css
if (isFirefox()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_firefox.css";
	document.head.appendChild(link);
}
//If the browser is chrome, load icon_chrome.css
if (isChromium()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_chrome.css";
	document.head.appendChild(link);
}
if (isSafari()) {
	const link = document.createElement("link");
	link.rel = "stylesheet";
	link.type = "text/css";
	link.href = "../resource/css/icon_ios.css";
	document.head.appendChild(link);
}
function loadStyleSheetContent(content, path = "injected") {
	if (content != "") {
		const style = document.createElement("style");
		style.textContent = "/*" + path + "*/\n" + content;
		document.head.appendChild(style);
	}
}

function loadCustomCSS(content) {
	const styleId = "vh-custom-css";
	let style = document.getElementById(styleId);
	if (!style) {
		style = document.createElement("style");
		style.id = styleId;
		document.head.appendChild(style);
	}
	style.textContent = content ? `/*general.customCSS*/\n${content}` : "";
}

// Register required components
Chart.register(...registerables);

// Register custom background plugin
Chart.register({
	id: "customBackground",
	beforeDraw: (chart) => {
		const { ctx, chartArea } = chart;
		if (!chartArea) return;

		// Use the original dates from drop_stats instead of labels
		const dates = chart.data._source_dates;
		if (!dates) return; // Safety check

		const scale = chart.scales.x;

		// Find the first and last date
		const firstDate = dates[0];
		const lastDate = dates[dates.length - 1];

		// Calculate days between
		const days = Math.ceil((lastDate - firstDate) / (24 * 60 * 60 * 1000));

		// For each day
		for (let i = 0; i <= days; i++) {
			const currentDay = new Date(firstDate);
			currentDay.setDate(currentDay.getDate() + i);
			// Set to start of day (0h)
			currentDay.setHours(0, 0, 0, 0);

			const nextDay = new Date(currentDay);
			nextDay.setDate(nextDay.getDate() + 1);

			// Find start and end indices for this day
			const startIdx = dates.findIndex((d) => d >= currentDay);
			const endIdx = dates.findIndex((d) => d >= nextDay);

			if (startIdx !== -1) {
				const startPixel = startIdx === 0 ? chartArea.left : scale.getPixelForValue(startIdx);
				const endPixel = endIdx !== -1 ? scale.getPixelForValue(endIdx) : chartArea.right;

				ctx.fillStyle = i % 2 === 0 ? "rgba(0,0,0,0.05)" : "rgba(0,0,0,0.15)";
				ctx.fillRect(startPixel, chartArea.top, endPixel - startPixel, chartArea.bottom - chartArea.top);
			}
		}
	},
});

// Track loaded data to avoid reloading
let hourlyDataLoaded = false;
let monthlyDataLoaded = false;

/**
 * This function will apply the translations with the user selected language, replacing the browser defaults.
 */
function applyItemExplorerStatsTranslations() {
	const m = (key, fallback) => getMessageForTemplate(key) || fallback;
	document.title = m("itemExplorerStatsTitle", "VHIE - Statistics");
	const q = (s) => document.querySelector(s);
	if (q(".vh-header-text h2")) q(".vh-header-text h2").textContent = m("itemExplorerHeaderTitle", "Items Explorer");
	if (q(".vh-header-text h3")) q(".vh-header-text h3").textContent = m("itemExplorerHeaderSubtitle", "Statistics");
	if (q("#main-tabs-index a[href='#main-tabs-hourly']"))
		q("#main-tabs-index a[href='#main-tabs-hourly']").textContent = m(
			"itemExplorerMainTabsHourly",
			"Last 7 days / hourly"
		);
	if (q("#main-tabs-index a[href='#main-tabs-monthly']"))
		q("#main-tabs-index a[href='#main-tabs-monthly']").textContent = m("itemExplorerMainTabsMonthly", "Monthly");
	const tabKeys = [
		["#tabs-index-hourly a[href='#tabs-stacked']", "itemExplorerTabsStacked"],
		["#tabs-index-hourly a[href='#tabs-total']", "itemExplorerTabsTrueTotal"],
		["#tabs-index-hourly a[href='#tabs-rfy']", "itemExplorerTabsRfy"],
		["#tabs-index-hourly a[href='#tabs-afa']", "itemExplorerTabsAfa"],
		["#tabs-index-hourly a[href='#tabs-ai']", "itemExplorerTabsAi"],
		["#tabs-index-hourly a[href='#tabs-all']", "itemExplorerTabsAll"],
	];
	tabKeys.forEach(([sel, key]) => {
		const el = q(sel);
		if (el) el.textContent = m(key, el.textContent);
	});
	const h3Keys = [
		["#tabs-stacked h3", "itemExplorerDropStatsStacked"],
		["#tabs-total h3", "itemExplorerDropStatsTrueTotal"],
		["#tabs-rfy h3", "itemExplorerDropStatsRfy"],
		["#tabs-afa h3", "itemExplorerDropStatsAfa"],
		["#tabs-ai h3", "itemExplorerDropStatsAi"],
		["#tabs-all h3", "itemExplorerDropStatsAll"],
	];
	h3Keys.forEach(([sel, key]) => {
		const el = q(sel);
		if (el) el.textContent = m(key, el.textContent);
	});
	if (q(".vh-graph-title")) q(".vh-graph-title").textContent = m("itemExplorerYearlyTitle", "Yearly Drop Statistics");
	if (q(".vh-graph-subtitle"))
		q(".vh-graph-subtitle").textContent = m("itemExplorerYearlySubtitle", "Monthly totals by year");
}

(async () => {
	await Settings.waitForLoad();
	await initLocaleOverride(Settings.get("i18n.localeOverride"));
	window.__VH_GET_MESSAGE__ = getMessageForTemplate;
	applyItemExplorerStatsTranslations();

	//Check if the membership is valid
	if (Settings.isPremiumUser(3) == false) {
		const message = getMessageOrDefault(
			"itemExplorerPremiumRequired",
			"You need to be a tier 3 Patreon subscriber to use this feature."
		);
		displayError(message);
		return;
	}

	if (Settings.get("general.customCSS")) {
		loadCustomCSS(Settings.get("general.customCSS"));
	}

	const countryCode = Settings.get("general.country");

	if (countryCode != null) {
		i18n.setCountryCode(countryCode);
	}

	// Initialize main tabs (Last 7 days / hourly vs Monthly)
	initMainTabs();

	// Initialize hourly sub-tabs (Stacked, True Total, RFY, AFA, AI, ALL)
	initTabs("#tabs-index-hourly", "#tabs-content-hourly");

	// Load hourly data by default (first tab)
	loadHourlyData();
})();

function initMainTabs() {
	document.querySelectorAll("#main-tabs-index > ul li").forEach(function (item) {
		item.onclick = function (event) {
			event.preventDefault();
			const currentTab = this.querySelector("a").href.split("#").pop();
			selectMainTab(currentTab);
			this.classList.add("active");
			return false;
		};
	});
	//Set the first tab as active
	document.querySelector("#main-tabs-index > ul li:first-child").click();
}

function selectMainTab(selectedTab) {
	//Hide all main tabs
	document.querySelectorAll("#main-tabs-content .main-tab").forEach(function (item) {
		item.style.display = "none";
		item.classList.remove("active");
	});

	document.querySelectorAll("#main-tabs-index > ul li").forEach(function (item) {
		item.classList.remove("active");
	});

	//Display the current tab
	const tabElement = document.querySelector("#" + selectedTab);
	if (tabElement) {
		tabElement.style.display = "block";
		tabElement.classList.add("active");

		// Load data when tab is displayed
		if (selectedTab === "main-tabs-hourly" && !hourlyDataLoaded) {
			loadHourlyData();
		} else if (selectedTab === "main-tabs-monthly" && !monthlyDataLoaded) {
			loadMonthlyData();
		}
	}
}

function showLoading(containerId) {
	const container = document.getElementById(containerId);
	if (container) {
		container.innerHTML = '<div class="vh-loading-spinner"></div>';
	}
}

function hideLoading(containerId) {
	const container = document.getElementById(containerId);
	if (container) {
		const spinner = container.querySelector(".vh-loading-spinner");
		if (spinner) {
			spinner.remove();
		}
	}
}

async function loadHourlyData() {
	if (hourlyDataLoaded) return;

	hourlyDataLoaded = true;

	// Show loading for all chart containers
	const chartContainers = [
		"vh-drop-stats",
		"vh-drop-stats-stacked",
		"vh-drop-stats-rfy",
		"vh-drop-stats-afa",
		"vh-drop-stats-ai",
		"vh-drop-stats-all",
	];
	chartContainers.forEach((id) => {
		const container = document.getElementById(id);
		if (container) {
			container.innerHTML = '<div class="vh-loading-spinner"></div>';
		}
	});

	const data = {
		api_version: 5,
		app_version: env.data.appVersion,
		action: "item_explorer_stats",
		country: i18n.getCountryCode(),
		uuid: Settings.get("general.uuid", false),
		cid: await env.getCID(),
	};
	const s = await cryptoKeys.signData(data);
	data.s = s;
	data.pk = await cryptoKeys.getExportedPublicKey();

	try {
		const response = await fetch(env.getAPIUrl(), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(data),
		});

		const responseData = await response.json();
		if (!response.ok) {
			throw new Error(responseData.error || "Server error");
		}

		// Hide loading and clear containers before creating charts
		chartContainers.forEach((id) => {
			const container = document.getElementById(id);
			if (container) {
				container.innerHTML = ""; // Clear loading spinner and any existing canvas
			}
		});

		// Create canvas elements and generate graphs
		const canvas = document.createElement("canvas");
		document.getElementById("vh-drop-stats").appendChild(canvas);
		generateGraph(canvas, responseData.drop_stats);

		const canvas5 = document.createElement("canvas");
		document.getElementById("vh-drop-stats-stacked").appendChild(canvas5);
		generateStackedGraph(
			canvas5,
			responseData.drop_stats_rfy,
			responseData.drop_stats_afa,
			responseData.drop_stats_ai,
			responseData.drop_stats_all
		);

		const canvas2 = document.createElement("canvas");
		document.getElementById("vh-drop-stats-rfy").appendChild(canvas2);
		generateGraph(canvas2, responseData.drop_stats_rfy);

		const canvas3 = document.createElement("canvas");
		document.getElementById("vh-drop-stats-afa").appendChild(canvas3);
		generateGraph(canvas3, responseData.drop_stats_afa);

		const canvas4 = document.createElement("canvas");
		document.getElementById("vh-drop-stats-ai").appendChild(canvas4);
		generateGraph(canvas4, responseData.drop_stats_ai);

		const canvas6 = document.createElement("canvas");
		document.getElementById("vh-drop-stats-all").appendChild(canvas6);
		generateGraph(canvas6, responseData.drop_stats_all);
	} catch (error) {
		console.error("Error loading hourly data:", error);
		const errorMessage =
			typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage
				? chrome.i18n.getMessage("itemExplorerErrorLoadingData") || "Error loading data. Please try again."
				: "Error loading data. Please try again.";
		chartContainers.forEach((id) => {
			const container = document.getElementById(id);
			if (container) {
				container.innerHTML = `<p style="color: #999; text-align: center; padding: 20px;">${errorMessage}</p>`;
			}
		});
		hourlyDataLoaded = false; // Allow retry
	}
}

async function loadMonthlyData() {
	if (monthlyDataLoaded) return;

	monthlyDataLoaded = true;
	showLoading("vh-yearly-stats");

	try {
		await fetchYearlyStats();
		hideLoading("vh-yearly-stats");
	} catch (error) {
		console.error("Error loading monthly data:", error);
		const errorMessage =
			typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage
				? chrome.i18n.getMessage("itemExplorerErrorLoadingData") || "Error loading data. Please try again."
				: "Error loading data. Please try again.";
		const container = document.getElementById("vh-yearly-stats");
		if (container) {
			container.innerHTML = `<p style="color: #999; text-align: center; padding: 20px;">${errorMessage}</p>`;
		}
		monthlyDataLoaded = false; // Allow retry
	}
}

async function fetchYearlyStats() {
	const data = {
		api_version: 5,
		app_version: env.data.appVersion,
		action: "item_explorer_stats_yearly",
		country: i18n.getCountryCode(),
		uuid: Settings.get("general.uuid", false),
		cid: await env.getCID(),
	};
	const s = await cryptoKeys.signData(data);
	data.s = s;
	data.pk = await cryptoKeys.getExportedPublicKey();

	const response = await fetch(env.getAPIUrl(), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data),
	});

	const responseData = await response.json();
	if (!response.ok) {
		throw new Error(responseData.error || "Server error");
	}

	// Data format expected:
	// yearly_stats: {
	//   "2023": [
	//     { month: "2023-01", total_items: 1500 },
	//     { month: "2023-02", total_items: 1600 },
	//     ...
	//   ],
	//   "2024": [
	//     { month: "2024-01", total_items: 1700 },
	//     ...
	//   ],
	//   ...
	// }

	if (responseData.yearly_stats) {
		// Clear any existing canvas before adding new one
		const container = document.getElementById("vh-yearly-stats");
		if (container) {
			const existingCanvas = container.querySelector("canvas");
			if (existingCanvas) {
				existingCanvas.remove();
			}
		}
		const canvas = document.createElement("canvas");
		document.getElementById("vh-yearly-stats").appendChild(canvas);
		generateYearlyGraph(canvas, responseData.yearly_stats);
	} else {
		throw new Error("No yearly stats data received");
	}
}

function generateYearlyGraph(canvas, yearlyData) {
	if (!yearlyData || Object.keys(yearlyData).length === 0) {
		console.error("No yearly data for graph");
		return;
	}

	// Get all unique months (Jan-Dec) for x-axis labels
	const monthLabels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

	// Get all years and sort them
	const years = Object.keys(yearlyData).sort();
	const colors = [
		"rgba(255, 99, 132, 0.8)", // Red
		"rgba(54, 162, 235, 0.8)", // Blue
		"rgba(75, 192, 192, 0.8)", // Teal
		"rgba(153, 102, 255, 0.8)", // Purple
		"rgba(255, 159, 64, 0.8)", // Orange
		"rgba(199, 199, 199, 0.8)", // Grey
		"rgba(83, 102, 255, 0.8)", // Indigo
		"rgba(255, 205, 86, 0.8)", // Yellow
	];

	const datasets = years.map((year, yearIndex) => {
		const yearData = yearlyData[year];
		// Create array with 12 values (one per month), filling missing months with 0
		const monthlyValues = monthLabels.map((_, monthIndex) => {
			const monthStr = `${year}-${String(monthIndex + 1).padStart(2, "0")}`;
			const monthData = yearData.find((d) => d.month === monthStr);
			return monthData ? monthData.total_items : 0;
		});

		return {
			label: year,
			data: monthlyValues,
			borderColor: colors[yearIndex % colors.length],
			backgroundColor: colors[yearIndex % colors.length].replace("0.8", "0.2"),
			borderWidth: 2,
			fill: false,
			tension: 0.1,
		};
	});

	const chart = new Chart(canvas, {
		type: "line",
		data: {
			labels: monthLabels,
			datasets: datasets,
		},
		options: {
			responsive: true,
			maintainAspectRatio: true,
			scales: {
				y: {
					beginAtZero: true,
					title: {
						display: true,
						text:
							typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage
								? chrome.i18n.getMessage("itemExplorerYearlyYAxis") || "Total Items"
								: "Total Items",
					},
				},
				x: {
					title: {
						display: true,
						text:
							typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage
								? chrome.i18n.getMessage("itemExplorerYearlyXAxis") || "Month"
								: "Month",
					},
				},
			},
			plugins: {
				legend: {
					display: true,
					position: "top",
				},
				tooltip: {
					mode: "index",
					intersect: false,
				},
			},
		},
	});
}

function generateGraph(canvas, data) {
	if (!data) {
		console.error("No data for graph");
		return;
	}
	// When creating the chart, store the original dates
	const dates = data.map((d) => new Date(d.hour_slot));
	const chart = new Chart(canvas, {
		type: "bar",
		data: {
			labels: data.map((d) => {
				const date = new Date(d.hour_slot);
				return date.toLocaleString("en-US", { weekday: "long" }) + " " + date.getHours() + ":00";
			}),
			_source_dates: dates, // Store the original dates here
			datasets: [
				{
					label: "Items",
					data: data.map((d) => d.item_count),
					tension: 0.1,
				},
			],
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			scales: {
				y: {
					beginAtZero: true,
				},
				x: {
					grid: {
						display: false,
					},
					ticks: {
						callback: function (value, index) {
							const date = new Date(data[index].hour_slot);
							return date.toLocaleString("en-US", { weekday: "short" }) + " " + date.getHours() + ":00";
						},
					},
				},
			},
			interaction: {
				mode: "index", // Show tooltip for all elements at the same index (X-axis)
				intersect: false, // Allow hover even if not directly intersecting the bar
			},
			plugins: {
				tooltip: {
					mode: "index",
					intersect: false,
				},
				legend: {
					display: true,
				},
				customBackground: true, // Enable the custom background plugin
			},
		},
	});
}

function generateStackedGraph(canvas, dataRFY, dataAFA, dataAI, dataALL) {
	if (!dataRFY || !dataAFA || !dataAI || !dataALL) {
		console.error("No data for graph");
		return;
	}
	// When creating the chart, store the original dates
	const dates = dataRFY.map((d) => new Date(d.hour_slot));
	const chart = new Chart(canvas, {
		type: "bar",
		data: {
			labels: dataRFY.map((d) => {
				const date = new Date(d.hour_slot);
				return date.toLocaleString("en-US", { weekday: "long" }) + " " + date.getHours() + ":00";
			}),
			_source_dates: dates, // Store the original dates here
			datasets: [
				{
					label: "AI Items",
					data: dataAI.map((d) => d.item_count),
					backgroundColor: "rgba(75, 192, 192, 0.8)",
					borderColor: "rgb(75, 192, 192)",
					borderWidth: 1,
				},
				{
					label: "AFA Items",
					data: dataAFA.map((d) => d.item_count),
					backgroundColor: "rgba(54, 162, 235, 0.8)",
					borderColor: "rgb(54, 162, 235)",
					borderWidth: 1,
				},
				{
					label: "RFY Items",
					data: dataRFY.map((d) => d.item_count),
					backgroundColor: "rgba(255, 99, 132, 0.8)",
					borderColor: "rgb(255, 99, 132)",
					borderWidth: 1,
				},
				{
					label: 'Items from the "ALL" queue',
					data: dataALL.map((d) => d.item_count),
					backgroundColor: "rgba(153, 102, 255, 0.8)",
					borderColor: "rgb(153, 102, 255)",
					borderWidth: 1,
				},
			],
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			scales: {
				y: {
					beginAtZero: true,
					stacked: true,
				},
				x: {
					grid: {
						display: false,
					},
					stacked: true,
					ticks: {
						callback: function (value, index) {
							const date = new Date(dataRFY[index].hour_slot);
							return date.toLocaleString("en-US", { weekday: "short" }) + " " + date.getHours() + ":00";
						},
					},
				},
			},
			interaction: {
				mode: "index", // Show tooltip for all elements at the same index (X-axis)
				intersect: false, // Allow hover even if not directly intersecting the bar
			},
			plugins: {
				tooltip: {
					mode: "index",
					intersect: false,
				},
				legend: {
					display: true,
				},
				customBackground: true, // Enable the custom background plugin
			},
		},
	});
}

function displayError(message) {
	const container = document.getElementById("vh-item-explorer-content");
	// Clear existing content safely
	container.replaceChildren();

	// Create new elements safely
	const div = document.createElement("div");
	div.className = "notice";
	div.textContent = message;
	container.appendChild(div);
}

function initTabs(tabSelector, tabContainerSelector) {
	//Bind the click event for the tabs
	document.querySelectorAll(`${tabSelector} > ul li`).forEach(function (item) {
		item.onclick = function (event) {
			event.preventDefault();
			const currentTab = this.querySelector("a").href.split("#").pop();
			selectTab(currentTab, tabSelector, tabContainerSelector);
			this.classList.add("active");
			return false;
		};
	});
	//Set the first tab as active
	document.querySelector(`${tabSelector} > ul li:first-child`).click();
}

function selectTab(selectedTab, tabSelector, tabContainerSelector) {
	//Hide all tabs
	document.querySelectorAll(`${tabContainerSelector} .tab`).forEach(function (item) {
		item.style.display = "none";
	});

	document.querySelectorAll(`${tabSelector} > ul li`).forEach(function (item) {
		item.classList.remove("active");
	});

	//Display the current tab
	document.querySelector("#" + selectedTab).style.display = "block";
}
