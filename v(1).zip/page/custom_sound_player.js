import { loadLibrary, createPlaybackObjectUrl } from "/scripts/core/services/CustomSoundLibrary.js";

const params = new URLSearchParams(location.search);
const soundValue = params.get("sound");
const volume = Number(params.get("volume") ?? 1);

function notifyEnded() {
	window.parent.postMessage({ type: "vh-custom-sound-ended" }, "*");
}

async function playSound() {
	if (!soundValue) {
		notifyEnded();
		return;
	}

	const library = await loadLibrary();
	const src = createPlaybackObjectUrl(library, soundValue);
	if (!src) {
		notifyEnded();
		return;
	}

	const audio = new Audio(src);
	const cleanup = () => {
		if (src.startsWith("blob:")) {
			URL.revokeObjectURL(src);
		}
		notifyEnded();
	};
	audio.addEventListener("ended", cleanup);
	audio.addEventListener("error", cleanup);
	if (volume >= 0 && volume <= 1) {
		audio.volume = volume;
	}
	try {
		await audio.play();
	} catch {
		cleanup();
	}
}

void playSound();
