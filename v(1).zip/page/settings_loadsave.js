import { SettingsMgr } from "/scripts/core/services/SettingsMgr.js";
const Settings = new SettingsMgr();

import { Environment } from "/scripts/core/services/Environment.js";
const env = new Environment();

import { Internationalization, getMessageOrDefault } from "/scripts/core/services/Internationalization.js";
const i18n = new Internationalization();

import { HiddenListMgr } from "/scripts/core/services/HiddenListMgr.js";
var HiddenList = new HiddenListMgr();

import { DeviceFingerprintMgr } from "/scripts/core/services/DeviceFingerprintMgr.js";
var fingerprintMgr = new DeviceFingerprintMgr(Settings);

import { DeviceMgr } from "/scripts/core/services/DeviceMgr.js";
var deviceMgr = new DeviceMgr(Settings);

import { CryptoKeys } from "/scripts/core/utils/CryptoKeys.js";
var cryptoKeys = new CryptoKeys();

import { isSafari } from "/scripts/core/utils/BrowserDetection.js";
import { getMinutesUsed } from "/scripts/core/utils/MetricStorage.js";

import { runKeywordTest } from "./components/keywords/KeywordTesting.js";

// Import form control managers
import {
	manageCheckboxSetting,
	manageInputText,
	manageTextarea,
	manageRadio,
	manageTimeSetting,
	manageColorPicker,
	manageSlider,
	manageSelectBox,
	manageSoundSelectBox,
	manageCustomSoundLibraryButton,
	manageSelectVoice,
	managePlayButton,
	manageDualRangeSlider,
} from "./components/controls/FormControls.js";

// Import dialog utilities
import {
	confirmPrompt,
	confirmDataPreview,
	selectKeywordTypePrompt,
	displayMultiLinePopup,
} from "./components/dialogs/DialogUtils.js";

import { buildAnonymizedPreview, submitIfDue } from "/scripts/core/services/SettingsAnalytics.js";
import { AMAZON_ADDRESS_BOOK } from "/scripts/core/amazon/selectors.js";

// Import utility functions
import { rankSuffix } from "./utils/SettingsUtils.js";

/**
 * Resolve country/CID for contribution stats using the same persisted identity
 * as monitor/API calls (CID is authoritative when present).
 */
async function resolveContributionStatsIdentity() {
	const country = Settings.get("general.country") || i18n.getCountryCode();
	let cid = Settings.get("general.cid", false);
	if (!cid || typeof cid !== "string" || cid.length !== 64) {
		const computed = await env.getCID();
		if (computed && typeof computed === "string" && computed.length === 64) {
			cid = computed;
		} else {
			cid = null;
		}
	}
	return { country, cid };
}

function renderContributionStats(data) {
	const itemsFound = document.getElementById("itemsFound");
	const itemsFoundRank = document.getElementById("itemsFoundRank");
	const etvFound = document.getElementById("etvFound");
	const etvFoundRank = document.getElementById("etvFoundRank");

	const naLabel = getMessageOrDefault("statsNotAvailableLabel", "N/A");
	if (itemsFound) {
		itemsFound.textContent = data.items_found == undefined ? naLabel : data.items_found;
	}
	if (itemsFoundRank) {
		itemsFoundRank.textContent =
			data.items_found_rank == undefined ? naLabel : data.items_found_rank + rankSuffix(data.items_found_rank);
	}
	if (etvFound) {
		etvFound.textContent = data.etv_found == undefined ? naLabel : data.etv_found;
	}
	if (etvFoundRank) {
		etvFoundRank.textContent =
			data.etv_found_rank == undefined ? naLabel : data.etv_found_rank + rankSuffix(data.etv_found_rank);
	}
}

function renderLinkedDevices(devices) {
	const deviceList = document.getElementById("devicesLinkedToUUID");
	if (!deviceList) {
		return;
	}
	deviceList.replaceChildren();

	if (!Array.isArray(devices)) {
		return;
	}

	devices.forEach((device) => {
		const listItem = document.createElement("li");
		listItem.className = "device-item";
		listItem.dataset.id = device.id;

		listItem.appendChild(document.createTextNode(device.name + " ("));

		const unlinkLink = document.createElement("a");
		unlinkLink.href = "#";
		unlinkLink.className = "delete_device";
		unlinkLink.dataset.id = device.id;
		unlinkLink.dataset.name = device.name;
		unlinkLink.textContent = "unlink";
		listItem.appendChild(unlinkLink);

		listItem.appendChild(document.createTextNode(")"));
		deviceList.appendChild(listItem);
	});

	document.querySelectorAll(".delete_device").forEach((item) => {
		item.onclick = async function (e) {
			e.preventDefault();
			const deviceName = item.dataset.name;
			if (confirm("Unlink device " + deviceName + " from this UUID?")) {
				await fingerprintMgr.deleteDevice(item.dataset.id);
				const deviceItem = document.querySelector(`.device-item[data-id="${item.dataset.id}"]`);
				if (deviceItem) {
					deviceItem.remove();
				}
			}
		};
	});
}

/**
 * Fetch and display contribution stats for the About / Server tabs.
 * Refreshes when the About tab is opened so counts stay current.
 */
async function loadUserContributionStats() {
	if (!Settings.get("general.uuid", false)) {
		return;
	}

	const { country, cid } = await resolveContributionStatsIdentity();
	const content = {
		api_version: 5,
		app_version: env.data.appVersion,
		action: "get_user_stats",
		country,
		uuid: Settings.get("general.uuid", false),
		fid: Settings.get("general.fingerprint.id", false),
		cid,
	};
	const s = await cryptoKeys.signData(content);
	content.s = s;
	content.pk = await cryptoKeys.getExportedPublicKey();

	try {
		const response = await fetch(env.getAPIUrl(), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(content),
		});
		const data = await response.json();
		if (!response.ok || data.error) {
			console.warn("[settings] Failed to load contribution stats:", data.error || response.status);
			return;
		}

		if (data.resolved_uuid && data.resolved_uuid !== Settings.get("general.uuid", false)) {
			await Settings.set("general.uuid", data.resolved_uuid);
			const uuidInput = document.getElementById("generaluuid");
			if (uuidInput) {
				uuidInput.value = data.resolved_uuid;
			}
			if (data.uuid_mismatch) {
				console.info("[settings] Synced local UUID to server account resolved from CID:", data.resolved_uuid);
			}
		}

		renderContributionStats(data);
		renderLinkedDevices(data.devices);
	} catch (error) {
		console.warn("[settings] Failed to load contribution stats:", error);
	}
}

// Import keyword groups management
import {
	manageKeywordGroups,
	renderKeywordGroups,
	saveGroupKeywords,
	moveGroup,
	showAddGroupDialog,
	showKeywordNoteDialog,
} from "./components/keywords/KeywordGroupsUI.js";

// Import keyword drag and drop
import { initKeywordDragAndDrop } from "./components/keywords/KeywordDragAndDrop.js";

// Favourite categories (assisted load)
import { initFavouriteCategoriesSettingsUI } from "./components/favourites/FavouriteCategoriesSettingsUI.js";

const FULL_SETTINGS_RELOAD_KEYS = new Set([
	"general.country",
	"general.patreon.tier",
	"general.theme",
	"i18n.localeOverride",
]);

/** Runtime-only settings keys with no form control on this page. */
const SETTINGS_PAGE_IGNORE_PATH_PREFIXES = ["general.cid", "checkout.current", "checkout.arrCurrentCheckouts"];

function isIgnoredSettingsChangePath(path) {
	if (!path) return false;
	return SETTINGS_PAGE_IGNORE_PATH_PREFIXES.some((prefix) => path === prefix || path.startsWith(`${prefix}.`));
}

function shouldForceFullSettingsReload(changedPaths = []) {
	return changedPaths.some((path) => {
		if (!path) return true;
		if (FULL_SETTINGS_RELOAD_KEYS.has(path)) return true;
		if (path.startsWith("general.keywordGroups")) return true;
		return false;
	});
}

function syncSettingControlValue(key) {
	if (!key) return false;

	const keyEscaped = CSS.escape(key);
	const value = Settings.get(key);
	let updated = false;

	const textarea = document.querySelector(`textarea[name='${keyEscaped}']`);
	if (textarea) {
		textarea.value = value == null ? "" : String(value);
		updated = true;
	}

	const checkbox = document.querySelector(`input[type='checkbox'][name='${keyEscaped}']`);
	if (checkbox) {
		checkbox.checked = value === true;
		updated = true;
	}

	const radios = document.querySelectorAll(`input[type='radio'][name='${keyEscaped}']`);
	if (radios.length > 0) {
		radios.forEach((radio) => {
			radio.checked = String(radio.value) === String(value);
		});
		updated = true;
	}

	const directInput = document.querySelector(`input[name='${keyEscaped}']`);
	if (directInput && directInput.type !== "checkbox" && directInput.type !== "radio") {
		directInput.value = value == null ? "" : String(value);
		updated = true;
	}

	const wrappedInput = document.querySelector(`label[for='${keyEscaped}'] input`);
	if (
		wrappedInput &&
		wrappedInput.type !== "checkbox" &&
		wrappedInput.type !== "radio" &&
		wrappedInput.type !== "range"
	) {
		wrappedInput.value = value == null ? "" : String(value);
		updated = true;
	}

	const selectWrapped = document.querySelector(`label[for='${keyEscaped}'] select`);
	if (selectWrapped) {
		selectWrapped.value = value == null ? "" : String(value);
		updated = true;
	}

	const selectDirect = document.querySelector(`select[name='${keyEscaped}']`);
	if (selectDirect) {
		selectDirect.value = value == null ? "" : String(value);
		updated = true;
	}

	return updated;
}

function applyExternalSettingsDelta(changedPaths = []) {
	if (!Array.isArray(changedPaths) || changedPaths.length === 0) {
		return false;
	}

	for (const key of changedPaths) {
		if (!syncSettingControlValue(key)) {
			return false;
		}
	}

	if (changedPaths.some((key) => key.startsWith("discord."))) {
		void drawDiscord();
	}
	if (changedPaths.some((key) => key.startsWith("general.orderNow") || key === "general.skipPrimeAd")) {
		initCheckoutFlowPreview();
		initCheckoutRiskGate();
	}

	return true;
}

// Redraw when settings change in another tab/context (chrome.storage.local sync)
const unsubscribeSettingsChangeObserver = Settings.addSettingsChangeObserver((payload) => {
	const changedPaths = Array.isArray(payload?.changedPaths) ? payload.changedPaths : [];
	// In-memory settings already refreshed; diff unavailable when chrome.storage omits oldValue.
	if (changedPaths.length === 0) {
		return;
	}
	const relevantPaths = changedPaths.filter((path) => !isIgnoredSettingsChangePath(path));
	if (relevantPaths.length === 0) {
		return;
	}
	if (shouldForceFullSettingsReload(relevantPaths)) {
		void initiateSettings(false);
		return;
	}
	if (applyExternalSettingsDelta(relevantPaths)) {
		return;
	}
	void initiateSettings(false);
});

function cleanupSettingsPageObservers() {
	unsubscribeSettingsChangeObserver();
	if (typeof Settings.dispose === "function") {
		Settings.dispose();
	}
}

window.addEventListener("pagehide", cleanupSettingsPageObservers, { once: true });
async function drawDiscord() {
	//Show or hide the discord options
	const discordOptions = document.querySelector("#discordOptions");
	if (!discordOptions) return; // Element doesn't exist (e.g., in popup mode)

	discordOptions.style.display = Settings.get("discord.active") ? "block" : "none";

	if (Settings.get("discord.active")) {
		let showLink = Settings.get("discord.guid", false) === null;

		const guidLink = document.querySelector("#discord-guid-link");
		const guidUnlink = document.querySelector("#discord-guid-unlink");
		if (guidLink) guidLink.style.display = showLink ? "block" : "none";
		if (guidUnlink) guidUnlink.style.display = showLink ? "none" : "block";
	}
}

function initCheckoutFlowPreview() {
	const container = document.getElementById("checkout-flow-preview");
	if (!container) return;

	function updatePreview() {
		const orderNow = document.querySelector('input[name="general.orderNow.active"]')?.checked ?? false;
		const skipPrime = document.querySelector('input[name="general.skipPrimeAd"]')?.checked ?? false;
		const skipConfirm = document.querySelector('input[name="general.orderNow.skipConfirmOrder"]')?.checked ?? false;
		const parallel = document.querySelector('input[name="general.orderNow.parallelCheckout"]')?.checked ?? false;

		container.querySelector('[data-step="variants"]')?.classList.toggle("checked", orderNow);
		container.querySelector('[data-step="see-details"]')?.classList.toggle("checked", orderNow);
		container.querySelector('[data-step="voice-order"]')?.classList.toggle("checked", orderNow);
		container.querySelector('[data-step="submit-form"]')?.classList.toggle("checked", orderNow);
		container.querySelector('[data-step="prime-ad"]')?.classList.toggle("checked", skipPrime);
		container.querySelector('[data-step="confirm-order"]')?.classList.toggle("checked", skipConfirm);
		container.classList.toggle("parallel-layout", parallel);
	}

	updatePreview();

	[
		"general.orderNow.active",
		"general.skipPrimeAd",
		"general.orderNow.skipConfirmOrder",
		"general.orderNow.parallelCheckout",
	].forEach((name) => {
		const input = document.querySelector(`input[name="${name}"]`);
		if (input && !input._checkoutPreviewListener) {
			input._checkoutPreviewListener = updatePreview;
			input.addEventListener("change", updatePreview);
		}
	});
}

function syncLegendControlledFieldsets() {
	document.querySelectorAll("fieldset").forEach((fieldset) => {
		const checkbox = fieldset.querySelector(':scope > legend input[type="checkbox"]');
		if (!checkbox) return;

		if (typeof checkbox._VHelperToggleHandler === "function") {
			checkbox._VHelperToggleHandler();
		}
	});
}

const CHECKOUT_RISK_ACCEPTED_KEY = "checkout.riskAcceptedAt";

function initCheckoutRiskGate() {
	const gatedEl = document.getElementById("checkout-settings-gated");
	const linkEl = document.getElementById("checkout-risk-ack-link");
	const dateEl = document.getElementById("checkout-risk-ack-date");
	if (!gatedEl || !linkEl || !dateEl) return;

	const acceptedAt = Settings.get(CHECKOUT_RISK_ACCEPTED_KEY);
	if (acceptedAt) {
		gatedEl.classList.remove("gated");
		linkEl.style.display = "none";
		dateEl.style.display = "inline";
		const d = new Date(acceptedAt);
		const prefix = getMessageOrDefault("settingsCheckoutRiskAcceptedPrefix", "Risk accepted on ");
		dateEl.textContent = prefix + d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
	} else {
		gatedEl.classList.add("gated");
		linkEl.style.display = "inline";
		dateEl.style.display = "none";
		dateEl.textContent = "";
	}

	if (linkEl.dataset.riskListener === "1") return;
	linkEl.dataset.riskListener = "1";
	function acceptRisks() {
		Settings.set(CHECKOUT_RISK_ACCEPTED_KEY, new Date().toISOString());
		initCheckoutRiskGate();
	}
	linkEl.addEventListener("click", acceptRisks);
	linkEl.addEventListener("keydown", (e) => {
		if (e.key === "Enter" || e.key === " ") {
			e.preventDefault();
			acceptRisks();
		}
	});
}

function ensureCheckoutTabBound() {
	initCheckoutRiskGate();
	manageCheckboxSetting("general.orderNow.active");
	manageCheckboxSetting("general.skipPrimeAd");
	manageCheckboxSetting("general.orderNow.skipConfirmOrder");
	manageCheckboxSetting("general.orderNow.parallelCheckout");
	manageSelectBox("general.orderNow.preferredAddressId");
	manageSelectBox("general.orderNow.shippingPriority");
	initAddressSelector();
	initCheckoutFlowPreview();
}

async function initAddressSelector() {
	const selectBtn = document.getElementById("refresh-address-btn");
	const statusSpan = document.getElementById("refresh-address-status");
	const selectBox = document.getElementById("general.orderNow.preferredAddressId");

	if (!selectBtn || !selectBox) return;

	if (selectBtn.dataset.bound) return; // Prevent multiple bindings
	selectBtn.dataset.bound = "true";

	// Ensure the dropdown shows the saved preferred address ID by default,
	// even before loading the address list from Amazon.
	const savedVal = Settings.get("general.orderNow.preferredAddressId");
	if (savedVal) {
		let existing = Array.from(selectBox.options).some((opt) => opt.value === savedVal);
		if (!existing) {
			const opt = document.createElement("option");
			opt.value = savedVal;
			opt.textContent = getMessageOrDefault("pageSettingsCheckoutAddressIdLabel", "Address ID: $1$", [savedVal]);
			selectBox.appendChild(opt);
		}
		selectBox.value = savedVal;
	}

	// Define the fetch flow that populates the dropdown when the user requests it.
	const loadAddresses = async () => {
		if (statusSpan) {
			statusSpan.classList.remove("vh-hidden");
			statusSpan.textContent = getMessageOrDefault("pageSettingsCheckoutFetchingAddresses", "Fetching...");
		}
		selectBtn.disabled = true;

		try {
			// First, wait for i18n to load the domain
			const domain = i18n.getDomainTLD() || "com";
			const url = `https://www.amazon.${domain}/a/addresses`;

			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Fetching addresses from:", url, "domain:", domain);
			}

			const resp = await fetch(url, {
				method: "GET",
				mode: "cors",
				credentials: "include",
				headers: {
					accept: "text/html",
				},
			});

			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Address fetch response status:", resp.status, resp.statusText);
			}

			if (!resp.ok) {
				throw new Error("HTTP " + resp.status);
			}

			const html = await resp.text();
			const parser = new DOMParser();
			const doc = parser.parseFromString(html, "text/html");

			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Address page HTML length:", html.length);
			}

			// Extract addresses
			const editLinks = doc.querySelectorAll(AMAZON_ADDRESS_BOOK.EDIT_LINK);

			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Found", editLinks.length, "editLinks with addressID=");
			}
			const uniqueAddresses = new Map();

			editLinks.forEach((link) => {
				const linkUrl = new URL(link.href, url);
				const addressID = linkUrl.searchParams.get("addressID");
				if (addressID && !uniqueAddresses.has(addressID)) {
					// Find a descriptive container. Usually next to or containing the link.
					// Amazon typically places addresses in a box with `.displayAddressFullName`
					// or `.address-column`. We can find the closest generic container.
					const container = link.closest(".a-box-inner") || link.closest(".a-column") || link.parentElement;
					let label = `Address ${addressID}`;
					if (container) {
						// Grab text but exclude the bottom buttons (Edit, Delete, Set as Default)
						const spanNames = container.querySelectorAll(AMAZON_ADDRESS_BOOK.LABEL_PARTS);
						if (spanNames.length > 0) {
							label = Array.from(spanNames)
								.map((el) => el.innerText.trim())
								.join(", ");
						} else {
							// fallback: grab first few lines
							const lines = container.innerText
								.split("\n")
								.map((l) => l.trim())
								.filter((l) => l && l !== "Edit" && l !== "Remove" && l !== "Set as Default");
							if (lines.length > 0) {
								label = lines.slice(0, 4).join(", "); // Country is usually line 4
							}
						}
					}

					// Cut off at "Phone number:" if it somehow got included
					const phoneIndex = label.indexOf("Phone number:");
					if (phoneIndex !== -1) {
						label = label.substring(0, phoneIndex).trim();
						if (label.endsWith(",")) label = label.substring(0, label.length - 1).trim();
					}

					// Detect if Amazon flagged this as the default address
					let isDefault = /^Default:\s*[,|]?\s*[|,]?\s*/i.test(label);

					// Clean up the weird prefix that Amazon sometimes renders for the default address
					label = label.replace(/^Default:/i, "").replace(/^[,\s|]+/, "");

					if (isDefault) {
						const defaultSuffix = getMessageOrDefault(
							"pageSettingsCheckoutAddressSuffixDefault",
							"(Default)"
						);
						label = label + " " + defaultSuffix;
					}

					// Shorten if too long
					if (label.length > 100) label = label.substring(0, 97) + "...";

					uniqueAddresses.set(addressID, label);
				}
			});

			// Also try ID-based extraction as fallback
			const addressBlocks = doc.querySelectorAll("[id^='address-ui-widgets-AddressId_']");

			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Found", addressBlocks.length, "addressBlocks with AddressId_ prefix");
			}

			addressBlocks.forEach((block) => {
				const idMatch = block.id.match(/address-ui-widgets-AddressId_([a-zA-Z0-9]+)/);
				if (idMatch && idMatch[1] && !uniqueAddresses.has(idMatch[1])) {
					const id = idMatch[1];
					const nameEl = block.querySelector(
						".address-ui-widgets-desktop-delivery-instructions-container"
					)?.previousElementSibling;
					let label = `Address ${id}`;
					if (nameEl && nameEl.innerText) {
						label = nameEl.innerText.replace(/\n/g, ", ").trim();
					} else {
						const allText = block.innerText.replace(/\n+/g, ", ");
						if (allText) label = allText.substring(0, 100);
					}

					// Cut off at "Phone number:"
					const phoneIndex = label.indexOf("Phone number:");
					if (phoneIndex !== -1) {
						label = label.substring(0, phoneIndex).trim();
						if (label.endsWith(",")) label = label.substring(0, label.length - 1).trim();
					}

					// Detect if Amazon flagged this as the default address
					let isDefault = /^Default:\s*[,|]?\s*[|,]?\s*/i.test(label);

					// Clean up the weird prefix that Amazon sometimes renders for the default address
					label = label.replace(/^Default:/i, "").replace(/^[,\s|]+/, "");

					if (isDefault) {
						const defaultSuffix = getMessageOrDefault(
							"pageSettingsCheckoutAddressSuffixDefault",
							"(Default)"
						);
						label = label + " " + defaultSuffix;
					}

					if (label.length > 100) label = label.substring(0, 97) + "...";
					uniqueAddresses.set(id, label);
				}
			});

			// Clear existing options except default
			while (selectBox.options.length > 1) {
				selectBox.remove(1);
			}

			if (Settings.get("general.debugCheckout")) {
				console.log("VH Debug [Checkout]: Total unique addresses extracted:", uniqueAddresses.size);
				for (const [id, label] of uniqueAddresses.entries()) {
					console.log("VH Debug [Checkout]: Address ID:", id, "Label:", label);
				}
			}

			if (uniqueAddresses.size === 0) {
				const msg = getMessageOrDefault(
					"pageSettingsCheckoutNoAddressesSession",
					"No addresses found. Are you logged in?"
				);
				throw new Error(msg);
			}

			for (const [id, label] of uniqueAddresses.entries()) {
				const opt = document.createElement("option");
				opt.value = id;
				opt.textContent = label;
				selectBox.appendChild(opt);
			}

			// Re-apply setting since options were just constructed
			const savedVal = Settings.get("general.orderNow.preferredAddressId");
			if (savedVal) {
				selectBox.value = savedVal;
			}

			if (statusSpan) {
				const foundMsg = getMessageOrDefault(
					"pageSettingsCheckoutFoundAddresses",
					"Found " + uniqueAddresses.size + " addresses.",
					[uniqueAddresses.size.toString()]
				);
				statusSpan.textContent = foundMsg;
				setTimeout(() => {
					if (statusSpan) statusSpan.classList.add("vh-hidden");
				}, 3000);
			}
		} catch (e) {
			if (statusSpan) {
				const errMsg = getMessageOrDefault("pageSettingsCheckoutErrorFetching", "Error: " + e.message, [
					e.message,
				]);
				statusSpan.textContent = errMsg;
			}
			console.error("Failed to fetch Amazon addresses:", e);
		} finally {
			selectBtn.disabled = false;
		}
	};

	selectBtn.addEventListener("click", (e) => {
		e.preventDefault();
		loadAddresses();
	});
}

async function initiateSettings(firstRun = false) {
	//Wait for the settings to be loaded.
	await Settings.waitForLoad();

	//If the browser is firefox, replace all the input[type="color"] with input[type="text"]
	if (navigator.userAgent.includes("Firefox") && typeof window.popupView !== "undefined") {
		document.querySelectorAll("input[type='color']").forEach(function (item) {
			item.type = "text";
		});
	}

	//Handle premium feature access
	[1, 2, 3].forEach((tier) => {
		if (!Settings.isPremiumUser(tier)) {
			document
				.querySelectorAll(
					`.premium-feature-${tier} input, .premium-feature-${tier} select, .premium-feature-${tier} button, .premium-feature-${tier} textarea`
				)
				.forEach((item) => {
					item.disabled = true;
				});
		}
	});

	const tierLevel = Settings.get("general.patreon.tier");

	const tierCharacters = {
		0: { image: "character-tier-0.png" },
		1: { image: "character-tier-1.png" },
		2: { image: "character-tier-2.png" },
		3: { image: "character-tier-3.png" },
	};
	const premiumTierElement = document.getElementById("premiumTier");
	if (premiumTierElement) {
		premiumTierElement.textContent = getMessageOrDefault(
			"tierCharacter" + tierLevel + "Name",
			tierLevel === 0
				? "Commoner"
				: tierLevel === 1
					? "Omni Curator"
					: tierLevel === 2
						? "Gearmancer"
						: "Antiquarian Scout"
		);
	}
	const premiumCharacterElement = document.getElementById("premiumCharacter");
	if (premiumCharacterElement) {
		premiumCharacterElement.src = chrome.runtime.getURL("resource/image/" + tierCharacters[tierLevel].image);
	}
	const patreonCharacterDescriptionElement = document.getElementById("patreonCharacterDescription");
	if (patreonCharacterDescriptionElement) {
		const descKey = "tierCharacter" + tierLevel + "Description";
		const descDefault =
			tierLevel === 0
				? "The Commoner weaves through the bustling market, blending with the crowd. Keen-eyed and shrewd, they know every deal, every shortcut, and every hidden gem."
				: tierLevel === 1
					? "The Omni Curator shops with masterful precision, crafting lists like enchanted scrolls. Every item chosen holds purpose, every purchase a step toward perfection."
					: tierLevel === 2
						? "The Gearmancer strides through the market, armed with precision tools for every task. No gadget is too rare, no mechanism beyond their mastery."
						: "The Antiquarian Scout navigates the market with wisdom, one of the rare few granted access to the hidden archives where secrets of past wares reside.";
		patreonCharacterDescriptionElement.textContent = getMessageOrDefault(descKey, descDefault);
	}

	[0, 1, 2, 3].forEach((tier) => {
		const el = document.getElementById(`patreonLevelbarTier${tier}`);
		if (!el) return;
		el.classList.remove("filled0", "filled1", "filled2", "filled3", "locked", "active");
		if (tierLevel >= tier) {
			el.classList.add(`filled${tier}`);
			if (tierLevel === tier) {
				el.classList.add("active");
			}
		} else {
			el.classList.add("locked");
		}
	});
	const levelbar = document.querySelector(".patreonLevelbar");
	if (levelbar) {
		const overlay = levelbar.querySelector(".patreonLevelbar-overlay");
		const unlockedCount = levelbar.querySelectorAll(".patreonLevelbarSegment[class*='filled']").length;
		if (overlay) {
			overlay.style.width = unlockedCount > 0 ? `${(unlockedCount / 4) * 100}%` : "0";
		}
	}

	//Handle removing push notifications for safari
	try {
		if (!isSafari()) {
			chrome.permissions.contains({ permissions: ["notifications"] }, (result) => {
				if (!result) {
					document.querySelector("#notification.pushNotifications").disabled = true;
					document.querySelector("#notification.pushNotificationsAFA").disabled = true;
				}
			});
		}
	} catch (err) {
		//Do nothing.
	}

	//Show the usage time in days and hours (chrome.storage.local metric, migrated from legacy settings once)
	const minutesUsed = await getMinutesUsed(Settings);
	const days = Math.floor(minutesUsed / 1440);
	const hours = Math.floor((minutesUsed % 1440) / 60);
	const minutes = minutesUsed % 60;

	// Update Premium page usage display (legacy format)
	const usageTimeElement = document.getElementById("usageTime");
	if (usageTimeElement) {
		usageTimeElement.textContent = getMessageOrDefault(
			"usageTimeLegacyFormat",
			days + " day(s) and " + hours + " hour(s) and " + minutes + " minute(s)",
			[String(days), String(hours), String(minutes)]
		);
	}

	// Update Premium page usage display (new format)
	const premiumDaysElement = document.getElementById("premiumUsageDays");
	const premiumHoursElement = document.getElementById("premiumUsageHours");
	const premiumMinutesElement = document.getElementById("premiumUsageMinutes");
	if (premiumDaysElement) {
		premiumDaysElement.textContent = days;
	}
	if (premiumHoursElement) {
		premiumHoursElement.textContent = hours;
	}
	if (premiumMinutesElement) {
		premiumMinutesElement.textContent = minutes;
	}

	// Update Popup page usage display
	const popupDaysElement = document.getElementById("popupUsageDays");
	const popupHoursElement = document.getElementById("popupUsageHours");
	const popupMinutesElement = document.getElementById("popupUsageMinutes");
	if (popupDaysElement) {
		popupDaysElement.textContent = days;
	}
	if (popupHoursElement) {
		popupHoursElement.textContent = hours;
	}
	if (popupMinutesElement) {
		popupMinutesElement.textContent = minutes;
	}

	//Get the user's stats from the API
	await loadUserContributionStats();

	drawDiscord();

	const settingsLink = document.getElementById("settingsLink");
	if (settingsLink) {
		settingsLink.href = chrome.runtime.getURL("page/settings.html");
	}

	//###################
	//#### UI interaction

	//When a checkbox in the legend of a fieldset if changed,
	//enable or disable all the field contained in that fieldset.
	document.querySelectorAll("fieldset").forEach((fieldset) => {
		const checkbox = fieldset.querySelector(':scope > legend input[type="checkbox"]');

		if (checkbox) {
			// Function to enable/disable the fieldset contents
			const toggleFieldsetContent = () => {
				const isChecked = checkbox.checked;
				const elements = fieldset.querySelectorAll("input, select, button, textarea");

				elements.forEach((element) => {
					// Skip the checkbox itself in the legend
					if (element !== checkbox) {
						// Check if element or its parent has a premium-feature class
						let premiumParent = element.closest(
							".premium-feature-1, .premium-feature-2, .premium-feature-3"
						);
						let shouldDisable = !isChecked;

						if (premiumParent) {
							// Extract tier number from the class (e.g., "premium-feature-2" -> 2)
							const tierMatch = premiumParent.className.match(/premium-feature-([123])/);
							if (tierMatch) {
								const tier = parseInt(tierMatch[1], 10);
								// If user doesn't have access to this tier, keep it disabled
								if (!Settings.isPremiumUser(tier)) {
									shouldDisable = true;
								}
							}
						}

						element.disabled = shouldDisable;
					}
				});
			};

			// Add the event listener to the checkbox
			// Store event listener reference to prevent duplicates
			if (!checkbox._VHelperToggleHandler) {
				checkbox._VHelperToggleHandler = toggleFieldsetContent;
				checkbox.addEventListener("change", checkbox._VHelperToggleHandler);
			}

			// Initial state check
			toggleFieldsetContent();
		}
	});

	//###################
	//## Load/save settings:

	//## TAB - GENERAL

	manageSelectBox("i18n.localeOverride");
	const localeSelect = document.getElementById("i18nLocaleOverride");
	if (
		localeSelect &&
		(Settings.get("i18n.localeOverride") === undefined || Settings.get("i18n.localeOverride") === null)
	) {
		localeSelect.value = "";
	}
	if (localeSelect && !localeSelect._VHelperLocaleReload) {
		localeSelect._VHelperLocaleReload = true;
		localeSelect.addEventListener("change", () => {
			location.reload();
		});
	}

	manageCheckboxSetting("i18n.24hrsFormat");

	manageCheckboxSetting("general.topPagination");
	manageCheckboxSetting("general.verbosePagination");
	manageCheckboxSetting("general.detailsIcon");
	manageCheckboxSetting("general.displayETV");
	manageCheckboxSetting("general.displayPrice");
	manageCheckboxSetting("general.carousel.active");
	manageCheckboxSetting("general.displayModalETV");
	manageCheckboxSetting("general.etvModalOnTop");
	manageCheckboxSetting("general.displayFullTitleTooltip");
	manageCheckboxSetting("general.displayVariantIcon");
	manageCheckboxSetting("general.displayVariantButton");
	manageCheckboxSetting("general.displayFirstSeen");
	manageCheckboxSetting("general.bookmark");
	manageCheckboxSetting("hiddenTab.active");
	manageCheckboxSetting("hiddenTab.scrollToRFY", false);
	manageCheckboxSetting("pinnedTab.active");
	manageCheckboxSetting("unavailableTab.active");
	manageCheckboxSetting("general.modalNavigation");
	manageCheckboxSetting("general.searchOpenModal");
	manageCheckboxSetting("general.listView");
	manageCheckboxSetting("general.forceCheckoutNewTab");
	manageCheckboxSetting("general.scrollToRFY");
	manageCheckboxSetting("general.hideOptOutButton");
	manageCheckboxSetting("general.hideRecommendations");
	manageCheckboxSetting("general.hideHeader");
	manageCheckboxSetting("general.hideFooter");
	manageCheckboxSetting("general.hideAssociateStripe");
	manageCheckboxSetting("general.hideSideCart");
	manageCheckboxSetting("general.hideCategoriesRFYAFA");
	manageCheckboxSetting("general.reviewToolbar");
	manageSelectBox("general.reviewToolbarMaxReviews");
	manageCheckboxSetting("general.hideReviewHighlights");
	manageCheckboxSetting("general.displayAccountExtraStats");
	manageCheckboxSetting("general.reviewSubmissionMarker");
	manageCheckboxSetting("general.reviewManager");
	manageCheckboxSetting("general.hideNoNews");
	manageCheckboxSetting("general.tileSize.enabled");
	manageCheckboxSetting("general.tileSize.active");
	manageCheckboxSetting("general.projectedAccountStatistics");
	manageCheckboxSetting("general.rollingVine");
	manageCheckboxSetting("general.discoveryFirst");
	manageCheckboxSetting("general.highlightKWFirst");
	manageColorPicker("general.bookmarkColor");
	manageCheckboxSetting("general.highlightColor.ignore0ETVhighlight");
	// Note: general.highlightColor.color is now only used as default for keyword groups
	manageCheckboxSetting("general.highlightColor.ignoreUnknownETVhighlight");
	manageCheckboxSetting("general.zeroETVHighlight.active");
	manageColorPicker("general.zeroETVHighlight.color");
	manageCheckboxSetting("general.unknownETVHighlight.active");
	manageColorPicker("general.unknownETVHighlight.color");
	manageColorPicker("general.toolbarBackgroundColor");
	manageSlider("general.ETV.modifier");

	//## TAB - CHECKOUT
	manageCheckboxSetting("general.skipPrimeAd");
	manageCheckboxSetting("general.displayNonZeroPriceWarning");
	manageCheckboxSetting("general.orderNow.active");
	manageColorPicker("general.orderNow.colorNonVariants");
	manageColorPicker("general.orderNow.colorVariants");
	manageCheckboxSetting("general.orderNow.skipConfirmOrder");
	manageCheckboxSetting("general.orderNow.parallelCheckout");
	initCheckoutFlowPreview();

	//## TAB - DEBUG
	manageCheckboxSetting("general.debugReactDevTools", false);
	manageCheckboxSetting("general.debugTabTitle");
	manageCheckboxSetting("general.debugPlaceholders");
	manageCheckboxSetting("general.debugTitleDisplay");
	manageCheckboxSetting("general.debugMemory");
	manageCheckboxSetting("general.debugMemoryAutoSnapshot");
	manageCheckboxSetting("general.debugKeywords", false);
	manageCheckboxSetting("general.debugBulkOperations", false);
	manageCheckboxSetting("general.debugTruncation", false);
	manageCheckboxSetting("general.debugWebsocket", false);
	manageCheckboxSetting("general.debugServercom", false);
	manageCheckboxSetting("general.debugServiceWorker", false);
	manageCheckboxSetting("general.debugSettings", false);
	manageCheckboxSetting("general.debugStorage", false);
	manageCheckboxSetting("general.debugSound", false);
	manageCheckboxSetting("general.debugCoordination", false);
	manageCheckboxSetting("general.debugWebhooks", false);
	manageCheckboxSetting("general.debugMonitorLog", false);
	manageCheckboxSetting("general.debugDuplicates", false);
	manageCheckboxSetting("general.debugVisibility", false);
	manageCheckboxSetting("general.debugItemProcessing", false);
	manageCheckboxSetting("general.debugTileCounter", false);
	manageCheckboxSetting("general.debugCheckout", false);
	manageCheckboxSetting("general.debugVersionLabel", false);

	//##TAB - NOTIFICATIONS

	manageCheckboxSetting("notification.active");
	manageCheckboxSetting("notification.pushNotifications");
	manageCheckboxSetting("notification.pushNotificationsAFA");
	manageCheckboxSetting("notification.monitor.listView");
	manageCheckboxSetting("notification.monitor.placeholders");
	manageCheckboxSetting("notification.monitor.carousel.active");
	manageCheckboxSetting("notification.hideList");
	manageCheckboxSetting("notification.monitor.hideGoldNotificationsForSilverUser");
	manageCheckboxSetting("notification.monitor.hideDuplicateThumbnail");
	manageCheckboxSetting("notification.monitor.hideAddsToHiddenList");
	manageCheckboxSetting("notification.monitor.passiveClears");
	manageCheckboxSetting("notification.monitor.autoClearUnavailableOnInitialFetch");
	manageCheckboxSetting("notification.reduce");
	manageCheckboxSetting("notification.monitor.zeroETV.colorActive");
	manageCheckboxSetting("notification.monitor.rfy.colorActive");
	manageCheckboxSetting("notification.monitor.v4.titleFontSmartColor");
	manageCheckboxSetting("notification.monitor.unknownETV.colorActive");
	manageCheckboxSetting("notification.monitor.highlight.ignore0ETVhighlight");
	manageCheckboxSetting("notification.monitor.highlight.ignoreUnknownETVhighlight");
	manageRadio("notification.monitor.openLinksInNewTab");
	manageRadio("notification.monitor.v3LiteOpenLinksInNewTab");
	manageRadio("notification.monitor.v4OpenLinksInNewTab");
	manageRadio("notification.monitor.topRightLinkTarget");
	manageRadio("notification.connectionMode");
	manageCheckboxSetting("notification.monitor.preventUnload");
	manageCheckboxSetting("notification.monitor.bump0ETV");
	manageCheckboxSetting("notification.monitor.mouseoverPause");
	manageCheckboxSetting("notification.monitor.pauseOverlay");
	manageCheckboxSetting("notification.monitor.wakeLock");
	manageCheckboxSetting("notification.autoload.rfyActive");
	manageTimeSetting("notification.autoload.hourStart", "00:00");
	manageTimeSetting("notification.autoload.hourEnd", "23:59");

	//Sliders
	// Note: notification.monitor.highlight.volume is now only used for keyword groups
	manageSlider("notification.monitor.regular.volume");
	manageSlider("notification.monitor.zeroETV.volume");
	manageSlider("notification.monitor.rfy.volume");
	manageSelectBox("notification.soundCooldownDelay");

	//Select boxes
	manageSelectBox("general.hiddenItemsCacheSize");
	manageSelectBox("general.verbosePaginationStartPadding");
	await manageSoundSelectBox("notification.monitor.regular.sound");
	// Note: notification.monitor.highlight.sound is now only used as default for keyword groups
	await manageSoundSelectBox("notification.monitor.zeroETV.sound");
	await manageSoundSelectBox("notification.monitor.rfy.sound");
	manageCustomSoundLibraryButton("manageCustomSounds");
	manageSelectVoice();

	//Play buttons
	managePlayButton(
		"playScreenNotification",
		"notification.screen.regular.sound",
		"notification.screen.regular.volume"
	);
	managePlayButton(
		"playMonitorZeroETVNotification",
		"notification.monitor.zeroETV.sound",
		"notification.monitor.zeroETV.volume"
	);
	managePlayButton("playMonitorRFYNotification", "notification.monitor.rfy.sound", "notification.monitor.rfy.volume");
	managePlayButton(
		"playMonitorRegularNotification",
		"notification.monitor.regular.sound",
		"notification.monitor.regular.volume"
	);

	manageColorPicker("notification.monitor.zeroETV.color");
	manageColorPicker("notification.monitor.rfy.color");
	manageColorPicker("notification.monitor.unknownETV.color");

	// Display on screen notifications settings
	manageCheckboxSetting("notification.screen.active");
	manageCheckboxSetting("notification.screen.thumbnail");
	manageInputText("notification.screen.position");
	await manageSoundSelectBox("notification.screen.regular.sound");
	manageSlider("notification.screen.regular.volume");

	//##TAB - SYSTEM
	manageCheckboxSetting("hiddenTab.remote");
	manageCheckboxSetting("pinnedTab.remote");
	manageCheckboxSetting("general.versionInfoPopup", false);
	manageCheckboxSetting("general.onboardingIncomplete");

	//Factory reset
	const factoryResetBtn = document.getElementById("factoryReset");
	if (factoryResetBtn && !factoryResetBtn._VHelperClickHandler) {
		factoryResetBtn._VHelperClickHandler = async function () {
			const defaultResetAllMessage =
				"SAVE YOUR UUID OR YOU WILL LOOSE YOUR REMOTE STORED ITEMS !\n\nReset all VHelper settings & local storage to default?";

			const confirmed = await confirmPrompt(
				getMessageOrDefault("settingsResetAllConfirm", defaultResetAllMessage)
			);

			if (confirmed) {
				await chrome.storage.local.clear();
				alert(
					getMessageOrDefault(
						"settingsResetAllDoneAlert",
						"All settings were deleted. RELOAD AMAZON VINE to restaure default settings.\nDO NOT EDIT OPTIONS before you reloaded an amazon vine page."
					)
				);
			}
		};
		factoryResetBtn.addEventListener("click", factoryResetBtn._VHelperClickHandler);
	}

	const hiddenItemResetBtn = document.getElementById("hiddenItemReset");
	if (hiddenItemResetBtn && !hiddenItemResetBtn._VHelperClickHandler) {
		hiddenItemResetBtn._VHelperClickHandler = async function () {
			const deleteLocalHiddenConfirm = await confirmPrompt(
				getMessageOrDefault(
					"settingsDeleteLocalHiddenConfirm",
					"Delete all locally stored hidden items from VHelper?"
				)
			);
			if (deleteLocalHiddenConfirm) {
				chrome.storage.local.set({ hiddenItems: [] });
				alert(
					getMessageOrDefault("settingsDeleteLocalHiddenDoneAlert", "Hidden items in local storage emptied.")
				);
			}
			const deleteRemoteHiddenConfirm = await confirmPrompt(
				getMessageOrDefault(
					"settingsDeleteRemoteHiddenConfirm",
					"Delete all remotely stored hidden items from VHelper?"
				)
			);
			if (deleteRemoteHiddenConfirm) {
				const content = {
					api_version: 5,
					app_version: env.data.appVersion,
					action: "save_hidden_list",
					country: Settings.get("general.country", false),
					uuid: Settings.get("general.uuid", false),
					cid: await env.getCID(),
					items: "DELETE_ALL",
				};
				const s = await cryptoKeys.signData(content);
				content.s = s;
				content.pk = await cryptoKeys.getExportedPublicKey();
				//Post an AJAX request to the 3rd party server, passing along the JSON array of all the products on the page
				fetch(env.getAPIUrl(), {
					method: "POST",
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(content),
				}).then(async function (response) {
					alert(
						getMessageOrDefault(
							"settingsDeleteRemoteHiddenDoneAlert",
							"Hidden items in remote storage emptied."
						)
					);
				});
			}
		};
		hiddenItemResetBtn.addEventListener("click", hiddenItemResetBtn._VHelperClickHandler);
	}

	const fetchHiddenItemsBtn = document.getElementById("fetchHiddenItems");
	if (fetchHiddenItemsBtn && !fetchHiddenItemsBtn._VHelperClickHandler) {
		fetchHiddenItemsBtn._VHelperClickHandler = async function () {
			const fetchHiddenConfirm = await confirmPrompt(
				getMessageOrDefault(
					"settingsFetchHiddenConfirm",
					"The import will begin, if you have a large number of items, it may take a while."
				)
			);
			if (!fetchHiddenConfirm) {
				return;
			}
			fetchHiddenItemsBtn.disabled = true;
			const content = {
				api_version: 5,
				app_version: env.data.appVersion,
				action: "load_hidden_list",
				country: Settings.get("general.country", false),
				uuid: Settings.get("general.uuid", false),
				cid: await env.getCID(),
			};
			const s = await cryptoKeys.signData(content);
			content.s = s;
			content.pk = await cryptoKeys.getExportedPublicKey();
			//Post an AJAX request to the 3rd party server, passing along the JSON array of all the products on the page
			fetch(env.getAPIUrl(), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(content),
			})
				.then((data) => data.json())
				.then(async function (data) {
					for (let i = 0; i < data.items.length; i++) {
						const asin = data.items[i];
						await HiddenList.addItem(asin, false, false);

						//Save at every chunk of ~1000 items to avoid storage space overflow
						//That way the garbage collector can work if needed.
						if (i % 1000 == 0) {
							await HiddenList.saveList(false); //Do not remote save
						}
					}
					await HiddenList.saveList(false); //Do not remote save
					alert(
						getMessageOrDefault(
							"settingsFetchHiddenImportedAlert",
							data.items.length + " hidden item(s) have been imported.",
							[data.items.length]
						)
					);
					fetchHiddenItemsBtn.disabled = false;
				});
		};
		fetchHiddenItemsBtn.addEventListener("click", fetchHiddenItemsBtn._VHelperClickHandler);
	}

	function dynamicMaskedInput(id) {
		const key = CSS.escape(id);
		const input = document.querySelector(`#${key}`);
		input.onmouseenter = () => input.classList.remove("vh-input-masked");
		input.onmouseleave = () => input.classList.add("vh-input-masked");
	}

	//UUID/deviceId:
	dynamicMaskedInput("generaluuid");
	document.getElementById(`generaluuid`).value = Settings.get("general.uuid", false);

	document.querySelector("#saveUUID").onclick = async function () {
		document.querySelector("#saveUUID").disabled = true;
		let key = CSS.escape("generaluuid");
		//Post a fetch request to confirm if the UUID is valid
		const uuid = document.querySelector("#" + key).value;

		//Check if there is a device name
		try {
			const deviceName = await deviceMgr.getDeviceName();
			if (!deviceName) {
				await deviceMgr.generateDeviceName(true);
			}
			if (!deviceName) {
				throw new Error(getMessageOrDefault("settingsDeviceNameInvalidError", "Device name is not valid"));
			}
		} catch (error) {
			alert(
				getMessageOrDefault(
					"settingsDeviceNameError",
					"Error generating device name. Make sure the device name is valid and try again.\nError:\n "
				) + error.message
			);
			document.querySelector("#saveUUID").disabled = false;
			return;
		}

		//Save new UUID
		try {
			await fingerprintMgr.updateUUID(uuid);
			alert(
				getMessageOrDefault(
					"settingsUuidSavedAlert",
					"New UUID saved. Reload a vine page to reload your privileges."
				)
			);
		} catch (error) {
			alert(
				getMessageOrDefault(
					"settingsUuidSaveError",
					"Error saving UUID. Make sure the UUID is valid and try again.\nError:\n "
				) + error.message
			);
		}
		document.querySelector("#saveUUID").disabled = false;
	};

	document.querySelector("#resetAppId").onclick = async function () {
		const resetAppIdConfirm = await confirmPrompt(
			getMessageOrDefault(
				"settingsResetAppIdConfirm",
				"A new UUID will be generated automatically when you reload a Vine page.\n\nAre you sure you want to reset the App ID?"
			)
		);
		if (resetAppIdConfirm) {
			try {
				await Settings.set("general.uuid", null);
				await Settings.set("general.cid", null);
				// Clear the UUID input field
				document.getElementById("generaluuid").value = "";
				alert(
					getMessageOrDefault(
						"settingsResetAppIdDone",
						"App ID has been reset. A new UUID will be generated when you reload a Vine page."
					)
				);
			} catch (error) {
				alert(getMessageOrDefault("settingsResetAppIdErrorPrefix", "Error resetting App ID: ") + error.message);
			}
		}
	};

	manageInputText("general.deviceName");
	document.querySelector("#generateDeviceName").onclick = async function () {
		const key = CSS.escape("general.deviceName");
		const deviceName = await deviceMgr.generateDeviceName(false);
		document.querySelector("#" + key).value = deviceName;
	};
	document.querySelector("#saveDeviceName").onclick = async function () {
		try {
			let key = CSS.escape("generaluuid");
			const uuid = document.querySelector("#" + key).value;

			document.querySelector("#saveDeviceName").disabled = true;
			let deviceNameKey = CSS.escape("general.deviceName");
			let deviceName = document.querySelector("#" + deviceNameKey).value;
			await fingerprintMgr.updateDeviceName(uuid, deviceName);
			document.querySelector("#saveDeviceName").disabled = false;
		} catch (error) {
			alert(error);
			document.querySelector("#saveDeviceName").disabled = false;
		}
	};

	function initApiServerSettings() {
		const mainRadio = document.querySelector('input[name="general.apiServerMode"][value="main"]');
		const fallbackRadio = document.querySelector('input[name="general.apiServerMode"][value="fallback"]');
		const untilLabel = document.getElementById("apiFallbackUntilText");
		if (!mainRadio || !fallbackRadio) {
			return;
		}

		function refreshFromSettings() {
			const until = Settings.get("general.apiFallbackUntil", 0);
			const now = Date.now();
			const isFallback = typeof until === "number" && until > now;

			mainRadio.checked = !isFallback;
			fallbackRadio.checked = isFallback;

			if (untilLabel) {
				if (isFallback) {
					const d = new Date(until);
					const text = getMessageOrDefault(
						"settingsApiFallbackUntilLabel",
						"Using fallback server until $1$",
						[d.toLocaleString()]
					);
					untilLabel.textContent = text;
				} else {
					untilLabel.textContent = "";
				}
			}
		}

		refreshFromSettings();

		async function onChange(event) {
			const value = event.target.value;
			if (value === "fallback") {
				const confirmText = getMessageOrDefault(
					"settingsApiFallbackConfirm",
					"Use the fallback server (api.vinehelper.ovh) for the next 7 days?"
				);
				const confirmed = await confirmPrompt(confirmText);
				if (!confirmed) {
					refreshFromSettings();
					return;
				}
				const expiresAt = Date.now() + 7 * 24 * 60 * 60 * 1000;
				await Settings.set("general.apiFallbackUntil", expiresAt);
			} else {
				await Settings.set("general.apiFallbackUntil", 0);
			}
			refreshFromSettings();
		}

		if (!mainRadio._VHelperApiServerHandler) {
			mainRadio._VHelperApiServerHandler = onChange;
			mainRadio.addEventListener("change", onChange);
		}
		if (!fallbackRadio._VHelperApiServerHandler) {
			fallbackRadio._VHelperApiServerHandler = onChange;
			fallbackRadio.addEventListener("change", onChange);
		}
	}

	initApiServerSettings();

	function initSettingsTelemetrySubmit() {
		const btn = document.getElementById("submitSettingsTelemetry");
		if (!btn || btn._VHelperTelemetryHandler) {
			return;
		}

		btn._VHelperTelemetryHandler = true;
		btn.addEventListener("click", async () => {
			if (btn.disabled) {
				return;
			}
			btn.disabled = true;
			try {
				const settingsPreview = await buildAnonymizedPreview({ settingsMgr: Settings });
				const previewText = JSON.stringify(settingsPreview, null, 2);
				const intro = getMessageOrDefault(
					"pageSettingsServerTelemetryPreviewIntro",
					"The data below will be sent to VHelper. Each setting is reduced to a boolean (enabled or not)."
				);
				const confirmed = await confirmDataPreview(intro, previewText);
				if (!confirmed) {
					return;
				}

				const ok = await submitIfDue(true, {
					settingsMgr: Settings,
					env,
					cryptoKeys,
					i18n,
				});
				if (ok) {
					alert(
						getMessageOrDefault(
							"pageSettingsServerTelemetrySuccess",
							"Settings usage telemetry sent. Thank you."
						)
					);
				} else {
					alert(
						getMessageOrDefault(
							"pageSettingsServerTelemetryFailed",
							"Telemetry could not be sent. Make sure your UUID is saved, you have visited a Vine page at least once, and try again."
						)
					);
				}
			} catch (err) {
				console.warn("[Settings] Telemetry submit error:", err);
				alert(
					getMessageOrDefault("pageSettingsServerTelemetryFailed", "Telemetry could not be sent.") +
						(err?.message ? `\n${err.message}` : "")
				);
			} finally {
				btn.disabled = false;
			}
		});
	}

	initSettingsTelemetrySubmit();

	//##TAB - DISCORD - WEBHOOKS:
	const WEBHOOK_DEFAULT_BODY = `{
		"content": "New item in $QUEUE_NAME!",
		"embeds": [
			{
				"title": "$TITLE",
				"url": "$VH_URL",
				"thumbnail": {
					"url": "$IMG_URL"
				}
			}
		]
	}`;
	const WEBHOOK_DUMMY_VARS = {
		$QUEUE_NAME: "QUEUE_TEST",
		$TITLE: "Test product title",
		$IMG_URL: "https://www.v-helper.com/logo.png",
		$ASIN: "B00TEST00",
		$VH_URL: "https://www.v-helper.com",
		$VINE_SEARCH_URL: "https://www.v-helper.com",
		$AMZ_URL: "https://www.v-helper.com",
	};
	async function sendTestWebhook(urlId, methodId, contentId) {
		const urlEl = document.querySelector("#" + CSS.escape(urlId));
		const methodEl = document.querySelector("#" + CSS.escape(methodId));
		const contentEl = contentId ? document.querySelector("#" + CSS.escape(contentId)) : null;
		const url = ((urlEl && urlEl.value) || "").trim();
		if (!url) {
			alert(getMessageOrDefault("settingsWebhookMissingUrlAlert", "Please enter a webhook URL first."));
			return;
		}
		const method = (methodEl && methodEl.value) || "POST";
		let body = (contentEl && contentEl.value && contentEl.value.trim()) || WEBHOOK_DEFAULT_BODY;
		const vars = { ...WEBHOOK_DUMMY_VARS };
		for (const [key, value] of Object.entries(vars)) {
			body = body.replaceAll(key, value);
		}
		const options = {
			method,
			headers: { "Content-Type": "application/json" },
		};
		if (method !== "GET") options.body = body;
		try {
			const response = await fetch(url, options);
			if (response.ok) {
				alert(getMessageOrDefault("settingsWebhookTestSuccess", "Test webhook sent successfully."));
			} else {
				alert(
					getMessageOrDefault("settingsWebhookTestFailedPrefix", "Test webhook failed: ") +
						response.status +
						" " +
						response.statusText
				);
			}
		} catch (err) {
			alert(
				getMessageOrDefault("settingsWebhookTestErrorPrefix", "Test webhook error: ") +
					(err.message || String(err))
			);
		}
	}
	manageInputText("discord.webhook.KWsMatch.url");
	manageSelectBox("discord.webhook.KWsMatch.method");
	manageTextarea("discord.webhook.KWsMatch.content");
	const btnKWsMatchTest = document.querySelector("#discordWebhookKWsMatchTest");
	if (btnKWsMatchTest)
		btnKWsMatchTest.onclick = () =>
			sendTestWebhook(
				"discordWebhookKWsMatchUrl",
				"discordWebhookKWsMatchMethod",
				"discordWebhookKWsMatchContent"
			);
	manageCheckboxSetting("discord.webhook.AFA.active");
	manageInputText("discord.webhook.AFA.url");
	manageSelectBox("discord.webhook.AFA.method");
	manageTextarea("discord.webhook.AFA.content");
	const btnAFATest = document.querySelector("#discordWebhookAFATest");
	if (btnAFATest)
		btnAFATest.onclick = () =>
			sendTestWebhook("discordWebhookAFAUrl", "discordWebhookAFAMethod", "discordWebhookAFAContent");
	manageCheckboxSetting("discord.webhook.RFY.active");
	manageInputText("discord.webhook.RFY.url");
	manageSelectBox("discord.webhook.RFY.method");
	manageTextarea("discord.webhook.RFY.content");
	const btnRFYTest = document.querySelector("#discordWebhookRFYTest");
	if (btnRFYTest)
		btnRFYTest.onclick = () =>
			sendTestWebhook("discordWebhookRFYUrl", "discordWebhookRFYMethod", "discordWebhookRFYContent");
	manageCheckboxSetting("discord.webhook.zeroETV.active");
	manageInputText("discord.webhook.zeroETV.url");
	manageSelectBox("discord.webhook.zeroETV.method");
	manageTextarea("discord.webhook.zeroETV.content");
	["#discordWebhookAFAActive", "#discordWebhookRFYActive", "#discordWebhookzeroETVActive"].forEach((selector) => {
		const checkbox = document.querySelector(selector);
		if (checkbox) {
			checkbox.dispatchEvent(new Event("change"));
		}
	});
	const btnZeroETVTest = document.querySelector("#discordWebhookzeroETVTest");
	if (btnZeroETVTest)
		btnZeroETVTest.onclick = () =>
			sendTestWebhook("discordWebhookzeroETVUrl", "discordWebhookzeroETVMethod", "discordWebhookzeroETVContent");

	//##TAB - DISCORD - BRENDA:
	manageCheckboxSetting("discord.active"); //Handled manually

	const chkDiscord = document.querySelector(`#discordactive`);
	if (chkDiscord && !chkDiscord._VHelperDiscordDrawHandler) {
		chkDiscord._VHelperDiscordDrawHandler = function () {
			setTimeout(() => drawDiscord(), 1);
		};
		chkDiscord.addEventListener("change", chkDiscord._VHelperDiscordDrawHandler);
	}

	document.querySelector("#saveGUID").onclick = async function () {
		document.querySelector("#saveGUID").disabled = true;
		let key = CSS.escape("discord.guid");
		//Post a fetch request to the Brenda API from the AmazonVine Discord server
		//We want to check if the guid is valid.
		let url = "https://api.llamastories.com/brenda/user/" + document.querySelector("#" + key).value;
		const response = await fetch(url, { method: "GET" });
		if (response.status == 200) {
			await Settings.set("discord.guid", document.querySelector(`#${key}`).value);

			document.querySelector("#guid-txt").textContent = Settings.get("discord.guid", false);
			document.querySelector("#discord-guid-link").style.display = "none";
			document.querySelector("#discord-guid-unlink").style.display = "block";
		} else {
			document.querySelector(`#${key}`).value = "";
			alert(getMessageOrDefault("settingsInvalidApiTokenAlert", "invalid API Token."));
		}
		document.querySelector("#saveGUID").disabled = false;
	};
	document.querySelector("#unlinkGUID").onclick = async function () {
		Settings.set("discord.guid", null);

		document.querySelector("#discord-guid-link").style.display = "block";
		document.querySelector("#discord-guid-unlink").style.display = "none";
	};
	if (Settings.get("discord.guid", false)) {
		document.querySelector("#guid-txt").textContent = Settings.get("discord.guid");
	}

	//##TAB - KEYWORDS
	manageCheckboxSetting("general.unblurImageOnHover");
	// Manage keyword groups (new system)
	await manageKeywordGroups();
	initiateTogglers();
	initiateTestKeywords();

	const keywordsTesting = document.querySelector("#keywords-testing");
	const pinKeywordsTesting = document.querySelector("#pin-keywords-testing");
	if (pinKeywordsTesting && !pinKeywordsTesting._VHelperClickHandler) {
		pinKeywordsTesting._VHelperClickHandler = function (e) {
			// Prevent the click from bubbling up to the legend and collapsing the fieldset
			e.stopPropagation();
			e.preventDefault();

			if (pinKeywordsTesting.classList.contains("vh-icon-pin")) {
				pinKeywordsTesting.classList.remove("vh-icon-pin");
				pinKeywordsTesting.classList.add("vh-icon-unpin");
				keywordsTesting.classList.add("keywords-testing-pinned");
			} else {
				pinKeywordsTesting.classList.remove("vh-icon-unpin");
				pinKeywordsTesting.classList.add("vh-icon-pin");
				keywordsTesting.classList.remove("keywords-testing-pinned");
			}
		};
		pinKeywordsTesting.addEventListener("click", pinKeywordsTesting._VHelperClickHandler);
	}

	//##TAB - KEYBINDINGS

	manageCheckboxSetting("keyBindings.active");
	manageInputText("keyBindings.pauseFeed");
	manageInputText("keyBindings.clearUnavailable");
	manageInputText("keyBindings.clearAll");
	manageInputText("keyBindings.nextPage");
	manageInputText("keyBindings.previousPage");
	manageInputText("keyBindings.RFYPage");
	manageInputText("keyBindings.AFAPage");
	manageInputText("keyBindings.ALLPage");
	manageInputText("keyBindings.OrdersPage");
	manageInputText("keyBindings.AIPage");
	manageInputText("keyBindings.AIPage2");
	manageInputText("keyBindings.AIPage3");
	manageInputText("keyBindings.AIPage4");
	manageInputText("keyBindings.AIPage5");
	manageInputText("keyBindings.AIPage6");
	manageInputText("keyBindings.AIPage7");
	manageInputText("keyBindings.AIPage8");
	manageInputText("keyBindings.AIPage9");
	manageInputText("keyBindings.AIPage10");
	manageInputText("keyBindings.availableTab");
	manageInputText("keyBindings.unavailableTab");
	manageInputText("keyBindings.hiddenTab");
	manageInputText("keyBindings.pinnedTab");
	manageInputText("keyBindings.hideAll");
	manageInputText("keyBindings.showAll");
	manageInputText("keyBindings.hideAllNext");
	manageInputText("keyBindings.debug");
	manageInputText("keyBindings.firstPage");

	//##TAB - STYLES

	manageTextarea("general.customCSS");

	//##TAB - ?

	if (!isSafari()) {
		//Copy buttons
		const copyBTCBtn = document.getElementById("copyBTC");
		if (copyBTCBtn && !copyBTCBtn._VHelperClickHandler) {
			copyBTCBtn._VHelperClickHandler = function () {
				navigator.clipboard
					.writeText("bc1q0f82vk79u7hzxcrqe6q2levzvhdrqe72fm5w8z")
					.then(() => {
						// Alert the user that the text has been copied
						alert(getMessageOrDefault("settingsBtcCopiedAlert", "BTC address copied to clipboard"));
					})
					.catch((err) => {
						console.error("Failed to copy: ", err);
					});
			};
			copyBTCBtn.addEventListener("click", copyBTCBtn._VHelperClickHandler);
		}

		const copyETHBtn = document.getElementById("copyETH");
		if (copyETHBtn && !copyETHBtn._VHelperClickHandler) {
			copyETHBtn._VHelperClickHandler = function () {
				navigator.clipboard
					.writeText("0xF5b68799b43C358E0A54482f0D8445DFBEA9BDF1")
					.then(() => {
						// Alert the user that the text has been copied
						alert(getMessageOrDefault("settingsEthCopiedAlert", "ETH address copied to clipboard"));
					})
					.catch((err) => {
						console.error("Failed to copy: ", err);
					});
			};
			copyETHBtn.addEventListener("click", copyETHBtn._VHelperClickHandler);
		}

		//Patreon login link:
		document.getElementById("PatreonLogin").href =
			"https://www.patreon.com/oauth2/authorize" +
			"?response_type=code" +
			"&client_id=AqsjZu6eHaLtO3y8bj0VPydtRCNNV2n-5aQoWVKil4IPNb3qoxkT75VQMhSALTcO" +
			"&redirect_uri=" +
			encodeURIComponent(env.getAPIUrl() + "/patreon-login") +
			//"&scope=pledges-to-me" +
			"&state=" +
			Settings.get("general.uuid", false);

		//Patreon load page link (element only present when Patreon section is shown, not on Safari/Apple):
		const refreshVinePageEl = document.getElementById("RefreshVinePage");
		if (refreshVinePageEl) {
			if (Settings.get("general.country") == null) {
				refreshVinePageEl.style.display = "none";
			} else {
				refreshVinePageEl.href = `https://www.amazon.${i18n.getDomainTLD()}/vine/vine-items?queue=encore`;
			}
		}
	}

	// Apple subscription links (only when Safari – Apple section is only rendered then)
	if (isSafari()) {
		const appleTiersPageEl = document.getElementById("AppleTiersPageLink");
		if (appleTiersPageEl) {
			const uuid = Settings.get("general.uuid", false) || "";
			appleTiersPageEl.href = env.getAPIUrl() + "/apple-tiers/page?uuid=" + encodeURIComponent(uuid);
		}
		const appleSignInEl = document.getElementById("AppleSignInLink");
		if (appleSignInEl) {
			const uuid = Settings.get("general.uuid", false) || "";
			appleSignInEl.href =
				"https://appleid.apple.com/auth/authorize" +
				"?client_id=com.FrancoisMazerolle.VHelper" +
				"&redirect_uri=" +
				encodeURIComponent(env.getAPIUrl() + "/apple-login") +
				"&response_type=code" +
				"&scope=name%20email" +
				"&response_mode=form_post" +
				"&state=uuid:" +
				encodeURIComponent(uuid);
		}
	}

	//Import/Export JSON Settings
	const bulkImportJSONsettingsBtn = document.getElementById(`bulkImportJSONsettings`);
	if (bulkImportJSONsettingsBtn && !bulkImportJSONsettingsBtn._VHelperClickHandler) {
		bulkImportJSONsettingsBtn._VHelperClickHandler = async () => {
			displayMultiLinePopup(
				"",
				getMessageOrDefault("settingsJsonPastePlaceholder", "Paste your JSON content here..."),
				getMessageOrDefault("settingsJsonImportButtonLabel", "Import JSON"),
				async (data) => {
					try {
						if (data == "") {
							throw new Error(getMessageOrDefault("settingsJsonEmptyError", "Empty JSON data"));
						}
						const json = JSON.parse(data);
						if (!json.settings) {
							throw new Error(getMessageOrDefault("settingsJsonFormatInvalidError", "Format Invalid"));
						}
						await chrome.storage.local.set({ settings: json.settings });
						return true; //Hide the popup
					} catch (err) {
						alert(getMessageOrDefault("settingsJsonIncompleteError", "JSON data incomplete or invalid."));
						return false; //Keep the popup visible
					}
				}
			);
		};
		bulkImportJSONsettingsBtn.addEventListener("click", bulkImportJSONsettingsBtn._VHelperClickHandler);
	}

	//Export JSON
	const bulkExportJSONsettingsBtn = document.getElementById(`bulkExportJSONsettings`);
	if (bulkExportJSONsettingsBtn && !bulkExportJSONsettingsBtn._VHelperClickHandler) {
		bulkExportJSONsettingsBtn._VHelperClickHandler = async () => {
			const json = await chrome.storage.local.get("settings");
			//Delete the settings.fingerprint.id
			delete json.settings.general.fingerprint;
			delete json.settings.crypto;
			displayMultiLinePopup(JSON.stringify(json), "", null, null, {
				copyTooltip: getMessageOrDefault(
					"settingsCopyExportSettingsTooltip",
					"Copy Export Local Settings to Clipboard"
				),
			});
		};
		bulkExportJSONsettingsBtn.addEventListener("click", bulkExportJSONsettingsBtn._VHelperClickHandler);
	}

	//Import/Export JSON hidden items
	const bulkImportJSONhiddenBtn = document.getElementById(`bulkImportJSONhidden`);
	if (bulkImportJSONhiddenBtn && !bulkImportJSONhiddenBtn._VHelperClickHandler) {
		bulkImportJSONhiddenBtn._VHelperClickHandler = async () => {
			displayMultiLinePopup(
				"",
				getMessageOrDefault("settingsJsonPastePlaceholder", "Paste your JSON content here..."),
				getMessageOrDefault("settingsJsonImportButtonLabel", "Import JSON"),
				async (data) => {
					try {
						if (data == "") {
							throw new Error(getMessageOrDefault("settingsJsonEmptyError", "Empty JSON data"));
						}
						const json = JSON.parse(data);
						if (!json.hiddenItems) {
							throw new Error(getMessageOrDefault("settingsJsonFormatInvalidError", "Format Invalid"));
						}
						await chrome.storage.local.set({ hiddenItems: json.hiddenItems });
						return true; //Hide the popup
					} catch (err) {
						alert(getMessageOrDefault("settingsJsonIncompleteError", "JSON data incomplete or invalid."));
						return false; //Keep the popup visible
					}
				}
			);
		};
		bulkImportJSONhiddenBtn.addEventListener("click", bulkImportJSONhiddenBtn._VHelperClickHandler);
	}

	//Export JSON
	const bulkExportJSONhiddenBtn = document.getElementById(`bulkExportJSONhidden`);
	if (bulkExportJSONhiddenBtn && !bulkExportJSONhiddenBtn._VHelperClickHandler) {
		bulkExportJSONhiddenBtn._VHelperClickHandler = async () => {
			const json = await chrome.storage.local.get("hiddenItems");
			displayMultiLinePopup(JSON.stringify(json), "", null, null, {
				copyTooltip: getMessageOrDefault(
					"settingsCopyExportHiddenTooltip",
					"Copy Export Hidden Items to Clipboard"
				),
			});
		};
		bulkExportJSONhiddenBtn.addEventListener("click", bulkExportJSONhiddenBtn._VHelperClickHandler);
	}

	//Import/Export JSON pinned items
	const bulkImportJSONpinnedBtn = document.getElementById(`bulkImportJSONpinned`);
	if (bulkImportJSONpinnedBtn && !bulkImportJSONpinnedBtn._VHelperClickHandler) {
		bulkImportJSONpinnedBtn._VHelperClickHandler = async () => {
			displayMultiLinePopup(
				"",
				getMessageOrDefault("settingsJsonPastePlaceholder", "Paste your JSON content here..."),
				getMessageOrDefault("settingsJsonImportButtonLabel", "Import JSON"),
				async (data) => {
					try {
						if (data == "") {
							throw new Error(getMessageOrDefault("settingsJsonEmptyError", "Empty JSON data"));
						}
						const json = JSON.parse(data);
						if (!json.pinnedItems) {
							throw new Error(getMessageOrDefault("settingsJsonFormatInvalidError", "Format Invalid"));
						}
						await chrome.storage.local.set({ pinnedItems: json.pinnedItems });
						return true; //Hide the popup
					} catch (err) {
						alert(getMessageOrDefault("settingsJsonIncompleteError", "JSON data incomplete or invalid."));
						return false; //Keep the popup visible
					}
				}
			);
		};
		bulkImportJSONpinnedBtn.addEventListener("click", bulkImportJSONpinnedBtn._VHelperClickHandler);
	}

	//Export JSON
	const bulkExportJSONpinnedBtn = document.getElementById(`bulkExportJSONpinned`);
	if (bulkExportJSONpinnedBtn && !bulkExportJSONpinnedBtn._VHelperClickHandler) {
		bulkExportJSONpinnedBtn._VHelperClickHandler = async () => {
			const json = await chrome.storage.local.get("pinnedItems");
			displayMultiLinePopup(JSON.stringify(json), "", null, null, {
				copyTooltip: getMessageOrDefault(
					"settingsCopyExportPinnedTooltip",
					"Copy Export Pinned Items to Clipboard"
				),
			});
		};
		bulkExportJSONpinnedBtn.addEventListener("click", bulkExportJSONpinnedBtn._VHelperClickHandler);
	}

	manageDualRangeSlider({
		minKey: "notification.autoload.min",
		maxKey: "notification.autoload.max",
		fromSliderId: "fromSlider",
		toSliderId: "toSlider",
		fromInputId: "fromInput",
		toInputId: "toInput",
		defaultMin: 5,
		defaultMax: 10,
	});
	manageDualRangeSlider({
		minKey: "notification.autoload.whenDroppingMin",
		maxKey: "notification.autoload.whenDroppingMax",
		fromSliderId: "fromSliderDropping",
		toSliderId: "toSliderDropping",
		fromInputId: "fromInputDropping",
		toInputId: "toInputDropping",
		defaultMin: 30,
		defaultMax: 60,
	});
	manageDualRangeSlider({
		minKey: "notification.autoload.rfyMin",
		maxKey: "notification.autoload.rfyMax",
		fromSliderId: "fromSliderRFYAssisted",
		toSliderId: "toSliderRFYAssisted",
		fromInputId: "fromInputRFYAssisted",
		toInputId: "toInputRFYAssisted",
		defaultMin: 2,
		defaultMax: 5,
	});
	manageDualRangeSlider({
		minKey: "notification.autoload.favMin",
		maxKey: "notification.autoload.favMax",
		fromSliderId: "fromSliderFavAssisted",
		toSliderId: "toSliderFavAssisted",
		fromInputId: "fromInputFavAssisted",
		toInputId: "toInputFavAssisted",
		defaultMin: 30,
		defaultMax: 60,
	});
	initFavouriteCategoriesSettingsUI();

	initSeeDetailsBehaviorTabs();

	// Ensure fieldsets controlled by legend checkboxes reflect the final
	// checkbox state after all controls are initialized from stored settings.
	syncLegendControlledFieldsets();
}

function initSeeDetailsBehaviorTabs() {
	const tabsRoot = document.getElementById("vh-see-details-behavior-tabs");
	if (!tabsRoot) return;
	const tabButtons = Array.from(tabsRoot.querySelectorAll("[data-vh-see-details-tab]"));
	const panels = Array.from(document.querySelectorAll("[data-vh-see-details-panel]"));
	if (!tabButtons.length || !panels.length) return;

	const setActiveTab = (tabName) => {
		tabButtons.forEach((tab) => {
			const isActive = tab.getAttribute("data-vh-see-details-tab") === tabName;
			tab.classList.toggle("active", isActive);
		});
		panels.forEach((panel) => {
			const isActive = panel.getAttribute("data-vh-see-details-panel") === tabName;
			panel.style.display = isActive ? "block" : "none";
		});
	};

	tabButtons.forEach((tab) => {
		if (tab.dataset.vhSeeDetailsTabBound === "1") return;
		tab.dataset.vhSeeDetailsTabBound = "1";
		tab.addEventListener("click", (event) => {
			event.preventDefault();
			const tabName = tab.getAttribute("data-vh-see-details-tab");
			if (!tabName) return;
			setActiveTab(tabName);
		});
	});

	// Default selected tab requested by UX: Monitor V4.
	setActiveTab("v4");
}

/**
 * Function to handle the collapsible fieldsets
 */
function initiateTogglers() {
	document.querySelectorAll("a.toggle").forEach((link) => {
		if (link._VHelperToggleClickHandler) {
			return;
		}
		link._VHelperToggleClickHandler = (event) => {
			const container = link.parentElement.parentElement.querySelector("div.toggle-container");
			const toggleIcon = link.querySelector("div");
			if (toggleIcon.classList.contains("vh-icon-toggler-down")) {
				toggleIcon.classList.remove("vh-icon-toggler-down");
				toggleIcon.classList.add("vh-icon-toggler-right");

				container.style.display = "none";
			} else {
				toggleIcon.classList.remove("vh-icon-toggler-right");
				toggleIcon.classList.add("vh-icon-toggler-down");

				container.style.display = "block";
			}
		};
		link.addEventListener("click", link._VHelperToggleClickHandler);
	});
}

/**
 * Test a title against all keywords
 */
function initiateTestKeywords() {
	const titleObj = document.querySelector("#testTitle");
	if (!titleObj) return;

	const runTest = () => {
		const container = document.querySelector("#keywordGroupsContainer");
		const logEl = document.querySelector("#keywordsTestingLog");
		void runKeywordTest(titleObj.value, container, logEl, Settings);
	};

	if (!titleObj._VHelperKeyupHandler) {
		titleObj._VHelperKeyupHandler = runTest;
		titleObj.addEventListener("keyup", titleObj._VHelperKeyupHandler);
	}

	const testAgainBtn = document.querySelector("#testTitleAgain");
	if (testAgainBtn && !testAgainBtn._VHelperClickHandler) {
		testAgainBtn._VHelperClickHandler = runTest;
		testAgainBtn.addEventListener("click", testAgainBtn._VHelperClickHandler);
	}
}

// Dialog functions moved to ./components/dialogs/DialogUtils.js
// Utility functions moved to ./utils/SettingsUtils.js

// Keyword Groups Management - moved to ./components/keywords/KeywordGroupsUI.js
// Keyword groups and drag-and-drop functions moved to:
// - ./components/keywords/KeywordGroupsUI.js
// - ./components/keywords/KeywordDragAndDrop.js

export { initiateSettings, ensureCheckoutTabBound, loadUserContributionStats };
