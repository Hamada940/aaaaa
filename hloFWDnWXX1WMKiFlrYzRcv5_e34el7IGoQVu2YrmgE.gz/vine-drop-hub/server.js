'use strict';

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const https = require('https');
const WebSocket = require('ws');
const ioClient = require('socket.io-client');
const crypto = require('crypto');
const axios = require('axios');

// ============================================================================
// DIRECTORIES & PERSISTENCE
// ============================================================================
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const CONFIG_FILE = path.join(__dirname, 'config.json');
const ITEMS_FILE = path.join(DATA_DIR, 'items.json');
const ACTIVITY_FILE = path.join(DATA_DIR, 'activity.json');
const KEYWORDS_FILE = path.join(DATA_DIR, 'keywords.json');
const PINNED_FILE = path.join(DATA_DIR, 'pinned.json');
const DISMISSED_PRIORITY_FILE = path.join(DATA_DIR, 'dismissed_priority.json');
const HIDDEN_FILE = path.join(DATA_DIR, 'hidden.json');
const IDENTITY_FILE = path.join(DATA_DIR, 'identity.json');
const NOTIFIED_FILE = path.join(DATA_DIR, 'notified.json');

function loadJSON(file, def) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    console.error(`[FS] Error reading ${file}:`, error.message);
  }
  return def;
}

function saveJSON(file, data) {
  try {
    const tempFile = `${file}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tempFile, file);
  } catch (error) {
    console.error(`[FS] Error writing ${file}:`, error.message);
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================
const DEFAULT_CONFIG = {
  port: 3001,
  domain: 'amazon.ca',
  countryCode: 'ca',

  // Ultraviner is enabled by default. These identity values must all come from
  // the same current Ultraviner browser profile as the bearer token.
  enableUV: true,
  token: '',
  azUser: '',
  device: '',
  selectedScreenId: '',
  alertQueueId: '',
  exploreQueueId: '',
  displayName: 'Vine Drop Hub',
  uvUserAgent:
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
  uvIdentificationDelayMs: 500,
  uvAuthenticationTimeoutMs: 15000,
  uvReconnectDelayMs: 5000,

  // VHelper starts OFF. It can be enabled in config or through /api/vh/enable.
  // UV_ONLY=1 or DISABLE_VH=1 is a hard process-level kill switch.
  enableVH: false,

  telegramToken: '',
  telegramChatId: '',
  enableTelegram: false,
  discordWebhook: '',
  minPriorityPrice: 100,
  maxStoredItems: 2000,
  notificationDedupeMinutes: 5
};

let config = { ...DEFAULT_CONFIG, ...loadJSON(CONFIG_FILE, {}) };
saveJSON(CONFIG_FILE, config);

const VH_FORCE_DISABLED =
  process.env.UV_ONLY === '1' ||
  process.env.DISABLE_VH === '1' ||
  process.env.ENABLE_VH === '0';

function isVhEnabled() {
  return Boolean(config.enableVH) && !VH_FORCE_DISABLED;
}

let allItems = loadJSON(ITEMS_FILE, []);
if (!Array.isArray(allItems)) allItems = [];

let activityLog = loadJSON(ACTIVITY_FILE, []);
if (!Array.isArray(activityLog)) activityLog = [];

let keywords = loadJSON(KEYWORDS_FILE, {
  highlight: [
    'espresso',
    'coffee',
    'oled',
    '4k',
    'monitor',
    'anker',
    'drone',
    'ssd',
    'leather',
    'vacuum',
    'gpu',
    'nvme'
  ],
  hide: [],
  blur: []
});

const pinnedAsins = new Set(loadJSON(PINNED_FILE, []));
const dismissedPriorityAsins = new Set(loadJSON(DISMISSED_PRIORITY_FILE, []));
const hiddenAsins = new Set(loadJSON(HIDDEN_FILE, []));
let vhIdentity = loadJSON(IDENTITY_FILE, null);

// New format: { "ASIN": epochMilliseconds }. Old array files are deliberately
// migrated to timestamps of zero so historical entries do not permanently
// suppress a future genuine live alert.
const notifiedRaw = loadJSON(NOTIFIED_FILE, {});
const notifiedAt = new Map();
if (Array.isArray(notifiedRaw)) {
  notifiedRaw.forEach(asin => {
    if (asin) notifiedAt.set(asin, 0);
  });
} else if (notifiedRaw && typeof notifiedRaw === 'object') {
  Object.entries(notifiedRaw).forEach(([asin, timestamp]) => {
    const value = Number(timestamp);
    if (asin && Number.isFinite(value)) notifiedAt.set(asin, value);
  });
}

function persistNotified() {
  const entries = [...notifiedAt.entries()]
    .filter(([, timestamp]) => Number.isFinite(timestamp))
    .sort((a, b) => a[1] - b[1])
    .slice(-5000);
  saveJSON(NOTIFIED_FILE, Object.fromEntries(entries));
}

function wasRecentlyNotified(asin, now = Date.now()) {
  const timestamp = notifiedAt.get(asin);
  if (!Number.isFinite(timestamp) || timestamp <= 0) return false;
  const ttl = Math.max(0, Number(config.notificationDedupeMinutes) || 5) * 60000;
  return now - timestamp < ttl;
}

function markNotified(asin, now = Date.now()) {
  notifiedAt.set(asin, now);
  persistNotified();
}

function sortItemsArray(arr) {
  arr.sort((a, b) => {
    const aPin = pinnedAsins.has(a.asin);
    const bPin = pinnedAsins.has(b.asin);
    if (aPin && !bPin) return -1;
    if (!aPin && bPin) return 1;

    const aPriority = a.isHighlight && !dismissedPriorityAsins.has(a.asin);
    const bPriority = b.isHighlight && !dismissedPriorityAsins.has(b.asin);
    if (aPriority && !bPriority) return -1;
    if (!aPriority && bPriority) return 1;

    const timeA = new Date(a.date_added || a.date || a.last_seen || 0).getTime();
    const timeB = new Date(b.date_added || b.date || b.last_seen || 0).getTime();
    return timeB - timeA;
  });
}

sortItemsArray(allItems);
console.log(
  `[Storage] ${allItems.length} items, ${pinnedAsins.size} pinned, ` +
    `${notifiedAt.size} notification records.`
);

// ============================================================================
// VHELPER IDENTITY
// ============================================================================
const VH_APP_VERSION = '4.7.0';
const VH_DEVICE_NAME = 'cat-dashboard-v9';
const VH_API_URL = 'https://api.v-helper.com';
const VH_WS_URL = 'wss://api.v-helper.com';

// Preserved from the supplied script. If these keys are personal credentials,
// move them to environment/config storage and rotate the exposed copy.
const ECDSA_PRIVATE_JWK = {
  crv: 'P-256',
  d: 'x5vpowfSzCjS0zZWAyzGewCQaLyyY8Vw7mzmWBR6loQ',
  ext: true,
  key_ops: ['sign'],
  kty: 'EC',
  x: 'qTRfCjqGW_x785-DlpdIYoZm0be-t8j908YBMwYDpXU',
  y: '4wOAjBiaTtS_BJtNlix8mRtyv_7ONEYHsBAXcSCyELU'
};

const ECDSA_PUBLIC_JWK = {
  crv: 'P-256',
  ext: true,
  key_ops: ['verify'],
  kty: 'EC',
  x: 'qTRfCjqGW_x785-DlpdIYoZm0be-t8j908YBMwYDpXU',
  y: '4wOAjBiaTtS_BJtNlix8mRtyv_7ONEYHsBAXcSCyELU'
};

class IdentityManager {
  constructor() {
    this.currentIdentity = vhIdentity;
  }

  generateCustomerId() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let id = 'A';
    for (let i = 0; i < 13; i += 1) {
      id += chars[Math.floor(Math.random() * chars.length)];
    }
    return id;
  }

  signECDSA(privateKeyJwk, dataString) {
    const privateKey = crypto.createPrivateKey({ key: privateKeyJwk, format: 'jwk' });
    const sign = crypto.createSign('SHA256');
    sign.update(dataString);
    sign.end();
    return sign.sign({ key: privateKey, dsaEncoding: 'ieee-p1363' }).toString('base64');
  }

  getCID(country, customerId) {
    return crypto.createHash('sha256').update(`${country}${customerId}`).digest('hex');
  }

  async registerIdentity(country = 'ca') {
    if (!isVhEnabled()) throw new Error('VHelper is disabled');

    const customerId = this.generateCustomerId();
    const content = {
      api_version: 5,
      app_version: VH_APP_VERSION,
      action: 'get_uuid',
      country,
      cid: this.getCID(country, customerId)
    };

    const dataString = JSON.stringify(content);
    const signature = this.signECDSA(ECDSA_PRIVATE_JWK, dataString);
    const payload = { ...content, s: signature, pk: ECDSA_PUBLIC_JWK };
    const response = await axios.post(VH_API_URL, payload, { timeout: 15000 });

    if (response.data?.ok === 'ok' && response.data.uuid) {
      const identity = {
        uuid: response.data.uuid,
        customerId,
        country,
        createdAt: new Date().toISOString()
      };
      saveJSON(IDENTITY_FILE, identity);
      this.currentIdentity = identity;
      vhIdentity = identity;
      console.log(`[VH Identity] Registered UUID: ${identity.uuid}`);
      return identity;
    }

    throw new Error('VH identity registration failed');
  }

  async getOrCreateIdentity(country = 'ca') {
    if (this.currentIdentity?.uuid) return this.currentIdentity;
    return this.registerIdentity(country);
  }

  async rotateIdentity(country = 'ca') {
    try {
      if (fs.existsSync(IDENTITY_FILE)) fs.unlinkSync(IDENTITY_FILE);
    } catch (_) {}
    this.currentIdentity = null;
    vhIdentity = null;
    return this.registerIdentity(country);
  }
}

const identityManager = new IdentityManager();

// ============================================================================
// ULTRAVINER CRYPTOGRAPHY & UTILS
// ============================================================================
const COUNTRY_MAP = {
  'amazon.com': 1,
  US: 1,
  'amazon.ca': 2,
  CA: 2,
  'amazon.co.uk': 3,
  UK: 3,
  'amazon.de': 4,
  DE: 4,
  'amazon.fr': 5,
  FR: 5,
  'amazon.it': 6,
  IT: 6,
  'amazon.es': 7,
  ES: 7,
  'amazon.co.jp': 8,
  JP: 8,
  'amazon.com.au': 9,
  AU: 9
};
const Ge = COUNTRY_MAP;

function sha256(text) {
  if (!text) return '';
  if (/^[0-9a-f]{64}$/i.test(text)) return text.toLowerCase();
  return crypto.createHash('sha256').update(String(text)).digest('hex');
}

function sortObjectDeep(value) {
  if (value == null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(sortObjectDeep);
  const output = {};
  Object.keys(value)
    .sort()
    .forEach(key => {
      output[key] = sortObjectDeep(value[key]);
    });
  return output;
}

function signUvPayload(payload, token) {
  const timestamp = Date.now();
  const serialized = JSON.stringify(sortObjectDeep(payload));
  const signature = crypto
    .createHmac('sha256', token)
    .update(serialized)
    .digest('hex');

  return {
    'Content-Type': 'application/json',
    'X-Request-Signature': signature,
    'X-Request-Timestamp': timestamp.toString()
  };
}

// ============================================================================
// ITEM, TITLE, DATE & KEYWORD UTILS
// ============================================================================
function decodeHtmlEntities(str) {
  if (!str) return '';
  return String(str)
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, decimal) => String.fromCharCode(Number(decimal)))
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
}

function getFirstTwoWords(title) {
  if (!title) return '';
  const cleaned = decodeHtmlEntities(title)
    .trim()
    .replace(/[^\w\s\-']/g, ' ');
  return cleaned
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .join(' ');
}

function getTwoWordSearchUrl(title, domain = config.domain) {
  return `https://www.${domain}/vine/vine-items?search=${encodeURIComponent(
    getFirstTwoWords(title)
  )}`;
}

function normalizeQueue(queueValue, eventType = '', fallbackQueue = null) {
  if (queueValue === 15 || queueValue === '15') return 'AI';
  if (queueValue === 14 || queueValue === '14') return 'AFA';
  if (queueValue === 13 || queueValue === '13') return 'RFY';

  const value = String(queueValue || '')
    .toLowerCase()
    .replace(/[\s\-_]+/g, '_');

  if (
    eventType === 'alertFromBrenda' ||
    eventType === 'alertDetailsFromBrenda' ||
    value.includes('brenda') ||
    value.includes('discord')
  ) {
    return 'Discord/Brenda';
  }

  if (
    value.includes('potluck') ||
    value.includes('rfy') ||
    value.includes('vendor_targeted') ||
    value.includes('targeted')
  ) {
    return 'RFY';
  }

  if (
    value.includes('last_chance') ||
    value.includes('lastchance') ||
    value.includes('afa') ||
    value.includes('vendor_vine_for_all') ||
    value.includes('vine_for_all_vendor')
  ) {
    return 'AFA';
  }

  if (
    value.includes('encore') ||
    value === 'ai' ||
    value.includes('vine_for_all') ||
    value.includes('all_items') ||
    value.includes('allitems')
  ) {
    return 'AI';
  }

  if (fallbackQueue && fallbackQueue !== 'ALL') {
    const fallback = String(fallbackQueue).toUpperCase().trim();
    if (['RFY', 'AFA', 'AI'].includes(fallback)) return fallback;
  }

  return 'AI';
}

function parseItemTime(raw) {
  const value =
    raw?.alertedDate ??
    raw?.date_added ??
    raw?.date ??
    raw?.createdAt ??
    raw?.lastDate ??
    raw?.timestamp;

  if (value == null || value === '') return null;

  if (typeof value === 'number' || /^\d+$/.test(String(value))) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return null;
    return numeric < 1e12 ? numeric * 1000 : numeric;
  }

  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseMoney(value, fallback = 0) {
  if (value == null || value === '' || value === 'N/A') return fallback;
  const parsed = Number(String(value).replace(/[^0-9.+-]/g, ''));
  return Number.isFinite(parsed) ? parsed : fallback;
}

function checkKeywordMatches(title, price = null, etv = null) {
  const normalizedTitle = String(title || '').toLowerCase();
  const keywordHighlight = (keywords.highlight || []).some(keyword => {
    const value = String(keyword || '').toLowerCase().trim();
    return value && normalizedTitle.includes(value);
  });

  const numericPrice = parseMoney(price);
  const numericEtv = parseMoney(etv);
  const minimumPrice = parseMoney(config.minPriorityPrice);
  const priceHighlight =
    minimumPrice > 0 && (numericPrice >= minimumPrice || numericEtv >= minimumPrice);

  const hide = (keywords.hide || []).some(keyword => {
    const value = String(keyword || '').toLowerCase().trim();
    return value && normalizedTitle.includes(value);
  });

  const blur = (keywords.blur || []).some(keyword => {
    const value = String(keyword || '').toLowerCase().trim();
    return value && normalizedTitle.includes(value);
  });

  return {
    isHighlight: keywordHighlight || priceHighlight,
    isPriceHighlight: priceHighlight,
    isHide: hide,
    isBlur: blur
  };
}

const BACKFILL_EVENT_TYPES = new Set([
  'INITIAL_LOAD',
  'HISTORICAL',
  'EXPLORE',
  'CATALOG',
  'BATCH_INGEST',
  'HTML_INGEST',
  'SEARCH'
]);

const UV_LIVE_ALERT_TYPES = new Set([
  'alerts',
  'alertFromEtv',
  'alertFromExternalData',
  'alertFromCategory',
  'alertFromBrenda',
  'alertDetailsFromBrenda',
  'alertFromRedrop'
]);

const UV_DETAIL_TYPES = new Set(['alertDetail', 'pageData']);

// ============================================================================
// TELEGRAM & DISCORD
// ============================================================================
function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildTelegramMessage(item) {
  const queue = String(item.queue || 'AI').toUpperCase();
  const title = item.title || 'Unknown Product';
  const asin = item.asin || 'N/A';
  const price = item.price != null && item.price !== 'N/A' ? `$${item.price}` : 'N/A';
  const etv =
    item.etv != null && item.etv !== 'N/A'
      ? item.isZeroEtv
        ? '$0.00 (Free)'
        : `$${item.etv}`
      : 'N/A';
  const brand = item.brand || 'Unknown';
  const date = new Date(item.date_added || Date.now())
    .toISOString()
    .replace('T', ' ')
    .slice(0, 19);
  const words = item.firstTwoWords || getFirstTwoWords(title);
  const orderLink = `https://www.${config.domain}/vine/vine-items?search=${encodeURIComponent(
    words
  )}`;
  const dpLink = `https://www.${config.domain}/dp/${asin}`;
  const sourceTag = (item.sources || []).join(' + ') || 'Live';

  let message = '';
  if (item.isHighlight) message += '🚨 <b>[PRIORITY ITEM]</b>\n\n';
  message += `<b>${escapeHtml(title)}</b>\n\n`;
  message += `🏷️ <b>ASIN:</b> <code>${escapeHtml(asin)}</code>\n`;
  if (brand !== 'Unknown') message += `🏢 <b>Brand:</b> ${escapeHtml(brand)}\n`;
  message += `💰 <b>ETV:</b> ${etv} | <b>Retail:</b> ${price}\n`;
  message += `📅 <b>Detected:</b> ${date}\n\n`;
  message += `🛒 <b>Order:</b> <a href="${orderLink}">Search Vine for "${escapeHtml(
    words
  )}"</a>\n`;
  message += `🔗 <b>Amazon:</b> <a href="${dpLink}">View on Amazon</a>\n\n`;
  message += `🔔 <b>NEW ${queue} DROP!</b> [${escapeHtml(sourceTag)}]`;
  return message;
}

function sendTelegramTextOnly(text) {
  const payload = JSON.stringify({
    chat_id: config.telegramChatId,
    text,
    parse_mode: 'HTML',
    disable_web_page_preview: false
  });

  const request = https.request(
    {
      hostname: 'api.telegram.org',
      path: `/bot${config.telegramToken}/sendMessage`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    },
    response => {
      let body = '';
      response.on('data', chunk => {
        body += chunk;
      });
      response.on('end', () => {
        if (response.statusCode === 200) {
          console.log('[Telegram] Text alert sent.');
        } else {
          console.error(`[Telegram] HTTP ${response.statusCode}: ${body.slice(0, 300)}`);
        }
      });
    }
  );

  request.on('error', error => console.error('[Telegram Error]:', error.message));
  request.write(payload);
  request.end();
}

function sendTelegramNotification(item) {
  if (!config.enableTelegram || !config.telegramToken || !config.telegramChatId) return;

  const text = buildTelegramMessage(item);
  const imageUrl = item.img_url;

  if (!imageUrl || !String(imageUrl).startsWith('http')) {
    sendTelegramTextOnly(text);
    return;
  }

  const payload = JSON.stringify({
    chat_id: config.telegramChatId,
    photo: imageUrl,
    caption: text,
    parse_mode: 'HTML'
  });

  const request = https.request(
    {
      hostname: 'api.telegram.org',
      path: `/bot${config.telegramToken}/sendPhoto`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    },
    response => {
      let body = '';
      response.on('data', chunk => {
        body += chunk;
      });
      response.on('end', () => {
        if (response.statusCode === 200) {
          console.log(`[Telegram] Photo alert sent: ${item.asin}`);
        } else {
          console.warn(`[Telegram] Photo HTTP ${response.statusCode}; using text fallback.`);
          sendTelegramTextOnly(text);
        }
      });
    }
  );

  request.on('error', () => sendTelegramTextOnly(text));
  request.write(payload);
  request.end();
}

async function sendDiscordWebhook(item) {
  if (!config.discordWebhook) return;

  try {
    const sourceTag = (item.sources || []).join(' + ') || 'Drop';
    await axios.post(
      config.discordWebhook,
      {
        username: 'Vine Drop Hub',
        embeds: [
          {
            title: `${item.isHighlight ? '🚨 [HIGHLIGHT] ' : ''}[${sourceTag}] ${String(
              item.title || 'Unknown Product'
            ).slice(0, 200)}`,
            url: item.dpUrl,
            color: item.isHighlight ? 0xff4757 : item.isZeroEtv ? 0x2ed573 : 0x70a1ff,
            fields: [
              { name: 'ASIN', value: `\`${item.asin}\``, inline: true },
              { name: 'Queue', value: item.queue || 'AI', inline: true },
              {
                name: 'ETV / Price',
                value: item.etv != null && item.etv !== 'N/A' ? `$${item.etv}` : 'N/A',
                inline: true
              },
              {
                name: 'Sources',
                value: (item.sources || []).join(', ') || 'Live',
                inline: true
              },
              {
                name: 'Vine 2-Word Search',
                value: `[🔍 Search Vine: "${item.firstTwoWords}"](${item.vineSearchUrl})`,
                inline: false
              },
              { name: 'Links', value: `[🛒 Amazon Page](${item.dpUrl})`, inline: false }
            ],
            thumbnail: item.img_url ? { url: item.img_url } : undefined,
            timestamp: new Date().toISOString()
          }
        ]
      },
      { timeout: 8000 }
    );
  } catch (error) {
    console.error('[Discord Webhook Error]:', error.message);
  }
}

// ============================================================================
// EXPRESS/LOCAL WEBSOCKET STATE
// ============================================================================
let uvStatus = 'Disconnected';
let vhStatus = VH_FORCE_DISABLED ? 'Disabled (UV-only process mode)' : 'Disabled';

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const localWss = new WebSocket.Server({ server, path: '/ws-feed' });

function broadcastLocal(type, data) {
  const message = JSON.stringify({ type, data });
  localWss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) client.send(message);
  });
}

function addActivity(type, data) {
  const entry = { type, data, date: new Date().toISOString() };
  activityLog.unshift(entry);
  if (activityLog.length > 1000) activityLog.length = 1000;
  saveJSON(ACTIVITY_FILE, activityLog);
  broadcastLocal('activity', entry);
}

function notifyLiveItem(item) {
  if (!item || item.isHide || item.isHiddenManual) return false;
  if (wasRecentlyNotified(item.asin)) return false;

  markNotified(item.asin);
  sendTelegramNotification(item);
  void sendDiscordWebhook(item);
  return true;
}

localWss.on('connection', socket => {
  socket.send(
    JSON.stringify({
      type: 'init',
      data: {
        status: { uvStatus, vhStatus },
        itemsCount: allItems.length,
        keywords,
        pinnedAsins: [...pinnedAsins],
        dismissedPriorityAsins: [...dismissedPriorityAsins],
        hiddenAsins: [...hiddenAsins],
        config: {
          domain: config.domain,
          countryCode: config.countryCode,
          enableUV: config.enableUV,
          enableVH: config.enableVH,
          effectiveVHEnabled: isVhEnabled(),
          vhForceDisabled: VH_FORCE_DISABLED,
          hasToken: Boolean(config.token),
          minPriorityPrice: config.minPriorityPrice,
          enableTelegram: config.enableTelegram,
          hasTelegramToken: Boolean(config.telegramToken),
          telegramChatId: config.telegramChatId,
          hasWebhook: Boolean(config.discordWebhook)
        }
      }
    })
  );
});

// ============================================================================
// UNIFIED ITEM INGESTION
// ============================================================================
function ingestItem(raw, source = 'UV', eventType = 'drop', fallbackQueue = null) {
  if (!raw) return null;

  const flattened = raw.details ? { ...raw, ...raw.details } : { ...raw };
  const asin = flattened.asin || flattened.parentAsin || raw.asin || raw.parentAsin;
  if (!asin || asin === 'N/A') return null;

  const existingIndex = allItems.findIndex(item => item.asin === asin);
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const isBackfill = BACKFILL_EVENT_TYPES.has(eventType);

  const sourceTime = parseItemTime(flattened);
  const addedMs = isBackfill && sourceTime != null ? sourceTime : nowMs;
  const addedIso = new Date(addedMs).toISOString();

  const pick = (incoming, previous) => {
    const empty = value =>
      value === undefined ||
      value === null ||
      value === '' ||
      value === 'N/A' ||
      value === 'Unknown Product';

    if (isBackfill) {
      return !empty(previous) ? previous : !empty(incoming) ? incoming : previous;
    }
    return !empty(incoming) ? incoming : previous;
  };

  let rawQueue =
    flattened.queue ||
    flattened.queueType ||
    flattened.type ||
    flattened.recommendationType ||
    flattened.queue_type ||
    flattened.queueName ||
    '';

  if (!rawQueue) {
    if (flattened.rfyOrders > 0 && !flattened.afaOrders && !flattened.aiOrders) {
      rawQueue = 'RFY';
    } else if (flattened.afaOrders > 0 && !flattened.rfyOrders && !flattened.aiOrders) {
      rawQueue = 'AFA';
    }
  }

  const queue = normalizeQueue(rawQueue, eventType, fallbackQueue);
  const previous = existingIndex >= 0 ? allItems[existingIndex] : null;
  const rawTitle = flattened.title || flattened.name || previous?.title || 'Unknown Product';
  const title = decodeHtmlEntities(rawTitle).trim();
  const firstTwoWords = getFirstTwoWords(title);
  const vineSearchUrl = getTwoWordSearchUrl(title, config.domain);
  const dpUrl = `https://www.${config.domain}/dp/${asin}`;

  const price = flattened.price ?? previous?.price ?? 'N/A';
  const etv = flattened.etv ?? flattened.price ?? previous?.etv ?? 'N/A';
  const etvMin = flattened.etv_min ?? flattened.etv ?? previous?.etv_min ?? null;
  const etvMax = flattened.etv_max ?? flattened.etv ?? previous?.etv_max ?? null;
  const isZeroEtv =
    [etv, etvMin].some(value => value !== null && value !== 'N/A' && Number(value) === 0) ||
    Boolean(previous?.isZeroEtv);

  const imgUrl =
    flattened.img_url ||
    flattened.imageUrl ||
    flattened.img ||
    flattened.thumbnail ||
    previous?.img_url ||
    null;

  const additionalImages =
    flattened.additional_img || flattened.images || previous?.additional_img || [];
  const brand =
    flattened.brand || flattened.byLine || flattened.seller || previous?.brand || 'Unknown';
  const variants = flattened.variants || previous?.variants || [];
  const unavailable = flattened.unavailable ?? previous?.unavailable ?? false;
  const limited = flattened.limited ?? previous?.limited ?? false;
  const coupon = flattened.coupon || previous?.coupon || '';
  const discount = flattened.discount || previous?.discount || '';
  const stars = flattened.stars || previous?.stars || '';
  const reviewers = flattened.reviewers || previous?.reviewers || '';
  const orderSuccess = flattened.order_success ?? previous?.order_success ?? 0;
  const orderFailed = flattened.order_failed ?? previous?.order_failed ?? 0;

  const matches = checkKeywordMatches(title, price, etv);
  const isPinned = pinnedAsins.has(asin);
  const isPriorityDismissed = dismissedPriorityAsins.has(asin);
  const isHiddenManual = hiddenAsins.has(asin);

  if (existingIndex !== -1) {
    const existing = allItems[existingIndex];
    const sources = Array.isArray(existing.sources)
      ? [...existing.sources]
      : [existing.source || source];
    if (!sources.includes(source)) sources.push(source);

    const hadLiveBefore = existing.live_uv_ms != null || existing.live_vh_ms != null;
    const promotedFromBackfill = !isBackfill && !hadLiveBefore;

    let discoveredUvAt = existing.discovered_uv_at || null;
    let discoveredUvMs = existing.discovered_uv_ms ?? null;
    let discoveredVhAt = existing.discovered_vh_at || null;
    let discoveredVhMs = existing.discovered_vh_ms ?? null;
    let liveUvAt = existing.live_uv_at || null;
    let liveUvMs = existing.live_uv_ms ?? null;
    let liveVhAt = existing.live_vh_at || null;
    let liveVhMs = existing.live_vh_ms ?? null;

    if (source === 'UV' && discoveredUvMs == null) {
      discoveredUvAt = nowIso;
      discoveredUvMs = nowMs;
    }
    if (source === 'VH' && discoveredVhMs == null) {
      discoveredVhAt = nowIso;
      discoveredVhMs = nowMs;
    }

    if (!isBackfill) {
      if (source === 'UV' && liveUvMs == null) {
        liveUvAt = nowIso;
        liveUvMs = nowMs;
      }
      if (source === 'VH' && liveVhMs == null) {
        liveVhAt = nowIso;
        liveVhMs = nowMs;
      }
    }

    let firstDiscoveredBy = existing.firstDiscoveredBy || null;
    let firstDiscoveredAt = existing.firstDiscoveredAt || null;
    let firstDiscoveredMs = existing.firstDiscoveredMs ?? null;

    if (liveUvMs != null && liveVhMs != null) {
      if (liveUvMs <= liveVhMs) {
        firstDiscoveredBy = 'UV';
        firstDiscoveredAt = liveUvAt;
        firstDiscoveredMs = liveUvMs;
      } else {
        firstDiscoveredBy = 'VH';
        firstDiscoveredAt = liveVhAt;
        firstDiscoveredMs = liveVhMs;
      }
    } else if (liveUvMs != null) {
      firstDiscoveredBy = 'UV';
      firstDiscoveredAt = liveUvAt;
      firstDiscoveredMs = liveUvMs;
    } else if (liveVhMs != null) {
      firstDiscoveredBy = 'VH';
      firstDiscoveredAt = liveVhAt;
      firstDiscoveredMs = liveVhMs;
    }

    const leadMs =
      liveUvMs != null && liveVhMs != null ? Math.abs(liveUvMs - liveVhMs) : null;

    const mergedItem = {
      ...existing,
      asin,
      title: pick(title, existing.title),
      firstTwoWords: pick(firstTwoWords, existing.firstTwoWords),
      sources,
      firstDiscoveredBy,
      firstDiscoveredAt,
      firstDiscoveredMs,
      discovered_uv_at: discoveredUvAt,
      discovered_uv_ms: discoveredUvMs,
      discovered_vh_at: discoveredVhAt,
      discovered_vh_ms: discoveredVhMs,
      live_uv_at: liveUvAt,
      live_uv_ms: liveUvMs,
      live_vh_at: liveVhAt,
      live_vh_ms: liveVhMs,
      leadMs,
      queue: isBackfill ? existing.queue || queue : queue || existing.queue,
      price: pick(price, existing.price),
      etv: pick(etv, existing.etv),
      etv_min: etvMin ?? existing.etv_min,
      etv_max: etvMax ?? existing.etv_max,
      isZeroEtv,
      img_url: pick(imgUrl, existing.img_url),
      additional_img: additionalImages?.length
        ? additionalImages
        : existing.additional_img || [],
      brand: pick(brand, existing.brand),
      variants: variants?.length ? variants : existing.variants || [],
      unavailable: Boolean(unavailable),
      limited: Boolean(limited),
      coupon: pick(coupon, existing.coupon),
      discount: pick(discount, existing.discount),
      stars: pick(stars, existing.stars),
      reviewers: pick(reviewers, existing.reviewers),
      order_success: orderSuccess,
      order_failed: orderFailed,
      isHighlight: matches.isHighlight || existing.isHighlight,
      isPriceHighlight: matches.isPriceHighlight || existing.isPriceHighlight,
      isHide: matches.isHide,
      isBlur: matches.isBlur,
      isPinned,
      isPriorityDismissed,
      isHiddenManual,
      date_added: promotedFromBackfill ? nowIso : existing.date_added || addedIso,
      date_added_ms: promotedFromBackfill ? nowMs : existing.date_added_ms ?? addedMs,
      last_seen: nowIso,
      last_seen_ms: nowMs,
      last_live_event_at: !isBackfill ? nowIso : existing.last_live_event_at,
      last_live_event_ms: !isBackfill ? nowMs : existing.last_live_event_ms,
      last_updated_by: source,
      uv_event_at: flattened.uv_event_at || existing.uv_event_at,
      vineSearchUrl,
      dpUrl
    };

    allItems[existingIndex] = mergedItem;
    sortItemsArray(allItems);
    saveJSON(ITEMS_FILE, allItems);

    if (!isBackfill) {
      if (promotedFromBackfill) {
        broadcastLocal('new_item', mergedItem);
        addActivity('new_item', {
          asin,
          title: mergedItem.title,
          source,
          queue: mergedItem.queue,
          price: mergedItem.price,
          etv: mergedItem.etv,
          firstDiscoveredBy: mergedItem.firstDiscoveredBy,
          promotedFromBackfill: true
        });
        notifyLiveItem(mergedItem);
      } else {
        broadcastLocal('update_item', mergedItem);
      }
    }

    const leadText = leadMs != null ? ` | lead=${leadMs}ms (${firstDiscoveredBy})` : '';
    const modeText = isBackfill
      ? 'backfill/silent'
      : promotedFromBackfill
        ? 'promoted-to-live'
        : 'live-merge';
    console.log(
      `[Merged] [${sources.join('+')}] [${mergedItem.queue}] ${asin}${leadText} ` +
        `(${modeText}) - ${mergedItem.title.slice(0, 60)}`
    );
    return mergedItem;
  }

  const discoveredUvAt = source === 'UV' ? nowIso : null;
  const discoveredUvMs = source === 'UV' ? nowMs : null;
  const discoveredVhAt = source === 'VH' ? nowIso : null;
  const discoveredVhMs = source === 'VH' ? nowMs : null;
  const liveUvAt = !isBackfill && source === 'UV' ? nowIso : null;
  const liveUvMs = !isBackfill && source === 'UV' ? nowMs : null;
  const liveVhAt = !isBackfill && source === 'VH' ? nowIso : null;
  const liveVhMs = !isBackfill && source === 'VH' ? nowMs : null;

  const newItem = {
    asin,
    title,
    firstTwoWords,
    sources: [source],
    firstDiscoveredBy: source,
    firstDiscoveredAt: isBackfill ? addedIso : nowIso,
    firstDiscoveredMs: isBackfill ? addedMs : nowMs,
    discovered_uv_at: discoveredUvAt,
    discovered_uv_ms: discoveredUvMs,
    discovered_vh_at: discoveredVhAt,
    discovered_vh_ms: discoveredVhMs,
    live_uv_at: liveUvAt,
    live_uv_ms: liveUvMs,
    live_vh_at: liveVhAt,
    live_vh_ms: liveVhMs,
    leadMs: null,
    queue,
    price,
    etv,
    etv_min: etvMin,
    etv_max: etvMax,
    isZeroEtv,
    img_url: imgUrl,
    additional_img: additionalImages,
    brand,
    variants,
    unavailable: Boolean(unavailable),
    limited: Boolean(limited),
    coupon,
    discount,
    stars,
    reviewers,
    order_success: orderSuccess,
    order_failed: orderFailed,
    recommendation: flattened.recommendation,
    isParentAsin: flattened.isParentAsin,
    isPreRelease: flattened.isPreRelease,
    hashtagCount: flattened.hashtagCount,
    isHighlight: matches.isHighlight,
    isPriceHighlight: matches.isPriceHighlight,
    isHide: matches.isHide,
    isBlur: matches.isBlur,
    isPinned,
    isPriorityDismissed,
    isHiddenManual,
    date_added: addedIso,
    date_added_ms: addedMs,
    last_seen: nowIso,
    last_seen_ms: nowMs,
    last_live_event_at: !isBackfill ? nowIso : null,
    last_live_event_ms: !isBackfill ? nowMs : null,
    last_updated_by: source,
    uv_event_at: flattened.uv_event_at || null,
    vineSearchUrl,
    dpUrl
  };

  allItems.push(newItem);
  sortItemsArray(allItems);
  if (allItems.length > (Number(config.maxStoredItems) || 2000)) allItems.pop();
  saveJSON(ITEMS_FILE, allItems);

  if (!isBackfill) {
    broadcastLocal('new_item', newItem);
    addActivity('new_item', {
      asin,
      title,
      source,
      queue,
      price,
      etv,
      firstDiscoveredBy: source
    });
    notifyLiveItem(newItem);
    console.log(`[New Drop] [${source}] [${queue}] ${asin} - ${title.slice(0, 70)}`);
  } else {
    console.log(`[Backfill] [${source}] [${queue}] ${asin} (silent)`);
  }

  return newItem;
}

// Official Ultraviner treats alertDetail/pageData as enrichment only. This
// function never inserts a new item and never stamps a live discovery clock.
function applyUvAlertDetail(raw, messageType = 'alertDetail') {
  const detail = raw?.details ? { ...raw, ...raw.details } : { ...raw };
  const asin = detail.asin || detail.parentAsin;
  if (!asin) return null;

  const index = allItems.findIndex(item => item.asin === asin);
  if (index === -1) {
    console.log(`[UV DETAIL] Orphan ${messageType} ignored: ${asin}`);
    return null;
  }

  const existing = allItems[index];
  const sources = Array.isArray(existing.sources)
    ? [...existing.sources]
    : [existing.source || 'UV'];
  if (!sources.includes('UV')) sources.push('UV');

  const etv = detail.etv ?? existing.etv;
  const matches = checkKeywordMatches(existing.title, existing.price, etv);
  const hasEtv = etv != null && etv !== '' && etv !== 'N/A';
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();

  const updated = {
    ...existing,
    sources,
    recommendation: detail.recommendation ?? existing.recommendation,
    img_url: detail.imageUrl || detail.img_url || existing.img_url,
    additional_img:
      Array.isArray(detail.images) && detail.images.length
        ? detail.images
        : existing.additional_img,
    etv,
    etv_min: detail.etv !== undefined ? detail.etv : existing.etv_min,
    etv_max: detail.etv !== undefined ? detail.etv : existing.etv_max,
    isZeroEtv: (hasEtv && Number(etv) === 0) || existing.isZeroEtv,
    limited: detail.limited ?? existing.limited,
    seller: detail.seller ?? existing.seller,
    multiple_options: Array.isArray(detail.multiple_options)
      ? detail.multiple_options
      : existing.multiple_options,
    multiple_colors: Array.isArray(detail.multiple_colors)
      ? detail.multiple_colors
      : existing.multiple_colors,
    multiple_sizes: Array.isArray(detail.multiple_sizes)
      ? detail.multiple_sizes
      : existing.multiple_sizes,
    isParentAsin: detail.isParentAsin ?? existing.isParentAsin,
    isPreRelease: detail.isPreRelease ?? existing.isPreRelease,
    hashtagCount: detail.hashtagCount ?? existing.hashtagCount,
    isHighlight: matches.isHighlight || existing.isHighlight,
    isPriceHighlight: matches.isPriceHighlight || existing.isPriceHighlight,
    isHide: matches.isHide,
    isBlur: matches.isBlur,
    last_seen: nowIso,
    last_seen_ms: nowMs,
    last_detail_at: nowIso,
    last_updated_by: 'UV_DETAIL'
  };

  allItems[index] = updated;
  sortItemsArray(allItems);
  saveJSON(ITEMS_FILE, allItems);
  broadcastLocal('update_item', updated);
  console.log(`[UV DETAIL] Enriched existing item: ${asin}`);
  return updated;
}

function extractUvProducts(message) {
  const data = message?.data;
  if (Array.isArray(data?.products)) return data.products;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data)) return data;
  if (data?.product) return [data.product];
  if (data?.item) return [data.item];
  if (data?.asin || data?.parentAsin) return [data];
  if (message?.asin || message?.parentAsin) return [message];
  return [];
}

// ============================================================================
// ULTRAVINER STREAM
// ============================================================================
let uvWs = null;
let uvPingInterval = null;
let uvReconnectTimer = null;
let uvIdentificationTimer = null;
let uvAuthenticationTimer = null;
let uvGeneration = 0;
let uvReconnectBlocked = false;
let uvAuthenticated = false;
let uvConnectedAt = null;
let uvLastFrameAt = null;
let uvLastAlertAt = null;
const uvRecentFrames = [];

function clearUvTimers() {
  if (uvPingInterval) clearInterval(uvPingInterval);
  if (uvReconnectTimer) clearTimeout(uvReconnectTimer);
  if (uvIdentificationTimer) clearTimeout(uvIdentificationTimer);
  if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
  uvPingInterval = null;
  uvReconnectTimer = null;
  uvIdentificationTimer = null;
  uvAuthenticationTimer = null;
}

function destroyUvSocket() {
  if (!uvWs) return;
  try {
    uvWs.removeAllListeners();
    uvWs.terminate();
  } catch (_) {}
  uvWs = null;
}

function stopUltraviner(status = 'Disabled') {
  uvGeneration += 1;
  uvReconnectBlocked = true;
  uvAuthenticated = false;
  clearUvTimers();
  destroyUvSocket();
  uvStatus = status;
  broadcastLocal('status', { uvStatus, vhStatus });
  console.log(`[UV WS] ${status}`);
}

function validateUvConfig() {
  const required = ['token', 'azUser', 'device', 'selectedScreenId', 'alertQueueId'];
  const missing = required.filter(key => !config[key]);
  if (missing.length) throw new Error(`Missing UV configuration: ${missing.join(', ')}`);
}

function effectiveUvIdentity() {
  return {
    device: config.device,
    azUserHash: sha256(config.azUser),
    selectedScreenId: config.selectedScreenId,
    alertQueueId: config.alertQueueId,
    displayName: config.displayName,
    domain: config.domain,
    userAgent: config.uvUserAgent
  };
}

function scheduleUvReconnect(generation) {
  if (
    generation !== uvGeneration ||
    uvReconnectBlocked ||
    !config.enableUV ||
    uvReconnectTimer
  ) {
    return;
  }

  const delay = Math.max(1000, Number(config.uvReconnectDelayMs) || 5000);
  uvReconnectTimer = setTimeout(() => {
    uvReconnectTimer = null;
    connectUltraviner();
  }, delay);
  console.log(`[UV WS] Reconnect scheduled in ${delay}ms.`);
}

function recordUvFrame(type, productCount) {
  uvLastFrameAt = new Date().toISOString();
  uvRecentFrames.unshift({ type, productCount, date: uvLastFrameAt });
  if (uvRecentFrames.length > 25) uvRecentFrames.length = 25;
}

function connectUltraviner() {
  if (!config.enableUV) {
    stopUltraviner('Disabled');
    return;
  }

  try {
    validateUvConfig();
  } catch (error) {
    stopUltraviner(error.message);
    return;
  }

  uvGeneration += 1;
  const generation = uvGeneration;
  uvReconnectBlocked = false;
  uvAuthenticated = false;
  clearUvTimers();
  destroyUvSocket();

  const userAgent = config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent;
  const wsUrl = 'wss://api.ultraviner.com/';
  const headers = {
    Origin: `https://www.${config.domain}`,
    'User-Agent': userAgent,
    'Accept-Language': 'en-CA,en;q=0.9,ar;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    Pragma: 'no-cache',
    'Cache-Control': 'no-cache'
  };

  uvStatus = 'Connecting...';
  broadcastLocal('status', { uvStatus, vhStatus });
  console.log(`[UV WS] Connecting to ${wsUrl} for ${config.domain}...`);

  try {
    const socket = new WebSocket(wsUrl, {
      headers,
      handshakeTimeout: 15000,
      perMessageDeflate: true
    });
    uvWs = socket;

    socket.on('open', () => {
      if (generation !== uvGeneration || socket !== uvWs) return;

      uvConnectedAt = new Date().toISOString();
      uvStatus = 'Authenticating...';
      broadcastLocal('status', { uvStatus, vhStatus });
      console.log('[UV WS] Socket open; waiting before identification.');

      const delay = Math.max(0, Number(config.uvIdentificationDelayMs) || 500);
      uvIdentificationTimer = setTimeout(() => {
        uvIdentificationTimer = null;
        if (generation !== uvGeneration || socket.readyState !== WebSocket.OPEN) return;

        const identity = effectiveUvIdentity();
        const payload = {
          type: 'identification',
          token: config.token,
          data: {
            device: identity.device,
            azUser: identity.azUserHash,
            userAgent,
            height: 912,
            width: 1707,
            isTouchDevice: false,
            syncBookmarks: true,
            syncScreens: true,
            version: '26.9.11',
            domain: config.domain,
            launcherVersion: '1.0.19',
            launcherType: 'userscript',
            launcherPlatform: 'win32',
            displayName: config.displayName,
            selectedScreenId: config.selectedScreenId,
            alertQueues: [{ id: config.alertQueueId, name: '' }],
            chatQueues: [],
            themeName: 'Dark',
            language: 'EN',
            tier: 'gold',
            isFirefox: false
          }
        };

        const serializedIdentification = JSON.stringify(payload);
        socket.send(serializedIdentification, error => {
          if (error) {
            console.error('[UV WS] Identification write failed:', error.message);
            return;
          }
          console.log(
            `[UV WS] Identification frame flushed (${Buffer.byteLength(serializedIdentification)} bytes).`
          );
        });

        console.log('[UV WS] Identification queued:', {
          ...identity,
          token: '<redacted>',
          tokenLength: String(config.token || '').length,
          tokenFingerprint: sha256(config.token).slice(0, 12)
        });

        const authenticationTimeout = Math.max(
          5000,
          Number(config.uvAuthenticationTimeoutMs) || 15000
        );
        uvAuthenticationTimer = setTimeout(() => {
          uvAuthenticationTimer = null;
          if (
            generation !== uvGeneration ||
            socket !== uvWs ||
            socket.readyState !== WebSocket.OPEN ||
            uvAuthenticated
          ) {
            return;
          }

          // Do not hammer the service with an endless reconnect loop when the
          // application silently rejects identification. Require a manual
          // reconnect after the token/device/network issue is corrected.
          uvReconnectBlocked = true;
          uvStatus = 'Authentication timeout';
          broadcastLocal('status', { uvStatus, vhStatus });
          console.error(
            `[UV WS] No connected/plan response within ${authenticationTimeout}ms. ` +
              'Verify the token, close duplicate clients, or use a dedicated device UUID.'
          );
          try {
            socket.close(4001, 'authentication timeout');
          } catch (_) {}
        }, authenticationTimeout);
      }, delay);

      uvPingInterval = setInterval(() => {
        if (
          generation === uvGeneration &&
          socket === uvWs &&
          socket.readyState === WebSocket.OPEN
        ) {
          socket.send(JSON.stringify({ type: 'ping' }));
        }
      }, 30000);
    });

    socket.on('message', raw => {
      if (generation !== uvGeneration || socket !== uvWs) return;

      const text = raw.toString();
      if (text === 'ping') {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({ type: 'pong' }));
        }
        return;
      }
      if (text === 'pong') return;

      let message;
      try {
        message = JSON.parse(text);
      } catch (error) {
        console.error('[UV WS] Non-JSON frame:', text.slice(0, 500));
        return;
      }

      const { type, data } = message;
      if (type === 'ping') {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({ type: 'pong' }));
        }
        return;
      }
      if (type === 'pong') return;

      const products = extractUvProducts(message);
      recordUvFrame(type || '<missing>', products.length);
      console.log(`[UV FRAME] type=${type || '<missing>'} products=${products.length}`);

      if (type === 'connected') {
        if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
        uvAuthenticationTimer = null;
        uvAuthenticated = true;
        uvStatus = 'Authenticated';
        broadcastLocal('status', { uvStatus, vhStatus });
        console.log('[UV WS] Session authenticated.');
        return;
      }

      if (type === 'invalidToken') {
        if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
        uvAuthenticationTimer = null;
        uvReconnectBlocked = true;
        uvAuthenticated = false;
        uvStatus = 'Invalid / Expired Token';
        broadcastLocal('status', { uvStatus, vhStatus });
        console.error('[UV WS] invalidToken; automatic reconnect blocked.');
        try {
          socket.close(1000, 'invalid token');
        } catch (_) {}
        return;
      }

      if (type === 'plan') {
        if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
        uvAuthenticationTimer = null;
        uvAuthenticated = true;
        if (uvStatus !== 'Authenticated') {
          uvStatus = 'Authenticated';
          broadcastLocal('status', { uvStatus, vhStatus });
        }
        console.log(`[UV WS] Plan: ${typeof data === 'object' ? JSON.stringify(data) : data}`);
        return;
      }

      const housekeepingTypes = new Set([
        'status',
        'patreon',
        'categories',
        'categoryList',
        'subcategoryList',
        'connectionSummary',
        'speedometer',
        'screens',
        'screen',
        'hiveLoad',
        'version',
        'promotion',
        'electronVersion',
        'refreshWebhooks'
      ]);
      if (housekeepingTypes.has(type)) return;

      if (UV_DETAIL_TYPES.has(type)) {
        if (!products.length) {
          console.log(`[UV DETAIL] ${type} contained no products.`);
          return;
        }
        products.forEach(product => applyUvAlertDetail(product, type));
        return;
      }

      if (!UV_LIVE_ALERT_TYPES.has(type)) {
        console.log(`[UV WS] Ignoring non-alert type: ${type}`);
        return;
      }

      if (uvAuthenticationTimer) clearTimeout(uvAuthenticationTimer);
      uvAuthenticationTimer = null;
      uvAuthenticated = true;
      uvStatus = 'Authenticated';
      uvLastAlertAt = data?.now || new Date().toISOString();
      broadcastLocal('status', { uvStatus, vhStatus });

      if (!products.length) {
        console.log(
          `[UV WS] Live alert ${type} contained no products: ${JSON.stringify(message).slice(
            0,
            1000
          )}`
        );
        return;
      }

      console.log(
        `[UV LIVE] ${type}: ${products.length} item(s), serverTime=${data?.now || 'n/a'}`
      );

      products.forEach(product => {
        const itemObj = product.details
          ? { ...product, ...product.details }
          : { ...product };

        itemObj.uv_event_at = data?.now || itemObj.date || new Date().toISOString();

        if (!itemObj.queue && !itemObj.queueType && !itemObj.recommendationType) {
          itemObj.queue =
            type === 'alertFromBrenda' || type === 'alertDetailsFromBrenda'
              ? 'Discord/Brenda'
              : 'AI';
        }

        ingestItem(itemObj, 'UV', type);
      });
    });

    socket.on('close', (code, reasonBuffer) => {
      if (generation !== uvGeneration || socket !== uvWs) return;

      const reason = reasonBuffer?.toString() || '(none)';
      console.log(`[UV WS] Closed: code=${code}, reason=${reason}`);
      clearUvTimers();
      uvWs = null;
      uvAuthenticated = false;

      if (!uvReconnectBlocked && config.enableUV) {
        uvStatus = 'Disconnected; reconnecting...';
        broadcastLocal('status', { uvStatus, vhStatus });
        scheduleUvReconnect(generation);
      } else if (!config.enableUV) {
        uvStatus = 'Disabled';
        broadcastLocal('status', { uvStatus, vhStatus });
      }
    });

    socket.on('error', error => {
      if (generation !== uvGeneration || socket !== uvWs) return;
      console.error('[UV WS] Error:', error.message);
    });
  } catch (error) {
    console.error('[UV WS] Setup error:', error.message);
    uvStatus = `Error: ${error.message}`;
    broadcastLocal('status', { uvStatus, vhStatus });
    scheduleUvReconnect(generation);
  }
}

// ============================================================================
// UV CATALOG/EXPLORER
// ============================================================================
function formatProductForDisplay(product, fallbackQueue = 'RFY') {
  const flattened = product.details ? { ...product, ...product.details } : product;
  const asin = flattened.asin || flattened.parentAsin || 'N/A';
  const title = decodeHtmlEntities(flattened.title || flattened.name || 'Unknown Product').trim();
  const rawQueue =
    flattened.queue ||
    flattened.queueType ||
    flattened.type ||
    flattened.recommendationType ||
    flattened.queue_type ||
    '';
  const queue = normalizeQueue(rawQueue, '', fallbackQueue);
  const price = flattened.price ?? 'N/A';
  const etv = flattened.etv ?? flattened.price ?? 'N/A';
  const imgUrl =
    flattened.img_url || flattened.imageUrl || flattened.img || flattened.thumbnail || '';
  const brand = flattened.brand || flattened.byLine || flattened.seller || 'Unknown';
  const matches = checkKeywordMatches(title, price, etv);

  return {
    asin,
    title,
    firstTwoWords: getFirstTwoWords(title),
    sources: ['UV'],
    firstDiscoveredBy: 'UV',
    queue,
    price,
    etv,
    isZeroEtv: etv !== 'N/A' && Number(etv) === 0,
    img_url: imgUrl,
    brand,
    isHighlight: matches.isHighlight,
    isPriceHighlight: matches.isPriceHighlight,
    isPinned: pinnedAsins.has(asin),
    date_added: flattened.date_added || flattened.date || new Date().toISOString(),
    vineSearchUrl: getTwoWordSearchUrl(title, config.domain),
    dpUrl: `https://www.${config.domain}/dp/${asin}`
  };
}

async function fetchInitialUvCatalog() {
  if (!config.token || !config.enableUV) return;

  const countryId = Ge[config.domain] || 2;
  const queueId = config.exploreQueueId || config.alertQueueId;
  if (!queueId) {
    console.warn('[UV Sync] Missing exploreQueueId/alertQueueId.');
    return;
  }

  try {
    const signedPayload = {
      pageSize: '100',
      page: '1',
      searchTerm: '',
      countryId: countryId.toString(),
      categories: '',
      queueTypes: 'RFY,AI,AFA',
      queueId,
      queueName: 'Explore'
    };
    const body = { token: config.token, ...signedPayload };
    const headers = {
      ...signUvPayload(signedPayload, config.token),
      Authorization: `Bearer ${config.token}`,
      Origin: `https://www.${config.domain}`,
      Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
      'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
    };

    const response = await fetch('https://api.ultraviner.com/ultraviner/search', {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      console.warn(`[UV Sync] HTTP ${response.status}: ${(await response.text()).slice(0, 300)}`);
      return;
    }

    const data = await response.json();
    const products = Array.isArray(data.products) ? data.products : [];
    console.log(`[UV Sync] Ingesting ${products.length} catalog records silently.`);

    for (let index = products.length - 1; index >= 0; index -= 1) {
      const product = products[index];
      ingestItem(product.details ? { ...product, ...product.details } : product, 'UV', 'INITIAL_LOAD');
    }

    sortItemsArray(allItems);
    saveJSON(ITEMS_FILE, allItems);
    broadcastLocal('feed_refreshed', { count: allItems.length });
  } catch (error) {
    console.error('[UV Sync] Error:', error.message);
  }
}

// ============================================================================
// VHELPER STREAM — HARD-DISABLE CAPABLE
// ============================================================================
let vhSocket = null;
let vhLast100Received = false;

function stopVHelper(status) {
  if (vhSocket) {
    try {
      vhSocket.removeAllListeners();
      vhSocket.disconnect();
      vhSocket.close();
    } catch (_) {}
    vhSocket = null;
  }

  vhLast100Received = false;
  vhStatus =
    status ||
    (VH_FORCE_DISABLED ? 'Disabled (UV-only process mode)' : 'Disabled');
  broadcastLocal('status', { uvStatus, vhStatus });
  console.log(`[VH WS] ${vhStatus}`);
}

async function connectVHelper() {
  // Always destroy an existing Socket.IO manager before deciding whether to
  // connect. The original code returned too early and left VH running.
  stopVHelper(isVhEnabled() ? 'Restarting...' : undefined);

  if (!isVhEnabled()) return;

  vhStatus = 'Connecting...';
  broadcastLocal('status', { uvStatus, vhStatus });
  console.log(`[VH WS] Authenticating with ${VH_API_URL}...`);

  try {
    const identity = await identityManager.getOrCreateIdentity(config.countryCode || 'ca');
    if (!isVhEnabled()) return;

    const cid = identityManager.getCID(config.countryCode || 'ca', identity.customerId);
    const socket = ioClient(VH_WS_URL, {
      transports: ['websocket'],
      reconnection: true,
      query: {
        app_version: VH_APP_VERSION,
        countryCode: config.countryCode || 'ca',
        uuid: identity.uuid,
        fid: '',
        cid,
        device_name: VH_DEVICE_NAME
      }
    });
    vhSocket = socket;
    vhLast100Received = false;

    socket.on('connect', () => {
      if (socket !== vhSocket || !isVhEnabled()) return;
      vhStatus = 'Connected';
      broadcastLocal('status', { uvStatus, vhStatus });
      console.log('[VH WS] Connected.');
    });

    socket.on('connection_info', () => {
      if (socket !== vhSocket || !isVhEnabled()) return;
      console.log('[VH WS] Requesting last 100 historical records.');
      setTimeout(() => {
        if (socket === vhSocket && socket.connected && isVhEnabled()) {
          socket.emit('getLast100', {
            app_version: VH_APP_VERSION,
            uuid: identity.uuid,
            cid,
            fid: '',
            countryCode: config.countryCode || 'ca',
            limit: 100,
            request_variants: true
          });
        }
      }, 500);
    });

    socket.on('last100', data => {
      if (socket !== vhSocket || !isVhEnabled()) return;
      const products = data?.products || data?.items || [];
      console.log(`[VH WS] Received ${products.length} historical records.`);
      for (let index = products.length - 1; index >= 0; index -= 1) {
        const raw = products[index];
        ingestItem(raw.item || raw.product || raw, 'VH', 'HISTORICAL');
      }
      sortItemsArray(allItems);
      saveJSON(ITEMS_FILE, allItems);
      broadcastLocal('feed_refreshed', { count: allItems.length });
      vhLast100Received = true;
    });

    socket.on('newItem', data => {
      if (socket === vhSocket && isVhEnabled()) {
        ingestItem(data.item || data.product || data, 'VH', 'newItem');
      }
    });

    socket.on('items', data => {
      if (socket !== vhSocket || !isVhEnabled()) return;
      (data.items || []).forEach(raw =>
        ingestItem(raw.item || raw.product || raw, 'VH', 'items')
      );
    });

    socket.on('message', data => {
      if (socket !== vhSocket || !isVhEnabled()) return;
      try {
        const payload = typeof data === 'string' ? JSON.parse(data) : data;
        if (payload.action === 'pong') return;
        ingestItem(payload.item || payload.product || payload, 'VH', 'message');
      } catch (error) {
        console.error('[VH WS] Message parse error:', error.message);
      }
    });

    socket.on('disconnect', reason => {
      if (socket !== vhSocket) return;
      vhStatus = isVhEnabled() ? 'Disconnected' : 'Disabled';
      broadcastLocal('status', { uvStatus, vhStatus });
      console.log(`[VH WS] Disconnected: ${reason}`);
    });

    socket.on('connect_error', error => {
      if (socket !== vhSocket) return;
      vhStatus = `Error: ${error.message}`;
      broadcastLocal('status', { uvStatus, vhStatus });
      console.error('[VH WS] Connect error:', error.message);
    });
  } catch (error) {
    if (!isVhEnabled()) return;
    vhStatus = `Failed: ${error.message}`;
    broadcastLocal('status', { uvStatus, vhStatus });
    console.error('[VH WS] Setup failure:', error.message);
  }
}

// ============================================================================
// REST API
// ============================================================================
app.get('/api/status', (req, res) => {
  const uvCount = allItems.filter(item => (item.sources || []).includes('UV')).length;
  const vhCount = allItems.filter(item => (item.sources || []).includes('VH')).length;
  const bothCount = allItems.filter(
    item => (item.sources || []).includes('UV') && (item.sources || []).includes('VH')
  ).length;

  res.json({
    uvStatus,
    vhStatus,
    uvAuthenticated,
    configuredVHEnabled: Boolean(config.enableVH),
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED,
    totalItems: allItems.length,
    uvCount,
    vhCount,
    bothCount,
    zeroEtvCount: allItems.filter(item => item.isZeroEtv).length,
    highlightCount: allItems.filter(item => item.isHighlight).length,
    rfyCount: allItems.filter(item => String(item.queue).toUpperCase() === 'RFY').length,
    afaCount: allItems.filter(item => String(item.queue).toUpperCase() === 'AFA').length,
    pinnedCount: pinnedAsins.size,
    domain: config.domain
  });
});

app.get('/api/items', (req, res) => {
  let items = [...allItems];
  const {
    search,
    asin,
    title,
    etv_min,
    etv_max,
    price_min,
    price_max,
    queue,
    source,
    zero_etv,
    highlight,
    show_hidden = 'false',
    pinned_only = 'false',
    page = 1,
    limit = 60
  } = req.query;

  if (show_hidden !== 'true') {
    items = items.filter(item => !item.isHide && !hiddenAsins.has(item.asin));
  }
  if (pinned_only === 'true') items = items.filter(item => pinnedAsins.has(item.asin));

  const query = String(search || title || asin || '').toLowerCase().trim();
  if (query) {
    items = items.filter(
      item =>
        String(item.title || '').toLowerCase().includes(query) ||
        String(item.asin || '').toLowerCase().includes(query) ||
        String(item.brand || '').toLowerCase().includes(query) ||
        String(item.firstTwoWords || '').toLowerCase().includes(query)
    );
  }

  if (queue && queue !== 'ALL') {
    items = items.filter(item => String(item.queue || '').toLowerCase() === queue.toLowerCase());
  }

  if (source && source !== 'ALL') {
    if (source === 'BOTH') {
      items = items.filter(
        item => (item.sources || []).includes('UV') && (item.sources || []).includes('VH')
      );
    } else if (source === 'UV_ONLY') {
      items = items.filter(
        item => (item.sources || []).includes('UV') && !(item.sources || []).includes('VH')
      );
    } else if (source === 'VH_ONLY') {
      items = items.filter(
        item => (item.sources || []).includes('VH') && !(item.sources || []).includes('UV')
      );
    } else {
      items = items.filter(item => (item.sources || []).includes(source));
    }
  }

  if (zero_etv === 'true') items = items.filter(item => item.isZeroEtv);
  if (highlight === 'true') items = items.filter(item => item.isHighlight);

  const etvMin = Number(etv_min);
  const etvMax = Number(etv_max);
  const priceMin = Number(price_min);
  const priceMax = Number(price_max);

  if (etv_min !== undefined && Number.isFinite(etvMin)) {
    items = items.filter(item => parseMoney(item.etv_min ?? item.etv, NaN) >= etvMin);
  }
  if (etv_max !== undefined && Number.isFinite(etvMax)) {
    items = items.filter(item => parseMoney(item.etv_max ?? item.etv, NaN) <= etvMax);
  }
  if (price_min !== undefined && Number.isFinite(priceMin)) {
    items = items.filter(item => parseMoney(item.price, NaN) >= priceMin);
  }
  if (price_max !== undefined && Number.isFinite(priceMax)) {
    items = items.filter(item => parseMoney(item.price, NaN) <= priceMax);
  }

  sortItemsArray(items);
  const total = items.length;
  const currentPage = Math.max(1, parseInt(page, 10) || 1);
  const pageLimit = Math.max(1, Math.min(500, parseInt(limit, 10) || 60));
  const start = (currentPage - 1) * pageLimit;

  res.json({
    items: items.slice(start, start + pageLimit),
    total,
    page: currentPage,
    totalPages: Math.ceil(total / pageLimit) || 1,
    limit: pageLimit,
    status: { uvStatus, vhStatus }
  });
});

app.get('/api/items/:asin', (req, res) => {
  const item = allItems.find(candidate => candidate.asin === req.params.asin);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  res.json(item);
});

app.post('/api/delete-item', (req, res) => {
  const { asin } = req.body;
  if (!asin) return res.status(400).json({ error: 'ASIN required' });

  allItems = allItems.filter(item => item.asin !== asin);
  pinnedAsins.delete(asin);
  dismissedPriorityAsins.delete(asin);
  hiddenAsins.delete(asin);
  notifiedAt.delete(asin);

  saveJSON(ITEMS_FILE, allItems);
  saveJSON(PINNED_FILE, [...pinnedAsins]);
  saveJSON(DISMISSED_PRIORITY_FILE, [...dismissedPriorityAsins]);
  saveJSON(HIDDEN_FILE, [...hiddenAsins]);
  persistNotified();
  broadcastLocal('item_deleted', { asin });
  res.json({ success: true, asin });
});

app.post('/api/delete-items', (req, res) => {
  const { asins } = req.body;
  if (!Array.isArray(asins) || !asins.length) return res.json({ success: true });

  const set = new Set(asins);
  allItems = allItems.filter(item => !set.has(item.asin));
  asins.forEach(asin => {
    pinnedAsins.delete(asin);
    dismissedPriorityAsins.delete(asin);
    hiddenAsins.delete(asin);
    notifiedAt.delete(asin);
  });

  saveJSON(ITEMS_FILE, allItems);
  saveJSON(PINNED_FILE, [...pinnedAsins]);
  saveJSON(DISMISSED_PRIORITY_FILE, [...dismissedPriorityAsins]);
  saveJSON(HIDDEN_FILE, [...hiddenAsins]);
  persistNotified();
  broadcastLocal('items_deleted', { asins });
  res.json({ success: true });
});

app.post('/api/clear-all', (req, res) => {
  allItems = [];
  activityLog = [];
  pinnedAsins.clear();
  dismissedPriorityAsins.clear();
  hiddenAsins.clear();
  notifiedAt.clear();

  saveJSON(ITEMS_FILE, []);
  saveJSON(ACTIVITY_FILE, []);
  saveJSON(PINNED_FILE, []);
  saveJSON(DISMISSED_PRIORITY_FILE, []);
  saveJSON(HIDDEN_FILE, []);
  persistNotified();
  broadcastLocal('clear_all', {});
  res.json({ success: true });
});

app.get('/api/pinned', (req, res) => res.json([...pinnedAsins]));

app.post('/api/pin/toggle', (req, res) => {
  const { asin } = req.body;
  if (!asin) return res.status(400).json({ error: 'ASIN required' });

  const isPinned = !pinnedAsins.has(asin);
  if (isPinned) pinnedAsins.add(asin);
  else pinnedAsins.delete(asin);

  const item = allItems.find(candidate => candidate.asin === asin);
  if (item) item.isPinned = isPinned;

  sortItemsArray(allItems);
  saveJSON(PINNED_FILE, [...pinnedAsins]);
  saveJSON(ITEMS_FILE, allItems);
  broadcastLocal('pinned_updated', { asin, isPinned, pinnedAsins: [...pinnedAsins] });
  res.json({ success: true, isPinned, pinnedAsins: [...pinnedAsins] });
});

app.post('/api/priority/dismiss', (req, res) => {
  const { asin, all } = req.body;
  if (all) {
    allItems.forEach(item => {
      if (item.isHighlight) dismissedPriorityAsins.add(item.asin);
    });
  } else if (asin) {
    dismissedPriorityAsins.add(asin);
  }

  allItems.forEach(item => {
    item.isPriorityDismissed = dismissedPriorityAsins.has(item.asin);
  });
  sortItemsArray(allItems);
  saveJSON(DISMISSED_PRIORITY_FILE, [...dismissedPriorityAsins]);
  saveJSON(ITEMS_FILE, allItems);
  broadcastLocal('priority_dismissed', {
    asin,
    all: Boolean(all),
    dismissedPriorityAsins: [...dismissedPriorityAsins]
  });
  res.json({ success: true, dismissedPriorityAsins: [...dismissedPriorityAsins] });
});

app.get('/api/hidden', (req, res) => res.json([...hiddenAsins]));

app.post('/api/hidden/toggle', (req, res) => {
  const { asin } = req.body;
  if (!asin) return res.status(400).json({ error: 'ASIN required' });

  const isHidden = !hiddenAsins.has(asin);
  if (isHidden) hiddenAsins.add(asin);
  else hiddenAsins.delete(asin);

  const item = allItems.find(candidate => candidate.asin === asin);
  if (item) item.isHiddenManual = isHidden;
  saveJSON(HIDDEN_FILE, [...hiddenAsins]);
  saveJSON(ITEMS_FILE, allItems);
  broadcastLocal('hidden_updated', [...hiddenAsins]);
  res.json({ success: true, hidden: isHidden });
});

app.get('/api/keywords', (req, res) => res.json(keywords));

function recheckAllKeywords() {
  allItems.forEach(item => {
    const matches = checkKeywordMatches(item.title, item.price, item.etv);
    item.isHighlight = matches.isHighlight;
    item.isPriceHighlight = matches.isPriceHighlight;
    item.isHide = matches.isHide;
    item.isBlur = matches.isBlur;
  });
  sortItemsArray(allItems);
  saveJSON(ITEMS_FILE, allItems);
  broadcastLocal('keywords_updated', keywords);
}

app.post('/api/keywords', (req, res) => {
  const { type, keyword } = req.body;
  if (!['highlight', 'hide', 'blur'].includes(type)) {
    return res.status(400).json({ error: 'Invalid keyword group type' });
  }

  const value = String(keyword || '').trim();
  if (!value) return res.status(400).json({ error: 'Keyword required' });

  if (!keywords[type]) keywords[type] = [];
  if (!keywords[type].some(item => item.toLowerCase() === value.toLowerCase())) {
    keywords[type].push(value);
    saveJSON(KEYWORDS_FILE, keywords);
    recheckAllKeywords();
  }
  res.json({ success: true, keywords });
});

app.post('/api/keywords/delete', (req, res) => {
  const { type, keyword } = req.body;
  if (!type || !keywords[type]) return res.status(400).json({ error: 'Invalid type' });

  keywords[type] = keywords[type].filter(
    item => item.toLowerCase() !== String(keyword || '').toLowerCase().trim()
  );
  saveJSON(KEYWORDS_FILE, keywords);
  recheckAllKeywords();
  res.json({ success: true, keywords });
});

app.post('/api/identity/rotate', async (req, res) => {
  if (!isVhEnabled()) {
    return res.status(409).json({ error: 'VHelper is disabled' });
  }
  try {
    const identity = await identityManager.rotateIdentity(config.countryCode || 'ca');
    void connectVHelper();
    res.json({ success: true, identity });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/activity', (req, res) => {
  const limit = Math.max(1, Math.min(1000, parseInt(req.query.limit, 10) || 100));
  res.json(activityLog.slice(0, limit));
});

app.get('/api/config', (req, res) => {
  res.json({
    ...config,
    hasToken: Boolean(config.token),
    tokenPreview: config.token
      ? `${config.token.slice(0, 6)}...${config.token.slice(-4)}`
      : '',
    hasWebhook: Boolean(config.discordWebhook),
    status: { uvStatus, vhStatus },
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED
  });
});

app.post('/api/config', (req, res) => {
  const allowedKeys = [
    'domain',
    'countryCode',
    'enableUV',
    'enableVH',
    'token',
    'azUser',
    'device',
    'selectedScreenId',
    'alertQueueId',
    'exploreQueueId',
    'displayName',
    'uvUserAgent',
    'uvIdentificationDelayMs',
    'uvAuthenticationTimeoutMs',
    'uvReconnectDelayMs',
    'telegramToken',
    'telegramChatId',
    'enableTelegram',
    'minPriorityPrice',
    'notificationDedupeMinutes',
    'maxStoredItems',
    'discordWebhook',
    'port'
  ];

  const uvRestartKeys = new Set([
    'domain',
    'enableUV',
    'token',
    'azUser',
    'device',
    'selectedScreenId',
    'alertQueueId',
    'displayName',
    'uvUserAgent',
    'uvIdentificationDelayMs',
    'uvAuthenticationTimeoutMs'
  ]);
  const vhRestartKeys = new Set(['countryCode', 'enableVH']);

  let restartUV = false;
  let restartVH = false;
  let recheckPriority = false;

  allowedKeys.forEach(key => {
    if (req.body[key] === undefined) return;
    let value = req.body[key];

    if (['port', 'maxStoredItems'].includes(key)) value = parseInt(value, 10);
    if (
      [
        'minPriorityPrice',
        'notificationDedupeMinutes',
        'uvIdentificationDelayMs',
        'uvAuthenticationTimeoutMs',
        'uvReconnectDelayMs'
      ].includes(key)
    ) {
      value = Number(value);
    }

    if (value === config[key]) return;
    config[key] = value;
    if (uvRestartKeys.has(key)) restartUV = true;
    if (vhRestartKeys.has(key)) restartVH = true;
    if (key === 'minPriorityPrice') recheckPriority = true;
  });

  saveJSON(CONFIG_FILE, config);
  if (recheckPriority) recheckAllKeywords();

  if (restartUV) {
    if (config.enableUV) connectUltraviner();
    else stopUltraviner('Disabled');
  }

  if (restartVH) {
    if (isVhEnabled()) void connectVHelper();
    else stopVHelper();
  }

  res.json({
    success: true,
    config,
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED
  });
});

// Explicit VHelper kill/enable endpoints.
app.get('/api/vh/status', (req, res) => {
  res.json({
    configuredEnabled: Boolean(config.enableVH),
    effectiveEnabled: isVhEnabled(),
    forceDisabled: VH_FORCE_DISABLED,
    connected: Boolean(vhSocket?.connected),
    status: vhStatus
  });
});

app.post('/api/vh/disable', (req, res) => {
  config.enableVH = false;
  saveJSON(CONFIG_FILE, config);
  stopVHelper('Disabled');
  res.json({ success: true, enableVH: false, status: vhStatus });
});

app.post('/api/vh/enable', (req, res) => {
  if (VH_FORCE_DISABLED) {
    return res.status(409).json({
      error: 'VH is force-disabled by UV_ONLY/DISABLE_VH/ENABLE_VH environment mode.'
    });
  }

  config.enableVH = true;
  saveJSON(CONFIG_FILE, config);
  void connectVHelper();
  res.json({ success: true, enableVH: true, status: 'Connecting...' });
});

app.post('/api/telegram/test', (req, res) => {
  if (!config.telegramToken || !config.telegramChatId) {
    return res.status(400).json({ error: 'Telegram Token and Chat ID required.' });
  }

  sendTelegramNotification({
    title: "Nespresso VertuoPlus Coffee and Espresso Machine by De'Longhi",
    asin: 'B01N7T7K3R',
    firstTwoWords: 'Nespresso VertuoPlus',
    queue: 'RFY',
    sources: ['UV'],
    price: '199.99',
    etv: '199.99',
    isZeroEtv: false,
    isHighlight: true,
    brand: 'Nespresso',
    img_url: '',
    date_added: new Date().toISOString()
  });
  res.json({ success: true });
});

app.post('/api/explore', async (req, res) => {
  const { searchTerm = '', queueTypes = ['RFY', 'AI', 'AFA'], page = 1, pageSize = 36 } =
    req.body;
  const countryId = Ge[config.domain] || 2;
  const normalizedTypes = Array.isArray(queueTypes) ? queueTypes : [queueTypes];
  const primaryQueue =
    normalizedTypes.length === 1 && normalizedTypes[0] !== 'ALL'
      ? normalizedTypes[0]
      : null;

  const queueId = config.exploreQueueId || config.alertQueueId;
  if (!config.token || !queueId) {
    return res.json({
      products: [],
      total: 0,
      searchTerm,
      queueTypes: normalizedTypes,
      uvStatus,
      error: 'Missing token or explore/alert queue ID'
    });
  }

  try {
    const signedPayload = {
      pageSize: String(pageSize),
      page: String(page),
      searchTerm,
      countryId: String(countryId),
      categories: '',
      queueTypes: normalizedTypes.join(','),
      queueId,
      queueName: 'Explore'
    };
    const body = { token: config.token, ...signedPayload };
    const response = await fetch('https://api.ultraviner.com/ultraviner/search', {
      method: 'POST',
      headers: {
        ...signUvPayload(signedPayload, config.token),
        Authorization: `Bearer ${config.token}`,
        Origin: `https://www.${config.domain}`,
        Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
        'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      return res.status(response.status).json({
        products: [],
        total: 0,
        error: (await response.text()).slice(0, 500),
        uvStatus
      });
    }

    const data = await response.json();
    const products = (data.products || []).map(product =>
      formatProductForDisplay(product, primaryQueue)
    );
    sortItemsArray(products);
    res.json({
      products,
      total: products.length,
      searchTerm,
      queueTypes: normalizedTypes,
      uvStatus
    });
  } catch (error) {
    res.status(500).json({ products: [], total: 0, error: error.message, uvStatus });
  }
});

app.post('/api/ingest/items', (req, res) => {
  const { items = [], defaultQueue = 'RFY', source = 'UV' } = req.body;
  if (!Array.isArray(items) || !items.length) {
    return res.status(400).json({ error: 'items array is required' });
  }

  let count = 0;
  items.forEach(raw => {
    const value = { ...raw };
    if (!value.queue && !value.queueType && !value.recommendationType) {
      value.queue = defaultQueue;
    }
    if (ingestItem(value, source, 'BATCH_INGEST')) count += 1;
  });
  res.json({ success: true, ingested: count, total: allItems.length });
});

app.post('/api/ingest/html', (req, res) => {
  const { html, queue = 'RFY', source = 'UV' } = req.body;
  if (!html || typeof html !== 'string') {
    return res.status(400).json({ error: 'html string is required' });
  }

  const parsed = [];
  const tileRegex =
    /<div[^>]*class="[^"]*vvp-item-tile[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/gi;
  let match;

  while ((match = tileRegex.exec(html)) !== null) {
    const tile = match[1];
    const asinMatch =
      tile.match(/data-asin="([A-Z0-9]{10})"/i) || tile.match(/\/dp\/([A-Z0-9]{10})/i);
    if (!asinMatch) continue;

    const titleMatch =
      tile.match(/<span[^>]*class="[^"]*a-truncate-full[^"]*"[^>]*>([\s\S]*?)<\/span>/i) ||
      tile.match(/<a[^>]*class="[^"]*a-link-normal[^"]*"[^>]*>([\s\S]*?)<\/a>/i) ||
      tile.match(/alt="([^"]+)"/i);
    const imageMatch =
      tile.match(/src="([^"]+media-amazon\.com[^"]+)"/i) || tile.match(/src="([^"]+)"/i);
    const recommendationMatch = tile.match(/data-recommendation-type="([^"]+)"/i);

    parsed.push({
      asin: asinMatch[1],
      title: titleMatch
        ? titleMatch[1].replace(/<[^>]+>/g, '').trim()
        : 'Vine Item',
      img_url: imageMatch?.[1] || null,
      queue: recommendationMatch?.[1] || queue,
      price: 'N/A',
      etv: 'N/A'
    });
  }

  let count = 0;
  parsed.forEach(item => {
    if (ingestItem(item, source, 'HTML_INGEST')) count += 1;
  });
  res.json({ success: true, count, items: parsed.slice(0, 10), total: allItems.length });
});

app.post('/api/uv/test-token', async (req, res) => {
  const token = req.body.token || config.token;
  if (!token) return res.status(400).json({ error: 'Token is required' });

  const countryId = Ge[config.domain] || 2;
  const queueId = config.exploreQueueId || config.alertQueueId;
  if (!queueId) return res.status(400).json({ error: 'Queue ID is required' });

  const signedPayload = {
    pageSize: '10',
    page: '1',
    searchTerm: '',
    countryId: String(countryId),
    categories: '',
    queueTypes: 'RFY,AI,AFA',
    queueId,
    queueName: 'Explore'
  };

  try {
    const response = await fetch('https://api.ultraviner.com/ultraviner/search', {
      method: 'POST',
      headers: {
        ...signUvPayload(signedPayload, token),
        Authorization: `Bearer ${token}`,
        Origin: `https://www.${config.domain}`,
        Referer: `https://www.${config.domain}/vine/vine-items?ultraviner`,
        'User-Agent': config.uvUserAgent || DEFAULT_CONFIG.uvUserAgent
      },
      body: JSON.stringify({ token, ...signedPayload })
    });
    const text = await response.text();
    if (!response.ok) {
      return res.status(response.status).json({ success: false, error: text });
    }

    const data = JSON.parse(text);
    res.json({
      success: true,
      count: (data.products || []).length,
      message: 'Token valid; UV search API connected.'
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/uv/test-drop', (req, res) => {
  const randomAsin = `B0${Math.random().toString(36).slice(2, 10).toUpperCase()}`.slice(0, 10);
  const item = ingestItem(
    {
      title: 'Ultraviner Test Drop: Nespresso Vertuo Coffee Machine',
      asin: randomAsin,
      queue: 'RFY',
      price: '199.99',
      etv: '199.99',
      brand: 'Nespresso',
      img_url: 'https://m.media-amazon.com/images/I/71wK+o8oYVL._AC_SL1500_.jpg',
      date: new Date().toISOString()
    },
    'UV',
    'TEST_LIVE'
  );
  res.json({ success: true, item });
});

app.post('/api/uv/reconnect', (req, res) => {
  config.enableUV = true;
  saveJSON(CONFIG_FILE, config);
  connectUltraviner();
  res.json({ success: true, status: 'Connecting...' });
});

app.get('/api/uv/diagnostics', (req, res) => {
  const identity = effectiveUvIdentity();
  res.json({
    uvStatus,
    vhStatus,
    isWsOpen: Boolean(uvWs && uvWs.readyState === WebSocket.OPEN),
    uvAuthenticated,
    uvConnectedAt,
    uvLastFrameAt,
    uvLastAlertAt,
    reconnectBlocked: uvReconnectBlocked,
    hasToken: Boolean(config.token),
    tokenPreview: config.token ? `${config.token.slice(0, 6)}...${config.token.slice(-4)}` : 'None',
    identity,
    recentFrames: uvRecentFrames,
    totalItems: allItems.length,
    uvCount: allItems.filter(item => (item.sources || []).includes('UV')).length,
    vhCount: allItems.filter(item => (item.sources || []).includes('VH')).length,
    effectiveVHEnabled: isVhEnabled(),
    vhForceDisabled: VH_FORCE_DISABLED,
    lastUvActivity: activityLog.filter(entry => entry.data?.source === 'UV').slice(0, 10)
  });
});

app.post('/api/sync/refresh', async (req, res) => {
  if (config.token && config.enableUV) await fetchInitialUvCatalog();

  if (isVhEnabled() && vhSocket?.connected) {
    try {
      const identity = await identityManager.getOrCreateIdentity(config.countryCode || 'ca');
      const cid = identityManager.getCID(config.countryCode || 'ca', identity.customerId);
      vhSocket.emit('getLast100', {
        app_version: VH_APP_VERSION,
        uuid: identity.uuid,
        cid,
        fid: '',
        countryCode: config.countryCode || 'ca',
        limit: 100,
        request_variants: true
      });
    } catch (error) {
      console.error('[Manual Sync] VH error:', error.message);
    }
  }

  if (uvWs?.readyState === WebSocket.OPEN) {
    uvWs.send(JSON.stringify({ type: 'ping' }));
  }

  broadcastLocal('feed_refreshed', { count: allItems.length });
  res.json({ success: true, count: allItems.length, uvStatus, vhStatus });
});

// ============================================================================
// CLEANUP & SERVER START
// ============================================================================
const trimInterval = setInterval(() => {
  const maximum = Number(config.maxStoredItems) || 2000;
  if (allItems.length <= maximum) return;

  const trimmed = allItems.length - maximum;
  allItems.splice(maximum);
  saveJSON(ITEMS_FILE, allItems);
  broadcastLocal('items_trimmed', { count: maximum });
  console.log(`[Cleanup] Trimmed ${trimmed} old items.`);
}, 3600000);

const PORT = Number(process.env.PORT) || Number(config.port) || 3001;

server.listen(PORT, async () => {
  console.log('\n===============================================================');
  console.log('Vine Drop Hub — corrected UV alert routing');
  console.log(`Port: ${PORT}`);
  console.log(`UV: ${config.enableUV ? 'ENABLED' : 'DISABLED'}`);
  console.log(
    `VH: ${isVhEnabled() ? 'ENABLED' : 'COMPLETELY DISABLED'}${
      VH_FORCE_DISABLED ? ' (process-level UV-only mode)' : ''
    }`
  );
  console.log(`Web interface: http://localhost:${PORT}`);
  console.log('===============================================================\n');

  if (config.enableUV) connectUltraviner();
  else stopUltraviner('Disabled');

  if (isVhEnabled()) void connectVHelper();
  else stopVHelper();
});

let isShuttingDown = false;
function gracefulShutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  console.log(`\n[${signal}] Shutting down...`);

  clearInterval(trimInterval);
  stopUltraviner('Stopped');
  stopVHelper('Stopped');

  try {
    localWss.clients.forEach(client => client.terminate());
    localWss.close();
  } catch (_) {}

  server.close(() => {
    console.log('[Shutdown] HTTP server closed.');
    process.exit(0);
  });

  setTimeout(() => process.exit(0), 1000).unref();
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
