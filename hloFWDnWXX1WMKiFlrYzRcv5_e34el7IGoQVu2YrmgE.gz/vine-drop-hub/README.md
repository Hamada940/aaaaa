# Vine Drop Hub — updated UV alert receiver

This package contains the corrected Node server and dashboard for passive Ultraviner alerts. VHelper is disabled by default and can be hard-disabled for a clean UV-only test.

## Files

- `server.js` — Express server, UV WebSocket receiver, optional VH receiver, persistence, REST API, and local `/ws-feed` WebSocket.
- `public/index.html` — dashboard with Live Feed, Explorer, Settings, VH controls, and UV diagnostics.
- `config.json` — populated with the captured UV profile values. It includes the token previously supplied in chat.
- `config.example.json` — safe template without real credentials.
- `package.json` / `package-lock.json` — Node dependencies and commands.

## Where live alerts appear

A real UV WebSocket `alerts` message goes to **Live Feed**, not Explorer:

1. UV sends `type: "alerts"`.
2. `server.js` calls `ingestItem(..., "UV", "alerts")`.
3. The item is stored in `data/items.json`.
4. The server broadcasts `new_item` on `/ws-feed`.
5. `public/index.html` inserts/upserts it on the **Live Feed** tab.

`alertDetail` and `pageData` only enrich an existing Live Feed item through `update_item`; they do not create another drop. Explorer is populated only by a manual `/api/explore` catalog query.

## Requirements

- Node.js 20 recommended
- npm

Check versions:

```bash
node -v
npm -v
```

## Install

```bash
cd ~/vine
npm ci
```

Or, if `npm ci` reports a lock-file problem:

```bash
npm install
```

## Configuration

`config.json` is already populated with the captured UV identity and has:

```json
"enableUV": true,
"enableVH": false
```

Protect it:

```bash
chmod 600 config.json
```

The supplied token was exposed in chat. It is present because explicitly requested, but replacing it with a newly issued token is strongly recommended.

The required UV fields are:

- `token`
- `azUser` (raw Amazon customer ID or its 64-character SHA-256 hash)
- `device`
- `selectedScreenId`
- `alertQueueId`
- `domain`

`exploreQueueId` may remain empty; the server falls back to `alertQueueId` for catalog requests.

## Start in hard UV-only mode

On Ubuntu/Linux:

```bash
UV_ONLY=1 NODE_OPTIONS=--dns-result-order=ipv4first node server.js
```

Or with npm:

```bash
NODE_OPTIONS=--dns-result-order=ipv4first npm run start:uv-only
```

Hard UV-only mode prevents VH from being enabled by the UI or API for that process.

Normal mode, while still respecting `"enableVH": false` in config:

```bash
NODE_OPTIONS=--dns-result-order=ipv4first npm start
```

Stop with `Ctrl+C`.

## Open the dashboard

Locally:

```text
http://127.0.0.1:3001
```

For a remote VPS, do not expose port 3001 publicly: the dashboard APIs do not currently require authentication and the settings endpoint contains credentials. Use an SSH tunnel from your computer:

```bash
ssh -L 3001:127.0.0.1:3001 ubuntu@YOUR_SERVER_IP
```

Then open:

```text
http://127.0.0.1:3001
```

## Clean passive UV test

1. Open **Settings**.
2. Confirm **Enable Ultraviner (UV)** is selected.
3. Confirm **Enable VHelper (VH)** is not selected.
4. Click **Prepare Clean UV-Only Test**. This stops VH and clears old VH/history records that could otherwise make a real UV alert look like a merge.
5. Do **not** click **Catalog Backfill** during the passive test.
6. Watch **UV Diagnostics** and the terminal.

Expected authentication sequence:

```text
[UV WS] Socket open; waiting before identification.
[UV WS] Identification queued: ...
[UV WS] Identification frame flushed (... bytes).
[UV FRAME] type=connected products=0
[UV WS] Session authenticated.
[UV FRAME] type=plan products=0
[UV WS] Plan: ultimate
```

Expected real alert sequence:

```text
[UV FRAME] type=alerts products=1
[UV LIVE] alerts: 1 item(s)
[New Drop] [UV] [AI] ...
```

Possible enrichment afterward:

```text
[UV FRAME] type=alertDetail products=1
[UV DETAIL] Enriched existing item: ...
```

## Runtime controls

Disable VH immediately:

```bash
curl -X POST http://127.0.0.1:3001/api/vh/disable
```

Check VH state:

```bash
curl http://127.0.0.1:3001/api/vh/status
```

Force a UV reconnect after correcting configuration:

```bash
curl -X POST http://127.0.0.1:3001/api/uv/reconnect
```

View UV diagnostics:

```bash
curl http://127.0.0.1:3001/api/uv/diagnostics
```

Validate the configured token through the UV search API without printing it:

```bash
curl -sS \
  -X POST \
  -H 'Content-Type: application/json' \
  -d '{}' \
  http://127.0.0.1:3001/api/uv/test-token
```

Clear all stored items/activity before testing:

```bash
curl -X POST http://127.0.0.1:3001/api/clear-all
```

## VPS authentication timeout

The exact packaged token and identity successfully authenticated and received a real UV `alerts` message in a controlled test. If the VPS gets a WebSocket `101` but no `connected` or `plan` response:

1. Confirm Node 20 and `ws` 8.18.3:

   ```bash
   node -v
   npm ls ws
   ```

2. Force IPv4 using the start command above.
3. Test the token with `/api/uv/test-token`.
4. Try a dedicated device UUID while keeping the token, `azUser`, screen, and queue unchanged:

   ```bash
   node <<'NODE'
   const fs = require('fs');
   const crypto = require('crypto');
   const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
   config.device = crypto.randomUUID();
   fs.writeFileSync('config.json', JSON.stringify(config, null, 2) + '\n', { mode: 0o600 });
   console.log('New standalone device:', config.device);
   NODE
   ```

5. If the token test works but WebSocket identification still times out, run the package on the same computer/network where the official extension works. A successful local connection would isolate the VPS/data-centre network or IP as the difference.

After an authentication timeout, automatic reconnect is intentionally blocked to avoid hammering the service. Use **Reconnect UV** or `/api/uv/reconnect` after making a correction.
