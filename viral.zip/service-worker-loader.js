import './assets/index.ts-218b8c6a.js';
