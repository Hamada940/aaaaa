const USERSCRIPT_URL = "https://ultraviner.com/dist/ultraviner.user.js";
const USERSCRIPT_CACHE_KEY = "ultraviner_userscript";
const USERSCRIPT_VERSION_KEY = "ultraviner_userscript_version";
const MIN_VERSION = "1.0.17";

/**
 * GM polyfill that wraps chrome.storage and messaging
 */
const GM_POLYFILL = `
(function() {
  // Create GM object with Tampermonkey-compatible API
  window.GM = {
    setValue: localStorage.setItem.bind(localStorage),
    getValue: localStorage.getItem.bind(localStorage),
    info: {
      script: {
        version: "2.0.7",
      },
    },
  };
  
  // Ensure React and ReactDOM are available before marking script as loaded
  // This prevents race conditions when loading from CDN
  function waitForReact() {
    return new Promise((resolve) => {
      const maxWait = 10000; // 10 second timeout
      const startTime = Date.now();
      const checkInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        
        if (window.React && window.ReactDOM) {
          clearInterval(checkInterval);
          resolve(true);
        } else if (elapsed > maxWait) {
          clearInterval(checkInterval);
          console.warn('React/ReactDOM did not load within timeout. React:', !!window.React, 'ReactDOM:', !!window.ReactDOM);
          resolve(false);
        }
      }, 50);
    });
  }
  
  // Wait for React/ReactDOM, then mark script as loaded
  waitForReact().then(function() {
    window.__ultraviner_loaded__ = true;
  });
})();
`;

// Check if userScripts API is available
function isUserScriptsAvailable() {
  try {
    chrome.userScripts.getScripts();
    return true;
  } catch {
    return false;
  }
}

// Initialize extension on install/update
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install" || details.reason === "update") {
    // Clear cache on update to force re-download
    await chrome.storage.local.remove(USERSCRIPT_CACHE_KEY);
    await registerUserScript();
  }
});

// Ensure userScript is registered when extension starts
chrome.runtime.onStartup.addListener(async () => {
  await registerUserScript();
});

// Monitor for userScript permission changes
// When user enables "Allow user scripts", automatically re-register
chrome.permissions.onAdded.addListener(async (permissions) => {
  if (
    permissions.permissions &&
    permissions.permissions.includes("userScripts")
  ) {
    console.log("userScripts permission granted - registering userScript");
    await registerUserScript();
  }
});

// Periodic check every 5 seconds to see if userScript API became available
let lastAvailable = isUserScriptsAvailable();
setInterval(async () => {
  const nowAvailable = isUserScriptsAvailable();
  // If it wasn't available before but is now, register the userScript
  if (!lastAvailable && nowAvailable) {
    console.log("userScripts API became available - registering userScript");
    await registerUserScript();
  }
  lastAvailable = nowAvailable;
}, 5000);

/**
 * Extract @require URLs from userScript metadata
 */
function extractRequiredScripts(scriptContent) {
  const requireRegex = /\/\/\s*@require\s+(.+)/g;
  const requires = [];
  let match;

  while ((match = requireRegex.exec(scriptContent)) !== null) {
    requires.push(match[1].trim());
  }

  return requires;
}

/**
 * Fetch external dependencies with retries
 */
async function fetchRequiredScripts(urls) {
  const scripts = [];
  const maxRetries = 3;

  for (const url of urls) {
    let lastError;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(
          `Fetching required script: ${url} (attempt ${attempt}/${maxRetries})`,
        );
        const response = await fetch(url, {
          cache: "no-store",
          timeout: 15000,
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const content = await response.text();

        // Validate the content is not empty
        if (!content || content.trim().length === 0) {
          throw new Error("Downloaded script is empty");
        }

        scripts.push(content);
        console.log(
          `Successfully fetched ${url}, size: ${content.length} bytes`,
        );
        break; // Success, exit retry loop
      } catch (error) {
        lastError = error;
        console.error(
          `Failed to fetch required script ${url} (attempt ${attempt}/${maxRetries}):`,
          error,
        );
        if (attempt < maxRetries) {
          // Wait before retrying
          await new Promise((r) => setTimeout(r, 1000 * attempt));
        }
      }
    }

    if (scripts.length === urls.indexOf(url)) {
      // Script wasn't added (all retries failed)
      console.error(
        `Failed to fetch required script ${url} after ${maxRetries} attempts:`,
        lastError,
      );
    }
  }

  return scripts;
}

/**
 * Remove @require lines from script content
 */
function removeRequireDirectives(scriptContent) {
  return scriptContent.replace(/\/\/\s*@require\s+.+\n?/g, "");
}

/**
 * Download userScript from server
 */
async function downloadUserScript() {
  try {
    const response = await fetch(USERSCRIPT_URL + "?ts=" + Date.now());
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const scriptContent = await response.text();

    // Validate before caching - check if script has version or is valid content
    const versionMatch = scriptContent.match(/@version\s+(\d+(?:\.\d+)*)/);
    let version = versionMatch ? versionMatch[1] : null;

    // If no version found, just log warning but continue (script might be valid)
    if (!version) {
      console.warn("No version found in userScript, proceeding anyway");
      version = "0.0.0";
    }

    // Check if version is acceptable
    if (parseFloat(version) < parseFloat(MIN_VERSION)) {
      console.warn(
        `Script version ${version} is older than minimum ${MIN_VERSION}, but proceeding`,
      );
    }

    // Validate that script is not empty
    if (!scriptContent || scriptContent.trim().length === 0) {
      throw new Error("Downloaded script is empty");
    }

    await chrome.storage.local.set({
      [USERSCRIPT_CACHE_KEY]: scriptContent,
      [USERSCRIPT_VERSION_KEY]: version,
    });

    console.log(`UserScript downloaded successfully (version: ${version})`);
    return scriptContent;
  } catch (error) {
    console.error("Failed to download userScript:", error);
    throw error;
  }
}

/**
 * Register userScript using chrome.userScripts API
 */
async function registerUserScript() {
  if (!isUserScriptsAvailable()) {
    console.warn(
      "userScripts API not available. User may need to enable 'Allow User Scripts' toggle.",
    );
    return;
  }

  try {
    // Unregister existing script first
    try {
      await chrome.userScripts.unregister({ ids: ["ultraviner"] });
      console.log("Unregistered existing userScript");
    } catch (e) {
      // Script might not exist yet, that's fine
    }

    // Try to get cached script
    const cached = await chrome.storage.local.get(USERSCRIPT_CACHE_KEY);
    let scriptContent = cached[USERSCRIPT_CACHE_KEY];

    // If not cached or invalid, download it
    if (!scriptContent) {
      console.log("No cached script found, downloading from server...");
      try {
        scriptContent = await downloadUserScript();
      } catch (error) {
        console.error("Failed to download userScript:", error);
        notifyContentScriptsOfMissingScript();
        return;
      }
    } else {
      console.log("Using cached userScript");
    }

    // Extract @require URLs from the script
    const requiredUrls = extractRequiredScripts(scriptContent);
    console.log(`Found ${requiredUrls.length} required scripts:`, requiredUrls);

    // Fetch required scripts
    let requiredScripts = [];
    if (requiredUrls.length > 0) {
      requiredScripts = await fetchRequiredScripts(requiredUrls);
      console.log(
        `Successfully fetched ${requiredScripts.length} required scripts`,
      );
    }

    // Remove @require directives from main script
    const cleanedScript = removeRequireDirectives(scriptContent);

    // Configure the user script world for messaging
    await chrome.userScripts.configureWorld({
      messaging: true,
      csp: "script-src 'self' 'wasm-unsafe-eval'; object-src 'self';",
    });

    // Combine all scripts: GM polyfill + required dependencies + main script
    // Add a safety wrapper to ensure React/ReactDOM are available before main script runs
    const injectionCode = `
${GM_POLYFILL}

// Load required dependencies (React, ReactDOM, etc.)
${requiredScripts.join("\n")}

// Safety wrapper to ensure React/ReactDOM are globally available
(function() {
  if (typeof window === 'undefined') {
    console.error('Window object not available');
    return;
  }
  
  // Verify React libraries loaded correctly
  if (!window.React) {
    console.error('React library failed to load or is undefined');
  }
  if (!window.ReactDOM) {
    console.error('ReactDOM library failed to load or is undefined');
  }
  
  // Export to global for backward compatibility
  if (window.React) {
    window.React = window.React;
  }
  if (window.ReactDOM) {
    window.ReactDOM = window.ReactDOM;
  }
})();

// Main script - now guaranteed React/ReactDOM are in global scope
${cleanedScript}
`.trim();

    console.log(`Total injection code size: ${injectionCode.length} bytes`);

    // Register the userScript
    await chrome.userScripts.register([
      {
        id: "ultraviner",
        matches: [
          "*://*.amazon.com/vine/*",
          "*://*.amazon.co.uk/vine/*",
          "*://*.amazon.ca/vine/*",
          "*://*.amazon.fr/vine/*",
          "*://*.amazon.it/vine/*",
          "*://*.amazon.de/vine/*",
          "*://*.amazon.es/vine/*",
          "*://*.amazon.co.jp/vine/*",
          "*://*.amazon.com.au/vine/*",
          "*://*.amazon.sg/vine/*",
        ],
        js: [{ code: injectionCode }],
        runAt: "document_start",
        world: "MAIN",
      },
    ]);

    console.log("UltraViner userScript registered successfully");
  } catch (error) {
    console.error("Error registering userScript:", error);
    notifyContentScriptsOfMissingScript();
  }
}

/**
 * Notify content scripts to show download prompt
 */
function notifyContentScriptsOfMissingScript() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (
        tab.url &&
        (tab.url.includes("amazon.com/vine/") ||
          tab.url.includes("amazon.co.uk/vine/") ||
          tab.url.includes("amazon.ca/vine/"))
      ) {
        chrome.tabs
          .sendMessage(tab.id, { action: "showDownloadPrompt" })
          .catch(() => {});
      }
    });
  });
}

// Message listener for content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "setCountry" && message.country) {
    chrome.storage.local.set({ ultraviner_country: message.country });
  } else if (message.action === "retryRegisterUserScript") {
    registerUserScript().then(() => {
      sendResponse({ success: true });
    });
    return true; // Will respond asynchronously
  } else if (message.action === "isUserScriptsAvailable") {
    sendResponse({ available: isUserScriptsAvailable() });
  } else if (message.action === "isUserScriptRunning") {
    // Check if userScript was successfully registered
    if (!chrome?.userScripts?.getScripts) {
      console.log("userScripts API not available");
      sendResponse({ isRunning: false });
      return;
    }

    try {
      chrome.userScripts.getScripts((scripts) => {
        const isRunning = scripts && scripts.some((s) => s.id === "ultraviner");
        console.log("isUserScriptRunning check - scripts found:", isRunning);
        sendResponse({ isRunning: isRunning });
      });
    } catch (error) {
      console.log("userScripts not ready yet:", error.message);
      sendResponse({ isRunning: false });
    }
    return true; // Will respond asynchronously
  } else if (message.action === "openExtensionSettings") {
    // Open the extensions page for this extension
    const extensionId = message.extensionId;
    chrome.tabs.create({
      url: `chrome://extensions/?id=${extensionId}`,
    });
    sendResponse({ success: true });
  }
});

// Action click handler
chrome.action.onClicked.addListener(async (tab) => {
  const country = await chrome.storage.local.get("ultraviner_country");
  if (country.ultraviner_country) {
    chrome.tabs.create({
      url: `https://amazon.${country.ultraviner_country}/vine/vine-items?ultraviner`,
    });
  } else {
    chrome.tabs.create({
      url: "https://ultraviner.com/undefined_country.html",
    });
  }
});
