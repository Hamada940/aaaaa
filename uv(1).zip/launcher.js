// Country detection and messaging
const hostname = window.location.hostname;
const amazonUrl = `https://${hostname}`;
const domainTermination = amazonUrl.split(".").splice(2).join(".");

// Send country information to service worker
chrome.runtime.sendMessage({
  action: "setCountry",
  country: domainTermination,
});

// Check if userScript actually ran by sending a message to service worker
// The service worker will tell us if the script was registered
setTimeout(async () => {
  try {
    const response = await chrome.runtime.sendMessage({
      action: "isUserScriptRunning",
    });

    if (!response || !response.isRunning) {
      console.log("UserScript is not running - showing setup prompt");
      showSetupPrompt();
    }
  } catch (error) {
    console.log("Error checking userScript status:", error);
    // If we can't communicate with service worker, show prompt to be safe
    showSetupPrompt();
  }
}, 1000);

// Also listen for messages from service worker
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "showDownloadPrompt") {
    showSetupPrompt();
  }
});

/**
 * Show setup prompt dialog
 */
function showSetupPrompt() {
  if (document.getElementById("ultraviner-setup-prompt")) {
    return; // Already showing
  }

  const SETUP_PROMPT_HTML = `
    <div id="ultraviner-setup-prompt" style="
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      padding: 16px;
      box-sizing: border-box;
    ">
      <div style="
        background: white;
        border-radius: 12px;
        padding: 24px;
        width: 100%;
        max-width: 550px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        text-align: center;
        max-height: 90vh;
        overflow-y: auto;
        box-sizing: border-box;
      ">
        <img src="https://ultraviner.com/favicon.png" alt="Ultraviner" style="
          height: 48px;
          margin-bottom: 16px;
        ">
        <h2 style="
          margin: 0 0 12px 0;
          color: #232f3e;
          font-size: clamp(18px, 5vw, 22px);
          font-weight: 600;
        ">One More Step to Enable Ultraviner</h2>
        <p style="
          margin: 0 0 24px 0;
          color: #555;
          font-size: clamp(12px, 4vw, 14px);
          line-height: 1.6;
        ">
          Ultraviner requires a special permission to run. This is a security feature on Chromium that keeps your browser safe.
          <br><br>
          <strong>Follow these steps:</strong>
        </p>
        
        <div style="
          text-align: left;
          background: #f5f5f5;
          border-radius: 8px;
          padding: 16px;
          margin-bottom: 20px;
          overflow-x: auto;
        ">
          <ol style="
            margin: 0;
            padding-left: 20px;
            color: #333;
            font-size: clamp(12px, 3vw, 13px);
            line-height: 1.8;
          ">
            <li>Click the <strong>"Open Extension Settings"</strong> button below</li>
            <li>Look for the toggle labeled <strong>"Allow User Scripts"</strong></li>
            <li>Turn it <strong>ON</strong></li>
            <li>Come back to this page and refresh</li>
          </ol>
        </div>

        <p style="
          margin: 0 0 20px 0;
          color: #999;
          font-size: clamp(11px, 3vw, 12px);
          background: #fffacd;
          border-left: 3px solid #d87e00;
          padding: 12px;
          border-radius: 4px;
          text-align: left;
        ">
          💡 <strong>Chrome 138+:</strong> The toggle is on this extension's details page.<br>
          <strong>Chrome &lt;138:</strong> You may need to enable Developer Mode first.
        </p>

        <div style="display: flex; flex-direction: column; gap: 10px;">
          <button id="ultraviner-open-settings-btn" style="
            padding: clamp(10px, 3vw, 14px) clamp(16px, 5vw, 24px);
            background: #d87e00;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: clamp(13px, 4vw, 15px);
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
          ">Open Extension Settings</button>
          <button id="ultraviner-reload-btn" style="
            padding: clamp(10px, 3vw, 14px) clamp(16px, 5vw, 24px);
            background: #59974e;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: clamp(13px, 4vw, 14px);
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
          ">Reload Page</button>
          <button id="ultraviner-dismiss-btn" style="
            padding: clamp(10px, 3vw, 14px) clamp(16px, 5vw, 24px);
            background: #f0f0f0;
            color: #333;
            border: none;
            border-radius: 6px;
            font-size: clamp(13px, 4vw, 14px);
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
          ">Close for Now</button>
        </div>
        
        <p style="
          margin: 16px 0 0 0;
          color: #999;
          font-size: clamp(10px, 3vw, 11px);
        ">
          Need help? Check Installation Instructions at <a href="https://ultraviner.com" target="_blank" style="color: #FF9900; text-decoration: none;">ultraviner.com</a>
        </p>
      </div>
    </div>
  `;

  const container = document.createElement("div");
  container.innerHTML = SETUP_PROMPT_HTML;
  document.body.appendChild(container);

  const openSettingsBtn = document.getElementById(
    "ultraviner-open-settings-btn",
  );
  const dismissBtn = document.getElementById("ultraviner-dismiss-btn");
  const reloadBtn = document.getElementById("ultraviner-reload-btn");

  openSettingsBtn.addEventListener("click", () => {
    // Get extension ID from runtime
    const extensionId = chrome.runtime.id;
    // Send message to service worker to open the extensions page
    chrome.runtime.sendMessage({
      action: "openExtensionSettings",
      extensionId: extensionId,
    });
  });

  dismissBtn.addEventListener("click", () => {
    // Remove the prompt
    container.remove();
  });

  reloadBtn.addEventListener("click", () => {
    // Reload the page
    window.location.reload();
  });

  // Add hover effects
  openSettingsBtn.addEventListener("mouseover", () => {
    openSettingsBtn.style.background = "#E6860F";
  });
  openSettingsBtn.addEventListener("mouseout", () => {
    openSettingsBtn.style.background = "#FF9900";
  });

  dismissBtn.addEventListener("mouseover", () => {
    dismissBtn.style.background = "#E0E0E0";
  });
  dismissBtn.addEventListener("mouseout", () => {
    dismissBtn.style.background = "#f0f0f0";
  });
}
